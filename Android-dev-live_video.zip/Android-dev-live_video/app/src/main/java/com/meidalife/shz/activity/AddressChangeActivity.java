package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.model.PositionOutDO;
import com.meidalife.shz.rest.request.RequestAddress;
import com.meidalife.shz.util.LoadUtil;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 修改收获地址
 */
public class AddressChangeActivity extends BaseActivity {

    private static final int STATUS_DEFAULT = 0;
    private static final int STATUS_CHANGE = 1;
    private int mStatus;
    private String addressId;

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.contentLayout)
    ViewGroup contentLayout;

    @Bind(R.id.nickname)
    EditText nickname;
    @Bind(R.id.phone)
    EditText phone;

    @Bind(R.id.matchedAddressRL)
    ViewGroup matchedAddressRL;
    @Bind(R.id.textPickAddress)
    TextView textPickAddress;
    @Bind(R.id.detailAddress)
    EditText detailAddress;

    @Bind(R.id.deleteAddress)
    View deleteAddress;
    @Bind(R.id.setDefaultAddress)
    TextView setDefaultAddress;

    PositionOutDO poiDO;
    AddressItem addressItem = new AddressItem();
    LoadUtil mLoadUtil;

//    String matchAddress = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address_change);
        initActionBar(R.string.title_activity_address_detail, true, true);

        mStatus = getIntent().getIntExtra(Constant.EXTRA_TAG_ADDRESS_STATUS, STATUS_DEFAULT);
        addressId = getIntent().getStringExtra(Constant.EXTRA_TAG_ADDRESS_ID);
        ButterKnife.bind(this);


        setEnable(mStatus == STATUS_CHANGE);

        mButtonRight.setText(R.string.btn_change_address);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mStatus = STATUS_CHANGE;
                setEnable(true);
            }
        });

        mLoadUtil = new LoadUtil(LayoutInflater.from(this));
        xhrAddress();

        initPhoneListener();
    }

    //todo 点击区域
    public void handlePickLocation(View view) {
        Router.sharedRouter().openFormResult("pick/addresslocation", Constant.REQUEST_CODE_PICK_ADDRESS, this);
    }

    private void initEditText() {
        if (addressItem != null) {
//            int index = addressItem.getAddressName().indexOf("市");

            StringBuilder sb = new StringBuilder();
            sb.append(addressItem.getContactorPhone().substring(0, 3) + " ");
            sb.append(addressItem.getContactorPhone().substring(3, 7) + " ");
            sb.append(addressItem.getContactorPhone().substring(7));

            nickname.setText(addressItem.getContactorName());
            phone.setText(sb.toString());
            textPickAddress.setText(addressItem.getMatchedName());
            detailAddress.setText(addressItem.getDetailedAddress());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        //地图选择地址

        if (Constant.REQUEST_CODE_PICK_ADDRESS == requestCode && resultCode == RESULT_OK) {
            poiDO = (PositionOutDO) data.getSerializableExtra("positionDO");
            if (poiDO != null) {
                if (poiDO.getAddByManual() == 1) {
                    textPickAddress.setText(poiDO.getAddress());
                } else {
                    xhrMatchedAddress(poiDO);
                }
            }
        }
    }

    public void handleDeleteAddress(View view) {

        try {
            JSONObject params = new JSONObject();
            params.put("addressId", addressItem.getAddressId());
            showProgressDialog("正在删除");
            RequestAddress.removeAddress(params, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {
                    MessageUtils.showToastCenter("删除成功");
                    hideProgressDialog();
                    finish();
                }

                @Override
                public void onFail(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "删除失败");
                }
            });
        } catch (JSONException e) {

        }
    }

    public void handleSetDefaultAddress(View view) {

        if (mStatus == STATUS_DEFAULT) {
            try {
                JSONObject params = new JSONObject();
                params.put("addressId", addressItem.getAddressId());
                //setRecentUsed原用于最近使用，现用作设置为默认
                RequestAddress.setRecentUsed(params);
                //提示设置成功
                MessageUtils.showToastCenter("已设置为默认");
                finish();
            } catch (JSONException e) {
                MessageUtils.showToastCenter("设置失败，请稍后再试");
            }

        } else if (mStatus == STATUS_CHANGE) {
            setEnable(false);
            mStatus = STATUS_DEFAULT;

            modifyAddress();
        }
    }


    void xhrMatchedAddress(final PositionOutDO poiDO) {
        JSONObject params = new JSONObject();

        try {
            if (poiDO != null) {
                params.put("name", poiDO.getName());
                params.put("address", poiDO.getAddress());
                params.put("poiLongitude", "" + poiDO.getPoiLongitude());
                params.put("poiLatitude", "" + poiDO.getPoiLatitude());
            }

            RequestAddress.matchAddress(params, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {
                    if (result.containsKey("matchedName")) {
                        textPickAddress.setText(result.getString("matchedName"));
                    } else {
                        textPickAddress.setText(poiDO.getName());//与ios逻辑保持一致
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    textPickAddress.setText(poiDO.getName());//与ios逻辑保持一致
                }
            });
        } catch (JSONException e) {

        }
    }


    void modifyAddress() {

        try {
            JSONObject params = new JSONObject();
//                params.put("isEdited", 1);
            params.put("addressId", addressItem.getAddressId());
            params.put("contactorName", nickname.getText().toString());
            params.put("contactorPhone", phone.getText().toString().replace(" ", ""));

            if (poiDO != null) {
                params.put("name", poiDO.getName());
                params.put("address", poiDO.getAddress());
                params.put("poiLongitude", "" + poiDO.getPoiLongitude());
                params.put("poiLatitude", "" + poiDO.getPoiLatitude());
            } else {
                //没有重新选择 使用服务端返回信息
                params.put("name", addressItem.getName());
                params.put("address", addressItem.getAddress());
                params.put("poiLongitude", "" + addressItem.getPoiLongitude());
                params.put("poiLatitude", "" + addressItem.getPoiLatitude());
            }
            params.put("detailedAddress", detailAddress.getText().toString());

            //新增字段
            params.put("matchedName", textPickAddress.getText().toString());

            params.put("selected", 0);

            RequestAddress.modifyAddress(params, new HttpClient.HttpCallback<AddressItem>() {
                @Override
                public void onSuccess(AddressItem result) {
                    /**
                     * 该段代码返回地址数据 给下单页OrderActivity.java选择地址使用
                     */
                    //MessageUtils.showToastCenter("地址修改成功");
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(Constant.EXTRA_TAG_ADDRESS, result);
                    intent.putExtras(bundle);
                    setResult(RESULT_OK, intent);
                    finish();
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "修改失败，请重试");
                    finish();
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setEnable(Boolean bool) {
        nickname.setEnabled(bool);
        if (bool) {
            nickname.setSelection(nickname.length());
        }
        deleteAddress.setVisibility(bool ? View.GONE : View.VISIBLE);
        mButtonRight.setVisibility(bool ? View.GONE : View.VISIBLE);
        setDefaultAddress.setText(bool ? R.string.btn_save_address : R.string.default_setting_address_btn);
        phone.setEnabled(bool);
        matchedAddressRL.setEnabled(bool);
        detailAddress.setEnabled(bool);
    }

    private void initPhoneListener() {
        phone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String contents = Helper.formatMobileNumber(s.toString());
                if (contents.length() != s.toString().length()) {
                    phone.setText(contents);
                    phone.setSelection(contents.length());
                }
            }
        });
    }

    private void xhrAddress() {
        mLoadUtil.loadPre(rootLayout, contentLayout);
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("addressId", addressId);
        HttpClient.get("1.0/address/get", params, AddressItem.class, new HttpClient.HttpCallback<AddressItem>() {
            @Override
            public void onSuccess(AddressItem obj) {
                addressItem = obj;
                initEditText();
                mLoadUtil.loadSuccess(contentLayout);

                setDefaultAddress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFail(HttpError error) {
                mLoadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        xhrAddress();
                    }
                });

                setDefaultAddress.setVisibility(View.GONE);
            }
        });
    }
}
