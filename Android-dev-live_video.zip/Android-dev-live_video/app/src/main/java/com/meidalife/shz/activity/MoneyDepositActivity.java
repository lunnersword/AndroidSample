package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ChargeGridAdapter;
import com.meidalife.shz.adapter.OuterPaywayAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.FontEditText;
import com.meidalife.shz.view.MyListView;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class MoneyDepositActivity extends BaseActivity {

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    View contentView;
    @Bind(R.id.tv_balance_money)
    TextView mBalanceMoneyTv;
    @Bind(R.id.grid_charge)
    GridView mChargeGridView;
    @Bind(R.id.listViewPayWays)
    MyListView listViewPayWays;
    @Bind(R.id.moneyAmount)
    FontEditText moneyAmount;
    @Bind(R.id.btnConfirm)
    View btnConfirm;
    private LoadUtil loadUtil;
    private JSONArray outerList;
    private int payType = -1;
    private String tradeNumber;

    private List<Integer> mMoneyList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_money_deposit);
        initActionBar(R.string.title_activity_money_deposit, true);
        loadUtil = new LoadUtil(getLayoutInflater());
        ButterKnife.bind(this);

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String moneyStr = moneyAmount.getText().toString();
                if (!(moneyStr.length() > 0)) {
                    MessageUtils.showToastCenter("你还没有输入金额");
                    return;
                }

                int moneyInt = Integer.valueOf(moneyStr);
                if (!(moneyInt > 0)) {
                    MessageUtils.showToastCenter("请输入大于0的金额");
                    return;
                }

                int index = listViewPayWays.getCheckedItemPosition();
                JSONObject item = outerList.getJSONObject(index);
                payType = item.getIntValue("type");

                JSONObject params = new JSONObject();
                params.put("gwPayway", payType);
                params.put("amount", moneyInt * 100);

                startDeposit(params);
            }
        });

        fetchPayWays();

        renderMoneys();
    }

    private void renderMoneys() {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < mMoneyList.size(); i++) {
            if (mMoneyList.get(i) > 0) {
                list.add(String.format("%d元", mMoneyList.get(i)));
            } else {
                list.add("自定义");
            }
        }
        ChargeGridAdapter adapter = new ChargeGridAdapter(this, list);
        adapter.setItemSelectedListener(new ChargeGridAdapter.OnItemSelectedListener() {
            @Override
            public void onSelected(int position) {
                if (mMoneyList.get(position) > 0) {
                    moneyAmount.getText().clear();
                    moneyAmount.getText().append(String.format("%d", mMoneyList.get(position)));
                    moneyAmount.setEnabled(false);
                } else {
                    moneyAmount.setEnabled(true);
                    moneyAmount.requestFocus();
                    moneyAmount.setSelection(moneyAmount.getText().length());
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(0, InputMethodManager.SHOW_FORCED);
                }
            }
        });
        mChargeGridView.setAdapter(adapter);
    }

    private void startDeposit(JSONObject params) {
        showProgressDialog("正在充值", false);
        HttpClient.get("1.0/recharge/orderAndPay", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {

            @Override
            public void onSuccess(JSONObject payInfo) {
                hideProgressDialog();
                tradeNumber = payInfo.containsKey(Pay.TAG_PAY_TRADE_NUMBER) ? payInfo.getString(Pay.TAG_PAY_TRADE_NUMBER) : "";

                if (payInfo.getIntValue(Pay.TAG_PAY_WAY) == Pay.PAY_WAY_ALIPAY) {
                    Pay.payWithAlipay(MoneyDepositActivity.this, payInfo.getString("signPayStr"), new Pay.PayCallback() {
                        @Override
                        public void success() {
                            MessageUtils.showCustomizeToast(LayoutInflater.from(MoneyDepositActivity.this)
                                    .inflate(R.layout.view_toast_charge_success, null), Toast.LENGTH_LONG);
                            finish();
                        }

                        @Override
                        public void failure(Error error) {
                            MessageUtils.showCustomizeToast(LayoutInflater.from(MoneyDepositActivity.this)
                                    .inflate(R.layout.view_toast_charge_failed, null), Toast.LENGTH_SHORT);
                        }
                    });
                } else if (payInfo.getIntValue(Pay.TAG_PAY_WAY) == Pay.PAY_WAY_WECHAT) {
                    Pay.payWithWechat(MoneyDepositActivity.this, payInfo.getJSONObject("wxPay"));
                }
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showCustomizeToast(LayoutInflater.from(MoneyDepositActivity.this)
                        .inflate(R.layout.view_toast_charge_failed, null), Toast.LENGTH_SHORT);
            }
        });
    }

    private void fetchPayWays() {
        loadUtil.loadPre(rootView, contentView);
        JSONObject params = new JSONObject();
        HttpClient.get("1.0/recharge/payway", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {

            @Override
            public void onSuccess(JSONObject payInfo) {
                loadUtil.loadSuccess(contentView);

                outerList = payInfo.getJSONArray("outerPayways");
                OuterPaywayAdapter outerPaywayAdapter = new OuterPaywayAdapter(MoneyDepositActivity.this, outerList);
                listViewPayWays.setAdapter(outerPaywayAdapter);
                for (int i = 0; i < outerList.size(); i++) {
                    JSONObject payway = outerList.getJSONObject(i);
                    if (payway.getIntValue("selected") == 1) {
                        listViewPayWays.setItemChecked(i, true);
                    } else {
                        listViewPayWays.setItemChecked(i, false);

                    }
                }

                int[] moneys = payInfo.getObject("presetAmounts", int[].class);
                mMoneyList.clear();
                for (int i = 0; i < moneys.length; i++) {
                    mMoneyList.add(moneys[i]/100);
                }
                mMoneyList.add(0);
                renderMoneys();

                long balance = payInfo.getIntValue("balance");
                String balanceStr = String.format("%d.%d", balance/100, balance%100);
                mBalanceMoneyTv.setText(balanceStr);
            }

            @Override
            public void onFail(HttpError error) {
                loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        fetchPayWays();
                    }
                });

            }
        });
    }

}
