package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.FavoritePersonFragment;
import com.meidalife.shz.activity.fragment.FavoriteServiceFragment;
import com.usepropeller.routable.Router;

import java.util.HashMap;
import java.util.Map;

/**
 * 我的收藏
 * Created by zuozheng
 */

public class FavoriteActivity extends BaseActivity {


    public final int TYPE_SERVICE = 1; // 服务
    public final int TYPE_PERSON = 2; //人

    private FragmentManager mFragmentManager;

    private int selectType = TYPE_SERVICE;

    public FavoriteServiceFragment mServiceFragment;
   // public FavoritePersonFragment mPersonFragment;

    private Map<View, TextView> barMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        initActionBar("我的收藏", true, false);//统一继承BaseActivity风格

//        ButterKnife.bind(this);

        mFragmentManager = getSupportFragmentManager();
    //    initBar();
        updateContentView(selectType);
    }

//    void initBar() {
//
//        View.OnClickListener orderTypeClick = new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                for (Map.Entry<View, TextView> e : barMap.entrySet()) {
//                    View onView = e.getKey();
//                    TextView label = e.getValue();
//                    if (onView == v) {
//                        onView.setBackgroundResource(R.drawable.order_list_type_bottom);
//                        label.setTextColor(getResources().getColor(R.color.brand_b));
//                        selectType = (Integer) onView.getTag();
//                    } else {
//                        onView.setBackgroundResource(R.color.white);
//                        label.setTextColor(getResources().getColor(R.color.grey_a));
//                    }
//                }
//                updateContentView(selectType);
//            }
//        };
//
////        View officialAuthView = findViewById(R.id.title_left);
////        TextView allLabel = (TextView) findViewById(R.id.title_left_label);
//        barMap.put(officialAuthView, allLabel);
//        officialAuthView.setOnClickListener(orderTypeClick);
//        officialAuthView.setTag(TYPE_SERVICE);
//        officialAuthView.setBackgroundResource(R.drawable.order_list_type_bottom);
//        allLabel.setTextColor(getResources().getColor(R.color.brand_b));
//
////        View personalAuthView = findViewById(R.id.title_right);
//        TextView acceptLabel = (TextView) findViewById(R.id.title_right_label);
//        barMap.put(personalAuthView, acceptLabel);
//        personalAuthView.setOnClickListener(orderTypeClick);
//        personalAuthView.setTag(TYPE_PERSON);
//        personalAuthView.setBackgroundResource(R.color.white);
//        acceptLabel.setTextColor(getResources().getColor(R.color.grey_a));
//
//    }

    private void updateContentView(int selectType) {

        if (selectType == TYPE_SERVICE) {
            mServiceFragment = new FavoriteServiceFragment();
            mFragmentManager.beginTransaction().replace(R.id.content_frame, mServiceFragment)
                    .commitAllowingStateLoss();

        }
//        else {
//            mPersonFragment = new FavoritePersonFragment();
//            mFragmentManager.beginTransaction().replace(R.id.content_frame, mPersonFragment)
//                    .commitAllowingStateLoss();
//
//        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().openFormResult("signin", Constant.REQUEST_CODE_SIGNIN,
                    FavoriteActivity.this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (Constant.REQUEST_CODE_SIGNIN == requestCode && resultCode == RESULT_OK) {
            updateContentView(selectType);
        } else if (Constant.REQUEST_CODE_SIGNIN == requestCode && resultCode == RESULT_CANCELED) {
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        mFragmentManager = null;
       // mPersonFragment = null;
        mServiceFragment = null;
        super.onDestroy();
    }
}
