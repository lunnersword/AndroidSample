package com.meidalife.shz;

/**
 * Created by zuozheng on 16/4/05.
 */
public class BroadcastConstant {
    public static final String COMMENT = "com.meidalife.shz.COMMENT";
    public static final String ITEMCLICK = "com.meidalife.shz.ITEMCLICK";
}
