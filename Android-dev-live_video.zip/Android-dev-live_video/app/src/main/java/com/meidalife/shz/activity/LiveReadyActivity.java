package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.LiveServiceRecyclerAdapter;
import com.meidalife.shz.manager.LiveManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import org.json.JSONException;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujian on 16/2/16.
 */
public class LiveReadyActivity extends BaseActivity implements View.OnClickListener {
    private static int TEXT_LENGTH_LIMIT_TITLE = 20;
    private final int GET_BING_SERVICE = 88;

    @Bind(R.id.bindService)
    View bindService;
    @Bind(R.id.picView)
    SimpleDraweeView picView;
    @Bind(R.id.removeImage)
    TextView removeImage;
    @Bind(R.id.selectPicView)
    View selectPicView;
    @Bind(R.id.startLive)
    View startLive;
    @Bind(R.id.liveContro)
    EditText liveContro;
    @Bind(R.id.textTitleLimit)
    TextView textTitleLimit;
    @Bind(R.id.canDo)
    TextView canDo;
    @Bind(R.id.bindHint)
    View bindHint;
    @Bind(R.id.bindTitle)
    View bindTitle;
    private String picPath;
    private boolean submit = false;
    private boolean uploadComplete = false;
    private boolean uploading = false;
    private String uploadImage;
    private Bundle serviceData;
    private File cropImage;
    private String avatarUrl;

    private List<ServiceItem> mData;
    private LiveServiceRecyclerAdapter liveServiceRecyclerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_live_ready);
        ButterKnife.bind(this);

        initActionBar(R.string.text_live_ready, true);
        initListener();
        hideIMM();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void initListener() {
        liveContro.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textTitleLimit.setText("" + s.toString().length());
                if (s.toString().length() > TEXT_LENGTH_LIMIT_TITLE) {
                    textTitleLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textTitleLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        removeImage.setOnClickListener(this);
        startLive.setOnClickListener(this);
        bindService.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bindService:
                Intent bindServiceIntent = new Intent(this, LiveBindServiceActivity.class);
                startActivityForResult(bindServiceIntent, GET_BING_SERVICE);
                break;
            case R.id.startLive:
                handleStartLive();
                break;
            case R.id.removeImage:
                removeImage.setVisibility(View.GONE);
                picView.setVisibility(View.GONE);
                selectPicView.setEnabled(true);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK)
            return;
        if (requestCode == GET_BING_SERVICE) {
            serviceData = data.getBundleExtra("params");
            if (serviceData == null)
                return;
            bindHint.setVisibility(View.GONE);
            bindTitle.setVisibility(View.VISIBLE);
            canDo.setText(serviceData.getString("title"));
            canDo.setVisibility(View.VISIBLE);

        }
        if (requestCode == Constant.REQUEST_CODE_PICK_PHOTO) {
            Bundle bundle = data.getExtras();
            ArrayList images = bundle.getStringArrayList("images");
            if (images.size() > 0) {
                avatarUrl = (String) images.get(0);
                Bundle params = new Bundle();
                params.putString("image_path", avatarUrl);
                params.putBoolean("return-data", false);

                cropImage = new File(ImgUtil.getEditedImagePath(this) +
                        File.separator + "cropped_avatar_" + System.currentTimeMillis() + ".jpg");
                params.putParcelable(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cropImage));
                Router.sharedRouter().openFormResult("cropImage", params,
                        Constant.REQUEST_CODE_CROP_PHOTO, this);
            }
        } else if (requestCode == Constant.REQUEST_CODE_CROP_PHOTO && resultCode == RESULT_OK) {
            if (cropImage != null && cropImage.exists()) {
                Uri uri = Uri.fromFile(new File(cropImage.getAbsolutePath()));
                picView.setImageURI(uri);
                picPath = cropImage.getAbsolutePath();
            } else {
                Uri uri = Uri.fromFile(new File(avatarUrl));
                picView.setImageURI(uri);
                picPath = avatarUrl;
            }
            picView.setVisibility(View.VISIBLE);
            removeImage.setVisibility(View.VISIBLE);
            selectPicView.setEnabled(false);
        }
    }

    private void handleStartLive() {
        if (serviceData == null) {
            MessageUtils.showToastCenter("还未选择直播绑定的服务哦");
            return;
        }

        if (picPath == null) {
            MessageUtils.showToastCenter("还未选择上传封面哦");
            return;
        }

        if (TextUtils.isEmpty(liveContro.getText().toString())) {
            MessageUtils.showToastCenter("还未填写直播介绍哦");
            return;
        }

        if (liveContro.getText().toString().length() > TEXT_LENGTH_LIMIT_TITLE) {
            MessageUtils.showToastCenter("直播介绍不能超过25个字");
            return;
        }

        if (!submit) {
            submit = true;
            showProgressDialog("正在准备", false);

            if (uploadComplete && uploadImage != null) {
                createLive();
            } else {
                uploadImages();
            }
        }
    }

    private void uploadImages() {
        if (!uploading && picPath != null) {
            uploading = true;
            RequestSign.upload(picPath, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    org.json.JSONObject json = (org.json.JSONObject) result;
                    try {
                        uploadImage = json.getString("data");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    uploading = true;
                    uploadComplete = true;
                    if (submit) {
                        createLive();
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    uploading = false;
                    uploadComplete = false;
                    submit = false;
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "准备失败");
                }
            });
        }
    }

    private void createLive() {
        JSONObject params = new JSONObject();
        params.put("itemId", serviceData.get("id"));
        params.put("pic", uploadImage);
        params.put("description", liveContro.getText().toString());
        HttpClient.get("1.0/live/create", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                //hideProgressDialog();
                int liveId = obj.getIntValue("liveId");  //直播ID
                Intent intent = new Intent(LiveReadyActivity.this, LiveActivity.class);
                intent.putExtra("liveId", liveId);
                startActivity(intent);
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                submit = false;
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "准备失败，请重试");
            }
        });
    }

    public void selectPic(View view) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", 1);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, this);
    }

    private static final String TAG = "LiveReadyActivity";
}
