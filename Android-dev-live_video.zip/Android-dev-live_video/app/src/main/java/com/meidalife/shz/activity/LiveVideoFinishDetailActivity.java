package com.meidalife.shz.activity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.LiveRankListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LiveRewardRankDO;
import com.meidalife.shz.rest.model.LiveVideoFinishDO;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.TimeUtils;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.MyListView;
import com.meidalife.shz.view.RankListHead123;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class LiveVideoFinishDetailActivity extends BaseActivity {

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    View contentView;
    @Bind(R.id.hostAvatar)
    SimpleDraweeView hostAvatar;
    @Bind(R.id.hostName)
    FontTextView hostName;
    @Bind(R.id.publishDate)
    FontTextView publishDate;
    @Bind(R.id.liveTitle)
    FontTextView liveTitle;
    @Bind(R.id.liveDescription)
    FontTextView liveDescription;
    @Bind(R.id.rewardCount)
    FontTextView rewardCount;
    @Bind(R.id.visitorCount)
    FontTextView visitorCount;
    @Bind(R.id.durationLiveVideo)
    FontTextView durationLiveVideo;
    @Bind(R.id.rankListHead123)
    RankListHead123 rankListHead123;
    @Bind(R.id.allAmount)
    FontTextView allAmount;
    @Bind(R.id.netAmount)
    FontTextView netAmount;
    @Bind(R.id.liveList)
    MyListView liveList;

    private static final int RANK_LIMIT = 10;
    private List<LiveRewardRankDO> mRewards;
    private LiveRankListAdapter mLiveRankListAdapter;
    private String liveId;
    private LoadUtil loadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_video_finish_detail);
        initActionBar(R.string.title_activity_live_video_finish_detail, true);
        ButterKnife.bind(this);
        loadUtil = new LoadUtil(getLayoutInflater());
        mRewards = new ArrayList<>();
        mLiveRankListAdapter = new LiveRankListAdapter(this, mRewards);
        liveList.setAdapter(mLiveRankListAdapter);

        liveId = getIntent().getStringExtra("liveId");

        fetchFinishData();
    }


    private void fetchFinishData() {
        JSONObject params = new JSONObject();
        params.put("liveId", liveId);
        params.put("limit", RANK_LIMIT);
        loadUtil.loadPre(rootView, contentView);

        HttpClient.get("1.0/live/detail", params, LiveVideoFinishDO.class, new HttpClient.HttpCallback<LiveVideoFinishDO>() {
            @Override
            public void onSuccess(LiveVideoFinishDO finishDO) {
                initView(finishDO);
                loadUtil.loadSuccess(contentView);
            }

            @Override
            public void onFail(HttpError error) {

                if (error != null)
                    MessageUtils.showToast(error.getMessage());
                loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {

                    @Override
                    public void retry() {
                        fetchFinishData();
                    }
                });
            }
        });
    }

    private void initView(LiveVideoFinishDO finishDO) {

        hostAvatar.setImageURI(Uri.parse(finishDO.getHost().getUserAvatar()));
        hostName.setText(finishDO.getHost().getUserName());
        publishDate.setText(DateUtils.time2StringShort2(finishDO.getCreateTime()) + " 发布直播");
        liveTitle.setText(finishDO.getTitle());
        liveDescription.setText(finishDO.getDescription());
        rewardCount.setText(finishDO.getAmount() / 100 + "元");
        visitorCount.setText(String.valueOf(finishDO.getCount()));
        durationLiveVideo.setText(TimeUtils.secToTime((int) (finishDO.getDuration() / 1000)));
        allAmount.setText(finishDO.getAmount() / 100 + "元");
        netAmount.setText(finishDO.getNetAmount() / 100 + "元");

        rankListHead123.initRankData(finishDO.getRewards(), this);

        mRewards.clear();
        mRewards.addAll(finishDO.getRewards());
        mLiveRankListAdapter.notifyDataSetChanged();


    }

}
