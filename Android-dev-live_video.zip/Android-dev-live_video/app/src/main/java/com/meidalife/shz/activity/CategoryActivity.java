package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.CategoryCateFilterAdapter;
import com.meidalife.shz.adapter.HomeBlockAdapter;
import com.meidalife.shz.adapter.SearchRecyclerViewAdapter;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.adapter.TodayRecommendationAdapter;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.SearchParamsChanceEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.SearchFilterDo;
import com.meidalife.shz.rest.model.ServiceListOutDo;
import com.meidalife.shz.rest.model.TodayRecommendItem;
import com.meidalife.shz.rest.request.RequestService;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ConvertToUtils;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.umeng.socialize.media.UMImage;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 二级类目
 * Created by fufeng on 15/11/9.
 */
public class CategoryActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener {
    private String contentBannerBgUrl;
    private String categoryTitleString = "";
    private String categoryContentString;

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.bannerBackgroud)
    SimpleDraweeView bannerBackground;
    @Bind(R.id.titleBar)
    ViewGroup titleBar;
    //标题栏目
    @Bind(R.id.backButton)
    TextView backButton;
    @Bind(R.id.title)
    TextView title;
    @Bind(R.id.searchIcon)
    TextView searchIcon;
    @Bind(R.id.shareIcon)
    TextView shareIcon;

    //类目标题
    @Bind(R.id.categoryBannerLayout)
    ViewGroup categoryBannerLayout;
    @Bind(R.id.categoryTitle)
    TextView categoryTitle;
    @Bind(R.id.categorySubTitle)
    TextView categorySubTitle;
    @Bind(R.id.browseCount)
    TextView browseCount;
    @Bind(R.id.favCount)
    TextView favCount;

    //今日推荐
    @Bind(R.id.todayHotContainer)
    View todayHotContainer;
    @Bind(R.id.todayTitle)
    FontTextView todayTitle;
    @Bind(R.id.liveCastContainer)
    View liveCastContainer;
    @Bind(R.id.todayHotAvatar)
    SimpleDraweeView todayHotAvatar;
    @Bind(R.id.liveCastTitle)
    FontTextView liveCastTitle;
    @Bind(R.id.todayRecommendRecycler)
    RecyclerView todayRecommendRecycler;

    @Bind(R.id.promotionGridView)
    GridView promotionGridView;

    @Bind(R.id.niuRenRank)
    View niuRenRank;
    @Bind(R.id.niuRenRankTitle)
    FontTextView niuRenRankTitle;
    @Bind(R.id.niuRenAvatar)
    SimpleDraweeView niuRenAvatar;
    @Bind(R.id.niuRenName)
    FontTextView niuRenName;

    private SearchRecyclerViewAdapter filterRecyclerAdapter;
    TodayRecommendationAdapter todayRecommendationAdapter;

    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.filterRecyclerView)
    RecyclerView filterRecyclerView;
    @Bind(R.id.tagGridView)
    GridView tagGridView;
    @Bind(R.id.filterRecyclerViewCopy)
    RecyclerView filterRecyclerViewCopy;
    @Bind(R.id.tagGridViewCopy)
    GridView tagGridViewCopy;
    @Bind(R.id.floatContainer)
    View floatContainer;
    @Bind(R.id.floatContainerCopy)
    View floatContainerCopy;

    private boolean isListLoading;
    private boolean isListComplete;
    private int page = 0;
    private int catId = Integer.MAX_VALUE;
    private int tabId = Integer.MAX_VALUE;
    private int subCatId = Integer.MAX_VALUE;
    private boolean needPOI = false;
    private boolean isFirstFetch = true;

    private ArrayList<ServiceListOutDo> listData;
    private ServicesAdapter servicesAdapter;
    private ListView listView;
    private View listHeader;

    private static final int REFRESH_LIVE_CAST = 11;
    private static final int REFRESH_LIVE_TIME = 5;

    private int topBarDistance = -1;
    private int dividerHeight = -1;
    private int floatViewHeight = -1;
    private SocialSharePopupWindow socialSharePopupWindow;
    private ShareActivity shareActivity;
    private CategoryCateFilterAdapter cateFilterAdapter;
    private Timer refreshLiveTimer;
    private JSONArray liveInfo;
    private LoadUtil mLoadUtil;
    private int liveCastId;
    boolean mLocationSuccess = false;


    final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case REFRESH_LIVE_CAST:
                    int randomInt = new Random().nextInt(liveInfo.size());
                    JSONObject jo = liveInfo.getJSONObject(randomInt);
                    String avatarUrl = jo.getString("liveCastImg");
                    if (!TextUtils.isEmpty(avatarUrl)) {
                        todayHotAvatar.setImageURI(Uri.parse(avatarUrl));
                        todayHotAvatar.setVisibility(View.VISIBLE);
                    } else
                        todayHotAvatar.setVisibility(View.INVISIBLE);
                    liveCastTitle.setText(jo.getString("liveCastTitle"));
                    liveCastId = jo.getIntValue("liveCastId");
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        listView = (ListView) findViewById(R.id.listView);
        listHeader = getLayoutInflater().inflate(R.layout.category_list_view_header, null);
        listView.addHeaderView(listHeader);
        ButterKnife.bind(this);

        initComponent();
        loadHeaderData();

    }

    //接收搜过数据参数的改变
    public void onEventMainThread(SearchParamsChanceEvent event) {

        if (event.eventType == MsgTypeEnum.TYPE_SEARCH_TAB_PARAMS_CHANGE) {
            tabId = event.getTabId();
            needPOI = event.isNeedPOI();
            loadServiceList(false);
        } else if (event.eventType == MsgTypeEnum.TYPE_SEARCH_CATE_PARAMS_CHANGE) {
            subCatId = event.getSubCateId();
            needPOI = event.isNeedPOI();
            loadServiceList(false);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void reportPause() {
        LogParam param = new LogParam();
        param.setType(LogUtil.TYPE_EXIT_PAGE);
        param.setPid(this.getClass().getName());
        param.setCategoryId(String.valueOf(catId));
        LogUtil.log(param);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        refreshLiveTimer.cancel();
    }

    @Override
    public void reportResume() {
        LogParam param = new LogParam();
        param.setType(LogUtil.TYPE_START_PAGE);
        param.setPid(this.getClass().getName());
        param.setCategoryId(String.valueOf(catId));
        LogUtil.log(param);
    }


    private void initComponent() {
        try {
            catId = Integer.valueOf(getIntent().getStringExtra("catId"));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        mLoadUtil = new LoadUtil(getLayoutInflater());

        topBarDistance = ConvertToUtils.dip2px(CategoryActivity.this, 105);
        dividerHeight = ConvertToUtils.dip2px(CategoryActivity.this, 8);
        todayRecommendationAdapter = new TodayRecommendationAdapter(this);
        todayRecommendRecycler.setAdapter(todayRecommendationAdapter);

        refreshLiveTimer = new Timer();

        //设置布局管理器
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        todayRecommendRecycler.setLayoutManager(linearLayoutManager);

        //设置布局管理器
        LinearLayoutManager filterLayoutManager = new LinearLayoutManager(this);
        filterLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        filterRecyclerView.setLayoutManager(filterLayoutManager);

        LinearLayoutManager filterLayoutManager2 = new LinearLayoutManager(this);
        filterLayoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL);
        filterRecyclerViewCopy.setLayoutManager(filterLayoutManager2);

        cateFilterAdapter = new CategoryCateFilterAdapter(this, new ArrayList<SearchFilterDo.CateListItem.SubCateListDo>());
        tagGridView.setAdapter(cateFilterAdapter);
        tagGridViewCopy.setAdapter(cateFilterAdapter);


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        shareIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHideShareList(v);
            }
        });

        searchIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("search_res");
            }
        });
        swipeRefreshLayout.setOnRefreshListener(this);

        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1 && !isListComplete) {
                        loadServiceList(true);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                int a = listHeader.getTop();
                if (topBarDistance > 0 && (-a > topBarDistance)) {
                    title.setText(categoryTitleString);
                    title.setVisibility(View.VISIBLE);
                } else {
                    title.setVisibility(View.GONE);
                }

                if (servicesAdapter != null && !(servicesAdapter.getCount() > 0))
                    return;
                final View topChildView = listView.getChildAt(1);

                if (topChildView != null) {
                    int b = topChildView.getTop();
                    floatViewHeight = floatContainer.getMeasuredHeight();
                    if (listView.getFirstVisiblePosition() == 0) {
                        if (floatViewHeight > 0 && (b < floatViewHeight + dividerHeight)) {
                            floatContainerCopy.setVisibility(View.VISIBLE);
                            floatContainer.setVisibility(View.INVISIBLE);
                        } else {
                            floatContainerCopy.setVisibility(View.INVISIBLE);
                            floatContainer.setVisibility(View.VISIBLE);
                        }
                    } else {
                        floatContainerCopy.setVisibility(View.VISIBLE);
                        floatContainer.setVisibility(View.INVISIBLE);
                    }

                }
            }
        });

        listData = new ArrayList<>();
        servicesAdapter = new ServicesAdapter(this, listData);
        listView.setAdapter(servicesAdapter);
    }

    private void loadHeaderData() {
        mLoadUtil.loadPre(rootLayout, swipeRefreshLayout);
        JSONObject params = new JSONObject();
        params.put("catId", catId);
        //2.1/category/info

        HttpClient.get("2.1/category/info", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {

                setBanner(result);
                setTodayRecommendation(result);
                titleBar.setVisibility(View.VISIBLE);
                swipeRefreshLayout.setVisibility(View.VISIBLE);
                categoryBannerLayout.setVisibility(View.VISIBLE);
                loadServiceList(false);

            }

            @Override
            public void onFail(HttpError error) {
                titleBar.setVisibility(View.GONE);
                mLoadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        loadHeaderData();
                    }
                });
            }
        });
    }

    private void loadServiceList(boolean loadMore) {
        mLoadUtil.loadPre(rootLayout, swipeRefreshLayout);
        if (isListLoading)
            return;

        if (needPOI && !checkLocationSetting()) {
            return;
        }

        if (loadMore) {
            page++;
        } else {
            page = 0;
            isListComplete = false;
            listData.clear();
        }

        isListLoading = true;
        RequestService.queryServiceListByCate(getListParams(page), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                isListLoading = false;
                hideStatusLoading();
                List<ServiceListOutDo> resData = null;
                if (result.containsKey("result")) {
                    resData = JSON.parseArray(result.getString("result"), ServiceListOutDo.class);

                    listData.addAll(resData);
                    if (listData.size() == 0) {
                        ServiceListOutDo error = new ServiceListOutDo();
                        error.setDesc("没有数据");
                        error.setType(2);
                        listData.add(error);
                    }
                    servicesAdapter.notifyDataSetChanged();
                    if (resData.size() < 20) {
                        isListComplete = true;
                    }
                }

                if (isFirstFetch) {
                    SearchFilterDo searchFilterDo = JSON.parseObject(result.toString(), SearchFilterDo.class);
                    SearchFilterDo tabFilterDo = new SearchFilterDo();
                    //todo 需要和一杨确认
                    tabFilterDo.setCateList(searchFilterDo.getCateList());
                    tabFilterDo.setFilters(searchFilterDo.getFilters());
                    tabFilterDo.setTabs(searchFilterDo.getTabs());
                    initTabView(tabFilterDo);
                    if (CollectionUtil.isNotEmpty(searchFilterDo.getCateList())) {
                        initCateView(searchFilterDo.getCateList().get(0).getSubcateList());
                    }
                    isFirstFetch = false;
                }
                mLoadUtil.loadSuccess(swipeRefreshLayout);
            }

            @Override
            public void onFail(HttpError error) {
                isListLoading = false;
                if (page > 0)
                    page--;
                mLoadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        loadHeaderData();
                    }
                });
            }
        });
    }

    private JSONObject getListParams(int page) {
        JSONObject params;
        params = new JSONObject();

        LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();
        params.put("longitude", String.valueOf(location.getLongitude()));
        params.put("latitude", String.valueOf(location.getLatitude()));

        params.put("pageSize", 20);
        params.put("offset", page * 20);

        if (Integer.MAX_VALUE != catId) {
            params.put("catId", catId);
        }
        if (Integer.MAX_VALUE != tabId) {
            params.put("tabId", tabId);
        }
        if (Integer.MAX_VALUE != subCatId) {
            params.put("subCatId", subCatId);
        }

        return params;
    }

    private boolean checkLocationSetting() {
        String locateCode = SHZApplication.getInstance().getLocationManager().getLocation().getCityCode();
        String selectCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
        listData.clear();
        if (Helper.isLocationEnabled(this)) {
            if (!TextUtils.isEmpty(locateCode)) {
                if (!TextUtils.isEmpty(locateCode) || locateCode.equals(selectCode)) {
                    mLocationSuccess = true;
                } else {
                    ServiceListOutDo error = new ServiceListOutDo();
                    error.setDesc("选择城市和定位所在城市不一致，无法显示哦");
                    error.setType(1);
                    listData.add(error);
                    mLocationSuccess = false;
                }
            } else {
                ServiceListOutDo error = new ServiceListOutDo();
                error.setDesc("定位失败，请尝试重新定位");
                error.setType(1);
                listData.add(error);
                mLocationSuccess = false;
                //todo 开始重新定位
            }
        } else {
            ServiceListOutDo error = new ServiceListOutDo();
            error.setDesc("未开启定位，点击设置");
            error.setType(1);
//            error.setNeedSetLocation(true);
            listData.add(error);
            mLocationSuccess = false;
        }
        servicesAdapter.notifyDataSetChanged();

        return mLocationSuccess;
    }

    private void setBanner(JSONObject result) {
        contentBannerBgUrl = result.getString("bannerUrl");
        String cdnUrl = ImgUtil.getCDNUrlWithWidth(result.getString("bannerUrl"),
                getResources().getDimensionPixelSize(R.dimen.category_banner_height));

        categoryTitleString = result.getString("title");
        categoryContentString = result.getString("subTitle");
        bannerBackground.setImageURI(Uri.parse(cdnUrl));
        categoryTitle.setText(categoryTitleString);
        categorySubTitle.setText(categoryContentString);

        browseCount.setText(result.getString("browseCount"));
        favCount.setText(result.getString("favCount"));

        if (result.containsKey("liveInfo") && (liveInfo = result.getJSONArray("liveInfo")).size() > 0) {

            TimerTask refreshLiveTask = new TimerTask() {
                @Override
                public void run() {
                    Message message = handler.obtainMessage();
                    message.what = REFRESH_LIVE_CAST;
                    handler.sendMessage(message);
                }
            };
            refreshLiveTimer.schedule(refreshLiveTask, 0, REFRESH_LIVE_TIME * 1000);
            liveCastContainer.setVisibility(View.VISIBLE);
            liveCastContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(CategoryActivity.this, LiveActivity.class);
                    if (!(liveCastId > 0))
                        return;
                    intent.putExtra("liveId", liveCastId);
                    startActivity(intent);
                }
            });

        } else
            liveCastContainer.setVisibility(View.GONE);

        if (result.containsKey("category4BlockAdList")) {
            final JSONArray blockAd4 = result.getJSONArray("category4BlockAdList");
            if (blockAd4.size() < 4)
                promotionGridView.setVisibility(View.GONE);
            else {
                HomeBlockAdapter homeBlockAdapter = new HomeBlockAdapter(this, blockAd4);
                promotionGridView.setAdapter(homeBlockAdapter);
                promotionGridView.setVisibility(View.VISIBLE);
            }

        } else {
            promotionGridView.setVisibility(View.GONE);
        }


        if (result.containsKey("niuRenRankTitle") && !TextUtils.isEmpty("niuRenRankTitle")) {
            niuRenRank.setVisibility(View.VISIBLE);
            niuRenRankTitle.setText(result.getString("niuRenRankTitle"));
            if (result.containsKey("niuRenAvatar") && !TextUtils.isEmpty(result.getString("niuRenAvatar")))
                niuRenAvatar.setImageURI(Uri.parse(result.getString("niuRenAvatar")));
            if (result.containsKey("niuRenName") && !TextUtils.isEmpty(result.getString("niuRenName")))
                niuRenName.setText(result.getString("niuRenName"));

            niuRenRank.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    // TODO: 16/5/5 牛人榜H5 URL
                    bundle.putString("url", "www.kongge.com");
                    Router.sharedRouter().open("web", bundle);
                }
            });
        } else
            niuRenRank.setVisibility(View.GONE);

    }

    private void setTodayRecommendation(JSONObject result) {
        List<TodayRecommendItem> recommendItemList = new ArrayList<>();
        if (result.containsKey("choiceTitle"))
            todayTitle.setText(result.getString("choiceTitle"));
        JSONArray todayRecommendationArray = result.getJSONArray("today");
        if (todayRecommendationArray == null || todayRecommendationArray.isEmpty()) {
            todayHotContainer.setVisibility(View.GONE);
            return;
        } else
            todayHotContainer.setVisibility(View.VISIBLE);

        for (int i = 0; i < todayRecommendationArray.size(); i++) {
            JSONObject today = (JSONObject) todayRecommendationArray.get(i);
            TodayRecommendItem item = new TodayRecommendItem();
            item.setIconUrl(today.getString("image"));
            item.setLink(today.getString("url"));
            item.setPvid(today.getString("pvid"));
            recommendItemList.add(item);
        }

        if (!recommendItemList.isEmpty()) {
            todayRecommendationAdapter.setData(recommendItemList);
            todayRecommendationAdapter.notifyDataSetChanged();
            todayRecommendRecycler.setVisibility(View.VISIBLE);
        } else {
            todayRecommendRecycler.setVisibility(View.GONE);
        }
    }

    private void initTabView(SearchFilterDo data) {
        filterRecyclerAdapter = new SearchRecyclerViewAdapter(this);
        filterRecyclerAdapter.setSearchFilterDO(data);
        filterRecyclerView.setAdapter(filterRecyclerAdapter);
        filterRecyclerViewCopy.setAdapter(filterRecyclerAdapter);
        filterRecyclerAdapter.notifyDataSetChanged();
        filterRecyclerView.setVisibility(View.VISIBLE);
        filterRecyclerViewCopy.setVisibility(View.VISIBLE);
    }

    private void initCateView(List<SearchFilterDo.CateListItem.SubCateListDo> subCateListDos) {
        if (CollectionUtil.isEmpty(subCateListDos)) {
            tagGridView.setVisibility(View.GONE);
            tagGridViewCopy.setVisibility(View.GONE);
            return;
        }
        tagGridView.setVisibility(View.VISIBLE);
        tagGridViewCopy.setVisibility(View.VISIBLE);
        cateFilterAdapter.setTabList(subCateListDos);

        AdapterView.OnItemClickListener listener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == cateFilterAdapter.getSelectPos()) {
                    if (position == 0)
                        return;
                    cateFilterAdapter.setSelectPos(0);
                } else
                    cateFilterAdapter.setSelectPos(position);
                cateFilterAdapter.notifyDataSetChanged();
                EventBus.getDefault().post(new SearchParamsChanceEvent(Integer.MAX_VALUE, cateFilterAdapter.getSubCatId(), false));
            }
        };

        tagGridView.setOnItemClickListener(listener);
        tagGridViewCopy.setOnItemClickListener(listener);
        cateFilterAdapter.notifyDataSetChanged();
    }

    @Override
    public void onRefresh() {
        swipeRefreshLayout.setRefreshing(false);
        EventBus.getDefault().post(new SearchParamsChanceEvent(Integer.MAX_VALUE, cateFilterAdapter.getSubCatId(), false));
    }

    private void showOrHideShareList(View v) {
        if (socialSharePopupWindow == null) {
            if (shareActivity == null) {
                shareActivity = new ShareActivity(this);
            }
            socialSharePopupWindow = new SocialSharePopupWindow(this, shareActivity, 0);
            socialSharePopupWindow.setShareUrl(Constant.URL_CATEGORY + catId);
            socialSharePopupWindow.setShareTitle(categoryTitleString);
            socialSharePopupWindow.setShareDescription(categoryContentString);
            socialSharePopupWindow.setShareImage(new UMImage(this, contentBannerBgUrl));
        }
        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

}
