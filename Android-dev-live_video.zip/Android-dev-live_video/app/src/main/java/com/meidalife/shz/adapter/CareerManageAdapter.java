package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CareerExpDo;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/4/26.
 */
public class CareerManageAdapter extends RecyclerView.Adapter<CareerManageAdapter.CareerViewHolder> {
    private List<CareerExpDo> careerExpDoList = new ArrayList<>();
    private LayoutInflater mInflater;
    SetMainCareerListener setMainCareerListener;

    public interface SetMainCareerListener {
        void onSet(String careerId);
    }

    public CareerManageAdapter(Context context, List<CareerExpDo> careerExpDoList) {
        mInflater = LayoutInflater.from(context);
        setCareerExpDoList(careerExpDoList);
    }

    public void setCareerExpDoList(List<CareerExpDo> careerExpDoList) {
        this.careerExpDoList = careerExpDoList;
    }

    public void setSetMainCareerListener(SetMainCareerListener setMainCareerListener) {
        this.setMainCareerListener = setMainCareerListener;
    }

    @Override
    public CareerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CareerViewHolder(mInflater.inflate(R.layout.item_career_manage, parent, false));
    }

    @Override
    public void onBindViewHolder(CareerViewHolder holder, int position) {
        final CareerExpDo careerExpDo = careerExpDoList.get(position);
        holder.careerTitle.setText(careerExpDo.getCareerName());
        if (!TextUtils.isEmpty(careerExpDo.getCareerPic())) {
            holder.careerIcon.setImageURI(Uri.parse(careerExpDo.getCareerPic()));
        }
        if (!TextUtils.isEmpty(careerExpDo.getPic())) {
            holder.careerLevelPic.setImageURI(Uri.parse(careerExpDo.getPic()));
        }
        holder.careerLevelTitle.setText(careerExpDo.getTitle());
        holder.careerLevelProgress.setProgress(careerExpDo.getExp());
        holder.careerLevelProgress.setMax(careerExpDo.getLevelTotalExp());
        holder.skillExpValue.setText(String.valueOf(careerExpDo.getExp()));

        if (!TextUtils.isEmpty(careerExpDo.getNextPic())) {
            holder.careerNextLevelPic.setImageURI(Uri.parse(careerExpDo.getNextPic()));
        }
        holder.careerNextLevelTitle.setText(careerExpDo.getNextTitle());
        holder.promotionGap.setText(String.format("还差%s经验值", careerExpDo.getGap()));

        holder.levelDesc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", careerExpDo.getActionUrl());
                Router.sharedRouter().open("web", bundle);
            }
        });

        holder.skillExpContainer.removeAllViews();
        for (CareerExpDo.SkillExpDo skillExpDo : careerExpDo.getChildSkills()) {
            View view = inflateSkillExpItem(skillExpDo);
            holder.skillExpContainer.addView(view);
        }

        holder.setAsDefaultCareer.setSelected(careerExpDo.isDefaultCareer());

        if (careerExpDo.isDefaultCareer()) {
            holder.setAsDefaultCareer.setText("已设为展示职业");
        } else {
            holder.setAsDefaultCareer.setText("设为展示职业");
        }
        holder.setAsDefaultCareer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (setMainCareerListener != null && !careerExpDo.isDefaultCareer()) {
                    setMainCareerListener.onSet(careerExpDo.getId());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return careerExpDoList.size();
    }

    private View inflateSkillExpItem(CareerExpDo.SkillExpDo skillExpDo) {
        View view = mInflater.inflate(R.layout.item_skill_exp, null);
        TextView skillName = (TextView) view.findViewById(R.id.skillName);
        TextView skillScore = (TextView) view.findViewById(R.id.skillScore);
        skillName.setText(skillExpDo.getSkillName());
        skillScore.setText(String.valueOf(skillExpDo.getScore()));
        return view;
    }

    class CareerViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.careerTitle)
        TextView careerTitle;
        @Bind(R.id.careerIcon)
        SimpleDraweeView careerIcon;
        @Bind(R.id.careerLevelPic)
        SimpleDraweeView careerLevelPic;
        @Bind(R.id.careerLevelTitle)
        TextView careerLevelTitle;
        @Bind(R.id.careerLevelProgress)
        ProgressBar careerLevelProgress;
        @Bind(R.id.skillExpValue)
        TextView skillExpValue;
        @Bind(R.id.careerNextLevelPic)
        SimpleDraweeView careerNextLevelPic;
        @Bind(R.id.careerNextLevelTitle)
        TextView careerNextLevelTitle;
        @Bind(R.id.promotionGap)
        TextView promotionGap;
        @Bind(R.id.skillExpContainer)
        ViewGroup skillExpContainer;
        @Bind(R.id.levelDesc)
        TextView levelDesc;
        @Bind(R.id.setAsDefaultCareer)
        TextView setAsDefaultCareer;

        public CareerViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
