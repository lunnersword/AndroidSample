package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.ViewGroup;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.MDMyLotteryListFragment;
import com.meidalife.shz.adapter.FragmentTabAdapter;
import com.meidalife.shz.util.CountDownTimerUtils;
import com.meidalife.shz.widget.SlidingTabLayout;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 我的夺宝
 * Created by liujian on 16/1/20.
 */
public class MDMyLotteryActivity extends BaseActivity{

    private final static String LOTTERY_ALL = "all";
    private final static String LOTTERY_WINNING = "winning";
    private final static String LOTTERY_NOTWINNING = "notwinning";

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.lotterySlidingTab)
    SlidingTabLayout lotterySlidingTab;
    @Bind(R.id.lotteryTabViewPager)
    ViewPager lotteryTabViewPager;

    FragmentTabAdapter lotteryPagerAdapter;
    private int type = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_md_my_lottery);
        ButterKnife.bind(this);

        initActionBar(R.string.text_md_my_lottery, true);

        if (!Helper.sharedHelper().hasToken()) {
            Bundle bundle = new Bundle();
            bundle.putString("action", "doDuoBao");
            Router.sharedRouter().open("signin", bundle);
            finish();
        }

        String typeStr = getIntent().getStringExtra("type");
        if(typeStr != null){
            if(LOTTERY_ALL.equals(typeStr)){
                type = 0;
            }else if(LOTTERY_WINNING.equals(typeStr)){
                type = 1;
            }else if(LOTTERY_NOTWINNING.equals(typeStr)){
                type = 2;
            }
        }
        lotteryPagerAdapter = new FragmentTabAdapter(getSupportFragmentManager());
        initTab();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        CountDownTimerUtils.newInstance().clearAllTimer();
    }

    private void initTab(){
        String[] myLotteryTypes = getResources().getStringArray(R.array.myLotteryType);
        for(int i=0;i<myLotteryTypes.length;i++){
            Bundle bundle =new Bundle();
            bundle.putString("title", myLotteryTypes[i]);
            bundle.putInt("type", i + 1);
            MDMyLotteryListFragment mdMyLotteryListFragment = MDMyLotteryListFragment.newInstance(bundle);
            lotteryPagerAdapter.addFragment(mdMyLotteryListFragment);
        }
        lotteryPagerAdapter.notifyDataSetChanged();
        lotteryTabViewPager.setAdapter(lotteryPagerAdapter);
        lotterySlidingTab.setCustomTabView(R.layout.item_my_lottery_tab, R.id.lotteryTabName);
        lotterySlidingTab.setSelectedIndicatorColors(getResources().getColor(R.color.brand_b));
        lotterySlidingTab.setSelectedTabTitleColorId(R.color.brand_b);
        lotterySlidingTab.setTabTitleColorId(R.color.black);
        lotterySlidingTab.setViewPager(lotteryTabViewPager);
        lotterySlidingTab.setDividerColors(android.R.color.transparent);
        lotterySlidingTab.setCalculateWidthByTitle(false);
        lotteryTabViewPager.setCurrentItem(type);
    }
}
