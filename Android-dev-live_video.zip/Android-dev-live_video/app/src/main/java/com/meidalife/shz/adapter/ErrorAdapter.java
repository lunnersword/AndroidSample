package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ErrorDO;

import java.util.ArrayList;

/**
 * Created by taber on 15/6/1.
 */
public class ErrorAdapter extends BaseAdapter {
    private static final String LOG_TAG = "LocationErrorAdapter";
    private static final int TYPE_COUNT = 2;

    LayoutInflater mInflater;
    Context mContext;
    ArrayList<ErrorDO> mData;

    public ErrorAdapter(Context context, ArrayList<ErrorDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    public void addAll(ArrayList<ErrorDO> items) {
        mData.addAll(items);
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public ErrorDO getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        ErrorDO error = mData.get(position);
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.location_error_view, parent, false);
            holder = new ViewHolder();
            holder.errorTip = (TextView) convertView.findViewById(R.id.nearbyHintLabel);
            holder.locationTip = convertView.findViewById(R.id.locationTip);
            holder.no_data_icon = convertView.findViewById(R.id.no_data_icon);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.errorTip.setText(error.getDesc());

        if (error.getType() == 1) {
            holder.locationTip.setVisibility(View.VISIBLE);
        } else {
            holder.locationTip.setVisibility(View.GONE);
        }

        if (error.getType() == 2) {
            holder.no_data_icon.setVisibility(View.VISIBLE);
        } else {
            holder.no_data_icon.setVisibility(View.GONE);
        }

        return convertView;
    }

    static class ViewHolder {
        TextView errorTip;
        View locationTip;
        View no_data_icon;
    }

}
