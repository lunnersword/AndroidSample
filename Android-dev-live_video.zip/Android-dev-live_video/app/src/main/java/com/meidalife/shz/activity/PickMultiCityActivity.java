package com.meidalife.shz.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.andraskindler.quickscroll.QuickScroll;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.ExpandableCityListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CityItem;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.FontTextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/3/14.
 */
public class PickMultiCityActivity extends BaseActivity implements ExpandableCityListAdapter.OnCitySelectListener {
    private static final String LOG_TAG = "PickMultiCityActivity";
    private List<CityItem> cityItemList = new ArrayList<>();
    private List<String> alphaIndex = new ArrayList<>();
    private Map<String, CityItem> cityItemMap = new HashMap<>();
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.cityList)
    ExpandableListView cityListView;
    @Bind(R.id.quickscroll)
    QuickScroll quickScroll;
    @Bind(R.id.alphaIndexTrack)
    LinearLayout alphaIndexTrack;
    @Bind(R.id.contentLayout)
    ViewGroup contentLayout;

    private ExpandableCityListAdapter expandableCityListAdapter;
    private ArrayList<CityItem> selectedCityList;
    private CityItem locationCity;
    private LoadUtil mLoadUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_multi_city);
        ButterKnife.bind(this);
        initActionBar("添加城市", true, true);
        mButtonRight.setText("确认");
        mButtonRight.setTextColor(getResources().getColor(R.color.brand));
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<CityItem> selectedCityList = new ArrayList<>();

                Set<String> selectCityCodes = new HashSet<>();
                for (CityItem item : cityItemList) {
                    selectCityCodes.addAll(item.getSelectedCodes());
                }
                for (String code : selectCityCodes) {
                    if (!selectCityCodes.contains(cityItemMap.get(code).getParentId())) {
                        CityItem item = cityItemMap.get(code);
                        item.setState(CityItem.STATE_ALL_SELECT);
                        selectedCityList.add(item);
                    }
                }

                if (selectedCityList.isEmpty()) {
                    MessageUtils.showToast("请至少选择一个城市");
                    return;
                }
                Intent intent = new Intent();
                intent.putParcelableArrayListExtra(Constant.EXTRA_TAG_CITY_LIST, selectedCityList);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        mLoadUtils = new LoadUtil(LayoutInflater.from(this));
        selectedCityList = getIntent().getParcelableArrayListExtra(Constant.EXTRA_TAG_CITY_LIST);
        getCityList();
    }

    private void getCityList() {
        JSONObject poiParams = new JSONObject();
        mLoadUtils.loadPre(rootView, contentLayout);
        LocationDO mLocation = SHZApplication.getInstance().getLocationManager().getLocation();
        if (mLocation != null) {
            poiParams.put("poiLongitude", "" + mLocation.getLongitude());
            poiParams.put("poiLatitude", "" + mLocation.getLatitude());

            if (!TextUtils.isEmpty(mLocation.getCityCode())) {
                poiParams.put("gdCityCode", mLocation.getCityCode());
            }
            if (!TextUtils.isEmpty(mLocation.getCityName())) {
                poiParams.put("gdCityName", mLocation.getCityName());
            }
        }

        HttpClient.get("1.0/city/getCityList", poiParams, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                mLoadUtils.loadSuccess(contentLayout);
                try {
                    if (obj.containsKey("city")) {
                        locationCity = JSON.parseObject(obj.getJSONObject("city").toJSONString(),
                                CityItem.class);
                    }
                    if (obj.containsKey("cityMap")) {
                        cityItemMap = JSON.parseObject(obj.getJSONObject("cityMap").toJSONString(),
                                new TypeReference<Map<String, CityItem>>() {
                                });
                        serializeCityList();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFail(HttpError error) {
                mLoadUtils.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        getCityList();
                    }
                });
            }
        });
    }

    private void serializeCityList() {
        long t1 = System.currentTimeMillis();
        Set<String> selectCityCodes = new HashSet<>();
        if (null != selectedCityList && !selectedCityList.isEmpty()) {
            for (CityItem item : selectedCityList) {
                item.selectAll();
                selectCityCodes.addAll(item.getSelectedCodes());
            }
            mButtonRight.setEnabled(true);
            mButtonRight.setTextColor(getResources().getColor(R.color.brand));
        }
        Iterator<Map.Entry<String, CityItem>> iterator = cityItemMap.entrySet().iterator();
        //设置定位城市
        while (iterator.hasNext()) {
            Map.Entry<String, CityItem> entry = iterator.next();
            CityItem item = entry.getValue();
            if(null != locationCity&& locationCity.getCode().equals(item.getCode())){
                locationCity = item;
                locationCity.setIsLocationCity(true);
                break;
            }
        }
        iterator = cityItemMap.entrySet().iterator();
        //加入全国&海外
        while (iterator.hasNext()) {
            Map.Entry<String, CityItem> entry = iterator.next();
            CityItem item = entry.getValue();
            if (item.getType() == CityItem.TYPE_COUNTRY) {
                if (selectCityCodes.contains(item.getCode()) || selectCityCodes.contains(item.getParentId())) {
                    item.setState(CityItem.STATE_ALL_SELECT);
                }
                cityItemList.add(item);
            }
            if (!TextUtils.isEmpty(entry.getValue().getCapital())
                    && !alphaIndex.contains(entry.getValue().getCapital())
                    && entry.getValue().getType() == CityItem.TYPE_PROVINCE) {
                alphaIndex.add(entry.getValue().getCapital());
            }
        }
        iterator = cityItemMap.entrySet().iterator();
        //加入省份&直辖市
        while (iterator.hasNext()) {
            Map.Entry<String, CityItem> entry = iterator.next();
            for (int i = 0; i < cityItemList.size(); i++) {
                CityItem item = cityItemList.get(i);
                //将省份直辖市加入到全国下面
                if (item.getType() == CityItem.TYPE_COUNTRY && "0".equals(item.getCode())
                        && entry.getValue().getType() == 1) {
                    if (selectCityCodes.contains(entry.getValue().getCode())
                            || selectCityCodes.contains(entry.getValue().getParentId())) {
                        entry.getValue().setState(CityItem.STATE_ALL_SELECT);
                    }
                    item.subCityList.add(entry.getValue());
                }
            }
        }
        iterator = cityItemMap.entrySet().iterator();
        //加入城市
        while (iterator.hasNext()) {
            Map.Entry<String, CityItem> entry = iterator.next();
            for (int i = 0; i < cityItemList.size(); i++) {
                for (int j = 0; j < cityItemList.get(i).subCityList.size(); j++) {
                    CityItem cityItem = cityItemList.get(i).subCityList.get(j);
                    //将城市加入对应省份
                    if (!TextUtils.isEmpty(entry.getValue().getParentId()) &&
                            entry.getValue().getParentId().equals(cityItem.getCode())) {
                        if (selectCityCodes.contains(entry.getValue().getCode()) ||
                                selectCityCodes.contains(entry.getValue().getParentId())) {
                            entry.getValue().setState(CityItem.STATE_ALL_SELECT);
                        }
                        cityItem.subCityList.add(entry.getValue());
                    }
                }
            }
        }
        Collections.sort(cityItemList, new Comparator<CityItem>() {
            @Override
            public int compare(CityItem lhs, CityItem rhs) {
                return lhs.getCode().compareTo(rhs.getCode());
            }
        });

        Collections.sort(alphaIndex, new Comparator<String>() {
            @Override
            public int compare(String lhs, String rhs) {
                return lhs.compareTo(rhs);
            }
        });

        for (int i = 0; i < cityItemList.size(); i++) {
            CityItem item = cityItemList.get(i);
            Collections.sort(item.subCityList, new Comparator<CityItem>() {
                @Override
                public int compare(CityItem lhs, CityItem rhs) {
                    return lhs.getCapital().compareTo(rhs.getCapital());
                }
            });
        }

        if (locationCity != null) {
            cityItemList.add(0, locationCity);
            if (selectCityCodes.contains(locationCity.getCode())) {
                locationCity.setState(CityItem.STATE_ALL_SELECT);
            }
        }

        cityListView.setGroupIndicator(null);
        expandableCityListAdapter = new ExpandableCityListAdapter(this, cityItemList);
        expandableCityListAdapter.setAlphaIndex(alphaIndex);
        expandableCityListAdapter.setOnCitySelectListener(this);
        cityListView.setAdapter(expandableCityListAdapter);

        cityListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                if (expandableCityListAdapter.getChildrenCount(groupPosition) > 0) {
                    quickScroll.setVisibility(View.VISIBLE);
                    alphaIndexTrack.setVisibility(View.VISIBLE);
                }
            }
        });

        cityListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int groupPosition) {
                if (expandableCityListAdapter.getChildrenCount(groupPosition) > 0) {
                    quickScroll.setVisibility(View.GONE);
                    alphaIndexTrack.setVisibility(View.GONE);
                }
            }
        });

        quickScroll.init(QuickScroll.TYPE_POPUP, cityListView, expandableCityListAdapter, QuickScroll.STYLE_NONE);
        quickScroll.setFixedSize(2);
        quickScroll.setPopupColor(QuickScroll.BLUE_LIGHT, QuickScroll.BLUE_LIGHT_SEMITRANSPARENT, 1, Color.WHITE, 1);
        quickScroll.setVisibility(View.GONE);
        alphaIndexTrack.setVisibility(View.GONE);
        Log.d(LOG_TAG, "Serialize city list cost time:" + (System.currentTimeMillis() - t1));
        createAlphaTrack();
    }

    private void createAlphaTrack() {
        final LinearLayout.LayoutParams textparams = new LinearLayout.
                LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f);
        for (int i = 0; i < alphaIndex.size(); i++) {
            final FontTextView textview = new FontTextView(this);
            textview.setLayoutParams(textparams);
            textview.setGravity(Gravity.CENTER_HORIZONTAL);
            textview.setText(alphaIndex.get(i));
            alphaIndexTrack.addView(textview);
        }
    }

    @Override
    public void onSelect(String code) {
//        selectCityCodes.add(code);
//        mButtonRight.setTextColor(getResources().getColor(R.color.brand));
//        mButtonRight.setEnabled(true);
    }

    @Override
    public void onUnSelect(String code) {
//        selectCityCodes.remove(code);
//        if (selectCityCodes.isEmpty()) {
//            mButtonRight.setTextColor(getResources().getColor(R.color.grey_t));
//            mButtonRight.setEnabled(false);
//        }
    }
}
