package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.adapter.ServiceGridAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.CommentAndOrderDO;
import com.meidalife.shz.rest.model.CommentByServerDO;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.FlowLayout;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 评价 (服务评价,技能评价)
 * Created by liujian on 16/4/22.
 */
public class CommentActivity extends BaseActivity {
    public final static int COMMENT_ADD_TYPE = 0;  //新增评论
    public final static int COMMENT_UPDATE_TYPE = 1;  //修改评论
    private final static int TEXT_LENGTH_LIMIT = 300;

    @Bind(R.id.userAvatar)
    SimpleDraweeView userAvatar;
    @Bind(R.id.iconGender)
    TextView iconGender;
    @Bind(R.id.userNick)
    TextView userNick;
    @Bind(R.id.jobName)
    TextView jobName;
    @Bind(R.id.jobIcon)
    SimpleDraweeView jobIcon;
    @Bind(R.id.jobTitle)
    TextView jobTitle;
    @Bind(R.id.title)
    TextView title;
    @Bind(R.id.commentSupply)
    View commentSupply;
    @Bind(R.id.levelText)
    TextView levelText;
    @Bind(R.id.tagLayout)
    FlowLayout tagLayout;
    @Bind(R.id.tagGuideLayout)
    View tagGuideLayout;
    @Bind(R.id.selectImages)
    GridView selectImagesGrid;
    @Bind(R.id.textComment)
    EditText textComment;
    @Bind(R.id.textCommentLimit)
    TextView textCommentLimit;
    @Bind(R.id.anonymousLayout)
    LinearLayout anonymousLayout;
    @Bind(R.id.selectIcon)
    TextView selectIcon;
    @Bind(R.id.anonymousText)
    TextView anonymousText;
    @Bind(R.id.publishBtn)
    Button publishBtn;
    @Bind(R.id.publishLayout)
    View publishLayout;
    @Bind(R.id.commentContent)
    View commentContent;
    @Bind(R.id.rootView)
    ViewGroup rootView;

    private String orderNo;
    private List<TextView> starList = new ArrayList<>();
    private int canPickPicCount;
    private ServiceGridAdapter adapter;
    private List<String> images;
    private int currentPosition = 0;
    private boolean isPublishing;
    private Map<String, String> uploadedImages = new HashMap<>();
    private boolean isUploading = false;
    private int anonymous = 1;
    private LoadUtil loadUtil;
    private int score = 0;
    private int type; //1代表服务评价 5代表技能评价
    private int canModify;  // 1 修改评价
    private String itemId;
    private String commentId;
    private List<CommentByServerDO.Tag> selectTags = new ArrayList<CommentByServerDO.Tag>();
    private List<CommentByServerDO.Tag> allTags = new ArrayList<CommentByServerDO.Tag>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_comment);
        ButterKnife.bind(this);
        initActionBar(R.string.title_activity_comment, true);
        orderNo = getIntent().getStringExtra("orderNo");
        if(getIntent().getStringExtra("canModify") != null)
            canModify = Integer.parseInt(getIntent().getStringExtra("canModify"));
        loadUtil = new LoadUtil(LayoutInflater.from(this));
        images = new ArrayList<String>();
        hideIMM();
        setStarFont();
        initSelectImagesGrid();
        initListener();
        if(canModify == COMMENT_ADD_TYPE){
            commentSupply.setVisibility(View.GONE);
        }
        initData();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (Activity.RESULT_OK == resultCode && requestCode == Constant.REQUEST_CODE_PICK_PHOTO) {
            Bundle bundle = data.getExtras();
            ArrayList<String> paths = bundle.getStringArrayList("images");
            if (paths != null && paths.size() > 0) {
                for (int i = 0; i < paths.size(); i++) {
                    if (currentPosition < images.size() &&
                            TextUtils.isEmpty(images.get(currentPosition))) {
                        images.set(currentPosition++, paths.get(i));
                        canPickPicCount--;
                    } else {
                        if (images.size() < Constant.MAX_IMAGE_LENGTH) {
                            images.add(paths.get(i));
                            canPickPicCount--;
                        }
                    }
                }
            }
            uploadImages();
            adapter.notifyDataSetChanged();
        }
    }

    private void initListener() {
        textComment.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textCommentLimit.setText("" + s.toString().length());
                if (s.toString().trim().length() > TEXT_LENGTH_LIMIT) {
                    textCommentLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textCommentLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        anonymousLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (anonymous == 1) {
                    selectIcon.setText(R.string.icon_checkbox_active);
                    selectIcon.setTextColor(CommentActivity.this.getResources().getColor(R.color.square_round_corner));
                    anonymousText.setTextColor(CommentActivity.this.getResources().getColor(R.color.square_round_corner));
                    anonymous = 0;
                } else {
                    selectIcon.setText(R.string.icon_checkbox_normal);
                    selectIcon.setTextColor(CommentActivity.this.getResources().getColor(R.color.grey_j));
                    anonymousText.setTextColor(CommentActivity.this.getResources().getColor(R.color.grey_j));
                    anonymous = 1;
                }
            }
        });
        publishBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (canModify == COMMENT_UPDATE_TYPE) {
                    updateComment();
                } else
                    publishComment();
            }
        });
    }

    private void initData() {
        JSONObject params = new JSONObject();
        params.put("orderNo", orderNo);
        loadUtil.loadPre(rootView, commentContent);
        publishLayout.setVisibility(View.GONE);
        HttpClient.get("1.1/comment/getCommentAndOrderInfo", params, CommentAndOrderDO.class, new HttpClient.HttpCallback<CommentAndOrderDO>() {
            @Override
            public void onSuccess(CommentAndOrderDO obj) {
                loadUtil.loadSuccess(commentContent);
                publishLayout.setVisibility(View.VISIBLE);
                title.setText(obj.getTitle());
                if (obj.getSeller() != null)
                    handlerSellerInfo(obj.getSeller());
                allTags = obj.getTags();
                //  handlerTags(obj.getTags());
                type = obj.getCommentType();
                if (obj.getSkillId() == null) {
                    itemId = obj.getItemId();
                } else
                    itemId = obj.getSkillId();
                if (obj.getComments() != null && canModify == COMMENT_UPDATE_TYPE)
                    handlerCommentData(obj.getComments());

            }

            @Override
            public void onFail(HttpError error) {
                loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initData();
                    }
                });
            }
        });
    }

    private void handlerCommentData(CommentByServerDO commentByServerDO){
        if (commentByServerDO.getImages() != null &&commentByServerDO.getImages().size() != 0) {
            for (String image : commentByServerDO.getImages()) {
                uploadedImages.put(image, image);
                images.add(image);
            }
            canPickPicCount = Constant.MAX_IMAGE_LENGTH - images.size();
            adapter.notifyDataSetChanged();
        }
        commentId = commentByServerDO.getCommentId();
        Integer size = commentByServerDO.getLevel();
        selectTags = commentByServerDO.getTags();
        updateScore(size);
        handlerTags(filterTagByScore(size));
        if (commentByServerDO.getComment() != null)
            textComment.setText(commentByServerDO.getComment());
    }



    private void updateScore(int size) {
        for (int i = 0; i < starList.size(); i++) {
            TextView star = starList.get(i);
            if (i < size) {
                star.setTextColor(getResources().getColor(R.color.brand_b));
            } else {
                star.setTextColor(getResources().getColor(R.color.grey_c));
            }
        }
        score = size;
        String[] scoreDesc = getResources().getStringArray(R.array.judgeScoreDescription);
        if (score > 0 && score <= scoreDesc.length) {
            levelText.setText(scoreDesc[score - 1]);
            levelText.setVisibility(View.VISIBLE);
        }
    }

    private void handlerSellerInfo(CommentAndOrderDO.Seller seller) {
        if (seller.getAvatar() != null)
            userAvatar.setImageURI(Uri.parse(seller.getAvatar()));
        userNick.setText(seller.getUserNick());
        // 设置性别
        if (seller.getUserGender() != null) {
            iconGender.setVisibility(View.VISIBLE);
            if (seller.getUserGender().equals("woman") || seller.getUserGender().equals("F")) {
                iconGender.setText(getResources().getString(R.string.icon_gender_f));
            } else {
                iconGender.setText(getResources().getString(R.string.icon_gender_m));
            }
        } else
            iconGender.setVisibility(View.GONE);
        if (seller.getJobs() != null && seller.getJobs().size() != 0) {
            jobName.setVisibility(View.VISIBLE);
            jobIcon.setVisibility(View.VISIBLE);
            jobName.setText(seller.getJobs().get(0).getTitle());
            if (seller.getJobs().get(0).getIconUrl() != null)
                jobIcon.setImageURI(Uri.parse(seller.getJobs().get(0).getIconUrl()));
        } else {
            jobName.setVisibility(View.GONE);
            jobIcon.setVisibility(View.GONE);
        }
        if (seller.getJobTitle() != null) {
            jobTitle.setVisibility(View.VISIBLE);
            jobTitle.setText(seller.getJobTitle());
        } else
            jobTitle.setVisibility(View.GONE);
    }

    //发表评论
    private void publishComment() {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();

        showProgressDialog("正在发表");
        isPublishing = true;
        if (!isUploadCompleted()) {
            uploadImages();
            return;
        }
        params.put("itemId", itemId);
        params.put("orderNumber", orderNo);
        params.put("clientType", 2);
        if(!TextUtils.isEmpty(textComment.getText()))
            params.put("comment", textComment.getText());
        params.put("level", score);
        params.put("type", type);
        params.put("images", uploadedImagesToJson());
        params.put("anonymous",anonymous);
        String tags = selectTagsToString();
        if(tags.length() > 0)
            params.put("tags", tags.substring(0,tags.length()-1));
        HttpClient.get("1.1/comment/addComment", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideProgressDialog();
                //跳转到分享页面
                Bundle params = new Bundle();
                params.putBoolean("isComment",true);
                params.putString("orderNo",orderNo);
                Router.sharedRouter().open("publishServiceFinish",params);
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "发表失败，请重试");
            }
        });
    }

    private JSONArray uploadedImagesToJson(){
        JSONArray imageArray = new JSONArray();
        for (String key : uploadedImages.keySet()) {
            imageArray.add(uploadedImages.get(key));
        }
        return imageArray;
    }

    private String selectTagsToString(){
        StringBuffer sb = new StringBuffer();
        for(CommentByServerDO.Tag tag : selectTags){
            sb.append(tag.getId()+",");
        }
        return sb.toString();
    }

    /**
     * 提交评论修改
     *
     * @param
     */
    private void updateComment() {
        showProgressDialog("正在发表");
        isPublishing = true;
        if (!isUploadCompleted()) {
            uploadImages();
            return;
        }
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("commentId", commentId);
        if(!TextUtils.isEmpty(textComment.getText()))
            params.put("comment", textComment.getText());
        params.put("images", uploadedImagesToJson());
        params.put("anonymous",anonymous);
        String tags = selectTagsToString();
        if(tags.length() > 0)
            params.put("tags", tags.substring(0,tags.length()-1));
        params.put("level", score);
        HttpClient.get("1.1/comment/updateComment", params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                hideProgressDialog();
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "发表失败，请重试");
            }
        });
    }

    private void setStarFont() {
        StarOnClickListener starOnClickListener = new StarOnClickListener();
        TextView star1 = (TextView) findViewById(R.id.order_judge_grade_1);
        star1.setOnClickListener(starOnClickListener);
        starList.add(star1);
        star1.setTag(1);

        TextView star2 = (TextView) findViewById(R.id.order_judge_grade_2);
        star2.setOnClickListener(starOnClickListener);
        starList.add(star2);
        star2.setTag(2);

        TextView star3 = (TextView) findViewById(R.id.order_judge_grade_3);
        star3.setOnClickListener(starOnClickListener);
        starList.add(star3);
        star3.setTag(3);


        TextView star4 = (TextView) findViewById(R.id.order_judge_grade_4);
        star4.setOnClickListener(starOnClickListener);
        starList.add(star4);
        star4.setTag(4);


        TextView star5 = (TextView) findViewById(R.id.order_judge_grade_5);
        star5.setOnClickListener(starOnClickListener);
        starList.add(star5);
        star5.setTag(5);
    }

    class StarOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            TextView curr = (TextView) v;
            Integer size = (Integer) curr.getTag();
            updateScore(size);
            //筛选tag
            List<CommentByServerDO.Tag> filterTags = filterTagByScore(size);
            selectTags.clear();
            handlerTags(filterTags);
            commentSupply.setVisibility(View.VISIBLE);
            publishLayout.setVisibility(View.VISIBLE);
        }
    }

    //根据星级筛选标签
    private List<CommentByServerDO.Tag> filterTagByScore(int level){
        List<CommentByServerDO.Tag> tags = new ArrayList<CommentByServerDO.Tag>();
        for(CommentByServerDO.Tag tag : allTags){
            if(tag.getLevel() == level)
                tags.add(tag);
        }
        return tags;
    }


    private void handlerTags(List<CommentByServerDO.Tag> tags) {
        if ( (tags == null || tags.size() == 0) && selectTags.size() == 0 ) {
            tagLayout.setVisibility(View.GONE);
            tagGuideLayout.setVisibility(View.GONE);
            return;
        }
        //设置标签
        tagLayout.setVisibility(View.VISIBLE);
        tagGuideLayout.setVisibility(View.VISIBLE);
        initTag(tagLayout, tags);
    }

    private void initTag(FlowLayout tagLayout, List<CommentByServerDO.Tag> tags) {
        tagLayout.removeAllViews();
        List<String> selectId = new ArrayList<String>();
        if(selectTags.size() != 0){
            for(CommentByServerDO.Tag tag : selectTags){
                addItem(tag,true);
                selectId.add(tag.getId());
            }
        }
        for(CommentByServerDO.Tag tag : tags){
            if(selectId.contains(tag.getId()))
                continue;
            addItem(tag,false);
        }
    }

    private void addItem(CommentByServerDO.Tag tag, boolean isSelected) {
        TextView itemView = (TextView) LayoutInflater.from(this).inflate(R.layout.item_comment_tag, tagLayout, false);
        itemView.setText(String.format(getString(R.string.text_comment_tag), tag.getTagName()));
        if (isSelected) {
            itemView.setBackgroundResource(R.color.brand);
            itemView.setTextColor(getResources().getColor(R.color.brand_c));
        } else{
            itemView.setBackgroundResource(R.drawable.bg_rec_border_grey_j);
            itemView.setTextColor(getResources().getColor(R.color.grey_j));
        }
        HashMap tags = new HashMap();
        tags.put("type",isSelected);
        tags.put("tag",tag);
        itemView.setTag(tags);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tv = (TextView)v;
                HashMap tags = (HashMap) v.getTag();
                boolean type = (boolean)tags.get("type");
                CommentByServerDO.Tag tag = (CommentByServerDO.Tag)tags.get("tag");
                if (type) {
                    selectTags.remove(tag);
                    tv.setBackgroundResource(R.drawable.bg_rec_border_grey_j);
                    tv.setTextColor(getResources().getColor(R.color.grey_j));
                }else{
                    selectTags.add(tag);
                    tv.setBackgroundResource(R.color.brand);
                    tv.setTextColor(getResources().getColor(R.color.brand_c));
                }
                HashMap newTags = new HashMap();
                newTags.put("type",!type);
                newTags.put("text",tag);
                v.setTag(newTags);
            }
        });
        tagLayout.addView(itemView);
    }

    private void initSelectImagesGrid() {
        canPickPicCount = Constant.MAX_IMAGE_LENGTH - images.size();
        adapter = new ServiceGridAdapter(this, images,
                Constant.MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_SERVICE);
        adapter.setTHREE(0);
        selectImagesGrid.setAdapter(adapter);
        adapter.setOnClickListener(new ServiceGridAdapter.OnClickListener() {
            @Override
            public void onAddClick(View v, int position) {
                addImg(position);
            }

            @Override
            public void onEditClick(View v, int position) {
                currentPosition = position;
                addImg(position);
            }

            @Override
            public void onRemoveClick(View v, int position) {
                if (position < images.size()) {
                    images.set(position, "");
                    canPickPicCount++;
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    void addImg(int position) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", canPickPicCount);
        bundle.putInt("position", position);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, this);
    }

    /**
     * 上传图片
     */
    private void uploadImages() {
        if (isUploadCompleted()) {
            return;
        }
        uploadImage(0);
    }

    /**
     * 检查是否上传完成
     *
     * @return
     */
    private boolean isUploadCompleted() {
        for (String image : images) {
            if (!TextUtils.isEmpty(image) && !uploadedImages.containsKey(image)) {
                return false;
            }
        }
        return true;
    }

    private void uploadImage(final int index) {
        if (isUploading) {
            return;
        }
        final String imagePath = images.get(index);
        if (uploadedImages.containsKey(imagePath)) {
            for (int i = 0; i < images.size(); i++) {
                if (!uploadedImages.containsKey(images.get(i))) {
                    uploadImage(i);
                    return;
                }
            }
        }
        isUploading = true;
        RequestSign.upload(imagePath, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                isUploading = false;
                try {
                    org.json.JSONObject json = (org.json.JSONObject) result;
                    uploadedImages.put(imagePath, json.getString("data"));
                    for (int i = 0; i < images.size(); i++) {
                        if (!uploadedImages.containsKey(images.get(i))) {
                            uploadImage(i);
                            break;
                        }
                    }
                    if (isUploadCompleted() && isPublishing) {
                        publishComment();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(HttpError error) {
                isUploading = false;
                MessageUtils.showToastCenter(error != null ? "上传图片失败失败:" + error.getMessage() : "上传图片失败失败");
                hideProgressDialog();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (!hasChange()) {
            super.onBackPressed();
            return;
        }

        MessageUtils.createDialog(CommentActivity.this, "提醒", "评论未完成,确定离开?", R.string.confirm_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }, R.string.cancel_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        }).show();
    }

    private boolean hasChange() {

        return true;
    }
}
