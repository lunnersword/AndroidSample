
package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

/**
 *
 * Created by liujian on 16/2/17.
 */
public class LiveBindServiceListAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private List<ServiceItem> items;
    private int selectPos = -1;

    public LiveBindServiceListAdapter(Context context, List<ServiceItem> items) {
        this.mContext = context;
        this.items = items;
        this.mInflater = LayoutInflater.from(context);
    }

    public int getSelectPos() {
        return selectPos;
    }

    public void setSelectPos(int selectPos) {
        this.selectPos = selectPos;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_live_service, parent, false);
            holder = new ViewHolder();
            holder.pic = (SimpleDraweeView) convertView.findViewById(R.id.pic);
            holder.checkedIcon = convertView.findViewById(R.id.checkedIcon);
            holder.starGroup = (ViewGroup) convertView.findViewById(R.id.detail_judge_star_icon_group);
            holder.canDo = (TextView) convertView.findViewById(R.id.canDo);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        ServiceItem item = items.get(position);
        Uri imageUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getImages().get(0), holder.pic.getLayoutParams().width));
        holder.pic.setImageURI(imageUri);
        holder.canDo.setText(item.getTag());

        // 评分
        View starsView = mInflater.inflate(R.layout.activity_service_detail_stars, null);
        View contentView = starsView.findViewById(R.id.contentView);

        ViewGroup.LayoutParams params = contentView.getLayoutParams();
        params.height = (int) Helper.convertDpToPixel(20, mContext);
        contentView.setLayoutParams(params);
        Double grade;
        if (item.getGrade() != Float.MAX_VALUE) {
            grade = item.getGrade();
        } else {
            grade = 5.0;
        }

        View starsRed = starsView.findViewById(R.id.star_red_group);
        starsRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, mContext) * grade / 5);
        starsRed.getLayoutParams().height = (int) Helper.convertDpToPixel(20, mContext);
        holder.starGroup.removeAllViews();
        holder.starGroup.addView(starsView);


        if (position == selectPos) {
            holder.checkedIcon.setVisibility(View.VISIBLE);
        } else {
            holder.checkedIcon.setVisibility(View.GONE);
        }
        return convertView;
    }

    static class ViewHolder {
        SimpleDraweeView pic;
        TextView canDo;
        ViewGroup starGroup;
        View checkedIcon;
    }

    public Bundle getSelectItemData() {
        if (selectPos == -1)
            return null;
        Bundle params = new Bundle();
        ServiceItem item = items.get(selectPos);
        params.putString("id", item.getItemId());
        params.putString("pic", item.getImages().get(0));
        params.putString("title", item.getTag());
        params.putString("content", item.getContent());
        return params;
    }
}
