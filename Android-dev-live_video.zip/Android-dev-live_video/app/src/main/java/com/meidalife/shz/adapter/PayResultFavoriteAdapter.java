package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.common.util.UriUtil;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.DelAttentionListener;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.model.UserOutDO;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import java.util.List;

/**
 * Created by liujian on 16/3/1.
 */
public class PayResultFavoriteAdapter extends RecyclerView.Adapter<PayResultFavoriteAdapter.ViewHolder> {
    public static final int TYPE_HEADER = 0;
    public static final int TYPE_NORMAL = 1;
    private View mHeaderView;
    private Context mContext;
    private LayoutInflater mInflater;
    private List<ServiceItem> serviceItemList;
    DelAttentionListener delAttentionListener;

    public PayResultFavoriteAdapter(Context context, List<ServiceItem> serviceItemList) {
        this.mContext = context;
        this.mInflater = LayoutInflater.from(context);
        this.serviceItemList = serviceItemList;
    }

    public void setDelAttentionListener(DelAttentionListener delAttentionListener) {
        this.delAttentionListener = delAttentionListener;
    }

    public void setData(List<ServiceItem> discoverItemList) {
        this.serviceItemList = discoverItemList;
    }

    public void setHeaderView(View headerView) {
        mHeaderView = headerView;
        notifyItemInserted(0);
    }

    public View getHeaderView() {
        return mHeaderView;
    }

    public int getRealPosition(RecyclerView.ViewHolder holder) {
        int position = holder.getLayoutPosition();
        return mHeaderView == null ? position : position - 1;
    }

    @Override
    public int getItemViewType(int position) {
        if (mHeaderView == null) return TYPE_NORMAL;
        if (position == 0) return TYPE_HEADER;
        return TYPE_NORMAL;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (mHeaderView != null && viewType == TYPE_HEADER)
            return new ViewHolder(mHeaderView);
        View itemView = mInflater.inflate(R.layout.favorite_service_card_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(itemView);
        viewHolder.avatar = (ImageView) itemView.findViewById(R.id.avatar);
        viewHolder.title = (TextView) itemView.findViewById(R.id.item_title);
        viewHolder.serviceType = (TextView) itemView.findViewById(R.id.service_type);
        viewHolder.image = (ImageView) itemView.findViewById(R.id.item_image);
        viewHolder.price = (TextView) itemView.findViewById(R.id.item_price);
        viewHolder.chatView = itemView.findViewById(R.id.buttonChat);
        viewHolder.rootView = itemView.findViewById(R.id.service_card);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (getItemViewType(position) == TYPE_HEADER)
            return;
        final int pos = getRealPosition(holder);
        if (pos < serviceItemList.size()) {
            final ServiceItem item = serviceItemList.get(pos);

            final UserOutDO user = item.getUser();
            if (user != null) {
                String avatarUrl = ImgUtil.getCDNUrlWithWidth(user.getUserAvatar(),
                        mContext.getResources().getDimensionPixelSize(R.dimen.discover_avatar_size));
                if (TextUtils.isEmpty(avatarUrl)) {
                    Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(user.getUserId()), user.getUserGender());
                    holder.avatar.setImageURI(getDefaultAvatarUri);
                } else {
                    holder.avatar.setImageURI(Uri.parse(avatarUrl));
                }
            }

            holder.title.setText(mContext.getResources().getString(R.string.label_i_can) + " " + item.getTag());

            String typeLabel = typeToLabel(item.getServiceType(), item.getCityName());
            if (typeLabel == null) {
                holder.serviceType.setVisibility(View.GONE);
            } else {
                holder.serviceType.setVisibility(View.VISIBLE);
                holder.serviceType.setText(typeLabel);
            }

            if (item.getImages() != null && item.getImages().size() > 0) {
                holder.image.setImageURI(Uri.parse(item.getImages().get(0)));
            } else {
                //todo 没有图片  显示默认
                Uri img = new Uri.Builder()
                        .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.avatar)).build();
                holder.image.setImageURI(img);
            }
            holder.price.setText(String.valueOf(item.getPrice()));


            holder.chatView.setVisibility(View.VISIBLE);
            holder.chatView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    // 使用 initIm 接口调用 方式
                    String action = "chatFormService/";
                    if (user != null) {
                        action += user.getUserId();
                    }
                    action += "/";
                    action += item.getItemId();

                    if (Helper.sharedHelper().hasToken()) {
                        Router.sharedRouter().open(action);
                        LogParam param = new LogParam();
                        param.setType(LogUtil.TYPE_CUSTOMIZE);
                        param.setEid(LogUtil.EVENT_ID_CHAT_CLICK);
                        param.setPvid(item.getPvid());
                        LogUtil.log(param);
                    } else {
                        Bundle bundle = new Bundle();
                        bundle.putString("action", action);
                        Router.sharedRouter().open("signin", bundle);
                    }
                }
            });

            holder.rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("services/" + item.getItemId());
                }
            });

        }
    }

    @Override
    public int getItemCount() {
        return mHeaderView == null ? serviceItemList.size() : serviceItemList.size() + 1;
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        RecyclerView.LayoutManager manager = recyclerView.getLayoutManager();
        if (manager instanceof GridLayoutManager) {
            final GridLayoutManager gridManager = ((GridLayoutManager) manager);
            gridManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override
                public int getSpanSize(int position) {
                    return getItemViewType(position) == TYPE_HEADER
                            ? gridManager.getSpanCount() : 1;
                }
            });
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView avatar;//头像
        TextView title;//宝贝标题
        TextView serviceType;//服务类型
        ImageView image;//图片
        TextView price;//价格
        View chatView;//聊天
        View rootView;//item root view

        public ViewHolder(View itemView) {
            super(itemView);
        }
    }

    public static String typeToLabel(int serviceType, String cityName) {
        String label = null;
        switch (serviceType) {
            case 1:
                label = (cityName == null ? "" : cityName) + "上门";
                break;
            case 2:
                label = (cityName == null ? "" : cityName) + "到店";
                break;
            case 3:
                label = "线上";
                break;
            case 4:
                label = "邮寄";
                break;
            default:
                label = null;
        }
        return label;
    }
}
