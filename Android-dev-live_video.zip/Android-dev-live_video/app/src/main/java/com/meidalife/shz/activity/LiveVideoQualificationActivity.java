package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.LiveVideoCheckListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LiveVideoCheckDO;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

public class LiveVideoQualificationActivity extends BaseActivity {

    private ArrayList<LiveVideoCheckDO.CheckList> checkLists;
    private LiveVideoCheckListAdapter liveVideoCheckListAdapter;

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentLayout)
    View contentLayout;
    @Bind(R.id.checkListView)
    ListView checkListView;
    @Bind(R.id.btnApplyFor)
    FontTextView btnApplyFor;
    @Bind(R.id.agreeLabel)
    IconTextView agreeLabel;
    @Bind(R.id.agreeLiveRule)
    View agreeLiveRule;
    @Bind(R.id.liveRule)
    View liveRule;

    private boolean isAgreed;
    private boolean isPassed;
    private LoadUtil mLoadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_video_qualification);
        initActionBar(R.string.title_activity_live_video_no_qualification, true);
        ButterKnife.bind(this);
        bindListener();

        mLoadUtil = new LoadUtil(getLayoutInflater());

        checkLists = new ArrayList<>();
        liveVideoCheckListAdapter = new LiveVideoCheckListAdapter(this, checkLists);
        checkListView.setAdapter(liveVideoCheckListAdapter);
        loadData(true);
    }

    private void bindListener() {
        btnApplyFor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 直播准备
//                Router.sharedRouter().open("liveReady");
//                finish();

                if (isPassed) {
                    if (isAgreed) {
                        Helper.sharedHelper().setBooleanUserInfo(Constant.USER_AGREED_LIVE_RULE, true);
                        Router.sharedRouter().open("liveReady");
                        finish();
                    } else {
                        MessageUtils.showToast("你还没有同意直播守则哦");
                    }

                } else {
                    MessageUtils.showToast("你还有未满足的条件哦");
                }

            }
        });

        agreeLiveRule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isAgreed) {
                    agreeLabel.setTextColor(getResources().getColor(R.color.square_i_want_title));
                    if (isPassed)
                        btnApplyFor.setBackgroundResource(R.color.brand_b);
                } else {
                    agreeLabel.setTextColor(getResources().getColor(R.color.grey_j));
                    btnApplyFor.setBackgroundResource(R.color.grey_j);
                }
                isAgreed = !isAgreed;
            }
        });

        liveRule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //// TODO: 16/4/9  直播准则 h5
            }
        });
    }

    private boolean mLoading = false;

    public void loadData(boolean reload) {
        if (mLoading) {
            return;
        }
        mLoading = true;
        if (reload) {
            checkLists.clear();
            mLoadUtil.loadPre(rootView, contentLayout);
        }
        checkQualification();
    }

    private void checkQualification() {
        JSONObject params = new JSONObject();
        params.put("type", 0);
        HttpClient.get("1.0/applyaccess/permission", params, LiveVideoCheckDO.class, new HttpClient.HttpCallback<LiveVideoCheckDO>() {
            @Override
            public void onSuccess(LiveVideoCheckDO liveVideoCheckDO) {
                mLoadUtil.loadSuccess(contentLayout);
                // 检查权限审核列表,并处理结果
                dealWithQualification(liveVideoCheckDO);
                mLoading = false;

            }

            @Override
            public void onFail(HttpError error) {
                mLoading = false;
                // 显示"权限审核"失败相关提示
                mLoadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        loadData(true);
                    }
                });
            }
        });
    }

    private void dealWithQualification(LiveVideoCheckDO liveVideoCheckDO) {
        ArrayList<LiveVideoCheckDO.CheckList> lists = liveVideoCheckDO.getCheckList();
        if (lists != null && lists.size() > 0) {
            checkLists.addAll(lists);
        }
        liveVideoCheckListAdapter.notifyDataSetChanged();

        if (liveVideoCheckDO.getStatus() == Constant.LIVE_VIDEO_STATUS_PASSED) {
            isPassed = true;
        }
    }

}
