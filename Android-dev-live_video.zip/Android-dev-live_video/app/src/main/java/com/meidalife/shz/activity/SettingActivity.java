package com.meidalife.shz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.util.DataCleanUtils;
import com.meidalife.shz.util.UpdateUtil;
import com.meidalife.shz.view.FlowLayout;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.widget.MessageDialog;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

public class SettingActivity extends BaseActivity {

    @Bind(R.id.signout)
    Button buttonSignout;
    @Bind(R.id.packageVersion)
    TextView packageVersion;

    @Bind(R.id.profileArrow)
    TextView profileArrow;
    @Bind(R.id.messageArrow)
    TextView messageArrow;
    @Bind(R.id.addressManageArrow)
    TextView addressManageArrow;
    @Bind(R.id.cleanCacheArrow)
    TextView cleanCacheArrow;
    @Bind(R.id.aboutMeArrow)
    TextView aboutMeArrow;
    @Bind(R.id.cacheSize)
    TextView cacheSize;

    private static final int SIGNIN_FOR_OPEN_PROFILE_REQUEST_CODE = 101;
    private static final int SIGNIN_FOR_OPEN_MESSAGE_REQUEST_CODE = 102;
    private static final int SIGNIN_FOR_OPEN_ADDRESS_MANAGE_REQUEST_CODE = 103;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        initActionBar(R.string.title_activity_setting, true);

        ButterKnife.bind(this);

        try {
            packageVersion.setText(getVersion());
        } catch (Exception e) {

        }
        profileArrow.setTypeface(Helper.sharedHelper().getIconFont());
        messageArrow.setTypeface(Helper.sharedHelper().getIconFont());
        addressManageArrow.setTypeface(Helper.sharedHelper().getIconFont());
        cleanCacheArrow.setTypeface(Helper.sharedHelper().getIconFont());
        aboutMeArrow.setTypeface(Helper.sharedHelper().getIconFont());

        try {
            cacheSize.setText(DataCleanUtils.getTotalCacheSize(this));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        if (Helper.sharedHelper().hasToken()) {
            buttonSignout.setVisibility(View.VISIBLE);
        } else {
            buttonSignout.setVisibility(View.GONE);
        }

    }

    public void handleOpenProfile(View view) {
        if (Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().open("aboutme");
        } else {
            Router.sharedRouter().openFormResult("signin", SIGNIN_FOR_OPEN_PROFILE_REQUEST_CODE, SettingActivity.this);
        }
    }

    public void handleOpenMessage(View view) {
        if (Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().open("messageSetting");
        } else {
            Router.sharedRouter().openFormResult("signin", SIGNIN_FOR_OPEN_MESSAGE_REQUEST_CODE, SettingActivity.this);
        }
    }

    public void handleOpenAddressManage(View view) {
        if (Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().open("addressManage");
        } else {
            Router.sharedRouter().openFormResult("signin", SIGNIN_FOR_OPEN_ADDRESS_MANAGE_REQUEST_CODE, SettingActivity.this);
        }
    }

    public void handleOpenCleanCache(View view) {
        try {
            DataCleanUtils.clearAllCache(this);
            Fresco.getImagePipeline().clearCaches();
            cacheSize.setText("0.0MB");
            MessageUtils.showToast("已清除");
        } catch (Exception e) {
            MessageUtils.showToast("清除失败");
            e.printStackTrace();
        }

    }

    public void handleCheckUpdate(View view) {
        UpdateUtil.getInstance(this).checkUpdate(true);
//        Intent intent = new Intent(this, LiveVideoListActivity.class);
//        startActivity(intent);
    }

    public void handleSignout(View view) {
        Helper.sharedHelper().signOut();
        MessageUtils.showToastCenter("已退出");
        finish();
    }

    public void handleComment(View view) {
        try {
            Uri uri = Uri.parse("market://details?id=" + getPackageName());
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void handleOpenAboutUs(View v) {
        Bundle bundle = new Bundle();
        bundle.putString("url", "http://kongge.com/support/about.html");
        Router.sharedRouter().open("web", bundle);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (Helper.sharedHelper().hasToken()) {
            if (requestCode == SIGNIN_FOR_OPEN_PROFILE_REQUEST_CODE) {
                Router.sharedRouter().open("aboutme");
            } else if (requestCode == SIGNIN_FOR_OPEN_MESSAGE_REQUEST_CODE) {
                Router.sharedRouter().open("messageSetting");
            } else if (requestCode == SIGNIN_FOR_OPEN_ADDRESS_MANAGE_REQUEST_CODE) {
                Router.sharedRouter().open("addressManage");
            }
        }
    }

    private String getVersion() throws Exception {
        if (HttpClient.BASE_URL_RELEASE.equals(HttpClient.genAbsoluteUrl(""))) {
            return Helper.sharedHelper().getVersionName();
        } else if (HttpClient.BASE_URL_PRE.equals(HttpClient.genAbsoluteUrl(""))) {
            return Helper.sharedHelper().getVersionName() + "_pre";
        } else if (HttpClient.BASE_URL_DEV.equals(HttpClient.genAbsoluteUrl(""))) {
            return Helper.sharedHelper().getVersionName() + "_dev";
        } else if (HttpClient.BASE_URL_DEV2.equals(HttpClient.genAbsoluteUrl(""))) {
            return Helper.sharedHelper().getVersionName() + "_dev2";
        }
        return Helper.sharedHelper().getVersionName();
    }
}
