package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.usepropeller.routable.Router;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 我的格子列表
 * Created by xingchen on 2015/12/21.
 */
public class MDMySquareActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener {
    private static int GET_DATA_REFRESH = 0;  // 刷新数据
    private static int GET_DATA_LOAD_MORE = 1;  //加载更多数据

    @Bind(R.id.squareListView)
    ListView squareListView;
    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    private View listFooter;
    private ProgressBar footerLoading;
    private Button footerReload;
    private TextView footerMessage;

    private int hostPage = 0;
    private int memberPage = 0;
    private boolean showLoading = false;
    private boolean isHostComplete;
    private boolean isMemberComplete;
    private boolean isHostRefresh = false;
    private boolean isHostLoad = false;
    private boolean isMemberRefresh = false;
    private boolean isMemberLoad = false;
    private JSONArray hostList;
    private JSONArray memberList;
    private SquareListAdapter squareListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_square_list);
        ButterKnife.bind(this);

        initActionBar(R.string.square_my, true);

        hostList = new JSONArray();
        memberList = new JSONArray();

        listFooter = View.inflate(this, R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);
        squareListView.addFooterView(listFooter);
        listFooter.setVisibility(View.GONE);

        squareListAdapter = new SquareListAdapter(this, hostList, memberList);
        squareListView.setAdapter(squareListAdapter);
        initListener();

    }

    @Override
    public void onResume() {
        super.onResume();
        showLoading = true;
        getHostData(GET_DATA_REFRESH);
    }

    private void initListener(){
        swipeRefreshLayout.setOnRefreshListener(this);
        squareListAdapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getTag() == null)
                    return;
                HashMap params = (HashMap)v.getTag();
                int dataType = (int)params.get("dataType");
                int position = (int)params.get("position");
                JSONObject item = null;
                if(dataType == SquareListAdapter.DATA_TYPE_HOST){
                    item = hostList.getJSONObject(position - 1);
                }else if(dataType == SquareListAdapter.DATA_TYPE_MEMBER){
                    if(hostList.size() == 0){
                        item = memberList.getJSONObject(position - 1);
                    }else{
                        if(position > hostList.size()+1){
                            item = memberList.getJSONObject(position - 2 - hostList.size());
                        }
                    }
                }
                if (item != null && item.containsKey("geziId")){
                    if(dataType == SquareListAdapter.DATA_TYPE_HOST){
                        Router.sharedRouter().open("squaremanage/index/" + item.getIntValue("geziId"), MDMySquareActivity.this);
                    }else{
                        Router.sharedRouter().open("squareindex/" + item.getIntValue("geziId"));
                    }
                }
            }
        });

        squareListView.setOnScrollListener(new AbsListView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                // BaseEvent message = new BaseEvent();
                final View topChildView = squareListView.getChildAt(0);
                if (scrollState == SCROLL_STATE_IDLE && squareListView.getFirstVisiblePosition() == 0
                        && topChildView.getTop() == 0) {
                    /*message.eventType = MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);*/
                } else {
                    /*message.eventType = MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);*/
                }

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        getHostData(GET_DATA_LOAD_MORE);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                //EventBus.getDefault().post(AttachUtil.isAdapterViewAttach(view));
            }
        });
    }

    private void getMemberSquare(final int loadType) {

        if (loadType == GET_DATA_REFRESH) {
            hideStatusErrorServer();
            hideStatusErrorNetwork();
            /*if(isMemberRefresh)
                return;*/
            isMemberRefresh = true;
            memberPage = 0;
            isMemberComplete = false;
        }
        if (loadType == GET_DATA_LOAD_MORE) {
            if (isMemberComplete || isMemberLoad) {
                return;
            }
            if (isHostComplete) {
                footerMessage.setText("正在加载");
                listFooter.setVisibility(View.VISIBLE);
                footerLoading.setVisibility(View.VISIBLE);
                footerMessage.setVisibility(View.VISIBLE);
                footerReload.setVisibility(View.GONE);
            }
            isMemberLoad = true;
            memberPage++;
        }
        JSONObject params = new JSONObject();
        params.put("type", 2);
        params.put("pageSize", 20);
        params.put("offset", memberPage * 20);
        HttpClient.get("1.0/gezi/mylist", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                swipeRefreshLayout.setRefreshing(false);
                if (showLoading)
                    hideStatusLoading();
                showLoading = false;
                hideStatusErrorNetwork();
                hideStatusErrorServer();

                swipeRefreshLayout.setVisibility(View.VISIBLE);
                JSONArray geziList = obj.getJSONArray("geziList");

                if (loadType == GET_DATA_REFRESH) {
                    isMemberRefresh = false;
                    memberList.clear();
                } else {
                    isMemberLoad = false;
                    listFooter.setVisibility(View.GONE);
                }
                memberList.addAll(geziList);
                squareListAdapter.notifyDataSetChanged();
                if (geziList.size() < 20) {
                    isMemberComplete = true;
                    if (isHostComplete) {
                        squareListView.removeFooterView(listFooter);
                    }
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (showLoading) {
                    hideStatusLoading();
                    showLoading = false;
                }

                if (loadType == GET_DATA_REFRESH) {
                    swipeRefreshLayout.setRefreshing(false);
                    swipeRefreshLayout.setVisibility(View.GONE);
                    isMemberRefresh = false;
                    if (hostList.size() > 0)
                        hostList.clear();
                    if (memberList.size() > 0)
                        memberList.clear();
                    squareListAdapter.notifyDataSetChanged();
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        showStatusErrorNetwork(rootView, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                showLoading = true;
                                getHostData(loadType);
                            }
                        });
                    } else {
                        showStatusErrorServer(rootView, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                showLoading = true;
                                getHostData(loadType);
                            }
                        });
                        if (!TextUtils.isEmpty(error.getMessage())) {
                            setTextErrorServer(error.getMessage());
                        }
                    }
                } else {
                    isMemberLoad = false;
                    memberPage--;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);

                    listFooter.setVisibility(View.VISIBLE);
                    footerReload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getMemberSquare(loadType);
                        }
                    });
                }
            }
        });

    }

    private void getHostData(final int loadType) {
        if (showLoading) {
            swipeRefreshLayout.setVisibility(View.GONE);
            showStatusLoading(rootView);
        }
        if (loadType == GET_DATA_REFRESH) {
            hideStatusErrorServer();
            hideStatusErrorNetwork();
            /*if(isHostRefresh)
                return;*/
            isHostRefresh = true;
            hostPage = 0;
            isHostComplete = false;
        }
        if (loadType == GET_DATA_LOAD_MORE) {
            if (isHostComplete) {
                getMemberSquare(loadType);
                return;
            } else if (isHostLoad) {
                return;
            }
            footerMessage.setText("正在加载");
            listFooter.setVisibility(View.VISIBLE);
            footerLoading.setVisibility(View.VISIBLE);
            footerMessage.setVisibility(View.VISIBLE);
            footerReload.setVisibility(View.GONE);
            isHostLoad = true;
            hostPage++;
        }
        JSONObject params = new JSONObject();
        params.put("type", 1);
        params.put("pageSize", 20);
        params.put("offset", hostPage * 20);
        HttpClient.get("1.0/gezi/mylist", params, null, new HttpClient.HttpCallback<JSONObject>() {

            @Override
            public void onSuccess(JSONObject obj) {
                hideStatusErrorNetwork();
                hideStatusErrorServer();

                JSONArray geziList = obj.getJSONArray("geziList");

                if (loadType == GET_DATA_REFRESH) {
                    isHostRefresh = false;
                    hostList.clear();
                } else {
                    isHostLoad = false;
                    if (isMemberComplete) {
                        swipeRefreshLayout.setRefreshing(false);
                        listFooter.setVisibility(View.GONE);
                        squareListAdapter.notifyDataSetChanged();
                    }
                }
                hostList.addAll(geziList);
                getMemberSquare(loadType);
                if (geziList.size() < 20) {
                    isHostComplete = true;
                    if (isMemberComplete) {
                        squareListView.removeFooterView(listFooter);
                    }
                }

            }

            @Override
            public void onFail(HttpError error) {
                if (showLoading) {
                    hideStatusLoading();
                    showLoading = false;
                }
                swipeRefreshLayout.setRefreshing(false);
                swipeRefreshLayout.setVisibility(View.GONE);
                if (loadType == GET_DATA_REFRESH) {
                    isHostRefresh = false;
                    if (hostList.size() > 0)
                        hostList.clear();
                    if (memberList.size() > 0)
                        memberList.clear();
                    squareListAdapter.notifyDataSetChanged();
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        showStatusErrorNetwork(rootView, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                showLoading = true;
                                getHostData(loadType);
                            }
                        });
                    } else {
                        showStatusErrorServer(rootView, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                showLoading = true;
                                getHostData(loadType);
                            }
                        });
                        if (!TextUtils.isEmpty(error.getMessage())) {
                            setTextErrorServer(error.getMessage());
                        }
                    }
                } else {
                    isHostLoad = false;
                    hostPage--;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);

                    listFooter.setVisibility(View.VISIBLE);
                    footerReload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getHostData(loadType);
                        }
                    });
                }
            }
        });
    }

    @Override
    public void onRefresh() {
        getHostData(GET_DATA_REFRESH);
    }
}
