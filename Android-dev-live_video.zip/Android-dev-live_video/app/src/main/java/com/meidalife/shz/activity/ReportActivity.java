package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.widget.CheckableIconText;
import com.meidalife.shz.widget.TutorialPopupWindow;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/1/29.
 */
public class ReportActivity extends BaseActivity {
    private Integer selectedId;
    private String squareId;
    private String targetId;
    private int target;
    private boolean isRequesting = false;

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.contentRoot)
    ViewGroup contentRoot;
    @Bind(R.id.reportTypeList)
    ListView reportTypeListView;
    @Bind(R.id.reportButton)
    Button reportButton;
    @Bind(R.id.reportNotice)
    TextView reportNotice;

    private ReportReasonAdapter reportReasonAdapter;
    private LoadUtil mLoadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        ButterKnife.bind(this);
        initActionBar("举报", true, false);
        initData();

        getReportTypeList();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().openFormResult("signin",
                    Constant.REQUEST_CODE_SIGNIN, this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_SIGNIN) {
            if (RESULT_OK == resultCode) {
                getReportTypeList();
            } else {
                finish();
            }
        }
    }

    private void initData() {
        mLoadUtil = new LoadUtil(LayoutInflater.from(this));
        squareId = getIntent().getStringExtra("squareId");
        targetId = getIntent().getStringExtra("targetId");
        target = getIntent().getIntExtra("target", 0);

        reportReasonAdapter = new ReportReasonAdapter(this, new JSONArray());
        reportTypeListView.setAdapter(reportReasonAdapter);

        reportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doReport();
            }
        });

        reportNotice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", "http://kongge.com/support/report.html");
                Router.sharedRouter().open("web", bundle);
            }
        });
    }

    private void getReportTypeList() {
        mLoadUtil.loadPre(rootLayout, contentRoot);
        HttpClient.get("1.0/report/getReportTypeList", new JSONObject(),
                JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {

                    @Override
                    public void onSuccess(JSONObject obj) {
                        mLoadUtil.loadSuccess(contentRoot);
                        reportReasonAdapter.setReportTypeList(obj.getJSONArray("reportTypeList"));
                    }

                    @Override
                    public void onFail(HttpError error) {
                        mLoadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                            @Override
                            public void retry() {
                                getReportTypeList();
                            }
                        });
                    }
                }
        );
    }

    @Override
    protected void doReport() {
        if (isRequesting) {
            return;
        }
        if (reportReasonAdapter.getSelectedId() == null) {
            MessageUtils.showToast("请选择举报理由");
            return;
        }

        JSONObject params = new JSONObject();
        params.put("type", reportReasonAdapter.getSelectedId());
        params.put("targetId", targetId);
        params.put("target", target);
        if (!TextUtils.isEmpty(squareId)) {
            params.put("geziId", squareId);
        }
        isRequesting = true;
        HttpClient.get("1.0/report/doReport", params,
                JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {

                    @Override
                    public void onSuccess(JSONObject obj) {
                        isRequesting = false;
                        showHintPopupWindow();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        isRequesting = false;
                        MessageUtils.showToast(error.toString());
                    }
                }
        );
    }

    private void showHintPopupWindow() {
        try {
            TutorialPopupWindow hintPopupWindow = new TutorialPopupWindow(this,
                    TutorialPopupWindow.TUTORIAL_TYPE_CUSTOMIZE);
            hintPopupWindow.addTutorialItems(new TutorialPopupWindow.TutorialItem(null,
                    getString(R.string.report_hint), null,
                    R.mipmap.response_2h, getString(R.string.i_know)));
            hintPopupWindow.setOnFinishListener(new TutorialPopupWindow.OnFinishListener() {
                @Override
                public void onFinish() {
                    finish();
                }
            });
            if (!isFinishing()) {
                hintPopupWindow.showTutorial(reportButton);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class ReportReasonAdapter extends BaseAdapter {
        private JSONArray reportTypeList;
        private LayoutInflater mInflater;

        public ReportReasonAdapter(Context context, JSONArray reportTypeList) {
            mInflater = LayoutInflater.from(context);
            setReportTypeList(reportTypeList);
        }

        public void setReportTypeList(JSONArray reportTypeList) {
            this.reportTypeList = reportTypeList;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return reportTypeList.size();
        }

        @Override
        public Object getItem(int position) {
            return reportTypeList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final ViewHolder viewHolder;
            if (convertView == null) {
                viewHolder = new ViewHolder();
                convertView = mInflater.inflate(R.layout.item_report_type, parent, false);
                viewHolder.reportType = (TextView) convertView.findViewById(R.id.reportType);
                viewHolder.checkableIconText = (CheckableIconText) convertView.findViewById(R.id.checkbox);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            JSONObject jsonObject = reportTypeList.getJSONObject(position);
            final Integer reportTypeId = jsonObject.getInteger("reportTypeId");
            viewHolder.reportType.setText(jsonObject.getString("reportType"));

            if (reportTypeId != null) {
                viewHolder.checkableIconText.setChecked(reportTypeId.equals(selectedId));
                convertView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        viewHolder.checkableIconText.setChecked(true);
                        selectedId = reportTypeId;
                        notifyDataSetChanged();
                    }
                });
            }
            return convertView;
        }

        public Integer getSelectedId() {
            return selectedId;
        }
    }

    public static class ViewHolder {
        TextView reportType;
        CheckableIconText checkableIconText;
    }
}
