package com.meidalife.shz.activity.fragment;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.AnimationDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.common.util.UriUtil;
import com.facebook.drawee.generic.RoundingParams;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.activity.AttentionListener;
import com.meidalife.shz.activity.BarcodeScannerActivity;
import com.meidalife.shz.activity.DynamicNewsListActivity;
import com.meidalife.shz.activity.PickCityActivity;
import com.meidalife.shz.activity.WebActivity;
import com.meidalife.shz.adapter.AdViewPageAdapter;
import com.meidalife.shz.adapter.CategoryItemPageAdapter;
import com.meidalife.shz.adapter.HomeBlockAdapter;
import com.meidalife.shz.adapter.HomeFindWonderAdapter;
import com.meidalife.shz.adapter.HomeTabAdapter;
import com.meidalife.shz.adapter.HomeVocationAdapter;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.AttentionUserEvent;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.HomeUpdateEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpClient.HttpCallback;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CategoryDO;
import com.meidalife.shz.rest.model.HomeCategoriesDO;
import com.meidalife.shz.rest.model.HomeDO;
import com.meidalife.shz.rest.model.HomeDiscoveriesDO;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.ServiceListOutDo;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ConvertToUtils;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.MyListView;
import com.meidalife.shz.view.PromotionTrebleView;
import com.meidalife.shz.widget.ActivityPopupWindow;
import com.umeng.analytics.MobclickAgent;
import com.usepropeller.routable.Router;
import com.viewpagerindicator.CirclePageIndicator;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

public class HomeFragment extends BaseFragment implements ViewPager.OnPageChangeListener {

    private static final int PAGE_SIZE = 10;

    private LayoutInflater mInflater;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;

    private View listFooter;
    private View listHeader;

    @Bind(R.id.locationLayout)
    ViewGroup locationLayout;
    @Bind(R.id.locationValue)
    TextView locationValue;
    @Bind(R.id.searchBar)
    ViewGroup searchBar;
    @Bind(R.id.avatarLayout)
    ViewGroup avatarLayout;
    @Bind(R.id.myProfile)
    TextView myProfile;
    @Bind(R.id.myAvatar)
    SimpleDraweeView myAvatar;
    @Bind(R.id.searchHint)
    TextView searchHint;
    @Bind(R.id.barcodeScanner)
    TextView barcodeScanner;

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    // ListView不用Bind的方式
    ListView listView;

//    @Bind(R.id.serviceRefreshButton)
//    View serviceRefreshButton;

//    @Bind(R.id.textStatusErrorServer)
//    TextView textStatusErrorServer;
//    @Bind(R.id.cellStatusLoading)
//    LinearLayout cellStatusLoading;
//    @Bind(R.id.cellStatusErrorNetwork)
//    LinearLayout cellStatusErrorNetwork;
//    @Bind(R.id.cellStatusErrorServer)
//    LinearLayout cellStatusErrorServer;

//    @Bind(R.id.updateItemCountView)
//    View updateItemCountView;

//    @Bind(R.id.updateItemCountText)
//    TextView updateItemCountText;

    @Bind(R.id.contentLayout)
    ViewGroup contentLayout;

    private TextView footerMessage;
    private View rootView;
    private ProgressBar footerLoading;
    private Button footerReload;
    private AnimationDrawable loadingAnimation;

    //顶部单张广告 2.3.1引入.
    SimpleDraweeView homeTopAd;
    View homeTopAdPlaceHolder;

    //头部滚动广告
    ViewGroup adViewLayout;
    ViewPager adViewPager;
    CirclePageIndicator adViewIndicator;

    //类目列表
    ViewPager categoryViewPager;
    CirclePageIndicator categoryIndicator;

    // 功能区块(一元抢约,技能直播,全民拼团,发布服务)
    @Bind(R.id.layout_function_block)
    LinearLayout mFuncBlockLayout;

    // 同城牛人
    @Bind(R.id.layout_the_same_city)
    View mOfflineCategoryLayout;
    @Bind(R.id.layout_vocation_banner)
    LinearLayout mVocationBannerLayout;
    @Bind(R.id.tv_vocation_banner_title)
    TextView mVocationBannerTitleTv;
    //@Bind(R.id.layout_vocation_banner_right)
    //LinearLayout mVocationBannerRightLayout;
    @Bind(R.id.drawee_vocation_banner)
    SimpleDraweeView mVocationBannerDrawee;
    @Bind(R.id.drawee_rank_1)
    SimpleDraweeView mRankDrawee1;
    @Bind(R.id.drawee_rank_2)
    SimpleDraweeView mRankDrawee2;
    @Bind(R.id.drawee_rank_3)
    SimpleDraweeView mRankDrawee3;
    // 线下类目
    @Bind(R.id.split_line_above_vocation)
    View mVocationSplitLine;
    @Bind(R.id.recyclerview_vocation)
    RecyclerView mVocationRecyclerView;

    // 发现精彩
    @Bind(R.id.split_line_above_discovery)
    View mDiscoverySplitLine;
    @Bind(R.id.layout_discovery_banner)
    View mDiscoveryBannerLayout;
    @Bind(R.id.tv_discovery_banner_title)
    TextView mDiscoveryBannerTitleTv;
    @Bind(R.id.drawee_discoveries_banner)
    SimpleDraweeView mDiscoveriesBannerDrawee;
    // 格子
    @Bind(R.id.split_line_above_square)
    View mSquareSplitLine;
    @Bind(R.id.layout_discovery_square)
    View mDiscoverySquareLayout;

    @Bind(R.id.drawee_gezi_image)
    SimpleDraweeView mGeziImageDrawee;
    @Bind(R.id.tv_gezi_subject)
    TextView mGeziSubjectTv;
    @Bind(R.id.tv_gezi_title)
    TextView mGeziTitleTv;
    @Bind(R.id.tv_gezi_distance)
    TextView mGeziDistanceTv;
    @Bind(R.id.tv_gezi_people_num)
    TextView mGeziPeopleNumTv;
    @Bind(R.id.tv_gezi_vocation_num)
    TextView mGeziVocationNum;
    @Bind(R.id.drawee_gezi_user_avatar)
    SimpleDraweeView mGeziUserAvatar;
    @Bind(R.id.tv_gezi_user_gender)
    TextView mGeziUserGenderTv;
    @Bind(R.id.tv_gezi_user_add_time)
    TextView mGeziUserAddTimeTv;
    @Bind(R.id.tv_gezi_user_desc)
    TextView mGeziUserDescTv;
    @Bind(R.id.tv_gezi_tag1)
    TextView mGeziTagTv1;
    @Bind(R.id.tv_gezi_tag2)
    TextView mGeziTagTv2;
    @Bind(R.id.tv_gezi_tag3)
    TextView mGeziTagTv3;
    @Bind(R.id.tv_gezi_tag4)
    TextView mGeziTagTv4;
    // 发现精彩列表
    @Bind(R.id.split_line_discoveries_list)
    View mDiscoveriesListSplitLine;
    @Bind(R.id.listview_discoveries)
    MyListView mDiscoveriesListView;

    //腰峰广告
    View homeBeltAdViewLayout;
    SimpleDraweeView homeBeltAdv;

    //滚动条广告
    ImageSwitcher userAvatar;
    TextSwitcher userNick;
    LinearLayout topSaleLayout;
    SimpleDraweeView topSaleIcon;

    //3个格子
    PromotionTrebleView promotionTrebleView;

    //4个格子
    GridView promotionGridView;

    View promotionAdvDividerLine;

    //服务列表
    GridView navTabView;
    @Bind(R.id.navTabViewTop)
    GridView navTabViewTop;

    private static final int TOP_SALE_CHANGE_TIMES = 5000;
    List<CategoryDO> categories = new ArrayList<>();
    //    private static int PROMOTION_ICON_SIZE;
    private String searchHintStr;

    int runtimes = 0;
    Handler handler = new Handler();
    //    Handler refreshHandler = new Handler() {
//
//        @Override
//        public void handleMessage(Message msg) {
//            super.handleMessage(msg);
//
//            if (msg.what == 1) {
//                updateItemCountView.setVisibility(View.GONE);
//                updateItemCountText.setText("");
//            }
//        }
//    };
    JSONArray topSales;

    private LoadUtil loadUtil;
    private AdViewPageAdapter adViewPageAdapter;

    private CategoryItemPageAdapter categoryItemPageAdapter;
    private HomeTabAdapter homeTabAdapter;

    private ArrayList<CategoryDO> tabList;

    private CategoryDO mCurrentCate = new CategoryDO();

    String cityName = "";

    private boolean isLoading = false;
    private boolean isComplete;
    private int page = 0;

    private List<ServiceListOutDo> listData;
    private ServicesAdapter adapter;

    private boolean resetRecommend = false;

    boolean mLocationSuccess = false;

    private boolean isFirstLoading = true;

    private BroadcastReceiver mLocationReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, android.content.Intent intent) {
            LocationDO mNewLocation = SHZApplication.getInstance().getLocationManager().getLocation();
            initLBSInfo(mNewLocation.getCityName());
        }
    };

    private ActivityPopupWindow activityPopupWindow;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            mInflater = inflater;
            rootView = inflater.inflate(R.layout.fragment_home_scroll, container, false);

            listView = (ListView) rootView.findViewById(R.id.listView);

            listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
            footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
            footerMessage = (TextView) listFooter.findViewById(R.id.message);
            footerReload = (Button) listFooter.findViewById(R.id.footerReload);

            listView.addFooterView(listFooter);
            listFooter.setVisibility(View.GONE);

            listHeader = getLayoutInflater(savedInstanceState).inflate(R.layout.fragment_home_header, null);
            initHeadView();
            listView.addHeaderView(listHeader);

            // 在addHeaderView和addFooterView之后进行Bind
            ButterKnife.bind(this, rootView);

            page = 0;
            listData = new ArrayList<ServiceListOutDo>();
            tabList = new ArrayList<CategoryDO>();
            isComplete = false;
            isLoading = false;
            adapter = new ServicesAdapter(getActivity(), listData);
            adViewPageAdapter = new AdViewPageAdapter(getActivity());


            listView.setAdapter(adapter);

//            serviceRefreshButton.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    resetRecommend = true;
//                    refreshServiceList();
//                }
//            });

            avatarLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Helper.sharedHelper().hasToken()) {
                        Router.sharedRouter().open("profile/" + Helper.sharedHelper().getUserId());
                    } else {
                        Router.sharedRouter().open("signin");
                    }
                }
            });

            initListener();
            initLBSInfo(null);
            loadUtil = new LoadUtil(inflater);
            loadCategoryData(true);
        }
        LocalBroadcastManager.getInstance(SHZApplication.getInstance()).registerReceiver(mLocationReceiver,
                new IntentFilter(AMapLocationManager.LOCATION_BROAD_ACTION));


        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        return rootView;
    }


    void initHeadView() {
        homeTopAd = (SimpleDraweeView) listHeader.findViewById(R.id.homeTopAd);
        homeTopAdPlaceHolder = listHeader.findViewById(R.id.homeTopAdPlaceHolder);
        adViewLayout = (ViewGroup) listHeader.findViewById(R.id.adViewLayout);
        adViewPager = (ViewPager) listHeader.findViewById(R.id.adViewpager);
        adViewIndicator = (CirclePageIndicator) listHeader.findViewById(R.id.adViewIndicator);

        categoryViewPager = (ViewPager) listHeader.findViewById(R.id.categoryViewpager);

        categoryIndicator = (CirclePageIndicator) listHeader.findViewById(R.id.categoryIndicator);
        homeBeltAdViewLayout = listHeader.findViewById(R.id.homeBeltAdViewLayout);

        homeBeltAdv = (SimpleDraweeView) listHeader.findViewById(R.id.homeBeltAdv);
        //滚动条
        userAvatar = (ImageSwitcher) listHeader.findViewById(R.id.userAvatar);
        userNick = (TextSwitcher) listHeader.findViewById(R.id.userNickAndContent);
        topSaleLayout = (LinearLayout) listHeader.findViewById(R.id.topSaleLayout);
        topSaleIcon = (SimpleDraweeView) listHeader.findViewById(R.id.topSaleIcon);

        //3个区块
        promotionTrebleView = (PromotionTrebleView) listHeader.findViewById(R.id.promotionTrebleView);

        //4个区块
        promotionGridView = (GridView) listHeader.findViewById(R.id.promotionGridView);

        navTabView = (GridView) listHeader.findViewById(R.id.navTabView);
    }

    private void initListener() {
//        mSwipeRefreshLayout.setVisibility(View.GONE);
//        mSwipeRefreshLayout.setEnabled(false);
        adapter.setOnClickListener(new AttentionListener() {
            @Override
            public void addFollowClick(String userId, int position) {
                addAttention(userId);
            }
        });


        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(false);
                loadCategoryData(true);
                //loadFindWonderData();
            }
        });

        if (null != barcodeScanner) {
            barcodeScanner.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), BarcodeScannerActivity.class);
                    startActivityForResult(intent, Constant.REQUEST_CODE_BARCODE_SCAN);
                }
            });
        }

//        PROMOTION_ICON_SIZE = getResources().getDimensionPixelSize(R.dimen.promotion_icon_size);
        locationLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(getActivity(), PickCityActivity.class);
                startActivityForResult(intent, Constant.REQUEST_CODE_PICK_CITY);
            }
        });

        searchBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle params = new Bundle();
                if (!TextUtils.isEmpty(searchHintStr)) {
                    params.putString("keyword", searchHintStr);
                }
                Router.sharedRouter().open("search_res", params);
            }
        });

        navTabViewTop.setOnItemClickListener(new ItemClickListener());

        navTabView.setOnItemClickListener(new ItemClickListener());

        userAvatar.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                SimpleDraweeView imageView = new SimpleDraweeView(getActivity());
                RoundingParams roundingParams = RoundingParams.asCircle();
                imageView.getHierarchy().setRoundingParams(roundingParams);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);//居中显示
                imageView.setLayoutParams(new ImageSwitcher.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));//定义组件
                return imageView;
            }
        });
        userAvatar.setInAnimation(getActivity(), R.anim.textswitcher_bottom_in);
        userAvatar.setOutAnimation(getActivity(), R.anim.textswitcher_bottom_out);

        userNick.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                FontTextView textView = new FontTextView(getActivity());
                textView.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                        getResources().getDimensionPixelSize(R.dimen.font_size));
                textView.setTextColor(getResources().getColor(R.color.black_a));
                textView.setGravity(Gravity.CENTER);
                textView.setSingleLine(true);
//                    textView.setPadding(1, 1, 1, 1);
                textView.setEllipsize(TextUtils.TruncateAt.END);
                return textView;
            }
        });
        userNick.setInAnimation(getActivity(), R.anim.textswitcher_bottom_in);
        userNick.setOutAnimation(getActivity(), R.anim.textswitcher_bottom_out);

//        cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                refreshServiceList();
//            }
//        });
//        cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                refreshServiceList();
//            }
//        });
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
//                    if ((errorMsgList.size() < 1) && view.getLastVisiblePosition() == view.getCount() - 1) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        loadMoreServiceList();
                    }

                } else {
                    mSwipeRefreshLayout.setEnabled(true);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (listView.getFirstVisiblePosition() >= 1) {
                    navTabViewTop.setVisibility(View.VISIBLE);
                } else {
                    navTabViewTop.setVisibility(View.GONE);
                }

//                //只有推荐tab显示 换一换
//                if (firstVisibleItem + visibleItemCount > 10 && -3 == mCurrentCate.getTabId()) {
//                    serviceRefreshButton.setVisibility(View.VISIBLE);
//                } else {
//                    serviceRefreshButton.setVisibility(View.GONE);
//                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constant.REQUEST_CODE_PICK_CITY) {
            if (resultCode == Activity.RESULT_OK) {
                Bundle extras = data.getExtras();
                String cityName = extras.getString("name");
                locationValue.setText(cityName);
                int selectCity = extras.getInt("code");
                Helper.sharedHelper().setStringUserInfo(Constant.SELECT_CITY_CODE, String.valueOf(selectCity));
                Helper.sharedHelper().setStringUserInfo(Constant.SELECT_CITY_NAME, cityName);
                //切换城市 重新刷列表
                refreshServiceList();
            }
        } else if (requestCode == Constant.REQUEST_CODE_BARCODE_SCAN && resultCode == Activity.RESULT_OK && null != data) {
            String url = data.getStringExtra("result");
            Intent intent = new Intent();
            intent.setClass(getActivity(), WebActivity.class);
            intent.putExtra("url", url);
            startActivity(intent);
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private void loadCategoryData(boolean showLoading) {
        if (showLoading) {
            loadUtil.loadPre(rootLayout, contentLayout);
        }
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();
        String locateCode = location.getCityCode();
        String selectCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
        params.put("cityCode", StrUtil.isEmpty(selectCode) ? locateCode : selectCode);  // 优先用户选择，其次自动定位
        params.put("longitude", String.valueOf(location.getLongitude()));
        params.put("latitude", String.valueOf(location.getLatitude()));
        params.put("channelH5Status", Helper.sharedHelper().getIntUserInfo(Constant.SF_H5_ACTIVITY_STATUS, 1));
        // test
        //params.put("cityCode", "0");
        //params.put("latitude", "30.2880170");
        //params.put("longitude", "120.000145");
        HttpClient.get("2.0/home/categories", params, HomeCategoriesDO.class, new HttpCallback<HomeCategoriesDO>() {
            @Override
            public void onSuccess(HomeCategoriesDO result) {
                if (getActivity() == null || isDetached()) {
                    return;
                }
                mSwipeRefreshLayout.setRefreshing(false);
                loadUtil.loadSuccess(contentLayout);

                loadAdViews(result);
                JSONArray categories = result.getCategories();
                parseCategories(categories);

                homeBlockFindWonder(result.getDiscoveries());
                homeBlockFunc(result.getHomeFunctionAreaList());
                homeBlockOfflineCategory(result.getNiuRenRank(), result.getHomeOfflineCategoryList());

                JSONArray homeBeltAdArray = result.getHomeBeltAdList();
                loadHomeBelt(homeBeltAdArray);

                if (result.getTopSales() != null) {
                    topSaleIcon.setImageURI(Uri.parse(result.getTopSales().getString("icon")));
                    topSales = result.getTopSales().getJSONArray("content");
                    loadTopSalesData();
                }

                JSONArray home3BlockAdList = result.getHome3BlockAdList();
                home3BlockAdList(home3BlockAdList);

                JSONArray homeBlocksAdList = result.getHome4BlockAdList();
                homeBlockAdList(homeBlocksAdList);

//                JSONArray categoryTab = result.getTabs();
//                loadCategoryTabs(categoryTab);
                searchHintStr = result.getPlaceholder();
                searchHint.setText(searchHintStr);

                //加载完成广告 加载宝贝列表
                refreshServiceList();

                if (!TextUtils.isEmpty(result.getImageUrl())) {
                    showH5ActivityPopup(result.getImageUrl(), result.getSkipUrl());
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (getActivity() == null || isDetached()) {
                    return;
                }
                mSwipeRefreshLayout.setRefreshing(false);
                loadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        loadCategoryData(true);
                    }
                });
            }
        });
    }

    Runnable topSaleSwitchRunnable = new Runnable() {
        @Override
        public void run() {
            // handler自带方法实现定时器
            if (topSales == null || topSales.isEmpty()) {
                return;
            }
            runtimes = runtimes % topSales.size();
            com.alibaba.fastjson.JSONObject item = topSales.getJSONObject(runtimes);
            userNick.setText(item.getString("userNick") + "：" + item.getString("text"));
            userAvatar.setImageURI(Uri.parse(item.getString("userAvatar")));

            runtimes++;
            handler.postDelayed(this, TOP_SALE_CHANGE_TIMES);
        }
    };


    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("HomeScreen");

//        EventBus.getDefault().register(this);

        //更新头像
        String userAvatar = Helper.sharedHelper().getStringUserInfo(Constant.USER_AVATAR);
        if (Helper.sharedHelper().hasToken() && !TextUtils.isEmpty(userAvatar)) {
            myAvatar.setImageURI(Uri.parse(userAvatar));
            myProfile.setVisibility(View.GONE);
            myAvatar.setVisibility(View.VISIBLE);
        } else {
            myAvatar.setVisibility(View.GONE);
            myProfile.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("HomeScreen");

//        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onDestroyView() {
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        LocalBroadcastManager.getInstance(SHZApplication.getInstance()).unregisterReceiver(mLocationReceiver);

        EventBus.getDefault().unregister(this);
        super.onDestroyView();
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {
        //解决viewpager和swiperefreshlayout的触摸事件冲突
//        swipeRefreshLayout.setEnabled(state == ViewPager.SCROLL_STATE_IDLE
//                && dragTopLayout.getState() == DragTopLayout.PanelState.EXPANDED);
        mSwipeRefreshLayout.setEnabled(state == ViewPager.SCROLL_STATE_IDLE);
    }

    class ItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            if (position < tabList.size()) {
                mCurrentCate = tabList.get(position);

                for (CategoryDO item : tabList) {
                    if (item.getTabId() == mCurrentCate.getTabId()) {
                        if (item.isSelected()) {
                            return;
                        } else {
                            item.setSelected(true);
                        }
                    } else {
                        item.setSelected(false);
                    }
                }
                homeTabAdapter.notifyDataSetChanged();

                //设置当前tabId
                adapter.setTabId(mCurrentCate.getTabId());

                //如果是推荐
                if (-3 == mCurrentCate.getTabId()) {
                    resetRecommend = true;
                }
                refreshServiceList();


                LogParam param = new LogParam();
                param.setType(LogUtil.TYPE_CUSTOMIZE);
                param.setEid(LogUtil.EVENT_ID_HOME_TAB_CLICK);
                param.setPoid(String.valueOf(position + 1));
                LogUtil.log(param);
            }
        }
    }

    private void refreshServiceList() {
//        cellStatusErrorNetwork.setVisibility(View.GONE);
//        cellStatusErrorServer.setVisibility(View.GONE);

//        showStatusLoading();

//        Log.d("myThisLog: ", title + " | " + tabId + " | " + needPOI);
        listFooter.setVisibility(View.GONE);

        if (mCurrentCate.isNeedPOI() && !checkLocationSetting()) {
//            hideStatusLoading();
            return;
        }

        if (isLoading) {
            return;
        }

        loadUtil.loadPre(rootLayout, contentLayout);

        isLoading = true;
        page = 0;
        isComplete = false;

        listData.clear();

        HttpClient.searchEnv("1.0/home", getParams(page), HomeDO.class, new HttpCallback<HomeDO>() {
            @Override
            public void onSuccess(HomeDO home) {
                isLoading = false;
                loadUtil.loadSuccess(contentLayout);
                mSwipeRefreshLayout.setRefreshing(false);

                if (isFirstLoading) {
                    loadCategoryTabs(home.getTabs());
                    isFirstLoading = false;
                }

                if (CollectionUtil.isEmpty(home.getResult())) {
                    ServiceListOutDo error = new ServiceListOutDo();
                    error.setDesc("没有数据");
                    error.setType(2);
                    listData.add(error);
                } else {
                    listData.addAll(home.getResult());
                }
                adapter.notifyDataSetChanged();

                if (listData.size() < PAGE_SIZE) {
                    isComplete = true;
                    listView.removeFooterView(listFooter);
                }


//                if (home.getUpdateItemCount() > 0 && resetRecommend) {
//                    updateItemCountView.setVisibility(View.VISIBLE);
//                    updateItemCountText.setText(String.format("已更新%s个精品服务", home.getUpdateItemCount()));
//
//                    //顶部提示文案消失
//                    refreshHandler.sendEmptyMessageDelayed(1, TOP_SALE_CHANGE_TIMES);
//
//                    //滚动顶部 tips: 增加header之后 listview position从1开始
//                    listView.setSelection(1);
//
//                    resetRecommend = false;
//                }
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                mSwipeRefreshLayout.setRefreshing(false);
//                hideStatusLoading();

                listData.clear();
                adapter.notifyDataSetChanged();

                loadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
//                        requestSquareData(location);
                        refreshServiceList();
                    }
                });

//                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
//                    cellStatusErrorNetwork.setVisibility(View.VISIBLE);
//                    return;
//                }
//                if (!TextUtils.isEmpty(error.getMessage())) {
//                    textStatusErrorServer.setText(error.getMessage());
//                }
//                cellStatusErrorServer.setVisibility(View.VISIBLE);
            }
        });

    }

    private boolean checkLocationSetting() {
        String locateCode = SHZApplication.getInstance().getLocationManager().getLocation().getCityCode();
        String selectCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
        listData.clear();
        if (Helper.isLocationEnabled(getActivity())) {
            if (!TextUtils.isEmpty(locateCode)) {
                if (!TextUtils.isEmpty(locateCode) || locateCode.equals(selectCode)) {
                    mLocationSuccess = true;
                } else {
                    ServiceListOutDo error = new ServiceListOutDo();
                    error.setDesc("选择城市和定位所在城市不一致，无法显示哦");
                    error.setType(1);
                    listData.add(error);
                    mLocationSuccess = false;
                }
            } else {
                ServiceListOutDo error = new ServiceListOutDo();
                error.setDesc("定位失败，请尝试重新定位");
                error.setType(1);
                listData.add(error);
                mLocationSuccess = false;
                //todo 开始重新定位
            }
        } else {
            ServiceListOutDo error = new ServiceListOutDo();
            error.setDesc("未开启定位，点击设置");
            error.setType(1);
//            error.setNeedSetLocation(true);
            listData.add(error);
            mLocationSuccess = false;
        }
        adapter.notifyDataSetChanged();

        return mLocationSuccess;
    }

    private void loadMoreServiceList() {
        listFooter.setVisibility(View.GONE);

        if (mCurrentCate.isNeedPOI() && !mLocationSuccess) {
            return;
        }

        if (!isLoading && !isComplete) {
            footerMessage.setText("正在加载");
            listFooter.setVisibility(View.VISIBLE);
            footerLoading.setVisibility(View.VISIBLE);
            footerMessage.setVisibility(View.VISIBLE);
            footerReload.setVisibility(View.GONE);
            isLoading = true;
            page++;

            HttpClient.searchEnv("1.0/home", getParams(page), HomeDO.class, new HttpCallback<HomeDO>() {

                @Override
                public void onSuccess(HomeDO home) {

                    listData.addAll(home.getResult());

                    adapter.notifyDataSetChanged();

                    // 其它处理
                    isLoading = false;
                    if (CollectionUtil.isEmpty(home.getResult()) || home.getResult().size() < PAGE_SIZE) {
                        isComplete = true;
                    }
                    listFooter.setVisibility(View.GONE);
                    if (isComplete) {
                        listView.removeFooterView(listFooter);
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    page--;
                    isLoading = false;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);

                    listFooter.setVisibility(View.GONE);
                }
            });
        }
    }

    private JSONObject getParams(int page) {
        JSONObject params;
        try {
            params = new JSONObject();
            LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();
            params.put("longitude", String.valueOf(location.getLongitude()));
            params.put("latitude", String.valueOf(location.getLatitude()));
            String locateCode = location.getCityCode();
            String selectCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
            params.put("cityCode", StrUtil.isEmpty(selectCode) ? locateCode : selectCode);  // 优先用户选择，其次自动定位
            params.put("pageSize", PAGE_SIZE);
            params.put("offset", page * PAGE_SIZE);
            if (Integer.MAX_VALUE != mCurrentCate.getCatId()) {
                params.put("catId", mCurrentCate.getCatId());
            }
            if (Integer.MAX_VALUE != mCurrentCate.getTabId()) {
                params.put("tabId", mCurrentCate.getTabId());
            }
        } catch (Exception e) {
            params = null;
        }

        return params;
    }

//    private void showStatusLoading() {
//        try {
//            cellStatusLoading.setVisibility(View.VISIBLE);
//            loadingAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.loading_animation);
//            ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
//            loadingImage.setBackgroundDrawable(loadingAnimation);
//            loadingAnimation.start();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    private void hideStatusLoading() {
//        try {
//            if (cellStatusLoading != null) {
//                cellStatusLoading.setVisibility(View.GONE);
//                if (loadingAnimation != null) {
//                    loadingAnimation.stop();
//                    loadingAnimation = null;
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    void initLBSInfo(String locateCityName) {

        //定位成功
        String selectCityName = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_NAME);
        String selectCityCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
        if (!TextUtils.isEmpty(selectCityName)) {
            cityName = selectCityName;  // 若之前已手动选择，则默认使用此定位

            //如果选择城市和定位城市不一致，弹出提示用户是否切换
            if (!Helper.sharedHelper().getBooleanUserInfo(Constant.SELECT_CITY_CONFIRMED, false)
                    && SHZApplication.getInstance().getLocationManager().getLocation() != null
                    && !TextUtils.isEmpty(SHZApplication.getInstance().getLocationManager().getLocation().getCityCode())
                    && !selectCityCode.equals(SHZApplication.getInstance().getLocationManager().getLocation().getCityCode())
                    && !TextUtils.isEmpty(SHZApplication.getInstance().getLocationManager().getLocation().getCityName())
                    && !SHZApplication.getInstance().getLocationManager().getLocation().getCityName().equals(selectCityName)) {
                MessageUtils.showDialog(getActivity(), "提示",
                        String.format("您当前选择的城市是%1$s，是否切换为%2$s", selectCityName,
                                SHZApplication.getInstance().getLocationManager().getLocation().getCityName()),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                locationValue.setText(SHZApplication.getInstance().getLocationManager().getLocation().getCityName());
                                Helper.sharedHelper().removeUserInfo(Constant.SELECT_CITY_NAME);
                                Helper.sharedHelper().removeUserInfo(Constant.SELECT_CITY_CODE);
                                refreshServiceList();
                            }
                        }, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //次提示如果取消就不再提示
                                Helper.sharedHelper().setBooleanUserInfo(Constant.SELECT_CITY_CONFIRMED, true);
                            }
                        });
            }
        } else {
            cityName = locateCityName;
            if (TextUtils.isEmpty(cityName)) {
                if (SHZApplication.getInstance().getLocationManager().getLocation() != null) {
                    cityName = SHZApplication.getInstance().getLocationManager().getLocation().getCityName();
                }
            }
        }
        if (TextUtils.isEmpty(cityName)) {
            cityName = "全国";
        }
        locationValue.setText(cityName);
    }

    private void loadAdViews(HomeCategoriesDO result) {
        JSONArray adViews = result.getAdList();
        if (adViews == null || adViews.isEmpty()) {
            adViewLayout.setVisibility(View.GONE);
        } else {
            adViewPageAdapter.setData(adViews);
            adViewPager.setAdapter(adViewPageAdapter);
            adViewIndicator.setViewPager(adViewPager);
            adViewLayout.setVisibility(View.VISIBLE);
            adViewIndicator.setOnPageChangeListener(this);
        }

        JSONObject topAdJson = result.getHomeTopAd();
        if (null != topAdJson && !TextUtils.isEmpty(topAdJson.getString("pic"))) {
            final String linkUrl = topAdJson.getString("url");
            ViewGroup.LayoutParams layoutParams = homeTopAd.getLayoutParams();
            layoutParams.height = (int) (getResources().getDisplayMetrics().widthPixels / 2.4);
            homeTopAd.setImageURI(Uri.parse(topAdJson.getString("pic")));
            homeTopAd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", linkUrl);
                    Router.sharedRouter().open("web", bundle);
                }
            });
            homeTopAd.setVisibility(View.VISIBLE);
            homeTopAdPlaceHolder.setVisibility(View.GONE);
        } else {
            homeTopAd.setVisibility(View.GONE);
            homeTopAdPlaceHolder.setVisibility(View.VISIBLE);
        }
    }


    private void parseCategories(JSONArray data) {
        categories.clear();
        if (data == null || data.isEmpty()) {
            return;
        }
        for (int i = 0; i < data.size(); i++) {
            com.alibaba.fastjson.JSONObject catJson = data.getJSONObject(i);
            CategoryDO category = new CategoryDO();
            category.setCatName(catJson.getString("title"));
            category.setIconUrl(catJson.getString("icon"));
            category.setLink(catJson.getString("url"));
            if (catJson.containsKey("cid")) {
                category.setCatId(catJson.getInteger("cid"));
            }
            categories.add(category);
        }
        if (!categories.isEmpty()) {
            categoryItemPageAdapter = new CategoryItemPageAdapter(getActivity());
            categoryItemPageAdapter.setCategoryList(categories);
            categoryViewPager.setAdapter(categoryItemPageAdapter);
            categoryIndicator.setViewPager(categoryViewPager);
            categoryIndicator.notifyDataSetChanged();
        }

        categoryIndicator.setOnPageChangeListener(this);
    }

    private void loadHomeBelt(JSONArray data) {
        if (data == null || data.isEmpty()) {
            homeBeltAdViewLayout.setVisibility(View.GONE);
            return;
        }

        homeBeltAdViewLayout.setVisibility(View.VISIBLE);
        if (data.size() > 0) {
            com.alibaba.fastjson.JSONObject homBeltData = data.getJSONObject(0);
            final String linkUrl = homBeltData.getString("url");
            homeBeltAdv.setImageURI(Uri.parse(homBeltData.getString("pic")));
            homeBeltAdv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", linkUrl);
                    Router.sharedRouter().open("web", bundle);
                }
            });
        }
    }

    //空格特惠
    private void loadTopSalesData() {
        handler.removeCallbacks(topSaleSwitchRunnable);
        if (topSales == null || topSales.isEmpty()) {
            topSaleLayout.setVisibility(View.GONE);
            return;
        }
        topSaleLayout.setVisibility(View.VISIBLE);
        topSaleLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", topSales.getJSONObject((runtimes - 1) < 0 ? 0 : runtimes - 1).getString("url"));
                Router.sharedRouter().open("web", bundle);
            }
        });
        if (runtimes < topSales.size()) {
            com.alibaba.fastjson.JSONObject item = topSales.getJSONObject(runtimes);
            userNick.setCurrentText(item.getString("userNick") + "：" + item.getString("title") + "" + item.getString("text"));
            userAvatar.setImageURI(Uri.parse(item.getString("userAvatar")));
        }

        runtimes++;
        handler.postDelayed(topSaleSwitchRunnable, TOP_SALE_CHANGE_TIMES);
    }

    /**
     * 功能区块数据渲染
     */
    private void homeBlockFunc(JSONArray data) {
        if (data == null || data.size() == 0) {
            mFuncBlockLayout.setVisibility(View.GONE);
            return;
        }

        mFuncBlockLayout.setVisibility(View.VISIBLE);
        int width = getResources().getDisplayMetrics().widthPixels;
        int margin = ConvertToUtils.dip2px(getActivity(), 5);
        int w = width / 4 - 2 * margin;

        for (int i = 0; i < data.size(); i++) {
            JSONObject json = (JSONObject) data.get(i);
            final String link = json.getString("url");
            String pic = json.getString("pic");
            if (!TextUtils.isEmpty(pic)) {
                SimpleDraweeView drawee = (SimpleDraweeView) mInflater.inflate(R.layout.view_home_item_func,
                        mFuncBlockLayout, false);
                drawee.setAspectRatio(246 / 225f);
                LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) drawee.getLayoutParams();
                lp.width = w;
                lp.height = LinearLayout.LayoutParams.WRAP_CONTENT;
                lp.leftMargin = margin;
                lp.rightMargin = margin;

                drawee.setImageURI(Uri.parse(pic));
                drawee.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", link);
                        Router.sharedRouter().open("web", bundle);
                    }
                });
                mFuncBlockLayout.addView(drawee, lp);
            }
        }

    }

    private void renderDrawee(SimpleDraweeView drawee, String pic, final String url) {
        if (!TextUtils.isEmpty(pic)) {
            drawee.setImageURI(Uri.parse(pic));
        }
        if (!TextUtils.isEmpty(url)) {
            drawee.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", url);
                    Router.sharedRouter().open("web", bundle);
                }
            });
        }
    }

    /**
     * 线下类目数据渲染
     */
    private void homeBlockOfflineCategory(HomeCategoriesDO.NiuRenRank topRank, JSONArray category) {
        mOfflineCategoryLayout.setVisibility(View.GONE);
        mVocationBannerLayout.setVisibility(View.GONE);

        mVocationSplitLine.setVisibility(View.GONE);
        mVocationRecyclerView.setVisibility(View.GONE);
        // 牛人榜横幅广告
        if (topRank != null && topRank.getNiuRenBanners() != null
                && topRank.getNiuRenBanners().size() > 0) {
            final HomeCategoriesDO.NiuRenBanner banner = topRank.getNiuRenBanners().get(0);
            renderDrawee(mVocationBannerDrawee, banner.getPic(), banner.getUrl());
            if (!TextUtils.isEmpty(banner.getUrl())) {
                mVocationBannerLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", banner.getUrl());
                        Router.sharedRouter().open("web", bundle);
                    }
                });
            }
            mVocationBannerTitleTv.setText(banner.getTitle());
            mVocationBannerLayout.setVisibility(View.VISIBLE);
        } else {
            mVocationBannerDrawee.setImageURI(ConvertToUtils.resId2Uri(R.mipmap.vocation_banner));
        }

        mRankDrawee1.setVisibility(View.GONE);
        mRankDrawee2.setVisibility(View.GONE);
        mRankDrawee3.setVisibility(View.GONE);
        // 牛人榜
        if (topRank != null && topRank.getNiuRenList() != null && topRank.getNiuRenList().size() > 0) {
            mOfflineCategoryLayout.setVisibility(View.VISIBLE);
            mVocationBannerLayout.setVisibility(View.VISIBLE);

            mRankDrawee1.setVisibility(View.VISIBLE);
            HomeCategoriesDO.User niuRen = topRank.getNiuRenList().get(0);
            //renderDrawee(mRankDrawee1, niuRen.getPicUrl(), null);
            String url = ImgUtil.getCDNUrlWithHeight(niuRen.getPicUrl(), ConvertToUtils.dip2px(getActivity(), 25));
            renderDrawee(mRankDrawee1, url, null);

            if (topRank.getNiuRenList().size() >= 2) {
                niuRen = topRank.getNiuRenList().get(1);
                //renderDrawee(mRankDrawee2, niuRen.getPicUrl(), null);
                url = ImgUtil.getCDNUrlWithHeight(niuRen.getPicUrl(), ConvertToUtils.dip2px(getActivity(), 25));
                renderDrawee(mRankDrawee2, url, null);
                mRankDrawee2.setVisibility(View.VISIBLE);
            }

            if (topRank.getNiuRenList().size() >= 3) {
                niuRen = topRank.getNiuRenList().get(2);
                //renderDrawee(mRankDrawee3, niuRen.getPicUrl(), null);
                url = ImgUtil.getCDNUrlWithHeight(niuRen.getPicUrl(), ConvertToUtils.dip2px(getActivity(), 25));
                renderDrawee(mRankDrawee3, url, null);
                mRankDrawee3.setVisibility(View.VISIBLE);
            }
        }

        // 线下类目列表
        if (category != null && category.size() > 0) {
            LinearLayoutManager llManager = new LinearLayoutManager(getActivity());
            llManager.setOrientation(LinearLayoutManager.HORIZONTAL);
            mVocationRecyclerView.setLayoutManager(llManager);
            HomeVocationAdapter vocationAdapter = new HomeVocationAdapter(getActivity(), category);
            mVocationRecyclerView.setAdapter(vocationAdapter);
            mVocationSplitLine.setVisibility(View.VISIBLE);
            mVocationRecyclerView.setVisibility(View.VISIBLE);
            mOfflineCategoryLayout.setVisibility(View.VISIBLE);
        }
    }

    /*
     * 发现精彩数据渲染
     */
    private void homeBlockFindWonder(HomeDiscoveriesDO data) {

        mDiscoverySplitLine.setVisibility(View.GONE);
        mDiscoveryBannerLayout.setVisibility(View.GONE);
        mSquareSplitLine.setVisibility(View.GONE);
        mDiscoverySquareLayout.setVisibility(View.GONE);
        mDiscoveriesListSplitLine.setVisibility(View.GONE);
        mDiscoveriesListView.setVisibility(View.GONE);
        if (data == null) return;

        // 发现精彩,横幅广告
        List<HomeDiscoveriesDO.HomeDiscoviesBlockAd> ads = data.getHomeDiscoviesBlockAd();
        if (ads != null && ads.size() > 0) {
            final HomeDiscoveriesDO.HomeDiscoviesBlockAd ad = ads.get(0);
            mDiscoveryBannerTitleTv.setText(ad.getTitle());
            ImgUtil.setControllerListener(mDiscoveriesBannerDrawee, ad.getPic(),
                    ConvertToUtils.dip2px(getActivity(), 50), getActivity());
            //mDiscoveriesBannerDrawee.setImageURI(Uri.parse(ad.getPic()));
            mDiscoveriesBannerDrawee.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", ad.getUrl());
                    Router.sharedRouter().open("web", bundle);
                }
            });
            mDiscoveriesBannerDrawee.setVisibility(View.VISIBLE);
            mDiscoverySplitLine.setVisibility(View.VISIBLE);
            mDiscoveryBannerLayout.setVisibility(View.VISIBLE);
        } else {
            mDiscoveriesBannerDrawee.setVisibility(View.GONE);
        }

        // 格子
        final HomeDiscoveriesDO.Gezi gezi = data.getGezi();
        if (gezi != null) {
            mDiscoverySplitLine.setVisibility(View.VISIBLE);
            mDiscoveryBannerLayout.setVisibility(View.VISIBLE);
            mSquareSplitLine.setVisibility(View.VISIBLE);
            mDiscoverySquareLayout.setVisibility(View.VISIBLE);
            // 格子数据渲染
            if (!TextUtils.isEmpty(gezi.getPicUrl())) {
                mGeziImageDrawee.setImageURI(Uri.parse(gezi.getPicUrl()));
            }
            mGeziSubjectTv.setText("[格子]" + gezi.getName());
            mGeziTitleTv.setText(String.format("已有%d人入驻!", gezi.getUserCount()));
            mGeziPeopleNumTv.setText("牛人数: " + gezi.getSellerCount());
            mGeziVocationNum.setText("牛人职业: " + gezi.getOccupationCount());
            if (!TextUtils.isEmpty(gezi.getId())) {
                mDiscoverySquareLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Router.sharedRouter().open("squareindex/"+gezi.getId());
                    }
                });
            }

            // 职业标签,最多4个
            TextView[] tagTvs = {
                    mGeziTagTv1,
                    mGeziTagTv2,
                    mGeziTagTv3,
                    mGeziTagTv4
            };
            for (int i = 0; i < 4; i++) {
                TextView tv = tagTvs[i];
                tv.setVisibility(View.GONE);
            }
            List<HomeDiscoveriesDO.Occupation> occupations = gezi.getOccupationList();
            if (occupations != null && occupations.size() > 0) {
                for (int i = 0; i < 4 && i < occupations.size(); i++) {
                    HomeDiscoveriesDO.Occupation o = occupations.get(i);
                    TextView tv = tagTvs[i];
                    tv.setText(o.getOccupationName());
                    tv.setVisibility(View.VISIBLE);
                }
            }

            // 距离
            long distance = (long)(gezi.getDistance()*1000);
            String distanceStr;
            if (distance > 1000) {
                distanceStr = String.format("%d.%d公里", distance / 1000, (distance % 1000) / 100);
            } else if (distance >= 0) {
                distanceStr = String.format("[%d米]", distance);
            } else {
                distanceStr = "";
            }
            mGeziDistanceTv.setText(distanceStr);

            mGeziUserAddTimeTv.setText("");
            mGeziUserDescTv.setText("");
            if (gezi.getFeedList() != null && gezi.getFeedList().size() > 0) {
                HomeDiscoveriesDO.Feed feed = gezi.getFeedList().get(0);
                if (feed.getUser() != null) {
                    HomeDiscoveriesDO.User user = feed.getUser();
                    String url = ImgUtil.getCDNUrlWithHeight(user.getPicUrl(), ConvertToUtils.dip2px(getActivity(), 25));
                    if (!TextUtils.isEmpty(url)) {
                        mGeziUserAvatar.setImageURI(Uri.parse(url));
                    }
                    if ("woman".equals(user.getGender()) || "F".equals(user.getGender())) {
                        mGeziUserGenderTv.setText(R.string.icon_gender_f);
                        mGeziUserGenderTv.setBackgroundResource(R.drawable.bg_circle_profile_red);
                    } else {
                        mGeziUserGenderTv.setText(R.string.icon_gender_m);
                        mGeziUserGenderTv.setBackgroundResource(R.drawable.bg_circle_profile_brand_i);
                    }
                }
                long duration = System.currentTimeMillis() / 1000 - feed.getCreateTime() / 1000;
                String time;
                if (duration > 86400) {
                    time = String.format("%d天前", duration / 86400);
                } else if (duration > 3600) {
                    time = String.format("%d小时前", duration / 3600);
                } else if (duration > 60) {
                    time = String.format("%d分钟前", duration / 60);
                } else {
                    time = "刚刚";
                }
                mGeziUserAddTimeTv.setText(time);
                mGeziUserDescTv.setText(feed.getContent());
            }
        }

        // 主题广告
        final List<HomeDiscoveriesDO.HomeThemeBlockAds> themeAds = data.getHomeThemeBlockAds();

        if (themeAds != null && themeAds.size() > 0) {
            mDiscoverySplitLine.setVisibility(View.VISIBLE);
            mDiscoveryBannerLayout.setVisibility(View.VISIBLE);
            mDiscoveriesListSplitLine.setVisibility(View.VISIBLE);
            mDiscoveriesListView.setVisibility(View.VISIBLE);

            HomeFindWonderAdapter findAdapter = new HomeFindWonderAdapter(getActivity(), themeAds);
            mDiscoveriesListView.setAdapter(findAdapter);
            mDiscoveriesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    HomeDiscoveriesDO.Custom custom = themeAds.get(position).getCustom();
                    String url = custom.getLink();
                    if (!TextUtils.isEmpty(url)) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", url);
                        Router.sharedRouter().open("web", bundle);
                    }
                }
            });
        }
    }

    private void home3BlockAdList(JSONArray data) {
        if (data == null || data.size() < 3) {
            promotionTrebleView.setVisibility(View.GONE);
            return;
        }
        promotionTrebleView.setVisibility(View.VISIBLE);
        for (int i = 0; i < 3; i++) {
            final JSONObject item = data.getJSONObject(i);
            final SimpleDraweeView image = promotionTrebleView.get(i);
            renderBlockPicture(image, item.getString("pic"));

            final String url = item.getString("url");
            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", url);
                    Router.sharedRouter().open("web", bundle);
                }
            });
        }
        promotionTrebleView.requestLayout();
    }

    private void renderBlockPicture(SimpleDraweeView imageView, String picUrl) {
        if (imageView == null) return;
        if (TextUtils.isEmpty(picUrl)) {
            Uri img = new Uri.Builder().scheme(UriUtil.LOCAL_RESOURCE_SCHEME)
                    .path(String.valueOf(R.drawable.avatar)).build();
            imageView.setImageURI(img);
        } else {
            imageView.setImageURI(Uri.parse(picUrl));
        }
    }

    private void homeBlockAdList(JSONArray data) {
        try {
            if (data == null || data.isEmpty()) {
                promotionGridView.setVisibility(View.GONE);
                return;
            }
            HomeBlockAdapter homeBlockAdapter = new HomeBlockAdapter(getActivity(), data);
            promotionGridView.setAdapter(homeBlockAdapter);
            promotionGridView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void loadCategoryTabs(List<CategoryDO> cateList) {
        if (CollectionUtil.isEmpty(cateList)) {
            return;
        }
        tabList.clear();
//        for (int i = 0; i < cateList.size(); i++) {
//            com.alibaba.fastjson.JSONObject catJson = data.getJSONObject(i);
//            CategoryDO category = new CategoryDO();
//            category.setCatName(catJson.getString("title"));
//            category.setTabId(catJson.getInteger("tabId"));
//            category.setNeedPOI(catJson.getBoolean("needPOI"));
        //默认第一个选中
//            if (i == 0) {
//                category.setIsClicked(true);
//            } else {
//                category.setIsClicked(false);
//            }
//            tabList.add(category);
//        }
        tabList.addAll(cateList);

        homeTabAdapter = new HomeTabAdapter(getActivity(), tabList);

        navTabViewTop.setNumColumns(tabList.size());
//        navTabViewTop.setPadding(getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin)
//                , 0, getResources().getDisplayMetrics().widthPixels / tabList.size(), 0);
        navTabView.setNumColumns(tabList.size());
//        navTabView.setPadding(getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin)
//                , 0, getResources().getDisplayMetrics().widthPixels / tabList.size(), 0);
        navTabViewTop.setAdapter(homeTabAdapter);
        navTabView.setAdapter(homeTabAdapter);
        homeTabAdapter.notifyDataSetChanged();

        //设置“推荐” 默认tab
        mCurrentCate = tabList.get(0);
    }

    private void showH5ActivityPopup(String imageUrl, String link) {
        try {
            if (activityPopupWindow != null && activityPopupWindow.isShowing()) {
                activityPopupWindow.dismiss();
            }
            activityPopupWindow = new ActivityPopupWindow(getActivity(), imageUrl, link);
            activityPopupWindow.showAtLocation(rootLayout, Gravity.CENTER, 0, 0);
            Helper.sharedHelper().setIntUserInfo(Constant.SF_H5_ACTIVITY_STATUS, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    public void onEvent(HomeUpdateEvent event) {
//        if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isLoading) {
////            refreshServiceList();
//            if (event.position >= -1 && event.position < listData.size()) {
//                listData.remove(event.position);
//                adapter.notifyDataSetChanged();
//            }
//        }
//    }

    public void onEvent(BaseEvent mEvent) {
        if (mEvent instanceof HomeUpdateEvent) {
            HomeUpdateEvent event = (HomeUpdateEvent) mEvent;
            if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isLoading) {
                if (event.position >= -1 && event.position < listData.size()) {
                    listData.remove(event.position);
                    adapter.notifyDataSetChanged();
                }
            }
        } else if (mEvent instanceof AttentionUserEvent) {
            AttentionUserEvent event = (AttentionUserEvent) mEvent;
            if (MsgTypeEnum.TYPE_ATTENTION_USER == event.eventType && !isLoading && CollectionUtil.isNotEmpty(listData)) {
                //全局关注或取消关注事件 更新
                for (ServiceListOutDo service : listData) {
                    if (service.getUser() != null && service.getUser().getUserId().equals(event.userId)) {
                        service.getUser().setFocused(true);
                    }
                }
                adapter.notifyDataSetChanged();
            }
        }
    }

    //关注人
    private void addAttention(final String userId) {
        RequestDynamic.addAttention(userId, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                AttentionUserEvent event = new AttentionUserEvent();
                event.userId = userId;
                event.isAttention = true;
                EventBus.getDefault().post(event);
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

}
