package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.LiveBindServiceListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.util.LoadUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujian on 16/2/16.
 */
public class LiveBindServiceActivity extends BaseActivity {
    private final static int PAGE_SIZE = 20;

    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.emptyView)
    View emptyView;
    @Bind(R.id.serviceList)
    ListView serviceList;
    @Bind(R.id.rootView)
    ViewGroup rootView;

    private LoadUtil mLoadUtil;
    private LiveBindServiceListAdapter liveBindServiceListAdapter;
    private List<ServiceItem> items;
    private boolean isLoading;
    private int page;
    private boolean isComplete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_bind_service);

        ButterKnife.bind(this);
        initActionBar(R.string.title_activity_pick_service, true, true);

        mButtonRight.setText(R.string.confirm);

        mLoadUtil = new LoadUtil(LayoutInflater.from(this));
        items = new ArrayList<>();
        liveBindServiceListAdapter = new LiveBindServiceListAdapter(this, items);
        serviceList.setAdapter(liveBindServiceListAdapter);
        initListener();
        initData(true);
    }

    private void initListener() {
        serviceList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        initData(false);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
            }
        });
        serviceList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (liveBindServiceListAdapter.getSelectPos() == position)
                    return;
                liveBindServiceListAdapter.setSelectPos(position);
                liveBindServiceListAdapter.notifyDataSetChanged();
            }
        });
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                initData(true);
            }
        });

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sureSelect();
            }
        });

    }

    private void initData(final boolean refresh) {
        if (isLoading)
            return;
        if (refresh) {
            page = 0;
            isComplete = false;
            mLoadUtil.loadPre(rootView, swipeRefreshLayout);
        } else {
            if (isComplete) {
                isLoading = false;
                return;
            }
            page++;
        }

        JSONObject params = new JSONObject();
        params.put("userId", Helper.sharedHelper().getUserId());
        params.put("pageSize", PAGE_SIZE);
        params.put("offset", page * PAGE_SIZE);
        HttpClient.get("2.0/user/getItemList", params, ServiceItem.class, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                mLoadUtil.hideStatusLoading();
                List<ServiceItem> services = (List<ServiceItem>) obj;

                if (refresh)
                    items.clear();
                items.addAll(services);
                if (items.size() == 0) {
                    swipeRefreshLayout.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                    liveBindServiceListAdapter.setSelectPos(-1);
                    liveBindServiceListAdapter.notifyDataSetChanged();
                }
                if (services.size() < PAGE_SIZE)
                    isComplete = true;
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                if (!refresh)
                    page--;
                mLoadUtil.loadFail(error, rootView, LiveBindServiceActivity.this, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initData(true);
                    }
                });
            }
        });
    }

    public void sureSelect() {
        Intent intent = new Intent();
        Bundle params = liveBindServiceListAdapter.getSelectItemData();

        if (params != null) {
            intent.putExtra("params", params);
        } else {
            MessageUtils.showToast("你还没有选择服务哦");
        }
        setResult(RESULT_OK, intent);
        finish();
    }
}
