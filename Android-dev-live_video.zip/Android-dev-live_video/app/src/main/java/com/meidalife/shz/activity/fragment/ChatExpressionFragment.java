package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.BasePageAdapter;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.viewpagerindicator.CirclePageIndicator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by fufeng on 15/11/20.
 */
public class ChatExpressionFragment extends Fragment {
    private JSONArray metaList;

    @Bind(R.id.chatExpressionViewPager)
    ViewPager chatExpressionViewPager;
    @Bind(R.id.chatExpressionIndicator)
    CirclePageIndicator chatExpressionIndicator;

    ExpressionPageAdapter expressionPageAdapter;
    ExpressionAdapter expressionAdapter;
    private View rootView;
    private ChatExpressionFragment chatExpressionFragment;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_chat_expression, container, false);
            ButterKnife.bind(this, rootView);
            initFaceMeta();

            expressionPageAdapter = new ExpressionPageAdapter(getActivity());
            chatExpressionViewPager.setAdapter(expressionPageAdapter);
            chatExpressionIndicator.setViewPager(chatExpressionViewPager);
        }
        return rootView;
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    private void initFaceMeta() {
        try {
            InputStream in = SHZApplication.getInstance().getAssets().open("faces/official/meta.json");
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line = null;
            StringBuilder content = new StringBuilder();
            while ((line = br.readLine()) != null) {
                content.append(line);
            }
            metaList = JSONArray.parseArray(content.toString());
        } catch (Exception e) {
            Log.e(ChatExpressionFragment.class.getName(), "init face meta fail", e);
        }
    }

    public class ExpressionPageAdapter extends BasePageAdapter {
        private Context context;
        LayoutInflater inflater;
        private final int PAGE_SIZE = 24;

        public ExpressionPageAdapter(Context context) {
            this.context = context;
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View newView(int position) {
            View root = inflater.inflate(R.layout.message_face_list, null);
            GridView chatFaceGridView = (GridView) root.findViewById(R.id.chatFaceGridView);
            int start = position * PAGE_SIZE;
            int end = Math.min(start + PAGE_SIZE, metaList.size());
            ExpressionAdapter faceImgAdapter = new ExpressionAdapter(context, start, end);
            chatFaceGridView.setAdapter(faceImgAdapter);
            return root;
        }

        @Override
        public int getCount() {
            int offset = metaList.size() % PAGE_SIZE;
            return (offset > 0 ? metaList.size() / PAGE_SIZE + 1 : metaList.size() / PAGE_SIZE);
        }
    }


    public class ExpressionAdapter extends BaseAdapter {
        private LayoutInflater inflater;
        private Context context;
        private int start;
        private int end;

        public ExpressionAdapter(Context context, int start, int end) {
            this.context = context;
            this.start = start;
            this.end = end;
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return end - start;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (convertView == null || convertView.getTag() == null) {
                convertView = inflater.inflate(R.layout.item_chat_expression, parent, false);
                viewHolder = new ViewHolder();
                viewHolder.expressionImage = (SimpleDraweeView) convertView.findViewById(R.id.expression);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            int index = start + position;
            final JSONObject obj = metaList.getJSONObject(index);
            viewHolder.expressionImage.setImageURI(Uri.parse("asset:///faces/official/" + obj.getString("file")));
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String expressionName = obj.getString("name");
                    ChatExpressionEvent event = new ChatExpressionEvent(MsgTypeEnum.TYPE_CHAT_EXPRESSION);
                    event.expressionName = expressionName;

                    EventBus.getDefault().post(event);
                }
            });
            return convertView;
        }
    }

    public static class ViewHolder {
        SimpleDraweeView expressionImage;
    }

    public class ChatExpressionEvent extends BaseEvent {
        ChatExpressionEvent(MsgTypeEnum type) {
            super(type);
        }

        public String expressionName;
    }
}
