package com.meidalife.shz.adapter;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.manager.LiveManager;
import com.meidalife.shz.rest.model.TencentImMsgDO;

import java.util.List;

import static com.meidalife.shz.R.drawable.bg_live_msg_item;

/**
 * Created by liujian on 16/2/19.
 */
public class LiveChatListAdapter extends BaseAdapter{

    private List<TencentImMsgDO> items;
    private LayoutInflater mInflater;
    private Context context;
    private ChatHelper mChatHelper;
    private String mHostId;
    private boolean mHost;
    private int mHostColor, mUserColor;

    public LiveChatListAdapter(Context context, boolean isHost, String hostId, List<TencentImMsgDO> items) {
        mHostId = hostId;
        mHost = isHost;
        this.items = items;
        this.context = context;
        this.mInflater = LayoutInflater.from(context);
        this.mChatHelper = ChatHelper.getInstance();
        mHostColor = context.getResources().getColor(R.color.brand_b);
        mUserColor = context.getResources().getColor(R.color.brand);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.item_live_chat_list,parent,false);
            holder = new ViewHolder();
            holder.chatBg = (LinearLayout)convertView.findViewById(R.id.chatBg);
            holder.headPic = (SimpleDraweeView)convertView.findViewById(R.id.headPic);
            holder.rewardIcon = (ImageView)convertView.findViewById(R.id.rewardIcon);
            holder.nickName = (TextView)convertView.findViewById(R.id.nickName);
            holder.chatText = (TextView)convertView.findViewById(R.id.chatText);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder)convertView.getTag();
        }
        TencentImMsgDO item = items.get(position);
        holder.rewardIcon.setVisibility(View.GONE);

        int specColor = mHost ? mHostColor : mUserColor;
        int textColor = mHost ? context.getResources().getColor(R.color.brand_c) : Color.WHITE;
        int bgResId = R.drawable.bg_live_msg_item;
        if (mHost) bgResId = R.drawable.bg_live_msg_host_item;

        // 非留言情况处理
        if (item.getType() != LiveManager.TYPE_MSG_TXT) {
            holder.nickName.setShadowLayer(1f, 0, 1f, 0x50000000);
            holder.chatText.setShadowLayer(1f, 0, 1f, 0x50000000);
            holder.chatBg.setBackgroundColor(0x00000000);
            specColor = mUserColor;
            textColor = Color.WHITE;
        }

        holder.chatText.setTextColor(textColor);
        if (item.getType() == LiveManager.TYPE_MSG_USER_IN) {
            holder.chatText.setText("进入房间");
        } else if (item.getType() == LiveManager.TYPE_MSG_REWARD) {
            holder.rewardIcon.setVisibility(View.VISIBLE);
            TencentImMsgDO.Content content = item.getContent();
            String text = String.format("打赏%s元: %s", content.getAmount(), content.getAmountDesc());
            SpannableString ss = new SpannableString(text);
            ss.setSpan(new ForegroundColorSpan(specColor), 2, 2 + content.getAmount().length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            holder.chatText.setText(ss);
        } else if (item.getType() == LiveManager.TYPE_MSG_TXT) {
            holder.chatText.setText(mChatHelper.getExpressionSpanText(item.getContent().getText(), 20));
            holder.chatBg.setBackgroundResource(bgResId);
        }

        holder.nickName.setTextColor(specColor);
        if (Helper.sharedHelper().getUserId().equals(item.getSender().getUserId())) {
            holder.nickName.setText("我：");
        } else {
            if (item.getSender().getUserId().equals(mHostId)) {
                holder.nickName.setText(item.getSender().getUserNick() + "：");
            } else {
                holder.nickName.setText(item.getSender().getUserNick() + "：");
            }
        }

        if (item.getSender().getUserId().equals(mHostId)) {
            holder.headPic.setImageURI(Uri.parse(item.getSender().getUserAvatar()));
            holder.headPic.setVisibility(View.VISIBLE);
        } else {
            holder.headPic.setVisibility(View.GONE);
        }

        return convertView;
    }

    class ViewHolder{
        LinearLayout chatBg;
        SimpleDraweeView headPic;
        ImageView rewardIcon;
        TextView nickName;
        TextView chatText;
    }
}
