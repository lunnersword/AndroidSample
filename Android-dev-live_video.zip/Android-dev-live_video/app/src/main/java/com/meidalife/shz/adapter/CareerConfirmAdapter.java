package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CareerDo;
import com.meidalife.shz.util.ImgUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/4/22.
 */
public class CareerConfirmAdapter extends BaseRecycleViewAdapter {
    Context mContext;
    List<CareerDo> skillsDoList = new ArrayList<>();

    public CareerConfirmAdapter(Context context, List<CareerDo> skillsDoList) {
        super(context);
        setSkillsDoList(skillsDoList);
        mContext = context;
    }

    public void setSkillsDoList(List<CareerDo> skillsDoList) {
        this.skillsDoList = skillsDoList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateContentViewHolder(ViewGroup parent, int viewType) {
        return new CareerViewHolder(inflater.inflate(R.layout.item_career_confirm, parent, false));
    }

    @Override
    public void onBindContentViewHolder(RecyclerView.ViewHolder holder, int position) {
        CareerDo skillsDo = skillsDoList.get(position);
        CareerViewHolder careerViewHolder = (CareerViewHolder) holder;

        careerViewHolder.careerTitle.setText(skillsDo.getName());
        if (!TextUtils.isEmpty(skillsDo.getLevelPic())) {
            careerViewHolder.levelIcon.setImageURI(Uri.parse(skillsDo.getLevelPic()));
        }

        careerViewHolder.levelTitle.setText(skillsDo.getTitle());
        StringBuffer skillStringBuffer = new StringBuffer();

        for (int i = 0; i < skillsDo.getSkills().size(); i++) {
            CareerDo.SkillDo skillDo = skillsDo.getSkills().get(i);
            skillStringBuffer.append(skillDo.getName());
            if (i < skillsDo.getSkills().size() - 1) {
                skillStringBuffer.append("、");
            }
        }
        careerViewHolder.skillDesc.setText(skillStringBuffer.toString());
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {
        //String name = userJson == null ? null : userJson.getString("userName");
        //String userAvatar = userJson == null ? null : userJson.getString("userAvatar");

        //本地取昵称
        ((TextView) holder.itemView.findViewById(R.id.userName))
                .setText(Helper.sharedHelper().getStringUserInfo(Constant.USER_NICK));
        //本地取头像
        String avatarUrl = Helper.sharedHelper().getStringUserInfo(Constant.USER_AVATAR);
        String cdnUrl = ImgUtil.getCDNUrlWithWidth(avatarUrl,
                mContext.getResources().getDimensionPixelSize(R.dimen.career_avatar_size));
        ((SimpleDraweeView) holder.itemView.findViewById(R.id.careerAvatar))
                .setImageURI(Uri.parse(cdnUrl));
    }

    @Override
    public void onBindFooterViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getContentItemCount() {
        return skillsDoList.size();
    }

    class CareerViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.careerTitle)
        TextView careerTitle;
        @Bind(R.id.levelIcon)
        SimpleDraweeView levelIcon;
        @Bind(R.id.levelTitle)
        TextView levelTitle;
        @Bind(R.id.skillDesc)
        TextView skillDesc;

        public CareerViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
