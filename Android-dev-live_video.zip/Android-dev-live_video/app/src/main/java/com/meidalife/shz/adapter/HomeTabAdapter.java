package com.meidalife.shz.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CategoryDO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ConvertToUtils;

import java.util.ArrayList;


/**
 */
public class HomeTabAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private ArrayList<CategoryDO> tabList;
    int itemWidth;
    Context mContext;

    public HomeTabAdapter(Context context, ArrayList<CategoryDO> tabList) {
        this.mContext = context;
        this.mInflater = (LayoutInflater) context.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
        this.tabList = tabList;

        Activity activity = (Activity) mContext;
        Display display = activity.getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        itemWidth = size.x;
        if (CollectionUtil.isNotEmpty(tabList)) {
//            itemWidth -= Helper.convertDpToPixel(10, mContext) * (tabList.size() - 1);
            itemWidth = itemWidth / tabList.size();
        }
    }

    @Override
    public int getCount() {
        return tabList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        CategoryDO cate = tabList.get(position);
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_home_tab_category, parent, false);
            holder = new ViewHolder();
            holder.filterTab = (TextView) convertView.findViewById(R.id.filterTab);
            holder.isSelect = convertView.findViewById(R.id.isSelect);

            convertView.setLayoutParams(new GridView.LayoutParams(itemWidth, ConvertToUtils.dip2px(mContext, 44)));

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.filterTab.setText(cate.getTabName());
        if (cate.isSelected()) {
            holder.isSelect.setVisibility(View.VISIBLE);
        } else {
            holder.isSelect.setVisibility(View.INVISIBLE);
        }

        return convertView;
    }

    static class ViewHolder {
        TextView filterTab;
        View isSelect;
    }

}
