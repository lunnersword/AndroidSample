package com.meidalife.shz.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ServiceListShowAdapter;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.model.ServiceListOutDo;
import com.meidalife.shz.rest.request.RequestService;
import com.meidalife.shz.util.LoadUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 他发布的服务
 */
public class ServiceListShowActivity extends BaseActivity {

    private ViewGroup rootView;
    private View contentRoot;
    private LoadUtil loadUtil;

    private ListView listView;

    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_list_show);
        initActionBar(R.string.title_service_list_show, true);

        rootView = (ViewGroup) findViewById(R.id.rootView);
        contentRoot = findViewById(R.id.contentRoot);
        loadUtil = new LoadUtil(getLayoutInflater());

        listView = (ListView) findViewById(R.id.listView);

        Bundle extras = getIntent().getExtras();
        userId = extras.getString("userId");
        initData();
    }

    private void initData() {
        loadUtil.loadPre(rootView, contentRoot);
        //todo 需要升级接口
        RequestService.getOtherPublishList(getParams(userId), new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                loadUtil.loadSuccess(contentRoot);
                ArrayList<ServiceItem> items = (ArrayList<ServiceItem>) result;
                ServiceListShowAdapter adapter = new ServiceListShowAdapter(ServiceListShowActivity.this, items);
                adapter.setIsTaService(true);
                listView.setAdapter(adapter);
            }

            @Override
            public void onFailure(HttpError error) {
                loadUtil.loadFail(error, rootView, ServiceListShowActivity.this, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initData();
                    }
                });
            }
        });
    }

    private JSONObject getParams(String userId) {
        JSONObject params = null;
        try {
            params = new JSONObject();
            params.put("userId", userId);
            params.put("pageSize", 100);
            params.put("offset", 0);
        } catch (JSONException e) {
            Log.e(ServiceListShowActivity.class.getName(), "gen req params userId = " + userId, e);
        }
        return params;
    }

}
