package com.meidalife.shz.activity.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.activity.AttentionListener;
import com.meidalife.shz.adapter.SearchRecyclerViewAdapter;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.adapter.ShopAdapter;
import com.meidalife.shz.adapter.SquareAdapter;
import com.meidalife.shz.event.AttentionUserEvent;
import com.meidalife.shz.event.SquarePortalRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.GridOutDo;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.SearchFilterDo;
import com.meidalife.shz.rest.model.ServiceListOutDo;
import com.meidalife.shz.rest.model.ShopOutDo;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.rest.request.RequestSearch;
import com.meidalife.shz.rest.request.RequestSquare;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ConvertToUtils;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.widget.TutorialPopupWindow;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by zuozheng on 16/4/29.
 * 格子首页
 */
public class SquareHomeFragment extends BaseFragment {
    private static final String LOG_TAG = "SquareHomeFragment";
    private static final int SQUARE_MAX_COUNT = 6;

    private int page;
    private static final int PAGE_SIZE = 10;

    private SquareAdapter mSquareAdapter;
    private ShopAdapter mShopAdapter;
    private ServicesAdapter mServicesAdapter;


    private LoadUtil loadUtil;
//    PortalSquareDO squareDO = new PortalSquareDO();

    private AMapLocationManager mLocationManager;
    private boolean needLocation = false;
    LocationDO mLocation;
    List<GridOutDo> mGridList;
    List<ShopOutDo> mShopList;
    List<ServiceListOutDo> mServiceList = new LinkedList<>();

    private SearchRecyclerViewAdapter filterRecyclerAdapter;

    MyPageChangeListener pageChangeListener;

    private View rootView;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    /**
     * actionBar locationView
     */
    @Bind(R.id.locationNameView)
    TextView locationNameView;
    /**
     * actionBar right navView
     */
    @Bind(R.id.squareNav)
    View squareNav;
    @Bind(R.id.squareNavDesc)
    TextView squareNavDesc;

    /**
     * sourrounding listview
     */
    @Bind(R.id.serviceListView)
    ListView serviceListView;

    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;


    //没有数据提示view
    View noDataHeadTipView;
    ViewPager viewPager;
    //    CirclePageIndicator viewIndicator;
    View bottomIndexView;
    TextView currentPositionView;
    TextView totalCountView;
    ListView shopListView;

    RelativeLayout shopGroupView;
    TextView shopTitleView;
    TextView shopCountView;

    RecyclerView filterRecyclerView;

    TutorialPopupWindow tutorialPopupWindow;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_square_home, null);

            ButterKnife.bind(this, rootView);


            initHeadView(savedInstanceState);

            loadUtil = new LoadUtil(inflater);
            initListener();
        }

        return rootView;
    }

    void initHeadView(Bundle savedInstanceState) {
        View view = getLayoutInflater(savedInstanceState).inflate(R.layout.fragment_square_home_header, null);

        /**
         * navBodyView
         */
        noDataHeadTipView = view.findViewById(R.id.noDataTipView);

        viewPager = (ViewPager) view.findViewById(R.id.viewPager);
//        viewIndicator = (CirclePageIndicator) view.findViewById(R.id.viewIndicator);

        bottomIndexView = view.findViewById(R.id.bottomIndexView);
        currentPositionView = (TextView) view.findViewById(R.id.currentIndex);
        totalCountView = (TextView) view.findViewById(R.id.totalCount);

        //shop view
        shopGroupView = (RelativeLayout) view.findViewById(R.id.star_shop_group);
        shopTitleView = (TextView) view.findViewById(R.id.star_shop_title);
        shopCountView = (TextView) view.findViewById(R.id.star_shop_count);
        shopListView = (ListView) view.findViewById(R.id.shopListView);

        filterRecyclerView = (RecyclerView) view.findViewById(R.id.filterRecyclerView);
        //设置布局管理器
        LinearLayoutManager filterLayoutManager = new LinearLayoutManager(getActivity());
        filterLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        filterRecyclerView.setLayoutManager(filterLayoutManager);

        serviceListView.addHeaderView(view);

        viewPager.setPageMargin(ConvertToUtils.dip2px(getActivity(), 16));
        viewPager.setOffscreenPageLimit(1);
        viewPager.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:
                        mSwipeRefreshLayout.setEnabled(false);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        mSwipeRefreshLayout.setEnabled(true);
                        break;
                }
                return false;
            }
        });
        pageChangeListener = new MyPageChangeListener();
        viewPager.addOnPageChangeListener(pageChangeListener);
    }

    class MyPageChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            currentPositionView.setText(String.valueOf(position + 1));
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mLocationManager = SHZApplication.getInstance().getLocationManager();
        mLocation = mLocationManager.getLocation();

        if (mLocation != null && mLocation.getLongitude() > 0) {
            requestCard(mLocation);
//            requestServiceData(mLocation);
            updateLBSInfo(mLocation);
        } else {
            needLocation = true;
            getCurrentLbsLocation();
        }
    }

    void getCurrentLbsLocation() {
        mLocationManager.updateLocation(mLocationChangedListener);
    }

    private AMapLocationManager.LocationChangedListener mLocationChangedListener = new AMapLocationManager.LocationChangedListener() {

        @Override
        public void onLocationUpdateFailed() {
            needLocation = true;

            //定位失败 使用选择城市id请求数据
            mLocation = new LocationDO();
            mLocation.setCityCode(Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE));
            requestCard(mLocation);
        }

        @Override
        public void onLocationChanged(LocationDO location) {
            mLocation = location;
            updateLBSInfo(location);

            //定位成功 重新请求数据
            requestCard(location);

            if (needLocation) {
                needLocation = false;
            }

        }
    };

    @Override
    public void onResume() {
        super.onResume();
        showTutorial();
        EventBus.getDefault().register(this);

    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

    public void onEvent(SquarePortalRefreshEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType) {
            requestCard(mLocation);
        }
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }

            viewPager.removeOnPageChangeListener(pageChangeListener);
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    void initListener() {
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(false);
                requestCard(mLocation);
            }
        });

        squareNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("ssswithmap", getActivity());
            }
        });

        serviceListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        //todo load more
                        loadMoreServiceData(mLocation);
                    }
                } else {
                    mSwipeRefreshLayout.setEnabled(true);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
//                if (serviceListView.getFirstVisiblePosition() >= 1) {
//                    surroundingTitleTop.setVisibility(View.VISIBLE);
//                } else {
//                    surroundingTitleTop.setVisibility(View.GONE);
//                }
            }
        });
        serviceListView.setCacheColorHint(Color.TRANSPARENT);

        shopGroupView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("shopList");
            }
        });
    }

    void updateLBSInfo(LocationDO location) {
        if (location != null) {
            locationNameView.setText(location.getAddress());
        } else {
            locationNameView.setText("定位失败");
        }
    }

    JSONObject getParam(LocationDO location) {
        JSONObject params = new JSONObject();
        if (location != null) {
            params.put("cityCode", location.getCityCode());
            params.put("longitude", location.getLongitude());
            params.put("latitude", location.getLatitude());
        }
        return params;
    }

    JSONObject getServiceParam(LocationDO location) {
        JSONObject params = new JSONObject();
        if (location != null) {
            params.put("cityCode", location.getCityCode());
            params.put("longitude", location.getLongitude());
            params.put("latitude", location.getLatitude());
            params.put("pageSize", PAGE_SIZE);
            params.put("offset", page * PAGE_SIZE);
        }
        return params;
    }

    private void requestCard(final LocationDO location) {
        loadUtil.loadPre(rootLayout, mSwipeRefreshLayout);

        RequestSquare.cardList(getParam(location), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                mSwipeRefreshLayout.setRefreshing(false);
                loadUtil.loadSuccess(mSwipeRefreshLayout);

//                squareDO = result;
                if (result != null) {
                    if (result.containsKey("addressName")) {
                        //todo update the title address name
//                        result.getString("addressName");
                    }

                    if (result.containsKey("grids")) {
                        //todo update card
//                        result.getString("addressName");
                        mGridList = JSON.parseArray(result.getString("grids"), GridOutDo.class);
                    }
                }
                requestShop(location);
            }

            @Override
            public void onFail(HttpError error) {
                mSwipeRefreshLayout.setRefreshing(false);

                loadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        requestCard(location);
                    }
                });

//                squareDO = new PortalSquareDO();
            }
        });
    }

    private void requestShop(final LocationDO location) {
        RequestSquare.shopList(getParam(location), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                if (getActivity() == null || getActivity().isFinishing()) {
                    return;
                }

                if (result != null) {
                    if (result.containsKey("title")) {
                        // update the title address name
                        shopTitleView.setText(result.getString("title"));
                    }

                    if (result.containsKey("totalCount")) {
                        // update the title address name
                        shopCountView.setText(String.format(getActivity().getString(R.string.tab_title_count), result.getString("totalCount")));
                    }

                    if (result.containsKey("shopList")) {
                        // update card
                        mShopList = JSON.parseArray(result.getString("shopList"), ShopOutDo.class);
                    }

                }

                requestServiceData(location);
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    private void requestServiceData(LocationDO location) {
        RequestSearch.nearby(getServiceParam(location), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                if (getActivity() == null || getActivity().isFinishing()) {
                    return;
                }
//                mSwipeRefreshLayout.setEnabled(true);
                mSwipeRefreshLayout.setVisibility(View.VISIBLE);

                updateSquareView();
                //todo update shop view
                updateShopView();
                try {

                    if (result instanceof JSONObject) {

                        SearchFilterDo filterTab = new SearchFilterDo();
                        if (result.containsKey("cateList")) {
                            filterTab.setCateList(JSON.parseArray(result.getString("cateList"), SearchFilterDo.CateListItem.class));
                        }
                        if (result.containsKey("tabs")) {
                            filterTab.setTabs(JSON.parseArray(result.getString("tabs"), SearchFilterDo.Tab.class));
                        }
                        if (result.containsKey("filters")) {
                            filterTab.setFilters(JSON.parseObject(result.getString("filters"), SearchFilterDo.Filter.class));
                        }
                        initTabView(filterTab);

                        List<ServiceListOutDo> serviceList = JSON.parseArray(result.getString("result"), ServiceListOutDo.class);
                        loadServiceView(serviceList);
                    }

                } catch (JSONException e) {

                }
            }

            @Override
            public void onFail(HttpError error) {
//                mSwipeRefreshLayout.setEnabled(true);
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    private void loadMoreServiceData(LocationDO location) {

        page++;
        RequestSearch.nearby(getServiceParam(location), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                if (getActivity() == null || getActivity().isFinishing()) {
                    return;
                }
//                mSwipeRefreshLayout.setEnabled(true);
//                mSwipeRefreshLayout.setVisibility(View.VISIBLE);

//                updateSquareView();
                //update shop view
//                updateShopView();
                try {

                    if (result instanceof JSONObject) {

                        SearchFilterDo filterTab = new SearchFilterDo();
//                        if (result.containsKey("cateList")) {
//                            filterTab.setCateList(JSON.parseArray(result.getString("cateList"), SearchFilterDo.CateListItem.class));
//                        }
//                        if (result.containsKey("tabs")) {
//                            filterTab.setTabs(JSON.parseArray(result.getString("tabs"), SearchFilterDo.Tab.class));
//                        }
//                        if (result.containsKey("filters")) {
//                            filterTab.setFilters(JSON.parseObject(result.getString("filters"), SearchFilterDo.Filter.class));
//                        }
//                        initTabView(filterTab);

                        List<ServiceListOutDo> serviceList = JSON.parseArray(result.getString("result"), ServiceListOutDo.class);
                        loadServiceView(serviceList);
                    }

                } catch (JSONException e) {

                }
            }

            @Override
            public void onFail(HttpError error) {
//                mSwipeRefreshLayout.setEnabled(true);
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    private void initTabView(SearchFilterDo data) {
        filterRecyclerAdapter = new SearchRecyclerViewAdapter(getActivity());
        filterRecyclerAdapter.setSearchFilterDO(data);
        filterRecyclerView.setAdapter(filterRecyclerAdapter);
        filterRecyclerAdapter.notifyDataSetChanged();
        filterRecyclerView.setVisibility(View.VISIBLE);
    }

    void loadServiceView(List<ServiceListOutDo> result) {
        if (CollectionUtil.isNotEmpty(result)) {
            mServiceList.addAll(result);
        } else {
            if (result == null) {
                result = new ArrayList<>();
            }

            if (Helper.isLocationEnabled(getActivity())) {
                if (needLocation) {
                    //开启定位  定位失败
                    ServiceListOutDo error = new ServiceListOutDo();
                    error.setDesc("定位失败，请检查定位设置");
                    error.setType(1);
                    result.add(error);
                } else {
                    if (result == null || result.size() <= 0) {
                        ServiceListOutDo noDataError = new ServiceListOutDo();
                        noDataError.setDesc("努力搜集中");
                        noDataError.setType(2);
                        result.add(noDataError);
                    }
                }
            } else {
                //用户没有开启定位
                ServiceListOutDo error = new ServiceListOutDo();
                error.setDesc("未开启定位，点击设置");
                error.setType(1);
                result.add(error);
            }
        }

        //todo update the service list
        updateServiceView();
    }


    void updateSquareView() {
        if (CollectionUtil.isNotEmpty(mGridList)) {
//            List<SquareDO> squareList = squareDO.getGeziList();


            int totalSize = mGridList.size();


            //如果已经加入 显示滚动列表
            bottomIndexView.setVisibility(View.VISIBLE);
            noDataHeadTipView.setVisibility(View.GONE);
            currentPositionView.setText("1");
            int maxTotalCount = Math.min(SQUARE_MAX_COUNT - 1, totalSize);
            totalCountView.setText("" + maxTotalCount);

            //最多显示5个格子
            List<GridOutDo> tmpList = new LinkedList<>();
            tmpList.addAll(mGridList);
            if (totalSize > 5) {
                tmpList = tmpList.subList(0, 5);
                tmpList.add(new GridOutDo());
            }
            mSquareAdapter = new SquareAdapter(getActivity(), tmpList);

            viewPager.setAdapter(mSquareAdapter);
//            viewIndicator.setViewPager(viewPager);
//            viewIndicator.setOnPageChangeListener(this);

            squareNavDesc.setText(String.format(getActivity().getResources().getString(R.string.str_square_count), totalSize));

        } else {
            bottomIndexView.setVisibility(View.GONE);
            noDataHeadTipView.setVisibility(View.VISIBLE);
        }
    }

    void updateShopView() {
        if (CollectionUtil.isNotEmpty(mShopList)) {
            int maxShopSize = Math.min(2, mShopList.size());
            mShopList = mShopList.subList(0, maxShopSize);
            mShopAdapter = new ShopAdapter(getActivity(), mShopList);
            shopListView.setAdapter(mShopAdapter);


//            mShopAdapter.setOnClickListener(new AttentionListener() {
//                @Override
//                public void addFollowClick(String userId, int position) {
//                    addAttention(userId);
//                }
//            });
        }
    }

    void updateServiceView() {
        mServicesAdapter = new ServicesAdapter(getActivity(), mServiceList);
        serviceListView.setAdapter(mServicesAdapter);

        mServicesAdapter.setOnClickListener(new AttentionListener() {
            @Override
            public void addFollowClick(String userId, int position) {
                addAttention(userId);
            }
        });
    }

    private void showTutorial() {
        try {
            if (Helper.sharedHelper().getBooleanUserInfo(Constant.SQUARE_FIRST_IN, true) && null != getActivity()) {
                if (tutorialPopupWindow == null) {
                    tutorialPopupWindow = new TutorialPopupWindow(getActivity(),
                            TutorialPopupWindow.TUTORIAL_TYPE_ENTER_SQUARE);

                    tutorialPopupWindow.setOnFinishListener(new TutorialPopupWindow.OnFinishListener() {
                        @Override
                        public void onFinish() {
                            Helper.sharedHelper().setBooleanUserInfo(Constant.SQUARE_FIRST_IN, false);
                        }
                    });
                }
                if (!tutorialPopupWindow.isShowing() && !getActivity().isFinishing()) {
                    tutorialPopupWindow.showTutorial(rootView);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //关注人
    private void addAttention(final String userId) {
        RequestDynamic.addAttention(userId, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                AttentionUserEvent event = new AttentionUserEvent();
                event.userId = userId;
                event.isAttention = true;
                EventBus.getDefault().post(event);
            }

            @Override
            public void onFail(HttpError error) {
            }
        });
    }
}
