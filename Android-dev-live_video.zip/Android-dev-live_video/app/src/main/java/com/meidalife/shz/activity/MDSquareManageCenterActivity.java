package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareManageActionAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 格子管理中心
 * Created by xingchen on 2015/12/21.
 */
public class MDSquareManageCenterActivity extends BaseActivity {

    @Bind(R.id.memberNumber)
    TextView memberNumber;
    @Bind(R.id.squarePic)
    SimpleDraweeView squarePic;
    @Bind(R.id.memberGroup)
    LinearLayout memberGroup;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    View contentView;
    @Bind(R.id.tipsView)
    TextView tipsView;
    @Bind(R.id.textName)
    TextView textName;
    @Bind(R.id.textTypeDesc)
    TextView textTypeDesc;
    @Bind(R.id.itemCount)
    TextView itemCount;
    @Bind(R.id.itemCountIncrement)
    TextView itemCountIncrement;
    @Bind(R.id.askCount)
    TextView askCount;
    @Bind(R.id.askCountIncrement)
    TextView askCountIncrement;
    @Bind(R.id.bbsCount)
    TextView bbsCount;
    @Bind(R.id.bbsCountIncrement)
    TextView bbsCountIncrement;
    @Bind(R.id.nearbyCount)
    TextView nearbyCount;
    @Bind(R.id.nearbyCountIncrement)
    TextView nearbyCountIncrement;
    @Bind(R.id.actionListView)
    ListView actionListView;
    @Bind(R.id.squarePicBg)
    SimpleDraweeView squarePicBg;
    @Bind(R.id.tabNameTopLeft)
    TextView tabNameTopLeft;
    @Bind(R.id.tabNameTopRight)
    TextView tabNameTopRight;
    @Bind(R.id.tabNameBottomLeft)
    TextView tabNameBottomLeft;
    @Bind(R.id.tabNameBottomRight)
    TextView tabNameBottomRight;

    private int geziId = Integer.MAX_VALUE;
    private JSONArray actionList;
    private boolean uploading = false;
    private String picPath;
    private String uploadImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_md_square_manage_center);

        ButterKnife.bind(this);
        initActionBar(R.string.square_manager_center, true);

        if(!TextUtils.isEmpty(getIntent().getStringExtra("geziId")))
            geziId = Integer.parseInt(getIntent().getStringExtra("geziId"));

        actionListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                JSONObject item = actionList.getJSONObject(position);
                if (item.containsKey("url")) {
                    if (item.getString("url").contains("http://")) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", item.getString("url"));
                        Router.sharedRouter().open("web", bundle);
                    } else {
                        Bundle params = new Bundle();
                        if (item.getString("url").contains("notice") && item.containsKey("tips"))
                            params.putString("notice", item.getString("tips"));
                        Router.sharedRouter().open(item.getString("url"), params);
                    }
                }
            }
        });

        squarePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putBoolean("isCheckbox", true);
                bundle.putInt("maxLength", 1);
                Router.sharedRouter().openFormResult("pick/photo", bundle,
                        Constant.REQUEST_CODE_PICK_PHOTO, MDSquareManageCenterActivity.this);
            }
        });

        memberNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle params = new Bundle();
                params.putString("squareId", getIntent().getStringExtra("geziId"));
                params.putBoolean("isOwner",true);
                Router.sharedRouter().open("squareUserList", params);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK)
            return;
        Bundle params;
        switch (requestCode) {

            case Constant.REQUEST_CODE_PICK_PHOTO:
                params = data.getExtras();
                ArrayList paths = params.getStringArrayList("images");
                if (paths.size() > 0) {
                    picPath = (String) paths.get(0);
                    uploadImages();
                }
                break;
        }
    }

    private void uploadImages() {
        if (!uploading) {
            uploading = true;
            RequestSign.upload(picPath, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    org.json.JSONObject json = (org.json.JSONObject) result;
                    try {
                        uploadImage = json.getString("data");
                        if(!TextUtils.isEmpty(uploadImage))
                            updateImage();

                    } catch (JSONException e) {
                        uploading = false;
                        MessageUtils.showToastCenter("上传失败");
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    uploading = false;
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "上传失败");
                }
            });
        }
    }

    private void updateImage() {
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        params.put("geziImg", uploadImage);
        HttpClient.get("1.0/gezi/update", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                squarePic.setImageURI(Uri.parse(uploadImage));
                squarePicBg.setImageURI(Uri.parse(uploadImage));
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "上传失败，请稍后再试");
            }
        });
    }

    private void initData() {
        contentView.setVisibility(View.GONE);
        showStatusLoading(rootView);
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        HttpClient.get("1.1/gezi/managingPage", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                contentView.setVisibility(View.VISIBLE);
                if (obj.containsKey("tips")) {
                    tipsView.setVisibility(View.VISIBLE);
                    tipsView.setText(obj.getString("tips"));
                }
                JSONObject geziData = obj.getJSONObject("gezi");
                initSquareData(geziData);
                actionList = obj.getJSONArray("actionList");
                SquareManageActionAdapter squareManageActionAdapter = new SquareManageActionAdapter(MDSquareManageCenterActivity.this, actionList);
                actionListView.setAdapter(squareManageActionAdapter);

            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                    if (!TextUtils.isEmpty(error.getMessage())) {
                        setTextErrorServer(error.getMessage());
                    }
                }
            }
        });
    }

    private void initSquareData(JSONObject geziData) {
        if (geziData.containsKey("userList")) {
            JSONArray userList = geziData.getJSONArray("userList");
            List<ServiceItem.ViewUser> datalist = new ArrayList<ServiceItem.ViewUser>();
            ServiceItem.ViewUser viewUser;
            for (int i = 0; i < userList.size(); i++) {
                viewUser = new ServiceItem.ViewUser();
                JSONObject user = userList.getJSONObject(i);
                if (user.containsKey("userId"))
                    viewUser.setUserId(user.getIntValue("userId") + "");
                if (user.containsKey("userNick"))
                    viewUser.setUserName("userNick");
                if (user.containsKey("userPicUrl"))
                    viewUser.setUserAvatar(user.getString("userPicUrl"));
                if (user.containsKey("userGender"))
                    viewUser.setGender(user.getString("userGender"));
                datalist.add(viewUser);
                viewUser = null;
            }
            showMemberAvatar(datalist);
        }

        if(geziData.containsKey("tabs")){
            JSONArray tabs = geziData.getJSONArray("tabs");
            for(int i=0;i<tabs.size();i++){
                switch (tabs.getJSONObject(i).getIntValue("type")){
//                    case Constant.SQUARE_TAB_SERVICE:
//                    case Constant.SQUARE_TAB_MISC:
//                        tabNameTopLeft.setText(tabs.getJSONObject(i).getString("desc"));
//                        break;
//                    case Constant.SQUARE_TAB_ASK:
//                        tabNameTopRight.setText(tabs.getJSONObject(i).getString("desc"));
//                        break;
//                    case Constant.SQUARE_TAB_BBS:
//                        tabNameBottomLeft.setText(tabs.getJSONObject(i).getString("desc"));
//                        break;
                    case Constant.SQUARE_TAB_NEARBY:
                        tabNameBottomRight.setText(tabs.getJSONObject(i).getString("desc"));
                        break;
                }
            }
        }

        if (geziData.containsKey("geziName"))
            textName.setText(geziData.getString("geziName"));
        if (geziData.containsKey("geziTypeDesc"))
            textTypeDesc.setText("["+geziData.getString("geziTypeDesc")+"]");
        if (geziData.containsKey("userCount"))
            memberNumber.setText(String.format(getResources().getString(R.string.square_member_number), geziData.getIntValue("userCount") + ""));
        if (geziData.containsKey("geziPicUrl")){
            squarePic.setImageURI(Uri.parse(geziData.getString("geziPicUrl")));
            squarePicBg.setImageURI(Uri.parse(geziData.getString("geziPicUrl")));
        }
        if (geziData.containsKey("itemCount"))
            itemCount.setText(geziData.getIntValue("itemCount") + "");
        if (geziData.containsKey("itemCountArrow") && geziData.getIntValue("itemCountArrow") == 1) {
            itemCountIncrement.setVisibility(View.VISIBLE);
            itemCountIncrement.setText(String.format(getResources().getString(R.string.square_member_status_up), geziData.getIntValue("itemCountIncrement") + ""));
        }
        if (geziData.containsKey("demandCount"))
            askCount.setText(geziData.getIntValue("demandCount") + "");
        if (geziData.containsKey("demandCountArrow") && geziData.getIntValue("demandCountArrow") == 1) {
            askCountIncrement.setVisibility(View.VISIBLE);
            askCountIncrement.setText(String.format(getResources().getString(R.string.square_member_status_up), geziData.getIntValue("demandCountIncrement") + ""));
        }
        if (geziData.containsKey("bbsTopicCount"))
            bbsCount.setText(geziData.getIntValue("bbsTopicCount") + "");
        if (geziData.containsKey("bbsTopicCountArrow") && geziData.getIntValue("bbsTopicCountArrow") == 1) {
            bbsCountIncrement.setVisibility(View.VISIBLE);
            bbsCountIncrement.setText(String.format(getResources().getString(R.string.square_member_status_up), geziData.getIntValue("bbsTopicCountIncrement") + ""));
        }
        if (geziData.containsKey("yellowPageCount"))
            nearbyCount.setText(geziData.getIntValue("yellowPageCount") + "");
        if (geziData.containsKey("yellowPageCountArrow") && geziData.getIntValue("yellowPageCountArrow") == 1) {
            nearbyCountIncrement.setVisibility(View.VISIBLE);
            nearbyCountIncrement.setText(String.format(getResources().getString(R.string.square_member_status_up), geziData.getIntValue("yellowPageCountIncrement") + ""));
        }
    }

    public void showMemberAvatar(List<ServiceItem.ViewUser> datalist) {

        memberGroup.removeAllViews();

        int end = Math.min(7, datalist.size());
        datalist = datalist.subList(0, end);

        for (int i = 0; i < datalist.size(); i++) {

            final ServiceItem.ViewUser user = datalist.get(i);
            View view = View.inflate(this, R.layout.activity_service_detail_like_avatar, null);
            ImageView avatar = (ImageView) view.findViewById(R.id.user_avatar);
            String avatarUrl = ImgUtil.getCDNUrlWithWidth(user.getUserAvatar(), avatar.getLayoutParams().width);
            if (TextUtils.isEmpty(avatarUrl)) {
                String userId = user.getUserId();
                String gender = user.getGender();
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, userId, gender);
                avatar.setImageURI(getDefaultAvatarUri);
            } else {
                avatar.setImageURI(Uri.parse(avatarUrl));
            }

            memberGroup.addView(view);

            avatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Router.sharedRouter().open("profile/" + user.getUserId());
                }
            });
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        initData();
    }

}
