package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.media.AudioRecorder;
import com.meidalife.shz.media.PlayMediaService;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.view.RecordTextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 15/11/25.
 */
public class VoiceRecorderView extends View {


    private List<View> volumeList = new ArrayList<>();

    @Bind(R.id.recordView)
    View recordView;

    @Bind(R.id.timeTip)
    TextView timeTip;

    @Bind(R.id.volumeGroup)
    View volumeGroup;

    @Bind(R.id.volume_1)
    View volume_1;

    @Bind(R.id.volume_2)
    View volume_2;

    @Bind(R.id.volume_3)
    View volume_3;

    @Bind(R.id.volume_4)
    View volume_4;

    @Bind(R.id.recordTipTV)
    TextView recordTipTV;

    @Bind(R.id.voiceRecord)
    RecordTextView voiceRecord;

    //todo 播放 重录和完成
    @Bind(R.id.playView)
    View playView;

    @Bind(R.id.playTimeTip)
    TextView playTimeTip;

    @Bind(R.id.playVoice)
    TextView playVoice;

    @Bind(R.id.resetView)
    View resetView;

    @Bind(R.id.finishView)
    TextView finishView;

    String voiceFilePath;

    long voiceRecordTime;

    AudioRecorder audioRecorder;

    private Activity mContext;

    boolean isPlaying = false;
    View rowView;

    boolean lastHaveVoice = false;

    public OnClickListener listener;
    Intent playIntent;

    private int dynTime = 0;
    private int newTime = 0;

    public void setListener(OnClickListener listener) {
        this.listener = listener;
    }

    public VoiceRecorderView(Activity context, String voiceUrl, long voiceTimeLength) {
        super(context);
        this.mContext = context;
        this.voiceFilePath = voiceUrl;
        this.voiceRecordTime = voiceTimeLength;
        init();
    }

    public View getView() {
        return rowView;
    }

    protected void init() {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        rowView = inflater.inflate(R.layout.record_voice, (ViewGroup) findViewById(R.id.recordViewParent), false);

        ButterKnife.bind(this, rowView);

        initVolume();
        playIntent = new Intent(mContext, PlayMediaService.class);

        audioRecorder = new AudioRecorder();
        voiceRecord.setAudioRecord(audioRecorder);
        voiceRecord.setRecordListener(new VoiceRecordListener());

        if (TextUtils.isEmpty(voiceFilePath)) {
            recordView.setVisibility(View.VISIBLE);
            playView.setVisibility(View.GONE);
        } else {
            recordView.setVisibility(View.GONE);
            playView.setVisibility(View.VISIBLE);
            playTimeTip.setText(voiceRecordTime + " ''");
            finishView.setText("删除");
            lastHaveVoice = true;

        }
        initListener();
        timeTip.setText(0 + " ''");

    }

    void initListener() {
        playVoice.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!isPlaying) {
                    playIntent.putExtra(PlayMediaService.INTENT_MEDIA_PLAY, voiceFilePath);
                    mContext.startService(playIntent);
                    playVoice.setText(mContext.getResources().getString(R.string.icon_pause));
                } else {
                    mContext.stopService(playIntent);
                    playVoice.setText(mContext.getResources().getString(R.string.icon_play));

                }
                isPlaying = !isPlaying;
            }
        });

        resetView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.stopService(playIntent);
                recordView.setVisibility(View.VISIBLE);
                playView.setVisibility(View.GONE);
                audioRecorder.deleteOldFile();
            }
        });

        finishView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //upload voice file to server
                if (lastHaveVoice) {
                    mContext.stopService(playIntent);
                    xhrDeleteVoiceFile();
                } else {
                    xhrUploadVoiceFile();
                }

            }
        });
    }

    public void xhrDeleteVoiceFile() {
        HttpClient.get("1.0/user/delUserSound", null, String.class, new HttpClient.HttpCallback<String>() {
            @Override
            public void onSuccess(String voiceUrl) {
                //删除成功
                voiceFilePath = null;
                voiceRecordTime = 0l;
                volumeGroup.setVisibility(View.VISIBLE);
                recordTipTV.setText("松开结束");
                timeTip.setText("0 ''");
                recordView.setVisibility(View.VISIBLE);
                playView.setVisibility(View.GONE);
                if (listener != null) {
                    listener.voiceDeleteSuccess();
                }
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    public void xhrUploadVoiceFile() {
        if (TextUtils.isEmpty(voiceFilePath)) {
            MessageUtils.showToast("语音文件为空 请重新录制");
            return;
        }
        RequestSign.uploadVoice(voiceFilePath, new HttpClient.HttpCallback<String>() {
            @Override
            public void onSuccess(String voiceUrl) {
                //上传文件成功 更新个人信息
                xhrUpdateProfile(voiceUrl);
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    private void xhrUpdateProfile(String voiceFileUrl) {
        try {
            JSONObject params = new JSONObject();

            if (voiceRecordTime > 0) {
                params.put("soundLength", voiceRecordTime);
            }
            params.put("soundUrl", voiceFileUrl);

            RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    //设置一个事件监听 如果设置完成 关闭当前dialog
                    if (listener != null) {
                        listener.voiceUploadSuccess();
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                }
            });
        } catch (JSONException e) {
        }
    }

    private void initVolume() {
        volumeList.add(volume_1);
        volumeList.add(volume_2);
        volumeList.add(volume_3);
        volumeList.add(volume_4);
    }


    // 录音Dialog图片随录音音量大小切换
    private void setDialogImage(double voiceValue) {
        if (voiceValue < 2700.0) {
            updateVolume(1);
        } else if (voiceValue > 2700.0 && voiceValue < 5400.0) {
            updateVolume(2);
        } else if (voiceValue > 5400.0 && voiceValue < 8000.0) {
            updateVolume(3);
        } else if (voiceValue > 8000.0) {
            updateVolume(4);
        }
    }

    private void updateVolume(int maxVolume) {
        for (int i = 0; i < 4; i++) {
            View view = volumeList.get(i);
            if (i < maxVolume) {
                view.setVisibility(View.VISIBLE);
            } else {
                view.setVisibility(View.INVISIBLE);
            }
        }
    }


    class VoiceRecordListener implements RecordTextView.RecordListener {
        @Override
        public void recordStart() {
            Log.d("mylisten", "start");
            volumeGroup.setVisibility(View.VISIBLE);
            recordTipTV.setText("松开结束");

            //设置录音button背景

        }

        @Override
        public void recording(double voiceValue, float time) {
            setDialogImage(voiceValue);

            newTime = (int) time;
            if (newTime != dynTime) {
                timeTip.setText(newTime + " ''");
                dynTime = newTime;
            }

            Log.d("mylisten", String.valueOf(dynTime));
        }

        @Override
        public void recordCancel() {
            volumeGroup.setVisibility(View.INVISIBLE);
            recordTipTV.setText("按住录音");
            timeTip.setText("0 ''");
            //设置录音button背景
        }

        @Override
        public void recordEnd(String filePath, long recordTime) {
            Log.e(VoiceRecorderView.class.getName(), "record voice end, file = " + filePath + ", record time = " + recordTime);
            Log.d("mylisten", "end");
            //录音界面结束  显示播放界面

            voiceFilePath = filePath;
            voiceRecordTime = recordTime;

            volumeGroup.setVisibility(View.INVISIBLE);
            recordTipTV.setText("按住录音");
            recordView.setVisibility(View.GONE);

            //防止下次进入显示上次时间，在退出显示0
            timeTip.setText("0 ''");

            playView.setVisibility(View.VISIBLE);
            playTimeTip.setText(recordTime + " ''");

            lastHaveVoice = false;
            finishView.setText("完成");


        }

        @Override
        public void recordTooShort() {

        }
    }


    public interface OnClickListener {
        public void voiceUploadSuccess();

        public void voiceDeleteSuccess();
    }

}
