package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SkillSelectAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CareersDo;
import com.meidalife.shz.rest.model.CareerDo;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.FontTextView;
import com.usepropeller.routable.Router;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/4/20.
 */
public class CareerSelectActivity extends BaseActivity implements SkillSelectAdapter.OnSkillSelectListener {
    List<CareerDo> skillsDoList = new ArrayList<>();

    private static final int TYPE_SEARCH = 0;
    private static final int TYPE_GET = 1;

    private boolean isLoading = false;
    private boolean searchStatus = false;
    private boolean hasCareerBefore = false;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentLayout)
    ViewGroup contentLayout;
    @Bind(R.id.iconClose)
    TextView iconClose;

    @Bind(R.id.tipsLayout)
    ViewGroup tipsLayout;
    @Bind(R.id.tipsContainer)
    ViewGroup tipsContainer;
    @Bind(R.id.tipsClose)
    TextView tipsClose;

    @Bind(R.id.cancelButton)
    TextView cancelButton;
    @Bind(R.id.careerSearch)
    EditText careerSearch;
    @Bind(R.id.careerRecyclerView)
    RecyclerView careerRecyclerView;

    @Bind(R.id.bottomLayout)
    ViewGroup bottomLayout;
    @Bind(R.id.selectCount)
    TextView selectCount;
    @Bind(R.id.selectedCareerNames)
    TextView selectedCareerNames;
    @Bind(R.id.nextBtn)
    TextView nextBtn;

    SkillSelectAdapter skillSelectAdapter;
    LoadUtil mLoadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_career_select);
        ButterKnife.bind(this);

        initComponent();
        getCareerList(null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (RESULT_OK == resultCode && requestCode == Constant.REQUEST_CODE_CONFIRM_CAREER) {
            if (!hasCareerBefore) {
                Router.sharedRouter().open("publish");
            }
            setResult(RESULT_OK);
            finish();
        }
    }

    private void initComponent() {
        mLoadUtil = new LoadUtil(LayoutInflater.from(this));
        skillSelectAdapter = new SkillSelectAdapter(this, skillsDoList);
        skillSelectAdapter.setOnSkillSelectListener(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        careerRecyclerView.setAdapter(skillSelectAdapter);
        careerRecyclerView.setLayoutManager(layoutManager);

        iconClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        tipsClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipsLayout.setVisibility(View.GONE);
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                careerSearch.setText("");
                getCareerList(null);
            }
        });

        careerSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH
                        || (event != null && KeyEvent.KEYCODE_ENTER == event.getKeyCode() && KeyEvent.ACTION_DOWN == event.getAction())) {
                    if (!TextUtils.isEmpty(careerSearch.getText().toString())) {
                        JSONObject param = new JSONObject();
                        param.put("type", TYPE_SEARCH);
                        param.put("keyword", careerSearch.getText().toString());
                        getCareerList(param);
                        cancelButton.setVisibility(View.VISIBLE);
                    }
                    return true;
                }
                return false;
            }
        });

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(CareerSelectActivity.this, CareerConfirmActivity.class);
                intent.putExtra(Constant.EXTRA_TAG_CAREER_IDS, (Serializable) skillSelectAdapter.getSelectedSkillSet());
                startActivityForResult(intent, Constant.REQUEST_CODE_CONFIRM_CAREER);
            }
        });
    }

    private void getCareerList(JSONObject param) {
        if(isLoading){
            return;
        }
        mLoadUtil.loadPre(rootView, contentLayout);
        if (param == null) {
            param = new JSONObject();
            param.put("type", TYPE_GET);
        }
        HttpClient.get("1.0/skills/list", param, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                isLoading = false;
                mLoadUtil.loadSuccess(contentLayout);
                if (null != obj) {
                    CareersDo careerDo = JSON.parseObject(obj.toJSONString(), CareersDo.class);
                    skillsDoList = careerDo.getSkills();
                    skillSelectAdapter.setMaxSelect(careerDo.getSkillsLimit());
                    skillSelectAdapter.setCareerDoList(skillsDoList);
                    skillSelectAdapter.notifyDataSetChanged();
                    for (CareerDo skillsDo : careerDo.getSkills()) {
                        if (skillsDo.isSelected()) {
                            hasCareerBefore = true;
                            break;
                        }
                    }
                    showTips(careerDo.getTips());
                }
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                mLoadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        getCareerList(null);
                    }
                });
            }
        });
    }

    private void showTips(List<String> tips) {
        if (null == tips || tips.isEmpty()) {
            tipsLayout.setVisibility(View.GONE);
            return;
        }
        tipsContainer.removeAllViews();
        for (String tip : tips) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            FontTextView tipDotTextView = new FontTextView(this);
            tipDotTextView.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimensionPixelSize(R.dimen.font_size_small));
            tipDotTextView.setTextColor(getResources().getColor(R.color.black_a));
            tipDotTextView.setText("•");
            linearLayout.addView(tipDotTextView);
            FontTextView tipTextView = new FontTextView(this);
            tipTextView.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimensionPixelSize(R.dimen.font_size_small));
            tipTextView.setTextColor(getResources().getColor(R.color.black_a));
            tipTextView.setText(tip);
            linearLayout.addView(tipTextView);
            tipsContainer.addView(linearLayout);
        }
        tipsLayout.setVisibility(View.VISIBLE);
    }

    @Override
    public void onChanged(Set<String> selectedSkillSet) {
        if (selectedSkillSet.isEmpty()) {
            bottomLayout.setVisibility(View.GONE);
        } else {
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("职业：");
            int count = 0;
            for (int i = 0; i < skillsDoList.size(); i++) {
                CareerDo skillsDo = skillsDoList.get(i);
                if (selectedSkillSet.contains(skillsDo.getId())) {
                    stringBuffer.append(skillsDo.getName());
                    count++;
                    if (count < selectedSkillSet.size()) {
                        stringBuffer.append("、");
                    }
                }
            }
            selectCount.setText(String.valueOf(selectedSkillSet.size()));
            selectedCareerNames.setText(stringBuffer.toString());
            bottomLayout.setVisibility(View.VISIBLE);
        }
    }
}
