package com.meidalife.shz.activity.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.AddressSuggestAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressTypeOutDO;
import com.meidalife.shz.rest.model.PositionOutDO;
import com.meidalife.shz.util.CollectionUtil;
import com.umeng.analytics.MobclickAgent;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class AddressLocationFragment extends BaseFragment {


    @Bind(R.id.listView)
    ListView listView;

    private View rootView;

    @Bind(R.id.textStatusErrorServer)
    TextView textStatusErrorServer;
    @Bind(R.id.cellStatusDotLoading)
    LinearLayout cellStatusDotLoading;
    @Bind(R.id.cellStatusErrorNetwork)
    LinearLayout cellStatusErrorNetwork;
    @Bind(R.id.cellStatusErrorServer)
    LinearLayout cellStatusErrorServer;
    @Bind(R.id.dataEmpty)
    ViewGroup dataEmpty;
//     private AnimationDrawable loadingAnimation;

    private int tabType;
    //    private String cityCode;
    private String lng;
    private String lat;
    private ArrayList<PositionOutDO> listData;

    AddressSuggestAdapter mAdapter;

    boolean isLoading = false;
    private boolean isComplete = false;
    //    private boolean isRefresh = false;
    private boolean isLoadMore = false;

    private static final int PAGE_SIZE = 10;
    //开始页数为1
    int page = 0;

    public static AddressLocationFragment newInstance(AddressTypeOutDO categoryDO, String lng, String lat) {
        AddressLocationFragment categoryFragment = new AddressLocationFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("tabType", categoryDO.getTabType());
        bundle.putString("lng", lng);
        bundle.putString("lat", lat);
        bundle.putString("title", categoryDO.getTabText());
        categoryFragment.setArguments(bundle);
        return categoryFragment;
    }

    public void refresh(String lng, String lat) {
        this.lng = lng;
        this.lat = lat;

        loadAddress();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            Bundle args = getArguments();
            tabType = args.getInt("tabType");
//            cityCode = args.getString("cityCode");
            lng = args.getString("lng");
            lat = args.getString("lat");

            rootView = inflater.inflate(R.layout.fragment_common_list, container, false);

//            ButterKnife.bind(this, rootView);
//
//            initAdapter();
//            initListener();
        }
        return rootView;
    }

    private void initAdapter() {
        listData = new ArrayList<PositionOutDO>();
        mAdapter = new AddressSuggestAdapter(getActivity());
        listView.setAdapter(mAdapter);
    }

    private void initListener() {

        cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStatusLoading();
                loadAddress();
            }
        });

        cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStatusLoading();
                loadAddress();
            }
        });

        //通知selectSquareLocation the current position address
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PositionOutDO clickedItem = listData.get(position);
                Intent intent = new Intent();
                intent.putExtra("positionDO", clickedItem);
                getActivity().setResult(getActivity().RESULT_OK, intent);
                getActivity().finish();
            }
        });

        listView.setOnScrollListener(new AbsListView.OnScrollListener() {

            private boolean moveToBottom = false;
            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (previous < firstVisibleItem) {
                    moveToBottom = true;
                } else if (previous > firstVisibleItem) {
                    moveToBottom = false;
                }
                previous = firstVisibleItem;
                if (totalItemCount == firstVisibleItem + visibleItemCount && moveToBottom) {
                    /* 需要加载更多数据的代码 */
                    loadMore();
                }
            }
        });

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
//        showStatusLoading();
//        refreshList();
        loadAddress();
    }

//    public void onEvent(BaseEvent event) {
//        if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isRefresh) {
//            showStatusLoading();
//            refreshList();
//        }
//    }

    @Override
    public void onDestroyView() {
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("AddressLocation");

        ButterKnife.bind(this, rootView);

        initAdapter();
        initListener();
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("AddressLocation");
    }


    private void loadAddress() {
        isLoading = false;
        isComplete = false;
        page = 0;

        if (CollectionUtil.isNotEmpty(listData)) {
            listData.clear();
        }
        refreshList();
    }

    private void loadMore() {
        if (isLoading || isComplete) {
            return;
        }
        page++;
        isLoadMore = true;
        Log.i("Taber", "load next profile");

        refreshList();
    }

    private void refreshList() {
        if (isLoading) {
            return;
        }
        isLoading = true;

        if (cellStatusErrorNetwork != null) {
            cellStatusErrorNetwork.setVisibility(View.GONE);
        }
        if (cellStatusErrorServer != null) {
            cellStatusErrorServer.setVisibility(View.GONE);
        }
        showStatusLoading();

        try {
            HttpClient.get("1.0/address/search", getParamsByPage(), JSONObject.class, callback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private JSONObject getParamsByPage() {
        JSONObject params = new JSONObject();

        try {
            params.put("poiLongitude", lng);
            params.put("poiLatitude", lat);

            params.put("keyword", "");
            params.put("offset", page * PAGE_SIZE);
            //type:0 default
            params.put("type", "");
            params.put("tabType", tabType);
        } catch (JSONException e) {
            params = null;
        }
        return params;
    }

    HttpClient.HttpCallback<JSONObject> callback = new HttpClient.HttpCallback<JSONObject>() {
        @Override
        public void onSuccess(JSONObject jsonObj) {
            isLoading = false;
            hideStatusLoading();
            //todo 需要支持翻页
            try {
                List<PositionOutDO> mData = JSON.parseArray(jsonObj.getString("results"), PositionOutDO.class);
                String locationStr = jsonObj.getString("location");

                PositionOutDO locationDO = new PositionOutDO();
                locationDO.setName("[当前]");
                locationDO.setAddress(locationStr);
                locationDO.setPoiLatitude(Double.parseDouble(lat));
                locationDO.setPoiLongitude(Double.parseDouble(lng));
                locationDO.setAddByManual(1);
                mData.add(0, locationDO);

                if (CollectionUtil.isEmpty(mData) || mData.size() < PAGE_SIZE) {
                    isComplete = true;
                }

                if (CollectionUtil.isNotEmpty(mData)) {
                    if (CollectionUtil.isEmpty(listData)) {
                        listData = new ArrayList<PositionOutDO>();
                    }
                    listData.addAll(mData);
                }

                if (CollectionUtil.isEmpty(listData)) {
                    dataEmpty.setVisibility(View.VISIBLE);
                } else {
                    dataEmpty.setVisibility(View.GONE);
                }

                mAdapter.setData(listData);
                mAdapter.notifyDataSetChanged();
            } catch (Exception e) {

            }
        }

        @Override
        public void onFail(HttpError error) {
            hideStatusLoading();
            isLoading = false;

            if (isLoadMore) {
                page--;
                isLoadMore = false;
            }

            if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                cellStatusErrorNetwork.setVisibility(View.VISIBLE);
                return;
            }
            if (!TextUtils.isEmpty(error.getMessage())) {
                textStatusErrorServer.setText(error.getMessage());
            }
            cellStatusErrorServer.setVisibility(View.VISIBLE);
        }
    };

    private void showStatusLoading() {
        try {
            if (cellStatusDotLoading != null) {
                cellStatusDotLoading.setVisibility(View.VISIBLE);
//                loadingAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.loading_animation);
//                ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
//                loadingImage.setBackgroundDrawable(loadingAnimation);
//                loadingAnimation.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideStatusLoading() {
        try {
            if (cellStatusDotLoading != null) {
                cellStatusDotLoading.setVisibility(View.GONE);
//                if (loadingAnimation != null) {
//                    loadingAnimation.stop();
//                    loadingAnimation = null;
//                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}