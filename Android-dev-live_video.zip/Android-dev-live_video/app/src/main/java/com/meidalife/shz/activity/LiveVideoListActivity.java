package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.LiveVideoListFragment;
import com.meidalife.shz.util.ConvertToUtils;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujian on 16/2/16.
 * Modified by LanBo on 16/3/29.
 */
public class LiveVideoListActivity extends BaseActivity {

    @Bind(R.id.layout_live_video_tabs)
    View mTabsLayout;
    @Bind(R.id.rankContent1)
    View rankContent1;
    @Bind(R.id.titleRankTag1)
    View titleRankTag1;
    @Bind(R.id.rankContent2)
    View rankContent2;
    @Bind(R.id.titleRankTag2)
    View titleRankTag2;
    @Bind(R.id.rankContent3)
    View rankContent3;
    @Bind(R.id.titleRankTag3)
    View titleRankTag3;

    LiveVideoListFragment mFragment;
    LiveVideoListFragment.IStateChangeListener mStateChangeListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_live_video_list);
        initActionBar(R.string.title_activity_live_video_list, true, true);
        ButterKnife.bind(this);
        // ActionBar Right Button 的通用属性不符合该界面, 需要自己重新设置
        mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());
        mButtonRight.setBackgroundResource(R.drawable.bg_live_publish_btn);
        mButtonRight.setText(getString(R.string.publish_live_video) + " 发布");
        mButtonRight.setSingleLine();
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) mButtonRight.getLayoutParams();
        int marginPx = ConvertToUtils.dip2px(this, 7f);
        lp.setMargins(marginPx, marginPx, marginPx, marginPx);
        lp.width = ViewGroup.LayoutParams.WRAP_CONTENT;
        mButtonRight.setLayoutParams(lp);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startLiveVideo(v);
            }
        });

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        mStateChangeListener = new LiveVideoListFragment.IStateChangeListener() {
            @Override
            public void onScrollToTop(boolean top) {
                if (top) {
                    mTabsLayout.setVisibility(View.VISIBLE);
                } else {
                    mTabsLayout.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTabChanged(int type) {
                renderTab(type);
            }
        };
        mFragment = new LiveVideoListFragment();
        mFragment.setStateChangeListener(mStateChangeListener);
        fragmentTransaction.add(R.id.layout_live_list_fragment, mFragment);
        fragmentTransaction.commit();

        renderTab(mFragment.getTabType());
        bindListener();
    }

    private void bindListener() {

        rankContent1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.setType(Constant.LIVE_TYPE_NEW);
            }
        });

        rankContent2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.setType(Constant.LIVE_TYPE_HOT);
            }
        });

        rankContent3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.setType(Constant.LIVE_TYPE_MY);
            }
        });
    }

    public void renderTab(int tabType) {
        switch (tabType) {
            case Constant.LIVE_TYPE_NEW:
                titleRankTag1.setVisibility(View.VISIBLE);
                titleRankTag2.setVisibility(View.INVISIBLE);
                titleRankTag3.setVisibility(View.INVISIBLE);
                break;
            case Constant.LIVE_TYPE_HOT:
                titleRankTag1.setVisibility(View.INVISIBLE);
                titleRankTag2.setVisibility(View.VISIBLE);
                titleRankTag3.setVisibility(View.INVISIBLE);
                break;
            case Constant.LIVE_TYPE_MY:
                titleRankTag1.setVisibility(View.INVISIBLE);
                titleRankTag2.setVisibility(View.INVISIBLE);
                titleRankTag3.setVisibility(View.VISIBLE);
                break;
        }
    }

    public void startLiveVideo(View view) {

        boolean isAgreedLiveRule = Helper.sharedHelper().getBooleanUserInfo(Constant.USER_AGREED_LIVE_RULE, false);
        if (isAgreedLiveRule) {
            Router.sharedRouter().open("liveReady");
        } else {
            Router.sharedRouter().open("liveVideoQualification");
        }

    }

}
