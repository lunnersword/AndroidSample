package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.SurroundSquareListAdapter;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.util.LoadUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 周边格子list
 * Created by zhq on 15/12/20.
 */
public class SurroundSquareListActivity extends BaseActivity {
    List<SquareDO> resultList = new ArrayList<>();
    @Bind(R.id.rootView)
    LinearLayout rootView;

    @Bind(R.id.recycler_view)
    RecyclerView recyclerView;

    //refresh layout
    @Bind(R.id.listViewSwipe)
    SwipeRefreshLayout mSwipeRefreshLayout;

    @Bind(R.id.backButton)
    View backButton;

    @Bind(R.id.locationNameView)
    TextView locationNameView;

    //红包规则
    @Bind(R.id.createSquare)
    View createSquareButton;

    LinearLayoutManager linearLayoutManager;
    SurroundSquareListAdapter adapter;
    //开始页数为1
    int page = 0;

    Boolean isRefresh;
    private static final int PAGE_SIZE = 20;

    private AMapLocationManager mLocationManager;
    private boolean needLocation = false;
    LocationDO mLocation;

    private LoadUtil mLoadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_surround_square_list);

        ButterKnife.bind(this);

        //从我的tab页跳转过来

        initAdapter();
        initListView();

        mLocationManager = SHZApplication.getInstance().getLocationManager();
        mLocation = mLocationManager.getLocation();

        mLoadUtil = new LoadUtil(getLayoutInflater());
        adapter = new SurroundSquareListAdapter(this, resultList);
        recyclerView.setAdapter(adapter);
        if (mLocation != null && mLocation.getLongitude() > 0) {
            updateLBSInfo(mLocation);
            loadData();
        } else {
            needLocation = true;
            getCurrentLbsLocation();
        }
    }

    void getCurrentLbsLocation() {
        mLocationManager.updateLocation(mLocationChangedListener);
    }

    private AMapLocationManager.LocationChangedListener mLocationChangedListener = new AMapLocationManager.LocationChangedListener() {

        @Override
        public void onLocationUpdateFailed() {
            needLocation = false;
        }

        @Override
        public void onLocationChanged(LocationDO location) {
            mLocation = location;
            updateLBSInfo(location);

            //定位成功 重新请求数据
            loadData();

            if (needLocation) {
                needLocation = false;
            }
        }
    };


    void updateLBSInfo(LocationDO location) {
        if (location != null) {
            locationNameView.setText(location.getAddress());
        } else {
            locationNameView.setText("定位失败");
        }
    }

    private void initAdapter() {
//        adapter = new SurroundSquareAdapter(this, serviceItems);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

//        int spacingInPixels = getResources().getDimensionPixelSize(R.dimen.item_horizontal_margin);
//        recyclerView.addItemDecoration(new SurroundSquareDividerItemDecoration(spacingInPixels));
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
//        recyclerView.setAdapter(adapter);
    }

    private void initListView() {
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
//                handleRefresh();
                loadData();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        createSquareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("createSquare", SurroundSquareListActivity.this);
            }
        });

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (linearLayoutManager.findLastCompletelyVisibleItemPosition() == (adapter.getItemCount() - 1)) {
                    xhrServices(false, false);
                }
            }
        });
    }

    private void loadData() {
        isRefresh = false;
        page = 0;
        //  resultList.clear();
        xhrServices(true, true);
    }

    private JSONObject getParamsByPage(int page) {
        JSONObject params = new JSONObject();

        try {
            if (mLocation != null) {
                params.put("pageSize", PAGE_SIZE);
                params.put("offset", page * PAGE_SIZE);
                params.put("cityCode", mLocation.getCityCode());
                params.put("longitude", mLocation.getLongitude());
                params.put("latitude", mLocation.getLatitude());
            }
        } catch (JSONException e) {
            params = null;
        }
        return params;
    }

    private void xhrServices(boolean showLoading, final boolean refresh) {
        if (isRefresh) {
            return;
        }
        isRefresh = true;

        if (showLoading) {
            mLoadUtil.loadPre(rootView, mSwipeRefreshLayout);
        }

        HttpClient.get("1.0/gezi/surroundingGezis", getParamsByPage(page), JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                isRefresh = false;
                mSwipeRefreshLayout.setRefreshing(false);

                mLoadUtil.loadSuccess(mSwipeRefreshLayout);

                List<SquareDO> list = null;
                if (result != null) {
                    list = JSON.parseArray(result.getString("geziList"), SquareDO.class);
                }

                if (null != list && !list.isEmpty()) {
                    if (refresh) {
                        resultList.clear();
                    }
                    resultList.addAll(list);
                    adapter.setData(resultList);
                    adapter.notifyDataSetChanged();
                }
                page++;
            }

            @Override
            public void onFail(HttpError error) {
                isRefresh = false;
                mSwipeRefreshLayout.setRefreshing(false);
                mLoadUtil.loadFail(error, rootView, SurroundSquareListActivity.this, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        loadData();
                    }
                });
            }
        });
    }
}
