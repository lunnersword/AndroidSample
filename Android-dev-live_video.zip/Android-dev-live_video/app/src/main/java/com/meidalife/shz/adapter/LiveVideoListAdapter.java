package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.manager.LiveManager;
import com.meidalife.shz.rest.model.LiveVideoListDO;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.TimeUtils;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yiyang on 16/2/17.
 */
public class LiveVideoListAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private Context mContext;
    private List<LiveVideoListDO.VideoDO> mLiveVideoList;

    public LiveVideoListAdapter(Context context, List<LiveVideoListDO.VideoDO> liveVideoList) {
        mContext = context;
        mLiveVideoList = liveVideoList;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mLiveVideoList.size();
    }

    @Override
    public LiveVideoListDO.VideoDO getItem(int position) {
        return mLiveVideoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LiveVideoListDO.VideoDO videoDO = getItem(position);
        LiveVideoHolder liveVideoHolder;
        View view;
        if (convertView == null) {
            view = mInflater.inflate(R.layout.item_live_video_list, parent, false);
            liveVideoHolder = new LiveVideoHolder(view);
            view.setTag(liveVideoHolder);
        } else {
            view = convertView;
            liveVideoHolder = (LiveVideoHolder) view.getTag();
        }

        String gender = videoDO.getHost().getGender();
        // 设置服务者性别
        if (gender != null) {
            liveVideoHolder.genderIcon.setVisibility(View.VISIBLE);
            if (gender.equals("woman") || gender.equals("F")) {
                liveVideoHolder.genderIcon.setText(mContext.getResources().getString(R.string.gender_female));
                liveVideoHolder.genderIcon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            } else {
                liveVideoHolder.genderIcon.setText(mContext.getResources().getString(R.string.gender_male));
                liveVideoHolder.genderIcon.setTextColor(mContext.getResources().getColor(R.color.brand_i));
            }
        } else {
            liveVideoHolder.genderIcon.setVisibility(View.GONE);
        }

        // 加载发布者头像
        ViewGroup.LayoutParams avatarParams = liveVideoHolder.imageAvatar.getLayoutParams();
        String userPicUrl = videoDO.getHost().getUserAvatar();
        if (TextUtils.isEmpty(userPicUrl) || userPicUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(videoDO.getHost().getUserId()), gender);
            liveVideoHolder.imageAvatar.setImageURI(getDefaultAvatarUri);

        } else {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(userPicUrl, avatarParams.width));
            liveVideoHolder.imageAvatar.setImageURI(uri);
        }

        liveVideoHolder.hostNick.setText(videoDO.getHost().getUserName());

        if (videoDO.isLive()) {
            liveVideoHolder.liveStatusLayout.setVisibility(View.VISIBLE);
            liveVideoHolder.recordLive.setVisibility(View.GONE);
        } else {
            liveVideoHolder.liveStatusLayout.setVisibility(View.GONE);
            liveVideoHolder.recordLive.setVisibility(View.VISIBLE);
        }
        long duration = System.currentTimeMillis() - videoDO.getStartTime();
        liveVideoHolder.liveDuration.setText(DateUtils.time2StringShortWithHour1(duration));

        String strPictureVideo = videoDO.getPic();
        if (strPictureVideo != null && !strPictureVideo.equals("")) {
            liveVideoHolder.picVideo.setImageURI(Uri.parse(strPictureVideo));
        }

        int visitorCount = videoDO.getChannelStatus().getVisitorCount();
        liveVideoHolder.visitorCount.setText(visitorCount + "人正在观看");
        liveVideoHolder.rewardCount.setText(((float) videoDO.getAmount()) / 100 + "元打赏");

        liveVideoHolder.iCanText.setText(videoDO.getItem().getTitle());
        liveVideoHolder.descriptionText.setText('"' + videoDO.getDescription() + '"');

        return view;
    }

    static class LiveVideoHolder {
        private View view;

        @Bind(R.id.imageAvatar)
        SimpleDraweeView imageAvatar;
        @Bind(R.id.hostNick)
        FontTextView hostNick;
        @Bind(R.id.genderIcon)
        IconTextView genderIcon;
        @Bind(R.id.hostJobTitle)
        FontTextView hostJobTitle;
        @Bind(R.id.hostJob)
        FontTextView hostJob;

        @Bind(R.id.visitorCount)
        FontTextView visitorCount;
        @Bind(R.id.rewardCount)
        FontTextView rewardCount;

        @Bind(R.id.liveStatusLayout)
        View liveStatusLayout;
        @Bind(R.id.liveDuration)
        FontTextView liveDuration;

        @Bind(R.id.iCanText)
        FontTextView iCanText;
        @Bind(R.id.descriptionText)
        FontTextView descriptionText;
        @Bind(R.id.likeCount)
        FontTextView likeCount;

        @Bind(R.id.picVideo)
        SimpleDraweeView picVideo;
        @Bind(R.id.recordLive)
        View recordLive;


        public LiveVideoHolder(View v) {
            view = v;
            ButterKnife.bind(this, view);
        }

    }
}
