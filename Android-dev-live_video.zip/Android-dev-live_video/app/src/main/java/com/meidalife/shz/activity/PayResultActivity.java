package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.PayResultFavoriteAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestOrder;
import com.meidalife.shz.util.CollectionUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 支付订单
 */
public class PayResultActivity extends BaseActivity {
    private static final String PAY_RESULT_STATUS_SUCCESS = "2";
    private static final String PAY_RESULT_STATUS_FAILED = "1";

    @Bind(R.id.rootView)
    LinearLayout rootView;

    @Bind(R.id.recyclerView)
    RecyclerView recyclerView;
    @Bind(R.id.commentBtn)
    Button commentBtn;
    private View headView;
    private TextView orderAmount;
    private TextView orderNoView;
    private TextView orderPayType;
    private TextView payResultStatusIcon;
    private TextView payResultTextView;
    private TextView recommendTipTextView;
    private TextView gotoOrderDetailView;
    private TextView gotoHomeView;
    private View likeLayout;

    private PayResultFavoriteAdapter mServiceAdapter;
    GridLayoutManager gridLayoutManager;

    private SimpleDraweeView homeBeltAdv;

    private static final int PAGE_SIZE = 10;
    private int page;

    private List<ServiceItem> serviceItemList = Collections.synchronizedList(new ArrayList<ServiceItem>());

    boolean isLoading = false;
    boolean isComplete = false;

    String orderNo;
    String tradeNo;
    private String itemId;
    private String stdCateId;

    private int orderType = 1; //3:抢约订单  6:技能支付

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_result);
        initActionBar(R.string.title_activity_pay, true);
        ButterKnife.bind(this);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            orderNo = bundle.getString("orderId");
            tradeNo = bundle.getString("tradeId");
        }

        initView();
        initDataAndListener();
    }

    private void initView(){
        headView = LayoutInflater.from(this).inflate(R.layout.view_pay_result_head,null,false);
        orderAmount = (TextView)headView.findViewById(R.id.orderAmount);
        orderNoView = (TextView)headView.findViewById(R.id.orderNo);
        orderPayType = (TextView)headView.findViewById(R.id.orderPayType);
        payResultStatusIcon = (TextView) headView.findViewById(R.id.payResultStatusIcon);
        payResultTextView = (TextView)headView.findViewById(R.id.payResultTextView);
        recommendTipTextView = (TextView)headView.findViewById(R.id.recommendTipTextView);
        gotoOrderDetailView = (TextView)headView.findViewById(R.id.gotoOrderDetail);
        gotoHomeView = (TextView)headView.findViewById(R.id.gotoHome);
        homeBeltAdv = (SimpleDraweeView)headView.findViewById(R.id.homeBeltAdv);
        likeLayout = headView.findViewById(R.id.likeLayout);

    }

    private void initDataAndListener() {

        gridLayoutManager = new GridLayoutManager(this,2);
        recyclerView.setLayoutManager(gridLayoutManager);
        mServiceAdapter = new PayResultFavoriteAdapter(this, serviceItemList);
        mServiceAdapter.setHeaderView(headView);
        recyclerView.setAdapter(mServiceAdapter);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (gridLayoutManager.findLastCompletelyVisibleItemPosition() == (gridLayoutManager.getItemCount() - 1)) {
                    loadMoreRecommend();
                }
            }
        });

        gotoOrderDetailView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (orderType == 3) {
                    gotoMyLottery(v);
                } else {
                    handleOrderDetail(v);
                }
            }
        });

        gotoHomeView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (orderType == 3) {
                    finishView(v);
                } else {
                    handleHome(v);
                }
            }
        });
        commentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("orderJudge/" + CommentActivity.COMMENT_ADD_TYPE + "/" + orderNo);
                finish();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        xhrPayResult();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
    }

    //获取支付订单数据
    private void xhrPayResult() {
        showStatusLoading(rootView);

        //start request
        startPayInfoRequest(orderNo);
    }

    void startPayInfoRequest(String orderNo) {
        RequestOrder.orderPayResult(orderNo, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                hideStatusLoading();

                //加载腰峰广告
                if (result.containsKey("banner")) {
                    JSONObject homeBeltAdArray = result.getJSONObject("banner");
                    loadHomeBelt(homeBeltAdArray);
                }

                //todo 请求支付结果数据成功 解析数据并刷新界面
                parseDataAndReqRecommend(result);

            }

            @Override
            public void onFail(HttpError error) {
                failure(error);
            }
        });


    }

    private void loadHomeBelt(JSONObject data) {
        try {
            homeBeltAdv.setVisibility(View.VISIBLE);
            final String linkUrl = data.getString("clickUrl");
            homeBeltAdv.setImageURI(Uri.parse(data.getString("picUrl")));
            homeBeltAdv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", linkUrl);
                    Router.sharedRouter().open("web", bundle);
                }
            });
        } catch (Exception e) {
        }
    }

    void parseDataAndReqRecommend(JSONObject json) {
        try {
            //todo parse data and show
            JSONObject payResultObj = json.getJSONObject("payResult");

            if (payResultObj.containsKey("itemId")) {
                itemId = payResultObj.getString("itemId");
                stdCateId = payResultObj.getString("stdCatId");
            }

            if (payResultObj.containsKey("statusText")) {
                payResultTextView.setText(payResultObj.getString("statusText"));
            }

            if (PAY_RESULT_STATUS_SUCCESS.equals(payResultObj.getString("status"))) {
                payResultStatusIcon.setText(R.string.icon_checkbox_active);
            } else {
                payResultStatusIcon.setText(R.string.icon_warn);
                payResultStatusIcon.setTextColor(getResources().getColor(R.color.brand_b));
            }

            JSONObject detailObj = json.getJSONObject("detail");

            if (detailObj.containsKey("amountText")) {
                orderAmount.setText("订单金额：¥" + (detailObj.getString("amountText")));
            }
            if (detailObj.containsKey("orderNo")) {
                orderNoView.setText("订单编号：" + detailObj.getString("orderNo"));
            }

            if (detailObj.containsKey("paywayText")) {
                orderPayType.setText("支付方式：" + detailObj.getString("paywayText"));
            }

            if (detailObj.containsKey("type")) {
//                orderPayType.setText("支付方式：" + detailObj.getString("paywayText"));
                orderType = detailObj.getIntValue("type");

                if (orderType == 3) {
                    gotoOrderDetailView.setText("查看我的抢约");
                    gotoHomeView.setText("继续抢约");
                }

                if(orderType == 6){
                    gotoOrderDetailView.setVisibility(View.GONE);
                    gotoHomeView.setVisibility(View.GONE);
                    commentBtn.setVisibility(View.VISIBLE);
                    likeLayout.setVisibility(View.GONE);
                }else{
                    gotoOrderDetailView.setVisibility(View.VISIBLE);
                    gotoHomeView.setVisibility(View.VISIBLE);
                    commentBtn.setVisibility(View.GONE);
                    likeLayout.setVisibility(View.VISIBLE);
                }

            }

            if(orderType != 6)
                xhrRecommend();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void xhrRecommend() {
        isLoading = false;
        isComplete = false;
        page = 1;
        xhrOrderRecommend();
    }

    void loadMoreRecommend() {
        page++;
        xhrOrderRecommend();
    }

    void xhrOrderRecommend() {
        if (isComplete || isLoading) {
            return;
        }

        isLoading = true;
        showStatusLoading(rootView);

        RequestOrder.orderRecommend(getParam(), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                hideStatusLoading();
                isLoading = false;
                //todo 请求支付结果数据成功 解析数据并刷新界面
//                JSONArray jsonArray = result.getJSONArray("serviceList");
                List<ServiceItem> list = null;
                try {
                    list = JSON.parseArray(result.getString("itemList"), ServiceItem.class);
                    String tip = result.getString("recommendReason");
                    recommendTipTextView.setText(tip);
                } catch (Exception e) {

                }

                if (CollectionUtil.isEmpty(list) || list.size() < PAGE_SIZE) {
                    isComplete = true;
                }

                serviceItemList.addAll(list);

                if (serviceItemList.isEmpty()) {
                    textStatusErrorServer.setText("没有推荐相关服务");
                } else {
                    mServiceAdapter.setData(serviceItemList);
                    mServiceAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                failure(error);
            }
        });
    }

    private JSONObject getParam() {
        JSONObject params = new JSONObject();

        try {
            params.put("itemId", itemId);
            params.put("subCateId", stdCateId);
            params.put("offset", page * PAGE_SIZE);
            params.put("pageSize", PAGE_SIZE);
        } catch (Exception e) {

        }
        return params;
    }


//    private ServiceItem transferToDiscoverItem(JSONObject data) {
//        ServiceItem item = new ServiceItem();
//        item.setItemId(data.getString("itemId"));
//        item.setUserId(data.getLong("userId"));
//        item.setUserAvatar(data.getString("userAvatar"));
//        item.setTag(data.getString("tag"));
//        item.setServiceType(data.getIntValue("serviceType"));
//        item.setImages((ArrayList<String>) JSONArray.parseArray(data.getString("images"), String.class));
//        item.setPrice(data.getString("price"));
//        item.setCityName(data.getString("cityName"));
//
//        return item;
//    }

    private void failure(HttpError error) {
        hideStatusLoading();
//        hideProgressDialog();

        if (error != null) {
            if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                showStatusErrorNetwork(rootView);
                setOnClickErrorNetwork(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        xhrPayResult();
                    }
                });
            } else {
                showStatusErrorServer(rootView);
                setTextErrorServer(error.getMessage());
                setOnClickErrorServer(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        xhrPayResult();
                    }
                });
            }
        } else {
            showStatusErrorServer(rootView);
            setTextErrorServer("获取数据失败，请点击重试");
            setOnClickErrorServer(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    xhrPayResult();
                }
            });
        }
    }

    private void gotoOrderDetail() {
        Bundle params = new Bundle();
        if (!TextUtils.isEmpty(orderNo)) {
            params.putString("orderId", orderNo);
        } else {
            params.putString("tradeId", tradeNo);
        }
        Router.sharedRouter().open("orderDetailAction", params);
        finish();
    }

    public void handleOrderDetail(View view) {
        gotoOrderDetail();
    }

    public void handleHome(View view) {
        Bundle bundle = new Bundle();
        bundle.putString("from", "payResult");
        Router.sharedRouter().open("main", bundle);
        finish();
    }

    public void gotoMyLottery(View view) {
        Router.sharedRouter().open("mylottery/all");
        finish();
    }

    public void finishView(View v) {
        Intent intent = new Intent();
        intent.setClass(PayResultActivity.this, WebActivity.class);
        intent.putExtra("url", "http://m.kongge.com/lottery");
        startActivity(intent);
        finish();
    }
}
