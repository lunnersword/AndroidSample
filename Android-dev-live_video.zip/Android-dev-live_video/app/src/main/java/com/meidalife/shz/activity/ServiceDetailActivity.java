package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CommentAdapter;
import com.meidalife.shz.adapter.PopupPhotoAdapter;
import com.meidalife.shz.adapter.ServiceDetailPhotoViewPageAdapter;
import com.meidalife.shz.adapter.SkuCommentAdapter;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.CommentDO;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.rest.model.ScopeOutDO;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.model.SkuCommentOutDO;
import com.meidalife.shz.rest.model.UserOutDO;
import com.meidalife.shz.rest.model.UserTagOutDO;
import com.meidalife.shz.rest.request.RequestCommentOpr;
import com.meidalife.shz.rest.request.RequestItem;
import com.meidalife.shz.rest.request.RequestService;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.widget.PopupListMenu;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.usepropeller.routable.Router;
import com.viewpagerindicator.CirclePageIndicator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * 315版本宝贝详情页
 * Created by zuozheng 2016/03/03
 */
public class ServiceDetailActivity extends BaseActivity implements AbsListView.OnScrollListener, ViewPager.OnPageChangeListener {

    private static final int MENU_ITEM_SHARE = 0;
    private static final int MENU_ITEM_SEARCH = 1;
    private static final int MENU_ITEM_HOME = 2;
    private static final int MENU_ITEM_JUBAO = 3;


    private LayoutInflater inflater;
    private Context context;


    @Bind(R.id.service_detail_body_root_view)
    ViewGroup contentRoot;

    @Bind(R.id.titleBar)
    RelativeLayout titleBar;
    //back
    @Bind(R.id.action_bar_button_back)
    TextView action_bar_button_back;
    //title
    @Bind(R.id.action_bar_title)
    TextView action_bar_title;
    //right
    @Bind(R.id.action_bar_button_right)
    TextView action_bar_button_right;


    //头部图片
    ViewGroup adViewLayout;
    ViewPager adViewPager;
    CirclePageIndicator adViewIndicator;

    TextView userOnLineStatusView;
    TextView userNickView;
    ImageView userAvatar;
    TextView sexIcon;
    LinearLayout userTagView;
    TextView realNameAuthStatus;
    TextView zmLevel;
    TextView skillAuth;

    private ProgressBar footProgressBar;
    private CommentAdapter msgAdapter;
    private View inputViewGroup;

    private TextView sellCountText;
    private TextView itemStockText;
    private View detailFooter;

    private View detail_skill_group;
    private ViewGroup servicePriceLayout;

    private ViewGroup earnestLayout;
    private TextView earnestValue;
    private TextView earnestPayLink;
    private TextView finalPayAmount;
    private ViewGroup earnestDetailLayout;
    private TextView earnestPrice;
    private TextView earnestOriPrice;
    private TextView finalPayTime;
    private ViewGroup commentViewGroup;
    private ListView commentListView;
    private ListView msgBoardView;
    private ViewGroup noMsgView;
    private TextView msgCountTextView;   // 处理新增评论更新数量
    LinearLayout latestSellGroup;
    View mainView;
    private String itemId;

    private boolean isComplete = false;
    private boolean isLoading = false;
    private int previous;
    private int page = 0;
    private int pageSize = 10;

    private int msgCount = 0;
    private CommentItemListener msgBoardItemListener;

    private PopupWindow popupWindow;
    private PopupListMenu mPopupListMenu;
    private SocialSharePopupWindow socialSharePopupWindow;

    private ServiceItem shareDO;

    int headerHeight;
    private int titleBarAlpha = 0;

    List<CommentDO> msgList = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_detail);

        context = this;
        Bundle extras = getIntent().getExtras();
        itemId = extras.getString("id");

        initView();

        initTitleBarBg();

        initLoadData();
    }

    @Override
    public void onPause() {
        super.onPause();
        //透明度还原，解决部分机型（联想等）影响其他titlebar透明度不恢复的bug
        titleBar.getBackground().setAlpha(255);
        titleBar.invalidate();
    }

    @Override
    public void onResume() {
        super.onResume();
        titleBar.getBackground().setAlpha(titleBarAlpha);
        titleBar.invalidate();
    }

    @Override
    public void onBackPressed() {
        if (inputViewGroup.getVisibility() == View.VISIBLE) {
            inputViewGroup.setVisibility(View.GONE);
            detailFooter.setVisibility(View.VISIBLE);
            return;
        }
        super.onBackPressed();
    }

    void initView() {

        ButterKnife.bind(this);

        inflater = getLayoutInflater();

        //main view
        mainView = inflater.inflate(R.layout.activity_service_detail_header, null);

        adViewLayout = (ViewGroup) mainView.findViewById(R.id.adViewLayout);
        adViewPager = (ViewPager) mainView.findViewById(R.id.adViewpager);
        adViewIndicator = (CirclePageIndicator) mainView.findViewById(R.id.adViewIndicator);

        //在线状态 头像 nick 性别
        userOnLineStatusView = (TextView) mainView.findViewById(R.id.detail_online_status);
        userAvatar = (ImageView) mainView.findViewById(R.id.detail_user_avatar);
        userNickView = (TextView) mainView.findViewById(R.id.detail_user_nick);
        sexIcon = (TextView) mainView.findViewById(R.id.detail_sex_icon);

        //个性表签
        userTagView = (LinearLayout) mainView.findViewById(R.id.detail_user_tag);

        //实名认证状态
        realNameAuthStatus = (TextView) mainView.findViewById(R.id.detail_real_name_auth_status);
        //芝麻信用分数
        zmLevel = (TextView) mainView.findViewById(R.id.detail_zm_level);
        //个人认证
        skillAuth = (TextView) mainView.findViewById(R.id.detail_skill_tv);
        detail_skill_group = mainView.findViewById(R.id.detail_skill_group);


        //销量 && 库存
        sellCountText = (TextView) mainView.findViewById(R.id.sellCountText);
        itemStockText = (TextView) mainView.findViewById(R.id.itemStockView);

        //服务价格布局,预定商品隐藏
        servicePriceLayout = (ViewGroup) mainView.findViewById(R.id.servicePriceLayout);
        //定金价格
        earnestLayout = (ViewGroup) mainView.findViewById(R.id.earnestLayout);
        earnestValue = (TextView) mainView.findViewById(R.id.earnestValue);
        earnestPayLink = (TextView) mainView.findViewById(R.id.earnestPayLink);
        finalPayAmount = (TextView) mainView.findViewById(R.id.finalPayAmount);

        earnestDetailLayout = (ViewGroup) mainView.findViewById(R.id.earnestDetailLayout);
        earnestPrice = (TextView) mainView.findViewById(R.id.earnestPrice);
        earnestOriPrice = (TextView) mainView.findViewById(R.id.earnestOriPrice);

        finalPayTime = (TextView) mainView.findViewById(R.id.finalPayTime);


        final View foot = inflater.inflate(R.layout.fragment_comment_foot, null);
        footProgressBar = (ProgressBar) foot.findViewById(R.id.detail_comment_foot_pb);

        //留言板
        detailFooter = findViewById(R.id.service_detail_footer);
        detailFooter.setVisibility(View.GONE);

        inputViewGroup = findViewById(R.id.detail_comment_input_group);
        EditText inputText = (EditText) findViewById(R.id.comment_input_text);
        TextView inputCommit = (TextView) findViewById(R.id.comment_input_commit);
        msgBoardItemListener = new CommentItemListener(inputText, inputViewGroup, detailFooter);
        inputCommit.setOnClickListener(msgBoardItemListener);


        msgBoardView = (ListView) findViewById(R.id.detail_msg_board_listview);
        msgBoardView.addHeaderView(mainView);
        msgBoardView.addFooterView(foot);
        msgBoardView.setOnItemClickListener(msgBoardItemListener);

        msgAdapter = new CommentAdapter(context, inflater, msgList);   // 为保证head显示，因此无论是否有数据，都设置adapter
        msgBoardView.setAdapter(msgAdapter);

        msgBoardView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
//                final CommentAdapter.PJViewHolder curr = (CommentAdapter.PJViewHolder) view.getTag();
//
//                if (null != curr) {
//                    View contextMenu = LayoutInflater.from(ServiceDetailActivity.this).inflate(R.layout.message_delete_dialog, null);
//                    final AlertDialog dialog = new AlertDialog.Builder(ServiceDetailActivity.this).create();
//                    dialog.setView(contextMenu, 0, 0, 0, 0);
//                    dialog.show();
//                    TextView deleteTv = (TextView) contextMenu.findViewById(R.id.singleContextMenu);
//                    deleteTv.setText(R.string.report);
//                    deleteTv.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            Intent intent = new Intent();
//                            intent.setClass(ServiceDetailActivity.this, ReportActivity.class);
//                            intent.putExtra("targetId", String.valueOf(curr.commentId));
//                            intent.putExtra("target", Constant.REPORT_TYPE_SERVICE_LEAVE_MESSAGE);
//                            startActivity(intent);
//                        }
//                    });
//
//                    return true;
//                }
                if (CollectionUtil.isEmpty(msgList))
                    return false;

                if ((position - 1) < msgList.size() && msgList.get(position - 1) != null) {
                    final CommentDO comment = msgList.get(position - 1);

                    View contextMenu = LayoutInflater.from(ServiceDetailActivity.this).inflate(R.layout.message_delete_dialog, null);
                    final AlertDialog dialog = new AlertDialog.Builder(ServiceDetailActivity.this).create();
                    dialog.setView(contextMenu, 0, 0, 0, 0);
                    dialog.show();
                    TextView deleteTv = (TextView) contextMenu.findViewById(R.id.singleContextMenu);
                    if (comment.getCanDelete() == 1) {
                        deleteTv.setText(R.string.delete);
                        deleteTv.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                //todo delete msg
                                deleteComment(comment);
                                dialog.dismiss();
                            }
                        });
                    } else {
                        deleteTv.setText(R.string.report);
                        deleteTv.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent();
                                intent.setClass(ServiceDetailActivity.this, ReportActivity.class);
                                intent.putExtra("targetId", comment.getCommentId());
                                intent.putExtra("target", Constant.REPORT_TYPE_SERVICE_LEAVE_MESSAGE);
                                startActivity(intent);
                            }
                        });
                    }
                    return true;
                }
                return false;
            }
        });


        //未评价view
        noMsgView = (ViewGroup) mainView.findViewById(R.id.noMsgView);

        mainView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                msgBoardItemListener.hideKeyword();
            }
        });
    }

    private void deleteComment(final CommentDO comment) {
        RequestCommentOpr.deleteComment(comment.getCommentId(), new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                if (msgList.contains(comment)) {
                    msgList.remove(comment);
                    msgAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }


    private void initPhotoListView(final ServiceItem item) {
        View albumView = LayoutInflater.from(this).inflate(R.layout.album_list, null);
        final ListView albumListView = (ListView) albumView.findViewById(R.id.album_list);
        PopupPhotoAdapter albumListAdapter = new PopupPhotoAdapter(this, item.getImages());
        albumListView.setAdapter(albumListAdapter);

        albumListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                popupWindow.dismiss();
            }
        });

        popupWindow = new PopupWindow(albumView, ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setAnimationStyle(R.style.PopupWindowAnimation);
        popupWindow.showAtLocation(contentRoot, Gravity.CENTER, 0, 0);
    }


    public void initLoadData() {
        showStatusLoading(contentRoot);
        RequestItem.get(itemId, null, new HttpClient.HttpCallback<ServiceItem>() {
            @Override
            public void onSuccess(ServiceItem result) {

                loadSuccess(contentRoot);
//                hideStatusLoading();
                hideStatusErrorServer();
                renderItem(result);

                loadComment();
                loadMsg(true);

                shareDO = result;
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(ServiceDetailActivity.class.getName(), "req item data fail, itemId=" +
                        itemId + ", " + error.toString());
                action_bar_button_back.setTextColor(getResources().getColor(R.color.black));
                action_bar_button_right.setVisibility(View.GONE);

                loadFail(error, contentRoot, ServiceDetailActivity.this, new LoadCallback() {
                    @Override
                    public void execute() {
                        initLoadData();
                    }
                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }


    public void renderItem(final ServiceItem item) {
//        serviceItem = item;

        //最新销量 增加右侧滑入和滑出消失动画
        renderLastSell(item);


        //图片处理 采用recylerview + adapter 实现
        renderPhotoView(item);

        renderSellerView(item);

        renderItemView(item);

        //评价

        //评价数量 adapter + listview
        commentViewGroup = (ViewGroup) findViewById(R.id.commentViewGroup);
        commentListView = (ListView) findViewById(R.id.commentListView);
        TextView commentCountView = (TextView) findViewById(R.id.detail_comment_count_view);
        TextView allCommentView = (TextView) findViewById(R.id.gotoCommentListView);

        commentCountView.setText(item.getEvaluationCount() > 0 ?
                String.format("服务评价（%s）", item.getEvaluationCount()) : getString(R.string.comment_count_none));
        allCommentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (item.getEvaluationCount() > 0) {
//                    Bundle params = new Bundle();
//                    params.putString("itemId", itemId);
                    Router.sharedRouter().open("servicecomment/" + itemId);
                }
            }
        });

        // 留言Label
        ViewGroup msg_board_group = (ViewGroup) findViewById(R.id.detail_msg_board_group);
        msg_board_group.setVisibility(View.VISIBLE);
        msgCountTextView = (TextView) findViewById(R.id.detail_msg_board_view);
        msgCount = item.getMessageCount();
        msgCountTextView.setText(String.format("留言板（%s）", msgCount));

        renderFootView(item);
    }

    void renderItemView(final ServiceItem item) {

        action_bar_title.setText(item.getTag());

        //商品名称
        TextView serviceTitleView = (TextView) findViewById(R.id.detail_service_title);
        serviceTitleView.setText(getString(R.string.label_i_can) + item.getTag());

        renderPriceLayout(item);

        // 评分
//        TextView judgeStar = (TextView) findViewById(R.id.detail_judge_star);
//        judgeStar.setText(item.getGrade() + "星");
        ViewGroup starGroup = (ViewGroup) findViewById(R.id.detail_judge_star_icon_group);
        View starsView = inflater.inflate(R.layout.activity_sku_service_detail_stars, null);
        View starsRed = starsView.findViewById(R.id.star_red_group);
        starsRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, context) * item.getGrade() / 5);
        starGroup.removeAllViews();
        starGroup.addView(starsView);

        //销量 库存
        sellCountText.setText(String.format(getString(R.string.sell_count), item.getSellCount()));

        //促销商品 显示促销库存  否者正式库存
        if (!item.isServiceCapacity() && item.getQuantitySum() > 0) {
            itemStockText.setText(String.format(getString(R.string.item_stock), item.getQuantitySum()));
            itemStockText.setVisibility(View.VISIBLE);
        }

        //服务描述
        TextView content = (TextView) findViewById(R.id.detail_service_desc);
        content.setText(item.getContent());

        //距离 服务时间 可用m豆 红包说明
        View locationGroup = findViewById(R.id.detail_location_group);
        TextView location = (TextView) findViewById(R.id.detail_location);
        if (item.getDistance() == null) {
            locationGroup.setVisibility(View.GONE);
        } else {
            locationGroup.setVisibility(View.VISIBLE);
            location.setText(String.format("相距%s", item.getDistance()));
        }

        setServiceDate(item);

        View canMcoinGroup = findViewById(R.id.detail_can_mcoin_group);
        if (item.getPointSupport() == 1) {
            TextView canMcoin = (TextView) findViewById(R.id.detail_can_mcoin);
            canMcoin.setText("可用M豆");
        } else {
            canMcoinGroup.setVisibility(View.GONE);
        }

        View redPackSupportLayout = findViewById(R.id.redPackSupportLayout);
        if (item.getRedpackSupport()) {
            TextView canUseRed = (TextView) findViewById(R.id.redPackSupport);
            canUseRed.setText("可用红包");
        } else {
            redPackSupportLayout.setVisibility(View.GONE);
        }

        //todo 跳转到服务属性 待实现
        ViewGroup serviceScopeViewGroup = (ViewGroup) findViewById(R.id.detail_service_scope_group);
        ViewGroup detailServiceScopeLL = (ViewGroup) findViewById(R.id.detail_service_scope_ll);
        View serviceScopeRightIcon = findViewById(R.id.detail_service_scope_right);

        List<ScopeOutDO> scopeList = item.getItemScope();
        List<ScopeOutDO> tempList = new ArrayList<>();
        if (CollectionUtil.isNotEmpty(scopeList)) {
            int maxCount = Math.min(3, scopeList.size());
            if (maxCount >= 3) {
                serviceScopeRightIcon.setVisibility(View.VISIBLE);
                tempList.addAll(scopeList.subList(0, maxCount));
            } else {
                tempList.addAll(scopeList);
            }

//            detailServiceScopeLL.removeAllViews();
            for (ScopeOutDO scope : tempList) {
                View scopeView = inflater.inflate(R.layout.service_detail_scope, null);
                TextView keyText = (TextView) scopeView.findViewById(R.id.service_scope_key);
                TextView valueText = (TextView) scopeView.findViewById(R.id.service_scope_value);
                keyText.setText(scope.getName() + "：");
                valueText.setText(scope.getValue());
                detailServiceScopeLL.addView(scopeView);
            }

            serviceScopeViewGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Bundle bundle = new Bundle();
//                    bundle.putSerializable("service", item);
                    Router.sharedRouter().open("attribute/" + item.getItemId());
                }
            });
            serviceScopeViewGroup.setVisibility(View.VISIBLE);
        } else {
            serviceScopeViewGroup.setVisibility(View.GONE);
        }


        //todo 服务方式
        TextView serviceTypeView = (TextView) findViewById(R.id.detail_service_view);
        String serviceTypeValue = "服务方式：";
        switch (item.getServiceType()) {
            case 1:
                serviceTypeValue = new StringBuilder(serviceTypeValue).append(TextUtils.isEmpty(item.getCityName()) ? "" : item.getCityName()).append("上门").toString();
                break;
            case 2:
                serviceTypeValue = new StringBuilder(serviceTypeValue).append(TextUtils.isEmpty(item.getCityName()) ? "" : item.getCityName()).append("到店").toString();
                break;
            case 3:
                serviceTypeValue = serviceTypeValue + "线上";
                break;
            case 4:
                ((TextView) findViewById(R.id.detail_buy_bt)).setText("立即购买");
                //根据设置分为 现货邮寄、现做邮寄
                if (item.getIsSpot() == 1) {
                    serviceTypeValue = serviceTypeValue + "邮寄(现做)";
                } else {
                    serviceTypeValue = serviceTypeValue + "邮寄(定制)";
                }
                break;
        }
        serviceTypeView.setText(serviceTypeValue);


        // 服务地址，仅到店显示
//        View addressGroup = findViewById(R.id.detail_address_group);
//        TextView detailAddressValue = (TextView) findViewById(R.id.detail_address_value);
//        if (item.getAddressName() == null) {
//            addressGroup.setVisibility(View.GONE);
//        } else {
//            addressGroup.setVisibility(View.VISIBLE);
//            detailAddressValue.setText(item.getAddressName());
//        }

        //格子
        View squareGroup = findViewById(R.id.detail_square_group);
        TextView detailSquareValue = (TextView) findViewById(R.id.detail_square_name);

        if (item.getNearestGezi() == null) {
            squareGroup.setVisibility(View.GONE);
        } else {
            squareGroup.setVisibility(View.VISIBLE);
            squareGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("squareindex/" + item.getNearestGezi().getGeziId());
                }
            });

            detailSquareValue.setText("该服务来自 " + item.getNearestGezi().getGeziName());
        }

        View skuGroup = findViewById(R.id.detail_sku_group);
        TextView skuTitleView = (TextView) findViewById(R.id.detail_sku_name);

        if (!TextUtils.isEmpty(item.getSkuTitle())) {
            skuTitleView.setText(item.getSkuTitle());
        }

        if (Helper.sharedHelper().getUserId().equals(item.getUserId())) {
            skuGroup.setEnabled(false);
        }

        skuGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupPreOrderView();
            }
        });
    }

    void popupPreOrderView() {
        if (Helper.sharedHelper().hasToken()) {
            Bundle bundle = new Bundle();
            bundle.putString("itemId", itemId);
            Router.sharedRouter().open("preOrder", bundle);
        } else {
            Router.sharedRouter().open("signin");
        }
    }

    void renderLastSell(ServiceItem item) {
        latestSellGroup = (LinearLayout) findViewById(R.id.detail_latest_sell_ll);

        TextView latestSell = (TextView) findViewById(R.id.detail_latest_sell);
        long latestOrderTime = item.getLatestOrderTime();
        if (latestOrderTime > 0) {
            long offset = System.currentTimeMillis() / 1000 / 60 - latestOrderTime / 60;
            if (offset < 60) {
                latestSell.setText(offset + "分钟前卖出一笔");
            } else if (offset < (60 * 24)) {
                latestSell.setText((offset / 60) + "小时前卖出一笔");
            } else {
                latestSell.setText("一天前卖出一笔");
            }

            //最后一笔买家头像
            SimpleDraweeView lastBuyerAvatar = (SimpleDraweeView) findViewById(R.id.detail_latest_buyer_avatar);
            String avatarUrl = ImgUtil.getCDNUrlWithWidth(item.getLatestOrderUserAvatar(), lastBuyerAvatar.getLayoutParams().width);
            if (!TextUtils.isEmpty(avatarUrl)) {
                lastBuyerAvatar.setImageURI(Uri.parse(avatarUrl));
            }

            latestSellGroup.setVisibility(View.VISIBLE);
            Animation hyperspaceJumpAnimation = AnimationUtils.loadAnimation(this, R.anim.popwindow_right_in);
            latestSellGroup.startAnimation(hyperspaceJumpAnimation);

            handler.sendEmptyMessageDelayed(1, 5000);
        } else {
            latestSellGroup.setVisibility(View.GONE);
        }
    }

    Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                Animation hyperspaceJumpAnimation = AnimationUtils.loadAnimation(ServiceDetailActivity.this, R.anim.popwindow_right_out);
                latestSellGroup.startAnimation(hyperspaceJumpAnimation);

                hyperspaceJumpAnimation.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        latestSellGroup.setVisibility(View.GONE);

                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });
            }
        }
    };

    void renderPhotoView(final ServiceItem item) {
        if (CollectionUtil.isEmpty(item.getImages())) {
            adViewLayout.setVisibility(View.GONE);
            return;
        }

        ServiceDetailPhotoViewPageAdapter adViewPageAdapter = new ServiceDetailPhotoViewPageAdapter(this, item.getImages());
        adViewPageAdapter.setOnClickListener(new ServiceDetailPhotoViewPageAdapter.OnClickListener() {
            @Override
            public void onClick() {
                initPhotoListView(item);
            }
        });
        adViewPager.setAdapter(adViewPageAdapter);
        adViewIndicator.setViewPager(adViewPager);
        adViewLayout.setVisibility(View.VISIBLE);
        adViewIndicator.setOnPageChangeListener(this);
    }

    void renderSellerView(final ServiceItem item) {

        final UserOutDO seller = item.getUser();
        if (seller != null) {
            if (TextUtils.isEmpty(seller.getUserAvatar())) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(seller.getUserId()), seller.getUserGender());
                userAvatar.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(seller.getUserAvatar(), userAvatar.getLayoutParams().width));
                userAvatar.setImageURI(uri);
            }

            userAvatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("profile/" + seller.getUserId());
                }
            });

            if (!TextUtils.isEmpty(seller.getOnLineInfo())) {
                userOnLineStatusView.setText(seller.getOnLineInfo());
                userOnLineStatusView.setVisibility(View.VISIBLE);
            }

            userNickView.setText(seller.getUserName());

            if (seller.getUserGender() == null) {
                sexIcon.setVisibility(View.GONE);
            } else {
                if (seller.getUserGender().equals("woman") || seller.getUserGender().equals("F")) {
                    sexIcon.setText(context.getResources().getString(R.string.icon_gender_f));
                    sexIcon.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    sexIcon.setText(context.getResources().getString(R.string.icon_gender_m));
                    sexIcon.setTextColor(getResources().getColor(R.color.brand_i));
                }
            }

            //todo 城市 星座 个性标签
            try {
                if (CollectionUtil.isNotEmpty(seller.getUserTags())) {
                    for (UserTagOutDO tag : seller.getUserTags()) {
                        View tagView = getLayoutInflater().inflate(R.layout.service_detail_user_tag, null);
                        TextView tabText = (TextView) tagView.findViewById(R.id.user_tag_text);
                        if (!TextUtils.isEmpty(tag.getText())) {
                            tabText.setText(tag.getText());
                            tabText.setBackgroundColor(Color.parseColor(tag.getBgColor()));
                            userTagView.addView(tabText);
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("userTagParseError", e.getMessage());
            }

            //设置用户实名认证状态和技能认证状态
            if (seller.getRealNameCert() == 1) {
                realNameAuthStatus.setText("已实名认证");
            } else {
                realNameAuthStatus.setText("未实名认证");
            }

            if (TextUtils.isEmpty(seller.getZmLevel())) {
                zmLevel.setText("芝麻信用未绑定");
            } else {
                zmLevel.setText("芝麻信用" + seller.getZmLevel());
            }

            //todo 个性认证 显示数量问题
            List<String> certList = seller.getCertList();
            if (CollectionUtil.isNotEmpty(certList)) {
                skillAuth.setText(certList.get(0).toString());
                detail_skill_group.setVisibility(View.VISIBLE);
            }

            //用户头像 服务数&动态
            SimpleDraweeView gotoHomeUserAvatarView = (SimpleDraweeView) findViewById(R.id.detail_home_user_avatar);
            if (TextUtils.isEmpty(seller.getUserAvatar())) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(seller.getUserId()), seller.getUserGender());
                gotoHomeUserAvatarView.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(seller.getUserAvatar(), gotoHomeUserAvatarView.getLayoutParams().width));
                gotoHomeUserAvatarView.setImageURI(uri);
            }

            TextView serviceCountView = (TextView) findViewById(R.id.serviceCount);
            TextView opusCount = (TextView) findViewById(R.id.opusCount);
            serviceCountView.setText(item.getServiceCount());
            //作品秀
            opusCount.setText(item.getNewsCount());

            View gotoHomeView = findViewById(R.id.gotoLotteryListView);
            gotoHomeView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("profile/" + seller.getUserId());
                }
            });

        }
    }

    private void setServiceDate(ServiceItem item) {
        try {
            Calendar nextServiceTime = Calendar.getInstance();
            nextServiceTime.setTimeInMillis(item.getNextServiceTime());
            int serviceDay = nextServiceTime.get(Calendar.DAY_OF_YEAR);

            Calendar current = Calendar.getInstance();
            current.setTime(new Date());
            int currentDay = current.get(Calendar.DAY_OF_YEAR);

            TextView canTime = (TextView) findViewById(R.id.detail_can_time);
            canTime.setText(item.getReadableNextServiceTime() + "起有空");

            if (nextServiceTime.get(Calendar.YEAR) == current.get(Calendar.YEAR)) {
                if (serviceDay == currentDay) {
                    canTime.setText(getString(R.string.today_avilable));
                } else if ((serviceDay - currentDay) == 1) {
                    canTime.setText(getString(R.string.tomorrow_avilable));
                } else if ((serviceDay - currentDay) == 2) {
                    canTime.setText(getString(R.string.the_day_after_tomorrow_avilable));
                }
            } else {
                currentDay -= getMaxYear();
                if ((serviceDay - currentDay) == 1) {
                    canTime.setText(getString(R.string.tomorrow_avilable));
                } else if ((serviceDay - currentDay) == 2) {
                    canTime.setText(getString(R.string.the_day_after_tomorrow_avilable));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int getMaxYear() {
        Calendar cd = Calendar.getInstance();
        cd.set(Calendar.DAY_OF_YEAR, 1);// 把日期设为当年第一天
        cd.roll(Calendar.DAY_OF_YEAR, -1);// 把日期回滚一天。
        int MaxYear = cd.get(Calendar.DAY_OF_YEAR);
        return MaxYear;
    }

    private void renderFootView(final ServiceItem itemDO) {
        //todo 聊天
        /*
        点击聊一聊
         */
        ViewGroup chatBt = (ViewGroup) findViewById(R.id.chat_ll);
        SimpleDraweeView avatar = (SimpleDraweeView) findViewById(R.id.foot_user_avatar);
        //foot_user_avatar
        if (itemDO.getUser() != null) {
            String avatarUrl = ImgUtil.getCDNUrlWithWidth(itemDO.getUser().getUserAvatar(), avatar.getLayoutParams().width);
            if (!TextUtils.isEmpty(avatarUrl)) {
                avatar.setImageURI(Uri.parse(avatarUrl));
            }
        }


        chatBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //广告商品
                if (!StrUtil.isEmpty(itemDO.getLink())) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", itemDO.getLink());
                    Router.sharedRouter().open("web", bundle);
                }
                //进入聊一聊
                else {
                    String action = "chatFormService/";
                    if (itemDO.getUser() != null) {
                        action += itemDO.getUser().getUserId();
                        action += "/";
                    }
                    action += itemId;
//                    Bundle chatBundle = new Bundle();
//                    chatBundle.putString("itemPrice", itemDO.getPrice());
//                    chatBundle.putString("itemTitle", itemDO.getTag());
//                    chatBundle.putString("itemPic", itemDO.getImages().get(0));
//                    chatBundle.putString("receiveAvatar", itemDO.getUserAvatar());
//                    chatBundle.putString("receiveName", itemDO.getUserName());
                    if (Helper.sharedHelper().hasToken()) {
                        Router.sharedRouter().open(action);

                        LogParam param = new LogParam();
                        param.setType(LogUtil.TYPE_CUSTOMIZE);
                        param.setEid(LogUtil.EVENT_ID_CHAT_CLICK);
                        param.setPvid(itemDO.getPvid());
                        LogUtil.log(param);
                    } else {
//                        Bundle bundle = new Bundle();
//                        bundle.putString("action", action);
//                        bundle.putBundle("bundle", chatBundle);
                        Router.sharedRouter().open("signin");
                    }
                }
            }
        });

        //喜欢
        final TextView likeIconView = (TextView) findViewById(R.id.foot_like_icon);
        final TextView isLike = (TextView) findViewById(R.id.isLike);
        LinearLayout likeLayout = (LinearLayout) findViewById(R.id.like_ll);
        if (itemDO.getIsLike() != 0) {
            likeIconView.setText(getResources().getString(R.string.icon_star_active));
            likeIconView.setTextColor(getResources().getColor(R.color.brand_b));
            isLike.setText(getResources().getString(R.string.liked));
        }

        likeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    toggleIsLike(itemDO, likeIconView, isLike);
                } else {
                    jumpToLogin("services/" + itemId);
                    finish();
                }
            }
        });

        /*
        点击评论
         */
        View footPLLayout = findViewById(R.id.pl_ll);
        footPLLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    msgBoardItemListener.comment();
                } else {
                    jumpToLogin("services/" + itemId);
                }
            }
        });


        // 若是自己，隐藏立即预约和聊一聊
        ViewGroup earnestViewGroup = (ViewGroup) findViewById(R.id.earnest_ll);
        TextView earnestCountdownView = (TextView) findViewById(R.id.earnestCountdownView);
        TextView earnestPayButton = (TextView) findViewById(R.id.earnestPayButton);

        View buyBt = findViewById(R.id.detail_buy_bt);
        if (itemDO.getEditable() == 1) {
            chatBt.setVisibility(View.GONE);
            if (TextUtils.isEmpty(itemDO.getEarnest())) {
                buyBt.setVisibility(View.INVISIBLE);
                earnestViewGroup.setVisibility(View.GONE);
            } else {
                earnestViewGroup.setVisibility(View.INVISIBLE);
                buyBt.setVisibility(View.GONE);
            }
        } else {
            chatBt.setEnabled(true);
            buyBt.setEnabled(true);
            earnestPayButton.setEnabled(true);
            if (!TextUtils.isEmpty(itemDO.getEarnest())) {
                buyBt.setVisibility(View.GONE);
                earnestCountdownView.setText(itemDO.getFinalPayTime() + "后结束");
                earnestViewGroup.setVisibility(View.VISIBLE);
                earnestViewGroup.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupPreOrderView();
                    }
                });
            } else {
                earnestViewGroup.setVisibility(View.GONE);
                buyBt.setVisibility(View.VISIBLE);
                buyBt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupPreOrderView();
                    }
                });
            }
        }

    }

    //todo 价格和预约  需要优化
    private void renderPriceLayout(final ServiceItem item) {
        //特大活动标识
//        SimpleDraweeView bigPromotionIcon = (SimpleDraweeView) findViewById(R.id.bigPromotionIcon);
//        if (!TextUtils.isEmpty(item.getBigPromotionIcon())) {
//            bigPromotionIcon.setVisibility(View.VISIBLE);
//            bigPromotionIcon.setImageURI(Uri.parse(item.getBigPromotionIcon()));
//        }

        if (!TextUtils.isEmpty(item.getEarnest())) {
            earnestLayout.setVisibility(View.VISIBLE);
            earnestDetailLayout.setVisibility(View.VISIBLE);
            earnestValue.setText(String.format(getString(R.string.tail_yuan), item.getEarnest()));
            finalPayAmount.setText(String.format(getString(R.string.final_pay_amount), item.getFinalPay()));

            if (TextUtils.isEmpty(item.getPromotionPrice())) {
                earnestPrice.setText(String.format(getString(R.string.earnest_price), item.getPrice()));
                earnestOriPrice.setVisibility(View.GONE);
            } else {
                earnestPrice.setText(String.format(getString(R.string.earnest_price), item.getPromotionPrice()));
                earnestOriPrice.setText(String.format(getString(R.string.tail_yuan), item.getPrice()));
                earnestOriPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
                earnestOriPrice.setVisibility(View.VISIBLE);
            }
            earnestPayLink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", item.getPresellTip());
                    Router.sharedRouter().open("web", bundle);
                }
            });
            finalPayTime.setText(String.format(getString(R.string.final_pay_time), item.getFinalPayTime()));
            servicePriceLayout.setVisibility(View.GONE);

            LinearLayout earnestPromotionTagLayout = (LinearLayout) findViewById(R.id.earnestPromotionTagLayout);

            renderPromotionTagView(earnestPromotionTagLayout, item);
        } else {
            earnestDetailLayout.setVisibility(View.GONE);
            earnestLayout.setVisibility(View.GONE);
            servicePriceLayout.setVisibility(View.VISIBLE);

            //促销活动标识
            TextView promotionTag = (TextView) findViewById(R.id.detail_promotion_tag);
            TextView price = (TextView) findViewById(R.id.detail_price);
            TextView oriPrice = (TextView) findViewById(R.id.detail_origin_price);
            if (TextUtils.isEmpty(item.getPromotionPrice())) {
                price.setText(String.format(getString(R.string.tail_yuan), item.getPrice()));
            } else {
                promotionTag.setVisibility(View.VISIBLE);
                price.setText(String.format(getString(R.string.tail_yuan), item.getPromotionPrice()));
                oriPrice.setText(String.format(getString(R.string.tail_yuan), item.getPrice()));
                oriPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
                oriPrice.setVisibility(View.VISIBLE);
            }

            LinearLayout normalPromotionTagLayout = (LinearLayout) findViewById(R.id.normalPromotionTagLayout);
            renderPromotionTagView(normalPromotionTagLayout, item);
        }

    }

    void renderPromotionTagView(LinearLayout promotionTagLayout, ServiceItem service) {
        if (CollectionUtil.isNotEmpty(service.getPromotionTips())) {
            for (String tag : service.getPromotionTips()) {
                View promotionView = LayoutInflater.from(this).inflate(R.layout.item_promotion_tag, promotionTagLayout, false);
                ((TextView) promotionView.findViewById(R.id.textItemTag)).setText(tag);
                promotionTagLayout.addView(promotionView);
            }
        }
    }

    private void toggleIsLike(ServiceItem item, TextView icon, TextView text) {

        if (item.getIsLike() == 0) {
            likeReq(item, true, icon, text);
        } else {
            likeReq(item, false, icon, text);
        }
    }


    private void likeReq(final ServiceItem item, Boolean isLike, final TextView icon, final TextView text) {
        try {
            JSONObject params = new JSONObject();
            params.put("itemId", itemId);
            if (isLike) {
                RequestService.addAttention(params, new MeidaRestClient.RestCallback() {
                    @Override
                    public void onSuccess(Object result) {
                        MessageUtils.showToastCenter(getResources().getString(R.string.add_like_success));
                        // 改变样式
                        item.setIsLike(1);
//                        item.setLikeCount(item.getLikeCount() + 1);
                        icon.setTextColor(getResources().getColor(R.color.brand_b));
                        icon.setText(getResources().getString(R.string.icon_star_active));
                        text.setText(getResources().getString(R.string.liked));
                        // 喜欢列表
//                        likeCount = likeCount + 1;
//                        likeSize.setText("收藏（" + likeCount + "）");
//                        ServiceItem.ViewUser user = new ServiceItem.ViewUser();
//                        user.setUserAvatar(Helper.sharedHelper().getStringUserInfo(Constant.USER_PIC));
//                        user.setUserId(Helper.sharedHelper().getStringUserInfo(Constant.USER_ID));
//                        ArrayList<ServiceItem.ViewUser> likeList = item.getLikeUsers();
//                        likeList.add(0, user);
//                        showLikeAvatar(likeList);
                    }

                    @Override
                    public void onFailure(HttpError error) {
                    }
                });
            } else {
                RequestService.delAttention(params, new MeidaRestClient.RestCallback() {
                    @Override
                    public void onSuccess(Object result) {
                        MessageUtils.showToastCenter(getResources().getString(R.string.cancel_like_success));
                        // 改变样式
                        item.setIsLike(0);
//                        item.setLikeCount(item.getLikeCount() - 1);
                        icon.setTextColor(getResources().getColor(R.color.brand_d));
                        icon.setText(getResources().getString(R.string.icon_star_normal));
                        text.setText(getResources().getString(R.string.like));
                        // 喜欢列表 去掉收藏列表
//                        likeCount = likeCount - 1;
//                        likeSize.setText("收藏（" + likeCount + "）");
//                        String userId = Helper.sharedHelper().getStringUserInfo(Constant.USER_ID);
//                        ArrayList<ServiceItem.ViewUser> likeList = item.getLikeUsers();
//                        for (int i = 0; i < likeList.size(); i++) {
//                            ServiceItem.ViewUser u = likeList.get(i);
//                            if (userId.equals(u.getUserId())) {
//                                likeList.remove(i);
//                                break;
//                            }
//                        }
//                        showLikeAvatar(likeList);
                    }

                    @Override
                    public void onFailure(HttpError error) {
                        MessageUtils.showToastCenter(error.getMessage());
                    }
                });
            }
        } catch (JSONException e) {
        }
    }

    public com.alibaba.fastjson.JSONObject getCommentParams() {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", 2);
        params.put("offset", 0);
        params.put("typeList", "1");
        return params;
    }

    public com.alibaba.fastjson.JSONObject genMsgParams(int page) {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", pageSize);
        params.put("offset", page * pageSize);
        params.put("typeList", "2,4");
        return params;
    }

    public void loadComment() {

        RequestCommentOpr.skuCommentList(getCommentParams(), new HttpClient.HttpCallback<SkuCommentOutDO>() {
            @Override
            public void onSuccess(SkuCommentOutDO skuCommentOutDO) {

                if (skuCommentOutDO != null && CollectionUtil.isNotEmpty(skuCommentOutDO.getComments())) {
                    SkuCommentAdapter commentAdapter = new SkuCommentAdapter(ServiceDetailActivity.this, skuCommentOutDO.getComments());
                    commentListView.setAdapter(commentAdapter);
                    commentViewGroup.setVisibility(View.VISIBLE);
                }

                detailFooter.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(ServiceDetailActivity.class.getName(), "req comment data fail, itemId=" + itemId + ", " + error.toString());
                action_bar_button_back.setTextColor(getResources().getColor(R.color.black));
                action_bar_button_right.setVisibility(View.GONE);
                detailFooter.setVisibility(View.VISIBLE);

//                action_bar_button_back.setTextColor(getResources().getColor(R.color.black));
//                action_bar_button_right.setVisibility(View.GONE);

//                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
//                    showStatusErrorNetwork(contentRoot, new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            initLoadData();
//                        }
//                    });
//                    return;
//                }
//                showStatusErrorServer(contentRoot, error, new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        initLoadData();
//                    }
//                });
            }
        });
    }

    public void loadMsg(final boolean reload) {
        if (isComplete) {
            return;
        }

        if (isLoading) {
            return;
        }
        isLoading = true;
        if (reload) {
            page = 0;
            msgList.clear();
        } else {
            //loadMore
            footProgressBar.setVisibility(View.VISIBLE);
        }

        RequestCommentOpr.skuCommentList(genMsgParams(page), new HttpClient.HttpCallback<SkuCommentOutDO>() {
            @Override
            public void onSuccess(SkuCommentOutDO skuComment) {
                isLoading = false;
                detailFooter.setVisibility(View.VISIBLE);
                if (!reload) {
                    footProgressBar.setVisibility(View.GONE);
                }

                List<CommentDO> commentList = null;
                if (skuComment != null) {
                    commentList = skuComment.getComments();
                }

                if (CollectionUtil.isEmpty(commentList) || commentList.size() < pageSize) {
                    isComplete = true;
                }

                if (CollectionUtil.isNotEmpty(commentList)) {
                    msgList.addAll(commentList);
                    page++;
                }

                if (CollectionUtil.isNotEmpty(msgList)) {
                    noMsgView.setVisibility(View.GONE);
                    msgBoardView.setOnScrollListener(ServiceDetailActivity.this);
                } else {
                    noMsgView.setVisibility(View.VISIBLE);
                }

                msgAdapter.notifyDataSetChanged();

            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                if (!reload) {
                    footProgressBar.setVisibility(View.GONE);
                }

                action_bar_button_back.setTextColor(getResources().getColor(R.color.black));
                action_bar_button_right.setVisibility(View.GONE);

                detailFooter.setVisibility(View.VISIBLE);

                Log.e(ServiceDetailActivity.class.getName(), "req comment data fail, itemId=" + itemId + ", " + error.toString());

            }
        });
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
            if (view.getLastVisiblePosition() == view.getCount() - 1) {
                loadMsg(false);
            }

            if (msgBoardView.getFirstVisiblePosition() == 0 || msgBoardView.getLastVisiblePosition() == (msgBoardView
                    .getCount() - 1)) {
                changeTitleBarBg();
            }
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

    }

    public int getScrollY() {
        View c = msgBoardView.getChildAt(0);
        if (c == null) {
            return 0;
        }
        int firstVisiblePosition = msgBoardView.getFirstVisiblePosition();
        int top = c.getTop();
        return -top + firstVisiblePosition * c.getHeight();
    }

    private void jumpToLogin(String action) {
        Bundle bundle = new Bundle();
        bundle.putString("action", action);
        Router.sharedRouter().open("signin", bundle);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    public class CommentItemListener implements AdapterView.OnItemClickListener, TextView.OnClickListener {

        private CommentAdapter.PJViewHolder pre;
        private InputMethodManager keyboard;

        private EditText inputText;
        private View inputViewGroup;
        private View detailFoot;

        private Handler handler = new Handler();

        public CommentItemListener(EditText inputText, View inputViewGroup, View detailFoot) {
            keyboard = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            this.inputText = inputText;
            this.inputViewGroup = inputViewGroup;
            this.detailFoot = detailFoot;
        }

        @Override
        public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
            if (!Helper.sharedHelper().hasToken()) {
                finish();
                jumpToLogin("services/" + itemId);
                return;
            }

            inputText.setHint(null);

            if (pre == null && (null != view.getTag())) {
                CommentAdapter.PJViewHolder curr = (CommentAdapter.PJViewHolder) view.getTag();
                inputText.setFocusable(true);
                inputText.setFocusableInTouchMode(true);
                inputText.requestFocus();
                String nick = "";
                if (null != curr.buyNick && null != curr.buyNick.getText()) {
                    nick = curr.buyNick.getText().toString();
                }
                inputText.setHint("回复:" + nick);
                keyboard.showSoftInput(inputText, InputMethodManager.SHOW_IMPLICIT);
                pre = curr;
                inputViewGroup.setVisibility(View.VISIBLE);
                detailFoot.setVisibility(View.GONE);
            } else {
                hideKeyword();
            }
        }

        public void onClick(View v) {
            if (!Helper.sharedHelper().hasToken()) {
                finish();
                jumpToLogin("services/" + itemId);
                return;
            }

            keyboard.hideSoftInputFromWindow(v.getWindowToken(), 0);
            String content = inputText.getText().toString();

            if (StrUtil.isEmpty(content)) {
                Toast.makeText(context, "请输入内容", Toast.LENGTH_LONG).show();
                return;
            }

            String commentId = null;
            int type = 4;       // 默认，普通留言
            if (pre != null) {       // 普通回复
                commentId = pre.commentId;
                type = 2;
            }
            RequestCommentOpr.addComment(itemId, null, commentId, null, content, null, type, new HttpClient.HttpCallback<CommentDO>() {

                @Override
                public void onSuccess(CommentDO obj) {
                    Toast.makeText(context, "发表成功", Toast.LENGTH_SHORT).show();
                    msgBoardView.setVisibility(View.VISIBLE);
                    inputViewGroup.setVisibility(View.GONE);
                    detailFoot.setVisibility(View.VISIBLE);
                    noMsgView.setVisibility(View.GONE);
                    msgAdapter.addHead(obj);
                    msgAdapter.notifyDataSetChanged();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            msgBoardView.setSelection(msgBoardView.getBottom());
                        }
                    }, 50);
                    msgCountTextView.setVisibility(View.VISIBLE);
                    msgCount = msgCount + 1;
                    msgCountTextView.setText(msgCount + "条评论");
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToastCenter(error.toString());
                }

            });
            inputText.setText(null);    // 清空数据
            inputText.setHint(null);
            pre = null;
        }

        public void comment() {
            inputText.setFocusable(true);
            inputText.setFocusableInTouchMode(true);
            inputText.requestFocus();
            inputText.setHint(null);
            keyboard.showSoftInput(inputText, InputMethodManager.SHOW_IMPLICIT);
            inputViewGroup.setVisibility(View.VISIBLE);
            detailFoot.setVisibility(View.GONE);
        }

        public void hideKeyword() {
            keyboard.hideSoftInputFromWindow(inputText.getWindowToken(), 0);
            inputText.setText(null);
            inputViewGroup.setVisibility(View.GONE);
            detailFoot.setVisibility(View.VISIBLE);
            pre = null;
        }

    }

    @OnClick(R.id.action_bar_button_back)
    public void myHandleBack(View v) {
        handleBack(v);
    }

    @OnClick(R.id.action_bar_button_right)
    public void initPopupWindow(final View v) {

        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(this, R.layout.popup_window_share_menu, ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        List<MenuVO> menuList = new ArrayList<>();

        menuList.add(MENU_ITEM_SHARE, new MenuVO(R.string.icon_share, getString(R.string.label_share), 1));
        menuList.add(MENU_ITEM_SEARCH, new MenuVO(R.string.icon_search, getString(R.string.search), 1));
        menuList.add(MENU_ITEM_HOME, new MenuVO(R.string.tab_item_home_icon_normal, getString(R.string.tab_item_home_text), 1));
        menuList.add(MENU_ITEM_JUBAO, new MenuVO(R.string.icon_jubao, getString(R.string.report), 1));

        mPopupListMenu.setMenuData(menuList);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAsDropDown(v, -50, 0);
        }


        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_SHARE: {
                        shareService(v);
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_SEARCH: {
                        Router.sharedRouter().open("search_res");
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_HOME: {
                        Router.sharedRouter().open("main");
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_JUBAO: {
                        reportService();
                        mPopupListMenu.dismiss();
                        break;
                    }
                }
            }
        });
    }

    private void shareService(View v) {
        if (shareDO != null) {
            LogParam param = new LogParam();
            param.setType(LogUtil.TYPE_CUSTOMIZE);
            param.setEid(LogUtil.EVENT_ID_SHARE_CLICK);
            param.setPvid(shareDO.getPvid());
            LogUtil.log(param);
        }

        if (socialSharePopupWindow == null) {
            socialSharePopupWindow = new SocialSharePopupWindow(this, shareDO,
                    new ShareActivity(this), SocialSharePopupWindow.SHARE_TYPE_SERVICE);
        }
        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }


    private void reportService() {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", String.valueOf(itemId));
        intent.putExtra("target", Constant.REPORT_TYPE_SERVICE);
        startActivity(intent);
    }


    //改变导航背景
    private void changeTitleBarBg() {
        // 获取头布局
        if (mainView != null) {
            // 获取头布局现在的最上部的位置的相反数
            int top = -mainView.getTop();
            // 获取头布局的高度
            headerHeight = mainView.getHeight();
            // 满足这个条件的时候，是头布局在Listview的最上面第一个控件的时候，只有这个时候，我们才调整透明度
            if (top <= headerHeight / 5) {
                titleBarAlpha = 255;
                titleBar.getBackground().setAlpha(0);
                // 通知标题栏刷新显示
                titleBar.invalidate();

                action_bar_title.setTextColor(Color.argb(0, 113, 63, 49));
                action_bar_button_back.setTextColor(Color.argb(255, 255, 255, 255));
                action_bar_button_right.setTextColor(Color.argb(255, 255, 255, 255));
            } else {
                // 获取当前位置占头布局高度的百分比
                float f = (float) top / (float) (headerHeight / 5);
                titleBarAlpha = (int) (f * 255);
                titleBar.getBackground().setAlpha(titleBarAlpha);
                titleBar.setBackgroundColor(getResources().getColor(R.color.white));

                // 通知标题栏刷新显示
                titleBar.invalidate();
                action_bar_title.setTextColor(getResources().getColor(R.color.brand_c));
                action_bar_button_back.setTextColor(getResources().getColor(R.color.brand_c));
                action_bar_button_right.setTextColor(getResources().getColor(R.color.brand_c));
            }
        }
    }

    //初始化导航背景
    private void initTitleBarBg() {
        titleBar.getBackground().setAlpha(0);
        action_bar_title.setTextColor(Color.argb(0, 113, 63, 49));
        action_bar_button_back.setTextColor(Color.argb(255, 255, 255, 255));
        action_bar_button_right.setTextColor(Color.argb(255, 255, 255, 255));
    }
}
