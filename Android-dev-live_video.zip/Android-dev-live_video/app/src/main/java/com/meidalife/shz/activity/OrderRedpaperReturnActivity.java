package com.meidalife.shz.activity;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.util.StrUtil;
import com.umeng.socialize.media.UMImage;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/12/15.
 */
public class OrderRedpaperReturnActivity extends Activity {
    boolean isRequesting = false;
    String redpackValue;
    String redpackDesc;
    String shareTitle;
    String shareContent;
    String shareIcon;
    String shareUrl;
    String orderNo;
    UMImage shareImage;

    @Bind(R.id.redPaperTitle)
    TextView redpaperTitle;
    @Bind(R.id.redpaperDesc)
    TextView redpaperDesc;

    @Bind(R.id.resultTitle)
    TextView resultTitle;
    @Bind(R.id.resultDesc)
    TextView resultDesc;
    @Bind(R.id.shareLayout)
    ViewGroup redpaperShareLayout;
    @Bind(R.id.wechatShareLayout)
    ViewGroup wechatShareLayout;
    @Bind(R.id.wechatCircleShareLayout)
    ViewGroup wechatCircleShareLayout;
    @Bind(R.id.weiboShareLayout)
    ViewGroup weiboShareLayout;
    @Bind(R.id.qqShareLayout)
    ViewGroup qqShareLayout;
    @Bind(R.id.iconClose)
    TextView iconClose;

    ShareActivity shareActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_redpaper_return);
        ButterKnife.bind(this);
        intiData();
    }

    private void intiData() {
        redpackValue = getIntent().getStringExtra(Constant.EXTRA_TAG_AMOUNT);
        redpackDesc = getIntent().getStringExtra(Constant.EXTRA_TAG_DESC);
        shareTitle = getIntent().getStringExtra(Constant.EXTRA_TAG_SHARE_TITLE);
        shareContent = getIntent().getStringExtra(Constant.EXTRA_TAG_SHARE_CONTENT);
        shareIcon = getIntent().getStringExtra(Constant.EXTRA_TAG_SHARE_ICON);
        shareUrl = getIntent().getStringExtra(Constant.EXTRA_TAG_SHARE_URL);
        orderNo = getIntent().getStringExtra(Constant.EXTRA_TAG_ORDER_NO);
        redpaperTitle.setText(shareTitle);
        redpaperDesc.setText(redpackDesc);

        if (TextUtils.isEmpty(shareIcon)) {
            shareImage = new UMImage(this, R.mipmap.ic_launcher);
        } else {
            shareImage = new UMImage(this, shareIcon);
        }
        shareActivity = new ShareActivity(this);

        iconClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        wechatShareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareActivity.shareWithWeChat(OrderRedpaperReturnActivity.this,
                        shareTitle, shareContent, shareUrl, shareImage);

                gainReturnRedpaper();
            }
        });

        wechatCircleShareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareActivity.shareWithWxCircle(OrderRedpaperReturnActivity.this,
                        shareTitle, shareContent, shareUrl, shareImage);
                gainReturnRedpaper();

            }
        });

        weiboShareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareActivity.shareWithWeibo(OrderRedpaperReturnActivity.this,
                        shareTitle, shareContent, shareUrl, shareImage);
                gainReturnRedpaper();
            }
        });

        qqShareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareActivity.shareWithQQ(OrderRedpaperReturnActivity.this,
                        shareTitle, shareContent, shareUrl, shareImage);
                gainReturnRedpaper();
            }
        });
    }

    private void gainReturnRedpaper() {
        if (isRequesting) {
            return;
        }

        JSONObject params = new JSONObject();
        params.put("orderNO", orderNo);
        isRequesting = true;
        HttpClient.get("1.0/redpack/gainOrderReturnRedpack", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        isRequesting = false;
                        if (obj == null) {
                            return;
                        }
                        String amount = obj.getString("totalMoney");
                        if (!TextUtils.isEmpty(amount)) {
                            redpaperTitle.setVisibility(View.GONE);
                            redpaperDesc.setVisibility(View.GONE);
                            resultTitle.setVisibility(View.VISIBLE);
                            resultDesc.setVisibility(View.VISIBLE);
                            resultDesc.setText(StrUtil.getDigitSpanText(String.format(getString(R.string.get_redpaper_success_desc2), amount),
                                    getResources().getColor(R.color.brand_b), getResources().getDimensionPixelSize(R.dimen.font_size_large_xx)));
                            redpaperShareLayout.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        isRequesting = false;
                        MessageUtils.showToast(error.toString());
                        Log.d("OrderRedpaperReturn", error.getMessage());
                    }
                });
    }
}
