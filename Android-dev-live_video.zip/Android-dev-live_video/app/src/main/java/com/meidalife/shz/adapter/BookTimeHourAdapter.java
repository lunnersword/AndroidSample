package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.TimeVO;

import java.util.ArrayList;

/**
 * Created by taber on 15/6/18.
 */
public class BookTimeHourAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<TimeVO.HourVO> mData;
    LayoutInflater mInflater;

    static class ViewHolder {
        public TextView hour;
    }

    public BookTimeHourAdapter(Context c, ArrayList<TimeVO.HourVO> data) {
        mContext = c;
        mData = data;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return mData.size();
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    public boolean isEnabled(int position) {
        TimeVO.HourVO item = mData.get(position);
        return (int) item.getEnabled() == 1;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            convertView = mInflater.inflate(R.layout.view_select_hour, parent, false);
            TextView hour = (TextView) convertView.findViewById(R.id.hour);
            holder = new ViewHolder();
            holder.hour = hour;
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        // set data
        TimeVO.HourVO item = mData.get(position);
        holder.hour.setText(item.getHour());
        if (item.getEnabled() == 0) {
            convertView.setEnabled(false);
        } else {
            convertView.setEnabled(true);
        }
        return convertView;
    }
}
