package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ServiceNotPutOnSaleActivity extends BaseActivity {
    @Bind(R.id.publishHintTitle)
    TextView publishHintTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_not_put_on_sale);
        ButterKnife.bind(this);
        Bundle bundle = getIntent().getExtras();
        String serviceItemId = bundle.getString("itemId");
        boolean bindGezi = bundle.getBoolean("bindGezi", false);
        boolean isEditMode = getIntent().getBooleanExtra(Constant.EXTRA_TAG_EDIT_MODE, false);
        publishHintTitle.setText(isEditMode ? "保存成功，但未成功上架" : "发布成功，但未成功上架");
        if (bindGezi) {
            Bundle params = new Bundle();
            params.putString("serviceId", serviceItemId);
            params.putInt("type", ServiceJoinSquareActivity.ADD_SERVICE_TO_SQUARES);
            Router.sharedRouter().open("serviceJoinSquare", params);
        }
    }

    @OnClick(R.id.btnComplete)
    public void handleComplete(View view) {
        finish();
    }

    public void handleCertificate(View view) {
        Router.sharedRouter().open("certificationlist");
        finish();
    }

    public void handleContinuePublish(View view) {
        Router.sharedRouter().open("publish");
        finish();
    }

}
