package com.meidalife.shz.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bugtags.library.Bugtags;
import com.meidalife.shz.BuildConfig;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.widget.PopupListMenu;
import com.squareup.leakcanary.RefWatcher;
import com.umeng.analytics.MobclickAgent;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by taber on 15/6/17.
 */
public class BaseActivity extends AppCompatActivity {
    private static final int MENU_ITEM_CANCEL = 1;
    private static final int MENU_ITEM_REPORT = 0;

    private ProgressDialog progressDialog;
    private ActionBar mActionBar;
    public TextView mTextTitle;
    public Button mButtonBack;
    public Button mButtonRight;

    // public LinearLayout cellStatusLoading;
    //  private AnimationDrawable loadingAnimation;
    public LinearLayout cellStatusErrorNetwork;
    public LinearLayout cellStatusErrorServer;
    public TextView textStatusErrorServer;

    public LinearLayout cellStatusDotLoading;

    PopupListMenu mPopupListMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mActionBar = getSupportActionBar();
        hideActionBar();
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);
        reportResume();
        if (BuildConfig.SHOW_BUG_TAG) {
            Bugtags.onResume(this);
        }
    }

    public void reportResume() {
        LogUtil.log(LogUtil.TYPE_START_PAGE, this.getClass().getName());
    }

    @Override
    public void onPause() {
        hideProgressDialog();
        super.onPause();
        MobclickAgent.onPause(this);
        reportPause();
        if (BuildConfig.SHOW_BUG_TAG) {
            Bugtags.onPause(this);
        }
    }

    public void reportPause() {
        LogUtil.log(LogUtil.TYPE_EXIT_PAGE, this.getClass().getName());
    }

    @Override
    protected void onDestroy() {
        hideProgressDialog();
        if (BuildConfig.DEBUG) {
            RefWatcher refWatcher = SHZApplication.getRefWatcher(this);
            refWatcher.watch(this);
        }
        super.onDestroy();
    }

    public void initActionBar(int resId) {
        initActionBar(resId, false, false);
    }

    public void initActionBar(int resId, Boolean showBackButton) {
        initActionBar(resId, showBackButton, false);
    }

    public void initActionBar(int resId, Boolean showBackButton, Boolean showRightButton) {
        getActionBarBackButton();
        getActionBarRightButton();
        setActionBarTitle(resId);
        if (showBackButton) {
            showActionBarBackButton();
        } else {
            hideActionBarBackButton();
        }
        if (showRightButton) {
            showActionBarRightButton();
        } else {
            hideActionBarRightButton();
        }
    }

    public void initActionBar(String title, Boolean showBackButton, Boolean showRightButton) {
        getActionBarBackButton();
        getActionBarRightButton();
        setActionBarTitle(title);
        if (showBackButton) {
            showActionBarBackButton();
        } else {
            hideActionBarBackButton();
        }
        if (showRightButton) {
            showActionBarRightButton();
        } else {
            hideActionBarRightButton();
        }
    }

    public void initBackBar(Boolean showBackButton) {
        getActionBarBackButton();
        if (showBackButton) {
            showActionBarBackButton();
        } else {
            hideActionBarBackButton();
        }
    }

    public void showActionBar(String title) {
        if (null != mActionBar) {
            mActionBar.show();
            mActionBar.setTitle(title);
        }
    }

    public void hideActionBar() {
        if (null != mActionBar) {
            mActionBar.hide();
        }
    }


    public void handleBack(View view) {
        onBackPressed();
    }

    public void setActionBarTitle(int resId) {
        setActionBarTitle(getString(resId));
    }

    public void setActionBarTitle(String title) {
        if (mTextTitle == null) {
            mTextTitle = (TextView) findViewById(R.id.action_bar_title);
        }
        if (mTextTitle != null) {
            mTextTitle.setText(title);
        }
    }

    public void showActionBarBackButton() {
        if (mButtonBack != null) {
            mButtonBack.setVisibility(View.VISIBLE);
        }
    }

    public void hideActionBarBackButton() {
        if (mButtonBack != null) {
            mButtonBack.setVisibility(View.GONE);
        }
    }

    public void showActionBarRightButton() {
        if (mButtonRight != null) {
            mButtonRight.setVisibility(View.VISIBLE);
        }
    }

    public void hideActionBarRightButton() {
        if (mButtonRight != null) {
            mButtonRight.setVisibility(View.GONE);
        }
    }

    public void hideIMM() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    public synchronized void showProgressDialog(int strId) {
        showProgressDialog(getString(strId), true);
    }

    public synchronized void showProgressDialog(int strId, boolean cancelable) {
        showProgressDialog(getString(strId), cancelable);
    }

    public synchronized void showProgressDialog(String msg) {
        showProgressDialog(msg, true);
    }

    public synchronized void showProgressDialog(String msg, boolean cancelable) {
        if (progressDialog == null) {
            progressDialog = MessageUtils.getProgressDialog(this, msg);
        }
        progressDialog.setCancelable(cancelable);
        progressDialog.setMessage(msg);
        if (!isFinishing()) {
            progressDialog.show();
        }
    }

    public void setOnProgressDismissListener(DialogInterface.OnCancelListener l) {
        if (progressDialog != null) {
            progressDialog.setOnCancelListener(l);
        }
    }

    public synchronized void hideProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    public void getCellStatusErrorNetwork(ViewGroup parent) {
        if (cellStatusErrorNetwork == null) {
            cellStatusErrorNetwork = (LinearLayout) getLayoutInflater().inflate(R.layout.status_error_network, null);
            ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(parent.getLayoutParams().width,
                    parent.getLayoutParams().height);
            cellStatusErrorNetwork.setLayoutParams(layoutParams);
        }
    }

    public void showStatusErrorNetwork(ViewGroup parent) {
        getCellStatusErrorNetwork(parent);
        ViewGroup oldParent = (ViewGroup) cellStatusErrorNetwork.getParent();

        if (oldParent != null) {
            oldParent.removeView(cellStatusErrorNetwork);
        }
        parent.addView(cellStatusErrorNetwork);
        cellStatusErrorNetwork.setVisibility(View.VISIBLE);
    }

    public void showStatusErrorNetwork(ViewGroup parent, View.OnClickListener listener) {
        getCellStatusErrorNetwork(parent);
        ViewGroup oldParent = (ViewGroup) cellStatusErrorNetwork.getParent();

        if (oldParent != null) {
            oldParent.removeView(cellStatusErrorNetwork);
        }
        parent.addView(cellStatusErrorNetwork);
        cellStatusErrorNetwork.setVisibility(View.VISIBLE);
        if (null != listener) {
            cellStatusErrorNetwork.setOnClickListener(listener);
        }
    }

    public void hideStatusErrorNetwork() {
        if (cellStatusErrorNetwork != null) {
            cellStatusErrorNetwork.setVisibility(View.GONE);
        }
    }

    public void getCellStatusErrorServer(ViewGroup parent) {
        if (cellStatusErrorServer == null) {
            cellStatusErrorServer = (LinearLayout) getLayoutInflater().inflate(R.layout.status_error_server, null);
            ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(parent.getLayoutParams().width, parent.getLayoutParams().height);
            layoutParams.height = parent.getLayoutParams().height;
            cellStatusErrorServer.setLayoutParams(layoutParams);
        }
    }

    public void showStatusErrorServer(ViewGroup parent) {
        getCellStatusErrorServer(parent);
        ViewGroup oldParent = (ViewGroup) cellStatusErrorServer.getParent();

        if (oldParent != null) {
            oldParent.removeView(cellStatusErrorServer);
        }
        parent.addView(cellStatusErrorServer);
        cellStatusErrorServer.setVisibility(View.VISIBLE);
    }

    public void showStatusErrorServer(ViewGroup parent, View.OnClickListener listener) {
        getCellStatusErrorServer(parent);
        ViewGroup oldParent = (ViewGroup) cellStatusErrorServer.getParent();

        if (oldParent != null) {
            oldParent.removeView(cellStatusErrorServer);
        }
        parent.addView(cellStatusErrorServer);
        cellStatusErrorServer.setVisibility(View.VISIBLE);
        if (listener != null) {
            cellStatusErrorServer.setOnClickListener(listener);
        }
    }

    public void showStatusErrorServer(ViewGroup parent, HttpError error, View.OnClickListener listener) {
        getCellStatusErrorServer(parent);
        ViewGroup oldParent = (ViewGroup) cellStatusErrorServer.getParent();

        if (oldParent != null) {
            oldParent.removeView(cellStatusErrorServer);
        }
        parent.addView(cellStatusErrorServer);
        cellStatusErrorServer.setVisibility(View.VISIBLE);
        if (listener != null) {
            cellStatusErrorServer.setOnClickListener(listener);
        }

        if (error != null) {
            TextView errorTipView = (TextView) cellStatusErrorServer.findViewById(R.id.textStatusErrorServer);
            errorTipView.setText(error.toString());
        }
    }

    public void hideStatusErrorServer() {
        if (cellStatusErrorServer != null) {
            cellStatusErrorServer.setVisibility(View.GONE);
        }
    }

    public void showStatusLoading(ViewGroup parent) {
        if (cellStatusDotLoading == null) {
            cellStatusDotLoading = (LinearLayout) getLayoutInflater().inflate(R.layout.status_loading_dotted, null);
            ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(parent.getLayoutParams().width,
                    parent.getLayoutParams().height);
            layoutParams.height = parent.getLayoutParams().height;
            cellStatusDotLoading.setLayoutParams(layoutParams);
        }
        ViewGroup oldParent = (ViewGroup) cellStatusDotLoading.getParent();

        if (oldParent != null) {
            oldParent.removeView(cellStatusDotLoading);
        }
        parent.addView(cellStatusDotLoading);
        cellStatusDotLoading.setVisibility(View.VISIBLE);
    }

//    public void showStatusLoading(ViewGroup parent) {
//        if (cellStatusLoading == null) {
//            cellStatusLoading = (LinearLayout) getLayoutInflater().inflate(R.layout.status_loading, parent, false);
//            ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(parent.getLayoutParams().width,
//                    parent.getLayoutParams().height);
//            layoutParams.height = parent.getLayoutParams().height;
//            cellStatusLoading.setLayoutParams(layoutParams);
//        }
//        ViewGroup oldParent = (ViewGroup) cellStatusLoading.getParent();
//
//        if (oldParent != null) {
//            oldParent.removeView(cellStatusLoading);
//        }
//        parent.addView(cellStatusLoading);
//
//        cellStatusLoading.setVisibility(View.VISIBLE);
//
//        try {
//            AnimationDrawable loadingAnimation;
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//                loadingAnimation = (AnimationDrawable) (SHZApplication.getInstance().getDrawable(R.drawable.loading_animation));
//            } else {
//                loadingAnimation = (AnimationDrawable) (SHZApplication.getInstance().getResources().
//                        getDrawable(R.drawable.loading_animation));
//            }
//            ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
//
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
//                loadingImage.setBackground(loadingAnimation);
//            } else {
//                loadingImage.setBackgroundDrawable(loadingAnimation);
//            }
//            if (loadingAnimation != null) {
//                loadingAnimation.start();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    public void hideStatusLoading() {
        if (cellStatusDotLoading != null) {
            cellStatusDotLoading.setVisibility(View.GONE);
        }
    }

//    public void hideStatusLoading() {
//        try {
//            if (cellStatusLoading != null) {
//                cellStatusLoading.setVisibility(View.GONE);
//                if (null != loadingAnimation) {
//                    loadingAnimation.stop();
//                    loadingAnimation = null;
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    public void setTextErrorServer(String message) {
        if (cellStatusErrorServer != null) {
            if (textStatusErrorServer == null) {
                textStatusErrorServer = (TextView) cellStatusErrorServer.findViewById(R.id.textStatusErrorServer);
            }
            textStatusErrorServer.setText(message);
        }
    }

    public void setOnClickErrorNetwork(View.OnClickListener onClickErrorNetwork) {
        if (cellStatusErrorNetwork != null) {
            cellStatusErrorNetwork.setOnClickListener(onClickErrorNetwork);
        }
    }

    public void setOnClickErrorServer(View.OnClickListener onClickErrorNetwork) {
        if (cellStatusErrorServer != null) {
            cellStatusErrorServer.setOnClickListener(onClickErrorNetwork);
        }
    }

    private void getActionBarBackButton() {
        if (mButtonBack == null) {
            mButtonBack = (Button) findViewById(R.id.action_bar_button_back);
        }
        if (mButtonBack != null) {
            mButtonBack.setTypeface(Helper.sharedHelper().getIconFont());
        }
    }

    private void getActionBarRightButton() {
        if (mButtonRight == null) {
            mButtonRight = (Button) findViewById(R.id.action_bar_button_right);
        }
    }


    /*
    =============== 通用：第一次打开activity，加载效果和出错处理 ===============
     */

    public void loadPre(ViewGroup rootView, View contentRootView) {
        contentRootView.setVisibility(View.GONE);
        showStatusLoading(rootView);
        hideStatusErrorNetwork();
        hideStatusErrorServer();
    }

    public void loadSuccess(View contentRootView) {
        hideStatusLoading();
        contentRootView.setVisibility(View.VISIBLE);
    }

    public void loadFail(HttpError error, ViewGroup rootView, Activity activity, final LoadCallback callback) {
        hideStatusLoading();

        if (error != null) {
            if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                showStatusErrorNetwork(rootView);
                setOnClickErrorNetwork(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        callback.execute();
                    }
                });
            } else {
                showStatusErrorServer(rootView);
                setTextErrorServer(error.getMessage());
                setOnClickErrorServer(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        callback.execute();
                    }
                });
            }
        } else {
            showStatusErrorServer(rootView);
            setTextErrorServer("获取数据失败，请点击重试");
            setOnClickErrorServer(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    callback.execute();
                }
            });
        }
    }

    public interface LoadCallback {
        public void execute();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (BuildConfig.SHOW_BUG_TAG) {
            Bugtags.onDispatchTouchEvent(this, ev);
        }

        if (isInterceptTouchEvent()) {
            if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                View v = getCurrentFocus();
                if (isShouldHideInput(v, ev)) {

                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                    }
                    onTouchOutOfEditText();
                }
                return super.dispatchTouchEvent(ev);
            }
            // 必不可少，否则所有的组件都不会有TouchEvent了
            if (getWindow().superDispatchTouchEvent(ev)) {
                return true;
            }
            return onTouchEvent(ev);
        } else {
            return super.dispatchTouchEvent(ev);
        }
    }

    protected void onTouchOutOfEditText() {
    }

    public boolean isInterceptTouchEvent() {
        return true;
    }

    public boolean isShouldHideInput(View v, MotionEvent event) {
        if (v != null && (v instanceof EditText)) {
            int[] leftTop = {0, 0};
            //获取输入框当前的location位置
            v.getLocationInWindow(leftTop);
            int left = leftTop[0];
            int top = leftTop[1];
            int bottom = top + v.getHeight();
            int right = left + v.getWidth();
            if (event.getX() > left && event.getX() < right
                    && event.getY() > top && event.getY() < bottom) {
                // 点击的是输入框区域，保留点击EditText的事件
                return false;
            } else {
                return true;
            }
        }
        return false;
    }


    protected ProgressDialog mProgressDialog;

    public ProgressDialog showProgress(String title, String message) {
        return showProgress(title, message, -1);
    }

    public ProgressDialog showProgress(String title, String message, int theme) {
        if (mProgressDialog == null) {
            if (theme > 0) {
                mProgressDialog = new ProgressDialog(this, theme);
            } else {
                mProgressDialog = new ProgressDialog(this);
            }
            mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            mProgressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mProgressDialog.setCanceledOnTouchOutside(false);// 不能取消
            mProgressDialog.setIndeterminate(true);// 设置进度条是否不明确
        }

        if (TextUtils.isEmpty(title)) {
            mProgressDialog.setTitle(title);
        }
        mProgressDialog.setMessage(message);
        mProgressDialog.show();
        return mProgressDialog;
    }

    public void hideProgress() {
        if (mProgressDialog != null) {
            mProgressDialog.dismiss();
        }
    }

    protected boolean onPanelKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_SETTINGS) {
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_BACK) {
            onBackPressed();
            return true;
        }
        return false;
    }


    protected void showOrHidePopMenu(View v) {
        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(this, 0);
        }

        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_CANCEL: {
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_REPORT: {
                        doReport();
                        mPopupListMenu.dismiss();
                        break;
                    }
                }
            }
        });

        List<MenuVO> menuList = new ArrayList<>();

        menuList.add(MENU_ITEM_REPORT, new MenuVO(getString(R.string.report)));
        menuList.add(MENU_ITEM_CANCEL, new MenuVO(getString(R.string.cancel)));

        mPopupListMenu.setMenuData(menuList);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    protected void doReport() {
    }

    ;

}
