package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TabHost;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.BaseActivity;
import com.meidalife.shz.widget.TabManager;

/**
 *
 */
public abstract class BaseTabHostFragment extends BaseActivity {
    protected TabHost mTabHost;
    protected TabManager mTabManager;

    /**
     * 获得layoutResource
     *
     * @return
     */
    protected int getLayoutResource() {
        return R.layout.my_tabhost_main;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutResource());
        mTabHost = (TabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup();
        mTabManager = new TabManager(this, mTabHost, android.R.id.tabcontent);
        initTab();
    }

    /**
     * 设置tab
     *
     * @param tag
     * @author 亚龙
     * @date 2013-12-31
     */
    public void setTab(String tag) {
        mTabHost.setCurrentTabByTag(tag);
    }

    /**
     * 初始化tab
     */
    protected abstract void initTab();

//    /**
//     * 创建tabview
//     *
//     * @param drawable
//     * @return View
//     */
//    protected View createTabView(int drawable, String text) {
//        View view = LayoutInflater.from(this).inflate(R.layout.my_tabhost_tab, null);
//        TextView tv = (TextView) view.findViewById(R.id.tab_text);
//        tv.setText(text);
//        if (0 < drawable) {
//            tv.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(drawable), null, null);
//        }
//        return view;
//    }

    public TabHost.TabSpec getTabSpecView(String tag, int layoutId) {
        if (mTabHost != null && mTabHost.newTabSpec(tag) != null) {
            return mTabHost.newTabSpec(tag).setIndicator(getIndicatorView(layoutId));
        }
        return null;
    }

    private View getIndicatorView(int layout) {
        View view = getLayoutInflater().inflate(layout, null);
        TextView textView = (TextView) view.findViewById(R.id.tabIcon);
        if (textView != null) {
            textView.setTypeface(Helper.sharedHelper().getIconFont());
        }
        return view;
    }


    @Override
    protected void onDestroy() {
        mTabHost = null;
        if (null != mTabManager) {
            mTabManager.onDestroy();
            mTabManager = null;
        }
        super.onDestroy();
    }

    /**
     * 获取imFrom的值
     *
     * @return
     * @date Apr 3, 2013
     */
    protected String getImFromStr() {
        String mImFrom = getIntent().getStringExtra("IMFROM");
        return TextUtils.isEmpty(mImFrom) ? null : mImFrom;
    }

    @Override
    protected boolean onPanelKeyDown(int keyCode, KeyEvent event) {
        TabManager.TabInfo info = mTabManager.getCurrentTab();
        if (null != info && info.fragment.onFragmentKeyDown(keyCode, event)) {
            return true;
        }
        return super.onPanelKeyDown(keyCode, event);
    }
}
