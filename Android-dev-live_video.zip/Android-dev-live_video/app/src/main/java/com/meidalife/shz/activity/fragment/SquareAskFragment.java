package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CategoryTagRecyclerAdapter;
import com.meidalife.shz.adapter.SquareAskAdapter;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.SquareRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareAskDO;
import com.meidalife.shz.rest.model.SquareCategoryItemDO;
import com.meidalife.shz.rest.request.RequestSquareAsk;
import com.meidalife.shz.util.LoadUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.event.EventBus;

/**
 * Created by mzzcy on 2015/12/15.
 * 格子－－帮帮忙
 */
public class SquareAskFragment extends BaseFragment implements CategoryTagRecyclerAdapter.RefreshCategoryView {

    //    private static final int REQUEST_ASK_PUBLISH = 1200;
//    private static final int REQUEST_SIGN_IN = 1201;
    private int geziId = -1;
    private ViewGroup contentRoot;
    private ListView listView;
    private View noDataLayout;
    private View listFooter;
    private ProgressBar footerLoading;
    private TextView footerMessage;
    private Button footerReload;
    private Context mContext;
    private View rootView;
    private ViewGroup rootLayout;

    private RecyclerView categoryRecyclerView;
    private CategoryTagRecyclerAdapter categoryTagRecyclerAdapter;

    private ArrayList<SquareAskDO> demandList;
    private SquareAskAdapter squareAskAdapter;
    private int previous = 0;
    boolean loading = false;
    boolean complete = false;
    int PAGE_SIZE = 20;
    int page = 0;
    boolean isFirstEnter = true;
    private int mCatId = Integer.MAX_VALUE;
    private boolean isJoined = false;
    private boolean isGezhu;

    private LoadUtil loadUtilV2;

    public static SquareAskFragment newInstance(Bundle params) {
        SquareAskFragment squareAskFragment = new SquareAskFragment();
        squareAskFragment.setArguments(params);
        return squareAskFragment;
    }

    public void onEvent(SquareRefreshEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType) {
            isJoined = event.isJoined;
            isGezhu = event.isGezhu;
            complete = false;
            page = 0;
            refreshCategory(mCatId);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        EventBus.getDefault().register(this);
//        IconTextView publishIcon;
//        FontTextView publishText;
        Bundle params = getArguments();
        if (params != null) {
            geziId = params.getInt("geziId", Integer.MAX_VALUE);
            isJoined = params.getBoolean("isJoined", false);
            isGezhu = params.getBoolean("isGezhu", false);
        }
        mContext = getActivity();
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_square_ask, container, false);
            rootLayout = (ViewGroup) rootView.findViewById(R.id.rootLayout);
            contentRoot = (ViewGroup) rootView.findViewById(R.id.contentRoot);
            listView = (ListView) rootView.findViewById(R.id.help_platform_list);
            noDataLayout = rootView.findViewById(R.id.noDataLayout);
            categoryRecyclerView = (RecyclerView) rootView.findViewById(R.id.categoryList);
//            publishAsk = rootView.findViewById(R.id.publishAsk);
//            publishIcon = (IconTextView) rootView.findViewById(R.id.publishIcon);
//            publishText = (FontTextView) rootView.findViewById(R.id.publishText);
//            publishIcon.setText(R.string.icon_question);
//            publishText.setText(R.string.title_activity_publish_demand);
            categoryTagRecyclerAdapter = new CategoryTagRecyclerAdapter(mContext, new ArrayList<SquareCategoryItemDO>(), CategoryTagRecyclerAdapter.LIFE_COLLECT);
            categoryTagRecyclerAdapter.setOnClickCategoryListener(this);
            categoryRecyclerView.setAdapter(categoryTagRecyclerAdapter);

            //设置布局管理器
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
            linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
            categoryRecyclerView.setLayoutManager(linearLayoutManager);
            categoryRecyclerView.setVisibility(View.GONE);

            listFooter = inflater.inflate(R.layout.view_list_footer, null);
            footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
            footerMessage = (TextView) listFooter.findViewById(R.id.message);
            footerReload = (Button) listFooter.findViewById(R.id.footerReload);
            listView.addFooterView(listFooter);
            listFooter.setVisibility(View.GONE);
            bindListener();

            demandList = new ArrayList<>();
            squareAskAdapter = new SquareAskAdapter(mContext, demandList, isGezhu);
            listView.setAdapter(squareAskAdapter);

            loadUtilV2 = new LoadUtil(inflater);
        }

        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        fetchAskCategory();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
        super.onDestroyView();
    }

    private void bindListener() {

        footerReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchAskItem(mCatId);
            }
        });
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView absListView, int scrollState) {
                BaseEvent message = new BaseEvent();
                final View topChildView = listView.getChildAt(0);
                if (scrollState == SCROLL_STATE_IDLE && listView.getFirstVisiblePosition() == 0
                        && topChildView.getTop() == 0) {
                    message.eventType = MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                } else {
                    message.eventType = MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                }
                /*if (scrollState == SCROLL_STATE_IDLE) {
                    publishAsk.setVisibility(View.VISIBLE);
                }*/
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                /*if (firstVisibleItem > 0) {
                    publishAsk.setVisibility(View.GONE);
                }*/
                boolean moveToBottom = false;
                if (previous <= firstVisibleItem) {
                    moveToBottom = true;
                }
                previous = firstVisibleItem;
                if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom && !isFirstEnter) {
                    //* 需要加载更多数据的代码 *//*
                    loadAskItem();
                }
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                SquareAskDO squareAskDO = demandList.get(position);
                Bundle bundle = new Bundle();
                bundle.putBoolean("pin", squareAskDO.getPin());
                bundle.putInt("geziId", squareAskDO.getGeziId());
                Router.sharedRouter().openFormResult("squareaskdetail/" + squareAskDO.getId(), bundle,
                        Constant.REQUEST_CODE_ASK_DETAIL, getActivity());

            }
        });

    }

    //用于点击时的回调
    @Override
    public void refreshCategory(int catId) {
        demandList.clear();
        mCatId = catId;
        fetchAskItem(catId);
        listView.setVisibility(View.GONE);
        noDataLayout.setVisibility(View.GONE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_ASK_DETAIL) {
            complete = false;
            page = 0;
            refreshCategory(mCatId);
        }
    }

    private void loadAskItem() {
        if (!complete && !loading) {
            page++;
            fetchAskItem(mCatId);
        }
    }

    private void fetchAskCategory() {
        loadUtilV2.loadPre(rootLayout, contentRoot);
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        params.put("offset", page * PAGE_SIZE);
        params.put("pageSize", PAGE_SIZE);
        RequestSquareAsk.getDemandList(params, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                if (getActivity() == null) {
                    return;
                }
                loadUtilV2.loadSuccess(contentRoot);
                JSONObject dataJB = (JSONObject) obj;
                JSONArray categoryArray = dataJB.getJSONArray("catList");
//                if (categoryArray != null && categoryArray.size() != 0)
//                    initCat(categoryArray);
                initCat(categoryArray);
            }

            @Override
            public void onFail(HttpError error) {
                categoryRecyclerView.setVisibility(View.GONE);
                if (getActivity() == null) {
                    return;
                }
                loadUtilV2.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        fetchAskCategory();
                    }
                });
            }
        });
    }

    private void initCat(JSONArray cats) {
        if (cats == null || cats.size() == 0) {
            mCatId = Integer.MAX_VALUE;
            categoryRecyclerView.setVisibility(View.GONE);
        } else {
            List<SquareCategoryItemDO> tabList = new ArrayList<SquareCategoryItemDO>();
            SquareCategoryItemDO categoryItemDO;
            for (int i = 0; i < cats.size(); i++) {
                categoryItemDO = new SquareCategoryItemDO();
                JSONObject cat = cats.getJSONObject(i);
                if (cat.containsKey("catid"))
                    categoryItemDO.setCatId(cat.getIntValue("catid"));
                if (cat.containsKey("catName"))
                    categoryItemDO.setCatName(cat.getString("catName"));
                tabList.add(categoryItemDO);
            }

            mCatId = tabList.get(0).getCatId();
            categoryTagRecyclerAdapter.setTabList(tabList);
            categoryTagRecyclerAdapter.notifyDataSetChanged();
            categoryRecyclerView.setVisibility(View.VISIBLE);
        }
        //首次进入加载
        demandList.clear();
        fetchAskItem(mCatId);
        isFirstEnter = false;
    }

    private void fetchAskItem(int catId) {
        loadUtilV2.loadPre(rootLayout, contentRoot);
        loading = true;
        listFooter.setVisibility(View.VISIBLE);

        RequestSquareAsk.getDemandList(getAskItemParams(catId), new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object result) {
                listFooter.setVisibility(View.GONE);
                loading = false;
                loadUtilV2.loadSuccess(contentRoot);

                JSONObject dataJB = (JSONObject) result;
                JSONArray jsonArray = dataJB.getJSONArray("demandList");
                Log.d("mzLog", "result jsonArray: " + jsonArray.toString());
                int size = jsonArray.size();
                for (int i = 0; i < size; i++) {
                    SquareAskDO squareAskDO = new SquareAskDO();
                    JSONObject demandJB = (JSONObject) jsonArray.get(i);
                    if(demandJB.containsKey("id"))
                    squareAskDO.setId(demandJB.getInteger("id"));
                    if(demandJB.containsKey("geziId"))
                        squareAskDO.setGeziId(demandJB.getInteger("geziId"));
                    if(demandJB.containsKey("title"))
                        squareAskDO.setTitle(demandJB.getString("title"));
                    if(demandJB.containsKey("description"))
                    squareAskDO.setDescription(demandJB.getString("description"));
                    if (demandJB.containsKey("closeTime"))
                        squareAskDO.setCloseTime(demandJB.getInteger("closeTime"));
                    if (demandJB.containsKey("remainTime")) {
                        squareAskDO.setRemainTime(demandJB.getInteger("remainTime"));
                    }

                    if (demandJB.containsKey("user")) {
                        JSONObject user = demandJB.getJSONObject("user");
                        squareAskDO.setUserInstruction(user.getString("userInstruction"));
                        squareAskDO.setUserId(user.getInteger("userId"));
                        squareAskDO.setUserNick(user.getString("userNick"));
                        squareAskDO.setUserPicUrl(user.getString("userPicUrl"));
                        squareAskDO.setUserGender(user.getString("userGender"));
                        if (user.containsKey("isGezhu")) {
                            squareAskDO.setIsGezhu(user.getBoolean("isGezhu"));
                        }
                    }
                    if (demandJB.containsKey("commentCount"))
                        squareAskDO.setCommentCount(demandJB.getInteger("commentCount"));
                    if (demandJB.containsKey("pin"))
                        squareAskDO.setPin(demandJB.getBoolean("pin"));
                    if (demandJB.containsKey("status"))
                        squareAskDO.setStatus(demandJB.getIntValue("status"));
                    demandList.add(squareAskDO);
                    Log.d("mzLog squareAskDO", squareAskDO.toString());
                }

                if (demandList.size() == 0) {
                    listView.setVisibility(View.GONE);
                    noDataLayout.setVisibility(View.VISIBLE);
                } else {
                    squareAskAdapter.notifyDataSetChanged();
                    listView.setVisibility(View.VISIBLE);
                    noDataLayout.setVisibility(View.GONE);
                }

                if (size < PAGE_SIZE) {
                    complete = true;
                    listView.removeFooterView(listFooter);
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (page != 0) {
                    page--;
                }
                loading = false;
                loadUtilV2.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        fetchAskItem(mCatId);
                    }
                });
            }
        });
    }

    private JSONObject getAskItemParams(int catId) {
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        if (catId != Integer.MAX_VALUE)
            params.put("catId", catId);
        params.put("offset", page * PAGE_SIZE);
        params.put("pageSize", PAGE_SIZE);
        Log.d("mzLog helpItemParams", params.toString() + "||" + page + "||" + page * PAGE_SIZE);
        return params;
    }

}
