package com.meidalife.shz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.meidalife.shz.R;

import java.util.ArrayList;

/**
 * Created by fufeng on 15/12/23.
 */
public abstract class BaseRecycleViewAdapter extends RecyclerView.Adapter {
    static final int HEADER_TYPE = R.integer.header_type;
    static final int FOOTER_TYPE = R.integer.footer_type;

    private int headViewId = -1;
    private int footerViewId = -1;
    private View mHeaderViews = null; //头视图
    private View mFooterViews = null;   //尾视图
    LayoutInflater inflater;

    public BaseRecycleViewAdapter(Context context) {
        inflater = LayoutInflater.from(context);
    }

    public void setHeaderView(View headerView) {
        mHeaderViews = headerView;
    }

    public void setFooterView(View footerView) {
        mFooterViews = footerView;
    }

    public void setHeadViewId(int headViewId) {
        this.headViewId = headViewId;
    }

    public void setFooterViewId(int footerViewId) {
        this.footerViewId = footerViewId;
    }

    @Override
    final public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case HEADER_TYPE: {
                if (mHeaderViews != null) {
                    return new HeaderViewHolder(mHeaderViews);
                } else {
                    return new HeaderViewHolder(inflater.inflate(headViewId, parent, false));
                }
            }
            case FOOTER_TYPE: {
                if (mFooterViews != null) {
                    return new FooterViewHolder(mFooterViews);
                } else {
                    return new FooterViewHolder(inflater.inflate(footerViewId, parent, false));
                }
            }
        }
        return onCreateContentViewHolder(parent, viewType);
    }

    @Override
    final public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        switch (holder.getItemViewType()) {
            case HEADER_TYPE: {
                onBindHeaderViewHolder(holder, position);
                return;
            }
            case FOOTER_TYPE: {
                onBindFooterViewHolder(holder, position);
                return;
            }
        }

        if (mHeaderViews == null && headViewId <= 0) {
            onBindContentViewHolder(holder, position);
        } else {
            onBindContentViewHolder(holder, position - 1);
        }
    }

    @Override
    final public int getItemCount() {
        return getContentItemCount() + (mFooterViews == null && footerViewId <= 0 ? 0 : 1)
                + (mHeaderViews == null && headViewId <= 0 ? 0 : 1);
    }

    abstract public RecyclerView.ViewHolder onCreateContentViewHolder(ViewGroup parent, int viewType);

    abstract public void onBindContentViewHolder(RecyclerView.ViewHolder holder, int position);

    abstract public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position);

    abstract public void onBindFooterViewHolder(RecyclerView.ViewHolder holder, int position);

    abstract public int getContentItemCount();

    @Override
    public int getItemViewType(int position) {
        if (position == 0 && (mHeaderViews != null || headViewId > 0)) {
            return HEADER_TYPE;
        } else if ((mFooterViews != null || footerViewId > 0) && (position == getItemCount() - 1)) {
            return FOOTER_TYPE;
        }
        return super.getItemViewType(position);
    }

    class HeaderViewHolder extends RecyclerView.ViewHolder {

        public HeaderViewHolder(View itemView) {
            super(itemView);
        }
    }

    class FooterViewHolder extends RecyclerView.ViewHolder {

        public FooterViewHolder(View itemView) {
            super(itemView);
        }
    }
}
