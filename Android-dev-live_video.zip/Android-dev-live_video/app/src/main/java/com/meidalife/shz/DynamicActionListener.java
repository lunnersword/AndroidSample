package com.meidalife.shz;

import android.view.View;

import com.meidalife.shz.rest.model.DynamicBottomDO;
import com.meidalife.shz.rest.model.DynamicOutDO;

public interface DynamicActionListener {

    public void onAddAttentionClick(String userId);

    public void onCommentClick(int position, DynamicOutDO dynamic);

    //回复单条留言 还需要单挑的userId
    public void onCommentListItemClick(int position, DynamicOutDO dynamic, DynamicBottomDO comment);

    //点赞
    public void onSupportClick(int position, DynamicOutDO dynamic);

    //打赏
    public void onRewardClick(int position, DynamicOutDO dynamic);

    public void onMoreActionClick(int position, DynamicOutDO dynamic,View view);

    public void startPlayClick(int position, DynamicOutDO dynamic);

    public void stopPlayClick(int position, DynamicOutDO dynamic);
}