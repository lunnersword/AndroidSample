package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.NearbyCategoryListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 关联服务类目,话题类目
 * Created by xingchen on 2015/12/18.
 */
public class NearbyCategoryActivity extends BaseActivity {
    public final static int SQUARE_NEARBY_CATEGORY = 0;
    public final static int SQUARE_BBS_CATEGORY = 1;

    @Bind(R.id.categoryList)
    ListView categoryListView;
    @Bind(R.id.emptyView)
    View emptyView;
    @Bind(R.id.rootView)
    ViewGroup rootView;

    private JSONArray result;
    private int geziId;
    private int type;
    private String urlPath;
    private JSONObject choseItem;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearby_category);

        ButterKnife.bind(this);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            geziId = bundle.getInt("geziId");
            type = bundle.getInt("type");
        }

        if (type == SQUARE_NEARBY_CATEGORY) {
            initActionBar(R.string.square_nearby_category, true, true);
            urlPath = "1.0/gezi/yp/cats";
        } else {
            initActionBar(R.string.square_bbs_category, true, true);
            urlPath = "1.0/gezi/bbs/cats";
        }
        mButtonRight.setText(R.string.confirm);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (choseItem != null) {
                    Intent intent = new Intent();
                    Bundle params = new Bundle();
                    params.putInt("catId", choseItem.getIntValue("catId"));
                    params.putString("catName", choseItem.getString("catName"));
                    intent.putExtra("params", params);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });
        result = new JSONArray();
        categoryListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                choseItem = result.getJSONObject(position);
            }
        });
        initData();
    }

    private void initData() {
        categoryListView.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
        showStatusLoading(rootView);
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("geziId", geziId);
        HttpClient.get(urlPath, params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONArray>() {
            @Override
            public void onSuccess(JSONArray obj) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();

                if (obj == null) {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                    return;
                }
                if (obj.size() == 0) {
                    emptyView.setVisibility(View.VISIBLE);
                    return;
                }
                result = obj;
                categoryListView.setVisibility(View.VISIBLE);
                NearbyCategoryListAdapter nearbyCategoryListAdapter = new NearbyCategoryListAdapter(NearbyCategoryActivity.this,result);
                categoryListView.setAdapter(nearbyCategoryListAdapter);
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                }
            }
        });
    }
}
