package com.meidalife.shz.activity.fragment;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.BroadcastConstant;
import com.meidalife.shz.Constant;
import com.meidalife.shz.DynamicActionListener;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.ReportActivity;
import com.meidalife.shz.activity.RewardDialogActivity;
import com.meidalife.shz.adapter.DynamicAdapter;
import com.meidalife.shz.event.AttentionUserEvent;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.DynamicListRefreshEvent;
import com.meidalife.shz.event.SquareRefreshEvent;
import com.meidalife.shz.event.type.DynamicRefreshTypeEnum;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.media.PlayMediaService;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicBottomDO;
import com.meidalife.shz.rest.model.DynamicOutDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.umeng.socialize.media.UMImage;

import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by zuozheng on 16/3/29.
 * 动态frag
 */
public class CommonTimeLineFragment extends BaseFragment implements ViewPager.OnPageChangeListener {
    //默认推荐人列表是展开状态
    private volatile boolean isPlaying = false;
    private boolean isLoading = false;
    private boolean isComplete;
    private int page = 0;
    private static int PAGE_SIZE = 10;

    private DynamicOutDO clickedDynamic;
    Intent playIntent;

    private LinkedList<DynamicOutDO> mDynamicDataList = new LinkedList<>();

//    private DynamicTabDO mCurrentCate = new DynamicTabDO();

    private DynamicAdapter mDynamicAdapter;

    private LoadUtil loadUtil;
    private PopupWindow popupWindow;
    private SocialSharePopupWindow socialSharePopupWindow;
    ShareActivity shareActivity;

    private View rootView;
    private View dynamicListFooter;
    private ProgressBar dynamicFooterLoading;
    private TextView dynamicFooterMessage;
    private Button dynamicFooterReload;
    private AnimationDrawable loadingAnimation;


    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    //    @Bind(R.id.mSwipeRefreshLayout)
//    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.listView)
    ListView dynamicListView;

    @Bind(R.id.dataEmptyView)
    ViewGroup noMsgView;
    @Bind(R.id.dataEmptyTextView)
    TextView noMsgTextView;

    String geziId;

    public static CommonTimeLineFragment newInstance(Bundle params) {
        CommonTimeLineFragment timeLineFragment = new CommonTimeLineFragment();
        timeLineFragment.setArguments(params);
        return timeLineFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        if (rootView == null) {
            initView(inflater, container, savedInstanceState);

            page = 0;
            isComplete = false;
            isLoading = false;
            mDynamicAdapter = new DynamicAdapter(getActivity(), mDynamicDataList);
            dynamicListView.setAdapter(mDynamicAdapter);

            shareActivity = new ShareActivity(getActivity());
            initOnClickListener();

            loadUtil = new LoadUtil(inflater);

            geziId = getArguments().getString("geziId");

            xhrDynamic(true, "");

            playIntent = new Intent(getActivity(), PlayMediaService.class);
        }

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        return rootView;
    }

    void initOnClickListener() {

        mDynamicAdapter.setmListener(new DynamicActionListener() {
            @Override
            public void onAddAttentionClick(String userId) {
                //关注之后
                addAttention(userId);
            }

            @Override
            public void onCommentClick(int position, DynamicOutDO dynamic) {
                //发送输入事件 弹出键盘 并输入内容
                sendCommentBroadcast(position, dynamic);
            }

            @Override
            public void onCommentListItemClick(int position, DynamicOutDO dynamic, DynamicBottomDO comment) {
                sendItemClickBroadcast(position, dynamic, comment);
            }

            @Override
            public void onSupportClick(int position, DynamicOutDO dynamic) {
                supportOrCancel(dynamic);
            }

            @Override
            public void onRewardClick(int position, DynamicOutDO dynamic) {
                reward(dynamic);
            }

            @Override
            public void onMoreActionClick(int position, DynamicOutDO dynamic, View view) {
                //显示popup Window 举报或者xx
                initPopupWindowView(position, dynamic, view);
            }

            //todo 实现倒计时
            @Override
            public void startPlayClick(int position, DynamicOutDO dynamic) {
                if (isPlaying) {
                    getActivity().stopService(playIntent);
                }
                playIntent.putExtra(PlayMediaService.INTENT_MEDIA_PLAY, dynamic.getAdditionalInfo().getAudioUrl());
                getActivity().startService(playIntent);
                isPlaying = !isPlaying;
            }

            @Override
            public void stopPlayClick(int position, DynamicOutDO dynamic) {
                getActivity().stopService(playIntent);
            }
        });

//        newsViewGroup.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Router.sharedRouter().open("dynamic_news");
//            }
//        });
    }

    void initPopupWindowView(final int position, final DynamicOutDO dynamic, View view) {
        View popupView = LayoutInflater.from(getActivity()).inflate(R.layout.popup_window_dynamic, null);
        final View leftView = popupView.findViewById(R.id.view_left);
        View rightView = popupView.findViewById(R.id.view_right);
        TextView rightTextView = (TextView) popupView.findViewById(R.id.text_right);

        if (Helper.sharedHelper().getUserId().equals(dynamic.getUser().getUserId())) {
            rightTextView.setText("删除");
        }

        leftView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHideShareList(leftView, dynamic);
                popupWindow.dismiss();
            }
        });

        rightView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().getUserId().equals(dynamic.getUser().getUserId())) {
                    deleteFeed(position, dynamic.getFeedId());
                } else {
                    reportDynamic(dynamic.getFeedId());
                }
                popupWindow.dismiss();
            }
        });

        popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setAnimationStyle(R.style.PopupWindowAnimation);
        popupWindow.showAtLocation(view, Gravity.RIGHT, 0, 175);
    }

    void deleteFeed(final int position, String feedId) {
        JSONObject params = new JSONObject();

        if (!TextUtils.isEmpty(feedId)) {
            params.put("feedId", feedId);
        }

        RequestDynamic.deleteFeed(params, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                //实现列表假删除
                mDynamicDataList.remove(position);
                mDynamicAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    void initView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_comment_list, container, false);

        ButterKnife.bind(this, rootView);

        dynamicListFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
        dynamicFooterLoading = (ProgressBar) dynamicListFooter.findViewById(R.id.loading);
        dynamicFooterMessage = (TextView) dynamicListFooter.findViewById(R.id.message);
        dynamicFooterReload = (Button) dynamicListFooter.findViewById(R.id.footerReload);
        dynamicListView.addFooterView(dynamicListFooter);
        dynamicListFooter.setVisibility(View.GONE);


        dynamicListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
//                        xhrDynamic(false, mCurrentCate.getTabId());
                        xhrDynamic(false, "");
                    }
                } else {
//                    mSwipeRefreshLayout.setEnabled(true);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (dynamicListView.getFirstVisiblePosition() >= 1) {
                } else {
                }

            }
        });

        dynamicFooterReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                xhrDynamic(false, mCurrentCate.getTabId());
                xhrDynamic(false, "");
            }
        });

//        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                mSwipeRefreshLayout.setRefreshing(false);
//                xhrDynamic(true, "");
//            }
//        });
    }

    @Override
    public void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {
//        mSwipeRefreshLayout.setEnabled(state == ViewPager.SCROLL_STATE_IDLE);
    }

    private void renderDynamic(List<DynamicOutDO> dynamicList) {

        if (CollectionUtil.isEmpty(dynamicList) || dynamicList.size() < PAGE_SIZE) {
            isComplete = true;
            dynamicListView.removeFooterView(dynamicListFooter);
        }

        if (CollectionUtil.isNotEmpty(dynamicList)) {
            mDynamicDataList.addAll(dynamicList);
        }

        if (CollectionUtil.isEmpty(mDynamicDataList)) {
            noMsgView.setVisibility(View.VISIBLE);
            dynamicListView.setVisibility(View.GONE);
        } else {
            noMsgView.setVisibility(View.GONE);
            dynamicListView.setVisibility(View.VISIBLE);
        }

        mDynamicAdapter.notifyDataSetChanged();
    }

    private void xhrDynamic(final boolean refresh, final String tabId) {

        if (isLoading) {
            return;
        }
        isLoading = true;

        if (refresh) {
            loadUtil.loadPre(rootLayout, rootLayout);
            mDynamicDataList.clear();
            page = 0;
            isComplete = false;
            dynamicListFooter.setVisibility(View.GONE);
        } else {
            //load more

            if (isComplete) {
                isLoading = false;
                return;
            }

            dynamicFooterMessage.setText("正在加载");
            dynamicFooterMessage.setVisibility(View.VISIBLE);
            dynamicFooterLoading.setVisibility(View.VISIBLE);
            dynamicFooterReload.setVisibility(View.GONE);
            dynamicListFooter.setVisibility(View.VISIBLE);
            page++;
        }

        RequestDynamic.feedList(getParams(), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject json) {
                isLoading = false;

                if (refresh) {
                    loadUtil.loadSuccess(rootLayout);
                } else {
                    dynamicListFooter.setVisibility(View.GONE);
                }

                List<DynamicOutDO> dynamicList = null;
                if (json != null && json.containsKey("result")) {
                    dynamicList = JSON.parseArray(json.getString("result"), DynamicOutDO.class);
                }

                renderDynamic(dynamicList);
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                if (refresh) {
                    loadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                        @Override
                        public void retry() {
                            xhrDynamic(true, tabId);
                        }
                    });
                } else {
                    page--;
                    isLoading = false;
                    dynamicFooterMessage.setVisibility(View.GONE);
                    dynamicFooterLoading.setVisibility(View.GONE);
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            dynamicFooterReload.setText("网络异常，点击重试");
                        } else {
                            dynamicFooterReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        dynamicFooterReload.setText("发生一个未知错误，点击重试");
                    }
                    dynamicFooterReload.setVisibility(View.VISIBLE);
                    dynamicListFooter.setVisibility(View.VISIBLE);
                }
            }
        });

    }

    private JSONObject getParams() {
        JSONObject params;
        try {
            params = new JSONObject();

            if (!TextUtils.isEmpty(geziId)) {
                params.put("geziId", geziId);
            }
            params.put("pageSize", String.valueOf(PAGE_SIZE));
            params.put("offset", String.valueOf(page * PAGE_SIZE));
        } catch (Exception e) {
            params = null;
        }

        return params;
    }

    //关注人
    private void addAttention(final String userId) {
        RequestDynamic.addAttention(userId, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                AttentionUserEvent event = new AttentionUserEvent();
                event.userId = userId;
                event.isAttention = true;
                EventBus.getDefault().post(event);
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    void sendCommentBroadcast(int position, DynamicOutDO dynamic) {
        Intent intent = new Intent();
        intent.setAction(BroadcastConstant.COMMENT);
        intent.putExtra("position", position);
        intent.putExtra("item", dynamic);

        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
    }

    void sendItemClickBroadcast(int position, DynamicOutDO dynamic, DynamicBottomDO comment) {
        Intent intent = new Intent();
        intent.setAction(BroadcastConstant.ITEMCLICK);
        intent.putExtra("position", position);
        intent.putExtra("item", dynamic);
        intent.putExtra("comment", comment);

        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
    }

    private void supportOrCancel(final DynamicOutDO dynamic) {
        try {
            JSONObject params = new JSONObject();
            params.put("feedId", dynamic.getFeedId());
            if (dynamic.isSupported()) {
                params.put("type", 1);
            } else {
                params.put("type", 0);
            }

            RequestDynamic.supportOrCancel(params, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {

                }

                @Override
                public void onFail(HttpError error) {
                }
            });
        } catch (Exception e) {
        }
    }

    //弹出打赏popupWindow 如果打赏成功 更新对应adapter=
    private void reward(final DynamicOutDO item) {
        if (Helper.sharedHelper().getUserId().equals(item.getUser().getUserId())) {
            MessageUtils.showToast(R.string.dynamic_reward_self_tip);
        } else {
            clickedDynamic = item;
            Intent intent = new Intent(getActivity(), RewardDialogActivity.class);
            intent.putExtra("receiverId", item.getUser().getUserId());
            intent.putExtra("avatar", item.getUser().getAvatarUrl());
            intent.putExtra("sourceId", item.getFeedId());

            startActivityForResult(intent,
                    Constant.REQUEST_CODE_REWARD);
        }
    }


    public void onEvent(BaseEvent mEvent) {

        if (mEvent instanceof DynamicListRefreshEvent) {
            DynamicListRefreshEvent event = (DynamicListRefreshEvent) mEvent;
            if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isLoading) {
                if (event.position >= -1 && event.position < mDynamicDataList.size()) {
                    mDynamicAdapter.updateItemData(event.dynamic, event.typeEnum);
                }
            } else if (MsgTypeEnum.TYPE_PUBLISH == event.eventType && !isLoading) {
                //关注tab
                mDynamicDataList.addFirst(event.dynamic);
                mDynamicAdapter.notifyDataSetChanged();
            }
        } else if (mEvent instanceof AttentionUserEvent) {
            AttentionUserEvent event = (AttentionUserEvent) mEvent;
            if (MsgTypeEnum.TYPE_ATTENTION_USER == event.eventType && !isLoading) {

                //全局关注或取消关注事件 更新
                if (CollectionUtil.isNotEmpty(mDynamicDataList)) {
                    for (DynamicOutDO dynamic : mDynamicDataList) {
                        if (dynamic.getUser() != null && dynamic.getUser().getUserId().equals(event.userId)) {
                            dynamic.getUser().setFocused(event.isAttention);
                        }
                    }
                    mDynamicAdapter.notifyDataSetChanged();
                }
            }
        } else if (mEvent instanceof SquareRefreshEvent) {
            SquareRefreshEvent event = (SquareRefreshEvent) mEvent;
            if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isLoading) {
                xhrDynamic(true, "");
            }
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_REWARD && data != null) {
            double rewardAmount = data.getIntExtra("amount", 0);
            boolean result = data.getBooleanExtra(Pay.TAG_PAY_RESULT, false);
            if (result && rewardAmount > 0) {
                clickedDynamic.setBonusCount(rewardAmount / 1000 + clickedDynamic.getBonusCount());
                mDynamicAdapter.updateItemData(clickedDynamic, DynamicRefreshTypeEnum.TYPE_REWARD);
            } else {
                MessageUtils.showToast(R.string.reward_failed);
            }
        }
    }

    private void reportDynamic(String feedId) {
        Intent intent = new Intent();
        intent.setClass(getActivity(), ReportActivity.class);
        intent.putExtra("targetId", feedId);
        intent.putExtra("target", Constant.REPORT_TYPE_DYNAMIC);
        startActivity(intent);
    }

    private void showOrHideShareList(View v, DynamicOutDO dynamic) {
        if (socialSharePopupWindow == null) {
            socialSharePopupWindow = new SocialSharePopupWindow(getActivity(), shareActivity, 0);
        }

        socialSharePopupWindow.setShareUrl(null);
        socialSharePopupWindow.setShareTitle(dynamic.getUser().getUserNick());
        socialSharePopupWindow.setShareDescription(dynamic.getContent());
        socialSharePopupWindow.setShareImage(new UMImage(getActivity(), dynamic.getUser().getAvatarUrl()));

        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }
}
