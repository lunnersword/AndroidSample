package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareAskCategoryLvAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareCategoryItemDO;
import com.meidalife.shz.rest.request.RequestSquareAsk;

import java.util.ArrayList;

public class SquareAskChooseCategoryActivity extends BaseActivity {


    private ListView listView;
    private ArrayList<SquareCategoryItemDO> arrayList;
    private SquareAskCategoryLvAdapter squareAskCategoryLvAdapter;
    private int lastSelectIndex = -1;
    private SquareCategoryItemDO squareCategoryItemDO;
    private Intent mResultIntent;
    private ViewGroup contentRoot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_ask_category);
        initActionBar(R.string.title_activity_demand_associate_category, true, true);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            lastSelectIndex = bundle.getInt("lastSelectIndex");
        }

        mButtonRight.setText(R.string.confirm);
        contentRoot = (ViewGroup) findViewById(R.id.contentRoot);
        listView = (ListView) findViewById(R.id.listView);
        arrayList = new ArrayList<>();
        squareAskCategoryLvAdapter =
                new SquareAskCategoryLvAdapter(this, R.layout.item_square_ask_category, arrayList);
        listView.setAdapter(squareAskCategoryLvAdapter);

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mResultIntent == null) {
                    MessageUtils.showToast("请选择类目哦");
                } else {
                    finish();
                }
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                view.setSelected(true);
                lastSelectIndex = position;
                Bundle bundle = new Bundle();
                bundle.putInt("catid", arrayList.get(position).getCatId());
                bundle.putCharSequence("catName", arrayList.get(position).getCatName());
                bundle.putInt("lastSelectIndex", lastSelectIndex);
                mResultIntent = new Intent().putExtras(bundle);
                setResult(RESULT_OK, mResultIntent);
            }
        });

        fetchData();

    }

    private void fetchData() {
        showStatusLoading(contentRoot);
        listView.setVisibility(View.GONE);
        RequestSquareAsk.getCategoryList(new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();

                JSONArray jsonArray = null;
                try {
                    jsonArray = (JSONArray) obj;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                JSONObject item;
                for (int i = 0; i < jsonArray.size(); i++) {
                    squareCategoryItemDO = new SquareCategoryItemDO();
                    item = (JSONObject) jsonArray.get(i);
                    squareCategoryItemDO.setCatId(item.getInteger("catid"));
                    squareCategoryItemDO.setCatName(item.getString("catName"));
                    arrayList.add(squareCategoryItemDO);
                }
                listView.setVisibility(View.VISIBLE);
                squareAskCategoryLvAdapter.notifyDataSetChanged();
                if (lastSelectIndex != -1 && lastSelectIndex < arrayList.size()) {
                    listView.setItemChecked(lastSelectIndex, true);
                }

            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(contentRoot, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fetchData();
                        }
                    });
                } else {
                    showStatusErrorServer(contentRoot, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fetchData();
                        }
                    });
                    setTextErrorServer(error.getMessage());
                }
            }
        });
    }

}
