package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.usepropeller.routable.Router;

/**
 * Created by shijian on 15/7/7.
 */
public class CoinWholeActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.coin_whole_info);
        initActionBar(R.string.title_coin_whole, true);

        if (!Helper.sharedHelper().hasToken()) {
            Bundle bundle = new Bundle();
            bundle.putString("action", "profile_coin");
            Router.sharedRouter().open("signin", bundle);
            finish();
        }

        Bundle extras = getIntent().getExtras();
        String sumValue = extras.getString("sum");
        TextView coinTotalNum = (TextView) findViewById(R.id.coin_total_num);
        coinTotalNum.setText(sumValue + " 个");

        TextView coinDetailIcon = (TextView) findViewById(R.id.coin_detail_icon);
        coinDetailIcon.setTypeface(Helper.sharedHelper().getIconFont());

        View coinDetail = findViewById(R.id.coin_detail);
        coinDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("money_coin_detail/" + MoneyCoinDetailActivity.COIN_TYPE);
            }
        });
    }
}
