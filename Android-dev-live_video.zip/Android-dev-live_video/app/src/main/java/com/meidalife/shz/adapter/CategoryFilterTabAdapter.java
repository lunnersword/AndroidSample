package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;


/**
 * Created by xingchen on 2015/12/8.
 */
public class CategoryFilterTabAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private JSONArray tabList;
    private int selectPos;

    private String tagNameKey;

    public CategoryFilterTabAdapter(Context mContext, JSONArray tabList) {
        this.mInflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
        this.tabList = tabList;
    }

    public void setTagNameKey(String tagNameKey) {
        this.tagNameKey = tagNameKey;
    }

    @Override
    public int getCount() {
        return tabList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_category_filter_tab, parent, false);
            holder = new ViewHolder();
            holder.filterTab = (TextView) convertView.findViewById(R.id.filterTab);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        try {
            holder.filterTab.setText(((JSONObject) tabList.get(position)).getString(tagNameKey));
            if (selectPos == position) {
                holder.filterTab.setBackgroundResource(R.drawable.bg_filter_tab_selected);
            } else
                holder.filterTab.setBackgroundResource(R.drawable.bg_filter_tab);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return convertView;
    }

    static class ViewHolder {
        TextView filterTab;
    }

    public int getSelectPos() {
        return selectPos;
    }

    public void setSelectPos(int selectPos) {
        this.selectPos = selectPos;
    }

    public int getStdCatId() {
        if (selectPos == 0) {
            return Integer.MAX_VALUE;
        } else {
            return tabList.getJSONObject(selectPos).getInteger("stdCatId") == null ?
                    Integer.MAX_VALUE : tabList.getJSONObject(selectPos).getInteger("stdCatId");
        }
    }

    public int getDefaultCatId(){
        return tabList.getJSONObject(selectPos).getInteger("stdCatId") == null ?
                Integer.MAX_VALUE : tabList.getJSONObject(selectPos).getInteger("stdCatId");
    }

    public void setTabList(JSONArray tabList) {
        this.tabList = tabList;
    }
}
