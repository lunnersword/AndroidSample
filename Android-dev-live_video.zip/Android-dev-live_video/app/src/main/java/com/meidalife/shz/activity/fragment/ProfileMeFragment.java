package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.ProfilePersonalIntroduceActivity;
import com.meidalife.shz.adapter.ProfileMeAuthGridAdapter;
import com.meidalife.shz.adapter.ProfileMeRecycleAdapter;
import com.meidalife.shz.event.ScrollToTopEvent;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.MePageDO;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.FlowLayout;
import com.usepropeller.routable.Router;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 个人主页-me
 * Created by liujian on 16/4/7.
 */
public class ProfileMeFragment extends BaseFragment {

    public final static int UPDATE_PROFILE_INTRODUCE = 88;
    public final static int UPDATE_PROFILE_ME = 99;

    private View rootView;
    private Context context;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.recyclerView)
    RecyclerView recyclerView;
    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.personalIntroduce)
    View personalIntroduce;
    @Bind(R.id.labelLayout)
    FlowLayout labelLayout;
    @Bind(R.id.introduction)
    TextView introduction;
    @Bind(R.id.advantage)
    TextView advantage;
    @Bind(R.id.career)
    TextView career;
    @Bind(R.id.introEmptyView)
    View introEmptyView;
    @Bind(R.id.squareLayout)
    View squareLayout;
    @Bind(R.id.squareImage)
    SimpleDraweeView squareImage;
    @Bind(R.id.squareName)
    TextView squareName;
    @Bind(R.id.squareEmptyView)
    View squareEmptyView;
    @Bind(R.id.tagEmptyView)
    View tagEmptyView;
    @Bind(R.id.tagLayout)
    View tagLayout;
    @Bind(R.id.squareRootLayout)
    View squareRootLayout;
    @Bind(R.id.authGrid)
    GridView authGrid;
    @Bind(R.id.introduceRightIcon)
    View introduceRightIcon;
    @Bind(R.id.labelRightIcon)
    View labelRightIcon;
    @Bind(R.id.squareRightIcon)
    View squareRightIcon;
    @Bind(R.id.storeLayout)
    View storeLayout;
    @Bind(R.id.storeRightIcon)
    View storeRightIcon;
    @Bind(R.id.storeImage)
    SimpleDraweeView storeImage;
    @Bind(R.id.storeName)
    TextView storeName;
    @Bind(R.id.storeAddress)
    TextView storeAddress;
    @Bind(R.id.storePhone)
    TextView storePhone;

    private ScrollToTopEvent scrollToTopEvent;
    private ProfileMeRecycleAdapter profileMeRecycleAdapter;
    private LoadUtil loadUtil;
    private ArrayList<String> labels = new ArrayList<String>();
    private String squareId;
    private MePageDO mePageDO;
    private String userId;
    private boolean isMine;
    private String shopId;
    private ProfileMeAuthGridAdapter profileMeAuthGridAdapter;

    public void setScrollToTopEvent(ScrollToTopEvent scrollToTopEvent) {
        this.scrollToTopEvent = scrollToTopEvent;
    }

    public static ProfileMeFragment newInstance(Bundle params) {
        ProfileMeFragment profileMeFragment = new ProfileMeFragment();
        profileMeFragment.setArguments(params);
        return profileMeFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            Bundle params = getArguments();
            if (params != null) {
                userId = params.getString("userId") == null ? "" : params.getString("userId");
                isMine = userId.equals(Helper.sharedHelper().getUserId());
            }
            rootView = inflater.inflate(R.layout.fragment_profile_me, container, false);
            ButterKnife.bind(this, rootView);
            context = getActivity();
            loadUtil = new LoadUtil(inflater);

            //设置布局管理器
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
            recyclerView.setLayoutManager(linearLayoutManager);
            if (!isMine)
                hideRightIcon();
            initListener();

        }
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initData();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == getActivity().RESULT_OK && Constant.REQUEST_CODE_CHANGE_PROFILE_LABEL == requestCode) {
            Bundle bundle;
            bundle = data.getExtras();
            labels = bundle.getStringArrayList("userTag") == null ? new ArrayList<String>() : bundle.getStringArrayList("userTag");
            initTag();
        }
        if (resultCode == getActivity().RESULT_OK && UPDATE_PROFILE_INTRODUCE == requestCode) {
            initData();
        }
        if(UPDATE_PROFILE_ME == requestCode)
            initData();
    }

    private void hideRightIcon() {
        introduceRightIcon.setVisibility(View.GONE);
        labelRightIcon.setVisibility(View.GONE);
        squareRightIcon.setVisibility(View.GONE);
        storeRightIcon.setVisibility(View.GONE);
    }

    private void initListener() {
        scrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:
                        int scrollY = v.getScrollY();
                        scrollToTopEvent.onScrollToTop(scrollY == 0);
                        break;
                }
                return false;
            }
        });
        personalIntroduce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isMine)
                    return;
                Intent intent = new Intent(getActivity(), ProfilePersonalIntroduceActivity.class);
                if (mePageDO != null) {
                    intent.putStringArrayListExtra("imageList", (ArrayList) mePageDO.getImageList());
                    intent.putExtra("introduction", mePageDO.getIntroduction());
                    intent.putExtra("advantage", mePageDO.getAdvantage());
                    intent.putExtra("career", mePageDO.getCareer());
                }
                startActivityForResult(intent, UPDATE_PROFILE_INTRODUCE);
            }
        });
        tagLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isMine)
                    return;
                Bundle bundle = new Bundle();
                bundle.putStringArrayList("userTag", labels);
                Router.sharedRouter().openFormResult("profileLabel", bundle,
                        Constant.REQUEST_CODE_CHANGE_PROFILE_LABEL, getActivity());
            }
        });
        squareRootLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isMine || squareId == null)
                    return;
                Router.sharedRouter().open("squareindex/" + squareId);
            }
        });
        authGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                handlerAuthItem(position);
            }
        });
        storeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isMine || shopId == null)
                    return;
                // 跳转到门店
                Router.sharedRouter().open("shopdetail/" + shopId);
            }
        });
    }

    private void initData() {
        loadUtil.loadPre(rootLayout, scrollView);
        JSONObject params = new JSONObject();
        if (!isMine) {
            params.put("userId", userId);
        }
        HttpClient.get("1.0/user/getMePage", params, MePageDO.class, new HttpClient.HttpCallback<MePageDO>() {
            @Override
            public void onSuccess(MePageDO obj) {
                loadUtil.loadSuccess(scrollView);
                mePageDO = obj;
                if (obj != null) {
                    handlerData(obj);
                }
            }

            @Override
            public void onFail(HttpError error) {
                loadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initData();
                    }
                });
            }
        });
    }

    private void handlerData(MePageDO obj) {
        //个人简介
        int isIntroEmpty = 0;
        if (obj.getImageList() != null && obj.getImageList().size() != 0) {
            recyclerView.setVisibility(View.VISIBLE);
            profileMeRecycleAdapter = new ProfileMeRecycleAdapter(context, obj.getImageList());
            recyclerView.setAdapter(profileMeRecycleAdapter);
        } else {
            isIntroEmpty++;
            recyclerView.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(obj.getIntroduction())) {
            introduction.setVisibility(View.VISIBLE);
            introduction.setText("【自我介绍】" + obj.getIntroduction());
        } else {
            isIntroEmpty++;
            introduction.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(obj.getAdvantage())) {
            advantage.setVisibility(View.VISIBLE);
            advantage.setText("【服务优势】" + obj.getAdvantage());
        } else {
            isIntroEmpty++;
            advantage.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(obj.getCareer())) {
            career.setVisibility(View.VISIBLE);
            career.setText("【职业经历】" + obj.getCareer());
        } else {
            isIntroEmpty++;
            career.setVisibility(View.GONE);
        }
        if (isIntroEmpty == 4) {
            introEmptyView.setVisibility(View.VISIBLE);
        } else
            introEmptyView.setVisibility(View.GONE);
        //服务门店
        initStoreInfo(obj);
        //所在格子
        if (obj.getGeziList() != null && obj.getGeziList().size() != 0) {
            squareLayout.setVisibility(View.VISIBLE);
            squareEmptyView.setVisibility(View.GONE);
            if (!TextUtils.isEmpty(obj.getGeziList().get(0).getGeziPicUrl()))
                squareImage.setImageURI(Uri.parse(obj.getGeziList().get(0).getGeziPicUrl()));
            squareName.setText(obj.getGeziList().get(0).getGeziName());
            squareId = obj.getGeziList().get(0).getGeziId();
        } else {
            squareId = null;
            squareLayout.setVisibility(View.GONE);
            squareEmptyView.setVisibility(View.VISIBLE);
        }
        //个人标签
        labels.clear();
        if (obj.getUserTagList() != null)
            labels.addAll(obj.getUserTagList());
        initTag();
        initAuth(obj);
    }

    //初始化服务门店信息
    private void initStoreInfo(MePageDO obj){
        shopId = obj.getShopId();
        if(TextUtils.isEmpty(shopId)){
            storeLayout.setVisibility(View.GONE);
            return;
        }
        storeLayout.setVisibility(View.VISIBLE);
        if (!TextUtils.isEmpty(obj.getOutletImageUrl())) {
            storeImage.setImageURI(Uri.parse(obj.getOutletImageUrl()));
        }
        if (!TextUtils.isEmpty(obj.getOutletName())) {
            storeName.setText(obj.getOutletName());
        } else
            storeName.setVisibility(View.GONE);
        if (!TextUtils.isEmpty(obj.getOutletAddress())) {
            storeAddress.setText(obj.getOutletAddress());
        } else
            storeAddress.setVisibility(View.GONE);
        if (!TextUtils.isEmpty(obj.getOutletPhone())) {
            storePhone.setText(obj.getOutletPhone());
        } else
            storePhone.setVisibility(View.GONE);
    }

    private void initAuth(MePageDO obj) {
        profileMeAuthGridAdapter = new ProfileMeAuthGridAdapter(context, obj);
        authGrid.setAdapter(profileMeAuthGridAdapter);
    }

    private void handlerAuthItem(int position) {
        boolean isAuth;
        Bundle bundle = new Bundle();
        switch (position) {
            case 0:  //实名认证
                isAuth = "true".equals(mePageDO.getRealAuth());
                if (!isMine && !isAuth)
                    return;
                if (isMine) {
                    Router.sharedRouter().openFormResult("certificationlist", UPDATE_PROFILE_ME, getActivity());
                } else {
                    //h5页面
                }
                break;
            case 1:  //芝麻信用
                isAuth = "true".equals(mePageDO.getZmxyAuth());
                if (!isMine && !isAuth)
                    return;
                String url = "https://xy.alipay.com/auth/whatszhima.htm?view=mobile";
                if (isMine && !isAuth) {
                    // 若未授权，跳转到授权页面
                    url = "http://shenghuozhe.net/events/app_zmxy.html";
                }
                bundle.putString("url", url);
                Router.sharedRouter().openFormResult("web", bundle, UPDATE_PROFILE_ME, getActivity());
                break;
            case 2: //微博账号
                isAuth = "true".equals(mePageDO.getWeiboAuth());
                if (!isMine && !isAuth)
                    return;
                if (isAuth) {
                    bundle.putString("url", "http://m.weibo.cn/u/" + mePageDO.getWeiboAccount());
                    Router.sharedRouter().open("web", bundle);
                } else {
                    Router.sharedRouter().openFormResult("aboutme", UPDATE_PROFILE_ME, getActivity());
                }
                break;
            default:   //证书认证
                if (!isMine && (mePageDO.getSkillText() == null || mePageDO.getSkillText().size() == 0))
                    return;
                if (isMine) {
                    Router.sharedRouter().openFormResult("certificationlist/" + Constant.TYPE_PERSONAL, UPDATE_PROFILE_ME, getActivity());
                } else {
                    //h5页面
                }
        }
    }

    private void initTag() {
        labelLayout.removeAllViews();
        if (labels.size() > 0) {
            for (String label : labels) {
                if (TextUtils.isEmpty(label))
                    break;
                TextView itemView = (TextView) LayoutInflater.from(context).inflate(R.layout.item_profile_me_label, labelLayout, false);
                itemView.setText(label.trim());
                labelLayout.addView(itemView);
            }
        }
        if (labelLayout.getChildCount() == 0) {
            tagEmptyView.setVisibility(View.VISIBLE);
            labelLayout.setVisibility(View.GONE);
        } else {
            tagEmptyView.setVisibility(View.GONE);
            labelLayout.setVisibility(View.VISIBLE);
        }
    }

}
