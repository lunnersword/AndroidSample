package com.meidalife.shz.activity.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.DynamicDetailActivity;
import com.meidalife.shz.activity.ReportActivity;
import com.meidalife.shz.adapter.ProfileActionListAdapter;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.ProfileActionCommentEvent;
import com.meidalife.shz.event.ScrollToTopEvent;
import com.meidalife.shz.event.type.DynamicRefreshTypeEnum;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicBottomDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.rest.model.ProfileFeedDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.widget.BaseRewardPopupWindow;
import com.meidalife.shz.widget.PopupRecycleMenu;
import com.meidalife.shz.widget.RandRewardPopupWindow;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 个人主页-动态
 * Created by liujian on 16/4/6.
 */
public class ProfileActionFragment extends BaseFragment {

    private static final int MENU_ITEM_SHARE = 0;
    private static final int MENU_ITEM_DELETE = 1;

    @Bind(R.id.myListView)
    ListView myListView;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.emptyView)
    View emptyView;
    @Bind(R.id.emptyViewText)
    TextView emptyViewText;


    private View rootView;
    private ProfileActionListAdapter profileActionListAdapter;
    private ScrollToTopEvent scrollToTopEvent;
    private PopupRecycleMenu popupRecycleMenu;
    private LoadUtil loadUtil;
    private Context context;
    private int page;
    private final int pageSize = 15;
    private boolean isLoading;
    private boolean isComplete;
    private String userId;
    private List<ProfileFeedDO> profileFeedDOs;
    private boolean isMine;
    // 定义打赏PopupWindow
    private RandRewardPopupWindow mRewardWindow;

    public void setScrollToTopEvent(ScrollToTopEvent scrollToTopEvent) {
        this.scrollToTopEvent = scrollToTopEvent;
    }

    public static ProfileActionFragment newInstance(Bundle params) {
        ProfileActionFragment profileActionFragment = new ProfileActionFragment();
        profileActionFragment.setArguments(params);
        return profileActionFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        EventBus.getDefault().register(this);
        if (rootView == null) {
            Bundle params = getArguments();
            userId = "";
            if (params != null) {
                userId = params.getString("userId") == null ? "" : params.getString("userId");
            }
            rootView = inflater.inflate(R.layout.fragment_profile_comment, container, false);
            context = getActivity();
            ButterKnife.bind(this, rootView);
            loadUtil = new LoadUtil(inflater);
            isMine = userId.equals(Helper.sharedHelper().getUserId());
            if (isMine) {
                emptyViewText.setText(context.getResources().getString(R.string.text_empty_my_profile_action));
            } else {
                emptyViewText.setText(context.getResources().getString(R.string.text_empty_ta_profile_action));
            }
            profileFeedDOs = new ArrayList<ProfileFeedDO>();
            profileActionListAdapter = new ProfileActionListAdapter(getActivity(), profileFeedDOs);
            myListView.setAdapter(profileActionListAdapter);

            initListener();
        }
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getData(true);
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
        super.onDestroyView();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == Constant.REQUEST_CODE_REWARD) {
//            if (data != null) {
//                int rewardAmount = data.getIntExtra("amount", 0);
//                String desc = data.getStringExtra("rewardsDesc");
//                boolean result = data.getBooleanExtra(Pay.TAG_PAY_RESULT, false);
//                if (result && rewardAmount > 0 && rewardPos < profileFeedDOs.size()) {
//                    // 更新打赏总额
//                    ProfileFeedDO item = profileFeedDOs.get(rewardPos);
//                    item.setBonusCount(rewardAmount / 1000 + item.getBonusCount());
//                    profileFeedDOs.set(rewardPos, item);
//                    profileActionListAdapter.notifyDataSetChanged();
//                } else {
//                    MessageUtils.showToast(R.string.reward_failed);
//                }
//            }
//        }
    }

    public void onEvent(ProfileActionCommentEvent event) {
        //评论动态
        if (event.eventType == MsgTypeEnum.TYPE_REFRESH) {
            ProfileFeedDO item = profileFeedDOs.get(event.getPosition());
            DynamicBottomDO comment = new DynamicBottomDO();
            comment.setReplyNick(event.getNickName());
            comment.setContent(event.getContent());
            item.getComments().addFirst(comment);
            item.setReplyCount(item.getReplyCount() + 1);
            profileFeedDOs.set(event.getPosition(), item);
            profileActionListAdapter.notifyDataSetChanged();
        }

    }

    private void addComment(int position, int commentPos) {
        ProfileActionCommentEvent event = new ProfileActionCommentEvent(MsgTypeEnum.TYPE_PROFILE_ACTION_COMMENT);
        event.setFeedId(profileFeedDOs.get(position).getFeedId());
        event.setUserId(profileFeedDOs.get(position).getUser().getUserId());
        if (commentPos != -1) {
            event.setReplyUserId(profileFeedDOs.get(position).getComments().get(commentPos).getUser().getUserId());
            event.setNickName(profileFeedDOs.get(position).getComments().get(commentPos).getUser().getUserNick());
        }
        event.setPosition(position);
        EventBus.getDefault().post(event);
    }

    private void initListener() {
        profileActionListAdapter.setOnShowPopListener(new ProfileActionListAdapter.OnShowPopListener() {
            @Override
            public void showPop(View v, int position) {
                showItemPop(v, position);
            }
        });
        profileActionListAdapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String, String> tag = (HashMap<String, String>) v.getTag();
                int position = 0;
                if (tag.get("position") != null)
                    position = Integer.parseInt(tag.get("position"));
                switch (v.getId()) {
                    case R.id.supportLayout:   // 赞
                        handlerSupport(position);
                        break;
                    case R.id.rewardLayout:   //打赏
                        if (isMine)
                            return;
                        //实现弹窗
                        onClickReward(v, position);
//                        rewardPos = position;
//                        Bundle params = new Bundle();
//                        params.putString("receiverId", profileFeedDOs.get(position).getUser().getUserId());
//                        params.putString("avatar", profileFeedDOs.get(position).getUser().getAvatarUrl());
//                        Router.sharedRouter().openFormResult("rewards", params,
//                                Constant.REQUEST_CODE_REWARD, getActivity());
                        break;
                    case R.id.messageLayout:   //评论
                        addComment(position, -1);
                        break;
                }
                if (tag.get("commentPos") != null && !"-1".equals(tag.get("commentPos"))) {
                    int commentPos = Integer.parseInt(tag.get("commentPos"));
                    addComment(position, commentPos);
                }

            }
        });

        myListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1 && !isComplete) {
                        getData(false);
                    }
                }

                final View topChildView = view.getChildAt(0);
                if (scrollState == SCROLL_STATE_IDLE && view.getFirstVisiblePosition() == 0
                        && topChildView != null && topChildView.getTop() == 0) {
                    scrollToTopEvent.onScrollToTop(true);
                } else {
                    scrollToTopEvent.onScrollToTop(false);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

    }

    public void getData(final boolean reload) {
        if (reload) {
            page = 0;
            loadUtil.loadPre(rootLayout, myListView);
        }
        if (isLoading)
            return;
        isLoading = true;
        if (reload) {
            page = 0;
            isComplete = false;
            loadUtil.loadPre(rootLayout, myListView);
        } else {
            if (isComplete) {
                isLoading = false;
                return;
            }
            page++;
        }
        JSONObject params = new JSONObject();
        params.put("offset", pageSize * page);
        params.put("pageSize", pageSize);
        params.put("userId", Helper.sharedHelper().getUserId());
        params.put("posterId", userId);
        HttpClient.searchEnv("1.0/user/feed", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                if (null == getActivity() || getActivity().isFinishing()) {
                    return;
                }
                isLoading = false;
                loadUtil.loadSuccess(myListView);
                if (reload)
                    profileFeedDOs.clear();
                if (obj != null && obj.containsKey("result")) {
                    JSONArray jsonArray = obj.getJSONArray("result");
                    List<ProfileFeedDO> profileFeedDOList = JSON.parseArray(jsonArray.toString(), ProfileFeedDO.class);
                    if (profileFeedDOList != null && profileFeedDOList.size() != 0) {
                        for (int i = 0; i < profileFeedDOList.size(); i++) {
                            profileFeedDOs.add(handlerDateStr(profileFeedDOList.get(i)));
                        }
                    }
                    if (profileFeedDOs.size() == 0) {
                        myListView.setVisibility(View.GONE);
                        emptyView.setVisibility(View.VISIBLE);
                    } else {
                        myListView.setVisibility(View.VISIBLE);
                        emptyView.setVisibility(View.GONE);
                    }
                    if (profileFeedDOList != null && profileFeedDOList.size() < pageSize)
                        isComplete = true;
                }
                profileActionListAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                if (!reload)
                    page--;
                loadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        getData(true);
                    }
                });
            }
        });
    }

    /**
     * yyyy年MM月dd日 HH:mm
     *
     * @param item
     * @return
     */
    private ProfileFeedDO handlerDateStr(ProfileFeedDO item) {
        String dateStr = DateUtils.time2StringShort3(Long.parseLong(item.getCreateTime()));
        String nowDateStr = DateUtils.time2StringShort3(System.currentTimeMillis());
        String lastDateStr = DateUtils.time2StringShort3(Long.parseLong(item.getCreateTime()) + 1000 * 60 * 60 * 24);
        if (nowDateStr.substring(0, 11).equals(lastDateStr.substring(0, 11))) {   //昨天
            item.setPublishDate("昨天");
        } else {
            if (nowDateStr.substring(0, 11).equals(dateStr.substring(0, 11))) {  //同一天
                item.setPublishDate("今天");
            } else {
                item.setPublishDate(dateStr.substring(0, 11));
            }
        }
        item.setPublishHHmm(DateUtils.getOffsetDays(System.currentTimeMillis(), Long.parseLong(item.getCreateTime())));
        return item;
    }

    private void showItemPop(View v, final int pos) {
        if (null == popupRecycleMenu) {
            popupRecycleMenu = new PopupRecycleMenu(getActivity(), R.layout.popup_window_recycle_menu);
        }

        List<MenuVO> menuList = new ArrayList<>();

        menuList.add(MENU_ITEM_SHARE, new MenuVO(R.string.icon_share, getString(R.string.label_share), 1));
        menuList.add(MENU_ITEM_DELETE, new MenuVO(R.string.icon_jubao, getString(isMine ? R.string.delete : R.string.report), 1));

        popupRecycleMenu.setMenuData(menuList);

        if (popupRecycleMenu.isShowing()) {
            popupRecycleMenu.dismiss();
        } else {
            popupRecycleMenu.showAsDropDown((View) v.getParent(), ((View) v.getParent()).getWidth() - (int) Helper.convertDpToPixel(80 * menuList.size() + 15, getActivity()), 0);
        }


        popupRecycleMenu.setOnItemClickListener(new PopupRecycleMenu.OnItemClickListener() {
            @Override
            public void onItemClick(View v, int position) {
                switch (position) {
                    case MENU_ITEM_SHARE: {  //分享
                        popupRecycleMenu.dismiss();

                        break;
                    }
                    case MENU_ITEM_DELETE: {
                        popupRecycleMenu.dismiss();
                        if (isMine) {
                            deleteFeed(pos);
                        } else
                            report(profileFeedDOs.get(pos).getFeedId());
                        break;
                    }
                }
            }
        });
    }

    //举报
    private void report(String id) {
        Intent intent = new Intent();
        intent.setClass(context, ReportActivity.class);
        intent.putExtra("targetId", id);
        intent.putExtra("target", Constant.REPORT_TYPE_USER);
        startActivity(intent);
    }

    private void deleteFeed(final int position) {
        JSONObject params = new JSONObject();
        params.put("feedId", profileFeedDOs.get(position).getFeedId());
        HttpClient.get("1.0/feed/deleteFeed", params, null, new HttpClient.HttpCallback<JSONObject>() {

            @Override
            public void onSuccess(JSONObject obj) {
                profileFeedDOs.remove(position);
                profileActionListAdapter.notifyDataSetChanged();
                BaseEvent event = new BaseEvent(MsgTypeEnum.TYPE_PROFILE_ACTION_DEL_ID);
                EventBus.getDefault().post(event);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error.getMessage());
            }
        });
    }

    //点赞
    private void handlerSupport(final int position) {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("feedId", profileFeedDOs.get(position).getFeedId());
        if (profileFeedDOs.get(position).isSupported()) {
            params.put("type", 1);
        } else {
            params.put("type", 0);
        }

        RequestDynamic.supportOrCancel(params, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                if (profileFeedDOs.get(position).isSupported()) {
                    MessageUtils.showToastCenter("成功取消点赞");
                    profileFeedDOs.get(position).setSupported(false);
                    profileFeedDOs.get(position).setSupportCount(profileFeedDOs.get(position).getSupportCount() - 1);
                } else {
                    MessageUtils.showToastCenter("成功点赞");
                    profileFeedDOs.get(position).setSupported(true);
                    profileFeedDOs.get(position).setSupportCount(profileFeedDOs.get(position).getSupportCount() + 1);
                }
                profileActionListAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "操作失败，请稍后再试");
            }
        });
    }


    // 打赏按钮响应
    void onClickReward(View v, final int position) {
        if (mRewardWindow == null) {
            mRewardWindow = new RandRewardPopupWindow((Activity) getContext(),
                    profileFeedDOs.get(position).getUser().getUserId(), profileFeedDOs.get(position).getUser().getAvatarUrl());
            mRewardWindow.setOnRewardListener(new BaseRewardPopupWindow.OnRewardListener() {
                @Override
                public void onRewardFinished(int amount, String desc) {
                    //  打赏成功处理
                    if (amount > 0 && position < profileFeedDOs.size()) {
                        // 更新打赏总额
                        ProfileFeedDO item = profileFeedDOs.get(position);
                        item.setBonusCount(amount / 100 + item.getBonusCount());
                        profileFeedDOs.set(position, item);
                        profileActionListAdapter.notifyDataSetChanged();
                    } else {
                        MessageUtils.showToast(R.string.reward_failed);
                    }

                }
            });
        }
        mRewardWindow.showScreenCenter(v);
        mRewardWindow.requestRandReward();
    }


    @Override
    public void onPause() {
        super.onPause();
        if (profileActionListAdapter != null)
            profileActionListAdapter.stopCountDown();
    }
}
