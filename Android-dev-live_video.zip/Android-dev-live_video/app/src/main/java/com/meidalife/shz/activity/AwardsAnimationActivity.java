package com.meidalife.shz.activity;

import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.usepropeller.routable.Router;

import java.lang.reflect.Field;

/**
 * Created by shijian on 15/7/30.
 */
public class AwardsAnimationActivity extends Activity {

    private Handler handler;

    private String pointId;
    private String count;

    private ImageView awardsImg;
    private TextView awardsTip;
    private TextView awardsBt;
    private View awardsTipGroup;
    private View closeBt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.awards_animation);

        Bundle extras = getIntent().getExtras();
        pointId = extras.getString("pointId");
        count = extras.getString("count");

        handler = new Handler();

        awardsImg = (ImageView) findViewById(R.id.awards_animation_img);
        awardsTip = (TextView) findViewById(R.id.awards_animation_tip);
        awardsTip.setText("恭喜你，奖励" + count + "个M豆");
        awardsBt = (TextView) findViewById(R.id.awards_animation_bt);
        awardsTipGroup = findViewById(R.id.awards_animation_tip_group);
        closeBt = findViewById(R.id.awards_close);

        awardsBt.setOnClickListener(new GainMcoinListener());

        final AnimationDrawable oneAnimation = startAnimation(R.drawable.awards_animation_one);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isEnd(oneAnimation)) {
                    handler.postDelayed(this, 100);
                } else {
                    awardsTipGroup.setVisibility(View.VISIBLE);
                }
            }
        }, 800);
    }


    class GainMcoinListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {

            if (!Helper.sharedHelper().hasToken()) {
                Bundle bundle = new Bundle();
                bundle.putString("action", "mcoin/" + pointId + "/count/" + count);
                Router.sharedRouter().open("signin", bundle);
                finish();
                return;
            }

            awardsBt.setOnClickListener(null);
            awardsBt.setText("领取中...");

            JSONObject params = new JSONObject();
            params.put("issuePointId", pointId);
            HttpClient.get("1.0/point/gain", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject obj) {
                    awardsTip.setText("成功领取" + count + "M豆，快去使用吧");
                    startTwoAnimation();
                }

                @Override
                public void onFail(HttpError error) {
                    awardsTip.setText(error.getMessage());
                    if (error.getCode() < HttpError.ERR_CODE_NETWORK_CODE) {
                        awardsBt.setVisibility(View.GONE);
                        startTwoAnimation();
                    } else {
                        awardsBt.setText("领取M豆");
                        awardsBt.setOnClickListener(GainMcoinListener.this);
                        closeBt.setVisibility(View.VISIBLE);
                        closeBt.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                AwardsAnimationActivity.this.finish();
                            }
                        });
                    }
                }
            });
        }
    }

    public void startTwoAnimation() {

        final AnimationDrawable twoAnimation = startAnimation(R.drawable.awards_animation_two);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isEnd(twoAnimation)) {
                    handler.postDelayed(this, 100);
                } else {
                    awardsTipGroup.setVisibility(View.GONE);
                    ScaleAnimation scaleAnimation = new ScaleAnimation(1f, 0.1f, 1f, 0.1f, Animation.RELATIVE_TO_SELF, Animation.RELATIVE_TO_SELF, Animation.RELATIVE_TO_SELF, Animation.RELATIVE_TO_SELF);
                    scaleAnimation.setDuration(500);
                    awardsImg.setAnimation(scaleAnimation);
                    scaleAnimation.start();
                    scaleAnimation.setAnimationListener(new Animation.AnimationListener() {
                        @Override
                        public void onAnimationStart(Animation animation) {
                        }

                        @Override
                        public void onAnimationEnd(Animation animation) {
                            awardsImg.setVisibility(View.GONE);
                            AwardsAnimationActivity.this.finish();
                        }

                        @Override
                        public void onAnimationRepeat(Animation animation) {
                        }
                    });
                }
            }
        }, 800);

    }


    private AnimationDrawable startAnimation(int id) {
        awardsImg.setImageResource(id);
        AnimationDrawable animationDrawable = (AnimationDrawable) awardsImg.getDrawable();
        animationDrawable.start();
        return animationDrawable;
    }

    private boolean isEnd(AnimationDrawable obj) {
        try {
            Class<AnimationDrawable> animClass = AnimationDrawable.class;
            Field field = animClass.getDeclaredField("mCurFrame");
            field.setAccessible(true);
            int currFrameNum = field.getInt(obj);
            int totalFrameNum = obj.getNumberOfFrames();
            if ((currFrameNum == totalFrameNum - 1) || (currFrameNum == -1)) {
                return true;
            }
        } catch (Exception e) {
            MessageUtils.showToastCenter(getString(R.string.error_server_500));
            Log.e(AwardsAnimationActivity.class.getName(), getString(R.string.error_server_500), e);
        }
        return false;
    }

}
