package com.meidalife.shz.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Spannable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.ChatExpressionFragment;
import com.meidalife.shz.adapter.ShareSocialPlateformAdapter;
import com.meidalife.shz.event.DynamicListRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.media.AudioRecorder;
import com.meidalife.shz.media.PlayMediaService;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicOutDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.SocialShareDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.CounterDownUtil;
import com.meidalife.shz.view.IconTextView;
import com.meidalife.shz.view.RecordTextView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.greenrobot.event.EventBus;

/**
 * Created by zhq on 16/4/4.
 */
public class PublishVoiceDynamicActivity extends BaseActivity {

    String itemId;
    //    boolean uploadComplete = false;
    boolean submit = false;

    boolean isPlaying = false;

    //    private int dynTime = 0;
//    private int newTime = 0;
    AudioRecorder audioRecorder;
    Intent playIntent;
    String voiceFilePath;
    long voiceRecordTime;
    private String voiceFileUrl;

    @Bind(R.id.inputViewGroup)
    ViewGroup inputViewGroup;

    @Bind(R.id.inputEditView)
    EditText inputEditView;
    @Bind(R.id.textDescLimit)
    TextView textDescLimit;

    @Bind(R.id.recordView)
    ViewGroup recordView;
    @Bind(R.id.voiceRecordView)
    RecordTextView voiceRecordView;
    @Bind(R.id.recordTipTV)
    TextView recordTipTV;

    @Bind(R.id.recordVoiceFinishView)
    ViewGroup recordVoiceFinishView;

    @Bind(R.id.playView)
    ViewGroup playView;
    @Bind(R.id.playVoiceButton)
    IconTextView playVoiceButton;
    @Bind(R.id.voiceTimeSpan)
    TextView voiceTimeSpan;
    @Bind(R.id.resetView)
    View resetView;

    @Bind(R.id.rootView)
    ViewGroup rootView;

    @Bind(R.id.chatFaceIcon)
    View iconView;

    @Bind(R.id.share_bottom_view)
    View share_bottom_view;
    @Bind(R.id.share_recycler_view)
    RecyclerView recyclerView;

    @Bind(R.id.selectServiceTips)
    TextView selectServiceTips;
    @Bind(R.id.selectServiceTipsDesc)
    TextView selectServiceTipsDesc;

    @Bind(R.id.relativeServiceViewGroup)
    ViewGroup relativeServiceViewGroup;
    @Bind(R.id.textRelativeService)
    TextView textRelativeService;

    //todo 表情view
    @Bind(R.id.chatFaceGroup)
    ViewGroup chatFaceGroup;
    ViewGroup tabcontent;
    FragmentTabHost mTabHost;


    private ChatHelper chatHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish_voice_dynamic);
        initActionBar("发布语音", true, true);

        ButterKnife.bind(this);
        renderPubButtonView(false);

        hideIMM();
        playIntent = new Intent(this, PlayMediaService.class);

        audioRecorder = new AudioRecorder();
        voiceRecordView.setAudioRecord(audioRecorder);
        voiceRecordView.setMaxRecordTimeLength(120);
        voiceRecordView.setRecordListener(new VoiceRecordListener());

        chatHelper = ChatHelper.getInstance();
        initListener();
        //todo 初始化社会化分享数据 默认都不勾选
        showSocialShareView(recyclerView, new ArrayList<SocialShareDO>());

        mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);

        mTabHost.addTab(getTabSpecView("home", R.layout.item_single_image), ChatExpressionFragment.class, null);

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    private FragmentTabHost.TabSpec getTabSpecView(String tag, int layoutId) {
        return mTabHost.newTabSpec(tag).setIndicator(getLayoutInflater().inflate(layoutId, null));
    }


    //todo 增加录音1-120秒限制
    class VoiceRecordListener implements RecordTextView.RecordListener {
        @Override
        public void recordStart() {
            Log.d("mylisten", "start");
            recordTipTV.setText("松开结束");
            //设置录音button背景
            voiceRecordView.setTextColor(getResources().getColor(R.color.grey_b));
        }

        @Override
        public void recording(double voiceValue, float time) {
            //todo 弹出窗 提示正在录音
        }

        @Override
        public void recordCancel() {
            voiceRecordView.setTextColor(getResources().getColor(R.color.brand));
            recordTipTV.setText(getResources().getString(R.string.pub_dynamic_voice_tip));
            voiceTimeSpan.setText("00:00");
            //设置录音button背景
        }

        @Override
        public void recordEnd(String filePath, long recordTime) {
            Log.e("PublishVoiceDynamic", "record voice end, file = " + filePath + ", record time = " + recordTime);
            Log.d("mylisten", "end");
            //录音界面结束  显示播放界面

            voiceFilePath = filePath;
            voiceRecordTime = recordTime;

            recordTipTV.setText("录音结束");
            recordView.setVisibility(View.GONE);

            recordVoiceFinishView.setVisibility(View.VISIBLE);
            //todo 秒数转变成分钟
            voiceTimeSpan.setText("" + recordTime);

            inputViewGroup.setVisibility(View.VISIBLE);

            xhrUploadVoiceFile();
        }

        @Override
        public void recordTooShort() {
            voiceRecordView.setTextColor(getResources().getColor(R.color.brand));
            recordTipTV.setText(getResources().getString(R.string.pub_dynamic_voice_tip));
        }

    }

    private void renderPubButtonView(boolean pubButtonEnable) {
        if (pubButtonEnable) {
            mButtonRight.setEnabled(true);
            mButtonRight.setBackgroundColor(getResources().getColor(R.color.brand));
            mButtonRight.setTextColor(getResources().getColor(R.color.brand_c));
        } else {
            mButtonRight.setEnabled(false);
            mButtonRight.setBackgroundColor(getResources().getColor(R.color.grey_s));
            mButtonRight.setTextColor(getResources().getColor(R.color.grey_j));
        }
    }

    void initListener() {
        playView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                CounterDownUtil counterDown = new CounterDownUtil(PublishVoiceDynamicActivity.this, voiceRecordTime * 1000, 1000, playVoiceButton, voiceTimeSpan);

                if (isPlaying) {
                    playVoiceButton.setText(getResources().getString(R.string.icon_play));
                    stopService(playIntent);
                    counterDown.onFinish();
                } else {
                    playVoiceButton.setText(getResources().getString(R.string.icon_pause));
                    playIntent.putExtra(PlayMediaService.INTENT_MEDIA_PLAY, voiceFilePath);
                    startService(playIntent);
                    counterDown.start();
                }
                isPlaying = !isPlaying;
            }
        });

        resetView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(playIntent);
                recordView.setVisibility(View.VISIBLE);
                voiceRecordView.setTextColor(getResources().getColor(R.color.brand));

                inputViewGroup.setVisibility(View.INVISIBLE);

                recordVoiceFinishView.setVisibility(View.GONE);
                recordTipTV.setText(getResources().getString(R.string.pub_dynamic_voice_tip));

                audioRecorder.deleteOldFile();
                voiceFileUrl = "";
            }
        });

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handlePublish(v);
            }
        });

        inputEditView.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
                    return true;
                }
                return false;
            }
        });

        inputEditView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textDescLimit.setText(String.valueOf(s.toString().length()));
                if (s.toString().length() > 300) {
                    textDescLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textDescLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        inputEditView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share_bottom_view.setVisibility(View.GONE);
                chatFaceGroup.setVisibility(View.GONE);
                iconView.setVisibility(View.VISIBLE);
            }
        });

        inputEditView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    iconView.setVisibility(View.VISIBLE);
                    share_bottom_view.setVisibility(View.GONE);
                } else {
                    iconView.setVisibility(View.GONE);
                    chatFaceGroup.setVisibility(View.GONE);
                    share_bottom_view.setVisibility(View.VISIBLE);
                }
            }
        });

        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share_bottom_view.setVisibility(View.VISIBLE);
                iconView.setVisibility(View.GONE);
                chatFaceGroup.setVisibility(View.GONE);
                hideKeyboard();
            }
        });

        iconView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chatFaceGroup.setVisibility(View.VISIBLE);
//                chatFaceGroup.setDisplayedChild(2);
                hideKeyboard();
            }
        });

        mButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleBack(v);
            }
        });
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(inputEditView.getWindowToken(), 0);
    }

    public void showSocialShareView(RecyclerView recyclerView, List<SocialShareDO> dataList) {

        recyclerView.removeAllViews();
        if (CollectionUtil.isEmpty(dataList)) {
            recyclerView.setVisibility(View.GONE);
            return;
        }
        recyclerView.setVisibility(View.VISIBLE);

        recyclerView.setHasFixedSize(true);

        final LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(new ShareSocialPlateformAdapter(this, dataList));
    }

    public void handleSelectService(View view) {
        if (itemId != null) {
            Bundle bundle = new Bundle();
            bundle.putString("itemId", itemId);
            Router.sharedRouter().openFormResult("bind/service", bundle,
                    Constant.REQUEST_CODE_PICK_SERVICE, this);
        } else {
            Router.sharedRouter().openFormResult("bind/service",
                    Constant.REQUEST_CODE_PICK_SERVICE, this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Bundle bundle;
        switch (requestCode) {
            case Constant.REQUEST_CODE_PICK_SERVICE:
                if (resultCode == RESULT_OK) {
                    bundle = data.getExtras();
                    itemId = bundle.getString("itemId");
                    textRelativeService.setText(bundle.getString("title"));
                    if (TextUtils.isEmpty(itemId)) {
                        relativeServiceViewGroup.setVisibility(View.GONE);
                        selectServiceTips.setVisibility(View.VISIBLE);
                        selectServiceTipsDesc.setVisibility(View.VISIBLE);
                    } else {
                        relativeServiceViewGroup.setVisibility(View.VISIBLE);
                        selectServiceTips.setVisibility(View.GONE);
                        selectServiceTipsDesc.setVisibility(View.GONE);
                    }
                }
                break;
            default:
                break;
        }
    }

    @OnClick(R.id.action_bar_button_right)
    public void handlePublish(View view) {
        if (TextUtils.isEmpty(voiceFileUrl)) {
            xhrUploadVoiceFile();
        } else {
            xhrPublish();
        }
    }

    public void xhrUploadVoiceFile() {
        if (TextUtils.isEmpty(voiceFilePath)) {
            MessageUtils.showToast("语音文件为空 请重新录制");
            return;
        }
        RequestSign.uploadVoice(voiceFilePath, new HttpClient.HttpCallback<String>() {
            @Override
            public void onSuccess(String voiceUrl) {
                voiceFileUrl = voiceUrl;
                renderPubButtonView(true);
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    private void xhrPublish() {
        if (submit) {
            return;
        } else {
            submit = true;
            showProgressDialog("正在发布", false);
        }

        JSONObject params = new JSONObject();

        try {
            if (itemId != null) {
                params.put("itemId", itemId);
            }
            if (inputEditView.getText() != null) {
                params.put("description", inputEditView.getText().toString());
            }

            params.put("audioURL", voiceFilePath);
            params.put("audioLength", voiceRecordTime);
            params.put("type", 1);//1:音频

            RequestDynamic.createFeed(params, new HttpClient.HttpCallback<DynamicOutDO>() {
                @Override
                public void onSuccess(DynamicOutDO dynamic) {
                    submit = false;
                    hideProgressDialog();
                    //发布成功 关联服务插动态list
                    if (dynamic != null) {
                        DynamicUserOutDO user = new DynamicUserOutDO();
                        user.setUserId(Helper.sharedHelper().getUserId());
                        user.setUserNick(Helper.sharedHelper().getStringUserInfo(Constant.USER_NICK));
                        user.setUserGender(Helper.sharedHelper().getStringUserInfo(Constant.USER_GENDER));
                        user.setAvatarUrl(Helper.sharedHelper().getStringUserInfo(Constant.USER_AVATAR));
                        dynamic.setUser(user);
                        DynamicListRefreshEvent updateItemEvent = new DynamicListRefreshEvent();
                        updateItemEvent.eventType = MsgTypeEnum.TYPE_PUBLISH;
                        updateItemEvent.dynamic = dynamic;
                        EventBus.getDefault().post(updateItemEvent);
                    }
                    finish();
                }

                @Override
                public void onFail(HttpError error) {
                    submit = false;
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败，请重试");
                }
            });
        } catch (JSONException e) {

        }
    }

    @Override
    public void handleBack(View view) {
//        super.handleBack(view);
        MessageUtils.showDialog(this, "真的要放弃编辑吗？", "", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        if (isPlaying) {
            stopService(playIntent);
        }
    }

    public void onEventMainThread(ChatExpressionFragment.ChatExpressionEvent event) {
        Editable edit = inputEditView.getEditableText();//获取EditText的文字
        int index = inputEditView.getSelectionStart();
        if (index < 0 || index >= edit.length()) {
            edit.append(event.expressionName);
        } else {
            edit.insert(index, event.expressionName);//光标所在位置插入文字
        }
        ImageSpan expressionPan = chatHelper.getImageSpan(event.expressionName, 20);
        if (null != expressionPan) {
            edit.setSpan(expressionPan, index, index + event.expressionName.length(),
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }
}
