package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class PublishDynamicSplashActivity extends BaseActivity {

    @Bind(R.id.voiceDynamic)
    View voiceDynamic;
    @Bind(R.id.textDynamic)
    View textDynamic;
    @Bind(R.id.videoDynamic)
    View videoDynamic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish_dynamic_splash);
        ButterKnife.bind(this);
        initBackBar(true);

        voiceDynamic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleVoiceDynamicPublish(v);

            }
        });
        textDynamic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleTextDynamicPublish(v);
            }
        });
        videoDynamic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleVideoDynamicPublish(v);
            }
        });

    }


    @OnClick(R.id.voiceDynamic)
    public void handleVoiceDynamicPublish(View view) {
        if (Helper.sharedHelper().hasToken()) {
            //todo 跳转到创建动态页面
            Router.sharedRouter().open("pub_dynamic_voice");
            finish();
        } else {
            Router.sharedRouter().open("signin");
        }
    }

    @OnClick(R.id.textDynamic)
    public void handleTextDynamicPublish(View view) {
        if (Helper.sharedHelper().hasToken()) {
            //todo 跳转到创建动态页面
            Router.sharedRouter().open("pub_dynamic_text");
            finish();
        } else {
            Router.sharedRouter().open("signin");
        }
    }

    @OnClick(R.id.videoDynamic)
    public void handleVideoDynamicPublish(View view) {
        if (Helper.sharedHelper().hasToken()) {
            boolean isAgreedLiveRule = Helper.sharedHelper().getBooleanUserInfo(Constant.USER_AGREED_LIVE_RULE, false);
            if (isAgreedLiveRule) {
                Router.sharedRouter().open("liveReady");
            } else {
                Router.sharedRouter().open("liveVideoQualification");
            }
        } else {
            Router.sharedRouter().open("signin");
        }
    }

}
