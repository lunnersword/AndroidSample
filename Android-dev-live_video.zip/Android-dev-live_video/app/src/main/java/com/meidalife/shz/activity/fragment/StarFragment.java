package com.meidalife.shz.activity.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.ShopAdapter;
import com.meidalife.shz.adapter.StarAdapter;
import com.meidalife.shz.event.AttentionUserEvent;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.SquareRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.OccupationDo;
import com.meidalife.shz.rest.model.ShopOutDo;
import com.meidalife.shz.rest.request.RequestSearch;
import com.meidalife.shz.rest.request.RequestSquare;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.widget.OccupationFilterPopupWindow;
import com.meidalife.shz.widget.TutorialPopupWindow;
import com.usepropeller.routable.Router;

import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by zuozheng on 16/12/16.
 * 牛人榜
 */
public class StarFragment extends BaseFragment implements AbsListView.OnScrollListener, ViewPager.OnPageChangeListener {
    private static final String LOG_TAG = "StarFragment";
    private static final int SQUARE_MAX_COUNT = 6;

    private int page;
    private static final int PAGE_SIZE = 10;

    private ShopAdapter mShopAdapter;
    private StarAdapter mStarAdapter;


    private LoadUtil loadUtil;
//    PortalSquareDO squareDO = new PortalSquareDO();

    private AMapLocationManager mLocationManager;
    private boolean needLocation = false;
    LocationDO mLocation;
    List<ShopOutDo> mShopList = new LinkedList<>();
    List<DynamicUserOutDO> mStarList = new LinkedList<>();

    List<OccupationDo> occupationList = new LinkedList<>();


    private OccupationFilterPopupWindow filterPopupWindow;

    private View rootView;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;

    /**
     * user listview
     */
    @Bind(R.id.starListView)
    ListView starListView;

//    @Bind(R.id.mSwipeRefreshLayout)
//    SwipeRefreshLayout mSwipeRefreshLayout;

    @Bind(R.id.dataEmptyView)
    ViewGroup noMsgView;
    @Bind(R.id.dataEmptyTextView)
    TextView noMsgTextView;

    //没有数据提示view
    View noDataHeadTipView;
    TextView starTitleView;
    TextView updateTimeView;
    TextView totalProfessionView;
    View arrowActionView;
    TextView arrowActionIcon;

    ListView shopListView;


    TutorialPopupWindow tutorialPopupWindow;
    ViewGroup storeGroupView;


    String geziId;
    String ocupationId;

    public static StarFragment newInstance(Bundle params) {
        StarFragment starFragment = new StarFragment();
        starFragment.setArguments(params);
        return starFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_star, null);

            ButterKnife.bind(this, rootView);

            mStarAdapter = new StarAdapter(getActivity(), mStarList);
            starListView.setAdapter(mStarAdapter);

            initHeadView(savedInstanceState);

            geziId = getArguments().getString("geziId");

            loadUtil = new LoadUtil(inflater);
            initListener();
        }

        return rootView;
    }

    void initHeadView(Bundle savedInstanceState) {
        View view = getLayoutInflater(savedInstanceState).inflate(R.layout.fragment_star_header, null);

        /**
         * navBodyView
         */
        noDataHeadTipView = view.findViewById(R.id.noDataTipView);

        storeGroupView = (ViewGroup) view.findViewById(R.id.star_store_group);

        starTitleView = (TextView) view.findViewById(R.id.starTitleView);
        updateTimeView = (TextView) view.findViewById(R.id.updateTimeView);
        totalProfessionView = (TextView) view.findViewById(R.id.totalProfessionView);
        arrowActionView = view.findViewById(R.id.star_arrow_action);
        arrowActionIcon = (TextView) view.findViewById(R.id.star_arrow_icon);

        shopListView = (ListView) view.findViewById(R.id.shopListView);
//        mShopAdapter = new ShopAdapter(getActivity(), mShopList);
//        shopListView.setAdapter(mShopAdapter);


        starListView.addHeaderView(view);

//        OccupationDo occu = new OccupationDo();
//        occu.setOcupationId("1");
//        occu.setOcupationName("美发师");
//        occupationList.add(occu);
//        OccupationDo occu1 = new OccupationDo();
//        occu.setOcupationId("2");
//        occu.setOcupationName("美甲");
//        occupationList.add(occu1);
//        OccupationDo occu2 = new OccupationDo();
//        occu.setOcupationId("3");
//        occu.setOcupationName("健身");
//        occupationList.add(occu2);
//        OccupationDo occu3 = new OccupationDo();
//        occu.setOcupationId("4");
//        occu.setOcupationName("教师");
//        occupationList.add(occu3);
//        OccupationDo occu4 = new OccupationDo();
//        occu.setOcupationId("5");
//        occu.setOcupationName("厨师");
//        occupationList.add(occu4);
//        OccupationDo occu5 = new OccupationDo();
//        occu.setOcupationId("6");
//        occu.setOcupationName("哈哈");
//        occupationList.add(occu5);
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mLocationManager = SHZApplication.getInstance().getLocationManager();
        mLocation = mLocationManager.getLocation();

        if (mLocation != null && mLocation.getLongitude() > 0) {
            requestShop(mLocation);
        } else {
            needLocation = true;
            getCurrentLbsLocation();
        }
    }

    void getCurrentLbsLocation() {
        mLocationManager.updateLocation(mLocationChangedListener);
    }

    private AMapLocationManager.LocationChangedListener mLocationChangedListener = new AMapLocationManager.LocationChangedListener() {

        @Override
        public void onLocationUpdateFailed() {
            needLocation = true;

            //定位失败 使用选择城市id请求数据
            mLocation = new LocationDO();
            mLocation.setCityCode(Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE));
            requestShop(mLocation);
        }

        @Override
        public void onLocationChanged(LocationDO location) {
            mLocation = location;
//            updateLBSInfo(location);

            //定位成功 重新请求数据
            requestShop(location);

            if (needLocation) {
                needLocation = false;
            }

        }
    };

    @Override
    public void onResume() {
        super.onResume();
        showTutorial();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    void initListener() {
//        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                mSwipeRefreshLayout.setRefreshing(false);
//                requestShop(mLocation);
//            }
//        });

        starListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
//                if (starListView.getFirstVisiblePosition() >= 1) {
//                    starListView.setVisibility(View.VISIBLE);
//                } else {
//                    starListView.setVisibility(View.GONE);
//                }
            }
        });
        starListView.setCacheColorHint(Color.TRANSPARENT);

        storeGroupView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("geziId", geziId);
                Router.sharedRouter().open("shopList");
            }
        });

        arrowActionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (filterPopupWindow == null) {
                    filterPopupWindow = new OccupationFilterPopupWindow(getActivity());

                }
                filterPopupWindow.setData(occupationList);

                filterPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                    @Override
                    public void onDismiss() {
                        arrowActionIcon.setText(R.string.icon_expan);
//                       title.setTextColor(mContext.getResources().getColor(R.color.grey_c));
//                        icon.setTextColor(mContext.getResources().getColor(R.color.grey_c));
                    }
                });

                filterPopupWindow.setIndexChangeListener(new OccupationFilterPopupWindow.IPopupSelectIndexChangeListener() {
                    @Override
                    public void setIndex(int index) {
                        //todo 选择职业 重新查询用户
                        if (index < occupationList.size()) {
                            OccupationDo occup = occupationList.get(index);
                            if (occup != null) {
                                starTitleView.setText(occup.getOcupationName());
                                ocupationId = occup.getOcupationId();
                                requestStars();
                            }
                        }
                    }
                });

                if (filterPopupWindow.isShowing()) {
                    filterPopupWindow.dismiss();
                } else {
                    filterPopupWindow.showAtLocation(v, Gravity.CENTER_VERTICAL, 0, 0);
                }

            }
        });

    }

    //店铺列表 需要显示距离 需要传poi
    JSONObject getShopParam(LocationDO location) {
        JSONObject params = new JSONObject();
        if (location != null) {
            params.put("cityCode", location.getCityCode());
            params.put("longitude", location.getLongitude());
            params.put("latitude", location.getLatitude());
        }

        params.put("geziId", geziId);
//        params.put("pageSize", PAGE_SIZE);
//        params.put("offset", page * PAGE_SIZE);

        return params;
    }

    JSONObject getStarParam() {
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        params.put("pageSize", PAGE_SIZE);
        params.put("offset", page * PAGE_SIZE);

        if (!TextUtils.isEmpty(ocupationId)) {
            params.put("ocupationId", ocupationId);
        }

        return params;
    }


    private void requestShop(LocationDO location) {
        RequestSquare.shopList(getShopParam(location), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                if (getActivity() == null || getActivity().isFinishing()) {
                    return;
                }

                if (result != null) {
                    if (result.containsKey("title")) {
                        //update the title address name
//                        result.getString("title");
                    }

                    if (result.containsKey("totalCount")) {
                        //update the title address name
//                        result.getIntValue("totalCount");
                    }

                    if (result.containsKey("shopList")) {
                        //todo update card
                        mShopList = JSON.parseArray(result.getString("shopList"), ShopOutDo.class);
                    }

                }

                requestStars();
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    private void requestStars() {
        RequestSearch.searchUser(getStarParam(), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                if (getActivity() == null || getActivity().isFinishing()) {
                    return;
                }
//                mSwipeRefreshLayout.setEnabled(true);
//                mSwipeRefreshLayout.setVisibility(View.VISIBLE);

                //todo update shop view
                updateShopView();
                try {

                    long chartUpdateTime = obj.getLongValue("chartUpdateTime");

                    updateTimeView.setText(String.format("%s更新", DateUtils.time2StringDotShort(chartUpdateTime)));

                    List<DynamicUserOutDO> starList = JSON.parseArray(obj.getString("result"), DynamicUserOutDO.class);

                    JSONObject userChartObj = obj.getJSONObject("userChart");

                    if (userChartObj != null) {

                        if (userChartObj.containsKey("userInfo")) {
                            DynamicUserOutDO user = JSON.parseObject(userChartObj.getString("userInfo"), DynamicUserOutDO.class);

                            if (userChartObj.containsKey("userChart")) {
                                user.setRank(userChartObj.getString("userChart"));
                            }
                            starList.add(0, user);
                        }
                    }

                    if (CollectionUtil.isNotEmpty(starList)) {
                        mStarList.addAll(starList);
                    }

                    if (CollectionUtil.isEmpty(occupationList)) {
                        occupationList = JSON.parseArray(obj.getString("occupations"), OccupationDo.class);
                    }

                    updateStarsView();

                } catch (JSONException e) {

                }
            }

            @Override
            public void onFail(HttpError error) {
//                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    void updateShopView() {
        if (CollectionUtil.isNotEmpty(mShopList)) {
            int maxShopSize = Math.min(2, mShopList.size());
            mShopList = mShopList.subList(0, maxShopSize);

            mShopAdapter = new ShopAdapter(getActivity(), mShopList);
            shopListView.setAdapter(mShopAdapter);
        }
    }

    void updateStarsView() {

        if (CollectionUtil.isEmpty(mStarList)) {
            noMsgView.setVisibility(View.VISIBLE);
//            starListView.setVisibility(View.INVISIBLE);
        } else {
            noMsgView.setVisibility(View.GONE);
//            starListView.setVisibility(View.VISIBLE);
        }

        mStarAdapter.notifyDataSetChanged();
    }

    private void showTutorial() {
        try {
            if (Helper.sharedHelper().getBooleanUserInfo(Constant.SQUARE_FIRST_IN, true) && null != getActivity()) {
                if (tutorialPopupWindow == null) {
                    tutorialPopupWindow = new TutorialPopupWindow(getActivity(),
                            TutorialPopupWindow.TUTORIAL_TYPE_ENTER_SQUARE);

                    tutorialPopupWindow.setOnFinishListener(new TutorialPopupWindow.OnFinishListener() {
                        @Override
                        public void onFinish() {
                            Helper.sharedHelper().setBooleanUserInfo(Constant.SQUARE_FIRST_IN, false);
                        }
                    });
                }
                if (!tutorialPopupWindow.isShowing() && !getActivity().isFinishing()) {
                    tutorialPopupWindow.showTutorial(rootView);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {

    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

    }


    public void onEvent(BaseEvent mEvent) {
        if (mEvent instanceof AttentionUserEvent) {
            AttentionUserEvent event = (AttentionUserEvent) mEvent;

            if (MsgTypeEnum.TYPE_ATTENTION_USER == event.eventType && CollectionUtil.isNotEmpty(mStarList)) {
                //全局关注或取消关注事件 更新
                for (DynamicUserOutDO user : mStarList) {
                    if (user != null && user.getUserId().equals(event.userId)) {
                        user.setFocused(true);
                    }
                }
                mStarAdapter.notifyDataSetChanged();
            }
        } else if (mEvent instanceof SquareRefreshEvent) {
            SquareRefreshEvent event = (SquareRefreshEvent) mEvent;
            if (MsgTypeEnum.TYPE_REFRESH == event.eventType) {
                requestShop(mLocation);
            }
        }

    }
}
