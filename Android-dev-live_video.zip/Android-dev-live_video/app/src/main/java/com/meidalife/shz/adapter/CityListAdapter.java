package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CityItem;
import com.meidalife.shz.widget.CheckableIconText;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by fufeng on 16/3/14.
 */
class CityListAdapter extends BaseAdapter {
    Context mContext;
    List<CityItem> cityItemList = new ArrayList<>();
    private OnCitySelectListener onCitySelectListener;

    public CityListAdapter(Context context, List<CityItem> cityItems) {
        mContext = context;
        cityItemList = cityItems;
    }

    public interface OnCitySelectListener {
        void onSelcet(CityItem item);
        void unSelcet(CityItem item);
    }

    public void setOnCitySelectListener(OnCitySelectListener onCitySelectListener) {
        this.onCitySelectListener = onCitySelectListener;
    }


    @Override
    public int getCount() {
        return cityItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return cityItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.item_sub_city_item, parent, false);
            holder.cityGroupName = (TextView) convertView.findViewById(R.id.cityGroupName);
            holder.checkIcon = (CheckableIconText) convertView.findViewById(R.id.checkIcon);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final CityItem cityItem = cityItemList.get(position);
        holder.cityGroupName.setText(cityItemList.get(position).getName());

        holder.checkIcon.setChecked(cityItem.getState() != CityItem.STATE_UNSELECT);
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (selectIds.contains(cityItem.getCode())) {
//                    selectIds.remove(cityItem.getCode());
//                } else {
//                    selectIds.add(cityItem.getCode());
//                }
                if(cityItem.getState() == CityItem.STATE_UNSELECT) {
                    cityItem.setState(CityItem.STATE_ALL_SELECT);
                    if (onCitySelectListener != null) {
                        onCitySelectListener.onSelcet(cityItem);
                    }
                }else {
                    cityItem.setState(CityItem.STATE_UNSELECT);
                    if (onCitySelectListener != null) {
                        onCitySelectListener.unSelcet(cityItem);
                    }
                }
                holder.checkIcon.setChecked(cityItem.getState() != CityItem.STATE_UNSELECT);


            }
        });
        return convertView;
    }

    class ViewHolder {
        CheckableIconText checkIcon;
        TextView cityGroupName;
    }
}