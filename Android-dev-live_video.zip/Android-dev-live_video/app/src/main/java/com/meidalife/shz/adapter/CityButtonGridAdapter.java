package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CityItem;

import java.util.ArrayList;

/**
 * Created by taber on 15/6/10.
 */
public class CityButtonGridAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<CityItem> mData;
    LayoutInflater mInflater;
    private CityAdapter.OnClickListener mOnClickCellListener;

    static class ViewHolder {
        public Button button;
    }

    public CityButtonGridAdapter(Context c, ArrayList<CityItem> data) {
        mContext = c;
        mData = data;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void setOnClickCellListener(CityAdapter.OnClickListener listener) {
        mOnClickCellListener = listener;
    }

    public int getCount() {
        return mData.size();
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        CityItem item = mData.get(position);
        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            convertView = mInflater.inflate(R.layout.city_button_list_item, parent, false);
            Button button = (Button) convertView.findViewById(R.id.cityButton);
            holder = new ViewHolder();
            holder.button = button;
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.button.setText(item.getName());
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mOnClickCellListener.onClick(v, (CityItem) mData.get(position));
            }
        });

        return convertView;
    }
}
