package com.meidalife.shz.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Spannable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.ChatExpressionFragment;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.adapter.ShareSocialPlateformAdapter;
import com.meidalife.shz.event.DynamicListRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.DynamicOutDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.SocialShareDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.view.MyGridView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.greenrobot.event.EventBus;

/**
 * Created by zhq on 16/4/4.
 */
public class PublishTextDynamicActivity extends BaseActivity {


    ArrayList images;
    PublishGridAdapter adapter;
    String itemId;

    HashMap uploadImages = new HashMap();
    boolean uploadComplete = false;
    boolean submit = false;
    boolean uploading = false;

    private boolean descEmpty = true;

    @Bind(R.id.inputEditView)
    EditText inputEditView;
    @Bind(R.id.gridViewImages)
    MyGridView gridViewImages;

    @Bind(R.id.selectServiceTips)
    TextView selectServiceTips;
    @Bind(R.id.selectServiceTipsDesc)
    TextView selectServiceTipsDesc;

    @Bind(R.id.relativeServiceViewGroup)
    ViewGroup relativeServiceViewGroup;
    @Bind(R.id.textRelativeService)
    TextView textRelativeService;

    @Bind(R.id.rootView)
    ViewGroup rootView;
//    @Bind(R.id.scrollView)
//    ScrollView scrollView;

    @Bind(R.id.chatFaceIcon)
    View iconView;

    @Bind(R.id.share_bottom_view)
    View share_bottom_view;
    @Bind(R.id.share_recycler_view)
    RecyclerView recyclerView;

    @Bind(R.id.textDescLimit)
    TextView textDescLimit;
    //todo 表情view
    @Bind(R.id.chatFaceGroup)
    ViewGroup chatFaceGroup;
    //    @Bind(android.R.id.tabcontent)
    ViewGroup tabcontent;
    //    @Bind(android.R.id.tabhost)
    FragmentTabHost mTabHost;

    private ChatHelper chatHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish_text_dynamic);
        initActionBar("发布图片/文字", true, true);

        ButterKnife.bind(this);

        hideIMM();

        renderPubButtonView();
        images = new ArrayList();
        adapter = new PublishGridAdapter(this, images, Constant.MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_OTHER);
        gridViewImages.setAdapter(adapter);

        chatHelper = ChatHelper.getInstance();
        initListener();

        //todo 初始化社会化分享数据 默认都不勾选
        showSocialShareView(recyclerView, new ArrayList<SocialShareDO>());


        mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);

        mTabHost.addTab(getTabSpecView("home", R.layout.item_single_image), ChatExpressionFragment.class, null);

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    private FragmentTabHost.TabSpec getTabSpecView(String tag, int layoutId) {
        return mTabHost.newTabSpec(tag).setIndicator(getLayoutInflater().inflate(layoutId, null));
    }

    void initListener() {
        adapter.setOnClickPlusListener(new PublishGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                Bundle bundle = new Bundle();
                bundle.putBoolean("isCheckbox", true);
                bundle.putInt("maxLength", Constant.MAX_IMAGE_LENGTH - images.size());
                Router.sharedRouter().openFormResult("pick/photo", bundle,
                        Constant.REQUEST_CODE_PICK_PHOTO, PublishTextDynamicActivity.this);
            }
        });
        adapter.setOnClickRemoveListener(new PublishGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                if (position < images.size()) {
                    images.remove(position);
                    adapter.notifyDataSetChanged();
                    //删除图片需要更新发布button状态
                }
                renderPubButtonView();
            }
        });
        gridViewImages.setOnItemClickListener(adapter);

        inputEditView.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
                    return true;
                }
                return false;
            }
        });

        inputEditView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textDescLimit.setText(String.valueOf(s.toString().length()));
                if (s.toString().length() > 300) {
                    textDescLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textDescLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
                descEmpty = TextUtils.isEmpty(s.toString()) ? true : false;
                renderPubButtonView();
            }

            @Override
            public void afterTextChanged(Editable s) {
                share_bottom_view.setVisibility(View.VISIBLE);
            }
        });

        inputEditView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share_bottom_view.setVisibility(View.GONE);
                chatFaceGroup.setVisibility(View.GONE);
                iconView.setVisibility(View.VISIBLE);
            }
        });

        inputEditView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    iconView.setVisibility(View.VISIBLE);
                    share_bottom_view.setVisibility(View.GONE);
                } else {
                    iconView.setVisibility(View.GONE);
                    chatFaceGroup.setVisibility(View.GONE);
                    share_bottom_view.setVisibility(View.VISIBLE);
                }
            }
        });

        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share_bottom_view.setVisibility(View.VISIBLE);
                iconView.setVisibility(View.GONE);
                chatFaceGroup.setVisibility(View.GONE);
                hideKeyboard();
            }
        });
        //icon输入view
        iconView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chatFaceGroup.setVisibility(View.VISIBLE);
//                chatFaceGroup.setDisplayedChild(2);
                hideKeyboard();
            }
        });

        mButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleBack(v);
            }
        });
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(inputEditView.getWindowToken(), 0);
    }

    private void renderPubButtonView() {
        if (descEmpty && CollectionUtil.isEmpty(images)) {
            mButtonRight.setEnabled(false);
            mButtonRight.setBackgroundColor(getResources().getColor(R.color.grey_s));
            mButtonRight.setTextColor(getResources().getColor(R.color.grey_j));
        } else {
            mButtonRight.setEnabled(true);
            mButtonRight.setBackgroundColor(getResources().getColor(R.color.brand));
            mButtonRight.setTextColor(getResources().getColor(R.color.brand_c));
        }
    }

    public void showSocialShareView(RecyclerView recyclerView, List<SocialShareDO> dataList) {

        recyclerView.removeAllViews();
        if (CollectionUtil.isEmpty(dataList)) {
            recyclerView.setVisibility(View.GONE);
            return;
        }
        recyclerView.setVisibility(View.VISIBLE);

        recyclerView.setHasFixedSize(true);

        final LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(new ShareSocialPlateformAdapter(this, dataList));
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Bundle bundle;
        switch (requestCode) {
            case Constant.REQUEST_CODE_PICK_PHOTO:
                if (resultCode == RESULT_OK) {
                    bundle = data.getExtras();
                    ArrayList paths = bundle.getStringArrayList("images");
                    for (int i = 0; i < paths.size(); i++) {
                        // 如果图片列表中没有当前选中的照片，则添加到图片列表中
                        if (images.indexOf(paths.get(i)) == -1) {
                            images.add(paths.get(i));
                        }
                    }
                    adapter.notifyDataSetChanged();
                    uploading = false;
                    uploadComplete = false;
                    uploadImages();

                    renderPubButtonView();
                }
                break;
            case Constant.REQUEST_CODE_PICK_SERVICE:
                if (resultCode == RESULT_OK) {
                    bundle = data.getExtras();
                    itemId = bundle.getString("itemId");
                    textRelativeService.setText(bundle.getString("title"));
                    if (TextUtils.isEmpty(itemId)) {
                        relativeServiceViewGroup.setVisibility(View.GONE);
                        selectServiceTips.setVisibility(View.VISIBLE);
                        selectServiceTipsDesc.setVisibility(View.VISIBLE);
                    } else {
                        relativeServiceViewGroup.setVisibility(View.VISIBLE);
                        selectServiceTips.setVisibility(View.GONE);
                        selectServiceTipsDesc.setVisibility(View.GONE);
                    }
                }
                break;
            default:
        }
    }

    public void handleSelectService(View view) {
        if (itemId != null) {
            Bundle bundle = new Bundle();
            bundle.putString("itemId", itemId);
            Router.sharedRouter().openFormResult("bind/service", bundle,
                    Constant.REQUEST_CODE_PICK_SERVICE, this);
        } else {
            Router.sharedRouter().openFormResult("bind/service",
                    Constant.REQUEST_CODE_PICK_SERVICE, this);
        }
    }

    @OnClick(R.id.action_bar_button_right)
    public void handlePublish(View view) {
        if (!submit) {
            submit = true;
            showProgressDialog("正在发布", false);

            if (uploadComplete) {
                xhrPublish();
            } else {
                uploadImages();
            }
        }
    }

    private void xhrPublish() {
        //图片或文本不能同时为空
        JSONObject params = new JSONObject();

        try {
            if (itemId != null) {
                params.put("itemId", itemId);
            }
            if (inputEditView.getText() != null) {
                params.put("description", inputEditView.getText().toString());
            }
            params.put("images", getUploadImagesUrl());
            params.put("type", 0);//0.图片+文字

            RequestDynamic.createFeed(params, new HttpClient.HttpCallback<DynamicOutDO>() {
                @Override
                public void onSuccess(DynamicOutDO dynamic) {
                    hideProgressDialog();
                    submit = false;
                    //发布成功 关联服务插动态list
                    //dynamic.getLinkedService()
                    if (dynamic != null) {
                        DynamicUserOutDO user = new DynamicUserOutDO();
                        user.setUserId(Helper.sharedHelper().getUserId());
                        user.setUserNick(Helper.sharedHelper().getStringUserInfo(Constant.USER_NICK));
                        user.setUserGender(Helper.sharedHelper().getStringUserInfo(Constant.USER_GENDER));
                        user.setAvatarUrl(Helper.sharedHelper().getStringUserInfo(Constant.USER_AVATAR));
                        dynamic.setUser(user);
                        DynamicListRefreshEvent updateItemEvent = new DynamicListRefreshEvent();
                        updateItemEvent.eventType = MsgTypeEnum.TYPE_PUBLISH;
                        updateItemEvent.dynamic = dynamic;
                        EventBus.getDefault().post(updateItemEvent);
                    }
                    finish();
                }

                @Override
                public void onFail(HttpError error) {
                    hideProgressDialog();
                    submit = false;
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败，请重试");
                }
            });
        } catch (JSONException e) {

        }
    }

    private JSONArray getUploadImagesUrl() {
        JSONArray data = new JSONArray();
        for (int i = 0; i < images.size(); i++) {
            if (uploadImages.containsKey(images.get(i))) {
                data.add(uploadImages.get(images.get(i)));
            }
        }
        return data;
    }

    private void uploadImages() {
        if (!uploading) {
            uploading = true;

            ArrayList uploadQueue = new ArrayList();
            for (int i = 0; i < images.size(); i++) {
                // 如果图片列表中没有当前选中的照片，则添加到图片列表中
                if (!uploadImages.containsKey(images.get(i))) {
                    uploadQueue.add(images.get(i));
                }
            }

            xhrUpdateImages(uploadQueue, 0);
        }
    }

    private void xhrUpdateImages(final ArrayList paths, final int index) {
        if (paths.size() > 0) {
            final String path = (String) paths.get(index);
            RequestSign.upload(path, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    org.json.JSONObject json = (org.json.JSONObject) result;
                    try {
                        uploadImages.put(path, json.getString("data"));
                        if (index == paths.size() - 1) {
                            uploadComplete = true;
                            if (submit) {
                                xhrPublish();
                            }
                        } else {
                            uploadComplete = false;
                            xhrUpdateImages(paths, index + 1);
                        }
                    } catch (org.json.JSONException e) {
                        uploading = false;
                        uploadComplete = false;
                        hideProgressDialog();
                        MessageUtils.showToastCenter(e.getMessage());
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    uploading = false;
                    uploadComplete = false;
                    submit = false;
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "上传图片失败");
                }
            });
        } else {
            uploadComplete = true;
            if (submit) {
                xhrPublish();
            }
        }
    }

    @Override
    public void handleBack(View view) {
//        super.handleBack(view);
        MessageUtils.showDialog(this, "真的要放弃编辑吗？", "", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
    }

    public void onEventMainThread(ChatExpressionFragment.ChatExpressionEvent event) {
        Editable edit = inputEditView.getEditableText();//获取EditText的文字
        int index = inputEditView.getSelectionStart();
        if (index < 0 || index >= edit.length()) {
            edit.append(event.expressionName);
        } else {
            edit.insert(index, event.expressionName);//光标所在位置插入文字
        }
        ImageSpan expressionPan = chatHelper.getImageSpan(event.expressionName, 20);
        if (null != expressionPan) {
            edit.setSpan(expressionPan, index, index + event.expressionName.length(),
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }
}
