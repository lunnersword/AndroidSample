package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.LiveVideoCheckDO;
import com.meidalife.shz.rest.model.LiveVideoListDO;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yiyang on 16/2/18.
 */
public class LiveVideoCheckListAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<LiveVideoCheckDO.CheckList> mCheckLists;
    private LayoutInflater mInflater;

    public LiveVideoCheckListAdapter(Context context, ArrayList<LiveVideoCheckDO.CheckList> checkList) {
        mContext = context;
        mCheckLists = checkList;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mCheckLists.size();
    }

    @Override
    public LiveVideoCheckDO.CheckList getItem(int position) {
        return mCheckLists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LiveVideoCheckDO.CheckList checkList = getItem(position);
        CheckListHolder checkListHolder;
        View view;
        if (convertView == null) {
            view = mInflater.inflate(R.layout.item_live_video_status_check, parent, false);
            checkListHolder = new CheckListHolder(view);
            view.setTag(checkListHolder);
        } else {
            view = convertView;
            checkListHolder = (CheckListHolder) view.getTag();
        }

        checkListHolder.conditionText.setText(checkList.getText());
        if (checkList.isPassed()) {
            checkListHolder.conditionIcon.setText("满足");
            checkListHolder.conditionIcon.setTextColor(mContext.getResources().getColor(R.color.grey_j));
        } else {
            checkListHolder.conditionIcon.setText("未满足");
            checkListHolder.conditionIcon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
        }

        return view;
    }

    static class CheckListHolder {

        @Bind(R.id.conditionText)
        FontTextView conditionText;
        @Bind(R.id.conditionIcon)
        FontTextView conditionIcon;
        @Bind(R.id.conditionTips)
        FontTextView conditionTips;

        public CheckListHolder(View v) {
            ButterKnife.bind(this, v);

        }
    }
}
