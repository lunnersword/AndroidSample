package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/11/13.
 */
public class RedpaperForNewActivity extends Activity {
    private static final String LOG_TAG = RedpaperForNewActivity.class.getSimpleName();
    @Bind(R.id.redPaperSummary)
    TextView redPaperSummary;
    @Bind(R.id.redPaperLayout)
    ViewGroup redPaperLayout;
    @Bind(R.id.getRedpackButton)
    TextView getRedpackButton;
    @Bind(R.id.redPaperTitle)
    TextView totalMoneyText;
    @Bind(R.id.close)
    TextView closeButton;

    @Bind(R.id.getRedpackResult)
    ViewGroup getRedpackResult;
    @Bind(R.id.resultTitle)
    TextView resultTitle;
    @Bind(R.id.resultSummary)
    TextView resultSummary;
    @Bind(R.id.confirmButton)
    TextView confirmButton;

    String redpackIds;
    String totalMoney;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redpaper_for_new);
        redpackIds = getIntent().getStringExtra("redpackIds");
        ButterKnife.bind(this);
        totalMoney = getIntent().getStringExtra("totalMoney");
        getRedpackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gainRedPaper();
            }
        });
        totalMoneyText.setText(StrUtil.getDigitSpanText(String.format(getString(R.string.red_papaer_for_new_title), totalMoney),
                getResources().getColor(R.color.brand_b), getResources().getDimensionPixelSize(R.dimen.font_size_large_xxx)));

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        if (Helper.sharedHelper().hasToken()) {
            redPaperSummary.setVisibility(View.GONE);
        }
        setFinishOnTouchOutside(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Helper.sharedHelper().hasToken()) {
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (Constant.REQUEST_CODE_SIGNIN == requestCode && resultCode == RESULT_OK) {
            //gainRedPaper();
            finish();
        }
    }

    private void gainRedPaper() {
        if (!Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().openFormResult("signin",
                    Constant.REQUEST_CODE_SIGNIN, RedpaperForNewActivity.this);
            return;
        }
        JSONObject params = new JSONObject();
        params.put("redpackIds", redpackIds);
        HttpClient.get("1.0/redpack/gainMulti", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        Log.d(LOG_TAG, obj.toJSONString());
                        String amount = obj.getString("totalMoney");
                        if (!TextUtils.isEmpty(amount)) {
                            resultTitle.setText(getString(R.string.get_redpaper_success_desc1));
                            resultSummary.setText(StrUtil.getDigitSpanText(String.format(getString(R.string.get_redpaper_success_desc2), amount),
                                    getResources().getColor(R.color.brand_b), getResources().getDimensionPixelSize(R.dimen.font_size_large_xxx)));
                        } else {
                            resultTitle.setText(getString(R.string.get_redpaper_fail_desc1));
                            if (TextUtils.isEmpty(obj.getString("msg"))) {
                                resultSummary.setText(getString(R.string.get_redpaper_fail_desc2));
                            } else {
                                resultSummary.setText(obj.getString("msg"));
                            }
                        }

                        getRedpackResult.setVisibility(View.VISIBLE);
                        redPaperLayout.setVisibility(View.GONE);
                    }

                    @Override
                    public void onFail(HttpError error) {
                        getRedpackResult.setVisibility(View.VISIBLE);
                        resultTitle.setText(getString(R.string.get_redpaper_fail_desc1));
                        if (error == null || TextUtils.isEmpty(error.getMessage())) {
                            resultSummary.setText(getString(R.string.get_redpaper_fail_desc2));
                        } else {
                            resultSummary.setText(error.getMessage());
                        }
                        redPaperLayout.setVisibility(View.GONE);
                    }
                }

        );
    }
}
