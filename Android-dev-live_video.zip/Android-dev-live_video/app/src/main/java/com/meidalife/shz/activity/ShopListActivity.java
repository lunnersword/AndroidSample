package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.ShopAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.ShopOutDo;
import com.meidalife.shz.rest.request.RequestSquare;
import com.meidalife.shz.util.CollectionUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 收货地址管理（地址列表）
 */
public class ShopListActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener {

    private int page = 0;
    private int pageSize = 10;

    private boolean isComplete = false;


    String geziId;

    List<ShopOutDo> mShopList;
    ShopAdapter mAdapter;

    @Bind(R.id.rootView)
    LinearLayout rootView;


    @Bind(android.R.id.list)
    ListView listView;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.emptyView)
    ViewGroup emptyView;
    @Bind(R.id.description)
    TextView description;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_list);
        ButterKnife.bind(this);
        initActionBar(R.string.title_activity_shop_list, true);

        mShopList = new ArrayList();
        mAdapter = new ShopAdapter(this, mShopList);
        listView.setAdapter(mAdapter);
        listView.setEmptyView(emptyView);
        description.setText(R.string.no_data);


        mSwipeRefreshLayout.setOnRefreshListener(this);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Router.sharedRouter().open("shopDetail/" + mShopList.get(position).getId());
            }
        });

        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        xhrMoreShopList();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });
        geziId = getIntent().getStringExtra("geziId");

        xhrShopList();
    }

    private void xhrShopList() {
        showStatusLoading(rootView);
        hideStatusErrorServer();
        hideStatusErrorNetwork();

        mShopList.clear();
        isComplete = false;
        RequestSquare.shopList(getParam(), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                hideStatusLoading();
//                listView.setVisibility(View.VISIBLE);
                mSwipeRefreshLayout.setRefreshing(false);


                if (result.containsKey("shopList")) {
                    List<ShopOutDo> tmpList = JSON.parseArray(result.getString("shopList"), ShopOutDo.class);

                    if (CollectionUtil.isEmpty(tmpList) || tmpList.size() < pageSize) {
                        isComplete = true;
                    }
                    mShopList.addAll(tmpList);
                }

                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                mSwipeRefreshLayout.setRefreshing(false);

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrShopList();
                        }
                    });
                } else if (error.getCode() == HttpError.ERR_CODE_NOT_LOGIN) {
                    finish();
                } else {
                    showStatusErrorServer(rootView);
                    if (!TextUtils.isEmpty(error.getMessage())) {
                        setTextErrorServer(error.getMessage());
                    }
                }
            }
        });
    }

    private void xhrMoreShopList() {
        showStatusLoading(rootView);
        hideStatusErrorServer();
        hideStatusErrorNetwork();

        if (isComplete) {
            return;
        }

        page++;

        RequestSquare.shopList(getParam(), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                hideStatusLoading();
                listView.setVisibility(View.VISIBLE);
//                mShopList.clear();

                if (result.containsKey("shopList")) {
                    List<ShopOutDo> tmpList = JSON.parseArray(result.getString("shopList"), ShopOutDo.class);

                    if (CollectionUtil.isEmpty(tmpList) || tmpList.size() < pageSize) {
                        isComplete = true;
                    }
                    mShopList.addAll(tmpList);
                }

                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                page--;
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrShopList();
                        }
                    });
                } else if (error.getCode() == HttpError.ERR_CODE_NOT_LOGIN) {
                    finish();
                } else {
                    showStatusErrorServer(rootView);
                    if (!TextUtils.isEmpty(error.getMessage())) {
                        setTextErrorServer(error.getMessage());
                    }
                }
            }
        });
    }

    JSONObject getParam() {
        JSONObject params = new JSONObject();
        LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();
        if (location != null) {
            params.put("cityCode", location.getCityCode());
            params.put("longitude", location.getLongitude());
            params.put("latitude", location.getLatitude());
        }

        params.put("pageSize", pageSize);
        params.put("offset", page * pageSize);

        //todo add geziId 待确定
        if (!TextUtils.isEmpty(geziId)) {
            params.put("geziId", geziId);
        }

        return params;
    }

    @Override
    public void onRefresh() {
        page = 0;
        xhrShopList();
    }
}
