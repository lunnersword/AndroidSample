package com.meidalife.shz.activity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ScopeOutDO;
import com.meidalife.shz.util.CollectionUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/*
*   服务属性页
*   by yiyang
*/
public class ServiceAttributeActivity extends BaseActivity {

    private ListView listView;

    ArrayList<Map<String, Object>> dateArrayList = new ArrayList<>();
    SimpleAdapter dateListViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_attribute);
        initActionBar(R.string.title_activity_service_attribute, true);

        Bundle intentExtras = getIntent().getExtras();
        String itemId = intentExtras.getString("id");

        listView = (ListView) findViewById(R.id.listView);

        dateListViewAdapter = new SimpleAdapter(this, dateArrayList, R.layout.item_service_attribute, new String[]{"name", "value"}, new int[]{R.id.titleText, R.id.valueText});
        listView.setAdapter(dateListViewAdapter);

        xhrAttribute(itemId);
    }

    private void xhrAttribute(String itemId) {

        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("id", itemId);


        HttpClient.get("1.0/item/getProps", params, ScopeOutDO.class, new HttpClient.HttpCallback<ArrayList<ScopeOutDO>>() {
            @Override
            public void onSuccess(ArrayList<ScopeOutDO> scopeList) {

                if (CollectionUtil.isEmpty(scopeList)) {
                    return;
                }

                for (ScopeOutDO scope : scopeList) {
                    Map<String, Object> items = new HashMap<>();
                    items.put("name", scope.getName());
                    items.put("value", scope.getValue());
                    dateArrayList.add(items);
                }

                dateListViewAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
            }
        });
    }


}
