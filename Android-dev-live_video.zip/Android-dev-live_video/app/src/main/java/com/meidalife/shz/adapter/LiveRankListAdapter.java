package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.LiveRewardRankDO;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.FontTextView;
import com.usepropeller.routable.Router;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yiyang on 16/4/1.
 */
public class LiveRankListAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private Context mContext;
    private List<LiveRewardRankDO> mLiveVideoList;

    public LiveRankListAdapter(Context context, List<LiveRewardRankDO> liveVideoList) {
        mContext = context;
        mLiveVideoList = liveVideoList;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        if (mLiveVideoList.size() > 3)
            return mLiveVideoList.size() - 3;
        else
            return 0;
    }

    @Override
    public LiveRewardRankDO getItem(int position) {
        return mLiveVideoList.get(position + 3);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final LiveRewardRankDO livePayRankDO = getItem(position);
        LiveRankHolder liveRankHolder;
        View view;
        if (convertView == null) {
            view = mInflater.inflate(R.layout.item_live_rank_list, parent, false);
            liveRankHolder = new LiveRankHolder(view);
            view.setTag(liveRankHolder);
        } else {
            view = convertView;
            liveRankHolder = (LiveRankHolder) view.getTag();
        }
        //从3开始计算
        liveRankHolder.rankCount.setText("TOP." + (position + 4));

        String gender = livePayRankDO.getGender();
        // 头像
        ViewGroup.LayoutParams avatarParams = liveRankHolder.imageAvatar.getLayoutParams();
        String userPicUrl = livePayRankDO.getUserAvatar();
        if (TextUtils.isEmpty(userPicUrl) || userPicUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(livePayRankDO.getUserId()), gender);
            liveRankHolder.imageAvatar.setImageURI(getDefaultAvatarUri);

        } else {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(userPicUrl, avatarParams.width));
            liveRankHolder.imageAvatar.setImageURI(uri);
        }

        liveRankHolder.imageAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + livePayRankDO.getUserId());
            }
        });

        liveRankHolder.name.setText(livePayRankDO.getUserName());
        liveRankHolder.moneyCount.setText(String.valueOf(livePayRankDO.getAmount() / 100));
        return view;

    }

    static class LiveRankHolder {

        @Bind(R.id.rankCount)
        FontTextView rankCount;
        @Bind(R.id.imageAvatar)
        SimpleDraweeView imageAvatar;
        @Bind(R.id.name)
        FontTextView name;
        @Bind(R.id.moneyCount)
        FontTextView moneyCount;

        public LiveRankHolder(View view) {
            ButterKnife.bind(this, view);
        }

    }
}
