package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.BitmapVagueUtil;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public class SignUpActivity extends BaseActivity {

    private final static int RESULT_CODE_GET_LABEL = 88;
    public static ArrayList<HashMap<String, String>> data;

    private String action;
    private String avatarUrl;
    private String imageUrl;
    private Boolean submit;
    private Boolean uploading;

    private Button btnSignUp;
    private EditText editTextNickname;
    private LinearLayout genderRadioGroup;
    private TextView textCamera;
//    private SimpleDraweeView imageBanner;
    private SimpleDraweeView btnAvatar;
//    private TextView iconRight;
//    private TextView textConstellation;

//    int constellation;

    Bundle nextBundle;

    private String gender = "";
    private LinearLayout sexMan;
    private LinearLayout sexFemale;
    private TextView manIcon;
    private TextView femaleIcon;
    private TextView femaleLabel;
    private TextView manLabel;
    private VideoView myVideoView;
    private ImageView backgroundView;
    private View backBtn;

    private File cropImage;
    private String playUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        btnSignUp = (Button) findViewById(R.id.btnSignUp);
        editTextNickname = (EditText) findViewById(R.id.editTextNickname);
        textCamera = (TextView) findViewById(R.id.profileCamera);
//        imageBanner = (SimpleDraweeView) findViewById(R.id.profileBanner);
        btnAvatar = (SimpleDraweeView) findViewById(R.id.selectAvatarButton);
//        iconRight = (TextView) findViewById(R.id.iconRight);
//        textConstellation = (TextView) findViewById(R.id.textConstellation);
        sexMan = (LinearLayout)findViewById(R.id.sign_sex_man);
        sexFemale = (LinearLayout)findViewById(R.id.sign_sex_female);
        manIcon = (TextView) findViewById(R.id.sign_sex_man_icon);
        femaleIcon = (TextView) findViewById(R.id.sign_sex_female_icon);
        femaleLabel = (TextView) findViewById(R.id.sign_sex_female_label);
        manLabel = (TextView) findViewById(R.id.sign_sex_man_label);
        myVideoView = (VideoView)findViewById(R.id.myVideoView);
        backgroundView = (ImageView)findViewById(R.id.backgroundView);
        backBtn = findViewById(R.id.action_bar_button_back);

        manIcon.setTypeface(Helper.sharedHelper().getIconFont());
        femaleIcon.setTypeface(Helper.sharedHelper().getIconFont());
        textCamera.setTypeface(Helper.sharedHelper().getIconFont());
//        iconRight.setTypeface(Helper.sharedHelper().getIconFont());

        submit = false;
        uploading = false;
        imageUrl = "";

        playUri = "android.resource://" + getPackageName() + "/" + R.raw.sign_bg;
        initBackground();

        Bundle intentExtras = getIntent().getExtras();
        action = intentExtras != null ? intentExtras.getString("action") : null;

        if (intentExtras != null) {
            nextBundle = intentExtras.getBundle("bundle");
            Bundle userInfo = intentExtras.getBundle("userInfo");

            if (userInfo != null) {
                hideIMM();
                // 昵称
                editTextNickname.setText(userInfo.getString(Constant.USER_NICK));
                // 头像
                imageUrl = userInfo.getString(Constant.USER_AVATAR);
                avatarUrl = imageUrl;
                Uri uri = Uri.parse(imageUrl);
//                imageBanner.setImageURI(uri);
                btnAvatar.setImageURI(uri);
                textCamera.setVisibility(View.GONE);
                // 性别
                boolean isMan = userInfo.getString(Constant.USER_GENDER).equals(Constant.GENDER_MAN);
                if (isMan) {
                    selectSex(Constant.GENDER_MAN);
                } else {
                    selectSex(Constant.GENDER_WOMAN);
                }
            }
        }

        editTextNickname.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
                    return true;
                }
                return false;
            }
        });

        sexMan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constant.GENDER_MAN.equals(gender)) {
                    return;
                } else {
                    selectSex(Constant.GENDER_MAN);
                }
            }
        });
        sexFemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constant.GENDER_WOMAN.equals(gender)) {
                    return;
                } else {
                    selectSex(Constant.GENDER_WOMAN);
                }
            }
        });
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleBack(v);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        if(!TextUtils.isEmpty(playUri)){
            myVideoView.setVideoURI(Uri.parse(playUri));
            myVideoView.start();
        }
    }

    private void initBackground(){
        Bitmap bitmap = BitmapFactory.decodeResource(this.getResources(), R.mipmap.bg_sign_in);
        backgroundView.setImageBitmap(BitmapVagueUtil.getTransparentBitmap(BitmapVagueUtil.fastblur(this, bitmap, 18), 80));
        myVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                myVideoView.start();
            }
        });
    }

    private void selectSex(String sex) {
        if (Constant.GENDER_WOMAN.equals(sex)) {
            sexMan.setBackgroundColor(getResources().getColor(R.color.full_trans));
            manIcon.setTextColor(getResources().getColor(R.color.white));
            manIcon.setBackgroundResource(R.drawable.bg_circle_profile_brand_i);
            manLabel.setTextColor(getResources().getColor(R.color.brand_i));

            sexFemale.setBackgroundResource(R.drawable.sign_sex_rigth_check);
            femaleIcon.setTextColor(getResources().getColor(R.color.profile_gender_red));
            femaleIcon.setBackgroundResource(R.drawable.bg_circle_white);
            femaleLabel.setTextColor(getResources().getColor(R.color.white));
            gender = Constant.GENDER_WOMAN;
        } else {
            sexMan.setBackgroundResource(R.drawable.sign_sex_left_check);
            manIcon.setTextColor(getResources().getColor(R.color.brand_i));
            manIcon.setBackgroundResource(R.drawable.bg_circle_white);
            manLabel.setTextColor(getResources().getColor(R.color.white));

            sexFemale.setBackgroundColor(getResources().getColor(R.color.full_trans));
            femaleIcon.setTextColor(getResources().getColor(R.color.white));
            femaleIcon.setBackgroundResource(R.drawable.bg_circle_profile_red);
            femaleLabel.setTextColor(getResources().getColor(R.color.profile_gender_red));
            gender = Constant.GENDER_MAN;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Helper.ACTIVITY_RESULT_CODE_BACK) {
            setResult(Helper.ACTIVITY_RESULT_CODE_BACK);
            finish();
        } else if (requestCode == Constant.REQUEST_CODE_PICK_PHOTO && RESULT_OK == resultCode) {
            Bundle bundle = data.getExtras();
            ArrayList images = bundle.getStringArrayList("images");

            if (images.size() > 0) {
                avatarUrl = (String) images.get(0);
                Bundle params = new Bundle();
                params.putString("image_path", avatarUrl);
                params.putBoolean("return-data", false);

                cropImage = new File(ImgUtil.getEditedImagePath(this) +
                        File.separator + "cropped_avatar_" + System.currentTimeMillis() + ".jpg");
                params.putParcelable(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cropImage));
                Router.sharedRouter().openFormResult("cropImage", params,
                        Constant.REQUEST_CODE_CROP_PHOTO, SignUpActivity.this);
            }
        } else if (requestCode == Constant.REQUEST_CODE_CROP_PHOTO) {
            if (RESULT_OK == resultCode) {
                if (cropImage != null && cropImage.exists()) {
                    syncAvatar(cropImage.getAbsolutePath());
                    xhrUploadAvatar(cropImage.getAbsolutePath());
                } else {
                    syncAvatar(avatarUrl);
                    xhrUploadAvatar(avatarUrl);
                }
            }
        } else if(requestCode == RESULT_CODE_GET_LABEL && RESULT_OK == resultCode){
            if (action != null) {
                if (nextBundle != null) {
                     Router.sharedRouter().openFormResult(action, nextBundle, SignUpActivity.this);
                } else {
                    Router.sharedRouter().openFormResult(action, SignUpActivity.this);
                }
            }
            setResult(Helper.ACTIVITY_RESULT_CODE_BACK);
            finish();
        }
    }

    public void handlePickAvatar(View view) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", false);
        Router.sharedRouter().openFormResult("pick/photo", bundle, Constant.REQUEST_CODE_PICK_PHOTO, this);
    }

    public void handleSignUp(View view) {
//        if (avatarUrl == null) {
//            MessageUtils.showToastCenter("请上传头像");
//            return;
//        }
        if (editTextNickname.getText().toString().length() == 0) {
            MessageUtils.showToastCenter("请给自己起个响亮的昵称吧");
            return;
        }

        if(TextUtils.isEmpty(gender)){
            MessageUtils.showToastCenter("请给选择性别哦");
            return;
        }
//        if (constellation == 0) {
//            MessageUtils.showToastCenter("请选择您的星座");
//            return;
//        }
        if (!submit) {
            submit = true;
            showProgressDialog("正在注册", false);

            if (!TextUtils.isEmpty(avatarUrl)) {
                xhrUploadAvatar(avatarUrl);
            } else {
                xhrSignUp();
            }
        }
    }
//
//    public void handleSelectConstellation(final View view) {
//        final AlertDialog dialog = new AlertDialog.Builder(this).create();
//        dialog.show();
//        view.setEnabled(false);
//        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
//            @Override
//            public void onDismiss(DialogInterface dialog) {
//                view.setEnabled(true);
//            }
//        });
//        int deviceWidth = this.getResources().getDisplayMetrics().widthPixels;
//        int deviceHeight = this.getResources().getDisplayMetrics().heightPixels;
//        deviceWidth -= deviceWidth / 10;
//        deviceHeight /= 2;
//        dialog.getWindow().setLayout(deviceWidth, deviceHeight);
//        View rootView = getLayoutInflater().inflate(R.layout.view_select_constellation, null);
//        dialog.getWindow().setContentView(rootView);
//        // init view
//        ListView listView = (ListView) rootView.findViewById(R.id.optionConstellation);
//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                dialog.dismiss();
//                constellation = position + 1;
//                HashMap item = data.get(position);
//                textConstellation.setText((String)item.get("name"));
//            }
//        });
//        ConstellationAdapter adapter = new ConstellationAdapter(this, getConstellationData(SignUpActivity.this));
//        listView.setAdapter(adapter);
//        if (constellation > 0) {
//            listView.setItemChecked(constellation - 1, true);
//        }
//    }

    private void syncAvatar(String path) {
        textCamera.setVisibility(View.GONE);
        Uri uri = Uri.fromFile(new File(path));
        btnAvatar.setImageURI(uri);
//        imageBanner.setImageURI(uri);
    }

    private void xhrUploadAvatar(String path) {
        if (!uploading) {
            uploading = true;
            RequestSign.upload(path, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    uploading = false;
                    hideProgressDialog();
                    JSONObject json = (JSONObject) result;
                    try {
                        imageUrl = json.getString("data");
                        if (submit) {
                            xhrSignUp();
                        }
                    } catch (JSONException e) {
                        imageUrl = "";
                        if (submit) {
                            submit = false;
                        }
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    hideProgressDialog();
                    uploading = false;
                    if (error != null) {
                        MessageUtils.showToastCenter(error.getMessage());
                    } else {
                        MessageUtils.showToastCenter("头像上传失败，请重试");
                    }

                    imageUrl = "";
                    if (submit) {
                        submit = false;
                    }
                }
            });
        }
    }

    private void xhrSignUp() {
        try {
            JSONObject params = new JSONObject();
            if (!TextUtils.isEmpty(imageUrl)) {
                params.put("picUrl", imageUrl);
                params.put("backgroundUrl", imageUrl);
            }
            params.put("nick", editTextNickname.getText().toString());
            params.put("gender", gender);
//            params.put("constellation", constellation);

            RequestSign.signUp(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {

                    // 处理IM登录 //todo 注册结束后，立马进行IM鉴权，需要UserId
                    //SignInActivity.authWuKong();

                    // 存储用户昵称
                    Helper.sharedHelper().setStringUserInfo(Constant.USER_NICK, editTextNickname.getText().toString());
                    Helper.sharedHelper().setStringUserInfo(Constant.USER_GENDER, gender);
                    if (!TextUtils.isEmpty(imageUrl)) {
                        Helper.sharedHelper().setStringUserInfo(Constant.USER_AVATAR, imageUrl);
                    }

                    hideProgressDialog();
                    submit = false;

                   // setResult(Helper.ACTIVITY_RESULT_CODE_BACK);
                 //   Router.sharedRouter().openFormResult("signupLable", RESULT_CODE_GET_LABEL,SignUpActivity.this);
                  //  finish();
                }

                @Override
                public void onFailure(HttpError error) {
                    hideProgressDialog();
                    submit = false;
                    if (error != null) {
                        MessageUtils.showToastCenter(error.getMessage());
                    } else {
                        MessageUtils.showToastCenter("注册失败，请重试");
                    }
                }
            });
        } catch (JSONException e) {

        }
    }

    public static ArrayList<HashMap<String, String>> getConstellationData(Context context) {
        if (data != null) {
            return data;
        }

        data = new ArrayList<HashMap<String, String>>();
        String[] names = {
                "白羊座", "金牛座", "双子座",
                "巨蟹座", "狮子座", "处女座",
                "天秤座", "天蝎座", "射手座",
                "魔羯座", "水瓶座", "双鱼座"};
        String[] dates = {
                "3.21-4.19", "4.20-5.20", "5.21-6.21",
                "6.22-7.22", "7.23-8.22", "8.23-9.22",
                "9.23-10.23", "10.24-11.22", "11.23-12.21",
                "12.22-1.19", "1.20-2.18", "2.19-3.20"};
        String[] icons = {
                context.getResources().getString(R.string.icon_xingzhuo_1),
                context.getResources().getString(R.string.icon_xingzhuo_2),
                context.getResources().getString(R.string.icon_xingzhuo_3),
                context.getResources().getString(R.string.icon_xingzhuo_4),
                context.getResources().getString(R.string.icon_xingzhuo_5),
                context.getResources().getString(R.string.icon_xingzhuo_6),
                context.getResources().getString(R.string.icon_xingzhuo_7),
                context.getResources().getString(R.string.icon_xingzhuo_8),
                context.getResources().getString(R.string.icon_xingzhuo_9),
                context.getResources().getString(R.string.icon_xingzhuo_10),
                context.getResources().getString(R.string.icon_xingzhuo_11),
                context.getResources().getString(R.string.icon_xingzhuo_12)};
        for (int i = 0; i < 12; i++) {
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("name", names[i]);
            map.put("date", dates[i]);
            map.put("icon", icons[i]);
            data.add(map);
        }
        return data;
    }
}
