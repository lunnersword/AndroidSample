package com.meidalife.shz.adapter;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.ViewLocationActivity;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.im.Message;
import com.meidalife.shz.im.constants.ImConstants;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/4/6.
 */
public class ChatRecyclerAdapter extends RecyclerView.Adapter implements SensorEventListener {
    public static final int VIEW_TYPE_HEADER = 0;
    private static final int VIEW_TYPE_TEXT = 1;
    private static final int VIEW_TYPE_TEXT_MY = 2;
    private static final int VIEW_TYPE_IMAGE = 3;
    private static final int VIEW_TYPE_IMAGE_MY = 4;
    private static final int VIEW_TYPE_VOICE = 5;
    private static final int VIEW_TYPE_VOICE_MY = 6;
    private static final int VIEW_TYPE_LOCATION = 7;
    private static final int VIEW_TYPE_LOCATION_MY = 8;
    private static final int VIEW_TYPE_SERVICE = 9;
    private static final int VIEW_TYPE_SERVICE_MY = 10;
    private static final int VIEW_TYPE_REMINDER = 11;
    private static final int VIEW_TYPE_REWARD = 12;
    private static final int VIEW_TYPE_REWARD_MY = 13;
    public static final int VIEW_TYPE_TIME = 14;

    private String remoteAvatar;
    private String remoteNick;
    private String myAvatar;
    private String myNick;
    private List<Message> messageList = new ArrayList<>();
    private Context mContext;
    private LayoutInflater mInflater;
    private MediaPlayer mediaPlayer;
    private SensorManager mManager;
    private AudioManager mAudoManager;
    private ClipboardManager mClipboardManager;
    private ChatHelper chatHelper;

    public ChatRecyclerAdapter(Context context, List<Message> data,
                               String remoteAvatar, String remoteNick) {
        mContext = context;
        mInflater = LayoutInflater.from(context);
        setMessageList(data);
        chatHelper = ChatHelper.getInstance();
        mClipboardManager = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
        this.remoteAvatar = remoteAvatar;
        this.remoteNick = remoteNick;
        myAvatar = Helper.sharedHelper().getStringUserInfo(Constant.USER_AVATAR);
        myNick = Helper.sharedHelper().getStringUserInfo(Constant.USER_NICK);
    }

    public void setMessageList(List<Message> messageList) {
        this.messageList = messageList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case VIEW_TYPE_HEADER: {
                return new HeaderViewHolder(mInflater.inflate(R.layout.view_list_footer, parent, false));
            }
            case VIEW_TYPE_TEXT: {
                return new TextMessageViewHolder(mInflater.inflate(R.layout.message_type_text, parent, false));
            }
            case VIEW_TYPE_TEXT_MY: {
                return new TextMessageViewHolder(mInflater.inflate(R.layout.message_type_text_my, parent, false));
            }
            case VIEW_TYPE_IMAGE: {
                return new ImageMessageViewHolder(mInflater.inflate(R.layout.message_type_image, parent, false));
            }
            case VIEW_TYPE_IMAGE_MY: {
                return new ImageMessageViewHolder(mInflater.inflate(R.layout.message_type_image_my, parent, false));
            }
            case VIEW_TYPE_VOICE: {
                return new VoiceMessageViewHolder(mInflater.inflate(R.layout.message_type_voice, parent, false));
            }
            case VIEW_TYPE_VOICE_MY: {
                return new VoiceMessageViewHolder(mInflater.inflate(R.layout.message_type_voice_my, parent, false));
            }
            case VIEW_TYPE_LOCATION: {
                return new AddressMessageViewHolder(mInflater.inflate(R.layout.message_type_address, parent, false));
            }
            case VIEW_TYPE_LOCATION_MY: {
                return new AddressMessageViewHolder(mInflater.inflate(R.layout.message_type_address_my, parent, false));
            }
            case VIEW_TYPE_SERVICE: {
                return new ServiceMessageViewHolder(mInflater.inflate(R.layout.message_type_service, parent, false));
            }
            case VIEW_TYPE_SERVICE_MY: {
                return new ServiceMessageViewHolder(mInflater.inflate(R.layout.message_type_service_my, parent, false));
            }
            case VIEW_TYPE_REMINDER: {
                return new ReminderMessageHolder(mInflater.inflate(R.layout.message_type_remind, parent, false));
            }
            case VIEW_TYPE_REWARD: {
                return new RewardsMessageHolder(mInflater.inflate(R.layout.message_type_reward, parent, false));
            }
            case VIEW_TYPE_REWARD_MY: {
                return new RewardsMessageHolder(mInflater.inflate(R.layout.message_type_reward_my, parent, false));
            }
            case VIEW_TYPE_TIME: {
                return new TimeLabelHolder(mInflater.inflate(R.layout.message_type_time, parent, false));
            }
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Message message = messageList.get(position);
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_HEADER: {
                break;
            }
            case VIEW_TYPE_TEXT: {
                renderTextMessage((TextMessageViewHolder) holder, message);
                break;
            }
            case VIEW_TYPE_TEXT_MY: {
                renderTextMessage((TextMessageViewHolder) holder, message);
                break;
            }
            case VIEW_TYPE_IMAGE: {
                renderImageMessage((ImageMessageViewHolder) holder, message);
                break;
            }
            case VIEW_TYPE_IMAGE_MY: {
                renderImageMessage((ImageMessageViewHolder) holder, message);
                break;
            }
            case VIEW_TYPE_VOICE: {
                renderVoiceMessage((VoiceMessageViewHolder) holder, message);
                break;
            }
            case VIEW_TYPE_VOICE_MY: {
                renderVoiceMessage((VoiceMessageViewHolder) holder, message);
                break;
            }
            case VIEW_TYPE_LOCATION: {
                renderAddressMessage((AddressMessageViewHolder) holder, message);
                break;
            }
            case VIEW_TYPE_LOCATION_MY: {
                renderAddressMessage((AddressMessageViewHolder) holder, message);
                break;
            }
            case VIEW_TYPE_SERVICE: {
                renderServiceMessage((ServiceMessageViewHolder) holder, message);
                break;
            }
            case VIEW_TYPE_SERVICE_MY: {
                renderServiceMessage((ServiceMessageViewHolder) holder, message);
                break;
            }
            case VIEW_TYPE_REMINDER: {
                renderReminderMessage((ReminderMessageHolder) holder, message);
                break;
            }
            case VIEW_TYPE_REWARD: {
                renderRewardMessage((RewardsMessageHolder) holder, message);
                break;
            }
            case VIEW_TYPE_REWARD_MY: {
                renderRewardMessage((RewardsMessageHolder) holder, message);
                break;
            }
            case VIEW_TYPE_TIME: {
                renderTimeLabel((TimeLabelHolder) holder, message);
                break;
            }
        }
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    @Override
    public int getItemViewType(int position) {
        Message message = messageList.get(position);
        if (null != message.getType()) {
            switch (message.getType()) {
                case TEXT: {
                    return isSendByMe(message) ? VIEW_TYPE_TEXT_MY : VIEW_TYPE_TEXT;
                }
                case IMAGE: {
                    return isSendByMe(message) ? VIEW_TYPE_IMAGE_MY : VIEW_TYPE_IMAGE;
                }
                case VOICE: {
                    return isSendByMe(message) ? VIEW_TYPE_VOICE_MY : VIEW_TYPE_VOICE;
                }
                case LOCATION: {
                    return isSendByMe(message) ? VIEW_TYPE_LOCATION_MY : VIEW_TYPE_LOCATION;
                }
                case SERVICE: {
                    return isSendByMe(message) ? VIEW_TYPE_SERVICE_MY : VIEW_TYPE_SERVICE;
                }
                case REMINDER: {
                    return VIEW_TYPE_REMINDER;
                }
                case REWARD: {
                    return isSendByMe(message) ? VIEW_TYPE_REWARD_MY : VIEW_TYPE_REWARD;
                }
            }
        }

        try {
            return Integer.parseInt(message.getExtension(ImConstants.EXT_TAG_VIEW_TYPE));
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return VIEW_TYPE_REMINDER;
        }
    }

    public void release() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        }

        clearProximitySensor();
    }

    private void renderTextMessage(TextMessageViewHolder holder, final Message message) {
        //设置消息内容
        holder.content.setText(chatHelper.getExpressionSpanText(message.getContent(), 20));

        loadAvatar(holder.avatar, message);

        if (isSendByMe(message) && holder.status != null) {
            holder.status.setText(Message.ReadStatus.READ.equals(message.getReadStatus()) ? "已读" : "未读");
            holder.status.setTextColor(!Message.ReadStatus.READ.equals(message.getReadStatus()) ?
                    mContext.getResources().getColor(R.color.icon_im_service_color) :
                    mContext.getResources().getColor(R.color.grey_c));
        }

        holder.content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View contextMenu = mInflater.inflate(R.layout.message_delete_dialog, null);
                final AlertDialog dialog = new AlertDialog.Builder(mContext).create();
                dialog.setView(contextMenu, 0, 0, 0, 0);
                dialog.show();
                TextView deleteTv = (TextView) contextMenu.findViewById(R.id.singleContextMenu);
                deleteTv.setText(R.string.copy);
                deleteTv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        ClipData clipData = ClipData.newPlainText(null, message.getContent());
                        mClipboardManager.setPrimaryClip(clipData);
                    }
                });
            }
        });
    }

    private void renderImageMessage(ImageMessageViewHolder holder, Message message) {
        final String imgPath = message.getImageUrl();
        int imgWidth = (int) Helper.convertDpToPixel(150, mContext);
        int imgHeight = imgWidth;
        if (imgPath.startsWith("http://")) {
            String imgResizePath = imgPath;
            if (imgPath.contains("laiwang.com")) {    // 说明是来往数据，可增加缩放
                String[] info = imgPath.split("_");
                if (info.length == 3) {
                    float width = Float.parseFloat(info[1]);
                    float height = Float.parseFloat(info[2].split("\\.")[0]);
                    imgHeight = (int) ((height * imgWidth) / width);
                }
                imgResizePath = imgPath + "_" + imgWidth + "x" + imgHeight + ".jpg";
            } else {
                imgResizePath = imgPath;
            }
            ViewGroup.LayoutParams layout = holder.content.getLayoutParams();
            layout.width = imgWidth;
            layout.height = imgHeight;
            holder.content.setLayoutParams(layout);
            holder.content.setImageURI(Uri.parse(imgResizePath));
        } else {
            File imgFile = new File(imgPath);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(imgPath, options);
            float width = options.outWidth;
            float height = options.outHeight;
            imgHeight = (int) ((height * imgWidth) / width);
            ViewGroup.LayoutParams layout = holder.content.getLayoutParams();
            layout.width = imgWidth;
            layout.height = imgHeight;
            holder.content.setLayoutParams(layout);
            holder.content.setImageURI(Uri.fromFile(imgFile));
        }
        holder.content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImagesBrowser(imgPath);
            }
        });
        loadAvatar(holder.avatar, message);
    }

    private void openImagesBrowser(String selectedUrl) {
        ArrayList<String> images = new ArrayList<String>();
        int index = 0;
        for (int i = 0; i < messageList.size(); i++) {
            Message messageDO = messageList.get(i);
            String imgUrl = messageDO.getContent();
            if (!TextUtils.isEmpty(imgUrl) && Message.MessageType.IMAGE.equals(messageDO.getType())) {
                images.add(imgUrl);
                if (imgUrl.equals(selectedUrl)) {
                    index = images.size() - 1;
                }
            }
        }
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("photos", images);
        bundle.putInt("index", index);
        Router.sharedRouter().open("imageBrowser", bundle);
    }

    private void renderAddressMessage(AddressMessageViewHolder holder, final Message message) {
        loadAvatar(holder.avatar, message);
        int height = (int) Helper.convertDpToPixel(130, mContext);
        int width = (int) Helper.convertDpToPixel(220, mContext);
        Map<String, String> dataMap = message.getExtensions();
        String gps = dataMap.get("coordinate");
        String url = "http://api.map.baidu.com/staticimage?width=" + width +
                "&height=" + height + "&markers=" + gps + "&zoom=18&markerStyles=l,,0xff5e45";
        holder.addressImg.setImageURI(Uri.parse(url));
        String address = dataMap.get("name");
        holder.addressLabel.setText(address);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddressView(message);
            }
        });
    }

    private void openAddressView(Message msg) {
        if (msg != null && msg.getExtensions() != null) {
            try {
                String gps = msg.getExtensions().get("coordinate");
                if (!TextUtils.isEmpty(gps)) {
                    String[] posxyArray = gps.split(",");
                    if (posxyArray.length > 1) {
                        Bundle bundle = new Bundle();
                        bundle.putDouble(ViewLocationActivity.LOCATION_LNG,
                                Double.parseDouble(posxyArray[0]));
                        bundle.putDouble(ViewLocationActivity.LOCATION_LAT,
                                Double.parseDouble(posxyArray[1]));
                        Router.sharedRouter().open("viewPosition", bundle);
                    }
                }
            } catch (Exception e) {
                Log.e("viewPosition Error", e.getMessage());
            }
        }
    }

    private void renderVoiceMessage(VoiceMessageViewHolder holder, Message message) {
        loadAvatar(holder.avatar, message);
        final String voiceUrl = message.getVoiceUrl();
        ViewGroup.LayoutParams params = holder.content.getLayoutParams();
        int voiceTime = message.getVoiceTime();

        SimpleDateFormat formatter = new SimpleDateFormat("mm:ss");
        String timeString = formatter.format(new Date(voiceTime * 1000));
        holder.time.setText(timeString);

        int width = (int) Helper.convertDpToPixel((voiceTime * 10 + 55), mContext);
        int maxWidth = holder.content.getResources().getDisplayMetrics().widthPixels - (int) Helper.convertDpToPixel(150, mContext);
        params.width = Math.min(width, maxWidth);
        params.height = (int) Helper.convertDpToPixel(40, mContext);
        holder.content.setLayoutParams(params);

        holder.content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                        releaseMediaPlayer();
                    } else {
                        mediaPlayer = new MediaPlayer();

                        initProximitySensor(mContext);
                        if (mAudoManager != null && mAudoManager.isWiredHeadsetOn()) {
                            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                        } else {
                            mediaPlayer.setAudioStreamType(AudioManager.STREAM_VOICE_CALL);
                        }
                        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mp) {
                                releaseMediaPlayer();
                                clearProximitySensor();
                            }
                        });
                        mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                            @Override
                            public boolean onError(MediaPlayer mp, int what, int extra) {
                                releaseMediaPlayer();
                                clearProximitySensor();
                                return false;
                            }
                        });
                        String path = voiceUrl;
                        if (!voiceUrl.startsWith("http://"))  //若本地文件，增加前缀
                            path = "file:///" + voiceUrl;
                        mediaPlayer.setDataSource(path);
                        mediaPlayer.prepare();
                        mediaPlayer.start();
                    }
                } catch (Exception e) {
                    MessageUtils.showToastCenter("播放语音失败, " + e.getClass().getName());
                }
            }
        });
    }

    private void renderServiceMessage(ServiceMessageViewHolder holder, Message message) {
        loadAvatar(holder.avatar, message);
        final Map<String, String> data = message.getExtensions();
        if (!TextUtils.isEmpty(message.getExtension(ImConstants.EXT_TAG_SERVICE_IMAGE))) {
            String cdnUrl = ImgUtil.getCDNUrlWithWidth(message.getExtension(ImConstants.EXT_TAG_SERVICE_IMAGE),
                    mContext.getResources().getDimensionPixelSize(R.dimen.im_service_icon_size));
            holder.itemImage.setImageURI(Uri.parse(cdnUrl));
        }
        holder.itemTitle.setText("我能·" + message.getExtension(ImConstants.EXT_TAG_SERVICE_TITLE));
        holder.itemPrice.setText(StrUtil.getDigitSpanText(message.getExtension(ImConstants.EXT_TAG_SERVICE_PRICE),
                mContext.getResources().getColor(R.color.brand_b), mContext.getResources().getDimensionPixelSize(R.dimen.font_size)));

        if ("1".equals(message.getExtension(ImConstants.EXT_TAG_SERVICE_POINT_SUPPORT))) {
            holder.mCoinSupport.setVisibility(View.VISIBLE);
        } else {
            holder.mCoinSupport.setVisibility(View.GONE);
        }
        if ("1".equals(message.getExtension(ImConstants.EXT_TAG_SERVICE_REDPACK_SUPPORT))) {
            holder.redpackSupport.setVisibility(View.VISIBLE);
        } else {
            holder.redpackSupport.setVisibility(View.GONE);
        }

        int sellCount = -1;
        try {
            if (null != message.getExtension(ImConstants.EXT_TAG_SERVICE_SELL_COUNT)) {
                sellCount = Integer.parseInt(message.getExtension(ImConstants.EXT_TAG_SERVICE_SELL_COUNT));
                holder.sellCount.setText("销量：" + sellCount);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        holder.sellCount.setVisibility(sellCount >= 0 ? View.VISIBLE : View.GONE);

        int commentCount = -1;
        try {
            commentCount = Integer.parseInt(message.getExtension(ImConstants.EXT_TAG_SERVICE_MESSAGE_COUNT));
            holder.commentCount.setText("评价数：" + commentCount);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        holder.commentCount.setVisibility(commentCount >= 0 ? View.VISIBLE : View.GONE);

        holder.itemGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("services/" + data.get(ImConstants.EXT_TAG_SERVICE_ID));
            }
        });
    }

    private void renderReminderMessage(ReminderMessageHolder holder, Message message) {
        try {
            int reminderType = Integer.valueOf(message.getExtension(ImConstants.EXT_TAG_TYPE));
            holder.reminderText.setText(getDefaultReminderText(reminderType, message, isSendByMe(message)));
        } catch (Exception e) {
            e.printStackTrace();
            holder.reminderText.setText(mContext.getString(R.string.unknown_remind_type));
        }
    }

    private String getDefaultReminderText(int type, Message message, boolean isOwner) {
        switch (type) {
            case 1://兼容旧版本稍后删除
            case ImConstants.REMIND_MESSAGE_TYPE_REMINDER: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_reminder_for_owner)
                        : mContext.getResources().getString(R.string.reminder_message_reminder);
            }
            case 2://兼容旧版本稍后删除
            case ImConstants.REMIND_MESSAGE_TYPE_ORDER: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_order_for_owner)
                        : mContext.getResources().getString(R.string.reminder_message_order);
            }
            case 3://兼容旧版本稍后删除
            case ImConstants.REMIND_MESSAGE_TYPE_ORDER_RECEIVE: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_order_receive_for_owner)
                        : mContext.getResources().getString(R.string.reminder_message_order_receive);
            }
            case 4://兼容旧版本稍后删除
            case ImConstants.REMIND_MESSAGE_TYPE_REJECT: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_reject_for_seller)
                        : mContext.getResources().getString(R.string.reminder_message_reject_for_buyer);
            }
            case 5://兼容旧版本稍后删除
            case ImConstants.REMIND_MESSAGE_TYPE_BLOCK: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_block_for_sender)
                        : mContext.getResources().getString(R.string.reminder_message_block_for_receiver);
            }
            case 6://兼容旧版本稍后删除
            case ImConstants.REMIND_MESSAGE_TYPE_UNBLOCK: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_unblock_for_sender)
                        : mContext.getResources().getString(R.string.reminder_message_unblock_for_receiver);
            }
            case ImConstants.REMIND_MESSAGE_TYPE_NOTICE: {
                if (null != message && !TextUtils.isEmpty(message.getExtension("text"))) {
                    return message.getExtension("text");
                }
            }
            default:
        }
        return mContext.getResources().getString(R.string.unknown_remind_type) + ":" + String.valueOf(type);
    }

    private void renderRewardMessage(RewardsMessageHolder holder, final Message message) {
        loadAvatar(holder.avatar, message);
        if (isSendByMe(message) && holder.status != null) {
            holder.status.setText(Message.ReadStatus.READ.equals(message.getReadStatus()) ? "已读" : "未读");
            holder.status.setTextColor(!Message.ReadStatus.READ.equals(message.getReadStatus()) ?
                    mContext.getResources().getColor(R.color.icon_im_service_color) :
                    mContext.getResources().getColor(R.color.grey_c));
        }
        holder.rewardsDesc.setText(message.getExtensions().get("amountDesc"));

        int rewardType = Constant.REWARD_TYPE_IM;
        try {
            if (message.getExtensions().containsKey("rewardType")) {
                rewardType = Integer.parseInt(message.getExtensions().get("rewardType"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        switch (rewardType) {
            case Constant.REWARD_TYPE_IM: {
                holder.rewardSource.setText("聊天打赏");
                break;
            }
            case Constant.REWARD_TYPE_DYNAMIC: {
                holder.rewardSource.setText("来自牛人动态");
                break;
            }
            case Constant.REWARD_TYPE_LIVE: {
                holder.rewardSource.setText("来自视频直播");
                break;
            }
        }

        holder.rewardsLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle params = new Bundle();
                params.putBoolean("showResult", true);

                params.putString("owner", remoteNick);
                params.putString("avatar", remoteAvatar);
                params.putString("amount", message.getExtensions().get("amount"));
                params.putString("rewardsDesc", message.getExtensions().get("amountDesc"));
                Router.sharedRouter().open("rewards", params);
            }
        });
    }

    private void renderTimeLabel(TimeLabelHolder holder, Message message) {
        holder.time.setText(message.getExtension("text"));
    }

    /**
     * 根据消息判断发送方还是接收方，然后设置头像
     *
     * @param avatar
     * @param message
     */
    private void loadAvatar(SimpleDraweeView avatar, final Message message) {
        String url = null;
        if (isSendByMe(message)) {
            url = myAvatar;
        } else {
            url = remoteAvatar;
        }
        avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + message.getSenderId());
            }
        });
        ViewGroup.LayoutParams avatarLayoutParams = avatar.getLayoutParams();
        avatar.setImageURI(Uri.parse(ImgUtil.getCDNUrlWithWidth(url, avatarLayoutParams.width)));
    }

    private void initProximitySensor(Context context) {
        mManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        mAudoManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (null != mManager) {
            mManager.registerListener(this,
                    mManager.getDefaultSensor(Sensor.TYPE_PROXIMITY),
                    SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    private void releaseMediaPlayer() {
        try {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void clearProximitySensor() {
        if (mManager != null) {
            mManager.unregisterListener(this);
        }
    }

    private void openSpeaker() {
        try {
            if (mAudoManager != null && !mAudoManager.isWiredHeadsetOn()) {
                mAudoManager.setSpeakerphoneOn(true);
                mAudoManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                        mAudoManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL),
                        AudioManager.STREAM_VOICE_CALL);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void shutdownSpeaker() {
        try {
            if (mAudoManager != null && !mAudoManager.isWiredHeadsetOn()) {
                mAudoManager.setSpeakerphoneOn(false);
                mAudoManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                        mAudoManager.getStreamVolume(AudioManager.STREAM_VOICE_CALL),
                        AudioManager.STREAM_VOICE_CALL);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            if (event.values[0] < event.sensor.getMaximumRange()) {
                shutdownSpeaker();
            } else {
                openSpeaker();
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    class HeaderViewHolder extends RecyclerView.ViewHolder {

        public HeaderViewHolder(View itemView) {
            super(itemView);
        }
    }

    class TextMessageViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.avatar)
        SimpleDraweeView avatar;
        @Bind(R.id.content)
        TextView content;

        @Nullable
        @Bind(R.id.status)
        TextView status;
        @Nullable
        @Bind(R.id.loading)
        ProgressBar loading;
        @Nullable
        @Bind(R.id.retry)
        Button retry;

        TextMessageViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class ImageMessageViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.avatar)
        SimpleDraweeView avatar;
        @Bind(R.id.content)
        SimpleDraweeView content;
        @Nullable
        @Bind(R.id.status)
        TextView status;
        @Nullable
        @Bind(R.id.loading)
        ProgressBar loading;
        @Nullable
        @Bind(R.id.retry)
        Button retry;

        ImageMessageViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class VoiceMessageViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.avatar)
        SimpleDraweeView avatar;
        @Bind(R.id.content)
        TextView content;
        @Bind(R.id.time)
        TextView time;
        @Nullable
        @Bind(R.id.status)
        TextView status;
        @Nullable
        @Bind(R.id.loading)
        ProgressBar loading;
        @Nullable
        @Bind(R.id.retry)
        Button retry;

        public VoiceMessageViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class ServiceMessageViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.avatar)
        SimpleDraweeView avatar;
        @Bind(R.id.itemGroup)
        View itemGroup;
        @Bind(R.id.item_title)
        TextView itemTitle;
        @Bind(R.id.item_price)
        TextView itemPrice;
        @Bind(R.id.mCoinSupport)
        TextView mCoinSupport;
        @Bind(R.id.redpackSupport)
        TextView redpackSupport;
        @Bind(R.id.sellCount)
        TextView sellCount;
        @Bind(R.id.commentCount)
        TextView commentCount;
        @Bind(R.id.item_image)
        SimpleDraweeView itemImage;
        @Nullable
        @Bind(R.id.status)
        TextView status;
        @Nullable
        @Bind(R.id.loading)
        ProgressBar loading;
        @Nullable
        @Bind(R.id.retry)
        Button retry;

        public ServiceMessageViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class AddressMessageViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.avatar)
        SimpleDraweeView avatar;
        @Bind(R.id.addressImg)
        SimpleDraweeView addressImg;
        @Bind(R.id.addressLabel)
        TextView addressLabel;
        @Nullable
        @Bind(R.id.status)
        TextView status;
        @Nullable
        @Bind(R.id.loading)
        ProgressBar loading;
        @Nullable
        @Bind(R.id.retry)
        Button retry;

        public AddressMessageViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class ReminderMessageHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.remindMessage)
        TextView reminderText;

        public ReminderMessageHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    class RewardsMessageHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.rewardsLayout)
        ViewGroup rewardsLayout;
        @Bind(R.id.avatar)
        SimpleDraweeView avatar;
        @Bind(R.id.rewardsDesc)
        TextView rewardsDesc;
        @Bind(R.id.checkRewards)
        TextView checkRewards;
        @Nullable
        @Bind(R.id.status)
        TextView status;
        @Bind(R.id.rewardSource)
        TextView rewardSource;

        public RewardsMessageHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    private boolean isSendByMe(Message message) {
        return Helper.sharedHelper().getUserId()
                .equals(String.valueOf(message.getSenderId()));
    }

    class TimeLabelHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.msg_time_value)
        public TextView time;

        public TimeLabelHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
