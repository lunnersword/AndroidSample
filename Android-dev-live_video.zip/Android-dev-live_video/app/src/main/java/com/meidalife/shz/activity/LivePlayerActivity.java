package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LiveRecordDO;
import com.meidalife.shz.rest.model.LiveRewardRankDO;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestItem;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.util.TimeUtils;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.LiveHostInfoView;
import com.meidalife.shz.widget.LiveVideoRewardRankPopupWindow;
import com.meidalife.shz.widget.MessageDialog;
import com.meidalife.shz.widget.PopupListMenu;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujian on 16/2/21.
 * Modified by LanBo on 16/4/7.
 * 直播录像播放界面
 */
public class LivePlayerActivity extends BaseActivity implements View.OnClickListener, MediaPlayer.OnPreparedListener {
    private static final String TAG = "LivePlayerActivity";
    private static final int SEEK_BAR_MAX_VALUE = 100;

    @Bind(R.id.seek)
    SeekBar mSeekBar;
    @Bind(R.id.totalTime)
    TextView totalTime;
    @Bind(R.id.currentTime)
    TextView currentTime;
    @Bind(R.id.pauseLayout)
    View pauseLayout;
    @Bind(R.id.playVideoView)
    View playVideoView;
    @Bind(R.id.btn_close)
    View btnClose;
    @Bind(R.id.player)
    VideoView mPlayer;
    @Bind(R.id.btnPause)
    View btnPause;
    @Bind(R.id.btn_attention)
    View btnAttention;
    @Bind(R.id.btn_share)
    View btnShare;
    @Bind(R.id.btn_more)
    View btnMore;
    @Bind(R.id.host_info_layout)
    LiveHostInfoView hostInfoLayout;
    @Bind(R.id.reward_top_rank)
    LinearLayout rewardTopRank;


    private static final int REFRESH_SEEK_BAR_MESSAGE = 22;
    private int channelId;
    private LiveRecordDO liveRecordDO;
    private int videoDuration;

    private String mFileName;
    private List<String> mUrls = new ArrayList<>();
    private TimerTask refreshSeekBarTask;
    private Timer refreshSeekBarTimers;
    private int mVideoSize;
    private int currentSize;
    private LiveVideoRewardRankPopupWindow mRewardRankPopup;
    private boolean isPlayDone = false;
    private ServiceItem mServiceItem;


    final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case REFRESH_SEEK_BAR_MESSAGE:
                    if (videoDuration == 0)
                        return;
                    int currentPosition;
                    currentPosition = mPlayer.getCurrentPosition();
                    currentTime.setText(TimeUtils.secToTime(currentPosition / 1000));
                    mSeekBar.setProgress(((currentPosition * SEEK_BAR_MAX_VALUE) / videoDuration));
                    //播放结束时判断，结束前1.5秒就判断
                    currentPosition = mPlayer.getCurrentPosition();
                    if (videoDuration > 0 && currentPosition > videoDuration - 1500) {
                        mSeekBar.setProgress(0);
                        pauseVideo();
                        if (currentSize < mVideoSize - 1) {
                            videoDuration = 0;
                            mPlayer.stopPlayback();
                            mPlayer.setVideoURI(Uri.parse(mUrls.get(++currentSize)));
                            MessageUtils.showToast("即将为你播放第" + (currentSize + 1) + "段");
                        } else {
                            if (!isPlayDone)
                                MessageUtils.showToast("播放结束");
                            isPlayDone = true;
                            mPlayer.stopPlayback();
                            currentSize = 0;
                            mPlayer.setVideoURI(Uri.parse(mUrls.get(currentSize)));
                            playVideoView.setEnabled(false);
                        }

                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_player);

        ButterKnife.bind(this);


        refreshSeekBarTimers = new Timer();
        refreshSeekBarTask = new TimerTask() {
            @Override
            public void run() {

                Message message = handler.obtainMessage();
                message.what = REFRESH_SEEK_BAR_MESSAGE;
                handler.sendMessage(message);

            }
        };

        playVideoView.setEnabled(false);

        mSeekBar.setMax(SEEK_BAR_MAX_VALUE);
        mSeekBar.setEnabled(false);
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    mPlayer.pause();
                    int targetMTime = (videoDuration * progress / SEEK_BAR_MAX_VALUE);
                    mPlayer.seekTo(targetMTime);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

        });
        playVideoView.setOnClickListener(this);
        btnPause.setOnClickListener(this);
        btnClose.setOnClickListener(this);
        btnAttention.setOnClickListener(this);
        btnShare.setOnClickListener(this);
        btnMore.setOnClickListener(this);
        hostInfoLayout.setOnClickListener(this);
        rewardTopRank.setOnClickListener(this);


        channelId = getIntent().getIntExtra("channelId", Integer.MAX_VALUE);

        playRecordInit();
        refreshSeekBarTimers.schedule(refreshSeekBarTask, 0, 500);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mPlayer.stopPlayback();
        refreshSeekBarTimers.cancel();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.playVideoView:
                playVideo();
                break;
            case R.id.btnPause:
                pauseVideo();
                break;
            case R.id.btn_close:
                finish();
                break;
            case R.id.btn_attention:
                attentionLive();
                break;
            case R.id.btn_share:
                shareService(v);
                break;
            case R.id.btn_more:
                initMoreMenu(v);
                break;
            case R.id.reward_top_rank:
                if (mRewardRankPopup != null)
                    mRewardRankPopup.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM, 0, 0);
                break;
            case R.id.host_info_layout:
                showHostInfo();
                break;
        }
    }

    public void onPrepared(MediaPlayer mp) {
        videoDuration = mPlayer.getDuration();
        totalTime.setText(TimeUtils.secToTime(videoDuration / 1000));
        mSeekBar.setEnabled(true);
        playVideoView.setEnabled(true);
        if (!isPlayDone)
            playVideo();

        mp.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() {

            public void onBufferingUpdate(MediaPlayer mp, int percent) {
                //缓冲
                mSeekBar.setSecondaryProgress(percent);

            }
        });

        //拖动进度条时，待准备好了再播放
        mp.setOnSeekCompleteListener(new MediaPlayer.OnSeekCompleteListener() {
            @Override
            public void onSeekComplete(MediaPlayer mp) {
                mPlayer.start();
            }
        });
    }

    private void playRecordInit() {
        JSONObject params = new JSONObject();
        params.put("liveId", channelId);
        HttpClient.get("1.0/live/recordInit", params, LiveRecordDO.class, new HttpClient.HttpCallback<LiveRecordDO>() {
            @Override
            public void onSuccess(LiveRecordDO obj) {
                if (obj == null) {
                    MessageUtils.showToastCenter("视频不存在");
                    return;
                }
                liveRecordDO = obj;
                liveRecordDO.setCreateTime(liveRecordDO.getCreateTime() / 1000);
                fetchServiceData();
                initHostData();
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "播放失败，请稍后再试");
            }
        });
    }

    public void fetchServiceData() {
        String itemId = String.valueOf(liveRecordDO.getItem().getItemId());
        RequestItem.get(itemId, null, new HttpClient.HttpCallback<ServiceItem>() {
            @Override
            public void onSuccess(ServiceItem result) {
                mServiceItem = result;
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(TAG, error.toString());
            }
        });
    }

    private void fetchRewardRank() {
        JSONObject params = new JSONObject();
        params.put("topType", Constant.RANK_TYPE_ALL);
        params.put("role", Constant.RANK_TYPE_AUDIENCE);
        params.put("limit", 10);
        params.put("sourceId", channelId);
        params.put("sourceType", 5);

        HttpClient.get("1.0/rewards/top", params, LiveRewardRankDO.class, new HttpClient.HttpCallback<ArrayList<LiveRewardRankDO>>() {
            @Override
            public void onSuccess(ArrayList<LiveRewardRankDO> arrayList) {
                refreshRewardRankView(arrayList);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToast("获取打赏排行失败");
            }
        });
    }


    private void initHostData() {
        fetchRewardRank();
        mFileName = "";
        mUrls = new ArrayList<>();

        String avatarUrl = liveRecordDO.getHost().getUserAvatar();
        String gender = liveRecordDO.getHost().getGender();
        ViewGroup.LayoutParams avatarParams = hostInfoLayout.hostHeader.getLayoutParams();
        Uri uri;
        if (TextUtils.isEmpty(avatarUrl) || avatarUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(liveRecordDO.getHost().getUserId()), gender);
            hostInfoLayout.hostHeader.setImageURI(getDefaultAvatarUri);
        } else {
            uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, avatarParams.width));
            hostInfoLayout.hostHeader.setImageURI(uri);
        }

        if (gender.equals("woman") || gender.equals("F")) {
            hostInfoLayout.hostGender.setText(this.getResources().getString(R.string.icon_gender_f));
            hostInfoLayout.hostGender.setTextColor(this.getResources().getColor(R.color.brand_b));
        } else {
            hostInfoLayout.hostGender.setText(this.getResources().getString(R.string.icon_gender_m));
            hostInfoLayout.hostGender.setTextColor(this.getResources().getColor(R.color.brand_i));
        }

        hostInfoLayout.hostNick.setText(liveRecordDO.getHost().getUserName());
        hostInfoLayout.iCan.setText(liveRecordDO.getItem().getTitle());

        hostInfoLayout.setVisibility(View.VISIBLE);
        if (!liveRecordDO.getUserId().equals(liveRecordDO.getHost().getUserId())) {
            btnMore.setVisibility(View.VISIBLE);
            btnAttention.setVisibility(View.VISIBLE);
        } else {
            btnMore.setVisibility(View.GONE);
            btnAttention.setVisibility(View.GONE);
        }

        List<LiveRecordDO.PlayInfo> playList = liveRecordDO.getPlayInfo();
        List<LiveRecordDO.PlaySet> set;
        if (playList != null) {
            int size = playList.size();
            for (int i = 0; i < size; i++) {
                LiveRecordDO.PlayInfo info = playList.get(i);
                if (TextUtils.isEmpty(mFileName)) {
                    mFileName = info.getFileName();
                }
                set = info.getPlaySet();
                if (set != null) {
                    int setSize = set.size();
                    for (int j = 0; j < setSize; j++) {
                        mUrls.add(set.get(j).getUrl());
                    }
                }
            }
        }


        mVideoSize = mUrls.size();
        MessageUtils.showToast("当前录像总共" + mVideoSize + "段");

        currentSize = 0;
        if (mUrls != null && mVideoSize > 0) {
            mPlayer.setVideoURI(Uri.parse(mUrls.get(currentSize)));
            mPlayer.setOnPreparedListener(this);
        }
    }

    private void playVideo() {
        if (isPlayDone)
            isPlayDone = false;
        mPlayer.start();
        pauseLayout.setVisibility(View.GONE);
    }

    public void pauseVideo() {
        mPlayer.pause();
        pauseLayout.setVisibility(View.VISIBLE);
    }

    private void refreshRewardRankView(List<LiveRewardRankDO> rewards) {
        if (!(rewards.size() > 0)) {
            return;
        } else {
            rewardTopRank.setVisibility(View.VISIBLE);
        }
        rewardTopRank.removeAllViews();
        View rankItemView = getLayoutInflater().inflate(R.layout.item_live_video_rank_pic, null);
        rewardTopRank.addView(rankItemView);
        if (rewards == null || rewards.size() == 0) return;
        for (int i = 0; i < ((rewards.size() > 10) ? 10 : rewards.size()); i++) {
            LiveRewardRankDO reward = rewards.get(i);

            rankItemView = getLayoutInflater().inflate(R.layout.item_live_video_rank_avatar, null);
            SimpleDraweeView avatar = (SimpleDraweeView) rankItemView.findViewById(R.id.avatar);

            ViewGroup.LayoutParams avatarParams = avatar.getLayoutParams();
            if (TextUtils.isEmpty(reward.getUserAvatar()) || reward.getUserAvatar().equals("null")) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(reward.getUserId()), reward.getGender());
                avatar.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(reward.getUserAvatar(), avatarParams.width));
                avatar.setImageURI(uri);
            }
            rewardTopRank.addView(rankItemView);
        }

        if (mRewardRankPopup == null)
            mRewardRankPopup = new LiveVideoRewardRankPopupWindow(this);
        mRewardRankPopup.setRewardsData(rewards);

    }

    private void showHostInfo() {
        View customView = getLayoutInflater().inflate(R.layout.dialog_profile, null);
        View iconClose = customView.findViewById(R.id.iconClose);
        SimpleDraweeView imageAvatar = (SimpleDraweeView) customView.findViewById(R.id.imageAvatar);

        String avatarUrl = liveRecordDO.getHost().getUserAvatar();
        String gender = liveRecordDO.getHost().getGender();

        if (TextUtils.isEmpty(avatarUrl) || avatarUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(liveRecordDO.getHost().getUserId()), gender);
            imageAvatar.setImageURI(getDefaultAvatarUri);

        } else {
            ViewGroup.LayoutParams avatarParams = imageAvatar.getLayoutParams();
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, avatarParams.width));
            imageAvatar.setImageURI(uri);
        }

        TextView genderIcon = (TextView) customView.findViewById(R.id.genderIcon);
        TextView nickNameText = (TextView) customView.findViewById(R.id.nickNameText);
        TextView descriptionText = (TextView) customView.findViewById(R.id.descriptionText);
        if (gender.equals("woman") || gender.equals("F")) {
            genderIcon.setText(getResources().getString(R.string.icon_gender_f));
            genderIcon.setTextColor(getResources().getColor(R.color.brand_b));
        } else {
            genderIcon.setText(getResources().getString(R.string.icon_gender_m));
            genderIcon.setTextColor(getResources().getColor(R.color.brand_i));
        }
        nickNameText.setText(liveRecordDO.getHost().getUserName());
        descriptionText.setText(liveRecordDO.getHost().getInstruction());

        SimpleDraweeView servicePic = (SimpleDraweeView) customView.findViewById(R.id.servicePic);
        FontTextView serviceName = (FontTextView) customView.findViewById(R.id.serviceName);
        FontTextView servicePrice = (FontTextView) customView.findViewById(R.id.servicePrice);
        FontTextView orderCount = (FontTextView) customView.findViewById(R.id.orderCount);

        servicePic.setImageURI(Uri.parse(mServiceItem.getImages().get(0)));
        serviceName.setText(mServiceItem.getTag());
        servicePrice.setText(mServiceItem.getPrice());
        orderCount.setText(mServiceItem.getSellCount() + "人约单");

        // 评分
        View starsView = getLayoutInflater().inflate(R.layout.service_stars_normal, null);
        View contentView = starsView.findViewById(R.id.contentView);

        ViewGroup.LayoutParams params = contentView.getLayoutParams();
        params.height = (int) Helper.convertDpToPixel(15, this);
        contentView.setLayoutParams(params);
        ViewGroup starGroup = (ViewGroup) customView.findViewById(R.id.detail_judge_star_icon_group);

        View starsRed = starsView.findViewById(R.id.star_red_group);
        starsRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(75, this) * 4 / 5);
        starsRed.getLayoutParams().height = (int) Helper.convertDpToPixel(15, this);
        starGroup.removeAllViews();
        starGroup.addView(starsView);

        MessageDialog.Builder builder = new MessageDialog.Builder(this);
        builder.setCustomView(customView);
        builder.setPositiveButton("进入个人主页", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Router.sharedRouter().open("profile/" + liveRecordDO.getHost().getUserId());
            }
        });
        final MessageDialog dialog = builder.create();
        iconClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.getWindow().setBackgroundDrawable(new BitmapDrawable());
        dialog.show();
    }

    private final static int MENU_ITEM_REPORT = 0;
    private PopupListMenu mPopupListMenu;

    public void initMoreMenu(final View v) {
        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(this, R.layout.popup_window_share_menu, ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        List<MenuVO> menuList = new ArrayList<>();
        menuList.add(MENU_ITEM_REPORT, new MenuVO(R.string.icon_jubao, this.getResources().getString(R.string.report), 1));

        mPopupListMenu.setMenuData(menuList);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAsDropDown(v, -50, 0);
        }

        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_REPORT: {
                        reportService();
                        mPopupListMenu.dismiss();
                        break;
                    }
                }
            }
        });
    }

    private void reportService() {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", liveRecordDO.getItem().getItemId());
        intent.putExtra("target", Constant.REPORT_TYPE_SERVICE);
        this.startActivity(intent);
    }

    private SocialSharePopupWindow socialSharePopupWindow;

    private void shareService(View v) {
        if (mServiceItem != null) {
            LogParam param = new LogParam();
            param.setType(LogUtil.TYPE_CUSTOMIZE);
            param.setEid(LogUtil.EVENT_ID_SHARE_CLICK);
            param.setPvid(mServiceItem.getPvid());
            LogUtil.log(param);
        }

        Activity activity = this;
        if (socialSharePopupWindow == null) {
            socialSharePopupWindow = new SocialSharePopupWindow(activity, mServiceItem,
                    new ShareActivity(activity), SocialSharePopupWindow.SHARE_TYPE_SERVICE);
        }
        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private void attentionLive() {

        btnAttention.setEnabled(false);
        JSONObject params = new JSONObject();
        params.put("attentionUserId", liveRecordDO.getUserId());
        HttpClient.get("1.0 / attention / addUserAttention", params, null, new HttpClient.HttpCallback<ArrayList<Object>>() {
            @Override
            public void onSuccess(ArrayList<Object> arrayList) {
                MessageUtils.showToast("关注成功");
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToast("关注失败,请稍后再试");
                btnAttention.setEnabled(true);
            }
        });

    }

}


