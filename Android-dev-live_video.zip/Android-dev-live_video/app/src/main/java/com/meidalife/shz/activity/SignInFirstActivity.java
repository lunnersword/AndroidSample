package com.meidalife.shz.activity;

import android.content.Intent;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SignUserDo;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujian on 16/4/25.
 */
public class SignInFirstActivity extends BaseActivity {

    private static final int MAX_NUM_IMAGE_SHOW = 8;
    private static final int TOTAL_NUM_IMAGE = 50;
    private static final long IMAGE_SWITCH_TIME = 1500l;

    @Bind(R.id.myVideoView)
    VideoView myVideoView;
    @Bind(R.id.mRecyclerView)
    RecyclerView mRecyclerView;
    @Bind(R.id.userAvatar)
    SimpleDraweeView userAvatar;
    @Bind(R.id.bottom_layout)
    LinearLayout bottomLayout;
    @Bind(R.id.openView)
    TextView openView;
    @Bind(R.id.iconGender)
    TextView iconGender;
    @Bind(R.id.nickName)
    TextView nickName;
    @Bind(R.id.jobIcon)
    SimpleDraweeView jobIcon;
    @Bind(R.id.jobName)
    TextView jobName;
    @Bind(R.id.jobTitle)
    TextView jobTitle;
    @Bind(R.id.userInfoLayout)
    View userInfoLayout;

    private LinearLayoutManager linearLayoutManager;
    private MyRecycleAdapter myRecycleAdapter;
    private boolean move = false;
    private int mIndex = 0;
    private boolean hasMeasured = false;
    private Handler handler = new Handler();
    private int position = 0;
    private String playUri;

    private List<SignUserDo> signUserDos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_first);

        ButterKnife.bind(this);

        initListener();
        signUserDos = new ArrayList<SignUserDo>();
        //设置布局管理器
        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        myRecycleAdapter = new MyRecycleAdapter();
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setAdapter(myRecycleAdapter);
        mRecyclerView.addOnScrollListener(new RecyclerViewListener());
        playUri = "android.resource://" + getPackageName() + "/" + R.raw.sign_bg;
        initUsersData();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(!TextUtils.isEmpty(playUri)){
            myVideoView.setVideoURI(Uri.parse(playUri));
            myVideoView.start();
        }
        if(signUserDos.size() > 0){
            handler.postDelayed(imageSwitchRunnable, 0);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        handler.removeCallbacks(imageSwitchRunnable);
    }

    private void initListener(){
        ViewTreeObserver vto = bottomLayout.getViewTreeObserver();
        vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            public boolean onPreDraw() {
                if (hasMeasured)
                    return true;
                int height = bottomLayout.getMeasuredHeight();
                Rect frame = new Rect();
                getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
                int statusBarHeight = frame.top;
                int w = getResources().getDisplayMetrics().widthPixels;
                int h = getResources().getDisplayMetrics().heightPixels;
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) myVideoView.getLayoutParams();
                layoutParams.height = h - height - statusBarHeight;
                layoutParams.width = w;
                myVideoView.setLayoutParams(layoutParams);
                hasMeasured = true;
                return true;
            }
        });
        openView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().openFormResult("signin", Constant.REQUEST_CODE_SIGNIN, SignInFirstActivity.this);
                finish();
            }
        });
        myVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                myVideoView.start();
            }
        });
    }

    private void initUsersData() {
        HttpClient.get("2.0/home/users", null, SignUserDo.class, new HttpClient.HttpCallback<List<SignUserDo>>() {
            @Override
            public void onSuccess(List<SignUserDo> objs) {
                if (objs != null && objs.size() > 0) {
                    handlerUserView(objs.get(0));
                    userInfoLayout.setVisibility(View.VISIBLE);
                    signUserDos.clear();
                    signUserDos.addAll(objs);
                    if (objs.size() < TOTAL_NUM_IMAGE) {
                        int offSize = TOTAL_NUM_IMAGE - objs.size();
                        int a = offSize / objs.size();
                        int b = offSize % objs.size();
                        for (int i = 0; i < a; i++) {
                            signUserDos.addAll(objs);
                        }
                        signUserDos.addAll(objs.subList(0, b));
                    }
                    myRecycleAdapter.notifyDataSetChanged();
                    handler.postDelayed(imageSwitchRunnable, 0);
                }
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "加载失败，请稍后再试");
                userInfoLayout.setVisibility(View.INVISIBLE);
            }
        });
    }

    private void handlerUserView(SignUserDo item){
        userAvatar.setImageURI(Uri.parse(item.getAvatarUrl()));
        // 设置性别
        if (item.getUserGender() != null) {
            iconGender.setVisibility(View.VISIBLE);
            if (item.getUserGender().equals("woman") || item.getUserGender().equals("F")) {
                iconGender.setText(getResources().getString(R.string.icon_gender_f));
                iconGender.setBackgroundResource(R.drawable.bg_circle_profile_red);
            } else {
                iconGender.setText(getResources().getString(R.string.icon_gender_m));
                iconGender.setBackgroundResource(R.drawable.bg_circle_profile_brand_i);
            }
        } else {
            iconGender.setVisibility(View.GONE);
        }
        nickName.setText(item.getUserNick());
        if (item.getJobTitle() != null) {
            jobTitle.setVisibility(View.VISIBLE);
            jobTitle.setText(item.getJobTitle());
        } else
            jobTitle.setVisibility(View.GONE);
        if (item.getJobs() != null && item.getJobs().size() != 0) {
            jobName.setVisibility(View.VISIBLE);
            jobIcon.setVisibility(View.VISIBLE);
            jobName.setText(item.getJobs().get(0).getTitle());
            if (item.getJobs().get(0).getIconUrl() != null)
                jobIcon.setImageURI(Uri.parse(item.getJobs().get(0).getIconUrl()));
        } else {
            jobName.setVisibility(View.GONE);
            jobIcon.setVisibility(View.GONE);
        }
    }

    private void move(int n) {
        if (n < 0 || n >= myRecycleAdapter.getItemCount() - MAX_NUM_IMAGE_SHOW) {
            position = 0;
            n = position;
        }
        mIndex = n;
        mRecyclerView.stopScroll();

        smoothMoveToPosition(n);
    }

    private void smoothMoveToPosition(int n) {

        int firstItem = linearLayoutManager.findFirstVisibleItemPosition();
        int lastItem = linearLayoutManager.findLastVisibleItemPosition();
        if (n <= firstItem) {
            mRecyclerView.smoothScrollToPosition(n);
        } else if (n <= lastItem) {
            //int top = mRecyclerView.getChildAt(n - firstItem).getTop();
            int left = mRecyclerView.getChildAt(n - firstItem).getLeft();
            mRecyclerView.smoothScrollBy(left, 0);
        } else {
            mRecyclerView.smoothScrollToPosition(n);
            move = true;
        }

    }

    Runnable imageSwitchRunnable = new Runnable() {
        @Override
        public void run() {
            // handler自带方法实现定时器
           // userAvatar.setImageURI(Uri.parse(iamges[(position - 1) < 0 ? 0 : (position - 1)]));
            handlerUserView(signUserDos.get((position - 1) < 0 ? 0 : (position - 1)));
            move(position++);
            handler.postDelayed(this, IMAGE_SWITCH_TIME);
        }
    };


    class RecyclerViewListener extends RecyclerView.OnScrollListener {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            if (move && newState == RecyclerView.SCROLL_STATE_IDLE) {
                move = false;
                int n = mIndex - linearLayoutManager.findFirstVisibleItemPosition();
                if (0 <= n && n < mRecyclerView.getChildCount()) {
                    //int top = mRecyclerView.getChildAt(n).getTop();
                    int left = mRecyclerView.getChildAt(n).getLeft();
                    mRecyclerView.smoothScrollBy(left, 0);
                }

            }
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
//            if (move && false){
//                move = false;
//                int n = mIndex - linearLayoutManager.findFirstVisibleItemPosition();
//                if ( 0 <= n && n < mRecyclerView.getChildCount()){
//                    int top = mRecyclerView.getChildAt(n).getTop();
//                    mRecyclerView.scrollBy(0, top);
//                }
//            }
        }
    }

    private class MyRecycleAdapter extends RecyclerView.Adapter<MyRecycleAdapter.ViewHolder> {

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(SignInFirstActivity.this).inflate(R.layout.view_sign_image, parent, false);
            return new ViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            if (!TextUtils.isEmpty(signUserDos.get(position).getAvatarUrl()))
                holder.image.setImageURI(Uri.parse(signUserDos.get(position).getAvatarUrl()));
        }

        @Override
        public int getItemCount() {
            return signUserDos.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            private SimpleDraweeView image;

            public ViewHolder(View itemView) {
                super(itemView);
                image = (SimpleDraweeView) itemView.findViewById(R.id.image);
            }
        }
    }


}
