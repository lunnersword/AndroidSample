package com.meidalife.shz.activity;

import android.os.Bundle;

import com.amap.api.location.LocationManagerProxy;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.MarkerOptions;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;

/**
 * Created by fufeng on 15/12/27.
 * modify by zuozheng on 2016/03/06
 * 地图显示坐标
 */
public class ViewLocationActivity extends BaseActivity {
    public final static String LOCATION_LAT = "location_lat";
    public final static String LOCATION_LNG = "location_lng";
    private AMap aMap;
    private MapView mapView;
    private LocationManagerProxy mAMapLocationManager;
    private LatLng mLocationLatLng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_view_location);
        initActionBar("位置", true, false);

        // 如果传进来的是有地址的，就先定位到这里， 如果没有，那么定位到当前的位置
        Double lat = getIntent().getDoubleExtra(LOCATION_LAT, 0);
        Double lng = getIntent().getDoubleExtra(LOCATION_LNG, 0);
        if (0 != lat && 0 != lng) {
            mLocationLatLng = new LatLng(lat, lng);
        } else {
            mLocationLatLng = null;
        }

        initView(null);
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mapView != null) {
            try {
                mapView.onDestroy();
            } catch (Throwable e) {
            }
        }
        if (null != aMap) {
            aMap.clear();
            aMap = null;
        }
        if (null != mAMapLocationManager) {
            mAMapLocationManager.destroy();
            mAMapLocationManager = null;
        }
        mLocationLatLng = null;
    }

    /**
     * 方法必须重写
     */
    @Override
    public void onResume() {
        super.onResume();
        if (mapView != null)
            mapView.onResume();
    }

    /**
     * 方法必须重写
     */
    @Override
    public void onPause() {
        super.onPause();
        if (mapView != null)
            mapView.onPause();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mapView != null)
            mapView.onSaveInstanceState(outState);
    }


    private void initView(Bundle savedInstanceState) {
        mapView = (MapView) findViewById(R.id.map);

        try {
            mapView.onCreate(savedInstanceState);
        } catch (Throwable t) {
            MessageUtils.showToast("亲，内存不足，无法打开地图，请返回重试");
            finish();
            return;
        }

        if (!setUpMapIfNeeded()) {
            finish();
        }
    }

    private boolean setUpMapIfNeeded() {
        if (aMap == null) {
            aMap = mapView.getMap();
            if (aMap == null) {
                MessageUtils.showToast("地图初始化失败");
                return false;
            }
        }

        aMap.getUiSettings().setZoomControlsEnabled(false);// 设置系统默认缩放按钮可见
        //aMap.setOnCameraChangeListener(cameraChangeListener);
        mAMapLocationManager = LocationManagerProxy.getInstance(this);
        //aMap.setLocationSource(locationSource);
        aMap.setMyLocationEnabled(true);// 设置为true表示系统定位按钮显示并响应点击，false表示隐藏，默认是false
        aMap.getUiSettings().setMyLocationButtonEnabled(false);
        aMap.getUiSettings().setTiltGesturesEnabled(false);

        if (mLocationLatLng != null) {
            addMarker(mLocationLatLng, "");
        }

        return true;
    }

    /**
     * 往地图上添加marker
     * @param latLng
     */
    private void addMarker(LatLng latLng, String desc) {
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("[位置]");
        markerOptions.snippet(desc);
        markerOptions.anchor(0.5f, 1f);
        markerOptions.draggable(true);
        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_anchor));

        aMap.addMarker(markerOptions);
        aMap.moveCamera(CameraUpdateFactory.changeLatLng(latLng));
        aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
    }
}
