package com.meidalife.shz.activity;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.activity.fragment.SquareAddressFragment;
import com.meidalife.shz.adapter.FragmentTabAdapter;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.event.type.SquareAddressEventModel;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.SquareAddressCateOutDO;
import com.meidalife.shz.rest.model.SquareAddressOutDO;
import com.meidalife.shz.view.IconTextView;
import com.meidalife.shz.widget.SlidingTabLayout;
import com.usepropeller.routable.Router;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 申请格子 选择格子的地址
 * Created by zhq on 15/12/22.
 */

public class SelectSquareAddressActivity extends BaseMapActivity
        implements
        View.OnClickListener,
        AMap.OnCameraChangeListener, AMap.OnMarkerClickListener, ViewPager.OnPageChangeListener {

    private final static String TAG = "SquareAddressSelect";

    @Bind(R.id.location_position)
    IconTextView mImageArrow;
    @Bind(R.id.address_locating_icon)
    View mLocatingView;
    @Bind(R.id.locationAddressView)
    TextView locationAddress;
    @Bind(R.id.slidingTab)
    SlidingTabLayout slidingTab;
    @Bind(R.id.tabViewPager)
    ViewPager tabViewPager;
    @Bind(R.id.nextBtn)
    TextView nextBtn;

    private LatLng mLastPosition;
    private String mCityCode;
    private Double mCurLatitude;
    private Double mCurLongitude;

    private AMapLocationManager mLocationManager;
    private boolean needLocation = false;

    private SquareAddressOutDO currentPosition;
    private FragmentTabAdapter categoryPagerAdapter;
    String url;

    @Override
    public int getLayoutResource() {
        return R.layout.activity_select_square_location;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initActionBar("申请格子", true, false);

        ButterKnife.bind(this);

        Bundle intentExtras = getIntent().getExtras();
        url = intentExtras != null ? intentExtras.getString("url") : null;

        initView();
    }

    @Override
    public void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void onEventMainThread(SquareAddressEventModel event) {
        currentPosition = event.address;

        if (currentPosition != null) {
            if (currentPosition.isSelected()) {
                nextBtn.setEnabled(true);
                nextBtn.setBackgroundColor(getResources().getColor(R.color.brand));
                nextBtn.setTextColor(getResources().getColor(R.color.black_a));
            } else {
                nextBtn.setEnabled(false);
                nextBtn.setBackgroundColor(getResources().getColor(R.color.grey_j));
                nextBtn.setTextColor(getResources().getColor(R.color.white));
            }
        }
    }


    void initView() {
//        mButtonRight.setText("下一步");
//        mButtonRight.setVisibility(View.VISIBLE);
//        mButtonRight.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onAddressSelected();
//            }
//        });

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAddressSelected();
            }
        });

        mImageArrow.setTypeface(Helper.sharedHelper().getIconFont());
        mImageArrow.setOnClickListener(this);
        mLocatingView.setOnClickListener(this);

        slidingTab.setOnTabClickListener(new SlidingTabLayout.OnTabClickListener() {
            @Override
            public void onClick(View v, int position, int oldPosition) {
                if (position != oldPosition) {
                    EventBus.getDefault().post(new BaseEvent(MsgTypeEnum.TYPE_REFRESH));
                }

                LogParam param = new LogParam();
                param.setType(LogUtil.TYPE_CUSTOMIZE);
                param.setEid(LogUtil.EVENT_ID_HOME_TAB_CLICK);
                param.setPoid(String.valueOf(position + 1));
                LogUtil.log(param);
            }
        });

        categoryPagerAdapter = new FragmentTabAdapter(getSupportFragmentManager());
    }

    void initData() {
        currentPosition = new SquareAddressOutDO();
        mLocationManager = SHZApplication.getInstance().getLocationManager();

        LocationDO locationDO = mLocationManager.getLocation();
        if (locationDO != null) {
            mCurLongitude = locationDO.getLongitude();
            mCurLatitude = locationDO.getLatitude();

            mCityCode = locationDO.getCityCode();
        }

        Log.v(TAG, "longitude: " + mCurLongitude + ", latitude:" + mCurLatitude);

        if (mCurLongitude != 0 || mCurLatitude != 0) {
            setIntentLbsLocation(mCurLongitude, mCurLatitude);
        } else {
            getCurrentLbsLocation();
        }
    }


    void setIntentLbsLocation(double curLongitude, double curLatitude) {
        mCurLongitude = curLongitude;
        mCurLatitude = curLatitude;
    }

    void getCurrentLbsLocation() {
        mLocationManager.updateLocation(mLocationChangedListener);
    }

    /**
     * 定位监听
     */
    private AMapLocationManager.LocationChangedListener mLocationChangedListener = new AMapLocationManager.LocationChangedListener() {

        @Override
        public void onLocationUpdateFailed() {
            needLocation = false;
        }

        @Override
        public void onLocationChanged(LocationDO location) {
            mCurLongitude = location.getLongitude();
            mCurLatitude = location.getLatitude();

            locationAddress.setText(location.getAddress());

            if (needLocation) {
                needLocation = false;
                LatLng currentLln = new LatLng(mCurLatitude, mCurLongitude);
                aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
                aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
            }
        }
    };

    @Override
    protected void onSetUpAMap() {
        super.onSetUpAMap();
        initData();
        aMap.getUiSettings().setZoomControlsEnabled(false);
        aMap.setOnCameraChangeListener(this);
        addMark(mCurLongitude, mCurLatitude, "", "", true);
    }

    private void addMark(Double Longitude, Double Latitude, String descripe, String snippet, boolean isZoom) {

        try {
            LatLng llA = new LatLng(Latitude, Longitude);
            MarkerOptions markerOption = new MarkerOptions();
            markerOption.position(llA);
            markerOption.title(descripe);
            markerOption.snippet(snippet);
            markerOption.anchor(0.5f, 1f);
            markerOption.draggable(true);
            if ("".equals(snippet))
                markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
            else
                markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
            aMap.addMarker(markerOption);
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(llA));
            if (isZoom)
                aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
            aMap.setOnMarkerClickListener(this);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.address_locating_icon) {
            needLocation = true;
            getCurrentLbsLocation();

        } else if (v.getId() == R.id.location_position) {
//            processSelectLocation();
        }
    }

    @Override
    public void onCameraChange(CameraPosition cameraPosition) {
        Log.v(TAG, "onCameraChange: " + cameraPosition.toString());
        mImageArrow.setVisibility(View.VISIBLE);
    }

    /**
     * 对移动地图结束事件回调
     */
    @Override
    public void onCameraChangeFinish(CameraPosition cameraPosition) {
        Log.v(TAG, "onCameraChangeFinish:" + cameraPosition.toString());

        TranslateAnimation animation = getVerticalTranslateAnimation();
        mImageArrow.setAnimation(animation);
        animation.startNow();
        onLocationChanged(cameraPosition.target);
    }

    private void onLocationChanged(LatLng position) {
        if (mLastPosition != null
                && mLastPosition.equals(position)) {
            //Do not search same address again.
            return;
        }
        mLastPosition = position;

        mCurLongitude = position.longitude;
        mCurLatitude = position.latitude;

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("cityCode", mCityCode);
            jsonObject.put("longitude", String.valueOf(mCurLongitude));
            jsonObject.put("latitude", String.valueOf(mCurLatitude));
            HttpClient.get("1.0/gezi/apply/position", jsonObject, JSONObject.class, callback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    HttpClient.HttpCallback<JSONObject> callback = new HttpClient.HttpCallback<JSONObject>() {
        @Override
        public void onSuccess(JSONObject jsonObj) {

            List<SquareAddressCateOutDO> poiList = JSON.parseArray(jsonObj.getString("tabs"), SquareAddressCateOutDO.class);

            loadCategoryTabs(poiList);
        }

        @Override
        public void onFail(HttpError error) {
            MessageUtils.showToast("获取附近地址失败: " + error.getMessage());
        }
    };


    private void loadCategoryTabs(List<SquareAddressCateOutDO> poiList) {
        if (poiList == null || poiList.isEmpty()) {
            return;
        }

        categoryPagerAdapter.clear();
        for (SquareAddressCateOutDO cateDO : poiList) {
            categoryPagerAdapter.addFragment(SquareAddressFragment.newInstance(cateDO, mCityCode,
                    String.valueOf(mCurLongitude), String.valueOf(mCurLatitude)));
        }
        tabViewPager.setAdapter(categoryPagerAdapter);
        categoryPagerAdapter.notifyDataSetChanged();


        slidingTab.setCustomTabView(R.layout.item_category, R.id.categoryName);
        slidingTab.setSelectedIndicatorColors(getResources().getColor(R.color.brand));
        slidingTab.setViewPager(tabViewPager);
        slidingTab.setDividerColors(android.R.color.transparent);
    }

    private TranslateAnimation getVerticalTranslateAnimation() {
        TranslateAnimation animation = new TranslateAnimation(0, 0, 0, -20);
        animation.setInterpolator(new DecelerateInterpolator());
        animation.setDuration(200);//设置动画持续时间
        animation.setStartOffset(0);
        animation.setRepeatCount(1);//设置重复次数
        animation.setRepeatMode(Animation.REVERSE);//设置反方向执行
        return animation;
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        if (marker.getPosition().latitude >= 0 && marker.getPosition().longitude >= 0) {
            LatLng currentLln = new LatLng(marker.getPosition().latitude, marker.getPosition().longitude);
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
            aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (RESULT_OK == resultCode && requestCode == Constant.REQUEST_CODE_SQUARE_EXAM) {
            finish();
        }
    }

    private void onAddressSelected() {
        Bundle bundle = new Bundle();
        bundle.putString("url", url);
        bundle.putString("cityCode", mCityCode);
        bundle.putSerializable("squareAddress", currentPosition);
        Router.sharedRouter().openFormResult("web", bundle,
                Constant.REQUEST_CODE_SQUARE_EXAM, this);
    }



    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

}