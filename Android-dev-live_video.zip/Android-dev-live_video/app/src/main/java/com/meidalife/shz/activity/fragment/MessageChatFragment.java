package com.meidalife.shz.activity.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ConversationAdapter;
import com.meidalife.shz.event.ConversationEvent;
import com.meidalife.shz.event.type.NetworkConnectEventModel;
import com.meidalife.shz.event.type.NetworkConnectTypeEnum;
import com.meidalife.shz.im.Callback;
import com.meidalife.shz.im.Conversation;
import com.meidalife.shz.im.ConversationManager;
import com.meidalife.shz.im.ImClient;
import com.meidalife.shz.im.constants.ImConstants;
import com.meidalife.shz.util.LoadUtil;
import com.umeng.analytics.MobclickAgent;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

public class MessageChatFragment extends BaseFragment implements AbsListView.OnScrollListener {
    private static final String LOG_TAG = "MessageChatFragment";
    private boolean isLoading = false;
    private int previous;
    private int LIMIT_SIZE = 20;
    private int offset = 0;
    private List<Conversation> conversationList = new ArrayList<>();

    private Context context;

    private View rootLayout;
    @Bind(R.id.root_view)
    ViewGroup rootView;
    @Bind(R.id.content_root_view)
    View contentRoot;
    @Bind(R.id.message_list)
    ListView listView;
    @Bind(R.id.message_no_data)
    RelativeLayout cellEmptyData;
    @Bind(R.id.conversationSearch)
    EditText conversationSearch;
    @Bind(R.id.searchKeywordClear)
    TextView searchKeywordClear;

    private View listFooter;
    private LoadUtil loadUtilV2;
    private ConversationAdapter conversationAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        if (rootLayout == null) {
            context = inflater.getContext();
            rootLayout = inflater.inflate(R.layout.fragment_message_chat, container, false);
            ButterKnife.bind(this, rootLayout);
            loadUtilV2 = new LoadUtil(inflater);

            listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
            listView.addFooterView(listFooter);
            conversationAdapter = new ConversationAdapter(context, conversationList);
            listView.setAdapter(conversationAdapter);
            listFooter.setVisibility(View.GONE);
            //点击进入聊天
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (position >= conversationList.size()) {
                        return;
                    }

                    Conversation conversation = conversationList.get(position);
                    if (conversation.getRemoteId() == ImConstants.ATTENTION_REMOTE_ID) {
                        Router.sharedRouter().open("profileData/0");
                    } else {
                        String action = "chat/" + conversation.getRemoteId();
                        Bundle bundle = new Bundle();
                        bundle.putString("receiveAvatar", conversation.getRemoteAvatar());
                        bundle.putString("receiveName", conversation.getRemoteNick());
                        bundle.putSerializable("conversation", conversation);
                        Router.sharedRouter().open(action, bundle);
                    }

                    if (null != view.findViewById(R.id.badge_with_number)) {
                        view.findViewById(R.id.badge_with_number).setVisibility(View.GONE);
                    }
                }
            });

            //长按删除聊天
            listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                    View contextMenu = inflater.inflate(R.layout.message_delete_dialog, null);
                    final AlertDialog dialog = new AlertDialog.Builder(context).create();
                    dialog.setView(contextMenu, 0, 0, 0, 0);
                    dialog.show();
                    TextView deleteTv = (TextView) contextMenu.findViewById(R.id.singleContextMenu);
                    deleteTv.setText(R.string.delete_message);
                    deleteTv.setTag(position);
                    deleteTv.setOnClickListener(new DeleteMsgClickListener(dialog));
                    return true;
                }
            });

            //滚动加载更多
            listView.setOnScrollListener(this);

            conversationSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH
                            || (event != null && KeyEvent.KEYCODE_ENTER == event.getKeyCode() && KeyEvent.ACTION_DOWN == event.getAction())) {
                        if (!TextUtils.isEmpty(conversationSearch.getText().toString())) {
                            searchConversation(conversationSearch.getText().toString());
                        }
                        return true;
                    }
                    return false;
                }
            });
            conversationSearch.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    if (TextUtils.isEmpty(conversationSearch.getText().toString())) {
                        loadMsgData(true);
                    }
                }
            });
            searchKeywordClear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    conversationSearch.setText("");
                }
            });
        }

        ImClient.getImService(ConversationManager.class).syncConversations();
        loadMsgData(true);
        EventBus.getDefault().register(this);
        return rootLayout;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart(this.getClass().getName());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void onEventMainThread(ConversationEvent event) {
        if (!event.getConversationList().isEmpty()) {
            addOrReplaceConversationToList(event.getConversationList());
            sortAndNotifyDataSetChange();
        }
    }

    public void onEventMainThread(NetworkConnectTypeEnum eventType) {
        if (NetworkConnectTypeEnum.TYPE_CONNECTED.equals(eventType)) {
            loadMsgData(false);
        }
    }

    public void onEventMainThread(NetworkConnectEventModel model) {
        if (NetworkConnectTypeEnum.TYPE_CONNECTED.equals(model.type)) {
            loadMsgData(false);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd(this.getClass().getName());
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);

        try {
            ViewGroup parent = (ViewGroup) rootLayout.getParent();
            if (parent != null) {
                parent.removeView(rootLayout);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (isLoading) {
            return;         // 若已加载中，则忽略
        }
        boolean moveToBottom = false;
        if (previous < firstVisibleItem) {
            moveToBottom = true;
        }
        previous = firstVisibleItem;
        if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
            loadMsgData(false);
        }
    }

    public void loadMsgData(boolean reload) {
        if (isLoading) {
            return;
        }
        isLoading = true;

        if (reload) {
            loadUtilV2.loadPre(rootView, contentRoot);
            conversationList.clear();
            offset = 0;
        } else {
            listFooter.setVisibility(View.VISIBLE);
        }

        ImClient.getImService(ConversationManager.class)
                .getConversations(new com.meidalife.shz.im.Callback<List<com.meidalife.shz.im.Conversation>>() {
                    @Override
                    public void onSuccess(List<com.meidalife.shz.im.Conversation> conversations) {
                        isLoading = false;
                        loadUtilV2.loadSuccess(contentRoot);

                        addOrReplaceConversationToList(conversations);

                        if (conversationList.size() == 0) {
                            listView.setVisibility(View.GONE);
                            cellEmptyData.setVisibility(View.VISIBLE);
                        } else {
                            sortAndNotifyDataSetChange();
                        }
                        listFooter.setVisibility(View.GONE);
                        offset += conversations.size();
                    }

                    @Override
                    public void onException(long var1, String var2) {
                        Log.d(LOG_TAG, "Get conversation exception:" + var2);
                        isLoading = false;
                    }
                }, offset, LIMIT_SIZE, null);
    }

    /**
     * 去除重复会话列表
     *
     * @param conversations
     */
    private void addOrReplaceConversationToList(List<Conversation> conversations) {
        for (Conversation conversation : conversations) {
            //如果存在相同会话更新会话，不存在的话就加入
            if (conversationList.contains(conversation)) {
                for (int i = 0; i < conversationList.size(); i++) {
                    Conversation c = conversationList.get(i);
                    if (c.getConversationId().equals(conversation.getConversationId())) {
                        conversationList.set(i, conversation);
                    }
                }
            } else {
                conversationList.add(0, conversation);
            }
        }
    }

    private void searchConversation(String keyword) {
        if (isLoading) {
            return;
        }
        isLoading = true;
        loadUtilV2.loadPre(rootView, contentRoot);
        conversationList.clear();
        offset = 0;
        ImClient.getImService(ConversationManager.class)
                .getConversations(new com.meidalife.shz.im.Callback<List<com.meidalife.shz.im.Conversation>>() {
                    @Override
                    public void onSuccess(List<com.meidalife.shz.im.Conversation> conversations) {
                        isLoading = false;
                        loadUtilV2.loadSuccess(contentRoot);

                        conversationList.addAll(conversations);
                        if (conversationList.size() == 0) {
                            listView.setVisibility(View.GONE);
                            cellEmptyData.setVisibility(View.VISIBLE);
                        } else {
                            sortAndNotifyDataSetChange();
                            listView.setVisibility(View.VISIBLE);
                        }
                        listFooter.setVisibility(View.GONE);
                        offset += conversations.size();
                    }

                    @Override
                    public void onException(long var1, String var2) {
                        Log.d(LOG_TAG, "Get conversation exception:" + var2);
                        isLoading = false;
                    }
                }, 0, 0, keyword);
    }

    public class DeleteMsgClickListener implements View.OnClickListener {
        private Dialog dialog;

        public DeleteMsgClickListener(Dialog dialog) {
            this.dialog = dialog;
        }

        @Override
        public void onClick(View v) {
            final Integer position = (Integer) v.getTag();
            Conversation cd = (Conversation) conversationAdapter.getItem(position);

            ImClient.getImService(ConversationManager.class).removeConversation(new Callback<Conversation>() {
                @Override
                public void onSuccess(Conversation var1) {
                    conversationAdapter.remove(position);
                    sortAndNotifyDataSetChange();
                }

                @Override
                public void onException(long var1, String var2) {

                }
            }, cd.getConversationId());
            dialog.dismiss();
        }
    }

    private void sortAndNotifyDataSetChange() {
        List<Conversation> conversationsUnread = new ArrayList<>();
        List<Conversation> conversationsRead = new ArrayList<>();
        for (Conversation conversation : conversationList) {
            if (conversation.getUnreadMessageCount() > 0) {
                conversationsUnread.add(conversation);
            } else {
                conversationsRead.add(conversation);
            }
        }
        Collections.sort(conversationsUnread, new Comparator<Conversation>() {
            @Override
            public int compare(Conversation lhs, Conversation rhs) {
                return Long.valueOf(rhs.getTimestamp()).compareTo(lhs.getTimestamp());
            }
        });
        Collections.sort(conversationsRead, new Comparator<Conversation>() {
            @Override
            public int compare(Conversation lhs, Conversation rhs) {
                return Long.valueOf(rhs.getTimestamp()).compareTo(lhs.getTimestamp());
            }
        });
        conversationList.clear();
        conversationList.addAll(conversationsUnread);
        conversationList.addAll(conversationsRead);
        conversationAdapter.notifyDataSetChanged();
        listView.setVisibility(View.VISIBLE);
    }
}
