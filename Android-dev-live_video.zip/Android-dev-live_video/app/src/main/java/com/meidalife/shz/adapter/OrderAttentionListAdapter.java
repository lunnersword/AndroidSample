package com.meidalife.shz.adapter;

import android.content.Context;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.meidalife.shz.R;
import com.meidalife.shz.view.FontTextView;


/**
 * Created by xingchen on 2015/11/22.
 */
public class OrderAttentionListAdapter extends BaseAdapter {

    private JSONArray tips;
    private JSONArray warns;
    private LayoutInflater mInflater;
    private Context mContext;

    public OrderAttentionListAdapter(Context context, JSONArray tips, JSONArray warns) {
        this.warns = warns;
        this.tips = tips;
        this.mContext = context;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return warns.size() == 0 ? tips.size() : tips.size() + warns.size() + 1;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null || convertView.getTag() == null) {
            convertView = mInflater.inflate(R.layout.item_dialog_tip, parent, false);
            holder = new ViewHolder();
            holder.tip_no = (FontTextView) convertView.findViewById(R.id.tip_no);
            holder.tip_message = (FontTextView) convertView.findViewById(R.id.tip_message);
            holder.view = convertView.findViewById(R.id.view);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.tip_no.setVisibility(View.VISIBLE);
        holder.tip_message.setVisibility(View.VISIBLE);
        holder.view.setVisibility(View.GONE);
        try {
            if (position < tips.size()) {
                if (tips.size() == 1) {
                    holder.tip_no.setVisibility(View.GONE);
                } else {
                    holder.tip_no.setText(position + 1 + "");
                    holder.tip_no.setBackgroundResource(R.drawable.circle_dot);
                }
                holder.tip_message.setText(tips.get(position).toString());
                holder.tip_message.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                holder.tip_message.setTextColor(mContext.getResources().getColor(R.color.profile_common));
            } else if (position > tips.size()) {
                holder.tip_no.setText("!");
                holder.tip_no.setBackgroundResource(R.drawable.circle_dialog_warn);
                holder.tip_message.setText(warns.get((position - tips.size() - 1)).toString());
                holder.tip_message.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                holder.tip_message.setTextColor(mContext.getResources().getColor(R.color.grey_c));
            } else {
                holder.tip_no.setVisibility(View.GONE);
                holder.tip_message.setVisibility(View.GONE);
                holder.view.setVisibility(View.VISIBLE);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return convertView;
    }

    private class ViewHolder {
        private FontTextView tip_no;
        private FontTextView tip_message;
        private View view;
    }
}
