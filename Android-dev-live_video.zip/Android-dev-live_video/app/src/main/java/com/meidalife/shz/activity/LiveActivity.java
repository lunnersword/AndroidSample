package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.Editable;
import android.text.Spannable;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.BuildConfig;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.activity.fragment.ChatExpressionFragment;
import com.meidalife.shz.av.TencentConstants;
import com.meidalife.shz.av.control.QavsdkControl;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.manager.LiveManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LiveInitDO;
import com.meidalife.shz.rest.model.TencentImMsgDO;
import com.meidalife.shz.util.NetworkUtils;
import com.meidalife.shz.view.LiveTopLayerView;
import com.meidalife.shz.widget.ChatFacerLayout;
import com.tencent.TIMCallBack;
import com.tencent.TIMValueCallBack;
import com.tencent.av.TIMAvManager;
import com.tencent.av.sdk.AVAudioCtrl;
import com.tencent.av.sdk.AVConstants;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by liujian on 16/2/17.
 * Modified by LanBo on 16/4/5.
 */
public class LiveActivity extends BaseActivity implements ChatFacerLayout.ChatListener,
        LiveTopLayerView.OnEventListener, EnterLiveRoom.OnEnterRoomListener {
    private static final String TAG = "LiveActivity";
    private static final long TIMER_INTERVAL = 1000l;

    @Bind(R.id.rootView)
    View rootView;
    @Bind(R.id.viewpager)
    ViewPager mViewPager;

    @Bind(R.id.chatFacerLayout)
    ChatFacerLayout mChatFacerLayout;

    private List<View> mPageViews;
    LiveTopLayerView mLiveTopLayerView;

    private Context mContext;
    private QavsdkControl mController = null;

    private boolean mIsHost = false;
    private int mLiveId;
    private LiveInitDO mLiveInitDO;

    private boolean mExitRoomCompleted = false;
    private boolean mClosed = false;

    private EnterLiveRoom mEnterLiveRoom;

    private PowerManager.WakeLock mWakeLock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_live);

        mContext = this;
        ButterKnife.bind(this);
        EventBus.getDefault().register(this);

        mPageViews = new ArrayList<>();
        LayoutInflater inflater = getLayoutInflater();
        mLiveTopLayerView = (LiveTopLayerView) inflater.inflate(R.layout.live_top_layer_view, null);
        View view = new View(this);
        mPageViews.add(view);
        mPageViews.add(mLiveTopLayerView);
        //数据适配器
        PagerAdapter pagerAdapter = new PagerAdapter() {
            @Override
            public int getCount() {
                return mPageViews.size();
            }
            @Override
            public boolean isViewFromObject(View arg0, Object arg1) {
                return arg0==arg1;
            }
            public void destroyItem(View arg0, int arg1, Object arg2) {
                ((ViewPager) arg0).removeView(mPageViews.get(arg1));
            }
            public Object instantiateItem(View arg0, int arg1){
                ((ViewPager)arg0).addView(mPageViews.get(arg1));
                return mPageViews.get(arg1);
            }
        };
        mViewPager.setAdapter(pagerAdapter);
        mViewPager.setCurrentItem(1);

        mLiveId = getIntent().getIntExtra("liveId", Integer.MAX_VALUE);

        initListener();

        mController = LiveManager.getInstance().getQavsdkControl();

        mEnterLiveRoom = new EnterLiveRoom(this);
        mEnterLiveRoom.setEnterRoomListener(this);
        mEnterLiveRoom.onCreate();
        mEnterLiveRoom.enter(mLiveId);

        //this.mChatHelper = ChatHelper.getInstance(this);
        mChatFacerLayout.setupTabHost(getSupportFragmentManager());
        mChatFacerLayout.setChatListener(this);

        mHeartBeatManager = new HeartBeatManager(this);
        mLiveDurationManager = new LiveDurationManager(this);
        mRecordManager = new RecordManager(this);

        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        mWakeLock = powerManager.newWakeLock(PowerManager.FULL_WAKE_LOCK, "LiveLock");
    }

    boolean mEnterRoomFinished = false;

    @Override
    public void onEnterRoomFinished() {
        if (mEnterRoomFinished) {
            return;
        }
        mEnterRoomFinished = true;
        int netType = NetworkUtils.getNetWorkType(mContext);
        Log.e(TAG, "network type = " + netType);
        if (netType != AVConstants.NETTYPE_NONE) {
            mController.setNetType(NetworkUtils.getNetWorkType(mContext));
        }

        if (mController.getAVContext() != null) {
            mController.onCreate(SHZApplication.getInstance(), findViewById(android.R.id.content));
        } else {
            finish();
        }
        mController.setRequestCount(0);

        if (mController.hasAVContext()) {
            AVAudioCtrl avAudioCtrl = mController.getAVContext().getAudioCtrl();
            avAudioCtrl.enableMic(true);
        }

        if (mController.hasAVContext()) {
            mController.onResume();
        }

        mEnterLiveRoom.initIM();
        mLiveTopLayerView.setOnEventListener(this);

        if (mIsHost) {
            AVAudioCtrl avAudioCtrl = mController.getAVContext().getAudioCtrl();
            avAudioCtrl.enableMic(true);
        } else {
            mController.getAVContext().getAudioCtrl().enableMic(false);
        }

        if (!mIsHost) {
            // 发送进入房间的消息
            TencentImMsgDO msgDO = new TencentImMsgDO();
            LiveManager.getInstance().addSender(msgDO);
            LiveManager.getInstance().addContent(msgDO, null, null, null);
            msgDO.setType(LiveManager.TYPE_MSG_USER_IN);
            mEnterLiveRoom.sendText(msgDO.toJsonString());
            // 显示到本地列表
            mLiveTopLayerView.addNewMessage(msgDO);
        }
    }

    @Override
    public void onEnableCameraCompleted() {
        // 查看美颜功能
        if (mIsHost) {
            boolean isBeautyEnabled = mEnterLiveRoom.getIsBeautyEnabled();
            mLiveTopLayerView.enableBeauty(isBeautyEnabled);
        }
    }

    @Override
    public void onInitFinished() {
        mLiveInitDO = mEnterLiveRoom.getLiveInitDO();
        mIsHost = mLiveInitDO.isHost();
        mLiveTopLayerView.initView(this, mLiveInitDO);
    }

    @Override
    public void onRemoteVideoShow() {
        mLiveTopLayerView.statusChange(LiveManager.STATE_ENTER_LIVE);
    }

    /**
     * Override ChatFacerLayout.ChatListener.doSend()
     */
    @Override
    public void doSend(String msg) {
        // 判断用户是否登录
        if (TextUtils.isEmpty(Helper.sharedHelper().getUserId())) {
            Toast.makeText(LiveActivity.this, "未登录", Toast.LENGTH_SHORT).show();
        } else {
            TencentImMsgDO msgDO = new TencentImMsgDO();
            LiveManager.getInstance().addSender(msgDO);
            LiveManager.getInstance().addContent(msgDO, msg, null, null);
            msgDO.setType(LiveManager.TYPE_MSG_TXT);
            mEnterLiveRoom.sendText(msgDO.toJsonString());
            // 显示到本地列表
            mLiveTopLayerView.addNewMessage(msgDO);
        }

        onTouchOutOfEditText();
    }


    @Override
    public void onNewMessage(TencentImMsgDO msgDO) {
        // 新消息处理
        switch (msgDO.getType()) {
            case LiveManager.TYPE_MSG_TXT:
                mLiveTopLayerView.addNewMessage(msgDO);
                break;
            case LiveManager.TYPE_MSG_USER_IN:
                mLiveTopLayerView.addNewMessage(msgDO);
                break;
            case LiveManager.TYPE_MSG_REWARD: // 赏消息
                mLiveTopLayerView.addNewMessage(msgDO);
                try {
                    float amount = Float.parseFloat(msgDO.getContent().getAmount());
                    amount = amount * 100 + 0.5f;
                    LiveManager.getInstance().addRewardMoney((int) amount);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
                break;
            case LiveManager.TYPE_MSG_PRAISE: // 点赞消息
                mLiveTopLayerView.updatePraise(msgDO);
                break;
            case LiveManager.TYPE_REWARD_RANK: // 更新打赏排行榜
                mLiveTopLayerView.updateRewardRank(msgDO);
                break;
            case LiveManager.TYPE_CLOSE_HOST:
                // 主播被迫结束直播
                mLiveTopLayerView.recvLiveEndAbort(msgDO.getContent().getReason());
                break;
            case LiveManager.TYPE_HOST_EXIT:
                // 主播主动结束
                mLiveTopLayerView.recvLiveEndNormal(msgDO.getContent().getReason());
                break;

        }
    }

    public void onEventMainThread(ChatExpressionFragment.ChatExpressionEvent event) {
        EditText inputEdit = mChatFacerLayout.getInputEdit();
        Editable edit = inputEdit.getEditableText();//获取EditText的文字
        int index = inputEdit.getSelectionStart();
        if (index < 0 || index >= edit.length()) {
            edit.append(event.expressionName);
        } else {
            edit.insert(index, event.expressionName);//光标所在位置插入文字
        }
        ImageSpan expressionPan = ChatHelper.getInstance().getImageSpan(event.expressionName, 20);
        if (null != expressionPan) {
            edit.setSpan(expressionPan, index, index + event.expressionName.length(),
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    private void initListener() {
    }

    @Override
    public void onResume() {
        super.onResume();
        mWakeLock.acquire();
        if (mController.hasAVContext()) {
            mController.onResume();
        }
        mEnterLiveRoom.onResume();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // 开启mic
        if (mIsHost && mController.hasAVContext()) {
            AVAudioCtrl avAudioCtrl = mController.getAVContext().getAudioCtrl();
            avAudioCtrl.enableMic(true);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        mWakeLock.release();
        if (mController.hasAVContext()) {
            mController.onPause();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        // TODO 关闭摄像头
        /*if (mController.getIsEnableCamera() == true) {
            mController.toggleEnableCamera();
        }*/
        // 关闭mic
        if (mIsHost && mController.hasAVContext()) {
            AVAudioCtrl avAudioCtrl = mController.getAVContext().getAudioCtrl();
            avAudioCtrl.enableMic(false);
        }
    }

    @Override
    public void onBackPressed() {
        if (mChatShown) {
            mChatShown = false;
            mChatFacerLayout.show(false);
            mLiveTopLayerView.showChat(true);
            return;
        }
        if (mLiveInitDO != null) {
            mLiveTopLayerView.performBackPressed();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
        if (mController.hasAVContext()) {
            mController.onDestroy();
        }
        mEnterLiveRoom.onDestroy();

        mHeartBeatManager.end();
        mLiveDurationManager.end();
        mHandler.removeCallbacksAndMessages(null);
        mHandler = null;
        //MessageUtils.switchWaitingDialog(this, mDialogAtDestroy, DIALOG_DESTROY, false);
    }

    @Override
    public boolean isInterceptTouchEvent() {
        return true;
    }

    @Override
    public void onStartExitRoom() {
        mRecordManager.stop();
    }

    @Override
    public void onExitRoomCompleted() {
        mExitRoomCompleted = true;
        if (mIsHost && mController.hasAVContext()) {
            AVAudioCtrl avAudioCtrl = mController.getAVContext().getAudioCtrl();
            avAudioCtrl.enableMic(true);
        }
        if (mIsHost && mController.hasAVContext()) {
            if (mController.getIsEnableCamera() == true) {
                mController.toggleEnableCamera();
            }
        }
        tryClose();
    }

    @Override
    public void onCloseLive() {
        mLiveDurationManager.end();
        mHeartBeatManager.end();
        mClosed = true;
        tryClose();
    }

    @Override
    public void onSetGoEndPage() {
        mGotoEndPage = true;
    }

    @Override
    public void onSetGoLiveHome() {
        mGotoLiveHome = true;
    }

    boolean mGotoEndPage = false;
    boolean mGotoLiveHome = false;

    private void tryClose() {
        if (mExitRoomCompleted && mClosed) {
            LiveManager.getInstance().setExitRoomTimeStamp(System.currentTimeMillis() / 1000);
            Log.i(TAG, "tryClose finish()");
            if (mIsHost) {
                startActivity(new Intent(mContext, LiveVideoFinishActivity.class)
                        .putExtra(TencentConstants.EXTRA_ROOM_NUM, mLiveId)
                        .putExtra(TencentConstants.EXTRA_LEAVE_MODE, false));
            } else {
                if (mGotoEndPage) {
                    startActivity(new Intent(mContext, LiveVideoFinishActivity.class)
                            .putExtra(TencentConstants.EXTRA_ROOM_NUM, mLiveId)
                            .putExtra(TencentConstants.EXTRA_LEAVE_MODE, false));
                } else if (mGotoLiveHome) {
                    Intent intent = new Intent(mContext, LiveVideoListActivity.class);
                    startActivity(intent);
                }
            }
            finish();
        }
        /*if (mIsHost) {
            setResult(TencentConstants.SHOW_RESULT_CODE);
            // MessageUtils.switchWaitingDialog(mContext, mDialogAtDestroy, DIALOG_DESTROY, true);
            // TODO 打开直播结束界面
            //startActivity(new Intent(mContext, LiveVideoFinishActivity.class)
                    *//*.putExtra(Util.EXTRA_ROOM_NUM, roomNum)
                    .putExtra(Util.EXTRA_LEAVE_MODE,false)*//*
           //         );
        } else {
            setResult(TencentConstants.VIEW_RESULT_CODE);
        }*/
    }

    @Override
    public void onStartLive() {
        mLiveDurationManager.start();
        mHeartBeatManager.start();
        if (mIsHost) {
            mRecordManager.start();
        }
    }

    @Override
    public boolean isShouldHideInput(View v, MotionEvent event) {
        if (!mChatShown) return false;
        v = mChatFacerLayout;
        if (v != null) {
            int[] leftTop = {0, 0};
            //获取输入框当前的location位置
            v.getLocationInWindow(leftTop);
            int left = leftTop[0];
            int top = leftTop[1];
            int bottom = top + v.getHeight();
            int right = left + v.getWidth();
            if (event.getRawX() > left && event.getRawX() < right
                    && event.getRawY() > top && event.getRawY() < bottom) {
                // 点击的是输入区域，保留点击事件
                if (BuildConfig.DEBUG) {
                    Log.i(TAG, "点击的是输入区域，保留点击事件");
                }
                return false;
            } else {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onTouchOutOfEditText() {
        super.onTouchOutOfEditText();
        if (mChatShown) {
            mChatShown = false;
            mChatFacerLayout.show(false);
            mLiveTopLayerView.showChat(true);
        }
    }

    boolean mChatShown = false;

    @Override
    public void onClickChat() {
        if (!mChatShown) {
            mChatShown = true;
            mLiveTopLayerView.showChat(false);
            mChatFacerLayout.show(true);
        }
    }

    @Override
    public void onClickPraise() {
        TencentImMsgDO msgDO = new TencentImMsgDO();
        LiveManager.getInstance().addSender(msgDO);
        LiveManager.getInstance().addContent(msgDO, null, null, null);
        msgDO.setType(LiveManager.TYPE_MSG_PRAISE);
        mEnterLiveRoom.sendText(msgDO.toJsonString());
        mLiveTopLayerView.updatePraise(msgDO);
    }

    @Override
    public void onReward(long amount, String desc) {
        TencentImMsgDO msgDO = new TencentImMsgDO();
        LiveManager.getInstance().addSender(msgDO);
        LiveManager.getInstance().addContent(msgDO, null, String.format("%.2f", amount / 100.0f), desc);
        msgDO.setType(LiveManager.TYPE_MSG_REWARD);
        mEnterLiveRoom.sendText(msgDO.toJsonString());
        mLiveTopLayerView.addNewMessage(msgDO);
    }

    private static final int MSG_UPDATE_TIME = 100;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MSG_UPDATE_TIME:
                    if (LiveManager.getInstance().getStartRoomTimeStamp() != 0) {
                        long duration = System.currentTimeMillis() / 1000 - LiveManager.getInstance().getStartRoomTimeStamp();
                        mLiveTopLayerView.updateLiveTime(duration);
                    }
                    break;
            }
        }
    };

    /*******************************************************
     * 时间管理
     *******************************************************/
    private LiveDurationManager mLiveDurationManager;
    private class LiveDurationManager {
        private final WeakReference<LiveActivity> mActivity;
        private Timer mTimer = new Timer(true);
        private boolean mStarted = false;
        private TimerTask mTimerTask = new TimerTask() {
            @Override
            public void run() {
                updateTime();
            }
        };

        LiveDurationManager(LiveActivity activity) {
            mActivity = new WeakReference<LiveActivity>(activity);
        }

        private void start() {
            if (!mStarted) {
                mStarted = true;
                mTimer.schedule(mTimerTask, TIMER_INTERVAL, TIMER_INTERVAL);
            }
        }

        private void end() {
            if (mStarted) {
                mTimer.cancel();
                mStarted = false;
            }
        }

        private void updateTime() {
            if (mStarted) {
                mActivity.get().mHandler.sendEmptyMessage(MSG_UPDATE_TIME);
            } else {
                // TODO 隐藏时间
            }
        }
    }

    /*******************************************************
     * 心跳管理
     *******************************************************/
    private HeartBeatManager mHeartBeatManager;

    private static class HeartBeatManager {
        private final WeakReference<LiveActivity> mActivity;
        private int totalVisitCount;
        private int currentVisitCount;
        private long startTime = 0;
        private boolean mStarted = false;
        private Timer mTimer = new Timer(true);
        private TimerTask mTimerTask = new TimerTask() {
            @Override
            public void run() {
                heartBeat();
            }
        };

        HeartBeatManager(LiveActivity activity) {
            mActivity = new WeakReference<LiveActivity>(activity);
        }

        private void start() {
            if (!mStarted) {
                mStarted = true;
                mTimer.schedule(mTimerTask, 0, mActivity.get().mLiveInitDO.getLiveConfig().getHeartBeatInterval());
            }
        }

        private void end() {
            if (mStarted) {
                mTimer.cancel();
                mStarted = false;
            }
        }

        private void heartBeat() {
            JSONObject params = new JSONObject();
            params.put("liveId", mActivity.get().mLiveId);
            params.put("userId", mActivity.get().mLiveInitDO.getUserId());
            params.put("anonymous", mActivity.get().mLiveInitDO.isAnonymous());
            HttpClient.get("1.0/live/heartbeat/get", params, null, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject obj) {
                    handleHeartBeat(obj);
                }

                @Override
                public void onFail(HttpError error) {
                    // 服务器可能异常了, 结束直播.
                    mActivity.get().hideProgressDialog();
                    mActivity.get().mLiveTopLayerView.serverAbnormal();
                }
            });
        }

        private void handleHeartBeat(JSONObject obj) {
            totalVisitCount = obj.getIntValue("visitCount");
            currentVisitCount = obj.getIntValue("visitorCount");
            if (startTime == 0) {
                startTime = obj.getLongValue("startTime");
                // 该时间与本地时间会产生误差, 服务端返回成功之后就本地记录时间比较准确
                if (LiveManager.getInstance().getStartRoomTimeStamp() == 0) {
                    LiveManager.getInstance().setStartToomTimeStamp(startTime / 1000);
                }
                mActivity.get().mHandler.sendEmptyMessage(MSG_UPDATE_TIME);
            }
            LiveManager.getInstance().setVisitCount(totalVisitCount, currentVisitCount);

            switch (obj.getIntValue("status")) {
                case LiveManager.HEART_BEAT_STATE_HOST_LIVING:
                    // 主播在线, 更新观众数量
                    mActivity.get().hideProgressDialog();
                    mActivity.get().mLiveTopLayerView.updateLiveWatcher(totalVisitCount, currentVisitCount);
                    break;
                case LiveManager.HEART_BEAT_STATE_HOST_FINISH:
                    // 主播结束直播
                    mActivity.get().hideProgressDialog();
                    mActivity.get().mLiveTopLayerView.recvLiveEndNormal(null);
                    break;
                case LiveManager.HEART_BEAT_STATE_HOST_LEAVE:
                    // 主播离开
                    if (!mActivity.get().mIsHost) {
                        mActivity.get().showProgressDialog("主播被外星人抓走了,一会就回来");
                    }
                    break;
            }
        }

    }

    /*******************************************************
     * 录像管理
     *******************************************************/
    private RecordManager mRecordManager;
    private static class RecordManager {
        private final WeakReference<LiveActivity> mActivity;
        private TIMAvManager.RecordParam mRecordParam;
        private boolean mRecording = false;

        RecordManager(LiveActivity activity) {
            mActivity = new WeakReference<LiveActivity>(activity);
        }

        private void start() {
            if (!mRecording) {
                startDefaultRecord();
            }
        }

        private void stop() {
            if (mRecording) {
                stopRecord();
            }
        }

        private void stopRecord() {
            int chatRoomId = LiveManager.getInstance().getLiveInitDO().getChatRoomId();
            int liveRoomId = LiveManager.getInstance().getLiveInitDO().getLiveRoomId();

            TIMAvManager.RoomInfo roomInfo = TIMAvManager.getInstance().new RoomInfo();
            roomInfo.setRelationId(chatRoomId);
            roomInfo.setRoomId(liveRoomId);
            TIMAvManager.getInstance().requestMultiVideoRecorderStop(roomInfo, new TIMValueCallBack<List<String>>() {
                @Override
                public void onError(int i, String s) {
                    Log.e(TAG, "stop record error " + i + " : " + s);
                }

                @Override
                public void onSuccess(List<String> files) {
                    mRecording = false;
                    for (String file : files) {
                        Log.d(TAG, "stopRecord onSuccess file  " + file);
                    }
                }
            });
        }

        private void startDefaultRecord() {
            Log.d(TAG, "setDefaultRecordParam roomName");
            mRecordParam = TIMAvManager.getInstance().new RecordParam();

            mRecordParam.setFilename(""+mActivity.get().mLiveId);
            mRecordParam.setClassId(0);
            mRecordParam.setTransCode(true);//是否云转码,服务器可能会比较慢,但会有高清,普清两种视频.
            mRecordParam.setSreenShot(true);//是否截屏
            mRecordParam.setWaterMark(false);//是否添加水印
            mHandler.sendEmptyMessage(START_RECORD);
        }

        public void startRecord() {
            int liveRoomId = LiveManager.getInstance().getLiveInitDO().getLiveRoomId();

            TIMAvManager.RoomInfo roomInfo = TIMAvManager.getInstance().new RoomInfo();
            roomInfo.setRelationId(LiveManager.getInstance().getLiveInitDO().getChatRoomId());
            roomInfo.setRoomId(liveRoomId);

            TIMAvManager.getInstance().requestMultiVideoRecorderStart(roomInfo, mRecordParam, new TIMCallBack() {
                @Override
                public void onError(int i, String s) {
                    Log.e(TAG, "Record error" + i + " : " + s);
                    //Toast.makeText(getApplicationContext(), "start record error,try again", Toast.LENGTH_LONG).show();
                }

                @Override
                public void onSuccess() {
                    mRecording = true;
                    Log.i(TAG, "begin to record");
                    //Toast.makeText(getApplicationContext(), "start record now ", Toast.LENGTH_SHORT).show();
                }
            });
            mRecordParam = null;
        }

        private static final int START_RECORD = 0x101;
        private Handler mHandler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(android.os.Message msg) {
                switch (msg.what) {
                    case START_RECORD:
                        startRecord();
                        break;
                }
                return false;
            }
        });
    }
}
