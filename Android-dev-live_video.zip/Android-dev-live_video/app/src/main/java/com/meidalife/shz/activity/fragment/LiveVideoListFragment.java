package com.meidalife.shz.activity.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.LiveActivity;
import com.meidalife.shz.activity.LivePlayerActivity;
import com.meidalife.shz.adapter.LiveVideoListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LiveRewardRankDO;
import com.meidalife.shz.rest.model.LiveVideoListDO;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.RankListHeadLayout;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by LanBo on 16/03/28.
 */
public class LiveVideoListFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private static final int RANK_LIMIT = 3;

    private boolean mLoading = false;
    private boolean mCompleted = false;
    private int page = 0;
    private int PAGE_SIZE = 20;
    private List<LiveVideoListDO.VideoDO> mLiveList = new ArrayList<>();
    private View rootView;

    private LiveVideoListAdapter mLiveListAdapter;
    private LoadUtil mLoadUtil;
    private IStateChangeListener mStateChangeListener;

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    ListView mLiveListView;

    @Bind(R.id.audience_rank)
    RankListHeadLayout audienceRankLayout;
    @Bind(R.id.host_rank)
    RankListHeadLayout hostRankLayout;

    // header部分,需在ListView.addHeaderView之后Bind
    @Bind(R.id.rankContent1)
    View rankContent1;
    @Bind(R.id.titleRankTag1)
    View titleRankTag1;
    @Bind(R.id.rankContent2)
    View rankContent2;
    @Bind(R.id.titleRankTag2)
    View titleRankTag2;
    @Bind(R.id.rankContent3)
    View rankContent3;
    @Bind(R.id.titleRankTag3)
    View titleRankTag3;

    private int mLiveTabType = Constant.LIVE_TYPE_NEW;

    public void setType(int type) {
        mCompleted = false;
        mLiveTabType = type;
        if (mStateChangeListener != null) {
            mStateChangeListener.onTabChanged(type);
        }
        renderTab(type);
        loadData(true);
    }

    public int getTabType() {
        return mLiveTabType;
    }

    public void setStateChangeListener(IStateChangeListener l) {
        mStateChangeListener = l;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_live_list, container, false);
            mLiveListView = (ListView) rootView.findViewById(R.id.liveList);
            mLiveListView.setHeaderDividersEnabled(false);
            mLiveListView.addHeaderView(inflater.inflate(R.layout.fragment_live_video_list_head, null, false));
            ButterKnife.bind(this, rootView);
            initHeadView();

            mLoadUtil = new LoadUtil(inflater);

            bindListener();
            mSwipeRefreshLayout.setOnRefreshListener(this);

            mLiveListAdapter = new LiveVideoListAdapter(getActivity(), mLiveList);
            mLiveListView.setAdapter(mLiveListAdapter);

            loadData(true);
        }
        return rootView;
    }

    private void initHeadView() {
        audienceRankLayout.topContainer.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("ranklist/" + Constant.RANK_TYPE_AUDIENCE);
            }
        });

        hostRankLayout.topContainer.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("ranklist/" + Constant.RANK_TYPE_HOST);
            }
        });

        audienceRankLayout.titleTextView.setText("土豪榜");
        hostRankLayout.titleTextView.setText("魅力榜");
    }

    private void bindListener() {
        rankContent1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                setType(Constant.LIVE_TYPE_NEW);
            }
        });
        rankContent2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                setType(Constant.LIVE_TYPE_HOT);
            }
        });
        rankContent3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                setType(Constant.LIVE_TYPE_MY);
            }
        });
        mLiveListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) return;
                LiveVideoListDO.VideoDO videoDO = mLiveList.get(position - 1);
                boolean isLive = videoDO.isLive();
                if (isLive) {
                    int channelId = videoDO.getChannelId();
                    Intent intent = new Intent(getActivity(), LiveActivity.class);
                    intent.putExtra("liveId", channelId);
                    startActivity(intent);
                } else {
                    int channelId = videoDO.getChannelId();
                    Intent intent = new Intent(getActivity(), LivePlayerActivity.class);
                    intent.putExtra("channelId", channelId);
                    startActivity(intent);
                }
            }
        });
        mLiveListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == SCROLL_STATE_IDLE && mLiveListView.getFirstVisiblePosition() == 0
                        && mLiveListView.getChildAt(0).getTop() == 0) {
                    mSwipeRefreshLayout.setEnabled(true);
                } else {
                    mSwipeRefreshLayout.setEnabled(false);
                }

                if (mLiveListView.getFirstVisiblePosition() > 0) {
                    if (mStateChangeListener != null) mStateChangeListener.onScrollToTop(true);
                } else {
                    if (mStateChangeListener != null) mStateChangeListener.onScrollToTop(false);
                }

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1 && !mCompleted) {
                        page++;
                        loadData(false);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
                if (mLiveListView.getFirstVisiblePosition() > 0) {
                    if (mStateChangeListener != null) mStateChangeListener.onScrollToTop(true);
                } else {
                    if (mStateChangeListener != null) mStateChangeListener.onScrollToTop(false);
                }
//                // 加if防止刚刷新数据后不能切换类别hot new
//                if (firstVisibleItem > 0) {
//                    //typeNew.setEnabled(false);
//                    //typeHot.setEnabled(false);
//                }
            }
        });
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onResume() {
        //if (mStateChangeListener != null) mStateChangeListener.onScrollToTop(true);
        loadData(true);
        super.onResume();
    }

    @Override
    public void onDestroyView() {
        try {
            try {
                ViewGroup parent = (ViewGroup) rootView.getParent();
                if (parent != null) {
                    parent.removeView(rootView);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    public void loadData(final boolean reload) {
        Log.i("TAG", "loadData "+reload);
        if (mLoading) {
            return;
        }
        mLoading = true;
        int type = mLiveTabType;
        if (reload) {
            page = 0;
            mLoadUtil.loadPre((ViewGroup) rootView, mSwipeRefreshLayout);
        }
        // 请求网络数据, 并处理成功和失败结果
        JSONObject params = new JSONObject();
        params.put("type", type);
        params.put("offset", page * PAGE_SIZE);
        params.put("pageSize", PAGE_SIZE);

        HttpClient.get("1.0/live/list", params, LiveVideoListDO.class, new HttpClient.HttpCallback<LiveVideoListDO>() {
            @Override
            public void onSuccess(LiveVideoListDO obj) {
                mLoadUtil.loadSuccess(mSwipeRefreshLayout);
                if (reload) {
                    mLiveList.clear();
                }
                mLiveList.addAll(obj.getVideos());
                mLiveListAdapter.notifyDataSetChanged();
                if (!obj.isHasNextPage()) {
                    mCompleted = true;
                } else {
                    mCompleted = false;
                }
                mLoading = false;
                mSwipeRefreshLayout.setRefreshing(false);
                mLiveListView.setEnabled(true);
            }

            @Override
            public void onFail(HttpError error) {
                mSwipeRefreshLayout.setRefreshing(false);
                mLoading = false;
                mLiveListView.setEnabled(true);
                mLoadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        if (page > 0) page--;
                        loadData(true);
                    }
                });
            }
        });
        fetchRankData();
    }

    private void fetchRankData() {

        JSONObject params = new JSONObject();
        params.put("topType", Constant.RANK_TYPE_ALL);
        params.put("role", Constant.RANK_TYPE_AUDIENCE);
        params.put("limit", RANK_LIMIT);

        //土豪榜
        HttpClient.get("1.0/rewards/top", params, LiveRewardRankDO.class, new HttpClient.HttpCallback<ArrayList<LiveRewardRankDO>>() {
            @Override
            public void onSuccess(ArrayList<LiveRewardRankDO> arrayList) {
                initAudienceRankView(arrayList);
            }

            @Override
            public void onFail(HttpError error) {
            }
        });

        //魅力榜
        params.put("role", Constant.RANK_TYPE_HOST);
        HttpClient.get("1.0/rewards/top", params, LiveRewardRankDO.class, new HttpClient.HttpCallback<ArrayList<LiveRewardRankDO>>() {
            @Override
            public void onSuccess(ArrayList<LiveRewardRankDO> arrayList) {
                initHostRankView(arrayList);
            }

            @Override
            public void onFail(HttpError error) {
            }
        });
    }

    public void initAudienceRankView(final ArrayList<LiveRewardRankDO> arrayList) {

        audienceRankLayout.rankHeadView1.flagImageView.setImageResource(R.drawable.tag_live_rank_1);
        audienceRankLayout.rankHeadView2.flagImageView.setImageResource(R.drawable.tag_live_rank_2);
        audienceRankLayout.rankHeadView3.flagImageView.setImageResource(R.drawable.tag_live_rank_3);

        ViewGroup.LayoutParams avatarParams;
        Uri uri;
        int size = arrayList.size();
        String avatarUrl;
        String rankGender;

        // Rank1
        if (!(size > 0)) {
            audienceRankLayout.rankHeadView1.setVisibility(View.INVISIBLE);
            return;
        } else {
            audienceRankLayout.rankHeadView1.setVisibility(View.VISIBLE);
        }
        avatarUrl = arrayList.get(0).getUserAvatar();
        rankGender = arrayList.get(0).getGender();
        avatarParams = audienceRankLayout.rankHeadView1.avatarDraweeView.getLayoutParams();
        if (TextUtils.isEmpty(avatarUrl) || avatarUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(getActivity(), String.valueOf(arrayList.get(0).getUserId()), rankGender);
            audienceRankLayout.rankHeadView1.avatarDraweeView.setImageURI(getDefaultAvatarUri);
        } else {
            uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, avatarParams.width));
            audienceRankLayout.rankHeadView1.avatarDraweeView.setImageURI(uri);
        }
        audienceRankLayout.rankHeadView1.nickTextView.setText(arrayList.get(0).getUserName());
        audienceRankLayout.rankHeadView1.avatarDraweeView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + arrayList.get(0).getUserId());
            }
        });

        // Rank2
        if (!(size > 1)) {
            audienceRankLayout.rankHeadView2.setVisibility(View.INVISIBLE);
            return;
        } else {
            audienceRankLayout.rankHeadView2.setVisibility(View.VISIBLE);
        }
        avatarUrl = arrayList.get(1).getUserAvatar();
        rankGender = arrayList.get(1).getGender();
        avatarParams = audienceRankLayout.rankHeadView2.avatarDraweeView.getLayoutParams();
        if (TextUtils.isEmpty(avatarUrl) || avatarUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(getActivity(), String.valueOf(arrayList.get(1).getUserId()), rankGender);
            audienceRankLayout.rankHeadView2.avatarDraweeView.setImageURI(getDefaultAvatarUri);
        } else {
            uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, avatarParams.width));
            audienceRankLayout.rankHeadView2.avatarDraweeView.setImageURI(uri);
        }
        audienceRankLayout.rankHeadView2.nickTextView.setText(arrayList.get(1).getUserName());
        audienceRankLayout.rankHeadView2.avatarDraweeView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + arrayList.get(1).getUserId());
            }
        });

        // Rank3
        if (!(size > 2)) {
            audienceRankLayout.rankHeadView3.setVisibility(View.INVISIBLE);
            return;
        } else {
            audienceRankLayout.rankHeadView3.setVisibility(View.VISIBLE);
        }
        avatarUrl = arrayList.get(2).getUserAvatar();
        rankGender = arrayList.get(2).getGender();
        avatarParams = audienceRankLayout.rankHeadView3.avatarDraweeView.getLayoutParams();
        if (TextUtils.isEmpty(avatarUrl) || avatarUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(getActivity(), String.valueOf(arrayList.get(2).getUserId()), rankGender);
            audienceRankLayout.rankHeadView3.avatarDraweeView.setImageURI(getDefaultAvatarUri);
        } else {
            uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, avatarParams.width));
            audienceRankLayout.rankHeadView3.avatarDraweeView.setImageURI(uri);
        }
        audienceRankLayout.rankHeadView3.nickTextView.setText(arrayList.get(2).getUserName());
        audienceRankLayout.rankHeadView3.avatarDraweeView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + arrayList.get(2).getUserId());
            }
        });
    }

    public void initHostRankView(final ArrayList<LiveRewardRankDO> arrayList) {

        hostRankLayout.rankHeadView1.flagImageView.setImageResource(R.drawable.tag_live_rank_1);
        hostRankLayout.rankHeadView2.flagImageView.setImageResource(R.drawable.tag_live_rank_2);
        hostRankLayout.rankHeadView3.flagImageView.setImageResource(R.drawable.tag_live_rank_3);

        ViewGroup.LayoutParams avatarParams;
        Uri uri;
        int size = arrayList.size();
        String avatarUrl;
        String rankGender;

        // Rank1
        if (!(size > 0)) {
            hostRankLayout.rankHeadView1.setVisibility(View.INVISIBLE);
            return;
        } else {
            hostRankLayout.rankHeadView1.setVisibility(View.VISIBLE);
        }
        avatarUrl = arrayList.get(0).getUserAvatar();
        rankGender = arrayList.get(0).getGender();
        avatarParams = hostRankLayout.rankHeadView1.avatarDraweeView.getLayoutParams();
        if (TextUtils.isEmpty(avatarUrl) || avatarUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(getActivity(), String.valueOf(arrayList.get(0).getUserId()), rankGender);
            hostRankLayout.rankHeadView1.avatarDraweeView.setImageURI(getDefaultAvatarUri);
        } else {
            uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, avatarParams.width));
            hostRankLayout.rankHeadView1.avatarDraweeView.setImageURI(uri);
        }
        hostRankLayout.rankHeadView1.nickTextView.setText(arrayList.get(0).getUserName());
        hostRankLayout.rankHeadView1.avatarDraweeView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + arrayList.get(0).getUserId());
            }
        });

        // Rank2
        if (!(size > 1)) {
            hostRankLayout.rankHeadView2.setVisibility(View.INVISIBLE);
            return;
        } else {
            hostRankLayout.rankHeadView2.setVisibility(View.VISIBLE);
        }
        avatarUrl = arrayList.get(1).getUserAvatar();
        rankGender = arrayList.get(1).getGender();
        avatarParams = hostRankLayout.rankHeadView2.avatarDraweeView.getLayoutParams();
        if (TextUtils.isEmpty(avatarUrl) || avatarUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(getActivity(), String.valueOf(arrayList.get(1).getUserId()), rankGender);
            hostRankLayout.rankHeadView2.avatarDraweeView.setImageURI(getDefaultAvatarUri);
        } else {
            uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, avatarParams.width));
            hostRankLayout.rankHeadView2.avatarDraweeView.setImageURI(uri);
        }
        hostRankLayout.rankHeadView2.nickTextView.setText(arrayList.get(1).getUserName());
        hostRankLayout.rankHeadView2.avatarDraweeView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + arrayList.get(1).getUserId());
            }
        });

        // Rank3
        if (!(size > 2)) {
            hostRankLayout.rankHeadView3.setVisibility(View.INVISIBLE);
            return;
        } else {
            hostRankLayout.rankHeadView3.setVisibility(View.VISIBLE);
        }
        avatarUrl = arrayList.get(2).getUserAvatar();
        rankGender = arrayList.get(2).getGender();
        avatarParams = hostRankLayout.rankHeadView3.avatarDraweeView.getLayoutParams();
        if (TextUtils.isEmpty(avatarUrl) || avatarUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(getActivity(), String.valueOf(arrayList.get(2).getUserId()), rankGender);
            hostRankLayout.rankHeadView3.avatarDraweeView.setImageURI(getDefaultAvatarUri);
        } else {
            uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, avatarParams.width));
            hostRankLayout.rankHeadView3.avatarDraweeView.setImageURI(uri);
        }
        hostRankLayout.rankHeadView3.nickTextView.setText(arrayList.get(2).getUserName());
        hostRankLayout.rankHeadView3.avatarDraweeView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + arrayList.get(2).getUserId());
            }
        });
    }

    public void renderTab(int tabType) {
        switch (tabType) {
            case Constant.LIVE_TYPE_NEW:
                titleRankTag1.setVisibility(View.VISIBLE);
                titleRankTag2.setVisibility(View.INVISIBLE);
                titleRankTag3.setVisibility(View.INVISIBLE);
                break;
            case Constant.LIVE_TYPE_HOT:
                titleRankTag1.setVisibility(View.INVISIBLE);
                titleRankTag2.setVisibility(View.VISIBLE);
                titleRankTag3.setVisibility(View.INVISIBLE);
                break;
            case Constant.LIVE_TYPE_MY:
                titleRankTag1.setVisibility(View.INVISIBLE);
                titleRankTag2.setVisibility(View.INVISIBLE);
                titleRankTag3.setVisibility(View.VISIBLE);
                break;
        }
    }

    @Override
    public void onRefresh() {
        loadData(true);
    }

    //public void refresh() {
    //    loadData(true);
    //}

    public interface IStateChangeListener {
        void onScrollToTop(boolean top);
        void onTabChanged(int type);
    }
}
