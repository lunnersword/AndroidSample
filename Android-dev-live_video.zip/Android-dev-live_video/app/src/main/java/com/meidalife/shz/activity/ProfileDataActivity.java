package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.ProfileDataFragment;
import com.meidalife.shz.adapter.FragmentTabAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.model.ProfileDataDO;
import com.meidalife.shz.widget.SlidingTabLayout;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 个人主页-数据概况
 * Created by liujian on 16/4/8.
 */
public class ProfileDataActivity extends BaseActivity implements ViewPager.OnPageChangeListener {

    @Bind(R.id.slidingTab)
    SlidingTabLayout slidingTab;
    @Bind(R.id.tabViewPager)
    ViewPager tabViewPager;

    // private String followingNum = "0";
    private String followerNum = "0";
    private String orderNum = "0";
    private String viewNum = "0";
    private int filterTab = -1;
    FragmentTabAdapter fragmentTabAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_data);

        ButterKnife.bind(this);
        initActionBar(R.string.text_profile_data, true);

        Intent intent = getIntent();
        if (intent.getStringExtra("type") != null)
            filterTab = Integer.parseInt(intent.getStringExtra("type"));
        filterTab = filterTab == 0 ? -1 : filterTab;
        fragmentTabAdapter = new FragmentTabAdapter(getSupportFragmentManager());
        initTab();
    }

    private void initTab() {
        int currentItem = 0;
        if (filterTab != -1)
            currentItem = filterTab;
        String[] profileDataTypes = getResources().getStringArray(R.array.profileDataType);
        for (int i = 0; i < profileDataTypes.length; i++) {
            Bundle bundle = new Bundle();
            bundle.putString("title", profileDataTypes[i]);
            bundle.putInt("type", i + 1);
            ProfileDataFragment profileDataFragment = ProfileDataFragment.newInstance(bundle);
            profileDataFragment.setOnChangeDataCountListener(new ProfileDataFragment.OnChangeDataCountListener() {
                @Override
                public void onChangeData(List<ProfileDataDO.DataViewTab> dataViewTabList) {
                    if (dataViewTabList.size() < 3)
                        return;
                    //  followingNum = dataViewTabList.get(0).getCount() +"";
                    followerNum = dataViewTabList.get(0).getCount() + "";
                    orderNum = dataViewTabList.get(1).getCount() + "";
                    viewNum = dataViewTabList.get(2).getCount() + "";
                    initDataCount(true);
                }
            });
            fragmentTabAdapter.addFragment(profileDataFragment);
        }
        fragmentTabAdapter.notifyDataSetChanged();
        tabViewPager.setAdapter(fragmentTabAdapter);
        slidingTab.setCustomTabView(R.layout.item_profile_data_tab, R.id.tabName);
        slidingTab.setSelectedIndicatorColors(getResources().getColor(R.color.brand_b));
        slidingTab.setSelectedTabTitleColorId(R.color.brand_b);
        slidingTab.setTabTitleColorId(R.color.brand_c);
        slidingTab.setViewPager(tabViewPager);
        slidingTab.setDividerColors(android.R.color.transparent);
        slidingTab.setCalculateWidthByTitle(false);
        slidingTab.setOnPageChangeListener(this);
        tabViewPager.setCurrentItem(currentItem);
        initDataCount(true);
        ((TextView) (slidingTab.getChildTabView(currentItem).findViewById(R.id.dataCount))).setTextColor(getResources().getColor(R.color.brand_b));
        ((TextView) (slidingTab.getChildTabView(currentItem).findViewById(R.id.tabName))).setTextColor(getResources().getColor(R.color.brand_b));

    }

    private void initDataCount(boolean updateCount) {
        for (int i = 0; i < 3; i++) {
            TextView textView = ((TextView) (slidingTab.getChildTabView(i).findViewById(R.id.dataCount)));
            if (updateCount) {
                switch (i) {
//                    case 0:
//                        textView.setText("("+followingNum+")");
//                        break;
                    case 0:
                        textView.setText("(" + followerNum + ")");
                        break;
                    case 1:
                        textView.setText("(" + orderNum + ")");
                        break;
                    case 2:
                        textView.setText("(" + viewNum + ")");
                        break;
                }
            } else {
                textView.setTextColor(getResources().getColor(R.color.brand_c));
            }
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        //外部指定跳转某个Tab页时,不主动调用刷新
        if (filterTab == -1) {
            initDataCount(false);
            ((TextView) (slidingTab.getChildTabView(position).findViewById(R.id.dataCount))).setTextColor(getResources().getColor(R.color.brand_b));
            ((ProfileDataFragment) (fragmentTabAdapter.getItem(position))).initData(true);
        } else
            filterTab = -1;
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

}
