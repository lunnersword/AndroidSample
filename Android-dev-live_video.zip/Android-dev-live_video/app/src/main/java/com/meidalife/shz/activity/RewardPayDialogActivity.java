package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.PayWayAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.PayWayOutDo;
import com.tencent.mm.sdk.modelbase.BaseResp;

import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 支付打赏选择界面
 * Created by xingchen on 2015/11/25.
 */
public class RewardPayDialogActivity extends Activity {
    private String receiverId;
    private int rewardAmount;
    private String rewardsDesc;
    private String sourceId;
    private String orderNo;
    private boolean isLoading = false;
    @Bind(R.id.iconClose)
    TextView iconClose;
    @Bind(R.id.awardsTitle)
    TextView awardsTitle;
    @Bind(R.id.payWayGridView)
    GridView payWayGridView;

    private PayWayAdapter mAdapter;


    private List<PayWayOutDo> paywayList = new LinkedList<>();

    private BroadcastReceiver payResultReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int payWay = intent.getIntExtra(Pay.TAG_PAY_WAY, 0);
            int errCode = intent.getIntExtra(Pay.TAG_ERROR_CODE, BaseResp.ErrCode.ERR_COMM);
            if (payWay == Pay.PAY_WAY_WECHAT) {
                Intent data = new Intent();
                data.putExtra(Pay.TAG_PAY_RESULT, errCode == BaseResp.ErrCode.ERR_OK);
                data.putExtra(Pay.TAG_PAY_WAY, Pay.PAY_WAY_WECHAT);
                data.putExtra("amount", rewardAmount);
                data.putExtra("rewardsDesc", rewardsDesc);
                RewardPayDialogActivity.this.setResult(RESULT_OK, data);
                RewardPayDialogActivity.this.finish();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_award_pay_dialog);
        ButterKnife.bind(this);

        receiverId = getIntent().getStringExtra("receiverId");
        rewardAmount = getIntent().getIntExtra("amount", 0);
        rewardsDesc = getIntent().getStringExtra("rewardsDesc");
        sourceId = getIntent().getStringExtra("sourceId");


        createRewardOrder();
        initComponents();

        IntentFilter filter = new IntentFilter();
        filter.addAction(Pay.ACION_PAY_RESULT);

        LocalBroadcastManager.getInstance(this).registerReceiver(payResultReceiver, filter);
        setFinishOnTouchOutside(false);
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(payResultReceiver);
        super.onDestroy();
    }

    private void initComponents() {
        iconClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        payWayGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < paywayList.size()) {
                    PayWayOutDo clickedItem = paywayList.get(position);

                    for (PayWayOutDo item : paywayList) {
                        if (item.getType() == clickedItem.getType()) {
                            if (item.getSelected() != 1) {
                                item.setSelected(1);
                            }
                        } else {
                            item.setSelected(0);
                        }
                    }
                    mAdapter.notifyDataSetChanged();

                    switch (clickedItem.getType()) {
                        case 1:
                            rewardPay(Pay.PAY_WAY_ALIPAY);
                            break;
                        case 2:
                            rewardPay(Pay.PAY_WAY_WECHAT);
                            break;
                        case 3:
                        default:
                            rewardPay(Pay.PAY_WAY_FUND);
                            break;
                    }
                    payWayGridView.setEnabled(false);
                }
            }
        });
    }

    private void createRewardOrder() {
        JSONObject params = new JSONObject();
        params.put("receiverId", receiverId);
        params.put("amount", rewardAmount);
        params.put("rewardsDesc", rewardsDesc);
        params.put("sourceId", sourceId);//打赏来源ID，选传。例如 视频直播ID

        HttpClient.get("1.0/rewards/createOrder", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        orderNo = obj.getString("orderNo");
                        awardsTitle.setText(obj.getString("title"));

                        paywayList.addAll(JSON.parseArray(obj.getString("outerPayways"), PayWayOutDo.class));
                        payWayGridView.setNumColumns(paywayList.size());
                        payWayGridView.setPadding(getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin)
                                , 0, getResources().getDisplayMetrics().widthPixels / paywayList.size(), 0);
                        mAdapter = new PayWayAdapter(RewardPayDialogActivity.this, paywayList);
                        payWayGridView.setAdapter(mAdapter);
                        mAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(getString(R.string.reward_failed) + error.toString());
                        finish();
                    }
                });
    }

    private void rewardPay(final int payWay) {
        if (isLoading) {
            return;
        }
        isLoading = true;
        JSONObject params = new JSONObject();
        params.put("orderNo", orderNo);
        params.put("gwPayway", payWay);
        params.put("gwPayNum", rewardAmount);
        HttpClient.get("1.0/rewards/pay", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        switch (payWay) {
                            case Pay.PAY_WAY_ALIPAY:
                                String signPayStr = obj.getString("signPayStr");
                                Pay.payWithAlipay(RewardPayDialogActivity.this, signPayStr, new Pay.PayCallback() {
                                    @Override
                                    public void success() {
                                        Intent data = new Intent();
                                        data.putExtra(Pay.TAG_PAY_RESULT, true);
                                        data.putExtra(Pay.TAG_PAY_WAY, Pay.PAY_WAY_ALIPAY);
                                        data.putExtra("amount", rewardAmount);
                                        data.putExtra("rewardsDesc", rewardsDesc);
                                        setResult(RESULT_OK, data);
                                        finish();
                                    }

                                    @Override
                                    public void failure(Error error) {
                                        Intent data = new Intent();
                                        data.putExtra(Pay.TAG_PAY_RESULT, false);
                                        data.putExtra(Pay.TAG_PAY_WAY, Pay.PAY_WAY_ALIPAY);
                                        setResult(RESULT_OK, data);
                                        finish();
                                        MessageUtils.showToastCenter(error.getMessage());
                                    }
                                });
                                break;
                            case Pay.PAY_WAY_WECHAT: {
                                Pay.payWithWechat(RewardPayDialogActivity.this, obj.getJSONObject("wxPay"));
                                break;
                            }
                            case Pay.PAY_WAY_FUND: {
                                finish();
                                break;
                            }
                            default:
                                finish();
                        }
                        isLoading = false;
//                        alipayLayout.setEnabled(true);
//                        wechatPayLayout.setEnabled(true);
                        payWayGridView.setEnabled(true);
                    }

                    @Override
                    public void onFail(HttpError error) {
                        isLoading = false;
                        MessageUtils.showToast(getString(R.string.pay_error) + error.toString());
                        finish();
                    }
                });
    }
}
