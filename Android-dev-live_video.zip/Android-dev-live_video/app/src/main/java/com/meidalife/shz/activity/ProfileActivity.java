package com.meidalife.shz.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentTabHost;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.Spannable;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.ChatExpressionFragment;
import com.meidalife.shz.activity.fragment.ProfileActionFragment;
import com.meidalife.shz.activity.fragment.ProfileCommentFragment;
import com.meidalife.shz.activity.fragment.ProfileMeFragment;
import com.meidalife.shz.adapter.ProfileJobListAdapter;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.ProfileActionCommentEvent;
import com.meidalife.shz.event.ScrollToTopEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.MainPageDO;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.widget.DragTopLayout;
import com.meidalife.shz.widget.PopupListMenu;
import com.meidalife.shz.widget.ProfilePopupWindow;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.umeng.socialize.media.UMImage;
import com.usepropeller.routable.Router;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 个人主页
 * Created by liujian on 16/4/6.
 */
public class ProfileActivity extends BaseActivity implements ScrollToTopEvent {

    private static final int MENU_UPDATE_USER_INFO = 0;  //修改基础信息
    private static final int MENU_UPDATE_BACKGROUND_IMAGE = 1; //更改封面图片
    private static final int MENU_CANCEL = 2;  //取消

    private static final int MENU_ITEM_SHARE = 0;
    private static final int MENU_ITEM_GRCODE = 1;
    private static final int MENU_ITEM_REPORT = 2;

    private static final int PROFILE_TAB_COMMENT = 0;
    private static final int PROFILE_TAB_ACTION = 1;
    private static final int PROFILE_TAB_ME = 2;

    private static final long LIVE_INCREAS_TIME = 1000l;

    private static final int REFRESH_FRAGEMNT_ACTION = 11;

    @Bind(R.id.tabBar)
    LinearLayout tabBar;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    ViewGroup contentView;
    @Bind(R.id.action_bar_button_back)
    View action_bar_button_back;
    @Bind(R.id.fragmentContainer)
    FrameLayout fragmentContainer;
    @Bind(R.id.dragLayout)
    DragTopLayout dragLayout;
    @Bind(R.id.user_background)
    SimpleDraweeView user_background;
    @Bind(R.id.user_avatar)
    SimpleDraweeView user_avatar;
    @Bind(R.id.serviceItemImage)
    SimpleDraweeView serviceItemImage;
    @Bind(R.id.background)
    View background;
    @Bind(R.id.action_bar_button_right)
    View action_bar_button_right;
    @Bind(R.id.dataLayout)
    View dataLayout;
    @Bind(R.id.guide_add_service)
    View guide_add_service;
    @Bind(R.id.serviceItemGroup)
    View serviceItemGroup;
    @Bind(R.id.serviceTitle)
    TextView serviceTitle;
    @Bind(R.id.star_icon_group)
    LinearLayout starIconGroup;
    @Bind(R.id.servicePrice)
    TextView servicePrice;
    @Bind(R.id.serviceSellCount)
    TextView serviceSellCount;
    @Bind(R.id.user_name)
    TextView user_name;
    @Bind(R.id.iconGender)
    TextView iconGender;
    @Bind(R.id.user_Address)
    TextView user_Address;
    @Bind(R.id.onlineTime)
    TextView onlineTime;
    @Bind(R.id.followingLayout)
    View followingLayout;
    @Bind(R.id.followingNum)
    TextView followingNum;
    @Bind(R.id.followingLine)
    View followingLine;
    @Bind(R.id.followerLayout)
    View followerLayout;
    @Bind(R.id.followerNum)
    TextView followerNum;
    @Bind(R.id.followerLine)
    View followerLine;
    @Bind(R.id.orderLayout)
    View orderLayout;
    @Bind(R.id.orderNum)
    TextView orderNum;
    @Bind(R.id.orderLine)
    View orderLine;
    @Bind(R.id.serviceItemNum)
    TextView serviceItemNum;
    @Bind(R.id.jobListView)
    ListView jobListView;
    @Bind(R.id.jobLayout)
    View jobLayout;
    @Bind(R.id.guideText)
    TextView guideText;
    @Bind(R.id.guideOpr)
    TextView guideOpr;
    @Bind(R.id.commentNum)
    TextView commentNum;
    @Bind(R.id.actionNum)
    TextView actionNum;
    @Bind(R.id.constellation)
    TextView constellation;
    @Bind(R.id.jobTitle)
    TextView jobTitle;
    @Bind(R.id.viewNumLayout)
    View viewNumLayout;
    @Bind(R.id.viewNum)
    TextView viewNum;
    @Bind(R.id.konggeNumber)
    TextView konggeNumber;
    @Bind(R.id.rightIcon)
    View rightIcon;
    @Bind(R.id.jobListTitle)
    TextView jobListTitle;
    @Bind(R.id.checkJobs)
    TextView checkJobs;
    @Bind(R.id.liveLayout)
    View liveLayout;
    @Bind(R.id.liveTime)
    TextView liveTime;
    @Bind(R.id.publishLayout)
    View publishLayout;
    @Bind(R.id.publishServiceView)
    TextView publishServiceView;
    @Bind(R.id.publishActionView)
    TextView publishActionView;
    @Bind(R.id.emptyTitle)
    View emptyTitle;
    @Bind(R.id.backBtn)
    TextView backBtn;

    @Bind(R.id.commentView)
    LinearLayout commentView;
    @Bind(R.id.inputEdit)
    EditText inputEdit;
    @Bind(R.id.cellInputGroup)
    LinearLayout cellInputGroup;
    @Bind(R.id.chatFaceIcon)
    TextView chatFaceIcon;
    @Bind(R.id.chatSend)
    Button chatSend;
    @Bind(R.id.chatFaceContainer)
    LinearLayout chatFaceContainer;
    @Bind(android.R.id.tabhost)
    FragmentTabHost mTabHost;
    @Bind(R.id.chatFaceLayout)
    View chatFaceLayout;

    private int currentTab;
    private ProfilePopupWindow profilePopupWindow;
    private LoadUtil loadUtil;
    private boolean hasServiceItem;
    private boolean hasJob;
    private ProfileMeFragment profileMeFragment;
    private ProfileActionFragment profileActionFragment;
    private ArrayList<HashMap<String, String>> constellationData;
    private boolean isRefresh;
    private String backgroupUrl;
    private String userId;
    private String nick;
    private SocialSharePopupWindow socialSharePopupWindow;
    private ShareActivity shareActivity;
    private MainPageDO.User mainUser;
    private boolean isMine;    //是否为自己
    private Handler handler = new Handler();
    private long liveOnLineTime = Constant.DO_UNDEFINE_LONG_TYPE;
    private boolean isFollow;
    private InputMethodManager imm;
    private ProfileActionCommentEvent profileActionCommentEvent;
    private ChatHelper chatHelper;
    private int rootHeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ButterKnife.bind(this);

        loadUtil = new LoadUtil(LayoutInflater.from(this));
        constellationData = SignUpActivity.getConstellationData(this);
        shareActivity = new ShareActivity(this);
        Bundle bundle = getIntent().getExtras();
        userId = bundle.getString("userId");
        initListener();
        chatHelper = ChatHelper.getInstance();
        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        hideIMM();
        mTabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);
        mTabHost.addTab(getTabSpecView("home", R.layout.item_single_image), ChatExpressionFragment.class, null);
        setTab(PROFILE_TAB_COMMENT);
        setTabListener(tabBar);

        initData();
    }

    private void setTab(int tab) {
        replaceFragment(tab);
        setCurrentTabLine(tab, tabBar);
        currentTab = tab;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_CHANGE_PROFILE_LABEL
                || requestCode == ProfileMeFragment.UPDATE_PROFILE_INTRODUCE
                || requestCode == ProfileMeFragment.UPDATE_PROFILE_ME) {
            profileMeFragment.onActivityResult(requestCode, resultCode, data);
        } else if (resultCode == RESULT_OK && requestCode == Constant.REQUEST_CODE_PICK_PHOTO) {
            Bundle params = data.getExtras();
            ArrayList paths = params.getStringArrayList("images");
            if (paths.size() > 0) {
                if ((String) paths.get(0) != null)
                    UploadBackgroupImage((String) paths.get(0));
            }
        } else if (requestCode == Constant.REQUEST_CODE_PUBLISH_SERVICE && resultCode == RESULT_OK) {
            initData();
        } else if (resultCode == RESULT_OK && requestCode == Constant.REQUEST_CODE_REWARD) {
            profileActionFragment.onActivityResult(requestCode, resultCode, data);
        }else if(requestCode == REFRESH_FRAGEMNT_ACTION){
            initData();
            profileActionFragment.getData(true);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
        if (isRefresh) {
            setTab(PROFILE_TAB_COMMENT);
            initData();
            isRefresh = false;
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onBackPressed() {
        if (commentView.getVisibility() == View.VISIBLE) {
            hideInput();
            return;
        }
        super.onBackPressed();
    }

    public void onEvent(BaseEvent event) {
        //删除动态
        if (event.eventType == MsgTypeEnum.TYPE_PROFILE_ACTION_DEL_ID) {
            long feedNum = mainUser.getFeedNum() - 1;
            mainUser.setFeedNum(feedNum < 0 ? 0 : feedNum);
            initTabNum(mainUser.getCommentNum(), mainUser.getFeedNum());
        }
        //评论动态
        if (event.eventType == MsgTypeEnum.TYPE_PROFILE_ACTION_COMMENT) {
            profileActionCommentEvent = (ProfileActionCommentEvent) event;
            showInputEdit();
        }

        if (event.eventType == MsgTypeEnum.TYPE_CHAT_EXPRESSION) {
            ChatExpressionFragment.ChatExpressionEvent chatExpressionEvent = (ChatExpressionFragment.ChatExpressionEvent) event;
            Editable edit = inputEdit.getEditableText();//获取EditText的文字
            int index = inputEdit.getSelectionStart();
            if (index < 0 || index >= edit.length()) {
                edit.append(chatExpressionEvent.expressionName);
            } else {
                edit.insert(index, chatExpressionEvent.expressionName);//光标所在位置插入文字
            }
            ImageSpan expressionPan = chatHelper.getImageSpan(chatExpressionEvent.expressionName, 20);
            if (null != expressionPan) {
                edit.setSpan(expressionPan, index, index + chatExpressionEvent.expressionName.length(),
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }

    }

    private FragmentTabHost.TabSpec getTabSpecView(String tag, int layoutId) {
        return mTabHost.newTabSpec(tag).setIndicator(getLayoutInflater().inflate(layoutId, null));
    }

    private void initListener() {
        action_bar_button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleBack(null);
            }
        });
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleBack(null);
            }
        });
        background.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isMine)
                    showUpdateUserInfoPop(v);
            }
        });
        action_bar_button_right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSharePopMenu(v);
            }
        });
        dataLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mainUser == null || !isMine)
                    return;
                Router.sharedRouter().open("profileData/0");
                isRefresh = true;
            }
        });

        chatFaceLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (chatFaceContainer.getVisibility() == View.GONE) {
                    chatFaceContainer.setVisibility(View.VISIBLE);
                    chatFaceIcon.setText(getString(R.string.icon_chat_keyboard));
                    imm.hideSoftInputFromWindow(inputEdit.getWindowToken(), 0);
                } else {
                    inputEdit.requestFocus();
                    chatFaceIcon.setText(getString(R.string.icon_chat_face));
                    chatFaceContainer.setVisibility(View.GONE);
                }
            }
        });
        inputEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chatFaceContainer.setVisibility(View.GONE);
                chatFaceIcon.setText(getString(R.string.icon_chat_face));
            }
        });
        chatSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(inputEdit.getText().toString()))
                    addComment(inputEdit.getText().toString());
            }
        });
        ViewTreeObserver vto = rootView.getViewTreeObserver();
        vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            public boolean onPreDraw() {
                //解决键盘隐藏,布局高度不还原问题,重绘高度,
                int height = rootView.getMeasuredHeight();
                if (rootHeight != 0 && (rootHeight - height) < 0) {   //键盘隐藏
                    fragmentContainer.requestLayout();
                }
                rootHeight = height;
                return true;
            }
        });
    }

    private void initData() {
        emptyTitle.setVisibility(View.VISIBLE);
        loadUtil.loadPre(rootView, contentView);
        JSONObject params = new JSONObject();
        if (!TextUtils.isEmpty(userId)) {
            params.put("userId", userId);
        }
        HttpClient.get("2.0/user/getMainPage", params, MainPageDO.class, new HttpClient.HttpCallback<MainPageDO>() {
            @Override
            public void onSuccess(MainPageDO mainPageDO) {
                emptyTitle.setVisibility(View.GONE);
                loadUtil.loadSuccess(contentView);
                int tabId = mainPageDO.getTabId() == null ? 0 : Integer.parseInt(mainPageDO.getTabId());
                if(currentTab != tabId)
                    setTab(tabId);
                if (mainPageDO != null && mainPageDO.getUser() != null) {
                    mainUser = mainPageDO.getUser();
                    isFollow = mainPageDO.isFollow();
                    userId = mainUser.getUserId() == null ? "" : mainUser.getUserId() + "";
                    isMine = userId.equals(Helper.sharedHelper().getUserId());
                    nick = mainUser.getNick();
                    backgroupUrl = mainUser.getBackgroundUrl();
                    initHeaderView(mainUser);
                    initServiceItem(mainUser.getItemList(), mainUser.getItemNum());
                    initJobs(mainUser.getJobs());
                    showGuide();
                }
            }

            @Override
            public void onFail(HttpError error) {
                loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initData();
                    }
                });
            }
        });
    }

    private void initHeaderView(final MainPageDO.User mainUser) {

        if(!TextUtils.isEmpty(mainUser.getBackgroundUrl()))
            user_background.setImageURI(Uri.parse(mainUser.getBackgroundUrl()));
        if (mainUser.getPicUrl() != null)
            user_avatar.setImageURI(Uri.parse(mainUser.getPicUrl()));
        user_name.setText(mainUser.getNick());
        // 设置性别
        if (mainUser.getGender() != null) {
            iconGender.setVisibility(View.VISIBLE);
            if (mainUser.getGender().equals("woman") || mainUser.getGender().equals("F")) {
                iconGender.setText(getResources().getString(R.string.icon_gender_f));
                iconGender.setBackgroundResource(R.drawable.bg_circle_profile_red);
            } else {
                iconGender.setText(getResources().getString(R.string.icon_gender_m));
                iconGender.setBackgroundResource(R.drawable.bg_circle_profile_brand_i);
            }
        } else {
            iconGender.setVisibility(View.GONE);
        }
        if (mainUser.isKonggeMember()) {
            konggeNumber.setVisibility(View.VISIBLE);
        } else
            konggeNumber.setVisibility(View.GONE);
        user_Address.setText(mainUser.getCityName());
        onlineTime.setText(mainUser.getStayTime());
        if (mainUser.getJobTitle() != null) {
            jobTitle.setText(mainUser.getJobTitle());
        } else
            jobTitle.setVisibility(View.GONE);
        //星座
        if (mainUser.getConstellation() != Constant.DO_UNDEFINE_INT_TYPE) {
            Map<String, String> value = constellationData.get(mainUser.getConstellation() - 1);
            constellation.setText(value.get("name"));
            constellation.setVisibility(View.VISIBLE);
        } else {
            constellation.setVisibility(View.INVISIBLE);
        }
        //关注
        followingNum.setText(mainUser.getFollowingNum() + "");
        //粉丝
        followerNum.setText(mainUser.getFollowerNum() + "");
        //约单
        orderNum.setText(mainUser.getOrderOnBuyerNum() + "");

        if (isMine) {
            viewNumLayout.setVisibility(View.VISIBLE);
            orderLine.setVisibility(View.VISIBLE);
            rightIcon.setVisibility(View.VISIBLE);
            viewNum.setText(mainUser.getViewNum() + "");
        } else { //访客
            viewNumLayout.setVisibility(View.GONE);
            orderLine.setVisibility(View.GONE);
            rightIcon.setVisibility(View.GONE);
        }
        //直播相关
        if (mainUser.isLiveCast()) {
            liveLayout.setVisibility(View.VISIBLE);
            if (mainUser.getLiveStartTime() != Constant.DO_UNDEFINE_LONG_TYPE) {
                handler.removeCallbacks(liveRunnable);
                liveOnLineTime = System.currentTimeMillis() - mainUser.getLiveStartTime();
                liveTime.setText(DateUtils.time2StringShortWithHour1(liveOnLineTime));
                handler.postDelayed(liveRunnable, LIVE_INCREAS_TIME);
            }
            liveLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (liveOnLineTime == Constant.DO_UNDEFINE_LONG_TYPE)
                        return;
                    Intent intent = new Intent(ProfileActivity.this, LiveActivity.class);
                    intent.putExtra("liveId", mainUser.getLiveChannelId());
                    startActivity(intent);
                    isRefresh = true;
                }
            });
        } else
            liveLayout.setVisibility(View.GONE);
        //发布
        if (isMine) {
            publishServiceView.setText(getString(R.string.text_publish_service));
            publishActionView.setText(getString(R.string.text_publish_action));
            publishServiceView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    publishService();
                }
            });
            publishActionView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    publishAction();
                }
            });
        } else {
            publishServiceView.setText(getString(isFollow ? R.string.text_has_attention : R.string.text_add_attention));
            publishActionView.setText(getString(R.string.text_chat_ta));
            publishServiceView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    handlerAttention();
                }
            });
            publishActionView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    chatTa();
                }
            });
        }
        if (isMine) {
            jobListTitle.setText(getResources().getString(R.string.text_my_job));
        } else
            jobListTitle.setText(getResources().getString(R.string.text_ta_job));
        initTabNum(mainUser.getCommentNum(), mainUser.getFeedNum());
    }

    Runnable liveRunnable = new Runnable() {
        @Override
        public void run() {
            if (mainUser != null && mainUser.getLiveStartTime() != Constant.DO_UNDEFINE_LONG_TYPE) {
                liveOnLineTime = liveOnLineTime + LIVE_INCREAS_TIME;
                liveTime.setText(DateUtils.time2StringShortWithHour1(liveOnLineTime));
                handler.postDelayed(this, LIVE_INCREAS_TIME);
            }
        }
    };

    private void initTabNum(long comment, long feed) {
        commentNum.setText("(" + comment + ")");
        actionNum.setText("(" + feed + ")");
    }

    private void initServiceItem(List<MainPageDO.Item> itemList, int itemNum) {
        if (itemList == null || itemList.size() == 0) {
            hasServiceItem = false;
            return;
        }
        hasServiceItem = true;
        serviceItemGroup.setVisibility(View.VISIBLE);
        final MainPageDO.Item item = itemList.get(0);
        serviceItemGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("services/" + item.getItemId());
            }
        });
        serviceItemImage.setImageURI(Uri.parse(item.getItemUrl()));
        serviceTitle.setText(item.getTitle());
        servicePrice.setText(item.getPrice());
        if (item.getSellCount() == 0) {
            serviceSellCount.setVisibility(View.GONE);
        } else {
            serviceSellCount.setVisibility(View.VISIBLE);
            serviceSellCount.setText(String.format(getString(R.string.text_sell_count), item.getSellCount() + ""));
        }
        if (item.getGrade() == Constant.DO_UNDEFINE_INT_TYPE) {
            starIconGroup.setVisibility(View.INVISIBLE);
        } else {
            View starsView = LayoutInflater.from(this).inflate(R.layout.view_grade_stars, starIconGroup, false);
            ViewGroup starsRed = (ViewGroup) starsView.findViewById(R.id.star_red_group);
            ViewGroup starsGrey = (ViewGroup) starsView.findViewById(R.id.star_grey_group);
            for (int i = 0; i < 5; i++) {
                TextView iconTextView = (TextView) starsRed.getChildAt(i);
                iconTextView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);

                TextView iconTextView1 = (TextView) starsGrey.getChildAt(i);
                iconTextView1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
            }
            starsRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(12 * 5, this) * item.getGrade() / 5);
            starIconGroup.setVisibility(View.VISIBLE);
            starIconGroup.removeAllViews();
            starIconGroup.addView(starsView);
        }
        //管理服务数
        if (isMine) {
            serviceItemNum.setText(String.format(getString(R.string.text_service_item_num), itemNum + ""));
            serviceItemNum.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("serviceListPublish");
                }
            });
        } else {  //ta的服务
            serviceItemNum.setText(String.format(getString(R.string.text_ta_service_item_num), itemNum + ""));
            serviceItemNum.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("serviceListShow/" + userId);
                }
            });
        }
    }

    private void initJobs(List<MainPageDO.Job> jobs) {
        if (jobs == null || jobs.size() == 0) {
            hasJob = false;
            return;
        }
        hasJob = true;
        jobLayout.setVisibility(View.VISIBLE);
        ProfileJobListAdapter profileJobListAdapter = new ProfileJobListAdapter(this, jobs);
        jobListView.setAdapter(profileJobListAdapter);
        if (isMine) {
            checkJobs.setVisibility(View.VISIBLE);
            checkJobs.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    checkJob();
                }
            });
        } else {
            checkJobs.setVisibility(View.GONE);
        }
    }

    private void showGuide() {
        if (hasJob && !hasServiceItem) {   //有职业,无服务
            jobLayout.setVisibility(View.VISIBLE);
            serviceItemGroup.setVisibility(View.GONE);
            if (isMine) {
                guide_add_service.setVisibility(View.VISIBLE);
                guideText.setText("发布服务 边玩边赚");
                guideOpr.setText("添加服务");
                guideOpr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        publishService();
                    }
                });
            } else
                guide_add_service.setVisibility(View.GONE);
            return;
        }
        if (!hasJob && hasServiceItem) {   //无职业,有服务
            jobLayout.setVisibility(View.GONE);
            serviceItemGroup.setVisibility(View.VISIBLE);
            if (isMine) {
                guide_add_service.setVisibility(View.VISIBLE);
                guideText.setText("选职业 用技能赚钱");
                guideOpr.setText("+添加职业");
                guideOpr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        addJob();
                    }
                });
            } else
                guide_add_service.setVisibility(View.GONE);
            return;
        }
        if (!hasJob && !hasServiceItem) {   //无服务,无职业
            jobLayout.setVisibility(View.GONE);
            serviceItemGroup.setVisibility(View.GONE);
            guide_add_service.setVisibility(View.VISIBLE);

            if (isMine) {
                guideText.setText("发布服务 边玩边赚");
                guideOpr.setText("+添加服务");
                guideOpr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        publishService();
                    }
                });
            } else {
                guideText.setText("Ta还未发布任何服务哦");
                guideOpr.setVisibility(View.GONE);
            }
        }
        if (hasJob && hasServiceItem) {     //有服务,有职业
            jobLayout.setVisibility(View.VISIBLE);
            serviceItemGroup.setVisibility(View.VISIBLE);
            guide_add_service.setVisibility(View.GONE);
        }
    }

    //发布服务
    private void publishService() {
        if (Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().openFormResult("publish", Constant.REQUEST_CODE_PUBLISH_SERVICE, ProfileActivity.this);
        } else {
            MessageUtils.showDialog(ProfileActivity.this, "提醒", "你还没有登录，登录后才可以发布服务哦", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Bundle bundle = new Bundle();
                    bundle.putString("action", "publish");
                    Router.sharedRouter().openFormResult("signin", bundle, Constant.REQUEST_CODE_PUBLISH_SERVICE, ProfileActivity.this);
                }
            }, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });
        }
    }

    //发布动态
    public void publishAction() {
        if (Helper.sharedHelper().hasToken()) {
            //跳转到创建动态页面
            Router.sharedRouter().openFormResult("publish/dynamic", REFRESH_FRAGEMNT_ACTION,this);
        } else {
            Router.sharedRouter().open("signin");
        }
    }

    //添加关注
    private void handlerAttention() {
        JSONObject params = new JSONObject();
        params.put("attentionUserId", userId == null ? "" : userId);
        HttpClient.get(isFollow ? "1.0/attention/delUserAttention" : "1.0/attention/addUserAttention", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                isFollow = !isFollow;
                publishServiceView.setText(isFollow ? R.string.text_has_attention : R.string.text_add_attention);

            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error.getMessage());
            }
        });
    }

    //动态评论
    void addComment(final String content) {
        if (profileActionCommentEvent == null)
            return;
        chatSend.setEnabled(false);
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("feed_id", profileActionCommentEvent.getFeedId());
        params.put("feed_user_id", profileActionCommentEvent.getUserId());
        if (profileActionCommentEvent.getReplyUserId() != null)
            params.put("reply_user_id", profileActionCommentEvent.getReplyUserId());//需要提供回复用户id
        params.put("reply_content", content);

        RequestDynamic.addComment(params, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                MessageUtils.showToastCenter("发表成功");
                chatSend.setEnabled(true);
                hideInput();
                // 更新该动态评价
                ProfileActionCommentEvent event = new ProfileActionCommentEvent(MsgTypeEnum.TYPE_REFRESH);
                event.setPosition(profileActionCommentEvent.getPosition());
                event.setNickName(profileActionCommentEvent.getNickName());
                event.setContent(content);
                EventBus.getDefault().post(event);
            }

            @Override
            public void onFail(HttpError error) {
                chatSend.setEnabled(true);
                MessageUtils.showToastCenter(error.toString());
            }

        });
    }

    //找TA聊
    private void chatTa() {
        if (!TextUtils.isEmpty(userId)) {
            Router.sharedRouter().open("chat/" + userId);
        }
    }

    //添加职业
    private void addJob() {
        Router.sharedRouter().open("careerManage");
    }

    private void checkJob() {
        Router.sharedRouter().open("careerManage");
    }

    public void selectPic() {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", 1);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, this);
    }

    private void UploadBackgroupImage(String path) {
        RequestSign.upload(path, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                org.json.JSONObject json = (org.json.JSONObject) result;
                try {
                    if (json.getString("data") != null) {
                        backgroupUrl = json.getString("data");
                        user_background.setImageURI(Uri.parse(backgroupUrl));
                        xhrUpdateProfile();
                    }
                } catch (JSONException e) {
                }
                hideProgressDialog();
            }

            @Override
            public void onFailure(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "图片上传失败，请重试");
            }
        });
    }

    private void xhrUpdateProfile() {
        try {
            org.json.JSONObject params = new org.json.JSONObject();

            params.put("backgroundUrl", backgroupUrl);
            //  params.put("instruction", textDescription.getText().toString());

            showProgressDialog("正在保存");
            RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter("保存成功");
//                    finish();

                }

                @Override
                public void onFailure(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败");
                }
            });
        } catch (JSONException e) {
        }
    }

    void showQRCode() {
        Bundle params = new Bundle();
        params.putString("iconUrl", getQRCodeImage().toUrl());
        params.putString("content", ShareActivity.getProfileShareUrl(userId == null ? Helper.sharedHelper().getUserId() : userId));
        params.putString("title", nick != null ? nick : "");

        Router.sharedRouter().open("qrCodeCreate", params);
    }

    //分享
    private void showOrHideShareView(View v) {
        if (socialSharePopupWindow == null) {
            String title = null;
            String nickName = nick != null ? nick : "";
            String content = null;
            String url = ShareActivity.getProfileShareUrl(userId);
            if (userId.equals(Helper.sharedHelper().getUserId())) {
                title = String.format(getString(R.string.my_profile_share_title), nickName);
                content = getString(R.string.my_profile_share_content);
            } else {
                title = getString(R.string.profile_share_title);
                content = getString(R.string.profile_share_content);
            }

            socialSharePopupWindow = new SocialSharePopupWindow(this, shareActivity,
                    SocialSharePopupWindow.SHARE_TYPE_PROFILE);
            socialSharePopupWindow.setShareUrl(url);
            socialSharePopupWindow.setShareTitle(title);
            socialSharePopupWindow.setShareUserName(nickName);
            socialSharePopupWindow.setShareDescription(content);
            socialSharePopupWindow.setShareImage(getShareImage());
        }
        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private UMImage getQRCodeImage() {
        if (mainUser != null && !TextUtils.isEmpty(mainUser.getPicUrl()))
            return new UMImage(this, ImgUtil.getCDNUrlWithWidth(mainUser.getPicUrl(), 200));
        return new UMImage(this, R.mipmap.ic_launcher);
    }

    private UMImage getShareImage() {
        if (backgroupUrl != null)
            return new UMImage(this, ImgUtil.getCDNUrlWithWidth(backgroupUrl, 200));
        return new UMImage(this, R.mipmap.ic_launcher);
    }

    private void showSharePopMenu(final View v) {

        if (null == profilePopupWindow) {
            profilePopupWindow = new ProfilePopupWindow(this, R.layout.popup_window_share_menu);
        }

        List<MenuVO> menuList = new ArrayList<>();

        menuList.add(MENU_ITEM_SHARE, new MenuVO(R.string.icon_share, getString(R.string.label_share), 1));
        menuList.add(MENU_ITEM_GRCODE, new MenuVO(R.string.icon_qrcode, getString(R.string.text_grcode), 1));
        if (!isMine) {
            menuList.add(MENU_ITEM_REPORT, new MenuVO(R.string.icon_jubao, getString(R.string.report), 1));
        }
        profilePopupWindow.setMenuData(menuList);

        if (profilePopupWindow.isShowing()) {
            profilePopupWindow.dismiss();
        } else {
            profilePopupWindow.showAsDropDown(v, -50, 0);
        }

        profilePopupWindow.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_SHARE: {   //分享
                        profilePopupWindow.dismiss();
                        showOrHideShareView(v);
                        break;
                    }
                    case MENU_ITEM_GRCODE: {   //二维码
                        profilePopupWindow.dismiss();
                        showQRCode();
                        break;
                    }
                    case MENU_ITEM_REPORT: {   //举报
                        profilePopupWindow.dismiss();
                        report(userId);
                    }
                }
            }
        });
    }

    //举报
    private void report(String id) {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", id);
        intent.putExtra("target", Constant.REPORT_TYPE_USER);
        startActivity(intent);
    }

    //评论输入框弹出
    private void showInputEdit() {
        publishLayout.setVisibility(View.GONE);
        commentView.setVisibility(View.VISIBLE);
        if (profileActionCommentEvent != null && profileActionCommentEvent.getNickName() != null) {
            inputEdit.setHint("@" + profileActionCommentEvent.getNickName() + ":");
        } else
            inputEdit.setHint("评论");
        inputEdit.requestFocus();
        imm.showSoftInput(inputEdit, InputMethodManager.SHOW_FORCED);
    }

    private void hideInput() {
        commentView.setVisibility(View.GONE);
        inputEdit.setText(null);
        publishLayout.setVisibility(View.VISIBLE);
        chatFaceContainer.setVisibility(View.GONE);
        imm.hideSoftInputFromWindow(inputEdit.getWindowToken(), 0);
    }

    @Override
    public boolean isShouldHideInput(View v, MotionEvent event) {
        if (v != null && (v instanceof EditText)) {
            int[] leftTop = {0, 0};
            //获取输入框当前的location位置
            v.getLocationInWindow(leftTop);
            int left = leftTop[0];
            int top = leftTop[1];
            int bottom = top + v.getHeight();
            int right = left + v.getWidth();

            int[] leftTopAnony = {0, 0};
            //获取输入框当前的location位置
            commentView.getLocationInWindow(leftTopAnony);
            int leftAnony = leftTopAnony[0];
            int topAnony = leftTopAnony[1];
            int bottomAnony = topAnony + commentView.getHeight();
            int rightAnony = leftAnony + commentView.getWidth();
            if ((event.getX() > left && event.getX() < right
                    && event.getY() > top && event.getY() < bottom)
                    || (event.getX() > leftAnony && event.getX() < rightAnony
                    && event.getY() > topAnony && event.getY() < bottomAnony)) {
                // 点击的是输入框区域，保留点击EditText的事件
                return false;
            } else {
                return true;
            }
        }
        return false;
    }


    @Override
    protected void onTouchOutOfEditText() {
        super.onTouchOutOfEditText();
        hideInput();
    }

    private void showUpdateUserInfoPop(View v) {
        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(this, 0);
        }

        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_UPDATE_USER_INFO: {
                        Router.sharedRouter().open("aboutme");
                        isRefresh = true;
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_UPDATE_BACKGROUND_IMAGE: {  //更改背景图片
                        selectPic();
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_CANCEL: {
                        mPopupListMenu.dismiss();
                        break;
                    }
                }
            }
        });

        List<MenuVO> menuList = new ArrayList<>();
        menuList.add(MENU_UPDATE_USER_INFO, new MenuVO(getString(R.string.text_update_user_info)));
        menuList.add(MENU_UPDATE_BACKGROUND_IMAGE, new MenuVO(getString(R.string.text_update_background_image)));
        menuList.add(MENU_CANCEL, new MenuVO(getString(R.string.cancel)));

        mPopupListMenu.setMenuData(menuList);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private void setTabListener(ViewGroup viewGroup) {
        for (int i = 0; i < 3; i++) {
            ViewGroup childView = (ViewGroup) viewGroup.getChildAt(i);
            if (childView == null)
                return;
            childView.setTag(i);
            childView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = (int) v.getTag();
                    if (currentTab == pos)
                        return;
                    replaceFragment(pos);
                    setCurrentTabLine(pos, tabBar);
                }
            });
        }
    }

    private void setCurrentTabLine(int pos, ViewGroup viewGroup) {
        for (int i = 0; i < 3; i++) {
            ViewGroup childView = (ViewGroup) viewGroup.getChildAt(i);
            if (childView == null)
                return;
            if (pos == i) {
                childView.getChildAt(1).setVisibility(View.VISIBLE);
            } else
                childView.getChildAt(1).setVisibility(View.GONE);
        }
    }

    private void replaceFragment(int tab) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        Bundle params = new Bundle();
        params.putString("userId", userId);
        switch (tab) {
            case 0: {
                profileActionFragment = ProfileActionFragment.newInstance(params);
                profileActionFragment.setScrollToTopEvent(this);
                fragmentTransaction.replace(R.id.fragmentContainer, profileActionFragment);
                break;
            }
            case 1: {
                ProfileCommentFragment fragment = ProfileCommentFragment.newInstance(params);
                fragment.setScrollToTopEvent(this);
                fragmentTransaction.replace(R.id.fragmentContainer, fragment);
                break;
            }
            case 2: {
                profileMeFragment = ProfileMeFragment.newInstance(params);
                profileMeFragment.setScrollToTopEvent(this);
                fragmentTransaction.replace(R.id.fragmentContainer, profileMeFragment);
                break;
            }
        }
        fragmentTransaction.commitAllowingStateLoss();
        currentTab = tab;
    }


    @Override
    public void onScrollToTop(boolean top) {
        dragLayout.setTouchMode(top);
    }
}
