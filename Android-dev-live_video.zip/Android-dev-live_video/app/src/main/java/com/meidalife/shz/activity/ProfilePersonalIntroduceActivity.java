package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.adapter.ServiceGridAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.MyGridView;
import com.meidalife.shz.widget.IntroduceCaseShowPopup;
import com.usepropeller.routable.Router;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 个人简介编辑
 * Created by liujian on 16/4/9.
 */
public class ProfilePersonalIntroduceActivity extends BaseActivity {

    private final static int TEXT_LENGTH_LIMIT = 400;

    @Bind(R.id.selectImages)
    MyGridView selectImagesGrid;
    @Bind(R.id.introductionLimit)
    TextView introductionLimit;
    @Bind(R.id.introduction)
    EditText introduction;
    @Bind(R.id.advantage)
    EditText advantage;
    @Bind(R.id.career)
    EditText career;
    @Bind(R.id.advantageLimit)
    TextView advantageLimit;
    @Bind(R.id.careerLimit)
    TextView careerLimit;
    @Bind(R.id.saveView)
    TextView saveView;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.caseShow)
    TextView caseShow;

    private int canPickPicCount;
    private ServiceGridAdapter adapter;
    private List<String> images;
    private int currentPosition = 0;
    private Map<String, String> uploadedImages = new HashMap<>();
    private boolean isUploading = false;
    private boolean isPublishing;
    private String excellentCaseUrl;
    private LoadUtil loadUtil;
    private IntroduceCaseShowPopup introduceCaseShowPopup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_personal_introduce);

        ButterKnife.bind(this);
        initActionBar(R.string.title_activity_change_personal_introduce, true);
        images = new ArrayList<String>();
        loadUtil = new LoadUtil(LayoutInflater.from(this));
        initDataView();
        initSelectImagesGrid();
        initListener();
        //获取案例图片
        publishIntroduce(false);
    }

    private void initDataView() {
        Intent intent = getIntent();
        if (intent.getStringArrayListExtra("imageList") != null) {
            for (String image : intent.getStringArrayListExtra("imageList")) {
                uploadedImages.put(image, image);
                images.add(image);
            }
        }
        if (intent.getStringExtra("introduction") != null) {
            introduction.setText(intent.getStringExtra("introduction"));
            introduction.setSelection(introduction.length());
            introductionLimit.setText("" + introduction.length());
        }
        if (intent.getStringExtra("advantage") != null) {
            advantage.setText(intent.getStringExtra("advantage"));
            advantage.setSelection(advantage.length());
            advantageLimit.setText("" + advantage.length());
        }
        if (intent.getStringExtra("career") != null) {
            career.setText(intent.getStringExtra("career"));
            career.setSelection(career.length());
            careerLimit.setText("" + career.length());
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (Activity.RESULT_OK == resultCode && requestCode == Constant.REQUEST_CODE_PICK_PHOTO) {
            Bundle bundle = data.getExtras();
            ArrayList<String> paths = bundle.getStringArrayList("images");
            if (paths != null && paths.size() > 0) {
                for (int i = 0; i < paths.size(); i++) {
                    if (currentPosition < images.size() &&
                            TextUtils.isEmpty(images.get(currentPosition))) {
                        images.set(currentPosition++, paths.get(i));
                        canPickPicCount--;
                    } else {
                        if (images.size() < Constant.MAX_IMAGE_LENGTH) {
                            images.add(paths.get(i));
                            canPickPicCount--;
                        }
                    }
                }
            }
            uploadImages();
//            if (onServicePublishListener != null) {
//                onServicePublishListener.onServiceImageSelected();
//            }
            adapter.notifyDataSetChanged();
        }
    }

    private void initListener() {
        caseShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(excellentCaseUrl != null){
                    introduceCaseShowPopup = new IntroduceCaseShowPopup(ProfilePersonalIntroduceActivity.this,excellentCaseUrl);
                    introduceCaseShowPopup.showAtLocation(v, Gravity.CENTER,0,0);
                }
            }
        });
        saveView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                publishIntroduce(true);
            }
        });

        introduction.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                introductionLimit.setText("" + s.toString().length());
                if (s.toString().trim().length() > TEXT_LENGTH_LIMIT) {
                    introductionLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    introductionLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        advantage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                advantageLimit.setText("" + s.toString().length());
                if (s.toString().trim().length() > TEXT_LENGTH_LIMIT) {
                    advantageLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    advantageLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        career.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                careerLimit.setText("" + s.toString().length());
                if (s.toString().trim().length() > TEXT_LENGTH_LIMIT) {
                    careerLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    careerLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void initSelectImagesGrid() {
        canPickPicCount = Constant.MAX_IMAGE_LENGTH - images.size();
        adapter = new ServiceGridAdapter(this, images,
                Constant.MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_SERVICE);
        adapter.setTHREE(0);
        selectImagesGrid.setAdapter(adapter);
        adapter.setOnClickListener(new ServiceGridAdapter.OnClickListener() {
            @Override
            public void onAddClick(View v, int position) {
                addImg(position);
            }

            @Override
            public void onEditClick(View v, int position) {
                currentPosition = position;
                addImg(position);
            }

            @Override
            public void onRemoveClick(View v, int position) {
                if (position < images.size()) {
                    uploadedImages.remove(images.get(position));
                    images.set(position, "");
                    canPickPicCount++;
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void publishIntroduce(final boolean update) {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        if (update) {
//            if(!checkData())
//                return;
            showProgressDialog("正在发布");
            isPublishing = true;
            if (!isUploadCompleted()) {
                uploadImages();
                return;
            }
            params.put("introduction", introduction.getText().toString());
            params.put("advantage", advantage.getText().toString());
            params.put("career", career.getText().toString());
            JSONArray imageArray = new JSONArray();
            for (String key : uploadedImages.keySet()) {
                imageArray.add(uploadedImages.get(key));
            }
            params.put("imageList", imageArray);
        }else
            loadUtil.loadPre(rootView,scrollView);
        params.put("type", update);
        HttpClient.get("1.0/user/updateMePage", params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                if (update) {
                    hideProgressDialog();
                    isPublishing = false;
                    if (obj.getBoolean("result")) {
                        setResult(RESULT_OK);
                        finish();
                    }
                } else {
                    loadUtil.loadSuccess(scrollView);
                    if (obj.containsKey("excellentCaseUrl"))
                        excellentCaseUrl = obj.getString("excellentCaseUrl");
                }
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToast(error.toString());
                if(update){
                    hideProgressDialog();
                    isPublishing = false;
                }else
                    loadUtil.loadSuccess(scrollView);
            }
        });
    }

    private boolean checkData(){
        if (images == null || images.isEmpty()) {
            MessageUtils.showToastCenter("还未上传照片哦");
            return false;
        }
        if (TextUtils.isEmpty(introduction.getText().toString())) {
            MessageUtils.showToastCenter("还未填个人简介哦");
            return false;
        }
        if (TextUtils.isEmpty(advantage.getText().toString())) {
            MessageUtils.showToastCenter("还未填服务优势哦");
            return false;
        }
        if (TextUtils.isEmpty(career.getText().toString())) {
            MessageUtils.showToastCenter("还未填职业生涯哦");
            return false;
        }

        if (introduction.getText().toString().length() > TEXT_LENGTH_LIMIT) {
            MessageUtils.showToastCenter("个人简介不得超过" + TEXT_LENGTH_LIMIT + "字哦");
            return false;
        }
        if (advantage.getText().toString().length() > TEXT_LENGTH_LIMIT) {
            MessageUtils.showToastCenter("服务优势不得超过" + TEXT_LENGTH_LIMIT + "字哦");
            return false;
        }
        if (career.getText().toString().length() > TEXT_LENGTH_LIMIT) {
            MessageUtils.showToastCenter("职业生涯不得超过" + TEXT_LENGTH_LIMIT + "字哦");
            return false;
        }
        return true;
    }

    void addImg(int position) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", canPickPicCount);
        bundle.putInt("position", position);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, this);
    }

    /**
     * 上传图片
     */
    private void uploadImages() {
        if (isUploadCompleted()) {
            return;
        }
        uploadImage(0);
    }

    /**
     * 检查是否上传完成
     *
     * @return
     */
    private boolean isUploadCompleted() {
        for (String image : images) {
            if (!TextUtils.isEmpty(image) && !uploadedImages.containsKey(image)) {
                return false;
            }
        }
        return true;
    }

    private void uploadImage(final int index) {
        if (isUploading) {
            return;
        }
        final String imagePath = images.get(index);
        if (uploadedImages.containsKey(imagePath)) {
            for (int i = 0; i < images.size(); i++) {
                if (!uploadedImages.containsKey(images.get(i))) {
                    uploadImage(i);
                    return;
                }
            }
        }
        isUploading = true;
        RequestSign.upload(imagePath, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                isUploading = false;
                try {
                    JSONObject json = (JSONObject) result;
                    uploadedImages.put(imagePath, json.getString("data"));
                    for (int i = 0; i < images.size(); i++) {
                        if (!uploadedImages.containsKey(images.get(i))) {
                            uploadImage(i);
                            break;
                        }
                    }
                    if (isUploadCompleted() && isPublishing) {
                        publishIntroduce(true);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(HttpError error) {
                isUploading = false;
                MessageUtils.showToastCenter(error != null ? "上传图片失败失败:" + error.getMessage() : "上传图片失败失败");
                hideProgressDialog();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (!hasChange()) {
            super.onBackPressed();
            return;
        }

        MessageUtils.createDialog(ProfilePersonalIntroduceActivity.this, "提醒", "真的要放弃编辑吗", R.string.confirm_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }, R.string.cancel_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        }).show();
    }

    private boolean hasChange() {
//        if(id == Integer.MAX_VALUE){
//            if(catId == Integer.MAX_VALUE
//                    && "选择定位".equals(addressText.getText().toString())
//                    && TextUtils.isEmpty(nearbyTitle.getText().toString())
//                    && TextUtils.isEmpty(nearbyContent.getText().toString())
//                    && startTime.getText().toString().equals("00:00")
//                    && endTime.getText().toString().equals("00:00")
//                    && TextUtils.isEmpty(uploadImage)
//                    && TextUtils.isEmpty(phone.getText().toString())){
//                return false;
//            }
//        }
        return true;
    }

}
