package com.meidalife.shz.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.DynamicActionListener;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.LiveActivity;
import com.meidalife.shz.activity.LivePlayerActivity;
import com.meidalife.shz.event.type.DynamicRefreshTypeEnum;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.rest.model.DynamicAdditionDO;
import com.meidalife.shz.rest.model.DynamicBottomDO;
import com.meidalife.shz.rest.model.DynamicOutDO;
import com.meidalife.shz.rest.model.DynamicRelatedServiceDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.JobDO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.CounterDownUtil;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.IconTextView;
import com.usepropeller.routable.Router;

import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zuozheng on 16/3/29.
 * 动态adapter
 */
public class DynamicAdapter extends BaseAdapter {
    private static final String LOG_TAG = "DynamicAdapter";

    int imgWidth;

    int screenWidth;

    LayoutInflater mInflater;
    Context mContext;
    LinkedList<DynamicOutDO> mData;
    boolean isPlaying = false;

    private DynamicActionListener mListener;

    public void setmListener(DynamicActionListener mListener) {
        this.mListener = mListener;
    }

    private View rootView;

    Handler handler = new Handler();
    private ChatHelper chatHelper;

    static class ViewHolder {

        @Bind(R.id.rootView)
        ViewGroup rootView;

        @Bind(R.id.userGroup)
        ViewGroup userGroup;

        @Bind(R.id.avatar)
        SimpleDraweeView avatar;
        @Bind(R.id.iconGender)
        TextView iconGender;

        @Bind(R.id.nickView)
        TextView nickView;
        @Bind(R.id.jobTitleView)
        TextView jobTitleView;
        @Bind(R.id.jobsViewGroup)
        LinearLayout jobsViewGroup;

        @Bind(R.id.additionInfoView)
        TextView additionInfoView;

        @Bind(R.id.attentionView)
        View attentionView;
        @Bind(R.id.addAttentionIcon)
        View addAttentionIcon;
        @Bind(R.id.attentionTextView)
        TextView attentionTextView;


        @Bind(R.id.cellPhotoInfo)
        ViewGroup cellPhotoInfo;
        @Bind(R.id.singleImage)
        SimpleDraweeView singleImage;
        @Bind(R.id.imageList)
        GridView imageList;

        @Bind(R.id.videoCellInfo)
        ViewGroup videoCellInfo;
        @Bind(R.id.coverImageView)
        SimpleDraweeView coverImageView;

        @Bind(R.id.videoPlayButton)
        ViewGroup videoPlayButton;

        @Bind(R.id.liveVideoGroup)
        ViewGroup liveVideoGroup;
        @Bind(R.id.videoTimeView)
        TextView videoTimeView;

        @Bind(R.id.voiceViewGroup)
        ViewGroup voiceViewGroup;
        @Bind(R.id.voicePlayButton)
        IconTextView voicePlayButton;
        @Bind(R.id.voiceTimeSpan)
        TextView voiceTimeSpan;

        @Bind(R.id.publishTimeView)
        TextView publishTimeView;
        @Bind(R.id.contentTextView)
        TextView contentTextView;

        //关联服务
        @Bind(R.id.dynamic_relate_service)
        ViewGroup dynamic_relate_service;
        @Bind(R.id.serviceImage)
        SimpleDraweeView serviceImage;
        @Bind(R.id.serviceTagView)
        TextView serviceTagView;
        @Bind(R.id.sellCountView)
        TextView sellCountView;

        //对动态的操作
        @Bind(R.id.replyIcon)
        IconTextView replyIcon;
        @Bind(R.id.supportIcon)
        IconTextView supportIcon;
        @Bind(R.id.awardIcon)
        IconTextView awardIcon;
        @Bind(R.id.awardCountView)
        TextView awardCountView;

        @Bind(R.id.moreActionView)
        View moreActionView;


        @Bind(R.id.msgListView)
        ListView msgListView;

        @Bind(R.id.moreMsgView)
        ViewGroup moreMsgView;
        @Bind(R.id.msgCountView)
        TextView msgCountView;

        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }

    public DynamicAdapter(Context context, LinkedList<DynamicOutDO> data) {
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.mData = data;
        this.mContext = context;

        chatHelper = ChatHelper.getInstance();

    }

    @Override
    public int getCount() {
        return this.mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public DynamicOutDO getItem(int position) {
        return this.mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final DynamicOutDO item = mData.get(position);

        convertView = genViewHolder(convertView, parent);
        ViewHolder holder = (ViewHolder) convertView.getTag();

        DynamicUserOutDO user = item.getUser();
        if (user != null) {
            holder.userGroup.setVisibility(View.VISIBLE);
            // 加载动态用户信息
            holder.nickView.setText(user.getUserNick());
            String gender = user.getUserGender();
            // 设置服务者性别
            if (TextUtils.isEmpty(gender)) {
                holder.iconGender.setVisibility(View.GONE);
                holder.iconGender.setText("");
            } else {
                holder.iconGender.setVisibility(View.VISIBLE);
                if (gender.equals("woman") || gender.equals("F")) {
                    holder.iconGender.setText(mContext.getResources().getString(R.string.icon_female));
                    holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.color_icon_female));
                } else {
                    holder.iconGender.setText(mContext.getResources().getString(R.string.icon_male));
                    holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.color_icon_male));
                }
            }

            ViewGroup.LayoutParams avatarParams = holder.avatar.getLayoutParams();
            if (TextUtils.isEmpty(user.getAvatarUrl())) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(user.getUserId()), gender);
                holder.avatar.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(user.getAvatarUrl(), avatarParams.width));
                holder.avatar.setImageURI(uri);
            }

            holder.jobsViewGroup.removeAllViews();
            if (CollectionUtil.isNotEmpty(user.getJobs())) {
                for (JobDO job : user.getJobs()) {
                    View jobView = mInflater.inflate(R.layout.item_dynamic_user_job, null);
                    SimpleDraweeView icon = (SimpleDraweeView) jobView.findViewById(R.id.avatar);
                    TextView titleView = (TextView) jobView.findViewById(R.id.title);
                    ViewGroup.LayoutParams iconParams = icon.getLayoutParams();

                    if (!TextUtils.isEmpty(job.getIconUrl())) {
                        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(job.getIconUrl(), iconParams.width));
                        icon.setImageURI(uri);
                        icon.setVisibility(View.VISIBLE);
                    } else {
                        icon.setImageURI(null);
                        icon.setVisibility(View.GONE);
                    }
                    titleView.setText(job.getTitle());
//        jobsView.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, context) * item.getGrade() / 5);
                    holder.jobsViewGroup.addView(jobView);
                }
                holder.jobsViewGroup.setVisibility(View.VISIBLE);
            } else {
                holder.jobsViewGroup.removeAllViews();
                holder.jobsViewGroup.setVisibility(View.GONE);
            }

            holder.jobTitleView.setText(user.getJobTitle());
            if (TextUtils.isEmpty(user.getJobTitle())) {
                holder.jobTitleView.setVisibility(View.GONE);
            } else {
                holder.jobTitleView.setVisibility(View.VISIBLE);
            }

            holder.additionInfoView.setText(String.format("%s粉丝", user.getFollowerCount()));


            //用户自己不显示关注状态
            if (Helper.sharedHelper().getUserId().equals(user.getUserId())) {
                holder.attentionView.setVisibility(View.GONE);

                holder.awardIcon.setVisibility(View.GONE);
                holder.awardCountView.setVisibility(View.GONE);
            } else {
                holder.attentionView.setVisibility(View.VISIBLE);
                if (user.isFocused()) {
                    holder.attentionTextView.setText("已关注");
                    holder.attentionTextView.setTextColor(mContext.getResources().getColor(R.color.grey_j));
                    holder.addAttentionIcon.setVisibility(View.GONE);
                    holder.attentionView.setBackgroundResource(R.drawable.bg_rect_grey_border);
                } else {
                    holder.attentionTextView.setText("关注");
                    holder.attentionTextView.setTextColor(mContext.getResources().getColor(R.color.brand_c));
                    holder.addAttentionIcon.setVisibility(View.VISIBLE);
                    holder.attentionView.setBackgroundResource(R.drawable.bg_rect_black_border);
                }

                holder.awardIcon.setVisibility(View.VISIBLE);
                holder.awardCountView.setVisibility(View.VISIBLE);
            }

        } else {
            holder.userGroup.setVisibility(View.GONE);
        }

        //需要优化
        if (item.getCreateTime() > 0) {
            holder.publishTimeView.setText(DateUtils.getOffsetDays(System.currentTimeMillis(), item.getCreateTime()));
            holder.publishTimeView.setVisibility(View.VISIBLE);
        } else {
            holder.publishTimeView.setText("");
            holder.publishTimeView.setVisibility(View.VISIBLE);
        }

        holder.contentTextView.setText(chatHelper.getExpressionSpanText(item.getContent(), 20));
        if (TextUtils.isEmpty(item.getContent())) {
            holder.contentTextView.setVisibility(View.GONE);
        } else {
            holder.contentTextView.setVisibility(View.VISIBLE);
        }

        DynamicAdditionDO addInfo = item.getAdditionalInfo();
        if (addInfo != null) {
            //type : //0 图片，1 直播， 2 视频 ， 3 音频
            switch (addInfo.getPublishType()) {
                case "0":
                    holder.cellPhotoInfo.setVisibility(View.VISIBLE);
                    holder.voiceViewGroup.setVisibility(View.GONE);
                    holder.voiceTimeSpan.setText("");
                    holder.videoCellInfo.setVisibility(View.GONE);
                    holder.coverImageView.setImageURI(null);
                    holder.videoTimeView.setText("");

                    List<String> images = new LinkedList<>();
                    if (addInfo != null && CollectionUtil.isNotEmpty(addInfo.getImageUrls())) {
                        images.addAll(addInfo.getImageUrls());
                    }
                    if (CollectionUtil.isEmpty(images)) {
                        holder.singleImage.setVisibility(View.GONE);
                        holder.imageList.setVisibility(View.GONE);
                    } else {
                        boolean isSingle = images.size() == 1 ? true : false;
                        if (isSingle) {
//                    ViewGroup.LayoutParams layoutParams = holder.singleImage.getLayoutParams();
                            Uri itemUri = Uri.parse(ImgUtil.getCDNUrlWithHeight(images.get(0), screenWidth));
                            holder.singleImage.setImageURI(itemUri);

                            holder.imageList.setVisibility(View.GONE);
                            holder.singleImage.setVisibility(View.VISIBLE);
                        } else {
                            int endIndex = Math.min(DynamicImagesAdapter.MAX_IMG, images.size());
                            images = images.subList(0, endIndex);

                            holder.imageList.setAdapter(new DynamicImagesAdapter(mContext, images, imgWidth));

                            holder.singleImage.setVisibility(View.GONE);
                            holder.imageList.setVisibility(View.VISIBLE);
                        }
                    }
                    break;
                case "1":
                    holder.cellPhotoInfo.setVisibility(View.GONE);
                    holder.voiceViewGroup.setVisibility(View.VISIBLE);
                    holder.voiceTimeSpan.setText(DateUtils.countdownTimer(addInfo.getAudioLength()));
                    holder.videoCellInfo.setVisibility(View.GONE);
                    holder.coverImageView.setImageURI(null);
                    holder.videoTimeView.setText("");
                    break;
                case "2":
                    holder.cellPhotoInfo.setVisibility(View.GONE);
                    holder.voiceViewGroup.setVisibility(View.GONE);
                    holder.voiceTimeSpan.setText("");
                    holder.videoCellInfo.setVisibility(View.VISIBLE);
                    holder.liveVideoGroup.setVisibility(View.VISIBLE);
                    holder.videoPlayButton.setVisibility(View.GONE);

                    if (TextUtils.isEmpty(addInfo.getVideoPic())) {
                        holder.coverImageView.setImageURI(null);
                        holder.coverImageView.setVisibility(View.GONE);
                    } else {
                        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithHeight(addInfo.getVideoPic(), holder.coverImageView.getHeight()));
                        holder.coverImageView.setImageURI(uri);
                        holder.coverImageView.setVisibility(View.VISIBLE);
                    }

                    //转化成十分秒
                    holder.videoTimeView.setText(addInfo.getStartTime());
                    break;
                case "3":
                    holder.cellPhotoInfo.setVisibility(View.GONE);
                    holder.voiceViewGroup.setVisibility(View.GONE);
                    holder.voiceTimeSpan.setText("");
                    holder.videoCellInfo.setVisibility(View.VISIBLE);
                    holder.liveVideoGroup.setVisibility(View.GONE);
                    holder.videoPlayButton.setVisibility(View.VISIBLE);
                    holder.videoTimeView.setText("");
                    if (TextUtils.isEmpty(addInfo.getVideoPic())) {
                        holder.coverImageView.setImageURI(null);
                        holder.coverImageView.setVisibility(View.GONE);
                    } else {
                        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(addInfo.getVideoPic(), screenWidth));
                        holder.coverImageView.setImageURI(uri);
                        holder.coverImageView.setVisibility(View.VISIBLE);
                    }
                    break;
                default:
                    holder.cellPhotoInfo.setVisibility(View.GONE);
                    holder.voiceViewGroup.setVisibility(View.GONE);
                    holder.voiceTimeSpan.setText("");
                    holder.videoCellInfo.setVisibility(View.GONE);
                    holder.liveVideoGroup.setVisibility(View.GONE);
                    holder.videoPlayButton.setVisibility(View.GONE);
                    holder.coverImageView.setImageURI(null);
                    holder.videoTimeView.setText("");
            }
        } else {
            holder.cellPhotoInfo.setVisibility(View.GONE);
            holder.voiceViewGroup.setVisibility(View.GONE);
            holder.voiceTimeSpan.setText("");
            holder.videoCellInfo.setVisibility(View.GONE);
            holder.liveVideoGroup.setVisibility(View.GONE);
            holder.videoPlayButton.setVisibility(View.GONE);
            holder.coverImageView.setImageURI(null);
            holder.videoTimeView.setText("");
        }

        DynamicRelatedServiceDO service = item.getLinkedService();

        if (service != null) {
            holder.dynamic_relate_service.setVisibility(View.VISIBLE);
            ViewGroup.LayoutParams serviceImageParams = holder.serviceImage.getLayoutParams();
            if (!TextUtils.isEmpty(service.getFeedIconUrl())) {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(service.getFeedIconUrl(), serviceImageParams.width));
                holder.serviceImage.setImageURI(uri);
            } else {
                holder.serviceImage.setImageURI(null);
            }
            holder.serviceTagView.setText(service.getItemTitle());
            holder.sellCountView.setText(String.format("%s人约单", service.getSellCount()));
        } else {
            holder.serviceImage.setImageURI(null);
            holder.serviceTagView.setText("");
            holder.sellCountView.setText("");
            holder.dynamic_relate_service.setVisibility(View.GONE);
        }

//        renderFocus(item, holder.rootView);

        //留言
        replyCountView(item, holder.rootView);

        //赞或者取消赞
        toggleIsSupport(item, holder.rootView);

        //打赏
        toggleAward(item, holder.rootView);

        //显示留言
        showCommentListView(item.getComments(), holder.rootView);

        if (CollectionUtil.isEmpty(item.getComments()) || item.getComments().size() <= 4) {
            holder.moreMsgView.setVisibility(View.GONE);
            holder.msgCountView.setText("");
        } else {
            holder.moreMsgView.setVisibility(View.VISIBLE);
            holder.msgCountView.setText(String.format("全部留言(%s)", item.getComments().size()));
        }

        initListener(convertView, position, item, holder);

        return convertView;
    }

    private void initListener(View convertView, final int position, final DynamicOutDO item, final ViewHolder holder) {

        holder.rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + item.getUser().getUserId());
            }
        });

        holder.avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + item.getUser().getUserId());
            }
        });

        holder.attentionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //注册 监听事件 如果点击关注按钮 发起关注请求并添加关注
                if (!item.getUser().isFocused()) {
                    holder.attentionTextView.setText("已关注");
                    holder.attentionTextView.setTextColor(mContext.getResources().getColor(R.color.grey_j));
                    holder.addAttentionIcon.setVisibility(View.GONE);
                    holder.attentionView.setBackgroundResource(R.drawable.bg_rect_grey_border);

                    mListener.onAddAttentionClick(item.getUser().getUserId());

                }
            }
        });

        holder.imageList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                //进入动态详情
                Bundle bundle = new Bundle();
                bundle.putStringArrayList("photos", item.getAdditionalInfo().getImageUrls());
                bundle.putInt("index", pos);
                Router.sharedRouter().open("imageBrowser", bundle);
            }
        });
        holder.singleImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putStringArrayList("photos", item.getAdditionalInfo().getImageUrls());
                bundle.putInt("index", 0);
                Router.sharedRouter().open("imageBrowser", bundle);
            }
        });

        holder.videoCellInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //进入直播
                DynamicAdditionDO addInfo = item.getAdditionalInfo();
                if (addInfo != null) {
                    if (addInfo.getPublishType().equals("2")) {
                        Intent intent = new Intent(mContext, LiveActivity.class);
                        intent.putExtra("liveId", addInfo.getVideoId());
                        mContext.startActivity(intent);
                    } else if (addInfo.getPublishType().equals("3")) {
                        Intent intent = new Intent(mContext, LivePlayerActivity.class);
                        intent.putExtra("channelId", addInfo.getVideoId());
                        mContext.startActivity(intent);
                    }
                }
            }
        });

        holder.voiceViewGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CounterDownUtil counterDown = new CounterDownUtil(mContext, item.getAdditionalInfo().getAudioLength() * 1000, 1000, holder.voicePlayButton, holder.voiceTimeSpan);
                if (isPlaying) {
                    holder.voicePlayButton.setText(mContext.getResources().getString(R.string.icon_play));
                    mListener.stopPlayClick(position, item);
                    counterDown.onFinish();
                } else {
                    holder.voicePlayButton.setText(mContext.getResources().getString(R.string.icon_pause));
                    mListener.startPlayClick(position, item);
                    counterDown.start();
                }

                isPlaying = !isPlaying;
            }
        });

        holder.dynamic_relate_service.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("dynamic/" + item.getFeedId());
            }
        });

        holder.replyIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //对当前动态留言
                rootView = v.getRootView();
                mListener.onCommentClick(position, item);
            }
        });

        //回复单个留言
        holder.msgListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int pos, long id) {
                //回复留言 请求接口 成功刷新当前留言list 不重新请求数据
                rootView = v.getRootView();
                if (CollectionUtil.isNotEmpty(item.getComments()) && pos < item.getComments().size()) {
                    DynamicBottomDO comment = item.getComments().get(pos);
                    mListener.onCommentListItemClick(position, item, comment);
                }
            }
        });

        holder.supportIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //对当前点赞或者取消
                rootView = v.getRootView();
                if (item.isSupported()) {
                    item.setIsSupported(false);
                    item.setSupportCount(item.getSupportCount() - 1);
                } else {
                    item.setIsSupported(true);
                    item.setSupportCount(item.getSupportCount() + 1);
                }
                toggleIsSupport(item, holder.rootView);
                mListener.onSupportClick(position, item);
            }
        });

        holder.awardIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //对当前动态打赏
                rootView = v.getRootView();
                mListener.onRewardClick(position, item);
            }
        });

        holder.moreActionView.setOnClickListener(new AdapterView.OnClickListener() {
            @Override
            public void onClick(View v) {
                //显示popup window
                mListener.onMoreActionClick(position, item, holder.moreActionView);
            }
        });


        View.OnClickListener itemClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //进入动态详情
                Router.sharedRouter().open("dynamic/" + item.getFeedId());
            }
        };

        convertView.setOnClickListener(itemClickListener);
    }


    private View genViewHolder(View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_dynamic, parent, false);
            holder = new ViewHolder(convertView);

            // 计算多图每栏宽度
            Activity activity = (Activity) mContext;
            Display display = activity.getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);
            screenWidth = size.x;
//            float margin = Helper.convertDpToPixel(77, mContext);
            float spacing = Helper.convertDpToPixel(5, mContext);
//            float padding = Helper.convertDpToPixel(8, mContext);
            // width -= margin * 2;
//            screenWidth -= margin;
//            screenWidth -= spacing * 2;
//            screenWidth -= padding * 2;
            imgWidth = (int) (screenWidth - spacing * 2) / 3;
            holder.imageList.setColumnWidth(imgWidth);


            //设置单张图片的高度为整个屏幕的宽度
//            holder.imageSingleViewGroup.

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            if (holder == null) {
                return genViewHolder(null, parent);
            }
        }

        return convertView;
    }

    /**
     * Interface definition for a callback to be invoked when a view is clicked.
     */
    public interface OnClickListener {
        /**
         * Called when a view has been clicked.
         *
         * @param v        The view that was clicked.
         * @param position The item position.
         */
        void onClick(View v, int position, String itemId);

    }

    //需要区别刷新留言 点赞 还有打赏,暂时不区分更新事件类型
    public void updateItemData(final DynamicOutDO item, final DynamicRefreshTypeEnum refreshTypeEnum) {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateItem(item, rootView, refreshTypeEnum);
            }
        }, 50);
    }

    private void updateItem(DynamicOutDO item, View view, DynamicRefreshTypeEnum refreshTypeEnum) {
        switch (refreshTypeEnum) {
//            case TYPE_FOLLOW:
//                //关注或者取消关注
//                renderFocus(item, view);
//                break;
//            case TYPE_SUPPORT:
//                //赞或者取消赞
//                toggleIsSupport(item, view);
//                break;
            case TYPE_REWARD:
                //打赏
                toggleAward(item, view);
                break;
            case TYPE_COMMENT:
                // 留言或者回复留言
                showCommentListView(item.getComments(), view);
                //留言
                replyCountView(item, view);
                break;
            default:
                break;
        }
    }

//    private void renderFocus(DynamicOutDO item, View v) {
//        if (item == null || v == null) {
//            return;
//        }
//
//        ViewGroup unFocusViewGroup = (ViewGroup) v.findViewById(R.id.unFocusView);
//        TextView focusedView = (TextView) v.findViewById(R.id.focusedView);
//
//        if ((item != null && item.getUser() != null && item.getUser().isFocused())) {
//            unFocusViewGroup.setVisibility(View.GONE);
//            focusedView.setVisibility(View.VISIBLE);
//        } else {
//            unFocusViewGroup.setVisibility(View.VISIBLE);
//            focusedView.setVisibility(View.GONE);
//        }
//    }

    private void replyCountView(DynamicOutDO item, View v) {
        if (item == null || v == null) {
            return;
        }

        TextView label = (TextView) v.findViewById(R.id.replayCountView);

        if (item.getReplyCount() > 0) {
            label.setVisibility(View.VISIBLE);
        } else {
            label.setVisibility(View.GONE);
        }
        label.setText(String.valueOf(item.getReplyCount()));
    }

    private void toggleIsSupport(DynamicOutDO item, View v) {
        if (item == null || v == null) {
            return;
        }

        TextView icon = (TextView) v.findViewById(R.id.supportIcon);
        TextView label = (TextView) v.findViewById(R.id.supportCountView);

        if (item.isSupported()) {
            icon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
        } else {
            icon.setTextColor(mContext.getResources().getColor(R.color.grey_j));
        }

        if (item.getSupportCount() > 0) {
            label.setVisibility(View.VISIBLE);
            label.setText(String.valueOf(item.getSupportCount()));
        } else {
            label.setVisibility(View.GONE);
        }
    }

    private void toggleAward(DynamicOutDO item, View v) {
        if (item == null || v == null) {
            return;
        }

        TextView label = (TextView) v.findViewById(R.id.awardCountView);

        if (item.getBonusCount() > 0 && !Helper.sharedHelper().getUserId().equals(item.getUser().getUserId())) {
            label.setVisibility(View.VISIBLE);
        } else {
            label.setVisibility(View.GONE);
        }
        label.setText(String.valueOf(item.getBonusCount()));
    }

    void showCommentListView(List<DynamicBottomDO> dataList, View v) {
        if (v == null) {
            return;
        }

        ListView viewGroup = (ListView) v.findViewById(R.id.msgListView);

        if (CollectionUtil.isEmpty(dataList)) {
            viewGroup.setVisibility(View.GONE);
        } else {
            int end = Math.min(4, dataList.size());
            dataList = dataList.subList(0, end);
            viewGroup.setAdapter(new DynamicCommentAdapter(mContext, dataList));
            viewGroup.setVisibility(View.VISIBLE);
        }
    }
}
