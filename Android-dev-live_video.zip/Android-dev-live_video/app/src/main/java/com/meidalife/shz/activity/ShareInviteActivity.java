package com.meidalife.shz.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.request.RequestContacts;
import com.meidalife.shz.util.ShareActivity;
import com.usepropeller.routable.Router;

/**
 * Created by shijian on 15/7/16.
 */
public class ShareInviteActivity extends BaseActivity {

    private String code = null;
    private String point = null;
    private String nick = null;

    private TextView pointValue;
    private TextView shareCode;
    private TextView pointTitle;

    private ViewGroup rootView;
    private View contentRoot;

    public ShareActivity shareActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.earn_mcoin_share);
        initActionBar(R.string.title_share_invite_code, true);

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);

        pointValue = (TextView) findViewById(R.id.share_invite_point_value);
        shareCode = (TextView) findViewById(R.id.share_code);
        pointTitle = (TextView) findViewById(R.id.share_invite_point_title);

        nick = Helper.sharedHelper().getStringUserInfo("nick");

        View wxChat = findViewById(R.id.share_wx_chat);
        wxChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareActivity.shareInviteWithWxChat(ShareInviteActivity.this, code, nick);
            }
        });

        View wxCircle = findViewById(R.id.share_wx_circle);
        wxCircle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareActivity.shareInviteWithWxCircle(ShareInviteActivity.this, code, nick);
            }
        });

        View wbView = findViewById(R.id.share_weibo);
        wbView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareActivity.shareInviteWithWeibo(ShareInviteActivity.this, code, nick);
            }
        });

        View qqView = findViewById(R.id.share_qq);
        qqView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareActivity.shareInviteWithQQ(ShareInviteActivity.this, code, nick);
            }
        });

        View mcoinIntro = findViewById(R.id.mcoin_intro);
        mcoinIntro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", Constant.URL_MBILL_RULE);
                Router.sharedRouter().open("web", bundle);
            }
        });

        initLoadData();

        shareActivity = new ShareActivity(this);
    }

    public void initLoadData() {
        loadPre(rootView, contentRoot);
        RequestContacts.share(new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                try {
                    loadSuccess(contentRoot);
//                    JSONObject obj = (JSONObject) result;
//                    JSONObject data = obj.getJSONObject("data");
                    if (result.containsKey("invitationCode")) {
                        code = result.getString("invitationCode");
                    }
                    if (result.containsKey("inviteRegisterPoint")) {
                        point = result.getString("inviteRegisterPoint");
                    }
                    shareCode.setText(code);
                    pointValue.setText(point + "个");
                    if (result.containsKey("invitationInfo")) {
                        pointTitle.setText(result.getString("invitationInfo"));
                    }
                } catch (Exception e) {
                    Log.e(ShareInviteActivity.class.getName(), "unknown exception", e);
                    loadFail(new HttpError(HttpError.ERR_CODE_UNKNOWN,
                            getResources().getString(R.string.error_server_500)), rootView, ShareInviteActivity.this, new LoadCallback() {
                        @Override
                        public void execute() {
                            initLoadData();
                        }
                    });
                }
            }

            @Override
            public void onFail(HttpError error) {
                loadFail(error, rootView, ShareInviteActivity.this, new LoadCallback() {
                    @Override
                    public void execute() {
                        initLoadData();
                    }
                });
            }
        });
    }

}
