package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.DynamicBindServiceAdapter;
import com.meidalife.shz.event.DynamicBindServiceEvent;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.OrderTabTypeOutDO;
import com.meidalife.shz.rest.model.Service4DynamicDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.LoadUtil;

import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by zuozheng on 16/04/06.
 */
public class DynamicBindMyPubServiceFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private static final String TAG_TITLE = "title";
    private Boolean isLoading = false;
    private boolean loadComplete = false;

    private int page = 1;
    private static final int PAGE_SIZE = 10;

    private List<Service4DynamicDO> mList = new LinkedList<>();
    private View rootView;

    private DynamicBindServiceAdapter serviceListAdapter;
    private LoadUtil mLoadUtil;

    @Bind(R.id.emptyView)
    View emptyView;
    @Bind(R.id.emptyTextView)
    TextView emptyTextView;
    @Bind(R.id.orderList)
    ListView orderListView;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;

    Service4DynamicDO clickedItem;

    public static DynamicBindMyPubServiceFragment newInstance(String fragTitle) {
        DynamicBindMyPubServiceFragment orderListFragment = new DynamicBindMyPubServiceFragment();

        Bundle params = new Bundle();
        params.putString(TAG_TITLE, fragTitle);
        orderListFragment.setArguments(params);

        return orderListFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_order_list, null);
            ButterKnife.bind(this, rootView);

            //listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
            mLoadUtil = new LoadUtil(inflater);

            orderListView.setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                        if (view.getLastVisiblePosition() == view.getCount() - 1) {
                            loadData(false);
                        }
                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem,
                                     int visibleItemCount, int totalItemCount) {
                }
            });

            orderListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    //todo 需要实现反选 如果是选中状态 点击之后为非选中状态；如果是非选中状态,点击之后为选中状态
                    clickedItem = mList.get(position);
                    for (Service4DynamicDO item : mList) {
                        if (item.getItemId().equals(clickedItem.getItemId())) {
                            //实现反选
                            if (item.isSelected()) {
                                item.setSelected(false);
                            } else {
                                item.setSelected(true);
                            }
                            DynamicBindServiceEvent updateItemEvent = new DynamicBindServiceEvent();
                            updateItemEvent.selected = item.isSelected();
                            EventBus.getDefault().post(updateItemEvent);
                        } else {
                            item.setSelected(false);
                        }
                    }
                    serviceListAdapter.notifyDataSetChanged();
                }
            });

            swipeRefreshLayout.setOnRefreshListener(this);
            serviceListAdapter = new DynamicBindServiceAdapter(getActivity(), mList);
//            orderListAdapter.setOnOrderChangeLister(this);
            orderListView.setAdapter(serviceListAdapter);
        }
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // loadData(true);
    }

    @Override
    public void onResume() {
        // updateOrder();
        loadData(true);
        super.onResume();
    }

    @Override
    public void onDestroyView() {
        try {
            try {
                ViewGroup parent = (ViewGroup) rootView.getParent();
                if (parent != null) {
                    parent.removeView(rootView);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    public void loadData(final boolean reload) {
        if (isLoading) {
            return;
        }
        isLoading = true;

        if (reload) {
            page = 1;
            mList.clear();
            loadComplete = false;
        }

        if (loadComplete) {
            return;
        }

        mLoadUtil.loadPre((ViewGroup) rootView, swipeRefreshLayout);


        RequestDynamic.myServiceList(page, PAGE_SIZE, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                mLoadUtil.hideStatusLoading();
                if (getActivity() == null) {
                    return;
                }

                List<Service4DynamicDO> tmpList = null;
                if (result != null) {
                    tmpList = JSON.parseArray(result.getString("itemSell"), Service4DynamicDO.class);
                }

                if (CollectionUtil.isEmpty(tmpList) || tmpList.size() < PAGE_SIZE) {
                    loadComplete = true;
                }

                if (CollectionUtil.isNotEmpty(tmpList)) {
                    mList.addAll(tmpList);
                }

                if (CollectionUtil.isEmpty(mList)) {
                    swipeRefreshLayout.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                    emptyTextView.setText("快去发布服务吧~");
                } else {
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                    serviceListAdapter.notifyDataSetChanged();
                    page++;
                }
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                mLoadUtil.loadFail(error, (ViewGroup) rootView, getActivity(), new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        loadData(true);
                    }
                });
            }
        });
    }

    @Override
    public void onRefresh() {
        loadData(true);
    }

    public interface OnDataChangeListener {
        void onDataChange(List<OrderTabTypeOutDO> orderTabTypeDOList);
    }

    public Service4DynamicDO getClickedItem() {
        return clickedItem;
    }
}
