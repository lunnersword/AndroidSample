package com.meidalife.shz.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpClient.HttpCallback;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.model.BuyerVO;
import com.meidalife.shz.rest.model.ItemVO;
import com.meidalife.shz.rest.model.OrderCartVO;
import com.meidalife.shz.rest.model.OrderVO;
import com.meidalife.shz.rest.model.PreOrderFormVO;
import com.meidalife.shz.rest.model.SellerVO;
import com.meidalife.shz.rest.model.SkuOutDO;
import com.meidalife.shz.rest.model.TimeVO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.SelectTimeUtil;
import com.usepropeller.routable.Router;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 下单页
 */

public class OrderActivity extends BaseActivity {

    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.rootView)
    LinearLayout rootView;

    @Bind(R.id.cellToolBar)
    RelativeLayout cellToolBar;

    @Bind(R.id.redPaperTips)
    TextView redPaperTips;
    @Bind(R.id.tipSelectTimeView)
    TextView tipSelectTimeView;


    @Bind(R.id.sellerInfoView)
    View sellerInfoView;
    @Bind(R.id.sellerImageAvatar)
    SimpleDraweeView sellerImageAvatar;
    @Bind(R.id.textSellerName)
    TextView textSellerName;

    @Bind(R.id.textSellerAddress)
    TextView textSellerAddress;
    @Bind(R.id.cellSellerAddress)
    RelativeLayout cellSellerAddress;


    @Bind(R.id.itemImageView)
    SimpleDraweeView itemImageView;
    @Bind(R.id.textItemTagView)
    TextView textItemTagView;
    @Bind(R.id.itemServiceTypeView)
    TextView itemServiceTypeView;
    @Bind(R.id.isMcoinView)
    TextView isMcoinView;

    //库存
    @Bind(R.id.itemStockTV)
    TextView itemStockTV;
    //
//    //正常价格view
    @Bind(R.id.servicePriceViewGroup)
    View servicePriceViewGroup;

    @Bind(R.id.priceView)
    TextView priceView;
    @Bind(R.id.oriPriceView)
    TextView oriPriceView;

    //预定价格view
    @Bind(R.id.earnestViewGroup)
    View earnestViewGroup;
    @Bind(R.id.earnestValue)
    TextView earnestValue;
    @Bind(R.id.finalPayAmountView)
    TextView finalPayAmountView;


    @Bind(R.id.cellServiceTime)
    RelativeLayout cellServiceTime;


    // 针对格子服务 需要修改标题
    @Bind(R.id.itemCountTitle)
    TextView itemCountTitle;
    //活动促销限购标
    @Bind(R.id.itmCountDesc)
    TextView itmCountDesc;

    //减少商品数量
    @Bind(R.id.decItemCount)
    View decItemCount;
    //
    @Bind(R.id.itemCountOprView)
    EditText itemCountOprView;
    //增加商品数量
    @Bind(R.id.addItemCount)
    TextView addItemCount;


    @Bind(R.id.itemCountView)
    TextView itemCountView;

    //地址信息
    @Bind(R.id.textAddressAndUserInfo)
    RelativeLayout textAddressAndUserInfo;

    @Bind(R.id.textAddressTitle)
    View textAddressTitle;
    //提示选择地址
    @Bind(R.id.tipSelectAddressView)
    TextView tipSelectAddressView;
    //选择地址
    @Bind(R.id.cellBuyerAddressView)
    LinearLayout cellBuyerAddressView;
    @Bind(R.id.textContactInfoView)
    TextView textContactInfoView;
    @Bind(R.id.textAddressView)
    TextView textAddressView;

    //联系人
    @Bind(R.id.contactNameView)
    View contactNameView;
    @Bind(R.id.userNameView)
    EditText userNameView;
    //联系电话
    @Bind(R.id.contactPhoneView)
    View contactPhoneView;
    @Bind(R.id.userPhoneView)
    EditText userPhoneView;

    @Bind(R.id.textMessage)
    TextView textMessage;

    // 格子宝贝 修改销保文案
    @Bind(R.id.cellProtectionInfo)
    LinearLayout cellProtectionInfo;
    @Bind(R.id.textProtectionInfo)
    TextView textProtectionInfo;

    @Bind(R.id.totalPriceTitle)
    TextView totalPriceTitle;
    @Bind(R.id.totalPriceView)
    TextView totalPriceView;
    @Bind(R.id.btnBuy)
    Button btnBuy;

    @Bind(R.id.cellItemCount)
    View cellItemCount;


    String itemId;
    long snapshotItemId;
    String itemTitle;

    Boolean loadComplete;
    Boolean loadOrder;
    Boolean loadPay;
    List<TimeVO> timeList;
    String geziId;
    PreOrderFormVO preOrderFormVO;
    int bookDateIndex;
    int bookHourIndex;
    int bookHourIndexRelativeDateIndex;

    private int lastSelectIndex = -1;

    //商品最少可以购买数量
    private int buyDownLimit = 1;

    private int currentItemCount = 1;

    private String price;//价格 单位是元
    private Long promotionId;//促销id

    NumberFormat formatter = new DecimalFormat("#0.00");
    AddressItem addressItem = new AddressItem();

    boolean isShowSelectTime = false;
    boolean isShowSelectQuantity = false;
    boolean isShowSelectAddress = false;
    boolean isShowContactUserName = false;
    boolean isShowContactUserPhone = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        initActionBar(R.string.title_activity_order, true);
        ButterKnife.bind(this);

        itemId = null;

        loadComplete = false;
        loadOrder = false;
        loadPay = false;
        bookDateIndex = 0;
        bookHourIndex = -1;
        bookHourIndexRelativeDateIndex = -1;

        Bundle intentExtras = getIntent().getExtras();
        itemId = intentExtras != null ? intentExtras.getString("id") : null;
        geziId = intentExtras.getString(Constant.EXTRA_TAG_SQUARE_ID);
        preOrderFormVO = (PreOrderFormVO) intentExtras.getSerializable("preOrderFormVO");

        hideIMM();

        initClickEvent();

        xhrOrderForm();
    }


    void initClickEvent() {
        textMessage.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
                    return true;
                }
                return false;
            }
        });
        addItemCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (buyLimit > 0 && currentItemCount >= buyLimit) {
//                    MessageUtils.showToast("每人限购" + buyLimit + "件");
//                    return;
//                }
//
//                if (itemStock > 0 && currentItemCount >= itemStock) {
//                    MessageUtils.showToast("库存不足");
//                    return;
//                }
                currentItemCount++;
                //重新计算总价
//                xhrOrderForm();
                updateTotalPrice();
            }
        });

        decItemCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentItemCount <= buyDownLimit) {
                    MessageUtils.showToast(String.format("最少购买%s件", buyDownLimit));
                    return;
                }
                currentItemCount--;
                //重新计算总价
                updateTotalPrice();
            }
        });

        itemCountOprView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    currentItemCount = Integer.parseInt(s.toString());

                    double totalPrice = 0;
                    try {
                        double itemPrice = Double.valueOf(price);
                        totalPrice = itemPrice * currentItemCount;
                    } catch (Exception e) {

                    }
                    totalPriceView.setText(formatter.format(totalPrice) + "元");

                    itemCountView.setText("x" + currentItemCount);
                } catch (Exception e) {

                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if ((requestCode == Constant.REQUEST_CODE_PICK_ADDRESS && resultCode == RESULT_OK)
                || (requestCode == Constant.REQUEST_CODE_CHANGE_ADDRESS && resultCode == RESULT_OK)) {
            if (data != null && data.getExtras() != null) {
                Bundle bundle = data.getExtras();
                addressItem = (AddressItem) bundle.getSerializable(Constant.EXTRA_TAG_ADDRESS);
                if (null != addressItem) {
                    renderAddressInfo(addressItem.getAddressName(), addressItem.getContactorPhone(),
                            addressItem.getContactorName());
                }
                lastSelectIndex = bundle.getInt("lastSelectIndex");
            }
        } else if (requestCode == Constant.REQUEST_CODE_PICK_ADDRESS && resultCode == RESULT_CANCELED) {
            Bundle bundle = data.getExtras();
            if (bundle != null) {
                lastSelectIndex = bundle.getInt("lastSelectIndex");
            }
        }
    }


    private void xhrOrderForm() {
        cellToolBar.setVisibility(View.GONE);
        scrollView.setVisibility(View.GONE);
        hideStatusErrorNetwork();
        hideStatusErrorServer();
        showStatusLoading(rootView);

        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        if (preOrderFormVO != null) {
            params.put("itemId", preOrderFormVO.getItemId());
            params.put("itemCount", preOrderFormVO.getItemCount());
            params.put("itemSkuId", preOrderFormVO.getItemSkuId());
            params.put("bookTime", preOrderFormVO.getBookTime());
            params.put("addressId", preOrderFormVO.getAddressId());
            params.put("contactName", preOrderFormVO.getContactorName());
            params.put("contactPhone", preOrderFormVO.getContactorPhone());
        } else {
            params.put("itemId", itemId);
        }

        //只有派单需要回传格子id
        if (!TextUtils.isEmpty(geziId)) {
            params.put("geziId", geziId);
        }

        HttpClient.get("1.1/buyerOrder/orderForm", params, OrderCartVO.class, new HttpCallback<OrderCartVO>() {
            @Override
            public void onSuccess(OrderCartVO result) {
                cellToolBar.setVisibility(View.VISIBLE);
                scrollView.setVisibility(View.VISIBLE);
                hideStatusLoading();

                if (result == null || CollectionUtil.isEmpty(result.getOrderList())) {
                    return;
                }

                updateView(result);
            }

            @Override
            public void onFail(HttpError error) {
                xhrFailure(error);
            }
        });
    }

    void updateView(OrderCartVO result) {
        if (!TextUtils.isEmpty(result.getRedpackTip())) {
            redPaperTips.setText(result.getRedpackTip());
            redPaperTips.setVisibility(View.VISIBLE);
        }

        //购物车版本需改造成listview结构 待确定数据结构是否发生改变
        OrderVO orderVO = result.getOrderList().get(0);

        boolean isPaidan = orderVO.getPaidan();

        // 卖家信息
        SellerVO sellerVO = orderVO.getSeller();
        if (!isPaidan && sellerVO != null) {
            //卖家nick
            if (!TextUtils.isEmpty(sellerVO.getUserNick())) {
                textSellerName.setText(sellerVO.getUserNick());
                sellerInfoView.setVisibility(View.VISIBLE);

                if (!TextUtils.isEmpty(sellerVO.getAvatar())) {
                    String picUrl = ImgUtil.getCDNUrlWithWidth(sellerVO.getAvatar(), sellerImageAvatar.getLayoutParams().width);
                    sellerImageAvatar.setImageURI(Uri.parse(picUrl));
                } else {
                    String userId = sellerVO.getUserId();
                    String gender = sellerVO.getUserGender();
                    if (userId != null && gender != null) {
                        Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(OrderActivity.this, userId, gender);
                        sellerImageAvatar.setImageURI(getDefaultAvatarUri);
                    }
                }
            }

            //卖家地址
            if (!TextUtils.isEmpty(sellerVO.getAddressName())) {
                textSellerAddress.setText(sellerVO.getAddressName());
                cellSellerAddress.setVisibility(View.VISIBLE);
            }
        }

        if (CollectionUtil.isNotEmpty(orderVO.getItemList())) {
            ItemVO itemVO = orderVO.getItemList().get(0);

            if (itemVO != null) {
                renderItem(itemVO);

                if (isPaidan) {
                    itemCountTitle.setText(itemVO.getQuantityPrefix());
                }

                //增加限购数量解析逻辑
                if (itemVO.getBuyLimit() > 0) {
                    itmCountDesc.setText(String.format("(每人限购%s件)", itemVO.getBuyLimit()));
                    itmCountDesc.setVisibility(View.VISIBLE);
                }

                //设置数量
                currentItemCount = itemVO.getCount() > 0 ? itemVO.getCount() : 1;
                if (currentItemCount < buyDownLimit) {
                    currentItemCount = buyDownLimit;
                }
                itemCountOprView.setText(String.valueOf(currentItemCount));
                itemCountView.setText("x" + currentItemCount);
            }
        }

        isShowSelectTime = orderVO.getShowSelectTime();
        isShowSelectQuantity = orderVO.getShowSelectQuantity();
        isShowSelectAddress = orderVO.getShowSelectAddress();
        isShowContactUserName = orderVO.getShowContactUserName();
        isShowContactUserPhone = orderVO.getShowContactUserPhone();

        cellServiceTime.setVisibility(isShowSelectTime ? View.VISIBLE : View.GONE);
        cellItemCount.setVisibility(isShowSelectQuantity ? View.VISIBLE : View.GONE);
        textAddressAndUserInfo.setVisibility(isShowSelectAddress ? View.VISIBLE : View.GONE);
        contactNameView.setVisibility(isShowContactUserName ? View.VISIBLE : View.GONE);
        contactPhoneView.setVisibility(isShowContactUserPhone ? View.VISIBLE : View.GONE);

        tipSelectTimeView.setHint(orderVO.getSelectTimeDesc());
        tipSelectAddressView.setHint(orderVO.getSelectAddressDesc());

        // 可服务时间
        timeList = orderVO.getTime();
        // 地址
        BuyerVO buyer = orderVO.getBuyer();
        if (buyer != null) {
            if (isShowSelectAddress) {
                renderAddressInfo(buyer.getAddressName(), buyer.getContactorPhone(), buyer.getContactorName());
                //如果用户有地址 默认选取一个
                addressItem.setAddressId(buyer.getAddressId());
            }

            if (isShowContactUserName) {
                userNameView.setText(buyer.getContactorName());
            }
            if (isShowContactUserPhone) {
                userPhoneView.setText(buyer.getContactorPhone());
            }
        }

        itemCountOprView.setInputType(EditorInfo.TYPE_CLASS_NUMBER);
        userPhoneView.setInputType(EditorInfo.TYPE_CLASS_PHONE);


        //合计价格
        totalPriceView.setText(formatter.format(result.getAmount() / 100.00) + "元");

        // 消保文案
        if (CollectionUtil.isNotEmpty(orderVO.getGurantees())) {
            StringBuffer tips = null;
            for (String tee : orderVO.getGurantees()) {
                if (tips == null) {
                    tips = new StringBuffer(tee).append("\n");
                } else {
                    tips = tips.append(tee).append("\n");
                }
            }

            textProtectionInfo.setText(tips.toString());
            cellProtectionInfo.setVisibility(View.VISIBLE);
        }

    }


    private void renderAddressInfo(String addressName, String phone, String name) {
        String contactString = "联系人：" + name;
        contactString += "，";
        contactString += phone;
        textContactInfoView.setText(contactString);
        textAddressView.setText(addressName);

        textAddressTitle.setVisibility(View.GONE);
        tipSelectAddressView.setVisibility(View.GONE);
        cellBuyerAddressView.setVisibility(View.VISIBLE);
    }

    private void renderItem(ItemVO item) {
        promotionId = item.getPromotionId();
        snapshotItemId = item.getSnapshotItemId();
        itemTitle = item.getTitle();

        buyDownLimit = item.getBuyDownLimit() > 0 ? item.getBuyDownLimit() : 1;


        if (!TextUtils.isEmpty(
                item.getItemImage())) {
            String url = ImgUtil.getCDNUrlWithWidth(item.getItemImage(), itemImageView.getLayoutParams().width);
            if (!TextUtils.isEmpty(url)) {
                itemImageView.setImageURI(Uri.parse(url));
            }
        }
        textItemTagView.setText("我能·" + item.getTitle());

        SkuOutDO sku = item.getSku();
        if (sku != null) {
            itemStockTV.setVisibility(View.VISIBLE);
            itemStockTV.setText("服务规格：" + sku.getName());
            itemStockTV.setTextColor(getResources().getColor(R.color.color_order_item_sku));

            //设置价格
            renderPriceBySku(sku.getEarnest(), sku.getFinalPay(), sku.getPromotionPrice(), sku.getPrice());

            if (!TextUtils.isEmpty(sku.getEarnest())) {
                price = sku.getEarnest();
            } else if (!TextUtils.isEmpty(sku.getPromotionPrice())) {
                price = sku.getPromotionPrice();
            } else {
                price = sku.getPrice();
            }
        }
        //显示促销标
        renderPromotionTagView(item);

        //判断商品服务类型 展示字段
        if (item.getServiceType() == Constant.SERVICE_TYPE_POST) {
            if (item.getIsSpot() == 1) {
                itemServiceTypeView.setText("邮寄(现货)");
            } else {
                itemServiceTypeView.setText("邮寄(定制)");
            }
        } else {
            itemServiceTypeView.setText(item.getServiceTypeText());
        }

        if ("1".equals(item.getSupportPoint())) {
            isMcoinView.setVisibility(View.VISIBLE);
        }


        itemCountView.setText("x" + currentItemCount);
        itemCountView.setVisibility(View.VISIBLE);

    }

    void renderPromotionTagView(ItemVO item) {

        if (CollectionUtil.isNotEmpty(item.getPromotionTips())) {
            LinearLayout promotionTagLayout = (LinearLayout) findViewById(R.id.promotionTagLayout);
            promotionTagLayout.setVisibility(View.VISIBLE);

            for (String tag : item.getPromotionTips()) {
                View promotionView = LayoutInflater.from(this).inflate(R.layout.item_promotion_tag, promotionTagLayout, false);
                ((TextView) promotionView.findViewById(R.id.textItemTag)).setText(tag);
                promotionTagLayout.addView(promotionView);
            }
        }
    }

    void renderPriceBySku(String earnest, String finalPay, String promotionPrice, String oriPrice) {

        if (!TextUtils.isEmpty(earnest)) {
            servicePriceViewGroup.setVisibility(View.GONE);
            earnestViewGroup.setVisibility(View.VISIBLE);

            earnestValue.setText(String.format(getString(R.string.tail_yuan), earnest));
            finalPayAmountView.setText(String.format(getString(R.string.final_pay_amount), finalPay));


            totalPriceTitle.setText("预订金额：");
        } else {
            servicePriceViewGroup.setVisibility(View.VISIBLE);
            earnestViewGroup.setVisibility(View.GONE);

            if (TextUtils.isEmpty(promotionPrice)) {
                priceView.setText(String.format(getString(R.string.tail_yuan), oriPrice));
            } else {
                priceView.setText(String.format(getString(R.string.tail_yuan), promotionPrice));
                oriPriceView.setText(String.format(getString(R.string.tail_yuan), oriPrice));
                oriPriceView.setVisibility(View.VISIBLE);
                oriPriceView.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
            }
        }

//        itemStockTV.setText(String.format("(库存%s)", quantity));
    }

//    private void addServiceItem(List<ItemVO> itemList) {
//        if (CollectionUtil.isEmpty(itemList)) {
//            return;
//        }
//        for (ItemVO item : itemList) {
//            View itemView = LayoutInflater.from(this).inflate(R.layout.view_order_service_item, serviceItemGroup, false);
//            SimpleDraweeView imageItem = (SimpleDraweeView) itemView.findViewById(R.id.imageItem);
//            if (!TextUtils.isEmpty(item.getItemImage())) {
//                String url = ImgUtil.getCDNUrlWithWidth(item.getItemImage(), imageItem.getLayoutParams().width);
//                if (!TextUtils.isEmpty(url)) {
//                    imageItem.setImageURI(Uri.parse(url));
//                }
//            }
//            ((TextView) itemView.findViewById(R.id.textItemTag)).setText("我能·" + item.getTitle());
//            if (item.getSku() != null) {
//                ((TextView) itemView.findViewById(R.id.skuName)).setText(item.getSku().getName());
//                ((TextView) itemView.findViewById(R.id.textItemPrice)).setText(item.getSku().getPrice() + "");
//                TextView oriPriceItemPrice = (TextView) itemView.findViewById(R.id.skuName);
//                if (item.getSku().getPromotionPrice() != null) {
//                    oriPriceItemPrice.setText(item.getSku().getPromotionPrice() + "");
//                    oriPriceItemPrice.setVisibility(View.VISIBLE);
//                    oriPriceItemPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
//                }
//            }
//            TextView count = (TextView) itemView.findViewById(R.id.count);
//            TextView mItemServiceType = (TextView) itemView.findViewById(R.id.itemServiceType);
//            TextView isMcoin = (TextView) itemView.findViewById(R.id.is_mcoin);
//            TextView promotion = (TextView) itemView.findViewById(R.id.promotion);
//            count.setText(item.getCount() + "");
//            //判断商品服务类型 展示字段
//            if (item.getServiceType() == SERVICE_TYPE_DELIVER) {
//                if (item.getIsSpot() == 1) {
//                    mItemServiceType.setText("邮寄(现货)");
//                } else {
//                    mItemServiceType.setText("邮寄(定制)");
//                }
//            } else {
//                mItemServiceType.setText(item.getServiceTypeText());
//            }
//            if ("1".equals(item.getSupportPoint())) {
//                isMcoin.setVisibility(View.VISIBLE);
//            }
//
//            List<String> tipsList = item.getPromotionTips();
//            if (CollectionUtil.isNotEmpty(tipsList)) {
//                if (!TextUtils.isEmpty(tipsList.get(0))) {
//                    promotion.setText(tipsList.get(0));
//                    promotion.setVisibility(View.VISIBLE);
//                }
//            }
//            serviceItemGroup.addView(itemView);
//        }
//    }

    private void updateTotalPrice() {
        double totalPrice = 0;
        try {
            double itemPrice = Double.valueOf(price);
            totalPrice = itemPrice * currentItemCount;
        } catch (Exception e) {

        }
        totalPriceView.setText(formatter.format(totalPrice) + "元");

        itemCountOprView.setText(String.valueOf(currentItemCount));
        itemCountView.setText("x" + currentItemCount);
    }

    private void xhrFailure(HttpError error) {
        scrollView.setVisibility(View.GONE);
        cellToolBar.setVisibility(View.GONE);
        hideStatusLoading();
        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
            showStatusErrorNetwork(rootView, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    xhrOrderForm();
                }
            });
        } else {
            showStatusErrorServer(rootView, error, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    xhrOrderForm();
                }
            });
        }
    }


    public void handleBuy(View view) {
        try {
            JSONObject params = new JSONObject();
            if (preOrderFormVO != null) {
                itemId = preOrderFormVO.getItemId();
                params.put("itemSkuId", preOrderFormVO.getItemSkuId());
            }
            params.put("itemId", itemId);
            params.put("snapshotItemId", snapshotItemId);
            params.put("title", itemTitle);
            params.put("promotionId", promotionId);

            //数量和服务时间
            if (isShowSelectQuantity) {
                if (currentItemCount < buyDownLimit) {
                    MessageUtils.showToast(String.format("最少购买%s件", buyDownLimit));
                    return;
                }
                params.put("quantity", currentItemCount);

            }

            if (isShowSelectTime) {
                String time = tipSelectTimeView.getText().toString().trim();
                if (TextUtils.isEmpty(time)) {
                    MessageUtils.showToast("请选择时间");
                    return;
                }
                params.put("bookTime", time);
            }

            //地址参数
            if (isShowSelectAddress) {
                if (addressItem == null || TextUtils.isEmpty(addressItem.getAddressId())) {
                    MessageUtils.showToast("请选择地址");
                    return;
                }

                params.put("addressId", addressItem.getAddressId());
            }
            //联系人
            if (isShowContactUserName) {
                String name = userNameView.getText().toString().trim();
                if (TextUtils.isEmpty(name)) {
                    MessageUtils.showToast("请输入联系人");
                    return;
                }
                params.put("contactorName", name);
            }
            //联系电话
            if (isShowContactUserPhone) {
                String phone = userPhoneView.getText().toString().trim();
                if (TextUtils.isEmpty(phone)) {
                    MessageUtils.showToast("请输入联系电话");
                    return;
                }
                params.put("contactorPhone", phone);
            }

            String msg = textMessage.getText().toString().trim();
            if (!TextUtils.isEmpty(msg)) {
                params.put("buyerRemark", msg);
            }

            if (!TextUtils.isEmpty(geziId)) {
                params.put("geziId", geziId);
            }

            btnBuy.setEnabled(false);

            // 增加购买数量
            HttpClient.get("1.3/buyerOrder/order", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {
                    try {
                        if (result.containsKey("orderNo")) {
                            String orderNo = result.getString("orderNo");
                            Bundle bundle = new Bundle();
                            bundle.putString("orderNo", orderNo);
                            if (result.containsKey("title")) {
                                bundle.putString("title", result.getString("title"));
                            }
                            Router.sharedRouter().open("pay", bundle);
                        }

                        if (result.containsKey("pvid")) {
                            LogParam param = new LogParam();
                            param.setType(LogUtil.TYPE_CUSTOMIZE);
                            param.setEid(LogUtil.EVENT_ID_ORDER_CREATTE);
                            param.setPvid(result.getString("pvid"));
                            LogUtil.log(param);
                        }

                        finish();
                    } catch (JSONException e) {
                        btnBuy.setEnabled(true);
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    btnBuy.setEnabled(true);
                    if (null == error) {
                        MessageUtils.showToast("预约失败，请重试");
                        return;
                    }
                    switch (error.getCode()) {
                        case HttpError.ERR_CODE_UPDATE_ADRESS: {
                            MessageUtils.createDialog(OrderActivity.this, error.getTitle(), error.getMessage(),
                                    R.string.update, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Bundle bundle = new Bundle();
                                            bundle.putString(Constant.EXTRA_TAG_ADDRESS_ID, String.valueOf(addressItem.getAddressId()));
                                            bundle.putInt(Constant.EXTRA_TAG_ADDRESS_STATUS, 1);
                                            Router.sharedRouter().openFormResult("address/change", bundle,
                                                    Constant.REQUEST_CODE_CHANGE_ADDRESS, OrderActivity.this);
                                        }
                                    }, R.string.cancel, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    }).show();
                            return;
                        }
                        case HttpError.ERR_CODE_SERVICE_OUT_OF_RANGE: {
                            showNotInSquareServiceTip(error);
                            return;
                        }
                        case HttpError.ERR_CODE_SQUARE_OUT_OF_RANGE: {
                            showMaxJoinedSquareTip(error);
                            return;
                        }
                        case HttpError.ERR_CODE_NEED_JOIN_SQUARE: {
                            showJoinSquareTip(error);
                            return;
                        }
                    }
                    MessageUtils.showToastCenter(error.getMessage());
                }
            });
        } catch (JSONException e) {
            btnBuy.setEnabled(true);
        }
    }

    public void handleSelectTime(View view) {
        SelectTimeUtil util = new SelectTimeUtil(this, timeList);
        util.openSelectTimeDialog();

        util.setOnTimeClickListener(new SelectTimeUtil.OnTimeClickListener() {
            @Override
            public void onDelClick(String selectTime) {
                tipSelectTimeView.setText(selectTime);
            }
        });
    }

    public void handleSelectAddress(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("lastSelectIndex", lastSelectIndex);
        Router.sharedRouter().openFormResult("addresses", bundle, Constant.REQUEST_CODE_PICK_ADDRESS, this);
    }

    private void joinSquare(String squareId) {
        JSONObject params = new JSONObject();
        JSONArray array = new JSONArray();

        params.put("geziId", squareId);
        params.put("itemIdList", array);
        HttpClient.get("1.0/gezi/join", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        MessageUtils.showToast("加入成功");
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(error.toString());
                    }
                });
    }

    private void showJoinSquareTip(final HttpError error) {
        try {
            MessageUtils.createDialog(this, error.getTitle(), error.getMessage(), null, R.mipmap.order_square_join_tip,
                    R.string.join_now, new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (!TextUtils.isEmpty(geziId)) {
                                joinSquare(geziId);
                            } else {
                                joinSquare(error.getInfo().getString("geziId"));
                            }
                            dialog.dismiss();
                        }
                    }, R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showMaxJoinedSquareTip(HttpError error) {
        MessageUtils.createDialog(this, error.getTitle(), error.getMessage(), null,
                R.mipmap.order_square_max_tip, R.string.confirm, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }, 0, null).show();
    }

    private void showNotInSquareServiceTip(HttpError error) {
        MessageUtils.createDialog(this, error.getTitle(), error.getMessage(), null,
                R.mipmap.order_square_out_service_tip, R.string.confirm, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }, 0, null).show();
    }
}

