package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.Bind;
import butterknife.ButterKnife;

public class ChangeNicknameActivity extends BaseActivity {

    @Bind(R.id.editNickname)
    EditText editNickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_nickname);
        initActionBar(R.string.title_activity_change_nickname, true, true);
        ButterKnife.bind(this);
        mButtonRight.setText(R.string.confirm);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String nickname = editNickname.getText().toString().trim();

                if (nickname.length() == 0) {
                    MessageUtils.showToastCenter("输入呢称为空");
                    return;
                } else if (nickname.length() > 7) {
                    MessageUtils.showToastCenter("呢称不得超过7位");
                    return;
                } else {
                    mButtonRight.setEnabled(false);
                    JSONObject params = new JSONObject();
                    try {
                        params.put("nick", nickname);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
                        @Override
                        public void onSuccess(Object result) {
                            MessageUtils.showToastCenter("保存成功");
                            Intent intent = new Intent();
                            Bundle bundle = new Bundle();
                            bundle.putString("nickname", nickname);
                            intent.putExtras(bundle);
                            setResult(RESULT_OK, intent);
                            finish();
                        }

                        @Override
                        public void onFailure(HttpError error) {
                            MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败，请稍后再试");
                            mButtonRight.setEnabled(true);
                        }
                    });


                }
            }
        });

        Intent intent = getIntent();
        if (intent != null) {
            editNickname.setText(intent.getExtras().getString("nickname"));
            editNickname.setSelection(editNickname.length());
        }

    }


}
