package com.meidalife.shz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Switch;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareBbsIconAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.usepropeller.routable.Router;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by xingchen on 2015/12/20.
 */
public class SquareBbsPublishActivity extends BaseActivity {
    private static int TEXT_LENGTH_LIMIT_TITLE = 15;
    private final static int SELECT_CATEGORY = 80;

    private int geziId = Integer.MAX_VALUE;

    @Bind(R.id.bbsIconGV)
    GridView bbsIconGV;
    @Bind(R.id.bbsTitle)
    EditText bbsTitle;
    @Bind(R.id.textTitleLimit)
    TextView textTitleLimit;
    @Bind(R.id.anonymousSwitch)
    Switch anonymousSwitch;
    @Bind(R.id.removeImage)
    TextView removeImage;
    @Bind(R.id.picView)
    SimpleDraweeView picView;
    @Bind(R.id.selectPicView)
    View selectPicView;
    @Bind(R.id.catNameText)
    TextView catNameText;
    @Bind(R.id.publishView)
    TextView publishView;

    private int anonymous = 0;
    private String picPath;
    private int catId = Integer.MAX_VALUE;
    private String iconStr;
    private String[] bbsIcons;
    private boolean submit = false;
    private boolean uploadComplete = false;
    private boolean uploading = false;
    private String uploadImage;
    private SquareBbsIconAdapter squareBbsIconAdapter;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_bbs_publish);

        ButterKnife.bind(this);
        initActionBar(R.string.bbs_publish, true);
        if(!TextUtils.isEmpty(getIntent().getStringExtra("geziId")))
            geziId = Integer.parseInt(getIntent().getStringExtra("geziId"));
        hideIMM();
        bbsIcons = getResources().getStringArray(R.array.bbsIcon);
        iconStr = bbsIcons[0];
        squareBbsIconAdapter = new SquareBbsIconAdapter(this, bbsIcons);
        bbsIconGV.setAdapter(squareBbsIconAdapter);
        initListener();
    }

    private void initListener() {
        bbsTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textTitleLimit.setText("" + s.toString().length());
                if (s.toString().length() > TEXT_LENGTH_LIMIT_TITLE) {
                    textTitleLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textTitleLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        anonymousSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                anonymous = isChecked ? 1 : 0;
            }
        });

        bbsIconGV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == squareBbsIconAdapter.getSelectPos())
                    return;
                squareBbsIconAdapter.setSelectPos(position);
                squareBbsIconAdapter.notifyDataSetChanged();
                iconStr = bbsIcons[position];
            }
        });

        removeImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeImage.setVisibility(View.GONE);
                picView.setVisibility(View.GONE);
                selectPicView.setEnabled(true);
            }
        });
        publishView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handlePublish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK)
            return;
        Bundle params;
        switch (requestCode) {
            case SELECT_CATEGORY:
                params = data.getBundleExtra("params");
                String catName = params.getString("catName", "");
                catId = params.getInt("catId", Integer.MAX_VALUE);
                catNameText.setText(catName);
                catNameText.setTextColor(getResources().getColor(R.color.category_item_selected));
                break;
            case Constant.REQUEST_CODE_PICK_PHOTO:
                params = data.getExtras();
                ArrayList paths = params.getStringArrayList("images");
                if (paths.size() > 0) {
                    picPath = (String) paths.get(0);
                    Uri uri = Uri.fromFile(new File(picPath));
                    picView.setImageURI(uri);
                    picView.setVisibility(View.VISIBLE);
                    removeImage.setVisibility(View.VISIBLE);
                    selectPicView.setEnabled(false);
                }
                break;
        }
    }

    public void handlePublish() {
        if (catId == Integer.MAX_VALUE) {
            MessageUtils.showToastCenter("还未选择话题类型哦");
            return;
        }

        if (TextUtils.isEmpty(bbsTitle.getText().toString())) {
            MessageUtils.showToastCenter("还未填写主题内容哦");
            return;
        }

        if (bbsTitle.getText().toString().length() > TEXT_LENGTH_LIMIT_TITLE) {
            MessageUtils.showToastCenter("主题内容不能超过15个字");
            return;
        }

        if (TextUtils.isEmpty(iconStr)) {
            MessageUtils.showToastCenter("还未选择话题图标哦");
            return;
        }

//        if (picPath == null) {
//            MessageUtils.showToastCenter("还未选择上传图片哦");
//            return;
//        }

        if (!submit) {
            submit = true;
            showProgressDialog("正在发布", false);

            if (uploadComplete) {
                xhrPublish();
            } else {
                uploadImages();
            }
        }
    }

    private void uploadImages() {
        if(picPath == null && submit){
            xhrPublish();
            return;
        }
        if (!uploading) {
            uploading = true;
            RequestSign.upload(picPath, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    JSONObject json = (JSONObject) result;
                    try {
                        uploadImage = json.getString("data");
                        uploadComplete = true;
                        if (submit) {
                            xhrPublish();
                        }
                    } catch (JSONException e) {
                        uploading = false;
                        uploadComplete = false;
                        hideProgressDialog();
                        MessageUtils.showToastCenter(e.getMessage());
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    uploading = false;
                    uploadComplete = false;
                    submit = false;
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败");
                }
            });
        }
    }

    private void xhrPublish() {

        HttpClient.post("1.0/gezi/bbs/addTopic", getParams(), null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                hideProgressDialog();
                submit = false;
                setResult(RESULT_OK);
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                submit = false;
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败，请重试");
            }
        });
    }

    private com.alibaba.fastjson.JSONObject getParams() {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("geziId", geziId);
        params.put("icon", iconStr);
        params.put("title", bbsTitle.getText().toString());
        params.put("catId", catId);
        com.alibaba.fastjson.JSONArray pics = new com.alibaba.fastjson.JSONArray();
        pics.add(uploadImage);
        params.put("pics", pics);
        params.put("anonymous", anonymous);
        return params;
    }

    public void selectPic(View view) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", 1);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, this);
    }

    public void selectCategory(View view) {
        Bundle params = new Bundle();
        params.putInt("type", NearbyCategoryActivity.SQUARE_BBS_CATEGORY);
        params.putInt("geziId", geziId);
        Router.sharedRouter().openFormResult("nearbyCat", params, SELECT_CATEGORY, this);
    }

    @Override
    public void onBackPressed() {
        if(TextUtils.isEmpty(bbsTitle.getText().toString())
                && catId == Integer.MAX_VALUE
                && TextUtils.isEmpty(uploadImage)
                && anonymous == 0
                ){
            super.onBackPressed();
            return;
        }

        MessageUtils.createDialog(SquareBbsPublishActivity.this, "提醒", "真的要放弃编辑吗", R.string.confirm_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }, R.string.cancel_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        }).show();
    }

}
