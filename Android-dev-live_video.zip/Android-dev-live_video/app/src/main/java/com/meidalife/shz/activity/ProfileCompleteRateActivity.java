package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ConstellationAdapter;
import com.meidalife.shz.adapter.ProfileCompleteRateListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.UserCompleteDO;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtil;
import com.usepropeller.routable.Router;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 资料完善度页面
 * Created by liujian on 16/4/12.
 */
public class ProfileCompleteRateActivity extends BaseActivity {

    private final static int COMPLETE_INTRODUCE_ACTION = 88;
    private final static int PROFILE_RATE_DATA_REFRESH = 99;

    @Bind(R.id.completeRate)
    TextView completeRate;
    @Bind(R.id.dataListView)
    ListView dataListView;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    View contentView;

    private LoadUtil loadUtil;
    private List<UserCompleteDO.Result> results;
    private ProfileCompleteRateListAdapter profileCompleteRateListAdapter;
    private File cropImage;
    private String avatarUrl;
    private ArrayList<HashMap<String, String>> constellationData;
    private int constellationIndex;
    private String cityCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_complete_rate);

        ButterKnife.bind(this);
        initActionBar(R.string.title_profile_complete_rate, true);

        loadUtil = new LoadUtil(LayoutInflater.from(this));
        results = new ArrayList<UserCompleteDO.Result>();
        constellationData = SignUpActivity.getConstellationData(this);
        profileCompleteRateListAdapter = new ProfileCompleteRateListAdapter(ProfileCompleteRateActivity.this, results);
        profileCompleteRateListAdapter.setOnCompleteDataListener(new ProfileCompleteRateListAdapter.OnCompleteDataListener() {
            @Override
            public void onComplete(View v,String action) {
                handlerAction(v,action);
            }
        });
        dataListView.setAdapter(profileCompleteRateListAdapter);
        initData();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_PICK_PHOTO && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            ArrayList images = bundle.getStringArrayList("images");
            if (images.size() > 0) {
                avatarUrl = (String) images.get(0);
                Bundle params = new Bundle();
                params.putString("image_path", avatarUrl);
                params.putBoolean("return-data", false);

                cropImage = new File(ImgUtil.getEditedImagePath(this) +
                        File.separator + "cropped_avatar_" + System.currentTimeMillis() + ".jpg");
                params.putParcelable(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cropImage));
                Router.sharedRouter().openFormResult("cropImage", params,
                        Constant.REQUEST_CODE_CROP_PHOTO, ProfileCompleteRateActivity.this);
            }
        }
        else if (requestCode == Constant.REQUEST_CODE_CROP_PHOTO && resultCode == RESULT_OK) {
            if (cropImage != null && cropImage.exists()) {
                // syncAvatar(cropImage.getAbsolutePath());
                xhrUploadAvatar(cropImage.getAbsolutePath());
            } else {
                //  syncAvatar(avatarUrl);
                xhrUploadAvatar(avatarUrl);
            }

        }
        else if(requestCode == COMPLETE_INTRODUCE_ACTION && resultCode == RESULT_OK){
            initData();
        }
        else if (Constant.REQUEST_CODE_PICK_CITY == requestCode && resultCode == RESULT_OK) {
            Bundle bundle;
            bundle = data.getExtras();
            cityCode = bundle.getString("code");
            xhrUpdateProfile();
        }
        else if(requestCode == PROFILE_RATE_DATA_REFRESH){
            initData();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void initData() {
        loadUtil.loadPre(rootView, contentView);
        HttpClient.get("1.0/user/getUserComplete", null, UserCompleteDO.class, new HttpClient.HttpCallback<UserCompleteDO>() {
            @Override
            public void onSuccess(UserCompleteDO obj) {
                loadUtil.loadSuccess(contentView);
                if (obj != null) {
                    completeRate.setText(obj.getCompleteness() + "%");
                    results.clear();
                    if (obj.getResultList() != null) {
                        results.addAll(obj.getResultList());
                    }
                    profileCompleteRateListAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFail(HttpError error) {
                loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initData();
                    }
                });
            }
        });
    }

    private void xhrUploadAvatar(String path) {
        RequestSign.upload(path, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                JSONObject json = (JSONObject) result;
                try {
                    avatarUrl = json.getString("data");
                    xhrUpdateProfile();
                } catch (JSONException e) {
                }
                hideProgressDialog();
//                if (cropImage != null && cropImage.exists()) {
//                    syncAvatar(cropImage.getAbsolutePath());
//                } else {
//                    syncAvatar(avatarUrl);
//                }

            }

            @Override
            public void onFailure(HttpError error) {
                avatarUrl = null;
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "头像上传失败，请重试");
            }
        });
    }

    private void xhrUpdateProfile() {
        try {
            JSONObject params = new JSONObject();
            if (avatarUrl != null) {
                params.put("picUrl", avatarUrl);
                params.put("backgroundUrl", avatarUrl);
            }

            //  params.put("instruction", textDescription.getText().toString());
            if (constellationIndex > 0) {
                params.put("constellation", constellationIndex);
            }

            if(!TextUtils.isEmpty(cityCode)){
                params.put("cityCode",cityCode);
            }

            showProgressDialog("正在保存");
            RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter("保存成功");
//                    finish();
     //               Helper.sharedHelper().setStringUserInfo("nick", textNick.getText().toString());
                    if (avatarUrl != null) {
                        Helper.sharedHelper().setStringUserInfo("picUrl", avatarUrl);
                    }
                    initData();
                }

                @Override
                public void onFailure(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败");
                }
            });
        } catch (JSONException e) {
        }
    }

    private void handlerAction(View view,String action) {
        if (action.equals("doAvatar")) {  //头像
            Bundle bundle = new Bundle();
            bundle.putBoolean("isCheckbox", false);
            Router.sharedRouter().openFormResult("pick/photo", bundle,
                    Constant.REQUEST_CODE_PICK_PHOTO, ProfileCompleteRateActivity.this);
        }
        else if (action.equals("doConstellation")) {  //星座
            handleSelectConstellation(view);
        }
        else if (action.equals("doLocation")) {  //定位
            Router.sharedRouter().openFormResult("pick/city", Constant.REQUEST_CODE_PICK_CITY, this);
        }
        else if (action.equals("doIntroduction")) {  //个人简介
            Intent intent = new Intent(this,ProfilePersonalIntroduceActivity.class);
            startActivityForResult(intent,COMPLETE_INTRODUCE_ACTION);
        }
        else if (action.equals("doCertification")) {  //芝麻信用绑定或实名认证
            Router.sharedRouter().openFormResult("certificationlist",PROFILE_RATE_DATA_REFRESH,ProfileCompleteRateActivity.this);
        }
        else if (action.equals("doSkills")) {  //一项职业技能
            Router.sharedRouter().openFormResult("careerManage",PROFILE_RATE_DATA_REFRESH,ProfileCompleteRateActivity.this);
        }

    }

    public void handleSelectConstellation(final View view) {
        final AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.show();
        view.setEnabled(false);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                view.setEnabled(true);
            }
        });
        int deviceWidth = this.getResources().getDisplayMetrics().widthPixels;
        int deviceHeight = this.getResources().getDisplayMetrics().heightPixels;
        deviceWidth -= deviceWidth / 10;
        deviceHeight /= 2;
        dialog.getWindow().setLayout(deviceWidth, deviceHeight);
        View rootView = getLayoutInflater().inflate(R.layout.view_select_constellation, null);
        dialog.getWindow().setContentView(rootView);
        // init view
        ListView listView = (ListView) rootView.findViewById(R.id.optionConstellation);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                dialog.dismiss();
                constellationIndex = position + 1;
                HashMap<String, String> item = constellationData.get(position);
//                constellation.setText(item.get("name"));
//                constellation.setVisibility(View.VISIBLE);
                xhrUpdateProfile();
            }
        });
        ConstellationAdapter adapter = new ConstellationAdapter(this, constellationData);
        listView.setAdapter(adapter);
        if (constellationIndex > 0) {
            listView.setItemChecked(constellationIndex - 1, true);
        }
    }
}
