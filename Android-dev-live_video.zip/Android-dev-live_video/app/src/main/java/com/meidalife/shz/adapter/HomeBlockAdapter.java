package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.usepropeller.routable.Router;

/**
 * Created by fufeng on 16/4/13.
 */
public class HomeBlockAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private JSONArray homeBlockData = new JSONArray();

    public HomeBlockAdapter(Context context, JSONArray data) {
        mContext = context;
        mInflater = LayoutInflater.from(mContext);
        homeBlockData = data;
    }

    @Override
    public int getCount() {
        if (homeBlockData.size() % 2 == 1) {
            return homeBlockData.size() - 1;
        } else {
            return homeBlockData.size();
        }
    }

    @Override
    public Object getItem(int position) {
        return homeBlockData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.view_home_block, parent, false);
            holder.blockAdImage = (SimpleDraweeView) convertView.findViewById(R.id.blockAdImage);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        try {
            JSONObject data = homeBlockData.getJSONObject(position);
            String pic = data.getString("pic");
            final String link = data.getString("url");
            //中间坑位宽高比为2.15:1
            ViewGroup.LayoutParams layoutParams = holder.blockAdImage.getLayoutParams();
            layoutParams.height = (int) (mContext.getResources().getDisplayMetrics().widthPixels / 2 / 2.15);
            holder.blockAdImage.setLayoutParams(layoutParams);
            if (!TextUtils.isEmpty(pic)) {
                holder.blockAdImage.setImageURI(Uri.parse(pic));
            }
            if (!TextUtils.isEmpty(link)) {
                holder.blockAdImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", link);
                        Router.sharedRouter().open("web", bundle);
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (position < getCount() - 2) {
            if (position % 2 == 0)
                convertView.setBackgroundResource(R.drawable.border_bottom_right);
            else
                convertView.setBackgroundResource(R.drawable.border_bottom);
        } else if (position == getCount() - 2) {
            convertView.setBackgroundResource(R.drawable.border_right);
        }

        return convertView;
    }

    class ViewHolder {
        SimpleDraweeView blockAdImage;
    }
}
