package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.Service4DynamicDO;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class DynamicBindServiceAdapter extends BaseAdapter {
    Context context;
    List<Service4DynamicDO> mOrderList;
    LayoutInflater mInflater;

    public DynamicBindServiceAdapter(Context context, List<Service4DynamicDO> data) {
        this.context = context;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mOrderList = data;
    }

    @Override
    public int getCount() {
        return mOrderList.size();
    }

    @Override
    public Object getItem(int position) {
        return mOrderList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Service4DynamicDO service = mOrderList.get(position);

        ItemHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_dynamic_bind_service, parent, false);
            holder = new ItemHolder(convertView);

            convertView.setTag(holder);
        } else {
            holder = (ItemHolder) convertView.getTag();
        }

        if (!TextUtils.isEmpty(service.getSkillName())) {
            holder.title.setText(service.getSkillName());
        } else {
            holder.title.setText(service.getSellerName());
        }

        ViewGroup.LayoutParams avatarParams = holder.avatar.getLayoutParams();
        if (TextUtils.isEmpty(service.getImage())) {
            holder.avatar.setImageURI(null);
        } else {
            //加载本地默认头像
            String avatarUrl = ImgUtil.getCDNUrlWithWidth(service.getImage(), avatarParams.width);
            holder.avatar.setImageURI(Uri.parse(avatarUrl));
        }
        holder.serviceName.setText(service.getTitle());

        int level = 5;
        try {
            level = Integer.parseInt(service.getGrade());
        } catch (NumberFormatException e) {

        }
        View starsView = mInflater.inflate(R.layout.activity_sku_service_detail_stars, null);
        View starsRed = starsView.findViewById(R.id.star_red_group);
        starsRed.getLayoutParams().width = (int) Helper.convertDpToPixel(100, context) * level / 5;
        holder.judgeGroup.removeAllViews();
        holder.judgeGroup.addView(starsView);

        if (service.isSelected()) {
            holder.checkedIcon.setVisibility(View.VISIBLE);
        } else {
            holder.checkedIcon.setVisibility(View.GONE);
        }

        return convertView;
    }

    class ItemHolder {
        @Bind(R.id.title)
        public TextView title;
        @Bind(R.id.avatar)
        public SimpleDraweeView avatar;
        @Bind(R.id.serviceName)
        public TextView serviceName;
        @Bind(R.id.detail_judge_star_icon_group)
        public ViewGroup judgeGroup;
        @Bind(R.id.checkedIcon)
        TextView checkedIcon;

        public ItemHolder(View itemView) {
            ButterKnife.bind(this, itemView);
        }
    }
}
