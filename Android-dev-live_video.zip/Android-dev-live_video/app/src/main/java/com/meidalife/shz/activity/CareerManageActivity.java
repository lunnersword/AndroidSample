package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CareerManageAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CareerExpDo;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.FontButton;
import com.meidalife.shz.widget.RecyclerViewEmptySupport;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/4/26.
 */
public class CareerManageActivity extends BaseActivity implements CareerManageAdapter.SetMainCareerListener {
    List<CareerExpDo> careerExpDoList = new ArrayList<>();

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.careerList)
    RecyclerViewEmptySupport careerList;
    @Bind(R.id.action_bar_button_right)
    FontButton editButton;
    @Bind(R.id.careerEmptyView)
    ViewGroup careerEmptyView;
    @Bind(R.id.selectCareerButton)
    TextView selectCareerButton;

    CareerManageAdapter careerManageAdapter;
    LoadUtil mLoadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_career_manage);
        ButterKnife.bind(this);

        initActionBar("职业/技能", true, false);
        editButton.setText("编辑");
        mLoadUtil = new LoadUtil(LayoutInflater.from(this));
        careerManageAdapter = new CareerManageAdapter(this, careerExpDoList);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        careerList.setLayoutManager(linearLayoutManager);
        careerList.setAdapter(careerManageAdapter);
        careerList.setEmptyView(careerEmptyView);
        careerManageAdapter.setSetMainCareerListener(this);

        selectCareerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().openFormResult("careerSelect",
                        Constant.REQUEST_CODE_SELECT_CAREER, CareerManageActivity.this);
            }
        });
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().openFormResult("careerSelect",
                        Constant.REQUEST_CODE_SELECT_CAREER, CareerManageActivity.this);
            }
        });

        getCareerExp();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_SELECT_CAREER && resultCode == RESULT_OK) {
            getCareerExp();
        }
    }

    private void getCareerExp() {
        mLoadUtil.loadPre(rootView, careerList);
        HttpClient.get("1.0/skills/getAllSkill", new JSONObject(), null, new HttpClient.HttpCallback<JSONArray>() {
            @Override
            public void onSuccess(JSONArray obj) {
                try {
                    mLoadUtil.loadSuccess(careerList);

                    careerExpDoList = JSON.parseArray(obj.toJSONString(), CareerExpDo.class);
                    careerManageAdapter.setCareerExpDoList(careerExpDoList);
                    if (careerExpDoList.isEmpty()) {
                        editButton.setVisibility(View.GONE);
                    } else {
                        editButton.setVisibility(View.VISIBLE);
                    }
                    careerManageAdapter.notifyDataSetChanged();
                } catch (Exception e) {
                    editButton.setVisibility(View.GONE);
                    e.printStackTrace();
                    mLoadUtil.loadFail(new HttpError(HttpError.ERR_CODE_UNKNOWN, e.getMessage()),
                            rootView, new LoadUtil.Callback() {
                                @Override
                                public void retry() {
                                    getCareerExp();
                                }
                            });
                }
            }

            @Override
            public void onFail(HttpError error) {
                editButton.setVisibility(View.GONE);
                mLoadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        getCareerExp();
                    }
                });
            }
        });
    }

    @Override
    public void onSet(final String careerId) {
        JSONObject params = new JSONObject();
        params.put("careerId", careerId);
        HttpClient.get("1.0/skills/setSelectedCareer", params, null,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        for (CareerExpDo careerExpDo : careerExpDoList) {
                            if (careerId.equals(careerExpDo.getId())) {
                                careerExpDo.setDefaultCareer(true);
                            } else {
                                careerExpDo.setDefaultCareer(false);
                            }
                        }
                        careerManageAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast("设置失败:" + error);
                    }
                });
    }
}
