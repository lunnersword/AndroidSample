package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ServicePropRecycleAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ServicePropDo;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.widget.DividerItemDecoration;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/3/11.
 */
public class ServicePropSettingActivity extends BaseActivity {
    String skillId;
    boolean isEditMode = false;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.propRecyclerView)
    RecyclerView propRecyclerView;
    @Bind(R.id.hint)
    TextView hint;
    ServicePropRecycleAdapter servicePropRecycleAdapter;
    ArrayList<ServicePropDo> servicePropDoList = new ArrayList<>();
    ArrayList<ServicePropDo> savedPropDoList = new ArrayList<>();

    LoadUtil mLoadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_prop_setting);
        ButterKnife.bind(this);
        initActionBar(getIntent().getStringExtra(Constant.EXTRA_TAG_TITLE), true, true);

        initComponent();
        if (isEditMode || (savedPropDoList == null || savedPropDoList.isEmpty())) {
            getProps();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void initComponent() {
        mButtonRight.setText("保存");
        hint.setText(StrUtil.getSpanText("打<b>*</b>为必填项目",
                getResources().getColor(R.color.brand_b),
                getResources().getDimensionPixelSize(R.dimen.font_size_large)));
        skillId = getIntent().getStringExtra(Constant.EXTRA_TAG_SKILL_ID);
        isEditMode = getIntent().getBooleanExtra(Constant.EXTRA_TAG_EDIT_MODE, false);

        savedPropDoList = getIntent().getParcelableArrayListExtra(Constant.EXTRA_TAG_PROP_LIST);
        mLoadUtil = new LoadUtil(LayoutInflater.from(this));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        propRecyclerView.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL_LIST, getResources().getDrawable(R.drawable.thick_list_divider)));
        propRecyclerView.setLayoutManager(linearLayoutManager);

        if (savedPropDoList != null && !savedPropDoList.isEmpty() && !isEditMode) {
            servicePropRecycleAdapter = new ServicePropRecycleAdapter(this, savedPropDoList);
        } else {
            servicePropRecycleAdapter = new ServicePropRecycleAdapter(this, servicePropDoList);
        }
        propRecyclerView.setAdapter(servicePropRecycleAdapter);

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPropSetting()) {
                    Intent intent = new Intent();
                    intent.putParcelableArrayListExtra(Constant.EXTRA_TAG_PROP_LIST,
                            servicePropRecycleAdapter.getServicePropDoList());
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });
    }

    private void getProps() {
        JSONObject param = new JSONObject();
        param.put("skillId", skillId);
        mLoadUtil.loadPre(rootLayout, propRecyclerView);
        HttpClient.get("1.1/item/update/props", param, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                mLoadUtil.loadSuccess(propRecyclerView);
                hint.setVisibility(View.VISIBLE);
                if (obj.containsKey("props")) {
                    servicePropDoList = (ArrayList<ServicePropDo>) JSON.parseArray(obj.getJSONArray("props").toString(), ServicePropDo.class);
                }
                if (isEditMode && savedPropDoList != null && !savedPropDoList.isEmpty()) {
                    for (ServicePropDo savedPropDo : savedPropDoList) {
                        for (ServicePropDo servicePropDo : servicePropDoList) {
                            if (servicePropDo.getPid().equals(savedPropDo.getPid())) {
                                servicePropDo.setVid(savedPropDo.getVid());
                                servicePropDo.setVids(savedPropDo.getVids());
                                servicePropDo.setText(savedPropDo.getText());
                            }
                        }
                    }
                }
                servicePropRecycleAdapter.setServicePropDoList(servicePropDoList);
                servicePropRecycleAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                mLoadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        getProps();
                    }
                });
            }
        });
    }

    private boolean checkPropSetting() {
        for (ServicePropDo servicePropDo : servicePropDoList) {
            if (servicePropDo.isRequired()) {
                switch (servicePropDo.getType()) {
                    case ServicePropRecycleAdapter.PROP_TYPE_SINGLE_CHOICE: {
                        if (servicePropDo.getVid() == null) {
                            MessageUtils.showToast(servicePropDo.getName() + "必须选择一项");
                            return false;
                        }
                        break;
                    }
                    case ServicePropRecycleAdapter.PROP_TYPE_MULTI_CHOICE: {
                        if (servicePropDo.getVids() == null
                                || servicePropDo.getVids().isEmpty()) {
                            MessageUtils.showToast(servicePropDo.getName() + "至少选择一项");
                            return false;
                        }
                        break;
                    }
                    case ServicePropRecycleAdapter.PROP_TYPE_TEXT: {
                        if (TextUtils.isEmpty(servicePropDo.getText())) {
                            MessageUtils.showToast(servicePropDo.getName() + "不能为空");
                            return false;
                        }
                        break;
                    }
                }
            }
        }
        return true;
    }
}
