package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.PayWayOutDo;
import com.meidalife.shz.view.IconTextView;

import java.util.List;


/**
 * Created by zuozheng on 16/4/20.
 * 打赏支付
 */
public class PayWayAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private List<PayWayOutDo> list;
    private Context mContext;

//    private boolean hasNewMsg;

    public PayWayAdapter(Context mContext, List<PayWayOutDo> tabList) {
        this.mInflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
        this.list = tabList;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        PayWayOutDo item = list.get(position);
        if (convertView == null) {
            //todo 需要使用相对布局 实现小红点更新逻辑
            convertView = mInflater.inflate(R.layout.item_pay_way, parent, false);
            holder = new ViewHolder();
            holder.icon = (IconTextView) convertView.findViewById(R.id.paywayIcon);
            holder.textView = (TextView) convertView.findViewById(R.id.paywayText);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        switch (item.getType()) {
            case 1:
                holder.icon.setText(mContext.getResources().getString(R.string.icon_alipay_v2));
                if (item.getSelected() == 1) {
                    holder.icon.setTextColor(mContext.getResources().getColor(R.color.brand_l));
                } else {
                    holder.icon.setTextColor(mContext.getResources().getColor(R.color.grey_b));
                }
                break;
            case 2:
                holder.icon.setText(mContext.getResources().getString(R.string.icon_wechat));
                if (item.getSelected() == 1) {
                    holder.icon.setTextColor(mContext.getResources().getColor(R.color.wechat_color));
                } else {
                    holder.icon.setTextColor(mContext.getResources().getColor(R.color.grey_b));
                }
                break;
            case 3:
            default:
                holder.icon.setText(mContext.getResources().getString(R.string.icon_price_full));
                if (item.getSelected() == 1) {
                    holder.icon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                } else {
                    holder.icon.setTextColor(mContext.getResources().getColor(R.color.grey_b));
                }
                break;
        }
        holder.textView.setText(item.getTitle());

        return convertView;
    }

    static class ViewHolder {
        IconTextView icon;
        TextView textView;
    }
}
