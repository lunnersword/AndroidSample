package com.meidalife.shz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CareerDo;
import com.meidalife.shz.view.OnServicePublishListener;
import com.meidalife.shz.widget.TextTagView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/4/18.
 */
public class CareerRecyclerAdapter extends BaseRecycleViewAdapter {
    private Context mContext;
    private List<CareerDo> careerDoList = new ArrayList<>();
    private OnServicePublishListener onServicePublishListener;
    private String selectedCareerId;
    private String selectedSkillId;

    public CareerRecyclerAdapter(Context context, List<CareerDo> dataList) {
        super(context);
        setCareerDoList(dataList);
        setFooterViewId(R.layout.item_skill_footer);
    }

    public void setCareerDoList(List<CareerDo> careerDoList) {
        this.careerDoList = careerDoList;
    }

    public void setOnServicePublishListener(OnServicePublishListener onServicePublishListener) {
        this.onServicePublishListener = onServicePublishListener;
    }

    public String getSelectedCareerId() {
        return selectedCareerId;
    }

    public void setSelectedCareerId(String selectedCareerId) {
        this.selectedCareerId = selectedCareerId;
    }

    public String getSelectedSkillId() {
        return selectedSkillId;
    }

    public void setSelectedSkillId(String selectedSkillId) {
        this.selectedSkillId = selectedSkillId;
    }

    @Override
    public RecyclerView.ViewHolder onCreateContentViewHolder(ViewGroup parent, int viewType) {
        return new SkillItemViewHolder(inflater.inflate(R.layout.item_skill, parent, false));
    }

    @Override
    public void onBindContentViewHolder(RecyclerView.ViewHolder holder, int position) {
        final CareerDo careerDo = careerDoList.get(position);

        final SkillItemViewHolder skillItemViewHolder = (SkillItemViewHolder) holder;
        LinkedHashMap<String, String> tagMap = new LinkedHashMap<>();
        if (careerDo.getSkills() != null) {
            for (CareerDo.SkillDo skillDo : careerDo.getSkills()) {
                tagMap.put(skillDo.getId(), skillDo.getName());
            }
            skillItemViewHolder.textTagView.setTagData(tagMap);

            skillItemViewHolder.textTagView.setOnItemClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (CareerDo.SkillDo skillDo : careerDo.getSkills()) {
                        if (skillItemViewHolder.textTagView.getSelectedIds().contains(skillDo.getId())
                                && null != onServicePublishListener) {
                            selectedCareerId = careerDo.getId();
                            selectedSkillId = skillDo.getId();
                            onServicePublishListener.onSkillSelected(careerDo, skillDo);
                        }
                    }
                    notifyDataSetChanged();
                }
            });

            if (selectedCareerId != null && selectedCareerId.equals(careerDo.getId())) {
                if (selectedSkillId != null) {
                    HashSet<String> careerSelectedIds = new HashSet<>();
                    careerSelectedIds.add(selectedSkillId);
                    skillItemViewHolder.textTagView.setSelectedIds(careerSelectedIds);
                } else {
                    skillItemViewHolder.textTagView.reset();
                }
            } else {
                skillItemViewHolder.textTagView.reset();
            }
        }

        skillItemViewHolder.textTagView.setTagData(tagMap);
        skillItemViewHolder.skillTitle.setText(careerDo.getName());
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public void onBindFooterViewHolder(RecyclerView.ViewHolder holder, int position) {
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onServicePublishListener != null){
                    onServicePublishListener.onSkillUpdate();
                }
            }
        });
    }

    @Override
    public int getContentItemCount() {
        return careerDoList.size();
    }

    class SkillItemViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.skillTitle)
        TextView skillTitle;
        @Bind(R.id.skills)
        TextTagView textTagView;

        public SkillItemViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
