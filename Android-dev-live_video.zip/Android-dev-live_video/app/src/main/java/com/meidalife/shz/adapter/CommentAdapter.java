package com.meidalife.shz.adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.github.curioustechizen.ago.RelativeTimeTextView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CommentDO;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.FontTextView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiaoweilc on 15/6/22.
 */
public class CommentAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;

    private List<CommentDO> commentList;

    public CommentAdapter(Context context, List<CommentDO> commentList) {
        this.context = context;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.commentList = commentList;
    }

    public CommentAdapter(Context context, LayoutInflater inflater, List<CommentDO> commentList) {
        this.context = context;
        this.inflater = inflater;
        this.commentList = commentList;
    }

//    public void set(List<CommentDO> comments) {
//        this.commentList = comments;
//    }
//
//    public void add(List<CommentDO> comments) {
//        commentList.addAll(comments);
//    }

    public void addHead(CommentDO comment) {
        commentList.add(0, comment);
    }

    @Override
    public int getCount() {
        return commentList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (commentList.size() == 0) return null;    //TODO 数量为0，为什么还会进来？

        PJViewHolder pjHolder = null;
        if (convertView == null) {
            View pjView = inflater.inflate(R.layout.fragment_comment_item, null);
            pjHolder = new PJViewHolder();
            pjHolder.buyPic = (SimpleDraweeView) pjView.findViewById(R.id.detail_comment_pj_buy_pic);
            pjHolder.buyNick = (TextView) pjView.findViewById(R.id.detail_comment_pj_buy_nick);
            pjHolder.buyLevel = (LinearLayout) pjView.findViewById(R.id.detail_comment_pj_buy_level);
            pjHolder.buyPostTime = (RelativeTimeTextView) pjView.findViewById(R.id.detail_comment_pj_buy_posttime);
            pjHolder.buyCotent = (TextView) pjView.findViewById(R.id.detail_comment_pj_buy_content);
            pjHolder.buyPicList = (GridView) pjView.findViewById(R.id.detail_comment_pj_buy_pics_gridview);
            pjHolder.sellPic = (SimpleDraweeView) pjView.findViewById(R.id.detail_comment_pj_sell_pic);
            pjHolder.sellNick = (TextView) pjView.findViewById(R.id.detail_comment_pj_sell_nick);
            pjHolder.sellLevel = (LinearLayout) pjView.findViewById(R.id.detail_comment_pj_sell_level);
            pjHolder.sellPostTime = (RelativeTimeTextView) pjView.findViewById(R.id.detail_comment_pj_sell_posttime);
            pjHolder.sellContent = (TextView) pjView.findViewById(R.id.detail_comment_pj_sell_content);
            convertView = pjView;
            convertView.setTag(pjHolder);
        } else {
            pjHolder = (PJViewHolder) convertView.getTag();
        }

        CommentDO comment = commentList.get(position);
        CommentDO.InfoDO reply = comment.getReply();
        CommentDO.InfoDO quote = comment.getQuote();
        UserPicOnClickListener userPicOnClickListener = new UserPicOnClickListener();

        // 评论itemId、commentId
        pjHolder.itemId = comment.getItemId();
        pjHolder.commentId = comment.getCommentId();
        pjHolder.type = comment.getType();
        // 用户图像
        ImgUtil.load(context, comment.getAvatar(), pjHolder.buyPic.getLayoutParams(), pjHolder.buyPic);
        pjHolder.buyPic.setTag(comment.getUserId());
        pjHolder.buyPic.setOnClickListener(userPicOnClickListener);
        // 用户名
        pjHolder.buyNick.setText(comment.getNick());
        // 展示星级
        addLevelStar(comment.getLevel(), pjHolder.buyLevel);
        // 文本内容
        pjHolder.buyPostTime.setReferenceTime(comment.getCreateTime());
        // 判断是否增加回复
        if (quote != null) {
            pjHolder.buyCotent.setText("回复@" + comment.getQuote().getNick() + "：" + comment.getComment());
        } else {
            pjHolder.buyCotent.setText(comment.getComment());
        }
        // 图片
        if (comment.getImages() != null && comment.getImages().size() > 0) {
            pjHolder.buyPicList.setAdapter(new PJPicsAdapter(comment.getImages()));
            pjHolder.buyPicList.setVisibility(View.VISIBLE);
        } else {
            pjHolder.buyPicList.setVisibility(View.GONE);
        }
        // 卖家回复评价内容
        View replyView = convertView.findViewById(R.id.detail_comment_sell_reply);
        if (reply != null) {
            ImgUtil.load(context, reply.getAvatar(), pjHolder.sellPic.getLayoutParams(), pjHolder.sellPic);
            pjHolder.sellPic.setTag(reply.getUserId());
            pjHolder.sellPic.setOnClickListener(userPicOnClickListener);
            pjHolder.sellNick.setText(reply.getNick());
            addLevelStar(reply.getLevel(), pjHolder.sellLevel);
            pjHolder.sellPostTime.setReferenceTime(reply.getCreateTime());
            pjHolder.sellContent.setText(reply.getComment());
            replyView.setVisibility(View.VISIBLE);
        } else {
            replyView.setVisibility(View.GONE);
        }
        return convertView;
    }


    public void addLevelStar(Integer level, LinearLayout levelGroup) {
        if (level != null && level > 0) {
            levelGroup.removeAllViews();
            levelGroup.setVisibility(View.VISIBLE);
            for (int i = 0; i < level; i++) {
                TextView star = new FontTextView(context);
                LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                layout.setMargins(10, 10, 0, 0);
                star.setLayoutParams(layout);
                star.setFocusable(true);
                star.setText(R.string.icon_star_active);
                star.setTextColor(context.getResources().getColor(R.color.brand_b));
                star.setTypeface(Helper.sharedHelper().getIconFont());
                levelGroup.addView(star);
            }
        } else {
            levelGroup.setVisibility(View.GONE);
        }
    }

    class UserPicOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            try {
                Long userId = (Long) v.getTag();
                Router.sharedRouter().open("profile/" + userId.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class PJPicsAdapter extends BaseAdapter {

        private List<String> picList;

        public PJPicsAdapter(List<String> picList) {
            this.picList = picList;
        }

        @Override
        public int getCount() {
            return picList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            SimpleDraweeView imageView = null;
            if (convertView != null) {
                imageView = (SimpleDraweeView) convertView;
            } else {
                imageView = new SimpleDraweeView(context);
                imageView.setLayoutParams(new AbsListView.LayoutParams((int) Helper.convertDpToPixel(30, context), (int) Helper.convertDpToPixel(30, context)));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putInt("index", position);
                        bundle.putStringArrayList("photos", (ArrayList<String>) picList);
                        Router.sharedRouter().open("imageBrowser", bundle);
                    }
                });
            }
            ImgUtil.load(context, picList.get(position), imageView.getLayoutParams(), imageView);
            return imageView;
        }
    }

    public static class PJViewHolder {
        public String itemId;
        public String commentId;
        public int type;
        public SimpleDraweeView buyPic;
        public TextView buyNick;
        public RelativeTimeTextView buyPostTime;
        public TextView buyCotent;
        public LinearLayout buyLevel;
        public GridView buyPicList;
        public SimpleDraweeView sellPic;
        public TextView sellNick;
        public LinearLayout sellLevel;
        public RelativeTimeTextView sellPostTime;
        public TextView sellContent;
    }
}
