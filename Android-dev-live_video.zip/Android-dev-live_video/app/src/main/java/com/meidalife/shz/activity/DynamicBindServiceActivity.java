package com.meidalife.shz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.DynamicBindMyPaidServiceFragment;
import com.meidalife.shz.activity.fragment.DynamicBindMyPubServiceFragment;
import com.meidalife.shz.event.DynamicBindServiceEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.Service4DynamicDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.util.CollectionUtil;
import com.usepropeller.routable.Router;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.OnClick;
import de.greenrobot.event.EventBus;

/**
 * 选择关联服务
 * Created by zuozheng on 16/04／06
 */

public class DynamicBindServiceActivity extends BaseActivity {


    public final int TYPE_SERVICE_ME = 1; // 我发布服务
    public final int TYPE_SERVICE_PAY = 2; //我购买的服务

    private FragmentManager mFragmentManager;

    private int selectType = TYPE_SERVICE_ME;

    public DynamicBindMyPubServiceFragment mServiceFragment;
    public DynamicBindMyPaidServiceFragment mPaidServiceFragment;

    private Map<View, TextView> barMap = new HashMap<>();

    Service4DynamicDO item = null;
    private boolean isLoading = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_bind_service);

        initActionBar("选择关联服务", true, true);//统一继承BaseActivity风格
        renderPubButtonView(false);

        mFragmentManager = getSupportFragmentManager();
        initBar();

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        mButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleBack(v);
            }
        });

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handlePick(v);
            }
        });

        loadData();
    }

    private void renderPubButtonView(boolean pubButtonEnable) {
        if (pubButtonEnable) {
            mButtonRight.setBackgroundColor(getResources().getColor(R.color.brand));
            mButtonRight.setTextColor(getResources().getColor(R.color.brand_c));
        } else {
            mButtonRight.setBackgroundColor(getResources().getColor(R.color.grey_s));
            mButtonRight.setTextColor(getResources().getColor(R.color.grey_j));
        }
    }

    void initBar() {
        View officialAuthView = findViewById(R.id.title_left);
        TextView allLabel = (TextView) findViewById(R.id.title_left_label);
        barMap.put(officialAuthView, allLabel);
        officialAuthView.setTag(TYPE_SERVICE_ME);
        allLabel.setTextColor(getResources().getColor(R.color.grey_a));
        officialAuthView.setOnClickListener(orderTypeClick);

        View personalAuthView = findViewById(R.id.title_right);
        TextView acceptLabel = (TextView) findViewById(R.id.title_right_label);
        barMap.put(personalAuthView, acceptLabel);
        personalAuthView.setTag(TYPE_SERVICE_PAY);
        acceptLabel.setTextColor(getResources().getColor(R.color.grey_a));
        personalAuthView.setOnClickListener(orderTypeClick);
    }

    void updateNavBar(int selectType) {
        for (Map.Entry<View, TextView> e : barMap.entrySet()) {
            View onView = e.getKey();
            TextView label = e.getValue();
            if (onView.getTag() == selectType) {
                label.setBackgroundResource(R.drawable.bind_service_bottom);
                label.setTextColor(getResources().getColor(R.color.brand_c));
                selectType = (Integer) onView.getTag();
            } else {
                label.setBackgroundResource(R.color.white);
                label.setTextColor(getResources().getColor(R.color.grey_a));
            }
        }
    }

    View.OnClickListener orderTypeClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            for (Map.Entry<View, TextView> e : barMap.entrySet()) {
                View onView = e.getKey();
                TextView label = e.getValue();
                if (onView == v) {
                    label.setBackgroundResource(R.drawable.bind_service_bottom);
                    label.setTextColor(getResources().getColor(R.color.brand_c));
                    selectType = (Integer) onView.getTag();
                } else {
                    label.setBackgroundResource(R.color.white);
                    label.setTextColor(getResources().getColor(R.color.grey_a));
                }
            }
            updateContentView(selectType);
        }
    };


    private void updateContentView(int selectType) {

        if (selectType == TYPE_SERVICE_ME) {
            mServiceFragment = new DynamicBindMyPubServiceFragment();
            mFragmentManager.beginTransaction().replace(R.id.content_frame, mServiceFragment)
                    .commitAllowingStateLoss();

        } else {
            mPaidServiceFragment = new DynamicBindMyPaidServiceFragment();
            mFragmentManager.beginTransaction().replace(R.id.content_frame, mPaidServiceFragment)
                    .commitAllowingStateLoss();

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().openFormResult("signin", Constant.REQUEST_CODE_SIGNIN,
                    DynamicBindServiceActivity.this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (Constant.REQUEST_CODE_SIGNIN == requestCode && resultCode == RESULT_OK) {
            updateContentView(selectType);
        } else if (Constant.REQUEST_CODE_SIGNIN == requestCode && resultCode == RESULT_CANCELED) {
            finish();
        }
    }

    @OnClick(R.id.action_bar_button_right)
    public void handlePick(View view) {

        if (selectType == TYPE_SERVICE_ME) {
            item = mServiceFragment.getClickedItem();
        } else {
            item = mPaidServiceFragment.getClickedItem();
        }

        if (item != null && item.isSelected()) {
            Intent intent = new Intent();
            Bundle bundle = new Bundle();
            bundle.putString("itemId", item.getItemId());
            bundle.putString("title", item.getTitle());
            intent.putExtras(bundle);
            setResult(RESULT_OK, intent);
            finish();
        } else {
            showBingServiceDialog();
        }
    }


    @Override
    protected void onDestroy() {
        mFragmentManager = null;
        mPaidServiceFragment = null;
        mServiceFragment = null;
        EventBus.getDefault().unregister(this);

        super.onDestroy();
    }

    public void onEvent(DynamicBindServiceEvent event) {
        if (MsgTypeEnum.TYPE_BIND_SERVICE == event.eventType) {
            if (event.selected) {
                renderPubButtonView(true);
            } else {
                renderPubButtonView(false);
            }
        }
    }

    @Override
    public void handleBack(View view) {
        if (item == null || !item.isSelected()) {
            showBingServiceDialog();
        }
    }

    void showBingServiceDialog() {
        MessageUtils.showDialog(this, "真的要放弃关联动态？", "关联服务能大大提高动态的曝光率哦～", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putString("itemId", "");
                bundle.putString("title", "");
                intent.putExtras(bundle);
                setResult(RESULT_OK, intent);
                finish();
            }
        }, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
    }

    public void loadData() {
        if (isLoading) {
            return;
        }
        isLoading = true;

        RequestDynamic.myPaidServiceList(0, 2, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                isLoading = false;

                if (result != null) {
                    List<Service4DynamicDO> tmpList = JSON.parseArray(result.getString("itemPay"), Service4DynamicDO.class);

                    if (CollectionUtil.isNotEmpty(tmpList)) {
                        selectType = TYPE_SERVICE_PAY;
                    } else {
                        selectType = TYPE_SERVICE_ME;
                    }
                }
                updateNavBar(selectType);
                updateContentView(selectType);
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
            }
        });
    }
}
