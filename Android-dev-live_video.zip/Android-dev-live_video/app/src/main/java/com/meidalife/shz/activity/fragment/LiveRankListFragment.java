package com.meidalife.shz.activity.fragment;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.LiveRankListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LiveRewardRankDO;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.RankListHead123;
import com.meidalife.shz.widget.LiveVideoRewardRankPopupWindow;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by LanBo on 16/03/28.
 */
public class LiveRankListFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private static final String TAG_TYPE = "role";
    private static final String TAG_TITLE = "title";
    private static final int RANK_LIMIT = 10;

    private int mTopType = Constant.RANK_TYPE_DAY;
    private boolean mLoading = false;
    private List<LiveRewardRankDO> mLiveList = new ArrayList<>();
    private View rootView;

    private LiveRankListAdapter mLiveListAdapter;
    private LoadUtil mLoadUtil;

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    ListView mLiveListView;

    // header部分,需在ListView.addHeaderView之后Bind
    @Bind(R.id.rank1Avatar)
    SimpleDraweeView rank1Avatar;
    @Bind(R.id.rankTop1)
    FontTextView rankTop1;
    @Bind(R.id.rankContent1)
    View rankContent1;
    @Bind(R.id.titleRankTag1)
    View titleRankTag1;
    @Bind(R.id.rankContent2)
    View rankContent2;
    @Bind(R.id.titleRankTag2)
    View titleRankTag2;
    @Bind(R.id.rankContent3)
    View rankContent3;
    @Bind(R.id.titleRankTag3)
    View titleRankTag3;

    @Bind(R.id.rank_list_head_123)
    RankListHead123 rankListHead123;

    public static LiveRankListFragment newInstance(int liveListType) {
        LiveRankListFragment fragment = new LiveRankListFragment();

        Bundle params = new Bundle();
        params.putInt(TAG_TYPE, liveListType);
        String title = "";
        if (liveListType == Constant.RANK_TYPE_AUDIENCE) {
            title = "土豪榜";
        } else {
            title = "魅力榜";
        }
        params.putString(TAG_TITLE, title);
        fragment.setArguments(params);

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_live_rank_list, container, false);
            View headerView = inflater.inflate(R.layout.live_rank_header, null);
            mLiveListView = (ListView) rootView.findViewById(R.id.liveList);
            mLiveListView.addHeaderView(headerView);
            ButterKnife.bind(this, rootView);

            initHeaderListener();

            mLoadUtil = new LoadUtil(inflater);

            mSwipeRefreshLayout.setOnRefreshListener(this);
            mLiveListAdapter = new LiveRankListAdapter(getActivity(), mLiveList);
            mLiveListView.setAdapter(mLiveListAdapter);
            loadData(true);
        }
        return rootView;
    }

    private void initHeaderListener() {
        rankContent1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                titleRankTag1.setVisibility(View.VISIBLE);
                titleRankTag2.setVisibility(View.INVISIBLE);
                titleRankTag3.setVisibility(View.INVISIBLE);
                mTopType = Constant.RANK_TYPE_DAY;
                loadData(true);
            }
        });

        rankContent2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                titleRankTag1.setVisibility(View.INVISIBLE);
                titleRankTag2.setVisibility(View.VISIBLE);
                titleRankTag3.setVisibility(View.INVISIBLE);
                mTopType = Constant.RANK_TYPE_WEEK;
                loadData(true);
            }
        });

        rankContent3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                titleRankTag1.setVisibility(View.INVISIBLE);
                titleRankTag2.setVisibility(View.INVISIBLE);
                titleRankTag3.setVisibility(View.VISIBLE);
                mTopType = Constant.RANK_TYPE_ALL;
                loadData(true);
            }
        });

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroyView() {
        try {
            try {
                ViewGroup parent = (ViewGroup) rootView.getParent();
                if (parent != null) {
                    parent.removeView(rootView);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    public void loadData(final boolean reload) {
        if (mLoading) {
            return;
        }
        mLoading = true;
        int role = getArguments().getInt(TAG_TYPE);
        if (reload) {
            mLoadUtil.loadPre((ViewGroup) rootView, mSwipeRefreshLayout);
        }
        JSONObject params = new JSONObject();
        params.put("topType", mTopType);
        params.put("role", role);
        params.put("limit", RANK_LIMIT);

        HttpClient.get("1.0/rewards/top", params, LiveRewardRankDO.class, new HttpClient.HttpCallback<ArrayList<LiveRewardRankDO>>() {
            @Override
            public void onSuccess(ArrayList<LiveRewardRankDO> arrayList) {
                mLoadUtil.loadSuccess(mSwipeRefreshLayout);
                initHeaderData(arrayList);
                if (reload) {
                    mLiveList.clear();
                }
                if (arrayList.size() > 3) {
                    mLiveList.addAll(arrayList);
                }

                mLiveListAdapter.notifyDataSetChanged();
                mLoading = false;
                mSwipeRefreshLayout.setRefreshing(false);
                mLiveListView.setEnabled(true);
            }

            @Override
            public void onFail(HttpError error) {
                mSwipeRefreshLayout.setRefreshing(false);
                mLoading = false;
                mLiveListView.setEnabled(true);
                mLoadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        loadData(true);
                    }
                });
            }
        });
    }

    @Override
    public void onRefresh() {
        loadData(true);
    }

    private void initHeaderData(final ArrayList<LiveRewardRankDO> arrayList) {

        if (!(arrayList.size() > 0)) {
            return;
        }

        rankListHead123.initRankData(arrayList, getActivity());

        // 顶部和Rank1
        String avatarUrl = arrayList.get(0).getUserAvatar();
        String rankGender = arrayList.get(0).getGender();
        if (TextUtils.isEmpty(avatarUrl) || avatarUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(getActivity(), String.valueOf(arrayList.get(0).getUserId()), rankGender);
            rank1Avatar.setImageURI(getDefaultAvatarUri);
        } else {
            rank1Avatar.setImageURI(Uri.parse(avatarUrl));
        }

        rankTop1.setText(arrayList.get(0).getUserName());
    }

}
