package com.meidalife.shz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentTabHost;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Spannable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ViewAnimator;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.wukong.AuthConstants;
import com.alibaba.wukong.auth.AuthService;
import com.alibaba.wukong.im.ConversationService;
import com.alibaba.wukong.im.IMEngine;
import com.alibaba.wukong.im.MessageListener;
import com.alibaba.wukong.im.MessageService;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.activity.fragment.ChatExpressionFragment;
import com.meidalife.shz.adapter.ChatRecyclerAdapter;
import com.meidalife.shz.db.ChatTimer;
import com.meidalife.shz.db.ChatTimerDao;
import com.meidalife.shz.db.DaoSession;
import com.meidalife.shz.db.DatabaseManager;
import com.meidalife.shz.event.type.NetworkConnectTypeEnum;
import com.meidalife.shz.im.Callback;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.im.Conversation;
import com.meidalife.shz.im.ImClient;
import com.meidalife.shz.im.Message;
import com.meidalife.shz.im.MessageBuilder;
import com.meidalife.shz.im.MessageManager;
import com.meidalife.shz.im.constants.ImConstants;
import com.meidalife.shz.manager.WukongSender;
import com.meidalife.shz.media.AudioRecorder;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.model.ChatDO;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.rest.model.MessageDO;
import com.meidalife.shz.rest.model.PickServiceDo;
import com.meidalife.shz.rest.model.PositionOutDO;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.view.RecordView;
import com.meidalife.shz.widget.BaseRewardPopupWindow;
import com.meidalife.shz.widget.PopupListMenu;
import com.meidalife.shz.widget.RandRewardPopupWindow;
import com.usepropeller.routable.Router;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

public class ChatActivity extends BaseActivity {
    private static final String LOG_TAG = "ChatActivity";

    private static final int PAGE_SIZE = 10;
    private static final int STATUS_TIMER_STOP = 0;
    private static final int STATUS_TIMER_PAUSE = 1;
    private static final int STATUS_TIMER_PLAY = 2;

    private static final int MENU_ITEM_BLACK_LIST = 1;
    private static final int MENU_ITEM_CANCEL = 2;
    private static final int MENU_ITEM_REPORT = 0;

    private static final int CHILD_VIEW_INDEX_EXPAND_PANEL = 0;
    private static final int CHILD_VIEW_INDEX_FACE = 1;
    private static final int CHILD_VIEW_INDEX_VOICE = 2;

    private long timeInterval = 0;
    private long TIME_INTERVAL = 60 * 30; // 单位：毫秒
    private int retry;
    private int minVersion = 195;
    private boolean isLoading = false;
    private boolean isFirstScroll = true;
    private boolean isTimerOn = false;
    private int offset = 0;
    private int LIMIT_SIZE = 30;

    private long lastRemindOrderTime = 0;

    private String receiverId;
    private String itemId;
    private String orderNo;

    private List<String> trueWordsList = new ArrayList<>();
    private List<com.meidalife.shz.im.Message> messageDataList = new ArrayList<>();
    private LinearLayoutManager linearLayoutManager;
    private ChatDO chatDO;
    private ChatRecyclerAdapter chatRecycleAdapter;
    private WukongSender wukongSender;
    private Handler handler;
    private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    private ChatHelper chatHelper;
    private Timer chatTimer = null;
    private DatabaseManager databaseManager;
    private DaoSession daoSession;
    private Conversation conversation;

    @Bind(R.id.rootView)
    LinearLayout rootView;

    @Bind(R.id.menuButton)
    TextView menuButton;
    @Bind(R.id.itemInfoGroup)
    RelativeLayout itemInfoGroup;
    @Bind(R.id.itemImage)
    ImageView itemImage;
    @Bind(R.id.itemPrice)
    TextView itemPrice;
    @Bind(R.id.itemTitle)
    TextView itemTitle;
    @Bind(R.id.itemBuy)
    Button itemBuy;

    @Bind(R.id.messageList)
    RecyclerView messageReclerView;
    @Bind(R.id.timerLayout)
    ViewGroup timerLayout;
    @Bind(R.id.timer)
    TextView timer;
    @Bind(R.id.timerIndicator)
    TextView timerIndicator;
    @Bind(R.id.timerStatus)
    TextView timerStatus;

    @Bind(R.id.cellInputGroup)
    View cellInputGroup;
    @Bind(R.id.inputEdit)
    EditText inputEdit;
    @Bind(R.id.chatSend)
    View chatSend;

    @Bind(R.id.chatVoiceIcon)
    TextView chatVoiceIcon;
    @Bind(R.id.photoIcon)
    TextView photoIcon;
    @Bind(R.id.chatFaceIcon)
    TextView chatFaceIcon;
    @Bind(R.id.locationIcon)
    TextView locationIcon;
    @Bind(R.id.extendPaneIcon)
    TextView extendPaneIcon;
    @Bind(R.id.voiceRecord)
    RecordView voiceRecord;

    //发送服务
    @Bind(R.id.attachService)
    View attachService;
    //真心话
    @Bind(R.id.trueWords)
    ViewGroup trueWords;
    //打赏
    @Bind(R.id.rewardLayout)
    ViewGroup rewardLayout;

    @Bind(R.id.chatFaceGroup)
    View chatFaceGroup;

    @Bind(R.id.bottomPanel)
    ViewAnimator bottomPanel;
    //    @Bind(android.R.id.tabcontent)
    ViewGroup tabcontent;
    //    @Bind(android.R.id.tabhost)
    FragmentTabHost mTabHost;
    RandRewardPopupWindow randRewardPopupWindow;
    TextView[] imIconViewArray;

    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (AuthConstants.Event.EVENT_AUTH_LOGIN.equals(action)) {
                initIM();
            } else if (AuthConstants.Event.EVENT_AUTH_LOGOUT.equals(action)) {
                //退出登录
            } else if (AuthConstants.Event.EVENT_AUTH_KICKOUT.equals(action)) {
                //被踢断线
            }
        }
    };

    private MessageListener wukongMessageListener = new MessageListener() {
        @Override
        public void onAdded(List<com.alibaba.wukong.im.Message> list, DataType dataType) {
            for (com.alibaba.wukong.im.Message message : list) {
                Message m = com.meidalife.shz.im.utils.MessageUtils.toMessage(message);
                if (!messageDataList.contains(m)) {
                    message.read();
                    messageDataList.add(m);
                }
            }
            sortAndUpdateMessageList();
            scrollToLast();
        }

        @Override
        public void onRemoved(List<com.alibaba.wukong.im.Message> list) {

        }

        @Override
        public void onChanged(List<com.alibaba.wukong.im.Message> list) {
            for (com.alibaba.wukong.im.Message message : list) {
                Message m = com.meidalife.shz.im.utils.MessageUtils.toMessage(message);
                for (int i = 0; i < messageDataList.size(); i++) {
                    if (!TextUtils.isEmpty(m.getUniqMsgId()) && m.getUniqMsgId().equals(messageDataList.get(i).getUniqMsgId())) {
                        messageDataList.set(i, m);
                        break;
                    }
                }
            }
            sortAndUpdateMessageList();
        }
    };

    private com.meidalife.shz.im.MessageListener kgMessageListener = new com.meidalife.shz.im.MessageListener() {
        @Override
        public void onAdded(List<Message> messageList) {
            addMessageList(messageList);
        }

        @Override
        public void onRemoved(List<Message> messageList) {

        }

        @Override
        public void onChanged(List<Message> messageList) {
            updateMessageList(messageList);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        initActionBar(R.string.im_state_start, true);
        ButterKnife.bind(this);
        initData();
        initListener();

        chatHelper = ChatHelper.getInstance();

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(AuthConstants.Event.EVENT_AUTH_LOGIN);
        intentFilter.addAction(AuthConstants.Event.EVENT_AUTH_LOGOUT);
        intentFilter.addAction(AuthConstants.Event.EVENT_AUTH_KICKOUT);

        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, intentFilter);

        EventBus.getDefault().register(this);
        IMEngine.getIMService(MessageService.class).addMessageListener(wukongMessageListener);
        ImClient.getImService(MessageManager.class).addMessageListener(kgMessageListener);
        try {
            ImClient.getImService(MessageManager.class).syncMessageList(Integer.parseInt(receiverId));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

    }

    private void initData() {
        handler = new Handler();

        receiverId = getIntent().getStringExtra("receiverId");
        itemId = getIntent().getStringExtra("itemId");
        orderNo = getIntent().getStringExtra("orderNo");
        conversation = (Conversation) getIntent().getSerializableExtra("conversation");

        AudioRecorder audioRecorder = new AudioRecorder();
        voiceRecord.setAudioRecord(audioRecorder);
        voiceRecord.setRecordListener(new VoiceRecordListener());

        databaseManager = DatabaseManager.getInstance();
        daoSession = databaseManager.getDaoSession();

        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        messageReclerView.setLayoutManager(linearLayoutManager);
        messageReclerView.setAdapter(new ChatRecyclerAdapter(this,
                new ArrayList<com.meidalife.shz.im.Message>(), null, null));

        imIconViewArray = new TextView[]{chatVoiceIcon, photoIcon,
                chatFaceIcon, locationIcon, extendPaneIcon};
    }

    @Override
    protected void onStart() {
        super.onStart();
        retry = 0;
        initIM();
        SHZApplication.getInstance().setCurrentChatUserId(receiverId);
    }

    @Override
    protected void onStop() {
        SHZApplication.getInstance().setCurrentChatUserId("");
        super.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
        updateImIconStatus(-1);
    }

    @Override
    public void onPause() {
        super.onPause();
        if (conversation != null) {
            conversation.resetUnreadCount();
            if (!TextUtils.isEmpty(inputEdit.getText())) {
                conversation.setDraftMessage(inputEdit.getText().toString());
            } else {
                conversation.setDraftMessage("");
            }
        }
        if (null != chatRecycleAdapter) {
            chatRecycleAdapter.release();
        }
        stopTimer(isTimerOn ? STATUS_TIMER_PLAY : STATUS_TIMER_PAUSE);
    }


    public void onEventMainThread(NetworkConnectTypeEnum eventType) {
        if (NetworkConnectTypeEnum.TYPE_CONNECTED.equals(eventType)) {
            if (chatDO != null) {
                setActionBarTitle(chatDO.getReceiveUserName());
            }
        } else {
            setActionBarTitle("网络连接中...");
        }
    }

    public void onEventMainThread(ChatExpressionFragment.ChatExpressionEvent event) {
        Editable edit = inputEdit.getEditableText();//获取EditText的文字
        int index = inputEdit.getSelectionStart();
        if (index < 0 || index >= edit.length()) {
            edit.append(event.expressionName);
        } else {
            edit.insert(index, event.expressionName);//光标所在位置插入文字
        }
        ImageSpan expressionPan = chatHelper.getImageSpan(event.expressionName, 20);
        if (null != expressionPan) {
            edit.setSpan(expressionPan, index, index + event.expressionName.length(),
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
        EventBus.getDefault().unregister(this);
        IMEngine.getIMService(MessageService.class).removeMessageListener(wukongMessageListener);
        ImClient.getImService(MessageManager.class).removeMessageListener(kgMessageListener);
        super.onDestroy();
    }

    /**
     * 选择其它内容后回调
     */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {

            case Constant.REQUEST_CODE_PICK_PHOTO: {
                // 选择图片
                if (resultCode == RESULT_OK && null != data) {
                    Bundle bundle = data.getExtras();
                    ArrayList<String> paths = bundle.getStringArrayList("images");
                    if (null != paths && !paths.isEmpty()) {
                        for (String path : paths) {
                            if (wukongSender != null) {
                                wukongSender.sendImageMessage(path);
                            }
                        }

                        finishSend();
                    }
                }
                break;
            }
            case Constant.REQUEST_CODE_PICK_ADDRESS: {
                if (resultCode == RESULT_OK) {
                    Bundle extras = data.getExtras();
                    AddressItem addressItem = (AddressItem) extras.getSerializable(Constant.EXTRA_TAG_ADDRESS);
                    if (wukongSender != null) {
                        wukongSender.sendTextMessage(addressItem.getContactorName() + ", " +
                                addressItem.getContactorPhone() + ", " + addressItem.getAddressName());
                    }
                    finishSend();
                }
                break;
            }
            case Constant.REQUEST_CODE_PICK_LOCATION: {
                if (resultCode == RESULT_OK) {
                    Bundle extras = data.getExtras();
                    PositionOutDO positionOut = (PositionOutDO) extras.getSerializable("INTENT_SELECTED_ADDRESS");
                    if (wukongSender != null) {
                        wukongSender.sendPositionMessage(positionOut);
                    }
                    finishSend();
                }
                break;
            }

            case Constant.REQUEST_CODE_PICK_SERVICE: {
                if (resultCode == RESULT_OK) {
                    if (wukongSender != null) {
                        PickServiceDo serviceDo = data.getParcelableExtra(Constant.EXTRA_TAG_PICKED_SERVICE);
                        wukongSender.sendServiceMessage(serviceDo);
                    }
                    finishSend();
                }
                break;
            }
        }
    }

    private void updateImIconStatus(int selectedIndex) {
        for (int i = 0; i < imIconViewArray.length; i++) {
            if (i == selectedIndex) {
                imIconViewArray[i].setSelected(true);
            } else {
                imIconViewArray[i].setSelected(false);
            }
        }
    }

    private void initListener() {
        cellInputGroup.setVisibility(View.GONE);
        bottomPanel.setVisibility(View.GONE);
        chatSend.setVisibility(View.GONE);
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHidePopMenu(v);
            }
        });

        inputEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomPanel.setVisibility(View.GONE);
            }
        });

        inputEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().length() > 0) {
                    chatSend.setVisibility(View.VISIBLE);
                } else {
                    chatSend.setVisibility(View.GONE);
                }
                if (inputEdit.getTag() != null && (Boolean) inputEdit.getTag()) {
                    inputEdit.setTag(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        inputEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    bottomPanel.setVisibility(View.GONE);
                }
            }
        });

        messageReclerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideKeyboard();
                return false;
            }
        });

        messageReclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (linearLayoutManager.findFirstCompletelyVisibleItemPosition() == 0 && !isLoading && !isFirstScroll) {
                    loadMessages(false);
                }

                //解决第一次进入调用scrollToLast()触发的加载消息
                isFirstScroll = false;
            }
        });

        timerLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isTimerOn) {
                    stopTimer(STATUS_TIMER_PAUSE);
                } else {
                    startTimer();
                }
            }
        });

        timerStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isTimerOn) {
                    stopTimer(STATUS_TIMER_STOP);
                } else {
                    startTimer();
                }
            }
        });

        rewardLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rewardReceiver();
            }
        });

        chatSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = inputEdit.getText().toString();
                if (!StrUtil.isEmpty(text)) {
                    wukongSender.sendTextMessage(text);
                    finishSend();
                }
            }
        });

        chatVoiceIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //检查对方版本号
                    int version = Integer.parseInt(chatDO.getReceiveAppVersion().replace(".", ""));
                    if (version < minVersion && version > 0) {
                        MessageUtils.showToastCenter("对方版本过低，将收不到你的语音");
                        return;
                    }
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
                hideKeyboard();
                updateImIconStatus(0);
                bottomPanel.setVisibility(View.VISIBLE);
                bottomPanel.setDisplayedChild(1);
            }
        });

        photoIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putBoolean("isCheckbox", true);
                bundle.putInt("maxLength", 9);
                Router.sharedRouter().openFormResult("pick/photo", bundle,
                        Constant.REQUEST_CODE_PICK_PHOTO, ChatActivity.this);
                updateImIconStatus(1);
                bottomPanel.setVisibility(View.GONE);
            }
        });

        chatFaceIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomPanel.setVisibility(View.VISIBLE);
                bottomPanel.setDisplayedChild(2);
                hideKeyboard();
                updateImIconStatus(2);
            }
        });

        locationIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MessageUtils.singleChoiceDialog(ChatActivity.this, "", getResources()
                                .getStringArray(R.array.sendPosition), 0,
                        new MessageUtils.SingleChoiceDialogInterface() {

                            @Override
                            public void onNegative(DialogInterface dialog) {
                                dialog.dismiss();
                                updateImIconStatus(-1);
                            }

                            @Override
                            public void onPositive(DialogInterface dialog, int checkedItem) {
                                processChecked(checkedItem);
                                dialog.dismiss();
                                updateImIconStatus(-1);
                            }
                        });
                updateImIconStatus(3);
                bottomPanel.setVisibility(View.GONE);
            }
        });

        extendPaneIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bottomPanel.getVisibility() == View.GONE) {
                    bottomPanel.setVisibility(View.VISIBLE);
                    bottomPanel.setDisplayedChild(0);
                    updateImIconStatus(4);
                } else {
                    bottomPanel.setVisibility(View.GONE);
                    updateImIconStatus(-1);
                }
                hideKeyboard();
            }
        });

        attachService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //检查对方版本号
                    if (null != chatDO.getReceiveAppVersion()) {
                        int version = Integer.parseInt(chatDO.getReceiveAppVersion().replace(".", ""));
                        if (version < minVersion && version > 0) {
                            MessageUtils.showToastCenter("对方版本过低，将收不到你的服务");
                            return;
                        }
                    }
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
                Router.sharedRouter().openFormResult("pick/service",
                        Constant.REQUEST_CODE_PICK_SERVICE, ChatActivity.this);
            }
        });

        trueWords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendRandomTrueWord();
            }
        });

        mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);

        mTabHost.addTab(getTabSpecView("home", R.layout.item_single_image), ChatExpressionFragment.class, null);
    }

    private FragmentTabHost.TabSpec getTabSpecView(String tag, int layoutId) {
        return mTabHost.newTabSpec(tag).setIndicator(getLayoutInflater().inflate(layoutId, null));
    }

    @Override
    protected void showOrHidePopMenu(View v) {
        if (chatDO == null) {
            return;
        }
        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(this, 0);
        }

        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_BLACK_LIST: {
                        if (chatDO.isBlock()) {
                            unblockUser(chatDO.getReceiveUserId());
                        } else {
                            blockUser(chatDO.getReceiveUserId());
                        }
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_CANCEL: {
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_REPORT: {
                        doReport();
                        mPopupListMenu.dismiss();
                        break;
                    }
                }
            }
        });

        List<MenuVO> menuList = new ArrayList<>();


        menuList.add(MENU_ITEM_REPORT, new MenuVO(getString(R.string.report)));

        if (!chatDO.isBlock()) {
            menuList.add(MENU_ITEM_BLACK_LIST, new MenuVO(getString(R.string.menu_item_blacklist)));
        } else {
            menuList.add(MENU_ITEM_BLACK_LIST, new MenuVO(getString(R.string.menu_item_remove_blacklist)));
        }

        menuList.add(MENU_ITEM_CANCEL, new MenuVO(getString(R.string.cancel)));

        mPopupListMenu.setMenuData(menuList);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    @Override
    protected void doReport() {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", String.valueOf(receiverId));
        intent.putExtra("target", Constant.REPORT_TYPE_IM);
        startActivity(intent);
    }

    private void startTimer() {
        if (isTimerOn) {
            return;
        }
        if (chatTimer == null) {
            chatTimer = new Timer();
        }

        chatTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                timeInterval += 1000;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setTimerValue();
                    }
                });
            }
        }, 0, 1000);

        isTimerOn = true;
        timerLayout.setVisibility(View.VISIBLE);
        timerIndicator.setText(R.string.icon_pause);
        timerStatus.setText(getString(R.string.icon_timer_used));
        setTimerValue();
    }

    private void stopTimer(int status) {
        if (chatDO == null || TextUtils.isEmpty(chatDO.getReceiveUserId())
                || !isTimerOn) {
            return;
        }

        //停止计时器重新计时
        if (status == STATUS_TIMER_STOP) {
            timeInterval = 0;
            timerLayout.setVisibility(View.GONE);
            timerStatus.setText(getString(R.string.icon_timer_normal));
        }
        ChatTimer currentChatTimer = new ChatTimer();
        currentChatTimer.setUserId(chatDO.getReceiveUserId());
        currentChatTimer.setInterval(timeInterval);
        currentChatTimer.setStatus(status);
        daoSession.getChatTimerDao().insertOrReplace(currentChatTimer);
        if (chatTimer != null) {
            chatTimer.cancel();
            chatTimer = null;
        }
        timerIndicator.setText(R.string.icon_play);
        setTimerValue();
        isTimerOn = false;
    }

    private void checkChatTimer() {
        ChatTimer savedChatTimer = daoSession.getChatTimerDao().queryBuilder().
                where(ChatTimerDao.Properties.UserId.eq(chatDO.getReceiveUserId())).
                build().unique();
        if (null != savedChatTimer && savedChatTimer.getStatus() == STATUS_TIMER_PLAY) {
            //继续上次播放
            timeInterval = savedChatTimer.getInterval();
            timerStatus.setText(getString(R.string.icon_timer_used));
            startTimer();
            timerLayout.setVisibility(View.VISIBLE);
        } else if (null != savedChatTimer && savedChatTimer.getStatus() == STATUS_TIMER_PAUSE) {
            timeInterval = savedChatTimer.getInterval();
            timerStatus.setText(getString(R.string.icon_timer_used));
            timerLayout.setVisibility(View.VISIBLE);
        } else {
            timerStatus.setText(getString(R.string.icon_timer_normal));
        }

        setTimerValue();
        timerStatus.setVisibility(View.VISIBLE);
    }

    private void setTimerValue() {
        SimpleDateFormat format = new SimpleDateFormat("mm:ss");
        Date date = new Date(timeInterval);
        String timerString = format.format(date);
        long hours = (timeInterval / 1000) / 3600;
        if (!TextUtils.isEmpty(timerString)) {
            if (hours > 0) {
                String hoursString = String.valueOf(hours).length() == 1 ?
                        ("0" + String.valueOf(hours)) : String.valueOf(hours);

                timer.setText(hoursString + ":" + timerString);
            } else {
                timer.setText(timerString);
            }
        }
    }

    private void sendRandomTrueWord() {
        Random random = new Random();
        int index = random.nextInt(trueWordsList.size());
        String trueWordString = trueWordsList.get(index);
        wukongSender.sendTextMessage(trueWordString);
        scrollToLast();
    }

    private void initTrueWordsList() {
        HttpClient.get("1.0/conversation/getTrueWordsList", new JSONObject(), null, new HttpClient.HttpCallback<JSONArray>() {
            @Override
            public void onSuccess(JSONArray obj) {
                if (obj != null && obj.size() > 0) {
                    for (int index = 0; index < obj.size(); index++) {
                        if (!trueWordsList.contains(obj.getString(index))) {
                            trueWordsList.add(obj.getString(index));
                        }
                    }
                }
                if (!trueWordsList.isEmpty()) {
                    trueWords.setVisibility(View.VISIBLE);
                } else {
                    trueWords.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(LOG_TAG, "Failed to init true word list" + error);
            }
        });
    }

    private void blockUser(String userId) {
        JSONObject params = new JSONObject();
        params.put("type", "1");
        params.put("anotherUserId", userId);

        HttpClient.get("1.0/relationship/user/bind", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                chatDO.setBlock(true);
                wukongSender.sendReminderMessage(MessageDO.REMIND_MESSAGE_TYPE_BLOCK, Helper.sharedHelper().getUserId());
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(LOG_TAG, "Failed to init true word list" + error);
            }
        });
    }

    private void unblockUser(String userId) {
        JSONObject params = new JSONObject();
        params.put("type", "1");
        params.put("anotherUserId", userId);
        HttpClient.get("1.0/relationship/user/unbind", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                chatDO.setBlock(false);
                wukongSender.sendReminderMessage(MessageDO.REMIND_MESSAGE_TYPE_UNBLOCK, Helper.sharedHelper().getUserId());
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(LOG_TAG, "Failed to init true word list" + error);
            }
        });
    }

    void processChecked(int position) {
        //发送当前位置 选择地图位置
        if (position == 0) {
            Router.sharedRouter().openFormResult("location",
                    Constant.REQUEST_CODE_PICK_LOCATION, ChatActivity.this);
        } else {
            Router.sharedRouter().openFormResult("addresses",
                    Constant.REQUEST_CODE_PICK_ADDRESS, ChatActivity.this);
        }
    }

    private void initIM() {
        if (!Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().open("signin");
            finish();
            return;
        }

        showStatusLoading(rootView);
        if (!AuthService.getInstance().isLogin() && retry <= 5) {  // 此时用户已登录，等待鉴权成功，重试5次
            retry++;

            Long userId = Long.parseLong(Helper.sharedHelper().getUserId());

            if (IMEngine.getIMService(AuthService.class).latestAuthInfo().getOpenId() == userId) {
                IMEngine.getIMService(AuthService.class).autoLogin(userId);

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initIM();
                    }
                }, 500 + retry * 100);
            } else {
                ChatHelper.getInstance().authWuKong(Helper.sharedHelper().getUserId());
            }
        } else {
            // 初始化会话
            initConversation();
        }
    }

    private void initConversation() {
        JSONObject params = new JSONObject();
        params.put("receiveUserId", receiverId);
        if (orderNo != null) {
            params.put("orderNo", orderNo);
        } else {
            params.put("itemId", itemId);
        }

        HttpClient.get("1.0/conversation/initWukongChat", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        hideStatusLoading();
                        chatDO = JSON.parseObject(obj.toJSONString(), ChatDO.class);
                        // 标题栏头部
                        setActionBarTitle(chatDO.getReceiveUserName());

                        // 渲染头部
                        renderItemInfo(chatDO);

                        //只有在卖家界面，而且是陪聊类目时才显示计时器
                        if (chatDO.isChatCategory() && !TextUtils.isEmpty(chatDO.getItemOwnerId())
                                && chatDO.getItemOwnerId().equals(Helper.sharedHelper().getUserId())) {
                            checkChatTimer();
                        }

                        if (chatDO.isChatCategory()) {
                            initTrueWordsList();
                        } else {
                            trueWords.setVisibility(View.GONE);
                        }

                        chatRecycleAdapter = new ChatRecyclerAdapter(ChatActivity.this,
                                messageDataList, chatDO.getReceiveAvatar(), chatDO.getReceiveUserName());
                        messageReclerView.setAdapter(chatRecycleAdapter);
                        wukongSender = new WukongSender(ChatActivity.this, chatDO);
                        createWukongConversation();
                        loadMessages(true);
                    }

                    @Override
                    public void onFail(HttpError error) {
                        hideStatusLoading();
                        setActionBarTitle("系统异常");
                        if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                            showStatusErrorNetwork(rootView);
                        } else {
                            showStatusErrorServer(rootView);
                            if (!TextUtils.isEmpty(error.getMessage())) {
                                setTextErrorServer(error.getMessage());
                            }
                        }
                    }
                });
    }

    private void sortMessageList() {
        Collections.sort(messageDataList, new Comparator<Message>() {
            @Override
            public int compare(Message lhs, Message rhs) {
                return Long.valueOf(rhs.createdAt()).compareTo(lhs.createdAt());
            }
        });
    }

    private void loadMessages(final boolean reload) {
        Log.d(LOG_TAG, "loadMessages start.");
        if (isLoading) {
            return;
        }
        isLoading = true;
        if (reload) {
            offset = 0;
            messageDataList.clear();
        }
        ImClient.getImService(MessageManager.class)
                .getMessageList(new com.meidalife.shz.im.Callback<List<com.meidalife.shz.im.Message>>() {
                    @Override
                    public void onSuccess(List<com.meidalife.shz.im.Message> msgList) {
                        // 显示输入框
                        cellInputGroup.setVisibility(View.VISIBLE);
                        if (msgList.isEmpty()) {
                            return;
                        }
                        long previousTime = System.currentTimeMillis() / 1000;
                        int previousMessageListSize = messageDataList.size();
                        for (int i = 0; i < msgList.size(); i++) {
                            long interval = previousTime - msgList.get(i).createdAt();
                            if (!messageDataList.contains(msgList.get(i))) {
                                messageDataList.add(msgList.get(i));
                                if (interval > TIME_INTERVAL) {
                                    com.meidalife.shz.im.Message message = ImClient.getImService(MessageBuilder.class)
                                            .setCreateTime(msgList.get(i).createdAt() - 1)
                                            .setExtension("text", format.format(new Date(msgList.get(i).createdAt() * 1000)))
                                            .setExtension(ImConstants.EXT_TAG_VIEW_TYPE, String.valueOf(ChatRecyclerAdapter.VIEW_TYPE_TIME))
                                            .setMessageType(Message.MessageType.UNKNOWN)
                                            .create();
                                    messageDataList.add(message);
                                    previousTime = msgList.get(i).createdAt();
                                }
                            }
                        }

                        Log.d(LOG_TAG, "Get message list:" + messageDataList.size());
                        chatRecycleAdapter.setMessageList(messageDataList);

                        if (reload) {
                            sortAndUpdateMessageList();
                            scrollToLast();
                        } else {
                            Collections.sort(messageDataList, new Comparator<Message>() {
                                @Override
                                public int compare(Message lhs, Message rhs) {
                                    return lhs.createdAt() < rhs.createdAt() ? -1 : (lhs.createdAt() == rhs.createdAt() ? 0 : 1);
                                }
                            });
                            chatRecycleAdapter.notifyItemRangeInserted(0, messageDataList.size() - previousMessageListSize);
                        }

                        offset += LIMIT_SIZE;
                        isLoading = false;
                    }

                    @Override
                    public void onException(long var1, String var2) {
                        chatRecycleAdapter.notifyDataSetChanged();
                        cellInputGroup.setVisibility(View.VISIBLE);
                        isLoading = false;
                    }
                }, Long.parseLong(receiverId), offset, LIMIT_SIZE);
    }

    private void createWukongConversation() {
        //加载悟空消息
        ConversationService conversationService = IMEngine.getIMService(ConversationService.class);
        conversationService.createConversation(new com.alibaba.wukong.Callback<com.alibaba.wukong.im.Conversation>() {
            @Override
            public void onSuccess(com.alibaba.wukong.im.Conversation conversation) {
                wukongSender.setConversation(conversation);
            }

            @Override
            public void onException(String s, String s1) {

            }

            @Override
            public void onProgress(com.alibaba.wukong.im.Conversation conversation, int i) {

            }
        }, null, null, null, com.alibaba.wukong.im.Conversation.ConversationType.CHAT, Long.parseLong(receiverId));

    }

    private void renderItemInfo(final ChatDO chatDO) {
        //说明是宝贝或订单
        if (chatDO.getItemId() != null) {
            itemPrice.setText(chatDO.getItemPrice());
            itemTitle.setText(getString(R.string.label_i_can) + " " + chatDO.getItemTitle());
            ViewGroup.LayoutParams layoutParams = itemImage.getLayoutParams();
            itemImage.setImageURI(Uri.parse(ImgUtil.getCDNUrlWithWidth(chatDO.getItemPic(), layoutParams.width)));
            if (chatDO.getOrderNo() != null) {
                itemBuy.setBackgroundResource(R.drawable.chat_order_status_bg);
                itemBuy.setTextColor(getResources().getColor(R.color.brand_c));
                itemBuy.setText(chatDO.getOrderStatus());

                itemBuy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (chatDO.getOrderNo() != null) {
                            Router.sharedRouter().open("orderdetail/" + chatDO.getOrderNo());
                        } else {
                            Router.sharedRouter().open("order/" + chatDO.getItemId());
                        }
                    }
                });
            } else {
                itemBuy.setBackgroundResource(R.drawable.chat_buy_bg);
                itemBuy.setTextColor(getResources().getColor(R.color.white));

                if (chatDO.getItemOwnerId().equals(Helper.sharedHelper().getUserId())) {
                    if (chatDO.isRemindOrder()) {
                        itemBuy.setText(chatDO.getImStatus());
                        itemBuy.setVisibility(View.VISIBLE);
                        itemBuy.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (System.currentTimeMillis() - lastRemindOrderTime > 60000) {
                                    lastRemindOrderTime = System.currentTimeMillis();
                                    wukongSender.sendReminderMessage(MessageDO.REMIND_MESSAGE_TYPE_REMINDER,
                                            chatDO.getItemOwnerId());
                                } else {
                                    MessageUtils.showToast(R.string.reminder_message_remind_order_too_many);
                                }
                            }
                        });
                    } else {
                        itemBuy.setVisibility(View.GONE);
                    }
                } else {
                    itemBuy.setText("立即预约");
                    itemBuy.setVisibility(View.VISIBLE);
                    itemBuy.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (chatDO.getOrderNo() != null) {
                                Router.sharedRouter().open("orderdetail/" + chatDO.getOrderNo());
                            } else {
                                Router.sharedRouter().open("services/" + chatDO.getItemId());
                            }
                        }
                    });
                }
            }
            itemImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("services/" + chatDO.getItemId());
                }
            });

            itemInfoGroup.setVisibility(View.VISIBLE);
        } else {
            //隐藏头部
            itemInfoGroup.setVisibility(View.GONE);
        }
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(inputEdit.getWindowToken(), 0);
    }

    public void finishSend() {
        inputEdit.setText(null);
        scrollToLast();
    }

    private void scrollToLast() {
        messageReclerView.post(new Runnable() {
            @Override
            public void run() {
                messageReclerView.scrollToPosition(chatRecycleAdapter.getItemCount() - 1);
            }
        });
    }

    private void scrollToPosition(final int position) {
        messageReclerView.post(new Runnable() {
            @Override
            public void run() {
                if (position < chatRecycleAdapter.getItemCount()) {
                    messageReclerView.scrollToPosition(position);
                }
            }
        });
    }

    private void rewardReceiver() {
        randRewardPopupWindow = new RandRewardPopupWindow(ChatActivity.this,
                receiverId, chatDO.getReceiveAvatar());
        randRewardPopupWindow.showScreenCenter(rootView);
        randRewardPopupWindow.setType(Constant.REWARD_TYPE_IM);
        randRewardPopupWindow.setOnRewardListener(new BaseRewardPopupWindow.OnRewardListener() {
            @Override
            public void onRewardFinished(int amount, String desc) {
                if (amount > 0) {
                    wukongSender.sendRewardMessage(amount, desc);
                    finishSend();
                } else {
                    MessageUtils.showToast(R.string.reward_failed);
                }
            }
        });
    }

    class VoiceRecordListener implements RecordView.RecordListener {
        @Override
        public void recordEnd(String filePath, long recordTime) {
            Log.e(LOG_TAG, "record voice end, file = " + filePath + ", record time = " + recordTime);
            wukongSender.sendVoiceMessage(filePath, recordTime);
            finishSend();
        }
    }

    private void updateMessageList(List<Message> messageList) {
        for (Message m : messageList) {
            for (int i = 0; i < messageDataList.size(); i++) {
                if (messageDataList.get(i).equals(m)) {
                    messageDataList.get(i).setReadStatus(m.getReadStatus());
                    break;
                }
            }
        }
        chatRecycleAdapter.notifyDataSetChanged();
    }

    private void addMessageList(List<Message> messageList) {
        for (Message m : messageList) {
            if (!messageDataList.contains(m)) {
                messageDataList.add(m);
            }
        }
        sortAndUpdateMessageList();
        scrollToLast();
    }

    private void sortAndUpdateMessageList() {
        Collections.sort(messageDataList, new Comparator<Message>() {
            @Override
            public int compare(Message lhs, Message rhs) {
                return lhs.createdAt() < rhs.createdAt() ? -1 : (lhs.createdAt() == rhs.createdAt() ? 0 : 1);
            }
        });
        chatRecycleAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean isInterceptTouchEvent() {
        return false;
    }
}
