package com.meidalife.shz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.BroadcastConstant;
import com.meidalife.shz.BuildConfig;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.activity.fragment.BaseTabHostFragment;
import com.meidalife.shz.activity.fragment.DiscoverFragment;
import com.meidalife.shz.activity.fragment.DynamicFragment;
import com.meidalife.shz.activity.fragment.HomeFragment;
import com.meidalife.shz.activity.fragment.MessageFragment;
import com.meidalife.shz.activity.fragment.ProfileFragment;
import com.meidalife.shz.activity.fragment.SquareHomeFragment;
import com.meidalife.shz.bean.TabIndexEnum;
import com.meidalife.shz.event.ConversationEvent;
import com.meidalife.shz.event.DynamicListRefreshEvent;
import com.meidalife.shz.event.type.DynamicRefreshTypeEnum;
import com.meidalife.shz.event.type.ModifyUnReadMsdCountEventModel;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.event.type.TabMaskDisplayEventModel;
import com.meidalife.shz.im.ConversationManager;
import com.meidalife.shz.im.ImClient;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ConversationDO;
import com.meidalife.shz.rest.model.DynamicBottomDO;
import com.meidalife.shz.rest.model.DynamicOutDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.rest.request.RequestMessage;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.util.UpdateUtil;
import com.meidalife.shz.widget.TabManager;
import com.umeng.analytics.MobclickAgent;
import com.umeng.message.UmengRegistrar;
import com.usepropeller.routable.Router;

import java.util.List;
import java.util.Timer;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

public class MainActivity extends BaseTabHostFragment {

    //    private static WeakReference<MainActivity> wrActivity = null;
    private final int MESSAGE_SIGNIN_REQUEST_CODE = 100;
    private final int PUBLISH_REQUEST_CODE = 200;
    private final int PROFILE_SIGNIN_REQUEST_CODE = 300;

    private boolean isSquareSettingChecked = false;

    //    public FragmentTabHost mTabHost;
    public ShareActivity shareActivity;
    @Bind(R.id.guide_index_tab_mask)
    public View tabMask;

    @Bind(R.id.cellPublishComment)
    ViewGroup cellPublishComment;

    @Bind(android.R.id.tabs)
    View tabs;
    //    @Bind(R.id.comment_input_group)
//    View inputViewGroup;
    @Bind(R.id.comment_input_text)
    EditText inputText;
    @Bind(R.id.comment_input_commit)
    TextView inputCommit;


    //    TextView unreadTV;
    int chatUnread = 0;
    int notifyUnread = 0;
    private int index = 0;
    private Timer monitorTimer = new Timer();
    private boolean isPause = false;

    private long exitTime = 0;

    CommentItemListenerImpl msgBoardItemListener;

    private BroadcastReceiver mLocationReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, android.content.Intent intent) {
            int position = intent.getIntExtra("position", 0);
            DynamicOutDO dynamic = (DynamicOutDO) intent.getSerializableExtra("item");
            DynamicBottomDO comment = (DynamicBottomDO) intent.getSerializableExtra("comment");
            switch (intent.getAction()) {
                case BroadcastConstant.COMMENT:
                    msgBoardItemListener.comment(position, dynamic);
                    break;
                case BroadcastConstant.ITEMCLICK:
                    msgBoardItemListener.onItemClick(position, dynamic, comment);
                    break;
                default:
                    checkSquareSetting();
            }
        }
    };

    @Override
    protected int getLayoutResource() {
        return R.layout.activity_main;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 接受外部唤醒

        ButterKnife.bind(this);

        Helper.sharedHelper().setStringUserInfo(Constant.TAG_DEVICE_ID, UmengRegistrar.getRegistrationId(this));

        handleJumpEvent(getIntent());

        //动态初始化留言
        msgBoardItemListener = new CommentItemListenerImpl(this, inputText, cellPublishComment, tabs);
        inputCommit.setOnClickListener(msgBoardItemListener);


        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            if (bundle.getString("index") != null) {
                index = Integer.parseInt(bundle.getString("index"));
            } else {
                index = bundle.getInt("index");
            }
        }

        shareActivity = new ShareActivity(this);

//        wrActivity = new WeakReference<MainActivity>(this);

        // 初始化tab & setCurrentTab
        mTabHost.setCurrentTab(index);

        // 处理蒙版
        tabMask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // do nothing, for show guide
            }
        });
        // 检查更新
        UpdateUtil.getInstance(this).checkUpdate(false);

        EventBus.getDefault().register(this);

        IntentFilter filter = new IntentFilter();
        filter.addAction(AMapLocationManager.LOCATION_BROAD_ACTION);
        filter.addAction(BroadcastConstant.COMMENT);
        filter.addAction(BroadcastConstant.ITEMCLICK);

        LocalBroadcastManager.getInstance(SHZApplication.getInstance()).registerReceiver(mLocationReceiver, filter);

        checkSquareSetting();

        //Log.d("MainActivity", "signatures:" + Helper.getSignature(this, getPackageName()));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleJumpEvent(intent);
    }


    private void handleJumpEvent(Intent intent) {
        try {
            String scheme = intent.getScheme();
            if (!TextUtils.isEmpty(scheme)) {
                Uri uri = intent.getData();

                if (uri != null) {
                    String dataString = intent.getDataString();
                    String host = uri.getHost();
                    String path = uri.getPath();
                    //网页跳转
                    if ("go".equals(host) && !TextUtils.isEmpty(uri.getLastPathSegment())) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", uri.getLastPathSegment());
                        Router.sharedRouter().open("web", bundle);
                    } else {
                        Router.sharedRouter().open(host + path);
                    }
                    Log.e(MainActivity.class.getName(), "dataString:" + dataString + ", host:" + host + ", path:" + path);
                }

            }
            Bundle bundle = intent.getExtras();
            if (null != bundle && "payResult".equals(bundle.getString("from"))) {
                mTabHost.setCurrentTab(index);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void initTab() {
        String locationCityName = SHZApplication.getInstance().getLocationManager().getLocation().getCityName();
        mTabManager.addTab(getTabSpecView("home", R.layout.tab_item_home), HomeFragment.class, null);

        if (((!TextUtils.isEmpty(locationCityName) && Helper.sharedHelper().getBooleanUserInfo(Constant.LOCATION_SQUARE_ENABLED, true)))) {
            //定位到城市时，以定位城市决定是否显示格子
            mTabManager.addTab(getTabSpecView("discover", R.layout.tab_item_square), SquareHomeFragment.class, null);
        } else if ((!TextUtils.isEmpty(Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE)))
                && Helper.sharedHelper().getBooleanUserInfo(Constant.SELECT_CITY_SQUARE_ENABLED, true)) {
            //未定位到城市或者定位城市格子关闭时，以首选城市决定是否显示格子
            mTabManager.addTab(getTabSpecView("discover", R.layout.tab_item_square), SquareHomeFragment.class, null);
        } else {
            mTabManager.addTab(getTabSpecView("discover", R.layout.tab_item_discover), DiscoverFragment.class, null);
        }

//        mTabManager.addTab(getTabSpecView("publish", R.layout.tab_item_publish), BaseFragment.class, null);
        mTabManager.addTab(getTabSpecView("dynamic", R.layout.tab_item_dynamic), DynamicFragment.class, null);
        mTabManager.addTab(getTabSpecView("message", R.layout.tab_item_message), MessageFragment.class, null);
        mTabManager.addTab(getTabSpecView("profile", R.layout.tab_item_profile), ProfileFragment.class, null);
        mTabManager.setOnTabChangListener(new TabManager.OnTabChangListener() {
            @Override
            public boolean change(String tabId, TabManager.TabInfo tabInfo) {
                return false;
            }
        });
        mTabHost.getTabWidget().setDividerDrawable(R.color.grey_b);

//        mTabHost.getTabWidget().getChildTabViewAt(TabIndexEnum.PUBLISH_TAB_INDEX.value).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                cellPublish.setVisibility(View.VISIBLE);
//            }
//        });

        mTabHost.getTabWidget().getChildTabViewAt(TabIndexEnum.MESSAGE_TAB_INDEX.value).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    mTabHost.setCurrentTab(TabIndexEnum.MESSAGE_TAB_INDEX.value);
                } else {
                    Router.sharedRouter().openFormResult("signin", MESSAGE_SIGNIN_REQUEST_CODE, MainActivity.this);
                }
            }
        });
        mTabHost.getTabWidget().getChildTabViewAt(TabIndexEnum.PROFILE_TAB_INDEX.value).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    mTabHost.setCurrentTab(TabIndexEnum.PROFILE_TAB_INDEX.value);
                } else {
                    Router.sharedRouter().openFormResult("signin", PROFILE_SIGNIN_REQUEST_CODE, MainActivity.this);
                }
            }
        });
        mTabHost.getTabWidget().getChildTabViewAt(TabIndexEnum.COIN_TAB_INDEX.value).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTabHost.setCurrentTab(TabIndexEnum.COIN_TAB_INDEX.value);
            }
        });
//        mTabHost.setCurrentTab(0);
    }

    public void onEventMainThread(ConversationEvent event) {
        if (event.eventType == MsgTypeEnum.TYPE_CHAT) {
            ImClient.getImService(ConversationManager.class)
                    .getTotalUnreadCount(new com.meidalife.shz.im.Callback<Integer>() {
                        @Override
                        public void onSuccess(Integer unreadCount) {
                            chatUnread = unreadCount;
                            updateUnreadHighlight();
                        }

                        @Override
                        public void onException(long var1, String var2) {

                        }
                    });
        } else if (event.eventType == MsgTypeEnum.TYPE_NOTIFICATION) {
            notifyUnread = event.getUnreadNotificationCount();
            updateUnreadHighlight();
        }
    }

    public void onEventMainThread(ModifyUnReadMsdCountEventModel model) {
        //通知数量更新操作，服务端更新有延迟 通过减减的方式更新数量
        if (model.type.equals(MsgTypeEnum.TYPE_NOTIFICATION)) {
            notifyUnread = notifyUnread - model.msgCount;
            updateUnreadHighlight();
        } else {
            modifyMsgCount();
        }
    }

    public void onEventMainThread(TabMaskDisplayEventModel model) {
        switch (model.type) {
            case VISIBLE:
                tabMask.setVisibility(View.VISIBLE);
                break;
            case GONE:
                tabMask.setVisibility(View.GONE);
                break;
            default:
                break;
        }
    }

    void modifyMsgCount() {
        chatUnread = notifyUnread = 0;
        /**
         * 通知
         */
        if (Helper.sharedHelper().hasToken()) {
            RequestMessage.getConversationList(new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    List<ConversationDO> list = (List<ConversationDO>) result;
                    for (int i = 0; i < list.size(); i++) {
                        ConversationDO c = list.get(i);
                        notifyUnread += c.getUnread();
                    }
                    updateUnreadHighlight();
                }

                @Override
                public void onFailure(HttpError error) {
                    Log.d("MainActivity", error.getMessage());
                }
            });
        }

        ImClient.getImService(ConversationManager.class)
                .getTotalUnreadCount(new com.meidalife.shz.im.Callback<Integer>() {
                    @Override
                    public void onSuccess(Integer unreadCount) {
                        chatUnread = unreadCount;
                        updateUnreadHighlight();
                    }

                    @Override
                    public void onException(long var1, String var2) {

                    }
                });
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        if (monitorTimer != null) {
            monitorTimer.cancel();
            monitorTimer = null;
        }

        if (mTabManager != null) {
            mTabManager.onDestroy();
            mTabManager = null;
        }
        LocalBroadcastManager.getInstance(SHZApplication.getInstance()).unregisterReceiver(mLocationReceiver);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if ((System.currentTimeMillis() - exitTime) > 2000) {
            Toast.makeText(getApplicationContext(), "再按一次退出程序", Toast.LENGTH_SHORT).show();
            exitTime = System.currentTimeMillis();

            if (cellPublishComment.getVisibility() == View.VISIBLE) {
                cellPublishComment.setVisibility(View.GONE);
            }
        } else {
            MobclickAgent.onKillProcess(getApplicationContext());
            super.onBackPressed();
        }
    }

    private void updateUnreadHighlight() {
        try {
            TextView unreadTV = (TextView) findViewById(R.id.unreadHighlight);
            int count = chatUnread + notifyUnread;
            if (unreadTV != null) {
                if (count <= 0) {
                    unreadTV.setVisibility(View.GONE);
                } else {
                    unreadTV.setVisibility(View.VISIBLE);

                    if (count < 100) {
                        unreadTV.setText(String.valueOf(count));
                        unreadTV.setBackgroundResource(R.drawable.unread_highlight_oval);
                    } else {
                        unreadTV.setText("99+");
                        unreadTV.setBackgroundResource(R.drawable.unread_highlight_oval);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Constant.REQUEST_CODE_SIGNIN) {
            if (resultCode == RESULT_CANCELED && BuildConfig.FORCE_REGISTER) {
                finish();
                return;
            }
        }
        if (requestCode == MESSAGE_SIGNIN_REQUEST_CODE) {
            if (Helper.sharedHelper().hasToken()) {
                mTabHost.setCurrentTab(TabIndexEnum.MESSAGE_TAB_INDEX.value);
            }
        } else if (resultCode == Helper.ACTIVITY_RESULT_CODE_BACK) {
            mTabHost.setCurrentTab(0);
        } else if (resultCode == PROFILE_SIGNIN_REQUEST_CODE) {
            if (Helper.sharedHelper().hasToken()) {
                mTabHost.setCurrentTab(TabIndexEnum.PROFILE_TAB_INDEX.value);
            }
        }

        if ((requestCode & 0xffff) == Constant.REQUEST_CODE_PICK_CITY
                && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            String cityName = extras.getString("name");
            boolean openGezi = extras.getBoolean("openGezi");
            if (Helper.sharedHelper().getBooleanUserInfo(Constant.SELECT_CITY_SQUARE_ENABLED, false) ||
                    TextUtils.isEmpty(SHZApplication.getInstance().getLocationManager().getLocation().getCityName())) {
                showSquareTab(openGezi && !TextUtils.isEmpty(cityName));
                Helper.sharedHelper().setBooleanUserInfo(Constant.SELECT_CITY_SQUARE_ENABLED, openGezi);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);

        modifyMsgCount();
        if (BuildConfig.FORCE_REGISTER) {
            if (!Helper.sharedHelper().hasToken()) {
                //   Router.sharedRouter().openFormResult("signin", Constant.REQUEST_CODE_SIGNIN, MainActivity.this);
                Router.sharedRouter().openFormResult("signinFirst", Constant.REQUEST_CODE_SIGNIN, MainActivity.this);
            }
        }
        isPause = false;
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
        isPause = true;
    }

    private void showSquareTab(boolean isShow) {
        if (isFinishing() || (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN && isDestroyed())) {
            return;
        }
        if (isShow) {
            mTabManager.updateSquareTab(getTabSpecView("discover", R.layout.tab_item_square),
                    SquareHomeFragment.class, null, getString(R.string.tab_item_square_text));
        } else {
            mTabManager.updateSquareTab(getTabSpecView("discover", R.layout.tab_item_discover),
                    DiscoverFragment.class, null, getString(R.string.tab_item_discover_text));
        }
    }

    private void checkSquareSetting() {
        if (SHZApplication.getInstance().getLocationManager().getLocation().getLatitude() == 0.0
                || SHZApplication.getInstance().getLocationManager().getLocation().getLatitude() == 0.0
                || isSquareSettingChecked) {
            return;
        }

        JSONObject poiParams = new JSONObject();
        poiParams.put("poiLongitude", "" + SHZApplication.getInstance().getLocationManager().getLocation().getLongitude());
        poiParams.put("poiLatitude", "" + SHZApplication.getInstance().getLocationManager().getLocation().getLatitude());
        poiParams.put("gdCityCode", "" + SHZApplication.getInstance().getLocationManager().getLocation().getCityCode());
        poiParams.put("gdCityName", "" + SHZApplication.getInstance().getLocationManager().getLocation().getCityName());
        HttpClient.get("1.0/city/getCityPage", poiParams, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject data) {
                if (null == data) {
                    return;
                }

                JSONObject cityInfo = data.getJSONObject("city");
                if (cityInfo != null && cityInfo.containsKey("openGezi")) {
                    showSquareTab(cityInfo.getBoolean("openGezi"));
                    Helper.sharedHelper().setBooleanUserInfo(Constant.LOCATION_SQUARE_ENABLED,
                            cityInfo.getBoolean("openGezi"));
                } else {
                    Helper.sharedHelper().setBooleanUserInfo(Constant.LOCATION_SQUARE_ENABLED,
                            false);
                }

                isSquareSettingChecked = true;
            }

            @Override
            public void onFail(HttpError error) {
                Log.d("MainActivity", error.getMessage());
            }
        });
    }


    //动态评论作为全局的input view 实现
    public class CommentItemListenerImpl implements TextView.OnClickListener {

        private InputMethodManager keyboard;

        private View inputViewGroup;
        private EditText inputText;
        private View detailFoot;
        private Context mContext;

        private int position;

        private DynamicOutDO dynamic;
        private DynamicBottomDO comment;


        public CommentItemListenerImpl(Context context, EditText inputText, View inputViewGroup, View detailFoot) {
            this.mContext = context;
            keyboard = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            this.inputText = inputText;
            this.inputViewGroup = inputViewGroup;
            this.detailFoot = detailFoot;
        }

        public void onItemClick(int pos, DynamicOutDO dyn, DynamicBottomDO bottom) {
            position = pos;
            dynamic = dyn;
            //todo 如果没有session 跳转登录 并定位到第三个动态tab
            inputText.setHint(null);
            if (bottom != null) {
                this.comment = bottom;
                inputText.setFocusable(true);
                inputText.setFocusableInTouchMode(true);
                inputText.requestFocus();

                inputText.setHint("回复:" + bottom.getUser().getUserNick());
                keyboard.showSoftInput(inputText, InputMethodManager.SHOW_IMPLICIT);
                inputViewGroup.setVisibility(View.VISIBLE);
                detailFoot.setVisibility(View.GONE);
            } else {
                hideKeyword();
            }
        }

        public void onClick(View v) {
            if (!Helper.sharedHelper().hasToken()) {
                return;
            }

            keyboard.hideSoftInputFromWindow(v.getWindowToken(), 0);
            String content = inputText.getText().toString();

            if (TextUtils.isEmpty(content)) {
                Toast.makeText(mContext, "请输入内容", Toast.LENGTH_LONG).show();
                return;
            }

            addComment(dynamic, comment, content);

            inputText.setText(null);    // 清空数据
            inputText.setHint(null);
            this.dynamic = null;
            this.comment = null;
        }

        public void comment(int pos, DynamicOutDO dyn) {
            position = pos;
            dynamic = dyn;
            inputText.setFocusable(true);
            inputText.setFocusableInTouchMode(true);
            inputText.requestFocus();
            inputText.setHint(null);
            keyboard.showSoftInput(inputText, InputMethodManager.SHOW_IMPLICIT);
            inputViewGroup.setVisibility(View.VISIBLE);
            detailFoot.setVisibility(View.GONE);
        }

        private void hideKeyword() {
            keyboard.hideSoftInputFromWindow(inputText.getWindowToken(), 0);
            inputText.setText(null);
            cellPublishComment.setVisibility(View.GONE);
            detailFoot.setVisibility(View.VISIBLE);
            this.dynamic = null;
            this.comment = null;
        }
    }

    public void handleHideInputView(View view) {
        inputText.setText(null);
        cellPublishComment.setVisibility(View.GONE);
        tabs.setVisibility(View.VISIBLE);
    }

    void addComment(final DynamicOutDO dynamic, final DynamicBottomDO comment, final String content) {

        JSONObject params = new JSONObject();
        params.put("feed_id", dynamic.getFeedId());
        params.put("feed_user_id", dynamic.getUser().getUserId());
        if (comment != null) {
            params.put("reply_user_id", comment.getUser().getUserId());
        }
        params.put("reply_content", content);
        params.put("type", 0);

        RequestDynamic.addComment(params, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                Toast.makeText(MainActivity.this, "发表成功", Toast.LENGTH_SHORT).show();
                cellPublishComment.setVisibility(View.GONE);
                tabs.setVisibility(View.VISIBLE);
                //todo 返回评论对象 更新评论数据
                DynamicBottomDO bottom = new DynamicBottomDO();
                bottom.setContent(content);
                if (comment.getUser() != null) {
                    bottom.setReplyNick(comment.getUser().getUserNick());
                }
                dynamic.getComments().add(0, bottom);
                dynamic.setReplyCount(dynamic.getReplyCount() + 1);

                DynamicListRefreshEvent updateItemEvent = new DynamicListRefreshEvent();
                updateItemEvent.dynamic = dynamic;
                updateItemEvent.typeEnum = DynamicRefreshTypeEnum.TYPE_COMMENT;
                EventBus.getDefault().post(updateItemEvent);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error.toString());
            }
        });
    }
}
