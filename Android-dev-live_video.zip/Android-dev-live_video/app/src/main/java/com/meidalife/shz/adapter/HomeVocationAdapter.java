package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.usepropeller.routable.Router;

/**
 * Created by lanbo on 16/4/22.
 */
public class HomeVocationAdapter extends
        RecyclerViewAdapter<HomeVocationAdapter.Holder> {
    private Context mContext;
    private LayoutInflater mInflater;
    private JSONArray mData;

    public HomeVocationAdapter(Context context, JSONArray data) {
        super(context);
        mContext = context;
        mInflater = LayoutInflater.from(mContext);

        mData = data;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.view_home_item_vocation,
                parent, false);
        Holder holder = new Holder(view);

        holder.draweeView = (SimpleDraweeView) view.findViewById(R.id.drawee_vocation);
        holder.vocationTv = (TextView) view.findViewById(R.id.tv_vocation);
        return holder;
    }

    @Override
    public void onBindViewHolder(Holder holder, final int position) {
        JSONObject json = (JSONObject) mData.get(position);
        String pic = json.getString("pic");
        final String link = json.getString("url");
        String title = json.getString("title");

        if (!TextUtils.isEmpty(pic)) {
            holder.draweeView.setImageURI(Uri.parse(pic));
        }
        holder.vocationTv.setText(title);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onItemClick(position);
                }
                if (!TextUtils.isEmpty(link)) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", link);
                    Router.sharedRouter().open("web", bundle);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mData == null ? 0 : mData.size();
    }


    public void setOnItemClickListener(OnItemClickListener l) {
        mListener = l;
    }

    public static class Holder extends RecyclerView.ViewHolder {
        public Holder(View view) {
            super(view);
        }

        SimpleDraweeView draweeView;
        TextView vocationTv;
    }
}
