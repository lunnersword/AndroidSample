package com.meidalife.shz.activity;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ServiceDetailPhotoViewPageAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ScopeOutDO;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.model.UserOutDO;
import com.meidalife.shz.rest.model.UserTagOutDO;
import com.meidalife.shz.rest.request.RequestItem;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;
import com.viewpagerindicator.CirclePageIndicator;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by shijian on 15/8/2.
 * <p/>
 * update by zuozheng on 16/3/22 跟商品详情统一视觉
 */
public class ServiceSnapshotActivity extends BaseActivity implements ViewPager.OnPageChangeListener {

    private LayoutInflater inflater;
    private Context context;

    @Bind(R.id.root_view)
    ViewGroup rootView;
    @Bind(R.id.content_root_view)
    View contentRoot;


    @Bind(R.id.adViewLayout)
    ViewGroup adViewLayout;
    @Bind(R.id.adViewpager)
    ViewPager adViewPager;
    @Bind(R.id.adViewIndicator)
    CirclePageIndicator adViewIndicator;

    @Bind(R.id.detail_online_status)
    TextView userOnLineStatusView;
    @Bind(R.id.detail_user_nick)
    TextView userNickView;
    @Bind(R.id.detail_user_avatar)
    ImageView userAvatar;
    @Bind(R.id.detail_sex_icon)
    TextView sexIcon;
    @Bind(R.id.detail_user_tag)
    LinearLayout userTagView;
    @Bind(R.id.detail_real_name_auth_status)
    TextView realNameAuthStatus;
    @Bind(R.id.detail_zm_level)
    TextView zmLevel;
    @Bind(R.id.detail_skill_tv)
    TextView skillAuth;

    @Bind(R.id.sellCountText)
    TextView sellCountText;
    @Bind(R.id.itemStockView)
    TextView itemStockText;
    @Bind(R.id.detail_skill_group)
    View detail_skill_group;
    @Bind(R.id.servicePriceLayout)
    ViewGroup servicePriceLayout;

    @Bind(R.id.earnestLayout)
    ViewGroup earnestLayout;
    @Bind(R.id.earnestValue)
    TextView earnestValue;
    @Bind(R.id.earnestPayLink)
    TextView earnestPayLink;
    @Bind(R.id.finalPayAmount)
    TextView finalPayAmount;
    @Bind(R.id.earnestDetailLayout)
    ViewGroup earnestDetailLayout;
    @Bind(R.id.earnestPrice)
    TextView earnestPrice;
    @Bind(R.id.earnestOriPrice)
    TextView earnestOriPrice;
    @Bind(R.id.finalPayTime)
    TextView finalPayTime;

    private String itemId;
    private String snapshotId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_snapshot);


        //初始化action bar
        initActionBar("商品快照", true, false);

        context = getApplicationContext();
        inflater = getLayoutInflater();


        Bundle extra = getIntent().getExtras();
        itemId = extra.getString("itemId");
        snapshotId = extra.getString("snapshotId");

        initView();
        initLoadData();
    }

    void initView() {
        ButterKnife.bind(this);
    }


    public void initLoadData() {

        loadPre(rootView, contentRoot);

        RequestItem.get(itemId, snapshotId, new HttpClient.HttpCallback<ServiceItem>() {
            @Override
            public void onSuccess(ServiceItem result) {
                loadSuccess(contentRoot);
                renderItem(result);
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(ServiceDetailActivity.class.getName(), "req item data fail, itemId=" + itemId + ", " + error.toString());
                loadFail(error, rootView, ServiceSnapshotActivity.this, new LoadCallback() {
                    @Override
                    public void execute() {
                        initLoadData();
                    }
                });
            }
        });

    }

    public void renderItem(final ServiceItem item) {

        //设置action bar 为卖家名字
        //todo 最新销量 增加右侧滑入和滑出消失动画
        renderLastSell(item);


        //todo 图片处理 采用recylerview + adapter 实现
        renderPhotoView(item);

        renderSellerView(item);

        renderItemView(item);


        TextView snapshotLatest = (TextView) findViewById(R.id.snapshot_latest);
        snapshotLatest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Router.sharedRouter().open("services/" + itemId);
            }
        });
    }

    void renderLastSell(ServiceItem item) {
        final LinearLayout latestSellGroup = (LinearLayout) findViewById(R.id.detail_latest_sell_ll);

        TextView latestSell = (TextView) findViewById(R.id.detail_latest_sell);
        Long latestOrderTime = item.getLatestOrderTime();
        if (latestOrderTime != null) {
            long offset = System.currentTimeMillis() / 1000 / 60 - latestOrderTime / 60;
            if (offset < 60) {
                latestSell.setText(offset + "分钟前卖出一笔");
            } else if (offset < (60 * 24)) {
                latestSell.setText((offset / 60) + "小时前卖出一笔");
            } else {
                latestSell.setText("一天前卖出一笔");
            }

            //最后一笔买家头像
            SimpleDraweeView lastBuyerAvatar = (SimpleDraweeView) findViewById(R.id.detail_latest_buyer_avatar);
            String avatarUrl = ImgUtil.getCDNUrlWithWidth(item.getLatestOrderUserAvatar(), lastBuyerAvatar.getLayoutParams().width);
            if (!TextUtils.isEmpty(avatarUrl)) {
                lastBuyerAvatar.setImageURI(Uri.parse(avatarUrl));
            }

            latestSellGroup.setAlpha(0f);
            latestSellGroup.setVisibility(View.VISIBLE);


        } else {
            latestSellGroup.setVisibility(View.GONE);
        }
    }


    void renderPhotoView(final ServiceItem item) {
        if (CollectionUtil.isEmpty(item.getImages())) {
            adViewLayout.setVisibility(View.GONE);
            return;
        }

        ServiceDetailPhotoViewPageAdapter adViewPageAdapter = new ServiceDetailPhotoViewPageAdapter(this, item.getImages());
        adViewPager.setAdapter(adViewPageAdapter);
        adViewIndicator.setViewPager(adViewPager);
        adViewLayout.setVisibility(View.VISIBLE);
        adViewIndicator.setOnPageChangeListener(this);
    }

    void renderSellerView(ServiceItem item) {

        final UserOutDO seller = item.getUser();
        if (seller != null) {
            if (TextUtils.isEmpty(seller.getUserAvatar())) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(seller.getUserId()), seller.getUserGender());
                userAvatar.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(seller.getUserAvatar(), userAvatar.getLayoutParams().width));
                userAvatar.setImageURI(uri);
            }

            if (!TextUtils.isEmpty(seller.getOnLineInfo())) {
                userOnLineStatusView.setText(seller.getOnLineInfo());
                userOnLineStatusView.setVisibility(View.VISIBLE);
            }

            userNickView.setText(seller.getUserName());

            if (seller.getUserGender() == null) {
                sexIcon.setVisibility(View.GONE);
            } else {
                if (seller.getUserGender().equals("woman") || seller.getUserGender().equals("F")) {
                    sexIcon.setText(context.getResources().getString(R.string.icon_gender_f));
                    sexIcon.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    sexIcon.setText(context.getResources().getString(R.string.icon_gender_m));
                    sexIcon.setTextColor(getResources().getColor(R.color.brand_i));
                }
            }

            //todo 城市 星座 个性标签
            try {
                if (CollectionUtil.isNotEmpty(seller.getUserTags())) {
                    for (UserTagOutDO tag : seller.getUserTags()) {
                        View tagView = getLayoutInflater().inflate(R.layout.service_detail_user_tag, null);
                        TextView tabText = (TextView) tagView.findViewById(R.id.user_tag_text);
                        if (!TextUtils.isEmpty(tag.getText())) {
                            tabText.setText(tag.getText());
                            tabText.setBackgroundColor(Color.parseColor(tag.getBgColor()));
                            userTagView.addView(tabText);
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("userTagParseError", e.getMessage());
            }

            //设置用户实名认证状态和技能认证状态
            if (seller.getRealNameCert() == 1) {
                realNameAuthStatus.setText("已实名认证");
            } else {
                realNameAuthStatus.setText("未实名认证");
            }

            if (TextUtils.isEmpty(seller.getZmLevel())) {
                zmLevel.setText("芝麻信用未绑定");
            } else {
                zmLevel.setText("芝麻信用" + seller.getZmLevel());
            }

            //todo 个性认证 显示数量问题
            List<String> certList = seller.getCertList();
            if (CollectionUtil.isNotEmpty(certList)) {
                skillAuth.setText(certList.get(0).toString());
                detail_skill_group.setVisibility(View.VISIBLE);
            }
        }
    }

    private void setServiceDate(ServiceItem item) {
        try {
            Calendar nextServiceTime = Calendar.getInstance();
            nextServiceTime.setTimeInMillis(item.getNextServiceTime());
            int serviceDay = nextServiceTime.get(Calendar.DAY_OF_YEAR);

            Calendar current = Calendar.getInstance();
            current.setTime(new Date());
            int currentDay = current.get(Calendar.DAY_OF_YEAR);

            TextView canTime = (TextView) findViewById(R.id.detail_can_time);
            canTime.setText(item.getReadableNextServiceTime() + "起有空");

            if (nextServiceTime.get(Calendar.YEAR) == current.get(Calendar.YEAR)) {
                if (serviceDay == currentDay) {
                    canTime.setText(getString(R.string.today_avilable));
                } else if ((serviceDay - currentDay) == 1) {
                    canTime.setText(getString(R.string.tomorrow_avilable));
                } else if ((serviceDay - currentDay) == 2) {
                    canTime.setText(getString(R.string.the_day_after_tomorrow_avilable));
                }
            } else {
                currentDay -= getMaxYear();
                if ((serviceDay - currentDay) == 1) {
                    canTime.setText(getString(R.string.tomorrow_avilable));
                } else if ((serviceDay - currentDay) == 2) {
                    canTime.setText(getString(R.string.the_day_after_tomorrow_avilable));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int getMaxYear() {
        Calendar cd = Calendar.getInstance();
        cd.set(Calendar.DAY_OF_YEAR, 1);// 把日期设为当年第一天
        cd.roll(Calendar.DAY_OF_YEAR, -1);// 把日期回滚一天。
        int MaxYear = cd.get(Calendar.DAY_OF_YEAR);
        return MaxYear;
    }

    void renderItemView(final ServiceItem item) {
        //商品名称
        TextView serviceTitleView = (TextView) findViewById(R.id.detail_service_title);
        serviceTitleView.setText(getString(R.string.label_i_can) + item.getTag());

        renderPriceLayout(item);

        // 评分
//        TextView judgeStar = (TextView) findViewById(R.id.detail_judge_star);
//        judgeStar.setText(item.getGrade() + "星");
        ViewGroup starGroup = (ViewGroup) findViewById(R.id.detail_judge_star_icon_group);
        View starsView = inflater.inflate(R.layout.activity_sku_service_detail_stars, null);
        View starsRed = starsView.findViewById(R.id.star_red_group);
        starsRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, context) * item.getGrade() / 5);
        starGroup.removeAllViews();
        starGroup.addView(starsView);

        //销量 库存
        sellCountText.setText(String.format(getString(R.string.sell_count), item.getSellCount()));

        //todo 促销商品 显示促销库存  否者正式库存
        if (item.isServiceCapacity() && item.getQuantitySum() > 0) {
            itemStockText.setText(String.format(getString(R.string.item_stock), item.getQuantitySum()));
        }

        //服务描述
        TextView content = (TextView) findViewById(R.id.detail_service_desc);
        content.setText(item.getContent());

        //距离 服务时间 可用m豆 红包说明
        View locationGroup = findViewById(R.id.detail_location_group);
        TextView location = (TextView) findViewById(R.id.detail_location);
        if (item.getDistance() == null) {
            locationGroup.setVisibility(View.GONE);
        } else {
            locationGroup.setVisibility(View.VISIBLE);
            location.setText("相距" + item.getDistance());
        }

        setServiceDate(item);

        View canMcoinGroup = findViewById(R.id.detail_can_mcoin_group);
        if (item.getPointSupport() == 1) {
            TextView canMcoin = (TextView) findViewById(R.id.detail_can_mcoin);
            canMcoin.setText("可用M豆");
        } else {
            canMcoinGroup.setVisibility(View.GONE);
        }

        View redPackSupportLayout = findViewById(R.id.redPackSupportLayout);
        if (item.getRedpackSupport()) {
            TextView canUseRed = (TextView) findViewById(R.id.redPackSupport);
            canUseRed.setText("可用红包");
        } else {
            redPackSupportLayout.setVisibility(View.GONE);
        }

        //todo 跳转到服务属性 待实现
        ViewGroup serviceScopeViewGroup = (ViewGroup) findViewById(R.id.detail_service_scope_group);
        ViewGroup detailServiceScopeLL = (ViewGroup) findViewById(R.id.detail_service_scope_ll);
        View serviceScopeRightIcon = findViewById(R.id.detail_service_scope_right);

        List<ScopeOutDO> scopeList = item.getItemScope();
        if (CollectionUtil.isNotEmpty(scopeList)) {
            int maxCount = Math.min(3, scopeList.size());
            if (maxCount >= 3) {
                serviceScopeRightIcon.setVisibility(View.VISIBLE);
                scopeList = scopeList.subList(0, maxCount);
                serviceScopeViewGroup.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("service", item);
                        Router.sharedRouter().open("attribute", bundle);
                    }
                });
            }

//            detailServiceScopeLL.removeAllViews();
            for (ScopeOutDO scope : scopeList) {
                View scopeView = inflater.inflate(R.layout.service_detail_scope, null);
                TextView keyText = (TextView) scopeView.findViewById(R.id.service_scope_key);
                TextView valueText = (TextView) scopeView.findViewById(R.id.service_scope_value);
                keyText.setText(scope.getName() + "：");
                valueText.setText(scope.getValue());
                detailServiceScopeLL.addView(scopeView);
            }
            serviceScopeViewGroup.setVisibility(View.VISIBLE);
        } else {
            serviceScopeViewGroup.setVisibility(View.GONE);
        }


        //todo 服务方式
        TextView serviceTypeView = (TextView) findViewById(R.id.detail_service_view);
//        TextView typeIcon = (TextView) findViewById(R.id.detail_service_type_icon);
        String serviceTypeValue = "服务方式：";
        switch (item.getServiceType()) {
            case 1:
//                typeIcon.setBackgroundResource(R.mipmap.publish_type_1_active);
                if (!TextUtils.isEmpty(item.getCityName())) {
                    serviceTypeValue = serviceTypeValue + item.getCityName() + "上门";
                } else {
                    serviceTypeValue = serviceTypeValue + "上门";
                }
                break;
            case 2:
//                typeIcon.setBackgroundResource(R.mipmap.publish_type_2_active);
                if (!TextUtils.isEmpty(item.getCityName())) {
                    serviceTypeValue = serviceTypeValue + item.getCityName() + "到店";
                } else {
                    serviceTypeValue = serviceTypeValue + "到店";
                }
                break;
            case 3:
//                typeIcon.setBackgroundResource(R.mipmap.publish_type_3_active);
                serviceTypeValue = serviceTypeValue + "线上";
                break;
            case 4:
//                ((TextView) findViewById(R.id.detail_buy_bt)).setText("立即购买");
//                typeIcon.setBackgroundResource(R.mipmap.publish_type_4_active);
                //根据设置分为 现货邮寄、现做邮寄
                if (item.getIsSpot() == 1) {
                    serviceTypeValue = serviceTypeValue + "邮寄(现做)";
                } else {
                    serviceTypeValue = serviceTypeValue + "邮寄(定制)";
                }
                break;
        }
        serviceTypeView.setText(serviceTypeValue);


        // 服务地址，仅到店显示
//        View addressGroup = findViewById(R.id.detail_address_group);
//        TextView detailAddressValue = (TextView) findViewById(R.id.detail_address_value);
//        if (item.getAddressName() == null) {
//            addressGroup.setVisibility(View.GONE);
//        } else {
//            addressGroup.setVisibility(View.VISIBLE);
//            detailAddressValue.setText(item.getAddressName());
//        }

        //格子
        View squareGroup = findViewById(R.id.detail_square_group);
        TextView detailSquareValue = (TextView) findViewById(R.id.detail_square_name);

        if (item.getNearestGezi() == null) {
            squareGroup.setVisibility(View.GONE);
        } else {
            squareGroup.setVisibility(View.VISIBLE);
            squareGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("squareindex/" + item.getNearestGezi().getGeziId());
                }
            });

            detailSquareValue.setText("该服务来自 " + item.getNearestGezi().getGeziName());
        }

        TextView skuTitleView = (TextView) findViewById(R.id.detail_sku_name);

        if (!TextUtils.isEmpty(item.getSkuTitle())) {
            skuTitleView.setText(item.getSkuTitle());
        }
    }

    private void renderPriceLayout(final ServiceItem item) {
        //特大活动标识
        SimpleDraweeView bigPromotionIcon = (SimpleDraweeView) findViewById(R.id.bigPromotionIcon);
        if (!TextUtils.isEmpty(item.getBigPromotionIcon())) {
            bigPromotionIcon.setVisibility(View.VISIBLE);
            bigPromotionIcon.setImageURI(Uri.parse(item.getBigPromotionIcon()));
        }

        if (!TextUtils.isEmpty(item.getEarnest())) {
            earnestLayout.setVisibility(View.VISIBLE);
            earnestDetailLayout.setVisibility(View.VISIBLE);
            earnestValue.setText(item.getEarnest());

            if (TextUtils.isEmpty(item.getPromotionPrice())) {
                earnestPrice.setText(String.format(getString(R.string.earnest_price), item.getPrice()));
                earnestOriPrice.setVisibility(View.GONE);
            } else {
                earnestPrice.setText(String.format(getString(R.string.earnest_price), item.getPromotionPrice()));
                earnestOriPrice.setVisibility(View.VISIBLE);
                earnestOriPrice.setText(item.getPrice());
                earnestOriPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
            }
            earnestPayLink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", item.getPresellTip());
                    Router.sharedRouter().open("web", bundle);
                }
            });
            finalPayTime.setText(String.format(getString(R.string.final_pay_time), item.getFinalPayTime()));
            finalPayAmount.setText(String.format(getString(R.string.final_pay_amount), item.getFinalPay()));
            servicePriceLayout.setVisibility(View.GONE);


        } else {
            earnestDetailLayout.setVisibility(View.GONE);
            earnestLayout.setVisibility(View.GONE);
            servicePriceLayout.setVisibility(View.VISIBLE);


            //促销活动标识
            TextView promotionTag = (TextView) findViewById(R.id.detail_promotion_tag);
            TextView price = (TextView) findViewById(R.id.detail_price);
            TextView oriPrice = (TextView) findViewById(R.id.detail_origin_price);
            if (TextUtils.isEmpty(item.getPromotionPrice())) {
                price.setText(String.format(getString(R.string.tail_yuan), item.getPrice()));
            } else {
                promotionTag.setVisibility(View.VISIBLE);
                price.setText(String.format(getString(R.string.tail_yuan), item.getPromotionPrice()));
                oriPrice.setText(String.format(getString(R.string.tail_yuan), item.getPrice()));
                oriPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
                oriPrice.setVisibility(View.VISIBLE);
            }

        }

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
