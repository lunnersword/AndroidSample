package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.activity.fragment.AddressLocationFragment;
import com.meidalife.shz.adapter.FragmentTabAdapter;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressTypeOutDO;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.PositionOutDO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.widget.SlidingTabLayout;
import com.usepropeller.routable.Router;

import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 定位成功，显示用户周边推荐地址
 * Created by zhq on 15/12/20.
 */
public class AddressLocationActivity extends BaseMapActivity implements
        AMap.OnCameraChangeListener, AMap.OnMarkerClickListener {

    private final static String TAG = "AddressLocation";

    @Bind(R.id.locationLayout)
    ViewGroup locationLayout;
    @Bind(R.id.locationValue)
    TextView locationValue;
    @Bind(R.id.searchBar)
    ViewGroup searchBar;

    @Bind(R.id.rootView)
    RelativeLayout rootView;

    @Bind(R.id.backButton)
    View backButton;

    @Bind(R.id.location_position)
    View mImageArrow;
    @Bind(R.id.location_icon)
    View locationView;

    @Bind(R.id.slidingTab)
    SlidingTabLayout slidingTab;
    @Bind(R.id.tabViewPager)
    ViewPager tabViewPager;

    private FragmentTabAdapter categoryPagerAdapter;

    private HashMap<Integer, AddressLocationFragment> fragMap = new HashMap<>();

    boolean isLoading = false;
//    private boolean isComplete = false;
//    private boolean mRefresh = false;

    Marker mMarker;
    private AMapLocationManager mLocationManager;
    private boolean needLocation = false;
    LocationDO mLocation = new LocationDO();
    LocationDO mCurrentLocation = new LocationDO();

//    private LoadUtil mLoadUtil;

//    private static final int PAGE_SIZE = 20;
//    //开始页数为1
//    int page = 0;

    private LatLng mLastPosition;

//    ArrayList<CityDO> cityList = null;

    List<AddressTypeOutDO> poiList;

    @Override
    public int getLayoutResource() {
        return R.layout.activity_address_location;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ButterKnife.bind(this);

        initListener();

//        mLoadUtil = new LoadUtil(getLayoutInflater());
        initLocationData();

        executeLocationMethod();
//        EventBus.getDefault().register(this);
    }

    void initLocationData() {
        mLocationManager = SHZApplication.getInstance().getLocationManager();
        mLocation = mLocationManager.getLocation();
    }

    void executeLocationMethod() {
        if (mLocation != null && mLocation.getLongitude() > 0) {
            mCurrentLocation.setCityCode(mLocation.getCityCode());
            mCurrentLocation.setCityName(mLocation.getCityName());
            mCurrentLocation.setLongitude(mLocation.getLongitude());
            mCurrentLocation.setLatitude(mLocation.getLatitude());
            addMark(mCurrentLocation.getLongitude(), mCurrentLocation.getLatitude(), "", "", true);

            updateLBSInfo(mCurrentLocation);
            loadTabData();
        } else {
            needLocation = true;
            getCurrentLbsLocation();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }


    @Override
    protected void onSetUpAMap() {
        super.onSetUpAMap();
        aMap.getUiSettings().setZoomControlsEnabled(false);
        aMap.setOnCameraChangeListener(this);

    }

    void getCurrentLbsLocation() {
        mLocationManager.updateLocation(mLocationChangedListener);
    }

    private AMapLocationManager.LocationChangedListener mLocationChangedListener = new AMapLocationManager.LocationChangedListener() {

        @Override
        public void onLocationUpdateFailed() {
            needLocation = true;
            updateLBSInfo(null);
        }

        @Override
        public void onLocationChanged(LocationDO location) {
            //mLocation = location;
            if (location != null && location.getLongitude() > 0) {

                mCurrentLocation.setCityCode(location.getCityCode());
                mCurrentLocation.setCityName(location.getCityName());
                mCurrentLocation.setLongitude(location.getLongitude());
                mCurrentLocation.setLatitude(location.getLatitude());

                updateLBSInfo(location);
                loadTabData();
            }

//            mCurLongitude = location.getLongitude();
//            mCurLatitude = location.getLatitude();
//            mCityCode = location.getCityCode();

            //定位成功 重新请求数据

            if (needLocation) {
                needLocation = false;
            }

            LatLng currentLln = new LatLng(location.getLatitude(), location.getLongitude());
            if (mMarker != null) {
//                mMarker.remove();
                mMarker.setPosition(currentLln);
            }
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
            aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        }
    };

    void updateLBSInfo(LocationDO location) {
        if (location != null) {
            locationValue.setText(location.getCityName());
        } else {
            locationValue.setText("全国");
        }
    }

    private void initListener() {
        //返回键
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                mLocation = null;
                finish();
            }
        });

        //切换城市viewGroup
        locationLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //todo jump to select city for square
                Router.sharedRouter().openFormResult("pick/city", Constant.REQUEST_CODE_PICK_CITY, AddressLocationActivity.this);
            }
        });
        //搜索Group
        searchBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("cityCode", mCurrentLocation.getCityCode());
                bundle.putString("lng", "" + mCurrentLocation.getLongitude());
                bundle.putString("lat", "" + mCurrentLocation.getLatitude());

                Router.sharedRouter().openFormResult("searchaddresssquare", bundle, Constant.REQUEST_CODE_PICK_ADDRESS, AddressLocationActivity.this);
            }
        });

        locationView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mMarker != null) {
                    mMarker.remove();
                }
                executeLocationMethod();
            }
        });


        slidingTab.setOnTabClickListener(new SlidingTabLayout.OnTabClickListener() {
            @Override
            public void onClick(View v, int position, int oldPosition) {
                if (position != oldPosition) {
                    EventBus.getDefault().post(new BaseEvent(MsgTypeEnum.TYPE_REFRESH));
                }

                LogParam param = new LogParam();
                param.setType(LogUtil.TYPE_CUSTOMIZE);
                param.setEid(LogUtil.EVENT_ID_HOME_TAB_CLICK);
                param.setPoid(String.valueOf(position + 1));
                LogUtil.log(param);
            }
        });

        categoryPagerAdapter = new FragmentTabAdapter(getSupportFragmentManager());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mLocationChangedListener = null;
        mLocation = null;
//        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constant.REQUEST_CODE_PICK_CITY) {
            if (resultCode == Activity.RESULT_OK) {
                Bundle bundle = data.getExtras();
                int cityCode = bundle.getInt("code");
                String cityName = bundle.getString("name");
                double lng = bundle.getDouble("lng");
                double lat = bundle.getDouble("lat");

                if (!TextUtils.isEmpty(cityName)) {
                    locationValue.setText(cityName);
                    mCurrentLocation.setCityCode("" + cityCode);
                    mCurrentLocation.setLongitude(lng);
                    mCurrentLocation.setLatitude(lat);
                }

                //todo update location poi && request square list
                updateMarker(mCurrentLocation.getLongitude(), mCurrentLocation.getLatitude());
                loadTabData();
            }
        } else if (requestCode == Constant.REQUEST_CODE_PICK_ADDRESS) {
            if (resultCode == Activity.RESULT_OK) {
                Bundle extras = data.getExtras();
                PositionOutDO mSelectPosition = (PositionOutDO) extras.getSerializable("positionDO");

                Intent intent = new Intent();
                intent.putExtra("positionDO", mSelectPosition);
                setResult(RESULT_OK, intent);
                finish();
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }


    private void loadTabData() {
        isLoading = false;
        xhrTab(false, true);
    }

    private void xhrTab(boolean showLoading, final boolean refresh) {
        if (isLoading) {
            return;
        }
        isLoading = true;

//        if (showLoading) {
//            mLoadUtil.loadPre(rootView, mSwipeRefreshLayout);
//        }

        xhrTabData();
    }

    private void xhrTabData() {
        try {
            HttpClient.get("1.0/address/search", getParamsByPage(), JSONObject.class, callback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private JSONObject getParamsByPage() {
        JSONObject params = new JSONObject();

        try {
            if (mCurrentLocation != null) {
//                params.put("cityCode", mCurrentLocation.getCityCode());
                params.put("poiLongitude", String.valueOf(mCurrentLocation.getLongitude()));
                params.put("poiLatitude", String.valueOf(mCurrentLocation.getLatitude()));

                params.put("keyword", "");
                params.put("offset", "0");
                //type:0 default
                params.put("type", "");
                params.put("tabType", "");
            }
        } catch (JSONException e) {
            params = null;
        }
        return params;
    }

    HttpClient.HttpCallback<JSONObject> callback = new HttpClient.HttpCallback<JSONObject>() {
        @Override
        public void onSuccess(JSONObject jsonObj) {
            try {
                poiList = JSON.parseArray(jsonObj.getString("tabList"), AddressTypeOutDO.class);
                loadTabs(poiList);
            } catch (Exception e) {

            }
            isLoading = false;
        }

        @Override
        public void onFail(HttpError error) {
            MessageUtils.showToast("获取附近地址失败: " + error.getMessage());
            isLoading = false;
        }
    };


    private void loadTabs(List<AddressTypeOutDO> poiList) {
        categoryPagerAdapter.clear();
        fragMap.clear();
        if (CollectionUtil.isNotEmpty(poiList)) {
            for (AddressTypeOutDO cateDO : poiList) {
                AddressLocationFragment addressFrag = AddressLocationFragment.newInstance(cateDO,
                        String.valueOf(mCurrentLocation.getLongitude()), String.valueOf(mCurrentLocation.getLatitude()));
                fragMap.put(cateDO.getTabType(), addressFrag);
                categoryPagerAdapter.addFragment(addressFrag);
            }
        }
        tabViewPager.setAdapter(categoryPagerAdapter);
        categoryPagerAdapter.notifyDataSetChanged();

        slidingTab.setCustomTabView(R.layout.item_category, R.id.categoryName);
        slidingTab.setSelectedIndicatorColors(getResources().getColor(R.color.brand));
        slidingTab.setViewPager(tabViewPager);
        slidingTab.setDividerColors(android.R.color.transparent);
    }

    private void refreshTabs() {
        if (CollectionUtil.isEmpty(poiList)) {
            return;
        }
        for (AddressTypeOutDO cateDO : poiList) {
            AddressLocationFragment addressFrag = fragMap.get(cateDO.getTabType());
            if (addressFrag != null) {
                addressFrag.refresh(String.valueOf(mCurrentLocation.getLongitude()), String.valueOf(mCurrentLocation.getLatitude()));
            }
        }
        categoryPagerAdapter.notifyDataSetChanged();
    }


    private void addMark(Double Longitude, Double Latitude, String descripe, String snippet, boolean isZoom) {

        try {
            LatLng llA = new LatLng(Latitude, Longitude);
            MarkerOptions markerOption = new MarkerOptions();
            markerOption.position(llA);
            markerOption.title(descripe);
            markerOption.snippet(snippet);
            markerOption.anchor(0.5f, 1f);
            markerOption.draggable(true);
            if ("".equals(snippet))
                markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
            else
                markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
            mMarker = aMap.addMarker(markerOption.draggable(true));
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(llA));
            if (isZoom)
                aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateMarker(double Longitude, double Latitude) {

        try {
            LatLng currentLln = new LatLng(Latitude, Longitude);
            if (mMarker != null) {
                mMarker.setPosition(currentLln);
            }
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
            aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCameraChange(CameraPosition cameraPosition) {
        mImageArrow.setVisibility(View.VISIBLE);
    }

    /**
     * 对移动地图结束事件回调
     */
    @Override
    public void onCameraChangeFinish(CameraPosition cameraPosition) {

        TranslateAnimation animation = getVerticalTranslateAnimation();
        mImageArrow.setAnimation(animation);
        animation.startNow();
        onLocationChanged(cameraPosition.target);
    }

    private TranslateAnimation getVerticalTranslateAnimation() {
        TranslateAnimation animation = new TranslateAnimation(0, 0, 0, -20);
        animation.setInterpolator(new DecelerateInterpolator());
        animation.setDuration(200);//设置动画持续时间
        animation.setStartOffset(0);
        animation.setRepeatCount(1);//设置重复次数
        animation.setRepeatMode(Animation.REVERSE);//设置反方向执行
        return animation;
    }

    private void onLocationChanged(LatLng position) {
        if (mLastPosition != null
                && mLastPosition.equals(position)) {
            //Do not search same address again.
            return;
        }
        mLastPosition = position;
        if (mCurrentLocation != null) {
            mCurrentLocation.setLongitude(position.longitude);
            mCurrentLocation.setLatitude(position.latitude);
            //todo 加载数据
            refreshTabs();
        }
    }


    @Override
    public boolean onMarkerClick(Marker marker) {
        if (marker.getPosition().latitude >= 0 && marker.getPosition().longitude >= 0) {
            LatLng currentLln = new LatLng(marker.getPosition().latitude, marker.getPosition().longitude);
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
            aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        }
        return true;
    }
}
