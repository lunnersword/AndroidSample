package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.generic.GenericDraweeHierarchy;
import com.facebook.drawee.generic.GenericDraweeHierarchyBuilder;
import com.facebook.drawee.generic.RoundingParams;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.QRCodeUtil;
import com.meidalife.shz.widget.SocialSharePopupWindow;

import java.io.File;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/10/25.
 */
public class QRCodeCreateActivity extends Activity {
    public static final int QRCODE_TYPE_PAY = 3;
    private int qrCodeSize = 0;
    @Bind(R.id.close)
    TextView iconClose;
    @Bind(R.id.qrCodeShareGroup)
    ViewGroup shareContents;
    @Bind(R.id.shareIcon)
    SimpleDraweeView shareIcon;
    @Bind(R.id.title)
    TextView shareTitle;
    @Bind(R.id.qrCodeContent)
    ImageView qrCodeContent;
    @Bind(R.id.description)
    TextView shareDescription;
    @Bind(R.id.saveImageLayout)
    ViewGroup saveImageLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode_create);
        ButterKnife.bind(this);
        initComponent();
    }

    private void initComponent() {
        String content = getIntent().getStringExtra("content");
        String shareIconUrl = getIntent().getStringExtra("iconUrl");
        String title = getIntent().getStringExtra("title");
        int type = getIntent().getIntExtra("type", 1);

        String cdnUrl = ImgUtil.getCDNUrlWithWidth(shareIconUrl,
                getResources().getDimensionPixelSize(R.dimen.qrcode_size));

        shareTitle.setText(title);

        if (type == SocialSharePopupWindow.SHARE_TYPE_PROFILE) {
            shareDescription.setText(R.string.scan_qrcode_to_follow);
            RoundingParams roundingParams = RoundingParams.asCircle();
            GenericDraweeHierarchyBuilder genericDraweeHierarchyBuilder = GenericDraweeHierarchyBuilder.newInstance(getResources());
            GenericDraweeHierarchy hierarchy = genericDraweeHierarchyBuilder.setRoundingParams(roundingParams).build();
            shareIcon.setHierarchy(hierarchy);
            shareIcon.getHierarchy().setRoundingParams(roundingParams);
            shareIcon.setImageURI(Uri.parse(cdnUrl));
        }
        else if(type == QRCODE_TYPE_PAY){
            shareDescription.setText(R.string.text_qrcode_pay);
            shareIcon.setImageURI(Uri.parse(cdnUrl));
        }
        else {
            shareDescription.setText(R.string.scan_qrcode_to_check);

            shareIcon.setImageURI(Uri.parse(cdnUrl));
        }

        qrCodeSize = getResources().getDimensionPixelSize(R.dimen.qrcode_size);

        iconClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        saveImageLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SaveImageTask().execute();
            }
        });

        if (!TextUtils.isEmpty(content)) {
            new QRCodeGenerateTask().execute(content);
        }
    }

    public class QRCodeGenerateTask extends AsyncTask<String, String, Bitmap> {

        @Override
        protected Bitmap doInBackground(String... params) {
            String content = params[0];

            Bitmap bitmap = QRCodeUtil.createQRImage(content, qrCodeSize, qrCodeSize,
                    BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher));
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (null != bitmap) {
                qrCodeContent.setImageBitmap(bitmap);
            }
        }
    }

    public class SaveImageTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            String imageDir = ImgUtil.getSavedImagePath(QRCodeCreateActivity.this);
            try {
                if (!TextUtils.isEmpty(imageDir)) {
                    String imagePath = ImgUtil.getSavedImagePath(QRCodeCreateActivity.this) + File.separator
                            + "qrcode_" + System.currentTimeMillis() + ".jpg";
                    Bitmap bitmap = ImgUtil.getBitmapFromView(shareContents);

                    if (bitmap != null) {
                        ImgUtil.saveBitmap(bitmap, imagePath);
                        return imagePath;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String imagePath) {
            if (!TextUtils.isEmpty(imagePath)) {
                try {
                    File file = new File(imagePath);
                    if (file.exists()) {
                        Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                        Uri uri = Uri.fromFile(file);
                        intent.setData(uri);
                        sendBroadcast(intent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                MessageUtils.showToast(String.format(getString(R.string.image_saved_in),
                        imagePath), Toast.LENGTH_LONG);
            } else {
                MessageUtils.showToast(getString(R.string.save_image_failed), Toast.LENGTH_LONG);
            }
        }
    }
}
