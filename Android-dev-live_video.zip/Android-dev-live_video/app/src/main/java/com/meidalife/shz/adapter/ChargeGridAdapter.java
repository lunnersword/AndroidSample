package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.meidalife.shz.R;

import java.util.List;

/**
 * Created by lanbo on 16/4/30.
 */
public class ChargeGridAdapter extends CheckableGridAdapter<String> {
    private OnItemSelectedListener mItemSelectedListener;
    public ChargeGridAdapter(Context context, List<String> data) {
        super(context, data, false);
    }

    public void setItemSelectedListener(OnItemSelectedListener l) {
        mItemSelectedListener = l;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.item_grid_charge, null, false);
            convertView.setTag(holder);
            holder.chargeTextView = (TextView) convertView.findViewById(R.id.tv_charge_money);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.chargeTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeState(position);
                notifyDataSetChanged();
                if (mItemSelectedListener != null) {
                    mItemSelectedListener.onSelected(position);
                }
            }
        });

        String content = (String)getItem(position);
        holder.chargeTextView.setText(content);
        holder.chargeTextView.setSelected(isSelected(position));

        return convertView;
    }

    private static class ViewHolder {
        TextView chargeTextView;
    }

    public interface OnItemSelectedListener {
        void onSelected(int position);
    }

}
