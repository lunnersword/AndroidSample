package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ShareBean;
import com.meidalife.shz.util.ShareActivity;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 支付结果页
 * todo 需要完成功能
 * 1 判断支付页面 是否是一元夺宝  1:是 跳转到夺宝支付成功页  2:不是 关闭
 * 2 分享参数确定和分享实现
 * 3 夺宝页地址确定
 */
public class LotteryPayCompleteActivity extends BaseActivity {

    public ShareActivity shareActivity;

    @Bind(R.id.payFinishView)
    TextView finishView;

    @Bind(R.id.gotoLotteryListView)
    View gotoLotteryListView;

    @Bind(R.id.gotoLotteryView)
    View gotoLotteryView;

    ShareBean bean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_lottery_complete);

        ButterKnife.bind(this);

        shareActivity = new ShareActivity(this);

        gotoLotteryListView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //todo  jump to lottery list
                Router.sharedRouter().open("mylottery/all", LotteryPayCompleteActivity.this);
                finish();
            }
        });

        gotoLotteryView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //todo  jump to lottery h5
                finishView(v);
            }
        });

        finishView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(v);
            }
        });


        String url = "http://m.kongge.com/lottery";
        String title = "快约！不要钱？捡来的！空格高端服务待你约！";
//        String nick = Helper.sharedHelper().getStringUserInfo(Constant.USER_NICK);
        String content = "你懂我吗？爱上空格一元抢约，毫无征兆。";

        bean = new ShareBean();
        bean.setUrl(url);
        bean.setTitle(title);
//        bean.setNick(nick);
        bean.setContent(content);
    }

    public void finish(View v) {
        finish();
    }

    public void finishView(View v) {
        Intent intent = new Intent();
        intent.setClass(LotteryPayCompleteActivity.this, WebActivity.class);
        intent.putExtra("url", "http://m.kongge.com/lottery");
        startActivity(intent);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void handleShareCircle(View view) {
        if (bean == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        bean.setShareType(3);
        shareActivity.shareLotteryWith(this, bean);
    }

    public void handleShareWechat(View view) {
        if (bean == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        bean.setShareType(1);
        shareActivity.shareLotteryWith(this, bean);
    }

    public void handleShareSina(View view) {
        if (bean == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        bean.setShareType(4);
        shareActivity.shareLotteryWith(this, bean);
    }

    public void handleShareQQ(View view) {
        if (bean == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        bean.setShareType(2);
        shareActivity.shareLotteryWith(this, bean);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


}
