package com.meidalife.shz.activity.fragment;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.BroadcastConstant;
import com.meidalife.shz.Constant;
import com.meidalife.shz.DynamicActionListener;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.AttentionListener;
import com.meidalife.shz.activity.ReportActivity;
import com.meidalife.shz.activity.RewardDialogActivity;
import com.meidalife.shz.adapter.DynamicAdapter;
import com.meidalife.shz.adapter.DynamicTabAdapter;
import com.meidalife.shz.adapter.RecommendAdapter;
import com.meidalife.shz.adapter.UserAvatarAdapter;
import com.meidalife.shz.event.AttentionUserEvent;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.DynamicListRefreshEvent;
import com.meidalife.shz.event.type.DynamicRefreshTypeEnum;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.im.ImClient;
import com.meidalife.shz.im.NotificationListener;
import com.meidalife.shz.im.NotificationManager;
import com.meidalife.shz.media.PlayMediaService;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicBottomDO;
import com.meidalife.shz.rest.model.DynamicOutDO;
import com.meidalife.shz.rest.model.DynamicTabDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.UserDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.widget.BaseRewardPopupWindow;
import com.meidalife.shz.widget.RandRewardPopupWindow;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.umeng.socialize.media.UMImage;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by zuozheng on 16/3/29.
 * 动态frag
 */
public class DynamicFragment extends BaseFragment implements ViewPager.OnPageChangeListener {
    //默认推荐人列表是展开状态
    private static final int MaxRecommendSize = 3;
    private boolean isListExpanded = true;
    private volatile boolean isPlaying = false;
    private boolean isRecommendLoading = false;
    private boolean isLoading = false;
    private boolean isComplete;
    private int page = 0;
    private static int PAGE_SIZE = 3;

    private DynamicOutDO clickedDynamic;
    Intent playIntent;

    private List<DynamicUserOutDO> mRecommendDataList = new LinkedList<>();
    private List<DynamicUserOutDO> mRankingDataList = new LinkedList<>();
    private List<DynamicUserOutDO> mRecommendDataSource = new LinkedList<>();
    private ArrayList<DynamicTabDO> mTabList = new ArrayList<>();
    private LinkedList<DynamicOutDO> mDynamicDataList = new LinkedList<>();

    private DynamicTabDO mCurrentCate = new DynamicTabDO();

    String bannerUrl;

    private View rootView;
    private View dynamicListFooter;
    private View dynamicListHeader;
    private ProgressBar dynamicFooterLoading;
    private TextView dynamicFooterMessage;
    private Button dynamicFooterReload;
//    private AnimationDrawable loadingAnimation;

    private ViewGroup noMsgView;
    private TextView noMsgTextView;

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;

    @Bind(R.id.myAvatar)
    SimpleDraweeView myAvatar;
    @Bind(R.id.publishDynamicLayout)
    ViewGroup publishDynamicLayout;

    //content view
    @Bind(R.id.contentLayout)
    ViewGroup contentLayout;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.dynamicListView)
    ListView dynamicListView;
    @Bind(R.id.navTabViewTop)
    GridView navTabViewTop;

    ViewGroup newsViewGroup;
    SimpleDraweeView latestReplayUserAvatar;
    TextView newsCountView;

    //Bind header View
    View rankingViewGroup;
    RecyclerView recyclerView;


    View dynamicRecommendActionView;
    TextView dynamicRecommendIconView;
    View recommendHeadView;
    ListView recommendListView;
    GridView navTabView;


    private View recommendListFooter;
    private ProgressBar recommendFooterLoading;
    private TextView recommendFooterRefreshTip;
    private TextView recommendFooterMessage;
    private Button recommendFooterReload;

    private RecommendAdapter mRecommendAdapter;
    private DynamicTabAdapter mTabAdapter;
    private DynamicAdapter mDynamicAdapter;

    private LoadUtil loadUtil;
    private PopupWindow popupWindow;
    private SocialSharePopupWindow socialSharePopupWindow;
    ShareActivity shareActivity;


    // 定义打赏PopupWindow
    private RandRewardPopupWindow mRewardWindow;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        if (rootView == null) {
            initView(inflater, container, savedInstanceState);

            page = 0;
            isComplete = false;
            isLoading = false;
            mRecommendAdapter = new RecommendAdapter(getActivity(), mRecommendDataList);
            mDynamicAdapter = new DynamicAdapter(getActivity(), mDynamicDataList);

            recommendListView.setAdapter(mRecommendAdapter);
            dynamicListView.setAdapter(mDynamicAdapter);

//            mDynamicAdapter.setListView(dynamicListView);//单条更新

            shareActivity = new ShareActivity(getActivity());
            initOnClickListener();

            loadUtil = new LoadUtil(inflater);

            xhrRecommend(true);

            playIntent = new Intent(getActivity(), PlayMediaService.class);
        }

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        return rootView;
    }

    void initOnClickListener() {
        mRecommendAdapter.setOnClickListener(new AttentionListener() {
//            @Override
//            public void cancelFollowClick(String userId, int position) {
//            }

            @Override
            public void addFollowClick(String userId, int position) {
                addAttention(userId);
            }
        });

        mDynamicAdapter.setmListener(new DynamicActionListener() {
            @Override
            public void onAddAttentionClick(String userId) {
                //关注之后
                addAttention(userId);
            }

            @Override
            public void onCommentClick(int position, DynamicOutDO dynamic) {
                //发送输入事件 弹出键盘 并输入内容
                sendCommentBroadcast(position, dynamic);
            }

            @Override
            public void onCommentListItemClick(int position, DynamicOutDO dynamic, DynamicBottomDO comment) {
                sendItemClickBroadcast(position, dynamic, comment);
            }

            @Override
            public void onSupportClick(int position, DynamicOutDO dynamic) {
                supportOrCancel(dynamic);
            }

            @Override
            public void onRewardClick(int position, DynamicOutDO dynamic) {
//                reward(dynamic);
                onClickReward(dynamic);
            }

            @Override
            public void onMoreActionClick(int position, DynamicOutDO dynamic, View view) {
                //显示popup Window 举报或者xx
                initPopupWindowView(position, dynamic, view);
            }

            //todo 实现倒计时
            @Override
            public void startPlayClick(int position, DynamicOutDO dynamic) {
                if (isPlaying) {
                    getActivity().stopService(playIntent);
                }
                playIntent.putExtra(PlayMediaService.INTENT_MEDIA_PLAY, dynamic.getAdditionalInfo().getAudioUrl());
                getActivity().startService(playIntent);
                isPlaying = !isPlaying;
            }

            @Override
            public void stopPlayClick(int position, DynamicOutDO dynamic) {
                getActivity().stopService(playIntent);
            }
        });

        newsViewGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("dynamic_news");

                newsViewGroup.setVisibility(View.GONE);
                newsCountView.setText("");
            }
        });


        ImClient.getImService(NotificationManager.class).addNotificationListener(listener);
    }

    NotificationListener listener = new NotificationListener() {
        @Override
        public void onFeedsUpdate(int feedNumber) {
            for (DynamicTabDO item : mTabList) {
                if (item.getTabId().equals("1")) {
                    item.setCount(feedNumber);
                    break;
                }
            }
            mTabAdapter.notifyDataSetChanged();
        }

        @Override
        public void onAttentionUpdate(int attentionNumber) {
            newsViewGroup.setVisibility(View.VISIBLE);
            newsCountView.setText(String.format("%s个消息", attentionNumber));
        }
    };

    void initPopupWindowView(final int position, final DynamicOutDO dynamic, View view) {
        View popupView = LayoutInflater.from(getActivity()).inflate(R.layout.popup_window_dynamic, null);
        final View leftView = popupView.findViewById(R.id.view_left);
        View rightView = popupView.findViewById(R.id.view_right);
        TextView rightTextView = (TextView) popupView.findViewById(R.id.text_right);

        if (Helper.sharedHelper().getUserId().equals(dynamic.getUser().getUserId())) {
            rightTextView.setText("删除");
        }

        leftView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHideShareList(leftView, dynamic);
                popupWindow.dismiss();
            }
        });

        rightView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().getUserId().equals(dynamic.getUser().getUserId())) {
                    deleteFeed(position, dynamic.getFeedId());
                } else {
                    reportDynamic(dynamic.getFeedId());
                }
                popupWindow.dismiss();
            }
        });

        popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setAnimationStyle(R.style.PopupWindowAnimation);
        popupWindow.showAtLocation(view, Gravity.RIGHT, 0, 175);
    }

    void deleteFeed(final int position, String feedId) {
        JSONObject params = new JSONObject();

        if (!TextUtils.isEmpty(feedId)) {
            params.put("feedId", feedId);
        }

        RequestDynamic.deleteFeed(params, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                //实现列表假删除
                mDynamicDataList.remove(position - 1);
                mDynamicAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    void initView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_dynamic, container, false);

        ButterKnife.bind(this, rootView);
//        timelineActionBar.setVisibility(View.VISIBLE);

        dynamicListHeader = getLayoutInflater(savedInstanceState).inflate(R.layout.fragment_dynamic_header, null);

        rankingViewGroup = dynamicListHeader.findViewById(R.id.rankingViewGroup);
        recyclerView = (RecyclerView) dynamicListHeader.findViewById(R.id.avatar_recycler_view);

        recommendHeadView = dynamicListHeader.findViewById(R.id.dynamic_recommend_group);
        recommendListView = (ListView) dynamicListHeader.findViewById(R.id.recommendListView);
        recommendListFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_dynamic_recommend_list_footer, null);
        recommendFooterLoading = (ProgressBar) recommendListFooter.findViewById(R.id.loading);
        recommendFooterRefreshTip = (TextView) recommendListFooter.findViewById(R.id.refreshTip);
        recommendFooterMessage = (TextView) recommendListFooter.findViewById(R.id.message);
        recommendFooterReload = (Button) recommendListFooter.findViewById(R.id.footerReload);
        recommendFooterLoading.setVisibility(View.GONE);
        recommendFooterMessage.setText("换一换");
        recommendFooterMessage.setTextColor(getResources().getColor(R.color.black));
        recommendListView.addFooterView(recommendListFooter);

        dynamicRecommendActionView = dynamicListHeader.findViewById(R.id.dynamic_recommend_action);
        dynamicRecommendIconView = (TextView) dynamicListHeader.findViewById(R.id.dynamic_recommend_action_icon);
        navTabView = (GridView) dynamicListHeader.findViewById(R.id.navTabView);
        dynamicListView.addHeaderView(dynamicListHeader);

        noMsgView = (ViewGroup) dynamicListHeader.findViewById(R.id.dataEmptyView);
        noMsgTextView = (TextView) dynamicListHeader.findViewById(R.id.dataEmptyTextView);

        newsViewGroup = (ViewGroup) dynamicListHeader.findViewById(R.id.newsViewGroup);
        latestReplayUserAvatar = (SimpleDraweeView) dynamicListHeader.findViewById(R.id.latestReplayUserAvatar);
        newsCountView = (TextView) dynamicListHeader.findViewById(R.id.newsCountView);

        dynamicListFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
        dynamicFooterLoading = (ProgressBar) dynamicListFooter.findViewById(R.id.loading);
        dynamicFooterMessage = (TextView) dynamicListFooter.findViewById(R.id.message);
        dynamicFooterReload = (Button) dynamicListFooter.findViewById(R.id.footerReload);
        dynamicListView.addFooterView(dynamicListFooter);
        dynamicListFooter.setVisibility(View.GONE);

//        dynamicListFooter.setVisibility(View.GONE);


        String avatarUrl = Helper.sharedHelper().getStringUserInfo(Constant.USER_AVATAR);
        if (TextUtils.isEmpty(avatarUrl)) {
            String userId = Helper.sharedHelper().getStringUserInfo(Constant.USER_ID);
            String gender = Helper.sharedHelper().getStringUserInfo(Constant.USER_GENDER);
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(getActivity(), userId, gender);
            myAvatar.setImageURI(getDefaultAvatarUri);
        } else {
            Uri avatarUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, myAvatar.getLayoutParams().width));
            myAvatar.setImageURI(avatarUri);
        }

        myAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open("profile/" + Helper.sharedHelper().getUserId());
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });

        dynamicRecommendActionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击展开按钮 请空推荐数据 并刷新
                pickUpDataOrExpand();
            }
        });

        publishDynamicLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    //跳转到创建动态页面
                    Router.sharedRouter().open("pub_dynamic");
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });

        recommendListFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //刷新数据 实现假的数据刷新 如果内存数据大于3条 不重新请求
//                xhrRecommend(false);
                updateRecommend();
            }
        });

        dynamicFooterReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                xhrDynamic(false);
            }
        });


        dynamicListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        xhrDynamic(false);
                    }
                } else {
                    mSwipeRefreshLayout.setEnabled(true);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (dynamicListView.getFirstVisiblePosition() >= 1) {
                    navTabViewTop.setVisibility(View.VISIBLE);
                } else {
                    navTabViewTop.setVisibility(View.GONE);
                }

            }
        });

        navTabViewTop.setOnItemClickListener(new ItemClickListener());

        navTabView.setOnItemClickListener(new ItemClickListener());

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(false);
                xhrRecommend(true);
            }
        });

        rankingViewGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(bannerUrl)) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", bannerUrl);
                    Router.sharedRouter().open("web", bundle);
                }
            }
        });

    }

    void pickUpDataOrExpand() {
        if (CollectionUtil.isNotEmpty(mRecommendDataList) && isListExpanded) {
            //清空数据 并收起
            mRecommendDataList.clear();
            mRecommendAdapter.notifyDataSetChanged();

            dynamicRecommendIconView.setText(getResources().getText(R.string.icon_arrow_collapse));
            isListExpanded = false;

            recommendListView.removeFooterView(recommendListFooter);
        } else {
//            mRecommendDataList.addAll(mRecommendDataSource);
            updateRecommend();
            recommendListView.addFooterView(recommendListFooter);
            mRecommendAdapter.notifyDataSetChanged();

            dynamicRecommendIconView.setText(getResources().getText(R.string.icon_arrow_expand));
            isListExpanded = true;
        }
    }

    @Override
    public void onDestroy() {
        EventBus.getDefault().unregister(this);
        ImClient.getImService(NotificationManager.class).removeNotificationListener(listener);
        super.onDestroy();
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {
        mSwipeRefreshLayout.setEnabled(state == ViewPager.SCROLL_STATE_IDLE);
    }

    class ItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            if (position < mTabList.size()) {
                mCurrentCate = mTabList.get(position);

                for (DynamicTabDO item : mTabList) {
                    if (item.getTabId().equals(mCurrentCate.getTabId())) {
                        if (item.isSelected()) {
                            continue;
                        } else {
                            item.setSelected(true);
                        }
                    } else {
                        item.setSelected(false);
                    }
                }
                mTabAdapter.notifyDataSetChanged();

                //设置当前tabId
                xhrDynamic(true);
            }
        }
    }

    private void renderRecommendUsers() {
        if (CollectionUtil.isEmpty(mRecommendDataSource)) {
            return;
        }
        mRecommendDataList.clear();
        int end = Math.min(MaxRecommendSize, mRecommendDataSource.size());
        List<DynamicUserOutDO> tmpList = new LinkedList<>();
        tmpList.addAll(mRecommendDataSource.subList(0, end));
        mRecommendDataList.addAll(tmpList);
        mRecommendDataSource.removeAll(tmpList);

        mRecommendAdapter.notifyDataSetChanged();
    }

    private void renderRecommendAfterRequest() {
        if (CollectionUtil.isEmpty(mRecommendDataSource)) {
            recommendListView.setVisibility(View.GONE);
            rankingViewGroup.setVisibility(View.GONE);
            return;
        }

        mRankingDataList.clear();
        rankingViewGroup.setVisibility(View.VISIBLE);
        int maxSize = Math.min(5, mRecommendDataSource.size());
        mRankingDataList.addAll(mRecommendDataSource.subList(0, maxSize));
        List<UserDO> userList = new LinkedList<>();
        for (DynamicUserOutDO user : mRankingDataList) {
            UserDO avatarUser = new UserDO();
            avatarUser.setUserPicUrl(user.getAvatarUrl());
            userList.add(avatarUser);
        }
        showUserAvatar(recyclerView, userList);

        mRecommendDataList.clear();
        recommendListView.setVisibility(View.VISIBLE);

        int end = Math.min(MaxRecommendSize, mRecommendDataSource.size());
        mRecommendDataList.addAll(mRecommendDataSource.subList(0, end));

        mRecommendAdapter.notifyDataSetChanged();

        if (CollectionUtil.isEmpty(mRecommendDataList)) {
            recommendListView.setVisibility(View.GONE);
            recommendHeadView.setVisibility(View.GONE);
        } else {
            recommendListView.setVisibility(View.VISIBLE);
            recommendHeadView.setVisibility(View.VISIBLE);
        }
    }

    public void showUserAvatar(RecyclerView recyclerView, List<UserDO> dataList) {

        recyclerView.removeAllViews();
        if (CollectionUtil.isEmpty(dataList)) {
            recyclerView.setVisibility(View.GONE);
            return;
        }
        recyclerView.setVisibility(View.VISIBLE);

        recyclerView.setHasFixedSize(true);

        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

//        int end = Math.min(userAvatarMaxSize, dataList.size());
//        dataList = dataList.subList(0, end);

        recyclerView.setAdapter(new UserAvatarAdapter(getActivity(), dataList));
    }

    private void renderCategoryTabs(List<DynamicTabDO> tabList) {
        if (CollectionUtil.isEmpty(tabList)) {
            return;
        }

        mTabList.clear();
        mTabList.addAll(tabList);

        mTabAdapter = new DynamicTabAdapter(getActivity(), mTabList);

        navTabViewTop.setNumColumns(tabList.size());
//        navTabViewTop.setPadding(getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin)
//                , 0, getResources().getDisplayMetrics().widthPixels / mTabList.size(), 0);

        navTabView.setNumColumns(tabList.size());
//        navTabView.setPadding(getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin)
//                , 0, getResources().getDisplayMetrics().widthPixels / mTabList.size(), 0);

        navTabViewTop.setAdapter(mTabAdapter);
        navTabView.setAdapter(mTabAdapter);
        mTabAdapter.notifyDataSetChanged();

        //设置“推荐” 默认tab
//        mCurrentCate = tabList.get(0);
        for (DynamicTabDO tab : mTabList) {
            if (tab.isSelected()) {
                mCurrentCate = tab;
                break;
            }
        }
    }

    void updateRecommend() {
        if (mRecommendDataSource.size() < MaxRecommendSize) {
            xhrRecommend(false);
        } else {
            renderRecommendUsers();
        }
    }


    private void renderDynamic(List<DynamicOutDO> dynamicList) {

        if (CollectionUtil.isEmpty(dynamicList) || dynamicList.size() < PAGE_SIZE) {

            isComplete = true;
            dynamicListView.removeFooterView(dynamicListFooter);
        }

        if (CollectionUtil.isNotEmpty(dynamicList)) {
            mDynamicDataList.addAll(dynamicList);
        }

        if (CollectionUtil.isEmpty(mDynamicDataList)) {
            noMsgView.setVisibility(View.VISIBLE);
            switch (mCurrentCate.getTabId()) {
                case "1":
                    noMsgTextView.setText("快去关注牛人吧~");
                    break;
                case "2":
                    noMsgTextView.setText("暂无推荐");
                    break;

                case "3":
                    noMsgTextView.setText("还没有相关直播内容哦~");
                    break;
            }
        } else {
            noMsgView.setVisibility(View.GONE);
        }

        mDynamicAdapter.notifyDataSetChanged();
    }

    //请求推荐数据
    private void xhrRecommend(final boolean refresh) {

        if (isRecommendLoading) {
            return;
        }
        isRecommendLoading = true;

        if (refresh) {
            loadUtil.loadPre(rootLayout, contentLayout);
            mRecommendDataList.clear();
            mRecommendDataSource.clear();
        } else {
            recommendFooterLoading.setVisibility(View.VISIBLE);
            recommendFooterRefreshTip.setVisibility(View.GONE);
            recommendFooterMessage.setText("正在加载");
            recommendFooterMessage.setVisibility(View.VISIBLE);
            recommendFooterReload.setVisibility(View.GONE);
            recommendListFooter.setVisibility(View.VISIBLE);
        }
        JSONObject params = new JSONObject();
        params.put("pageSize", 50);

        HttpClient.searchEnv("1.0/user/recommend", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject object) {
                        isRecommendLoading = false;
                        mSwipeRefreshLayout.setRefreshing(false);

                        if (getActivity() == null || isDetached()) {
                            return;
                        }
                        //模拟tab数据 实现数据切换
                        if (refresh) {
                            loadUtil.loadSuccess(contentLayout);
                            xhrDynamic(true);
                        } else {
                            recommendFooterLoading.setVisibility(View.GONE);
                            recommendFooterRefreshTip.setVisibility(View.VISIBLE);
                            recommendFooterMessage.setText("换一换");
                            recommendFooterMessage.setVisibility(View.VISIBLE);
                            recommendFooterReload.setVisibility(View.GONE);
                            recommendListFooter.setVisibility(View.VISIBLE);
                        }

                        List<DynamicUserOutDO> userList = null;
                        if (object != null && object.containsKey("result")) {
                            JSONObject result = object.getJSONObject("result");
                            if (result != null && result.containsKey("users")) {
                                userList = JSON.parseArray(result.getString("users"), DynamicUserOutDO.class);

                                bannerUrl = result.getString("banners");
                            }
                        }

                        //parse recommend data
                        if (CollectionUtil.isNotEmpty(userList)) {
                            mRecommendDataSource.addAll(userList);
                        }
                        renderRecommendAfterRequest();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        isRecommendLoading = false;
                        mSwipeRefreshLayout.setRefreshing(false);

                        if (getActivity() == null || isDetached()) {
                            return;
                        }
                        if (refresh) {
                            loadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                                @Override
                                public void retry() {
                                    xhrRecommend(true);
                                }
                            });
                        } else {
                            page--;
                            recommendFooterMessage.setVisibility(View.GONE);
                            recommendFooterLoading.setVisibility(View.GONE);
                            if (error != null) {
                                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                                    recommendFooterReload.setText("网络异常，点击重试");
                                } else {
                                    recommendFooterReload.setText(error.getMessage() + "，点击重试");
                                }
                            } else {
                                recommendFooterReload.setText("发生一个未知错误，点击重试");
                            }
                            recommendFooterRefreshTip.setVisibility(View.VISIBLE);
                            recommendListFooter.setVisibility(View.VISIBLE);
                        }
                    }
                }

        );
    }


    private void xhrDynamic(final boolean refresh) {

        if (isLoading) {
            return;
        }
        isLoading = true;

        if (refresh) {
            loadUtil.loadPre(rootLayout, contentLayout);
            mDynamicDataList.clear();
            page = 0;
            isComplete = false;
            dynamicListFooter.setVisibility(View.GONE);
        } else {
            //load more

            if (isComplete) {
                isLoading = false;
                return;
            }

            dynamicFooterMessage.setText("正在加载");
            dynamicFooterMessage.setVisibility(View.VISIBLE);
            dynamicFooterLoading.setVisibility(View.VISIBLE);
            dynamicFooterReload.setVisibility(View.GONE);
            dynamicListFooter.setVisibility(View.VISIBLE);
            page++;
        }

        RequestDynamic.feedList(getParams(), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject json) {
                isLoading = false;
//                mSwipeRefreshLayout.setRefreshing(false);
                if (refresh) {
                    loadUtil.loadSuccess(contentLayout);

                    if (CollectionUtil.isEmpty(mTabList)) {
                        List<DynamicTabDO> tabList = null;
                        if (json != null && json.containsKey("tabList")) {
                            tabList = JSON.parseArray(json.getString("tabList"), DynamicTabDO.class);
                        }
                        renderCategoryTabs(tabList);
                    }
                } else {
                    dynamicListFooter.setVisibility(View.GONE);
                }

                List<DynamicOutDO> dynamicList = null;
                if (json != null && json.containsKey("result")) {
                    dynamicList = JSON.parseArray(json.getString("result"), DynamicOutDO.class);
                }

                renderDynamic(dynamicList);
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
//                mSwipeRefreshLayout.setRefreshing(false);
                if (refresh) {
//                    loadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
//                        @Override
//                        public void retry() {
//                            xhrDynamic(true, tabId);
//                        }
//                    });
                } else {
                    page--;
                    isLoading = false;
                    dynamicFooterMessage.setVisibility(View.GONE);
                    dynamicFooterLoading.setVisibility(View.GONE);
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            dynamicFooterReload.setText("网络异常，点击重试");
                        } else {
                            dynamicFooterReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        dynamicFooterReload.setText("发生一个未知错误，点击重试");
                    }
                    dynamicFooterReload.setVisibility(View.VISIBLE);
                    dynamicListFooter.setVisibility(View.VISIBLE);
                }
            }
        });

    }

    private JSONObject getParams() {
        JSONObject params;
        try {
            params = new JSONObject();

            if (mCurrentCate != null && !TextUtils.isEmpty(mCurrentCate.getTabId())) {
                params.put("tabId", mCurrentCate.getTabId());
            } else {
                params.put("tabId", "");

            }
            params.put("pageSize", String.valueOf(PAGE_SIZE));
            params.put("offset", String.valueOf(page * PAGE_SIZE));
        } catch (Exception e) {
            params = null;
        }

        return params;
    }

    //关注人
    private void addAttention(final String userId) {
        RequestDynamic.addAttention(userId, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                AttentionUserEvent event = new AttentionUserEvent();
                event.userId = userId;
                event.isAttention = true;
                EventBus.getDefault().post(event);
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    void sendCommentBroadcast(int position, DynamicOutDO dynamic) {
        Intent intent = new Intent();
        intent.setAction(BroadcastConstant.COMMENT);
        intent.putExtra("position", position);
        intent.putExtra("item", dynamic);

        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
    }

    void sendItemClickBroadcast(int position, DynamicOutDO dynamic, DynamicBottomDO comment) {
        Intent intent = new Intent();
        intent.setAction(BroadcastConstant.ITEMCLICK);
        intent.putExtra("position", position);
        intent.putExtra("item", dynamic);
        intent.putExtra("comment", comment);

        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
    }

    private void supportOrCancel(final DynamicOutDO dynamic) {
        try {
            JSONObject params = new JSONObject();
            params.put("feedId", dynamic.getFeedId());
            if (dynamic.isSupported()) {
                params.put("type", 1);
            } else {
                params.put("type", 0);
            }

            RequestDynamic.supportOrCancel(params, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {

                }

                @Override
                public void onFail(HttpError error) {
                }
            });
        } catch (Exception e) {
        }
    }

    //弹出打赏popupWindow 如果打赏成功 更新对应adapter=
    private void reward(final DynamicOutDO item) {
        if (Helper.sharedHelper().getUserId().equals(item.getUser().getUserId())) {
            MessageUtils.showToast(R.string.dynamic_reward_self_tip);
        } else {
            clickedDynamic = item;
            Intent intent = new Intent(getActivity(), RewardDialogActivity.class);
            intent.putExtra("receiverId", item.getUser().getUserId());
            intent.putExtra("avatar", item.getUser().getAvatarUrl());
            intent.putExtra("sourceId", item.getFeedId());

            startActivityForResult(intent,
                    Constant.REQUEST_CODE_REWARD);
        }
    }


    public void onEvent(BaseEvent mEvent) {

        if (mEvent instanceof DynamicListRefreshEvent) {
            DynamicListRefreshEvent event = (DynamicListRefreshEvent) mEvent;
            if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isLoading) {
                if ((event.position - 1) >= 0 && (event.position - 1) < mDynamicDataList.size()) {
                    mDynamicAdapter.updateItemData(event.dynamic, event.typeEnum);
                }
            } else if (MsgTypeEnum.TYPE_PUBLISH == event.eventType && !isLoading) {
                //发布动态成功  默认回到关注tab
                if (!"1".equals(mCurrentCate.getTabId())) {
                    for (DynamicTabDO tab : mTabList) {
                        if ("1".equals(tab.getTabId())) {
                            mCurrentCate = tab;
                            mCurrentCate.setSelected(true);
                            break;
                        }
                    }
                    mTabAdapter.notifyDataSetChanged();
                    xhrDynamic(true);
                } else {
                    mDynamicDataList.addFirst(event.dynamic);
                    renderDynamic(mDynamicDataList);
                }
            }
        } else if (mEvent instanceof AttentionUserEvent) {
            AttentionUserEvent event = (AttentionUserEvent) mEvent;
            if (MsgTypeEnum.TYPE_ATTENTION_USER == event.eventType && !isLoading) {
                //关注tab
                if (CollectionUtil.isNotEmpty(mRecommendDataList) && event.isAttention == true) {

                    List<DynamicUserOutDO> tmpList = new LinkedList<>();
                    for (DynamicUserOutDO user : mRecommendDataList) {
                        if (user.getUserId().equals(event.userId)) {
                            tmpList.add(user);
                        }
                    }
                    mRecommendDataList.removeAll(tmpList);


                    if (CollectionUtil.isNotEmpty(mRecommendDataSource)) {
                        DynamicUserOutDO tmp = mRecommendDataSource.get(0);
                        mRecommendDataList.add(tmp);
                        mRecommendDataSource.remove(tmp);
                    }
                    mRecommendAdapter.notifyDataSetChanged();
                }

                if (mRecommendDataSource.size() < MaxRecommendSize) {
                    xhrRecommend(false);
                }

                //全局关注或取消关注事件 更新
                if (CollectionUtil.isNotEmpty(mDynamicDataList)) {
                    for (DynamicOutDO dynamic : mDynamicDataList) {
                        if (dynamic.getUser() != null && dynamic.getUser().getUserId().equals(event.userId)) {
                            dynamic.getUser().setFocused(event.isAttention);
                        }
                    }
                    mDynamicAdapter.notifyDataSetChanged();
                }
            }
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_REWARD && data != null) {
            double rewardAmount = data.getIntExtra("amount", 0);
            boolean result = data.getBooleanExtra(Pay.TAG_PAY_RESULT, false);
            if (result && rewardAmount > 0) {
                clickedDynamic.setBonusCount(rewardAmount / 1000 + clickedDynamic.getBonusCount());
                mDynamicAdapter.updateItemData(clickedDynamic, DynamicRefreshTypeEnum.TYPE_REWARD);
            } else {
                MessageUtils.showToast(R.string.reward_failed);
            }
        }
    }

    private void reportDynamic(String feedId) {
        Intent intent = new Intent();
        intent.setClass(getActivity(), ReportActivity.class);
        intent.putExtra("targetId", feedId);
        intent.putExtra("target", Constant.REPORT_TYPE_DYNAMIC);
        startActivity(intent);
    }

    private void showOrHideShareList(View v, DynamicOutDO dynamic) {
        if (socialSharePopupWindow == null) {
            socialSharePopupWindow = new SocialSharePopupWindow(getActivity(), shareActivity, 0);
        }

        socialSharePopupWindow.setShareUrl(null);
        socialSharePopupWindow.setShareTitle(dynamic.getUser().getUserNick());
        socialSharePopupWindow.setShareDescription(dynamic.getContent());
        socialSharePopupWindow.setShareImage(new UMImage(getActivity(), dynamic.getUser().getAvatarUrl()));

        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }


    // 打赏按钮响应
    void onClickReward(DynamicOutDO dynamic) {
        if (mRewardWindow == null) {
            mRewardWindow = new RandRewardPopupWindow(getActivity(), dynamic.getUser().getUserId());
            mRewardWindow.setOnRewardListener(new BaseRewardPopupWindow.OnRewardListener() {
                @Override
                public void onRewardFinished(int amount, String desc) {
                    // TODO 打赏成功处理
                }
            });
        }
        mRewardWindow.showScreenCenter(rootLayout);
        mRewardWindow.requestRandReward();
    }

}
