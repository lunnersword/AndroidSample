package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ProfileDataListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ProfileDataDO;
import com.meidalife.shz.util.LoadUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujian on 16/4/8.
 */
public class ProfileDataFragment extends BaseFragment {

    private View rootView;
    private int type;
    private String tabTitle;
    private Context context;

    @Bind(R.id.profileDataList)
    ListView profileDataList;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.emptyViewText)
    TextView emptyViewText;
    @Bind(R.id.emptyView)
    View emptyView;

    private ProfileDataListAdapter profileDataListAdapter;
    private List<ProfileDataDO.User> users;
    private LoadUtil loadUtil;
    private final int pageSize = 15;
    private int page;
    private boolean isComplete;
    private boolean isLoading;
    private OnChangeDataCountListener onChangeDataCountListener;

    public static ProfileDataFragment newInstance(Bundle params) {
        ProfileDataFragment profileDataFragment = new ProfileDataFragment();
        profileDataFragment.setArguments(params);
        return profileDataFragment;
    }

    public void setOnChangeDataCountListener(OnChangeDataCountListener onChangeDataCountListener) {
        this.onChangeDataCountListener = onChangeDataCountListener;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_profile_data_list, container, false);
            ButterKnife.bind(this, rootView);
            Bundle bundle = getArguments();
            if (bundle != null) {
                type = bundle.getInt("type", 0);
                tabTitle = bundle.getString("title");
            }
            context = getActivity();
            initEmptyViewText(type);

            loadUtil = new LoadUtil(inflater);
            users = new ArrayList<ProfileDataDO.User>();
            profileDataListAdapter = new ProfileDataListAdapter(context, users);
            profileDataListAdapter.setType(type);
            profileDataListAdapter.setOnFollowListener(new ProfileDataListAdapter.OnFollowListener() {
                @Override
                public void onFollow(int position, boolean isAttention) {
                    handlerFollow(position, isAttention);
                }
            });
            profileDataList.setAdapter(profileDataListAdapter);
            initListener();
        }
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onResume() {
        initData(true);
        super.onResume();
    }

    private void initEmptyViewText(int type){
        switch (type){
            case 0:
                emptyViewText.setText("好高冷，居然没有关注一个人。不信你关注个人给我看看啊！");
                break;
            case 1:
                emptyViewText.setText("别灰心，发发动态，搞搞直播，粉丝涨上来哦");
                break;
            case 2:
                emptyViewText.setText("别灰心，完善服务更抓眼球，销量涨上来哦");
                break;
            case 3:
                emptyViewText.setText("别灰心，发发动态，搞搞直播，访问涨上来哦");
                break;
        }
    }

    private void initListener() {
        profileDataList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        initData(false);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
            }
        });
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                initData(true);
            }
        });
        profileDataList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Router.sharedRouter().open("profile/"+users.get(position).getUserId());
            }
        });
    }

    public void initData(final boolean refresh) {
        if (isLoading)
            return;
        isLoading = true;
        if (refresh) {
            page = 0;
            isComplete = false;
            loadUtil.loadPre(rootLayout, swipeRefreshLayout);
        } else {
            if (isComplete) {
                isLoading = false;
                return;
            }
            page++;
        }
        JSONObject params = new JSONObject();
        params.put("type", type);
        params.put("offset", pageSize * page);
        params.put("pageSize", pageSize);
        HttpClient.get("1.0/user/dataOverView", params, ProfileDataDO.class, new HttpClient.HttpCallback<ProfileDataDO>() {
            @Override
            public void onSuccess(ProfileDataDO obj) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                loadUtil.loadSuccess(swipeRefreshLayout);
                if (refresh)
                    users.clear();
                if (obj != null && obj.getUserData() != null) {
                    users.addAll(obj.getUserData());
                }
                if(obj.getDataViewTabList() != null && obj.getDataViewTabList().size() != 0
                        && onChangeDataCountListener != null){
                    onChangeDataCountListener.onChangeData(obj.getDataViewTabList());
                }
                if (users.size() == 0) {
                    swipeRefreshLayout.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                }
                profileDataListAdapter.notifyDataSetChanged();
                if (obj.getUserData() != null && obj.getUserData().size() < pageSize)
                    isComplete = true;
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                if (!refresh)
                    page--;
                loadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initData(true);
                    }
                });
            }
        });
    }

    private void handlerFollow(final int position, boolean isAttention) {
        JSONObject params = new JSONObject();
        params.put("attentionUserId", users.get(position).getUserId() == null ? "" : users.get(position).getUserId() + "");
        HttpClient.get(isAttention ? "1.0/attention/delUserAttention" : "1.0/attention/addUserAttention", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                initData(true);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error.getMessage());
            }
        });
    }

    public interface OnChangeDataCountListener {
        void onChangeData(List<ProfileDataDO.DataViewTab> dataViewTabList);
    }
}
