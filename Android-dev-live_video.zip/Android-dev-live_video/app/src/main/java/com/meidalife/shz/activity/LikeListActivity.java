package com.meidalife.shz.activity;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtil;
import com.usepropeller.routable.Router;

import java.util.List;

/**
 * Created by shijian on 15/7/17.
 */
public class LikeListActivity extends BaseActivity implements AbsListView.OnScrollListener {

    private Context context;
    private LayoutInflater inflater;

    private ViewGroup rootView;
    private View contentRoot;
    private LoadUtil loadHelper;

    private ListView likeListView;
    private LikeListAdapter adapter;
    private ProgressBar footPb;

    private String itemId;
    private int pageSize = 20;
    private int page = 0;
    private boolean isMoreData = true;
    private boolean isLoading = false;
    private int previous;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_like_list);
        initActionBar(R.string.title_like_list, true);

        context = getApplicationContext();
        inflater = getLayoutInflater();

        Bundle extras = getIntent().getExtras();
        itemId = extras.getString("itemId");

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);
        loadHelper = new LoadUtil(inflater);

        likeListView = (ListView) findViewById(R.id.like_list_view);
        View foot = inflater.inflate(R.layout.fragment_comment_foot, null);
        likeListView.addFooterView(foot);
        footPb = (ProgressBar) foot.findViewById(R.id.detail_comment_foot_pb);

        likeListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                JSONObject data = (JSONObject) view.getTag();
                Router.sharedRouter().open("profile/" + data.getString("userId"));
            }
        });

        initLoadData();
    }

    public void initLoadData() {

        isLoading = true;

        loadHelper.loadPre(rootView, contentRoot);

        likeListView.setOnScrollListener(this);

        JSONObject params = genParams(0);

        HttpClient.get("1.0/attention/getItemAttentionList", params, JSONObject.class, new HttpClient.HttpCallback<List<JSONObject>>() {
            @Override
            public void onSuccess(List<JSONObject> dataList) {
                isLoading = false;
                loadHelper.loadSuccess(contentRoot);
                adapter = new LikeListAdapter(dataList);
                likeListView.setAdapter(adapter);
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                loadHelper.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initLoadData();
                    }
                });
            }
        });

    }


    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (!isMoreData) {
            return;
        }
        if (isLoading) { // 若已经在加载中，则忽略
            return;
        }
        boolean moveToBottom = false;
        if (previous <= firstVisibleItem) {
            moveToBottom = true;
        }
        previous = firstVisibleItem;
        if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
            isLoading = true;
            footPb.setVisibility(View.VISIBLE);
            page++;
            HttpClient.get("1.0/attention/getItemAttentionList", genParams(page), JSONObject.class, new HttpClient.HttpCallback<List<JSONObject>>() {
                @Override
                public void onSuccess(List<JSONObject> dataList) {
                    isLoading = false;
                    if (dataList.size() == 0) {
                        isMoreData = false;
                        footPb.setVisibility(View.GONE);
                    } else {
                        adapter.add(dataList);
                        adapter.notifyDataSetChanged();
                        footPb.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    isLoading = false;
                    MessageUtils.showToastCenter(error.toString());
                    page--;
                    footPb.setVisibility(View.GONE);
                }
            });
        }
    }


    public JSONObject genParams(int page) {
        JSONObject params = new JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", pageSize);
        params.put("offset", page * pageSize);
        return params;
    }


    public class LikeListAdapter extends BaseAdapter {

        private List<JSONObject> datalist;

        public LikeListAdapter(List<JSONObject> datalist) {
            this.datalist = datalist;
        }

        public void add(List<JSONObject> datalist) {
            datalist.addAll(datalist);
        }

        @Override
        public int getCount() {
            return datalist.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final JSONObject obj = datalist.get(position);
            View v = inflater.inflate(R.layout.item_like_list_item, null);

            ImageView userAvatar = (ImageView) v.findViewById(R.id.like_user_avatar);
            //todo set default avatar
            String imageUrl = ImgUtil.getCDNUrlWithWidth(obj.getString("picUrl"), userAvatar.getLayoutParams().width);

            if (TextUtils.isEmpty(imageUrl)) {
                String gender = obj.getString("gender");
                String userId = obj.getString("userId");
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(LikeListActivity.this, userId, gender);
                userAvatar.setImageURI(getDefaultAvatarUri);
            } else {
                userAvatar.setImageURI(Uri.parse(imageUrl));
            }

            TextView userNick = (TextView) v.findViewById(R.id.like_user_nick);
            userNick.setText(obj.getString("nick"));

            convertView = v;
            convertView.setTag(obj);

            return convertView;
        }
    }


}
