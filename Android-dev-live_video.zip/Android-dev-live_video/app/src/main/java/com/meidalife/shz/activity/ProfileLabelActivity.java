package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.view.FlowLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by xingchen on 2015/11/20.
 */
public class ProfileLabelActivity extends BaseActivity {

    private static final int LABEL_TEXT_MAX_NUM = 5;
    private static final int LABEL_MAX_NUM = 10;

    @Bind(R.id.addLabelLayout)
    View addLabelLayout;
    @Bind(R.id.addLabelView)
    EditText addLabelView;
    @Bind(R.id.labelContent)
    FlowLayout labelContent;
    @Bind(R.id.sureAddLabel)
    TextView sureAddLabel;
    @Bind(R.id.contentView)
    View contentView;
    @Bind(R.id.rootView)
    ViewGroup rootView;

    private LayoutInflater inflater;
    private ArrayList<String> labels;
    private JSONArray moreLabels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_label);
        ButterKnife.bind(this);

        initActionBar(R.string.title_activity_profile_label, true, true);
        inflater = LayoutInflater.from(this);
        mButtonRight.setText(R.string.save);


        labels = new ArrayList<String>();
        moreLabels = new JSONArray();

        Intent intent = getIntent();

        ArrayList<String> labelsDate = intent.getExtras().getStringArrayList("userTag");
        if (labelsDate != null && labelsDate.size() != 0) {
            for (String item : labelsDate) {
                if(TextUtils.isEmpty(item))
                    break;
                addItem(item, true);
                labels.add(item);
            }
        }
        initListener();

        getMoreLabels(false);

    }

    private void initListener() {
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mButtonRight.setEnabled(false);
                xhrUpdateProfile();
            }
        });

        sureAddLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(addLabelView.getText().toString().trim()))
                    return;
                labels.add(addLabelView.getText().toString().trim());
                refreshLayout(true);
                addLabelView.setText("");
                addLabelLayout.setVisibility(View.GONE);
                mButtonRight.setEnabled(true);
            }
        });

        addLabelView.addTextChangedListener(new TextWatcher() {
            private CharSequence temp;
            private int editStart;
            private int editEnd;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = addLabelView.getSelectionStart();
                editEnd = addLabelView.getSelectionEnd();
                if (temp.length() > LABEL_TEXT_MAX_NUM) {
                    MessageUtils.showToastCenter(ProfileLabelActivity.this.getString(R.string.label_text_max_num));
                    s.delete(editStart - 1, editEnd);
                    addLabelView.setText(s);
                    addLabelView.setSelection(5);
                }
            }
        });
    }

    private void getMoreLabels(final boolean refresh) {
        contentView.setVisibility(View.GONE);
        showStatusLoading(rootView);
        HttpClient.get("1.0/user_label/getMore", com.alibaba.fastjson.JSONObject.parseObject(getParams().toString()), null, new HttpClient.HttpCallback<JSONArray>() {
            @Override
            public void onSuccess(JSONArray obj) {
                hideStatusLoading();
                contentView.setVisibility(View.VISIBLE);

                if (obj.size() == 0)
                    return;
                moreLabels = obj;

                refreshLayout(refresh);
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                contentView.setVisibility(View.VISIBLE);
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "获取数据失败，请稍后再试");
            }
        });
    }

    private void refreshLayout(boolean refresh) {
        if(refresh){
            labelContent.removeAllViews();
            for(String label : labels){
                addItem(label, true);
            }
        }
        for (int i = 0; i < moreLabels.size(); i++) {
            addItem(moreLabels.getString(i), false);
        }
    }

    private void addItem(String item, boolean isSelected) {
        TextView itemView = (TextView) inflater.inflate(R.layout.item_grid_label, labelContent, false);
        itemView.setText(item.trim());
        if (isSelected) {
            itemView.setBackgroundResource(R.drawable.label_item_select_bg);
        } else
            itemView.setBackgroundResource(R.drawable.label_item_bg);
        HashMap tags = new HashMap();
        tags.put("type",isSelected);
        tags.put("text",item);
        itemView.setTag(tags);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap tags = (HashMap) v.getTag();
                boolean type = (boolean)tags.get("type");
                String text = (String)tags.get("text");
                if (type) {
                    labels.remove(text);
                    moreLabels.add(text);
                    v.setBackgroundResource(R.drawable.label_item_bg);
                }else{
                    if(labels.size() >= LABEL_MAX_NUM){
                        MessageUtils.showToastCenter(ProfileLabelActivity.this.getString(R.string.label_max_num));
                        return;
                    }
                    moreLabels.remove(text);
                    labels.add(text);
                    v.setBackgroundResource(R.drawable.label_item_select_bg);
                }
                HashMap newTags = new HashMap();
                newTags.put("type",!type);
                newTags.put("text",text);
                v.setTag(newTags);
            }
        });
        labelContent.addView(itemView);
    }

    private void xhrUpdateProfile() {

        JSONObject params = getParams();

        showProgressDialog("正在保存");
        RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                hideProgressDialog();
                mButtonRight.setEnabled(true);
                MessageUtils.showToastCenter("保存成功");

                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putStringArrayList("userTag", labels);
                intent.putExtras(bundle);
                setResult(RESULT_OK, intent);

                finish();
            }

            @Override
            public void onFailure(HttpError error) {
                hideProgressDialog();
                mButtonRight.setEnabled(true);
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败，请稍后再试");
            }
        });

    }

    private JSONObject getParams() {
        JSONObject params = new JSONObject();
        try {
            StringBuffer labelSb = new StringBuffer();
            for (String label : labels) {
                labelSb.append(label + ",");
            }
            params.put("userTag", labelSb.toString().length() == 0 ? "" : labelSb.toString().substring(0, labelSb.toString().length() - 1));
            return params;
        } catch (JSONException e) {
            e.printStackTrace();
            mButtonRight.setEnabled(true);
            return params;
        }
    }

    public void addLabel(View view) {
        if(labels.size() >= LABEL_MAX_NUM){
            MessageUtils.showToastCenter(ProfileLabelActivity.this.getString(R.string.label_max_num));
            return;
        }
        addLabelLayout.setVisibility(View.VISIBLE);
        addLabelView.requestFocus();
        InputMethodManager m = (InputMethodManager) ProfileLabelActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
        m.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
        mButtonRight.setEnabled(false);
    }

    public void hideAddLabel(View view) {
        addLabelLayout.setVisibility(View.GONE);
        mButtonRight.setEnabled(true);
    }

    public void refreshLabel(View view) {
        getMoreLabels(true);
    }

}
