package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SearchFilterDo;
import com.meidalife.shz.rest.model.SearchTopListPromotionDO;
import com.meidalife.shz.rest.model.SearchTopListUserDO;
import com.meidalife.shz.rest.model.ServiceListOutDo;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.rest.request.RequestSearch;
import com.meidalife.shz.util.LoadUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/1/6.
 * <p/>
 * update by zuozheng on 16/04/29a
 */
public class SearchServiceResultFragment extends BaseFragment implements SwipeRefreshLayout.OnRefreshListener {
    public static final String SEARCH_ARG_KEYWORD = "keyword";
    public static final String SEARCH_PARAMS_CATE_ID = "cate_id";
    public static final String SEARCH_PARAMS_TAB_ID = "tab_id";
    public static final String SEARCH_PARAMS_SUB_CATE_ID = "sub_cate_id";
    public static final String SEARCH_ARG_FIRST_SEARCH = "first_search";
    public static final String SEARCH_PARAMS_NEED_POI = "needPOI";

    private static final int PAGE_SIZE = 20;
    private boolean needPOI = false;

    protected boolean isVisible;

    private boolean isLoadCompleted = false;
    private int page = 0;
    private String keyword;
    private boolean isLoading = false;
    private boolean hasLoadOnce = false;
    private ArrayList<ServiceListOutDo> items = new ArrayList<>();
    private List<SquareDO> squareDOs = new ArrayList<>();
    private boolean isFirstSearch;
    private int tabId = Integer.MAX_VALUE;
    private int cateId = Integer.MAX_VALUE;
    private int subCateId = Integer.MAX_VALUE;

    View rootView;
    View footView;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.searchResultList)
    ListView searchResultList;
    @Bind(R.id.searchEmptyLayout)
    ViewGroup searchEmptyLayout;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.nearByHintLayout)
    LinearLayout nearByHintLayout;
    @Bind(R.id.nearbyHintLabel)
    TextView nearbyHintLabel;

    ServicesAdapter serviceAdapter;
    SearchCompleteListener searchCompleteListener;
    private LoadUtil helperV2;

    public static SearchServiceResultFragment newInstance() {
        SearchServiceResultFragment fragment = new SearchServiceResultFragment();
        return fragment;
    }

    public void setSearchActionListener(SearchCompleteListener searchCompleteListener) {
        this.searchCompleteListener = searchCompleteListener;
    }

    public void setSearchParams(Bundle bundle) {
        tabId = bundle.getInt(SEARCH_PARAMS_TAB_ID);
        cateId = bundle.getInt(SEARCH_PARAMS_CATE_ID);
        subCateId = bundle.getInt(SEARCH_PARAMS_SUB_CATE_ID);

        needPOI = bundle.getBoolean(SEARCH_PARAMS_NEED_POI, false);
        keyword = bundle.getString(SEARCH_ARG_KEYWORD);
        isFirstSearch = bundle.getBoolean(SEARCH_ARG_FIRST_SEARCH, true);

        searchService(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (null == rootView) {
            rootView = inflater.inflate(R.layout.fragment_search_result, container, false);
            ButterKnife.bind(this, rootView);

            helperV2 = new LoadUtil(inflater);

            footView = inflater.inflate(R.layout.fragment_comment_foot, searchResultList, false);
            searchResultList.addFooterView(footView);
            searchResultList.setEmptyView(searchEmptyLayout);
            serviceAdapter = new ServicesAdapter(getActivity(), items);
            searchResultList.setAdapter(serviceAdapter);
            searchResultList.setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                        if (view.getLastVisiblePosition() == view.getCount() - 1 && !isLoadCompleted) {
                            footView.setVisibility(View.VISIBLE);
                            searchService(false);
                        }
                    }

                    final View topChildView = view.getChildAt(0);
                    if (scrollState == SCROLL_STATE_IDLE && view.getFirstVisiblePosition() == 0
                            && topChildView != null && topChildView.getTop() == 0) {
                        mSwipeRefreshLayout.setEnabled(true);
                        searchCompleteListener.onScrollToTop(true);
                    } else {
                        searchCompleteListener.onScrollToTop(false);
                        mSwipeRefreshLayout.setEnabled(false);
                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                }
            });
            mSwipeRefreshLayout.setOnRefreshListener(this);
        }

        return rootView;
    }

    @Override
    public void onDestroyView() {
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (getUserVisibleHint()) {
            isVisible = true;
            if (null != rootView && !hasLoadOnce) {
                searchService(true);
            }
        } else {
            isVisible = false;
        }
    }

    private boolean checkLocationSetting() {
        try {
            String locateCode = SHZApplication.getInstance().getLocationManager().getLocation().getCityCode();
            String selectCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
            if (Helper.isLocationEnabled(getActivity())) {
                if (!TextUtils.isEmpty(locateCode) && (locateCode.equals(selectCode) || TextUtils.isEmpty(selectCode))) {
                    nearByHintLayout.setVisibility(View.GONE);
                    return true;
                } else {
                    mSwipeRefreshLayout.setVisibility(View.GONE);
                    nearByHintLayout.setVisibility(View.VISIBLE);
                    nearbyHintLabel.setText("选择城市和定位所在城市不一致，无法显示哦");
                    return false;
                }
            } else {
                mSwipeRefreshLayout.setVisibility(View.GONE);
                nearByHintLayout.setVisibility(View.VISIBLE);
                nearbyHintLabel.setText("未开启定位，点击设置");
                nearByHintLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (Helper.isLocationEnabled(getActivity())) {
                            searchService(true);
                        } else {
                            Helper.openLocationSetting(getActivity());
                        }
                    }
                });
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    private void searchService(final boolean reload) {

        if (needPOI && !checkLocationSetting()) {
            return;
        }

        mSwipeRefreshLayout.setVisibility(View.VISIBLE);

        if (isLoading) {
            return;
        }

        if (reload) {
            page = 0;
            helperV2.loadPre(rootLayout, mSwipeRefreshLayout);
        }

        JSONObject searchParams = preParams();

        RequestSearch.search(searchParams, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject data) {

                        if (null == getActivity() || getActivity().isFinishing()) {
                            return;
                        }
                        if (reload) {
                            items.clear();
                        }

                        helperV2.loadSuccess(mSwipeRefreshLayout);
//                        JSONObject data = (JSONObject) result;
                        String itemList = null;
                        String squareList = null;
                        String additionalData = null;
                        SearchTopListPromotionDO searchTopListPromotionDO = null;
                        SearchTopListUserDO searchTopListUserDO = null;
                        int topListType = -1;
                        // 正常数据
                        if (data.containsKey("result")) {
                            itemList = data.getString("result");
                        }

                        if (isFirstSearch) {
                            SearchFilterDo searchFilterDo = JSON.parseObject(data.toString(), SearchFilterDo.class);
                            searchCompleteListener.onUpdateTabFilter(searchFilterDo);
                        }

                        //// TODO: 16/5/6 接口暂无数据 待做
                        //                        if (data.containsKey("additionalElement")) {
                        //                            JSONObject additionalElement = data.getJSONObject("additionalElement");
                        //                            topListType = Constant.SEARCH_TOP_LIST_TYPE_USER;
                        //                            additionalData = additionalElement.getString("elementInfo");
                        //                        }

                        List<ServiceListOutDo> newData = JSON.parseArray(itemList, ServiceListOutDo.class);
                        if (newData.size() < PAGE_SIZE) {
                            isLoadCompleted = true;
                        } else {
                            isLoadCompleted = false;
                        }

                        footView.setVisibility(View.GONE);
                        items.addAll(newData);
                        serviceAdapter.setData(items);
                        serviceAdapter.notifyDataSetChanged();

                        if (topListType == Constant.SEARCH_TOP_LIST_TYPE_PROMOTION) {
                            searchTopListPromotionDO = JSON.parseObject(additionalData, SearchTopListPromotionDO.class);
                            searchCompleteListener.onUpdateSquareList(searchTopListPromotionDO, topListType);

                        } else if (!TextUtils.isEmpty(squareList)) {

                            squareDOs = JSON.parseArray(squareList, SquareDO.class);
                            if (null != squareDOs && !squareDOs.isEmpty()) {
                                searchCompleteListener.onUpdateSquareList(squareDOs, Constant.SEARCH_TOP_LIST_TYPE_GEZI);
                            }

                        } else if (topListType == Constant.SEARCH_TOP_LIST_TYPE_USER)

                        {

                            searchTopListUserDO = JSON.parseObject(additionalData, SearchTopListUserDO.class);
                            searchCompleteListener.onUpdateSquareList(searchTopListUserDO, topListType);

                        }

                        page++;
                        isFirstSearch = false;
                        hasLoadOnce = true;
                    }

                    @Override
                    public void onFail(HttpError error) {
                        footView.setVisibility(View.GONE);
                        helperV2.loadFail(error, rootLayout, new LoadUtil.Callback() {
                            @Override
                            public void retry() {
                                searchService(true);
                            }
                        });
                    }
                }

        );
    }


    private JSONObject preParams() {
        JSONObject params = new JSONObject();
        params.put("offset", page * PAGE_SIZE);
        params.put("pageSize", PAGE_SIZE);

        double longitude = SHZApplication.getInstance().getLocationManager().getLocation().getLongitude();
        double latitude = SHZApplication.getInstance().getLocationManager().getLocation().getLatitude();
        params.put("longitude", longitude);
        params.put("latitude", latitude);

        params.put("isFirstSearch", isFirstSearch);
        params.put("query", keyword);

        if (tabId != Integer.MAX_VALUE)
            params.put("tabId", tabId);
        if (cateId != Integer.MAX_VALUE)
            params.put("cateId", cateId);
        if (subCateId != Integer.MAX_VALUE)
            params.put("subCateId", subCateId);

        return params;
    }

    @Override
    public void onRefresh() {
        isFirstSearch = false;
        mSwipeRefreshLayout.setRefreshing(false);
        searchService(true);
    }

    public interface SearchCompleteListener {
        void onUpdateSquareList(Object object, int type);

        void onScrollToTop(boolean top);

        void onUpdateTabFilter(SearchFilterDo searchFilterDo);

    }
}
