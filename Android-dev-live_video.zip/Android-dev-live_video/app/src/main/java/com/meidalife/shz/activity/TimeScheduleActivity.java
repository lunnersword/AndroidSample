package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.TimeScheduleAdapter;
import com.meidalife.shz.rest.model.ScheduleDo;
import com.meidalife.shz.view.ArcView;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/3/17.
 */
public class TimeScheduleActivity extends BaseActivity implements TimeScheduleAdapter.onSettingChangeListener {
    ArrayList<ScheduleDo> scheduleDoArrayList;

    @Bind(R.id.topPanel)
    LinearLayout topPanel;

    @Bind(R.id.timeScheduleList)
    RecyclerView timeScheduleList;

    TimeScheduleAdapter timeScheduleAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_schedule);
        ButterKnife.bind(this);
        initActionBar(R.string.title_activity_time_manage, true, true);
        mButtonRight.setText("确定");
        scheduleDoArrayList = getIntent().getParcelableArrayListExtra("schedule");

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        timeScheduleList.setLayoutManager(linearLayoutManager);
        timeScheduleAdapter = new TimeScheduleAdapter(this, scheduleDoArrayList);
        timeScheduleAdapter.setOnSettingChangeListener(this);
        timeScheduleList.setAdapter(timeScheduleAdapter);

        updateDayLabel();

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putParcelableArrayListExtra("schedule",
                        timeScheduleAdapter.getScheduleDoArrayList());
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void updateDayLabel() {
        HashMap item = new HashMap();
        topPanel.removeAllViews();
        for (int i = 0; i < scheduleDoArrayList.size(); i++) {
            String[] buckets = scheduleDoArrayList.get(i).
                    getValue().split("-");
            if (buckets.length == 3) {
                item.put("am", buckets[0].equals("1"));
                item.put("pm", buckets[1].equals("1"));
                item.put("ni", buckets[2].equals("1"));
                item.put("title", Constant.DAY_OF_WEEK[i]);
            } else {
                item.put("am", true);
                item.put("pm", true);
                item.put("ni", true);
                item.put("title", Constant.DAY_OF_WEEK[i]);
            }

            final int index = i;
            final View labelView = LayoutInflater.from(this).inflate(R.layout.schedule_label, null);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.MATCH_PARENT, 1.0f);
            labelView.setLayoutParams(layoutParams);
            renderLabel(labelView, item);
            labelView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    timeScheduleList.smoothScrollToPosition(index);
                }
            });
            topPanel.addView(labelView);
        }
    }

    private void renderLabel(View labelView, HashMap item) {
        Boolean amValue = (Boolean) item.get("am");
        Boolean pmValue = (Boolean) item.get("pm");
        Boolean niValue = (Boolean) item.get("ni");
        TextView textWeek = (TextView) labelView.findViewById(R.id.week);
        ArcView arcView = (ArcView) labelView.findViewById(R.id.arcView);

        textWeek.setText((String) item.get("title"));
        arcView.setData(amValue, pmValue, niValue);

        if (amValue || pmValue || niValue) {
            textWeek.setTextColor(getResources().getColor(R.color.brand_c));
        } else {
            textWeek.setTextColor(getResources().getColor(R.color.grey_b));
        }
    }

    @Override
    public void onSettingUpdate() {
        updateDayLabel();
    }
}
