package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

/**
 * Created by taber on 15/6/1.
 */
public class HomeServiceImagesAdapter extends BaseAdapter {

    private Context mContext;
    private List<String> mImages;
    LayoutInflater mInflater;
    private int mWidth;
    private int mStart;
    private int mEnd;

    static class ImageHolder {
        public ImageView image;
    }

    public HomeServiceImagesAdapter(Context c, List<String> images, int width, int start, int end) {
        mContext = c;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mImages = images;
        mWidth = width;
        this.mStart = start;
        this.mEnd = end;
    }

    public int getCount() {
        return mEnd - mStart;
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageHolder imageHolder;
        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            imageHolder = new ImageHolder();

            convertView = mInflater.inflate(R.layout.service_grid_item, parent, false);
            imageHolder.image = (ImageView) convertView.findViewById(R.id.serviceGridImage);
            ViewGroup.LayoutParams layoutParams = imageHolder.image.getLayoutParams();
            layoutParams.width = mWidth;
            layoutParams.height = mWidth;
            imageHolder.image.setLayoutParams(layoutParams);

            convertView.setTag(imageHolder);
        } else {
            imageHolder = (ImageHolder) convertView.getTag();
        }

        int index = mStart + position;

        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithHeight(mImages.get(index), mWidth));

        imageHolder.image.setImageURI(uri);


        return convertView;
    }
}
