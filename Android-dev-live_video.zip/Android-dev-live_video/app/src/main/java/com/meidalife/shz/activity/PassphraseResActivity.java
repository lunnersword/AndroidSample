package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestContacts;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by shijian on 15/7/15.
 */
public class PassphraseResActivity extends BaseActivity {

    private LayoutInflater inflater;
    private Context context;

    private ViewGroup rootView;
    private View contentRoot;

    private String code;

    private TextView resHint;
    private GridView resItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.passphrase_res);
        initActionBar(R.string.title_mcoin_passphrase, true);

        inflater = getLayoutInflater();
        context = getApplicationContext();

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);

        Bundle extras = getIntent().getExtras();
        code = extras.getString("code");

        resHint = (TextView) findViewById(R.id.passphrase_res_hint);
        resItems = (GridView) findViewById(R.id.passphrase_res_items);

        TextView toHome = (TextView) findViewById(R.id.passphrase_to_index);
        toHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(Helper.ACTIVITY_RESULT_CODE_BACK);
                finish();
            }
        });

        req();
    }


    public void req() {
        loadPre(rootView, contentRoot);
        RequestContacts.activate(code, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {

            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                loadSuccess(contentRoot);
                try {
//                    JSONObject json = (JSONObject) result;
                    if (result.containsKey("message")) {
                        resHint.setText(result.getString("message"));
                    }

                    if (result.containsKey("items")) {
                        JSONArray itemArray = result.getJSONArray("items");
                        List<ServiceItem> itemList = parse(itemArray);
                        PassphraseItemAdapter adapter = new PassphraseItemAdapter(itemList);
                        resItems.setAdapter(adapter);
                    }

                } catch (Exception e) {
                    loadFail(new HttpError(HttpError.ERR_CODE_SERVER_ERROR, getString(R.string.error_server_500)),
                            rootView, PassphraseResActivity.this, new LoadCallback() {
                                @Override
                                public void execute() {
                                    req();
                                }
                            });
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            req();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            req();
                        }
                    });
                }
            }
        });
    }


    private List<ServiceItem> parse(JSONArray array) throws Exception {
        List<ServiceItem> itemList = new ArrayList<>();
        int size = Math.min(6, array.size());
        try {
            for (int i = 0; i < size; i++) {
                ServiceItem item = new ServiceItem();
                JSONObject obj = array.getJSONObject(i);
                item.setItemId(obj.getString("itemId"));
                ArrayList<String> imgList = new ArrayList<>();
                JSONArray imgArray = obj.getJSONArray("images");
                imgList.add(imgArray.getString(0));
                item.setImages(imgList);
                item.setTag(obj.getString("tag"));
                item.setPrice(obj.getString("price"));
                itemList.add(item);
            }
        } catch (Exception e) {
            Log.e("PassphraseRes", "解析数据失败" + e.getMessage());
        }

        return itemList;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Helper.ACTIVITY_RESULT_CODE_BACK) {
            finish();
        }
    }


    class PassphraseItemAdapter extends BaseAdapter {

        private List<ServiceItem> dataList;

        public PassphraseItemAdapter(List<ServiceItem> data) {
            this.dataList = data;
        }

        @Override
        public int getCount() {
            return dataList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            PassphraseItemHolder holder = null;
            if (convertView == null) {
                holder = new PassphraseItemHolder();
                View v = inflater.inflate(R.layout.passphrase_res_item, null);
                holder.img = (SimpleDraweeView) v.findViewById(R.id.passphrase_res_item_img);
                holder.tag = (TextView) v.findViewById(R.id.passphrase_res_item_tag);
                holder.price = (TextView) v.findViewById(R.id.passphrase_res_item_price);
                v.setTag(holder);
                convertView = v;
            } else {
                holder = (PassphraseItemHolder) convertView.getTag();
            }

            ServiceItem item = dataList.get(position);
            holder.itemId = item.getItemId();
            ImgUtil.load(context, item.getImages().get(0), holder.img.getLayoutParams(), holder.img);
            holder.tag.setText("我能：" + item.getTag());
            holder.price.setText(item.getPrice());

            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PassphraseItemHolder i = (PassphraseItemHolder) v.getTag();
                    Router.sharedRouter().open("services/" + i.itemId);
                }
            });

            return convertView;
        }
    }

    class PassphraseItemHolder {
        public SimpleDraweeView img;
        public TextView tag;
        public TextView price;
        public String itemId;
    }
}
