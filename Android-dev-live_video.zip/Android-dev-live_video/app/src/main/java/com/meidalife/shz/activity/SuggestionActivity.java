package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.adapter.ServiceGridAdapter;
import com.meidalife.shz.adapter.SuggestionTypeListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.SuggestionTypeDO;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.LoadUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 意见反馈
 * Created by liujian on 16/4/26.
 */
public class SuggestionActivity extends BaseActivity{

    @Bind(R.id.myListView)
    ListView myListView;
    @Bind(R.id.suggestionText)
    EditText suggestionText;
    @Bind(R.id.selectImages)
    GridView selectImagesGrid;
    @Bind(R.id.commitView)
    Button commitView;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    View contentView;
    @Bind(R.id.successLayout)
    View successLayout;

    private LoadUtil loadUtil;
    private SuggestionTypeListAdapter suggestionTypeListAdapter;
    private int canPickPicCount;
    private ServiceGridAdapter adapter;
    private List<String> images;
    private int currentPosition = 0;
    private boolean isPublishing;
    private Map<String, String> uploadedImages = new HashMap<>();
    private boolean isUploading = false;
    private boolean hasChange = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggestion);
        ButterKnife.bind(this);

        initActionBar(R.string.title_suggestion, true);
        loadUtil = new LoadUtil(LayoutInflater.from(this));
        images = new ArrayList<String>();
        hideIMM();
        initListener();
        initSelectImagesGrid();
        loadSuggestionType();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (Activity.RESULT_OK == resultCode && requestCode == Constant.REQUEST_CODE_PICK_PHOTO) {
            Bundle bundle = data.getExtras();
            ArrayList<String> paths = bundle.getStringArrayList("images");
            if (paths != null && paths.size() > 0) {
                for (int i = 0; i < paths.size(); i++) {
                    if (currentPosition < images.size() &&
                            TextUtils.isEmpty(images.get(currentPosition))) {
                        images.set(currentPosition++, paths.get(i));
                        canPickPicCount--;
                    } else {
                        if (images.size() < Constant.MAX_IMAGE_LENGTH) {
                            images.add(paths.get(i));
                            canPickPicCount--;
                        }
                    }
                }
            }
            uploadImages();
            adapter.notifyDataSetChanged();
        }
    }

    private void initListener(){
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                suggestionTypeListAdapter.setSelectPosition(position);
                suggestionTypeListAdapter.notifyDataSetChanged();
            }
        });
        commitView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                commitSuggestion();
            }
        });
    }

    private void loadSuggestionType(){
        loadUtil.loadPre(rootView, contentView);
        commitView.setVisibility(View.GONE);
        HttpClient.get("1.0/suggest/getSuggestionTypeList", null, SuggestionTypeDO.class, new HttpClient.HttpCallback<SuggestionTypeDO>() {
            @Override
            public void onSuccess(SuggestionTypeDO obj) {
                loadUtil.loadSuccess(contentView);
                commitView.setVisibility(View.VISIBLE);
                if (obj.getSuggestionTypeList() != null) {
                    suggestionTypeListAdapter = new SuggestionTypeListAdapter(SuggestionActivity.this, obj.getSuggestionTypeList());
                    myListView.setAdapter(suggestionTypeListAdapter);
                }
            }

            @Override
            public void onFail(HttpError error) {
                loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        loadSuggestionType();
                    }
                });
            }
        });
    }

    private void commitSuggestion(){
        if(!checkData())
            return;
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        showProgressDialog("正在提交");
        isPublishing = true;
        if (!isUploadCompleted()) {
            uploadImages();
            return;
        }
        params.put("typeId", suggestionTypeListAdapter.getSelectItemId());
        params.put("uploadPic", imagesToStr());
        params.put("suggestionText", suggestionText.getText().toString());

        HttpClient.get("1.0/suggest/AddSuggestion", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                hideProgressDialog();
                hasChange = false;
                contentView.setVisibility(View.GONE);
                commitView.setVisibility(View.GONE);
                successLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "提交失败，请稍后再试");
            }
        });
    }

    private boolean checkData(){
        if(suggestionTypeListAdapter.getSelectItemId() == null){
            MessageUtils.showToastCenter("请选择问题类型");
            return false;
        }

        if(TextUtils.isEmpty(suggestionText.getText().toString())){
            MessageUtils.showToastCenter("请填写问题和意见");
            return false;
        }

        return true;
    }

    private String imagesToStr(){
        StringBuffer sb = new StringBuffer();
        for(String key : uploadedImages.keySet()){
            sb.append(uploadedImages.get(key)+",");
        }
        String imagesStr = sb.toString();
        if(imagesStr.length() > 0)
            imagesStr = imagesStr.substring(0,imagesStr.length()-1);
        return imagesStr;
    }

    private void initSelectImagesGrid() {
        canPickPicCount = Constant.MAX_IMAGE_LENGTH - images.size();
        adapter = new ServiceGridAdapter(this, images,
                Constant.MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_SERVICE);
        adapter.setTHREE(0);
        selectImagesGrid.setAdapter(adapter);
        adapter.setOnClickListener(new ServiceGridAdapter.OnClickListener() {
            @Override
            public void onAddClick(View v, int position) {
                addImg(position);
            }

            @Override
            public void onEditClick(View v, int position) {
                currentPosition = position;
                addImg(position);
            }

            @Override
            public void onRemoveClick(View v, int position) {
                if (position < images.size()) {
                    images.set(position, "");
                    canPickPicCount++;
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    void addImg(int position) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", canPickPicCount);
        bundle.putInt("position", position);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, this);
    }

    /**
     * 上传图片
     */
    private void uploadImages() {
        if (isUploadCompleted()) {
            return;
        }
        uploadImage(0);
    }

    /**
     * 检查是否上传完成
     *
     * @return
     */
    private boolean isUploadCompleted() {
        for (String image : images) {
            if (!TextUtils.isEmpty(image) && !uploadedImages.containsKey(image)) {
                return false;
            }
        }
        return true;
    }

    private void uploadImage(final int index) {
        if (isUploading) {
            return;
        }
        final String imagePath = images.get(index);
        if (uploadedImages.containsKey(imagePath)) {
            for (int i = 0; i < images.size(); i++) {
                if (!uploadedImages.containsKey(images.get(i))) {
                    uploadImage(i);
                    return;
                }
            }
        }
        isUploading = true;
        RequestSign.upload(imagePath, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                isUploading = false;
                try {
                    org.json.JSONObject json = (org.json.JSONObject) result;
                    uploadedImages.put(imagePath, json.getString("data"));
                    for (int i = 0; i < images.size(); i++) {
                        if (!uploadedImages.containsKey(images.get(i))) {
                            uploadImage(i);
                            break;
                        }
                    }
                    if (isUploadCompleted() && isPublishing) {
                        commitSuggestion();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(HttpError error) {
                isUploading = false;
                MessageUtils.showToastCenter(error != null ? "上传图片失败失败:" + error.getMessage() : "上传图片失败失败");
                hideProgressDialog();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (!hasChange()) {
            super.onBackPressed();
            return;
        }

        MessageUtils.createDialog(SuggestionActivity.this, "提醒", "意见反馈未完成,确定离开?", R.string.confirm_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }, R.string.cancel_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        }).show();
    }

    private boolean hasChange() {

        return hasChange;
    }
}
