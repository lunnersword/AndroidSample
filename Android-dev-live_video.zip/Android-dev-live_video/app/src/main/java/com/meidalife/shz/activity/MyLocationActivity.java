package com.meidalife.shz.activity;

/**
 * Created by zhq on 15/10/28.
 */
public class MyLocationActivity extends BaseActivity {


}
