package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.LiveRankListFragment;
import com.meidalife.shz.adapter.FragmentTabAdapter;
import com.meidalife.shz.widget.SlidingTabLayout;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by lanbo on 16/3/29.
 */
public class LiveRankListActivity extends BaseActivity implements ViewPager.OnPageChangeListener {

    @Bind(R.id.rankSlidingTab)
    SlidingTabLayout rankSlidingTab;
    @Bind(R.id.rankTabViewPager)
    ViewPager rankTabViewPager;
    @Bind(R.id.action_bar_button_back)
    View buttonBack;

    private String rankType = "0";

    private FragmentTabAdapter mRankPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rank_list);
        if (getIntent() != null)
            rankType = getIntent().getStringExtra("type");
        ButterKnife.bind(this);

        renderTabs();
    }

    private void renderTabs() {
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        mRankPagerAdapter = new FragmentTabAdapter(getSupportFragmentManager());
        LiveRankListFragment audienceFragment = LiveRankListFragment.newInstance(Constant.RANK_TYPE_AUDIENCE);
        mRankPagerAdapter.addFragment(audienceFragment);
        LiveRankListFragment hostFragment = LiveRankListFragment.newInstance(Constant.RANK_TYPE_HOST);
        mRankPagerAdapter.addFragment(hostFragment);

        rankTabViewPager.setOffscreenPageLimit(2);
        rankTabViewPager.setAdapter(mRankPagerAdapter);

        rankSlidingTab.setCustomTabView(R.layout.item_live_tab, R.id.liveTabName);
        rankSlidingTab.setSelectedIndicatorColors(getResources().getColor(R.color.brand_a));
        rankSlidingTab.setSelectedTabTitleColorId(R.color.white);
        rankSlidingTab.setTabTitleColorId(R.color.white);
        rankSlidingTab.setDividerColors(android.R.color.transparent);
        rankSlidingTab.setOnPageChangeListener(this);
        rankSlidingTab.setCalculateWidthByTitle(false);
        rankSlidingTab.setViewPager(rankTabViewPager);

        if (rankType.equals(String.valueOf(Constant.RANK_TYPE_HOST)))
            rankTabViewPager.setCurrentItem(1);

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    public void handleBack(View view) {
        finish();
    }
}
