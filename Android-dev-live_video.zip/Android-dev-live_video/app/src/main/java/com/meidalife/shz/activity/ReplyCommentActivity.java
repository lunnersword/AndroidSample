package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ProfileCommentGridAdapter;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.adapter.ServiceGridAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.CommentAndOrderDO;
import com.meidalife.shz.rest.model.CommentByServerDO;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.FlowLayout;
import com.meidalife.shz.view.MyGridView;
import com.usepropeller.routable.Router;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 回复评论,评价详情
 * Created by liujian on 16/4/9.
 */
public class ReplyCommentActivity extends BaseActivity {

    private final static int TEXT_LENGTH_LIMIT = 300;

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    View contentView;

    @Bind(R.id.selectImages)
    MyGridView selectImagesGrid;
    @Bind(R.id.publishBtn)
    TextView publishBtn;
    @Bind(R.id.replySupply)
    View replySupply;
    @Bind(R.id.levelText)
    TextView levelText;
    @Bind(R.id.publishReplyLayout)
    View publishReplyLayout;
    @Bind(R.id.textReply)
    EditText textReply;
    @Bind(R.id.textReplyLimit)
    TextView textReplyLimit;

    @Bind(R.id.userAvatar)
    SimpleDraweeView userAvatar;
    @Bind(R.id.iconGender)
    TextView iconGender;
    @Bind(R.id.userNick)
    TextView userNick;
    @Bind(R.id.jobIcon)
    SimpleDraweeView jobIcon;
    @Bind(R.id.jobName)
    TextView jobName;
    @Bind(R.id.jobTitle)
    TextView jobTitle;
    @Bind(R.id.commentTime)
    TextView commentTime;
    @Bind(R.id.title)
    TextView title;
    @Bind(R.id.commentContent)
    TextView commentContent;
    @Bind(R.id.tagLayout)
    FlowLayout tagLayout;
    @Bind(R.id.commentStarGroup)
    LinearLayout commentStarGroup;
    @Bind(R.id.imageList)
    GridView imageList;


    private int canPickPicCount;
    private ServiceGridAdapter adapter;
    private List<String> images;
    private int currentPosition = 0;
    private Map<String, String> uploadedImages = new HashMap<>();
    private boolean isUploading = false;
    private List<TextView> starList = new ArrayList<>();
    private String orderNo;
    private LoadUtil loadUtil;
    private int score = 0;
    private boolean isPublishing;
    private String commentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reply_comment);

        ButterKnife.bind(this);
        initActionBar(R.string.text_reply_comment, true);
        images = new ArrayList<String>();
        orderNo = getIntent().getStringExtra("orderNo");
        loadUtil = new LoadUtil(LayoutInflater.from(this));
        hideIMM();

        initSelectImagesGrid();
        setStarFont();
        initListener();
        initReplyInfoData();


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (Activity.RESULT_OK == resultCode && requestCode == Constant.REQUEST_CODE_PICK_PHOTO) {
            Bundle bundle = data.getExtras();
            ArrayList<String> paths = bundle.getStringArrayList("images");
            if (paths != null && paths.size() > 0) {
                for (int i = 0; i < paths.size(); i++) {
                    if (currentPosition < images.size() &&
                            TextUtils.isEmpty(images.get(currentPosition))) {
                        images.set(currentPosition++, paths.get(i));
                        canPickPicCount--;
                    } else {
                        if (images.size() < Constant.MAX_IMAGE_LENGTH) {
                            images.add(paths.get(i));
                            canPickPicCount--;
                        }
                    }
                }
            }
            uploadImages();
            adapter.notifyDataSetChanged();
        }
    }

    private void initListener() {
        publishBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                replyComment();
            }
        });
        textReply.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textReplyLimit.setText("" + s.toString().length());
                if (s.toString().trim().length() > TEXT_LENGTH_LIMIT) {
                    textReplyLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textReplyLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    //回复评论初始数据
    private void initReplyInfoData() {
        loadUtil.loadPre(rootView, contentView);
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("orderNo", orderNo);
        HttpClient.get("1.1/comment/getCommentAndOrderInfo", params, CommentAndOrderDO.class, new HttpClient.HttpCallback<CommentAndOrderDO>() {
            @Override
            public void onSuccess(CommentAndOrderDO obj) {
                loadUtil.loadSuccess(contentView);
                title.setText("[" + obj.getTitle() + "]");
                handlerCommentData(obj.getComments());
            }

            @Override
            public void onFail(HttpError error) {
                loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initReplyInfoData();
                    }
                });
            }
        });
    }

    private void handlerCommentData(CommentByServerDO item) {
        if (item == null)
            return;
        commentId = item.getCommentId();
        userAvatar.setImageURI(Uri.parse(item.getUser().getAvatar()));
        // 设置性别
        if (item.getUser().getUserGender() != null) {
            iconGender.setVisibility(View.VISIBLE);
            if (item.getUser().getUserGender().equals("woman") || item.getUser().getUserGender().equals("F")) {
                iconGender.setText(getResources().getString(R.string.icon_gender_f));
            } else {
                iconGender.setText(getResources().getString(R.string.icon_gender_m));
            }
        } else {
            iconGender.setVisibility(View.GONE);
        }
        //设置标签
        if (item.getTags() != null && item.getTags().size() != 0) {
            tagLayout.setVisibility(View.VISIBLE);
            initTag(tagLayout, item.getTags());
        } else
            tagLayout.setVisibility(View.GONE);
        userNick.setText(item.getUser().getUserNick());
        if (item.getUser().getJobs() != null && item.getUser().getJobs().size() != 0) {
            jobName.setVisibility(View.VISIBLE);
            jobIcon.setVisibility(View.VISIBLE);
            jobName.setText(item.getUser().getJobs().get(0).getTitle());
            if (item.getUser().getJobs().get(0).getIconUrl() != null)
                jobIcon.setImageURI(Uri.parse(item.getUser().getJobs().get(0).getIconUrl()));
        } else {
            jobName.setVisibility(View.GONE);
            jobIcon.setVisibility(View.GONE);
        }
        if (item.getUser().getJobTitle() != null) {
            jobTitle.setVisibility(View.VISIBLE);
            jobTitle.setText(item.getUser().getJobTitle());
        } else
            jobTitle.setVisibility(View.GONE);
        commentTime.setText(DateUtils.profileCommentTime(System.currentTimeMillis(), item.getCreateTime() * 1000));
        if (item.getComment() != null) {
            commentContent.setVisibility(View.VISIBLE);
            commentContent.setText(item.getComment());
        } else
            commentContent.setVisibility(View.GONE);

        //评论星级
        View starsView = LayoutInflater.from(this).inflate(R.layout.view_grade_stars, commentStarGroup, false);
        ViewGroup starsRed = (ViewGroup) starsView.findViewById(R.id.star_red_group);
        ViewGroup starsGrey = (ViewGroup) starsView.findViewById(R.id.star_grey_group);
        for (int i = 0; i < 5; i++) {
            TextView iconTextView = (TextView) starsRed.getChildAt(i);
            iconTextView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);

            TextView iconTextView1 = (TextView) starsGrey.getChildAt(i);
            iconTextView1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
        }
        starsRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(14 * 5, this) * item.getLevel() / 5);
        commentStarGroup.removeAllViews();
        commentStarGroup.addView(starsView);

        //评论图片
        if (item.getImages() != null && item.getImages().size() != 0) {
            imageList.setVisibility(View.VISIBLE);
            ArrayList<String> showImgList = new ArrayList<>();
            if (item.getImages().size() > 0) {
                int endIndex = Math.min(4, item.getImages().size());
                for (int i = 0; i < endIndex; i++) {
                    showImgList.add(item.getImages().get(i));
                }
            }
            imageList.setAdapter(new ProfileCommentGridAdapter(this, showImgList, item.getImages().size()));
        } else {
            imageList.setVisibility(View.GONE);
        }
    }

    private void replyComment() {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();

        showProgressDialog("正在发表");
        isPublishing = true;
        if (!isUploadCompleted()) {
            uploadImages();
            return;
        }
        params.put("level", score);
        if (!TextUtils.isEmpty(textReply.getText()))
            params.put("reply", textReply.getText());
        params.put("commentId", commentId);
        JSONArray imageArray = new JSONArray();
        for (String key : uploadedImages.keySet()) {
            imageArray.add(uploadedImages.get(key));
        }
        params.put("images", imageArray);
        HttpClient.get("1.0/comment/updateReply", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideProgressDialog();
                Bundle params = new Bundle();
                params.putBoolean("isComment",true);
                params.putString("orderNo",orderNo);
                Router.sharedRouter().open("publishServiceFinish", params);
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "发表失败，请重试");
            }
        });
    }

    private void setStarFont() {
        StarOnClickListener starOnClickListener = new StarOnClickListener();
        TextView star1 = (TextView) findViewById(R.id.order_judge_grade_1);
        star1.setOnClickListener(starOnClickListener);
        starList.add(star1);
        star1.setTag(1);

        TextView star2 = (TextView) findViewById(R.id.order_judge_grade_2);
        star2.setOnClickListener(starOnClickListener);
        starList.add(star2);
        star2.setTag(2);

        TextView star3 = (TextView) findViewById(R.id.order_judge_grade_3);
        star3.setOnClickListener(starOnClickListener);
        starList.add(star3);
        star3.setTag(3);


        TextView star4 = (TextView) findViewById(R.id.order_judge_grade_4);
        star4.setOnClickListener(starOnClickListener);
        starList.add(star4);
        star4.setTag(4);


        TextView star5 = (TextView) findViewById(R.id.order_judge_grade_5);
        star5.setOnClickListener(starOnClickListener);
        starList.add(star5);
        star5.setTag(5);
    }

    class StarOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            TextView curr = (TextView) v;
            Integer size = (Integer) curr.getTag();
            for (int i = 0; i < starList.size(); i++) {
                TextView star = starList.get(i);
                if (i < size) {
                    star.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    star.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }
            score = size;
            String[] scoreDesc = getResources().getStringArray(R.array.judgeScoreDescription);
            if (score > 0 && score <= scoreDesc.length) {
                levelText.setText(scoreDesc[score - 1]);
                levelText.setVisibility(View.VISIBLE);
            }
            replySupply.setVisibility(View.VISIBLE);
            publishBtn.setVisibility(View.VISIBLE);
        }
    }

    private void initSelectImagesGrid() {
        canPickPicCount = Constant.MAX_IMAGE_LENGTH - images.size();
        adapter = new ServiceGridAdapter(this, images,
                Constant.MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_SERVICE);
        adapter.setTHREE(0);
        selectImagesGrid.setAdapter(adapter);
        adapter.setOnClickListener(new ServiceGridAdapter.OnClickListener() {
            @Override
            public void onAddClick(View v, int position) {
                addImg(position);
            }

            @Override
            public void onEditClick(View v, int position) {
                currentPosition = position;
                addImg(position);
            }

            @Override
            public void onRemoveClick(View v, int position) {
                if (position < images.size()) {
                    images.set(position, "");
                    canPickPicCount++;
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    void addImg(int position) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", canPickPicCount);
        bundle.putInt("position", position);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, this);
    }

    /**
     * 上传图片
     */
    private void uploadImages() {
        if (isUploadCompleted()) {
            return;
        }
        uploadImage(0);
    }

    /**
     * 检查是否上传完成
     *
     * @return
     */
    private boolean isUploadCompleted() {
        for (String image : images) {
            if (!TextUtils.isEmpty(image) && !uploadedImages.containsKey(image)) {
                return false;
            }
        }
        return true;
    }

    private void uploadImage(final int index) {
        if (isUploading) {
            return;
        }
        final String imagePath = images.get(index);
        if (uploadedImages.containsKey(imagePath)) {
            for (int i = 0; i < images.size(); i++) {
                if (!uploadedImages.containsKey(images.get(i))) {
                    uploadImage(i);
                    return;
                }
            }
        }
        isUploading = true;
        RequestSign.upload(imagePath, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                isUploading = false;
                try {
                    JSONObject json = (JSONObject) result;
                    uploadedImages.put(imagePath, json.getString("data"));
                    for (int i = 0; i < images.size(); i++) {
                        if (!uploadedImages.containsKey(images.get(i))) {
                            uploadImage(i);
                            break;
                        }
                    }
                    if (isUploadCompleted() && isPublishing) {
                        replyComment();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(HttpError error) {
                isUploading = false;
                MessageUtils.showToastCenter(error != null ? "上传图片失败失败:" + error.getMessage() : "上传图片失败失败");
                hideProgressDialog();
            }
        });
    }

    private void initTag(FlowLayout tagLayout, List<CommentByServerDO.Tag> tags) {
        tagLayout.removeAllViews();
        if (tags.size() > 0) {
            for (CommentByServerDO.Tag tag : tags) {
                if (TextUtils.isEmpty(tag.getTagName()))
                    break;
                TextView itemView = (TextView) LayoutInflater.from(this).inflate(R.layout.item_comment_tag, tagLayout, false);
                itemView.setText(String.format(getString(R.string.text_comment_tag), tag.getTagName().trim()));
                tagLayout.addView(itemView);
            }
        }
    }
}
