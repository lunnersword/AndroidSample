package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CareerConfirmAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CareerDo;
import com.meidalife.shz.util.LoadUtil;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/4/21.
 */
public class CareerConfirmActivity extends BaseActivity {
    HashSet<String> careerIds;
    List<CareerDo> skillsDoList = new ArrayList<>();

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    ViewGroup contentView;
    @Bind(R.id.skillRecyclerView)
    RecyclerView skillRecyclerView;
    @Bind(R.id.confirmButton)
    TextView confirmButton;

    LoadUtil mLoadUtil;
    CareerConfirmAdapter careerConfirmAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_career_confirm);
        initActionBar("确认职业", true, false);
        ButterKnife.bind(this);
        initComponents();
        getSelectedCareerList();
    }

    private void initComponents() {
        careerIds = (HashSet<String>) getIntent().getSerializableExtra(Constant.EXTRA_TAG_CAREER_IDS);
        mLoadUtil = new LoadUtil(LayoutInflater.from(this));
        careerConfirmAdapter = new CareerConfirmAdapter(this, skillsDoList);

        careerConfirmAdapter.setHeadViewId(R.layout.item_career_confirm_header);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        skillRecyclerView.setAdapter(careerConfirmAdapter);
        skillRecyclerView.setLayoutManager(linearLayoutManager);

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmCareerSelect();
            }
        });
    }

    private void getSelectedCareerList() {
        JSONObject params = new JSONObject();
        mLoadUtil.loadPre(rootView, contentView);
        params.put("ids", JSON.parseArray(JSON.toJSONString(careerIds)));

        HttpClient.get("1.0/skills/confirmList", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                try {
                    mLoadUtil.loadSuccess(contentView);
                    skillsDoList = JSON.parseArray(obj.getJSONArray("skills").toJSONString(), CareerDo.class);
                    careerConfirmAdapter.setSkillsDoList(skillsDoList);
                    careerConfirmAdapter.notifyDataSetChanged();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFail(HttpError error) {
                mLoadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        getSelectedCareerList();
                    }
                });
            }
        });
    }

    private void confirmCareerSelect() {
        JSONObject params = new JSONObject();
        params.put("ids", JSON.parseArray(JSON.toJSONString(careerIds)));
        HttpClient.get("1.0/skills/confirm", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                MessageUtils.showCustomizeToast(LayoutInflater.from(CareerConfirmActivity.this)
                        .inflate(R.layout.view_toast_career_confirm, null), Toast.LENGTH_LONG);
                setResult(RESULT_OK);
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter("确认失败");
            }
        });
    }
}
