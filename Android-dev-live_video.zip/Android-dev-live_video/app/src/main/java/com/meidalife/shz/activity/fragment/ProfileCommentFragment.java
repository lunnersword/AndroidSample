package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ProfileCommentListAdapter;
import com.meidalife.shz.event.ScrollToTopEvent;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CommentByServerDO;
import com.meidalife.shz.util.LoadUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 个人主页-评论
 * Created by liujian on 16/4/6.
 */
public class ProfileCommentFragment extends BaseFragment {

    @Bind(R.id.myListView)
    ListView myListView;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.emptyView)
    View emptyView;
    @Bind(R.id.emptyViewText)
    TextView emptyViewText;

    private View rootView;
    private Context context;
    private ProfileCommentListAdapter profileCommentListAdapter;
    private ScrollToTopEvent scrollToTopEvent;
    private List<CommentByServerDO> commentByServerDOs;
    private LoadUtil loadUtil;
    private boolean isLoading;
    private final int pageSize = 15;
    private int page;
    private boolean isComplete;
    private String userId;

    public void setScrollToTopEvent(ScrollToTopEvent scrollToTopEvent) {
        this.scrollToTopEvent = scrollToTopEvent;
    }

    public static ProfileCommentFragment newInstance(Bundle params) {
        ProfileCommentFragment profileCommentFragment = new ProfileCommentFragment();
        profileCommentFragment.setArguments(params);
        return profileCommentFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            userId = "";
            Bundle params = getArguments();
            if (params != null) {
                userId = params.getString("userId") == null ? "" : params.getString("userId");
            }
            rootView = inflater.inflate(R.layout.fragment_profile_comment, container, false);
            context = getActivity();
            ButterKnife.bind(this, rootView);

            if(userId.equals(Helper.sharedHelper().getUserId())){
                emptyViewText.setText(context.getResources().getString(R.string.text_empty_my_profile_comment));
            }else
                emptyViewText.setText(context.getResources().getString(R.string.text_empty_ta_profile_comment));
            loadUtil = new LoadUtil(inflater);
            commentByServerDOs = new ArrayList<CommentByServerDO>();
            profileCommentListAdapter = new ProfileCommentListAdapter(context, commentByServerDOs);
            myListView.setAdapter(profileCommentListAdapter);
            myListView.setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                        if (view.getLastVisiblePosition() == view.getCount() - 1 && !isComplete) {
                            getData(false);
                        }
                    }

                    final View topChildView = view.getChildAt(0);
                    if (scrollState == SCROLL_STATE_IDLE && view.getFirstVisiblePosition() == 0
                            && topChildView != null && topChildView.getTop() == 0) {
                        scrollToTopEvent.onScrollToTop(true);
                    } else {
                        scrollToTopEvent.onScrollToTop(false);
                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

                }
            });
        }
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getData(true);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    private void getData(final boolean reload) {
        if (isLoading)
            return;
        isLoading = true;
        if (reload) {
            page = 0;
            isComplete = false;
            loadUtil.loadPre(rootLayout, myListView);
        } else {
            if (isComplete) {
                isLoading = false;
                return;
            }
            page++;
        }
        JSONObject params = new JSONObject();
        params.put("offset", pageSize * page);
        params.put("pageSize", pageSize);
        params.put("serverId",userId);
        HttpClient.get("1.0/comment/getCommentForMyPage", params, CommentByServerDO.class, new HttpClient.HttpCallback<List<CommentByServerDO>>() {
            @Override
            public void onSuccess(List<CommentByServerDO> items) {
                if (null == getActivity() || getActivity().isFinishing()) {
                    return;
                }
                isLoading = false;
                loadUtil.loadSuccess(myListView);
                if (reload)
                    commentByServerDOs.clear();
                if (items != null)
                    commentByServerDOs.addAll(items);
                if (commentByServerDOs.size() == 0) {
                    myListView.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    myListView.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                }
                profileCommentListAdapter.notifyDataSetChanged();
                if (items != null && items.size() < pageSize)
                    isComplete = true;
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                if (!reload)
                    page--;
                loadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        getData(true);
                    }
                });
            }
        });
    }


}
