package com.meidalife.shz.activity;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.PopupPhotoAdapter;
import com.meidalife.shz.adapter.ProfileMeRecycleAdapter;
import com.meidalife.shz.adapter.RecommendAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.rest.model.ShopDetailOutDo;
import com.meidalife.shz.rest.request.RequestSearch;
import com.meidalife.shz.rest.request.RequestSquare;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.widget.PopupListMenu;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 店铺详情页
 * Created by zhq 2016/04/30
 */
public class ShopDetailActivity extends BaseActivity implements AbsListView.OnScrollListener {

    private static final int MENU_ITEM_SHARE = 0;
    private static final int MENU_ITEM_JUBAO = 3;


    @Bind(R.id.detail_shop_title)
    TextView shopTitleTextView;
    @Bind(R.id.recyclerview)
    RecyclerView recyclerView;

    @Bind(R.id.detail_phone_group)
    View phoneGroup;
    @Bind(R.id.detail_address_group)
    View addressGroup;

    @Bind(R.id.detail_phone_name)
    TextView phoneTextView;
    @Bind(R.id.detail_address_name)
    TextView addressTextView;
//    @Bind(R.id.shop_server_title)
//    TextView serverTitleTextView;
    @Bind(R.id.shop_server_count)
    TextView serverCountTextView;
    @Bind(R.id.noMsgView)
    ViewGroup noMsgView;

    ViewGroup contentRoot;
    ListView mListView;

    private boolean isComplete = false;
    private boolean isLoading = false;
    private int page = 0;
    private int pageSize = 10;


    private LayoutInflater inflater;
    private RecommendAdapter msgAdapter;
    private PopupWindow popupWindow;
    private PopupListMenu mPopupListMenu;
    private SocialSharePopupWindow socialSharePopupWindow;
    private ShopDetailOutDo shareDO;
    private String shopId;
    List<DynamicUserOutDO> msgList = new LinkedList<>();
    private ShareActivity shareActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_detail);

        initActionBar("门店", true, true);

        mButtonRight.setText(R.string.icon_share);
        mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());

        shareActivity = new ShareActivity(this);

        Bundle extras = getIntent().getExtras();
        shopId = extras.getString("shopId");

        initView();

        initLoadData();
    }

    void initView() {
        contentRoot = (ViewGroup) findViewById(R.id.root_view);
        mListView = (ListView) findViewById(R.id.detail_listview);

        //main view
        View mainView = getLayoutInflater().inflate(R.layout.activity_shop_detail_header, null);
        ButterKnife.bind(this, mainView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        // 为保证head显示，因此无论是否有数据，都设置adapter
        msgAdapter = new RecommendAdapter(this, msgList);
        mListView.setAdapter(msgAdapter);

        mListView.addHeaderView(mainView);


        mButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleBack(v);
            }
        });

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initPopupWindow(v);
            }
        });

        phoneGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //打电话
            }
        });

        addressGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳地图
            }
        });

        mListView.setOnScrollListener(this);
    }


    private void initPhotoListView(final ShopDetailOutDo item) {
        View albumView = LayoutInflater.from(this).inflate(R.layout.album_list, null);
        final ListView albumListView = (ListView) albumView.findViewById(R.id.album_list);
        PopupPhotoAdapter albumListAdapter = new PopupPhotoAdapter(this, item.getShopImg());
        albumListView.setAdapter(albumListAdapter);

        albumListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                popupWindow.dismiss();
            }
        });

        popupWindow = new PopupWindow(albumView, ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setAnimationStyle(R.style.PopupWindowAnimation);
        popupWindow.showAtLocation(contentRoot, Gravity.CENTER, 0, 0);
    }


    public void initLoadData() {
        showStatusLoading(contentRoot);
        RequestSquare.shopDetail(getShopDetailParam(), new HttpClient.HttpCallback<ShopDetailOutDo>() {
            @Override
            public void onSuccess(ShopDetailOutDo shop) {

                loadSuccess(contentRoot);
                hideStatusErrorServer();
                renderItem(shop);

                loadUser(true);

                shareDO = shop;
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(ShopDetailActivity.class.getName(), "req item data fail, itemId=" +
                        shopId + ", " + error.toString());

                loadFail(error, contentRoot, ShopDetailActivity.this, new LoadCallback() {
                    @Override
                    public void execute() {
                        initLoadData();
                    }
                });
            }
        });
    }

    com.alibaba.fastjson.JSONObject getShopDetailParam() {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("shopId", shopId);
        return params;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void renderItem(ShopDetailOutDo item) {

        renderItemView(item);

        //图片处理 采用recylerview + adapter 实现
        renderPhotoView(item);
    }

    void renderItemView(final ShopDetailOutDo item) {
        shopTitleTextView.setText(item.getShopFullName());
        phoneTextView.setText(item.getPhone());
        addressTextView.setText(item.getAddress());

        // 留言Label
//        serverTitleTextView.setText(item.get);
        serverCountTextView.setText(String.format(getString(R.string.tab_title_count), item.getCount()));
    }

    void renderPhotoView(final ShopDetailOutDo item) {
        if (CollectionUtil.isEmpty(item.getShopImg())) {
            recyclerView.setVisibility(View.GONE);
            return;
        }

        ProfileMeRecycleAdapter adViewPageAdapter = new ProfileMeRecycleAdapter(this, item.getShopImg());
//        adViewPageAdapter.setOnClickListener(new ServiceDetailPhotoViewPageAdapter.OnClickListener() {
//            @Override
//            public void onClick() {
//                initPhotoListView(item);
//            }
//        });

        recyclerView.setAdapter(adViewPageAdapter);
    }

    public com.alibaba.fastjson.JSONObject getParams(int page) {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("shopId", shopId);
        params.put("pageSize", pageSize);
        params.put("offset", page * pageSize);
        params.put("typeList", "2,4");
        return params;
    }


    public void loadUser(final boolean reload) {

        if (isLoading) {
            return;
        }
        isLoading = true;

        if (reload) {
            page = 0;
            msgList.clear();
            isComplete = false;
        }

        if (isComplete) {
            return;
        }

        RequestSearch.searchUser(getParams(page), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject object) {
                isLoading = false;
                if (!reload) {
//                    footProgressBar.setVisibility(View.GONE);
                }

                List<DynamicUserOutDO> dataList = null;

                if (object.containsKey("result")) {
                    dataList = JSONObject.parseArray(object.getString("result"), DynamicUserOutDO.class);
                }

                if (CollectionUtil.isEmpty(dataList) || dataList.size() < pageSize) {
                    isComplete = true;
                }

                if (CollectionUtil.isNotEmpty(dataList)) {
                    msgList.addAll(dataList);
                    page++;
                }

                if (CollectionUtil.isNotEmpty(msgList)) {
                    noMsgView.setVisibility(View.GONE);
//                    msgBoardView.setOnScrollListener(ShopDetailActivity.this);
                } else {
                    noMsgView.setVisibility(View.VISIBLE);
                }

                msgAdapter.notifyDataSetChanged();

            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                if (!reload) {
//                    footProgressBar.setVisibility(View.GONE);
                }

//                detailFooter.setVisibility(View.VISIBLE);

                Log.e(ShopDetailActivity.class.getName(), "req comment data fail, itemId=" + shopId + ", " + error.toString());
            }
        });
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
            if (view.getLastVisiblePosition() == view.getCount() - 1) {
                loadUser(false);
            }
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

    }

    public int getScrollY() {
        View c = mListView.getChildAt(0);
        if (c == null) {
            return 0;
        }
        int firstVisiblePosition = mListView.getFirstVisiblePosition();
        int top = c.getTop();
        return -top + firstVisiblePosition * c.getHeight();
    }

    private void jumpToLogin(String action) {
        Bundle bundle = new Bundle();
        bundle.putString("action", action);
        Router.sharedRouter().open("signin", bundle);
    }


    public void myHandleBack(View v) {
        handleBack(v);
    }

    public void initPopupWindow(final View v) {

        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(this, R.layout.popup_window_share_menu, ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        List<MenuVO> menuList = new ArrayList<>();

        menuList.add(MENU_ITEM_SHARE, new MenuVO(R.string.icon_share, getString(R.string.label_share), 1));
        menuList.add(MENU_ITEM_JUBAO, new MenuVO(R.string.icon_jubao, getString(R.string.report), 1));

        mPopupListMenu.setMenuData(menuList);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAsDropDown(v, -50, 0);
        }


        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_SHARE: {
                        shareService(v);
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_JUBAO: {
                        reportService();
                        mPopupListMenu.dismiss();
                        break;
                    }
                }
            }
        });
    }

    private void shareService(View v) {
//        if (shareDO != null) {
//            LogParam param = new LogParam();
//            param.setType(LogUtil.TYPE_CUSTOMIZE);
//            param.setEid(LogUtil.EVENT_ID_SHARE_CLICK);
//            param.setPvid(shareDO.getPvid());
//            LogUtil.log(param);
//        }
//
//        if (socialSharePopupWindow == null) {
//            socialSharePopupWindow = new SocialSharePopupWindow(this, shareDO,
//                    new ShareActivity(this), SocialSharePopupWindow.SHARE_TYPE_SERVICE);
//        }
//        if (socialSharePopupWindow.isShowing()) {
//            socialSharePopupWindow.dismiss();
//        } else {
//            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
//        }
    }


    private void reportService() {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", shopId);
        intent.putExtra("target", Constant.REPORT_TYPE_SERVICE);
        startActivity(intent);
    }


//    private void showOrHideShareList(View v) {
//        if (socialSharePopupWindow == null) {
//            socialSharePopupWindow = new SocialSharePopupWindow(this, shareActivity, 0);
//        }
//        socialSharePopupWindow.setShareUrl(null);
//        socialSharePopupWindow.setShareTitle(shareDO.getUser().getUserNick());
//        socialSharePopupWindow.setShareDescription(shareDO.getContent());
//        socialSharePopupWindow.setShareImage(new UMImage(this, shareDO.getUser().getAvatarUrl()));
//
//        if (socialSharePopupWindow.isShowing()) {
//            socialSharePopupWindow.dismiss();
//        } else {
//            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
//        }
//    }
}
