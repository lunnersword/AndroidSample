package com.meidalife.shz.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.request.RequestContacts;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by shijian on 15/7/9.
 */
public class CoinContactsIntroActivity extends BaseActivity {

    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.inviteTitle)
    TextView inviteTitle;
    @Bind(R.id.inviteValue)
    TextView inviteValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.earn_mcoin_contacts_intro);
        initActionBar(R.string.title_earn_mcoin_contacts, true);

        ButterKnife.bind(this);

        if (!Helper.sharedHelper().hasToken()) {
            Helper.sharedHelper().jumpToLogin("earn_mcoin_contacts_intro", CoinContactsIntroActivity.this);
        }

        Button inviteBt = (Button) findViewById(R.id.invite_contacts_bt);
        inviteBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("earn_mcoin_contacts");
            }
        });

        View mcoinIntro = findViewById(R.id.mcoin_intro);
        mcoinIntro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", Constant.URL_MBILL_RULE);
                Router.sharedRouter().open("web", bundle);
            }
        });

        initLoadData();
    }

    public void initLoadData() {
        loadPre(rootView, scrollView);
        RequestContacts.share(new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                try {
                    loadSuccess(scrollView);
//                    JSONObject obj = (JSONObject) result;
//                    JSONObject data = obj.getJSONObject("data");
                    if (result.containsKey("inviteRegisterPoint")) {
                        inviteValue.setText(result.getString("inviteRegisterPoint") + "个");
                    }
                    
                    if (result.containsKey("invitationInfo")) {
                        inviteTitle.setText(result.getString("invitationInfo"));
                    }
                } catch (Exception e) {
                    Log.e(ShareInviteActivity.class.getName(), "unknown exception", e);
                    loadFail(new HttpError(HttpError.ERR_CODE_SERVER_ERROR, getString(R.string.error_server_500)),
                            rootView, CoinContactsIntroActivity.this, new LoadCallback() {
                                @Override
                                public void execute() {
                                    initLoadData();
                                }
                            });
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initLoadData();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initLoadData();
                        }
                    });
                }
            }
        });
    }
}
