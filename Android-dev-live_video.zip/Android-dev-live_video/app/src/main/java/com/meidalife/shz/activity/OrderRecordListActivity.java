package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.OrderRecordListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.UserOrderDO;
import com.meidalife.shz.util.LoadUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 买单记录
 * Created by liujian on 16/4/21.
 */
public class OrderRecordListActivity extends BaseActivity{
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.myListView)
    ListView myListView;
    @Bind(R.id.emptyView)
    View emptyView;

    private List<UserOrderDO.Order> orderList;
    private OrderRecordListAdapter orderRecordListAdapter;
    private LoadUtil loadUtil;
    private final int pageSize = 15;
    private int page;
    private boolean isComplete;
    private boolean isLoading;
    private int roleType = 1;   //1 买单记录 2 收款记录

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_order_record_list);
        ButterKnife.bind(this);


        if(getIntent().getStringExtra("type") != null)
            roleType = Integer.parseInt(getIntent().getStringExtra("type"));
        initActionBar(roleType == 1? R.string.title_activity_order_record : R.string.title_activity_order_seller_record, true);
        orderList = new ArrayList<UserOrderDO.Order>();
        loadUtil = new LoadUtil(LayoutInflater.from(this));
        orderRecordListAdapter = new OrderRecordListAdapter(this,orderList);
        myListView.setAdapter(orderRecordListAdapter);
        initListener();
    }

    @Override
    public void onResume() {
        super.onResume();
        initData(true);
    }

    private void initListener() {
        myListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        initData(false);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
            }
        });
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                initData(true);
            }
        });
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            }
        });
    }

    private void initData(final boolean refresh){
        if (isLoading)
            return;
        isLoading = true;
        if (refresh) {
            page = 0;
            isComplete = false;
            loadUtil.loadPre(rootView, swipeRefreshLayout);
        } else {
            if (isComplete) {
                isLoading = false;
                return;
            }
            page++;
        }
        JSONObject params = new JSONObject();
        params.put("page", pageSize * page);
        params.put("pageSize", pageSize);
        params.put("roleType",roleType);
        HttpClient.get("1.0/skill/userOrder/gets", params, UserOrderDO.class, new HttpClient.HttpCallback<UserOrderDO>() {
            @Override
            public void onSuccess(UserOrderDO obj) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                loadUtil.loadSuccess(swipeRefreshLayout);
                if (refresh)
                    orderList.clear();
                if (obj != null && obj.getOrders() != null) {
                    orderList.addAll(obj.getOrders());
                }
                if (orderList.size() == 0) {
                    swipeRefreshLayout.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                }
                orderRecordListAdapter.notifyDataSetChanged();
                if (obj.getOrders() != null && obj.getOrders().size() < pageSize)
                    isComplete = true;
            }

            @Override
            public void onFail(HttpError error) {
                loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initData(true);
                    }
                });
            }
        });
    }
}
