package com.meidalife.shz.activity.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.ViewLocationActivity;
import com.meidalife.shz.adapter.CategoryTagRecyclerAdapter;
import com.meidalife.shz.adapter.SquareNearByListAdapter;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.SquareRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.rest.model.SquareCategoryItemDO;
import com.meidalife.shz.widget.PopupListMenu;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 汇生活-格子
 * Created by xingchen on 2015/12/16.
 */
public class SquareNearByFragment extends BaseFragment {

    private int geziId = Integer.MAX_VALUE;
    private int catId = Integer.MAX_VALUE;
    private boolean isGezhu = false;
    private View rootView;
    private Context context;
    private boolean hasInitData = false;
    private boolean isComplete;
    private int page = 0;
    private boolean isRefresh = false;
    private boolean isLoad = false;
    private static int GET_DATA_REFRESH = 0;  // 刷新数据
    private static int GET_DATA_LOAD_MORE = 1;  //加载更多数据
    private static int PUBLISH_REQUEST_CODE = 88;
    private static final int MENU_ITEM_CALL = 0;
    private static final int MENU_ITEM_CANCEL = 1;
    private static final int MENU_ITEM_UPDATE = 2;

    @Bind(R.id.serviceList)
    ListView serviceListView;
    @Bind(R.id.cellStatusErrorNetwork)
    LinearLayout cellStatusErrorNetwork;
    @Bind(R.id.cellStatusErrorServer)
    LinearLayout cellStatusErrorServer;
    @Bind(R.id.cellStatusDotLoading)
    LinearLayout cellStatusDotLoading;
    @Bind(R.id.noDataLayout)
    LinearLayout noDataLayout;
    @Bind(R.id.hint_message)
    TextView hintMessage;
    @Bind(R.id.textStatusErrorServer)
    TextView textStatusErrorServer;
    @Bind(R.id.nearByHintLayout)
    LinearLayout nearByHintLayout;
    @Bind(R.id.categoryList)
    RecyclerView categoryListView;
    @Bind(R.id.line)
    View line;
    private View listFooter;
    private ProgressBar footerLoading;
    private Button footerReload;
    private TextView footerMessage;
    private AnimationDrawable loadingAnimation;
    private CategoryTagRecyclerAdapter categoryTagRecyclerAdapter;
    private SquareNearByListAdapter squareNearByListAdapter;
    private boolean isFirstLoad = false;
    PopupListMenu mPopupListMenu;
    private ProgressDialog progressDialog;

    private List<SquareCategoryItemDO> catList;

    public static SquareNearByFragment newInstance(Bundle params) {
        SquareNearByFragment squareNearByFragment = new SquareNearByFragment();
        squareNearByFragment.setArguments(params);
        return squareNearByFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        EventBus.getDefault().register(this);
        if (rootView == null) {
            Bundle params = getArguments();
            if (params != null) {
                geziId = Integer.parseInt(params.getString("geziId"));
                isGezhu = params.getBoolean("isGezhu", false);
            }
            rootView = inflater.inflate(R.layout.fragment_square_list, container, false);
            context = getActivity();
            ButterKnife.bind(this, rootView);
            hintMessage.setText(R.string.square_no_content);

            listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
            footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
            footerMessage = (TextView) listFooter.findViewById(R.id.message);
            footerReload = (Button) listFooter.findViewById(R.id.footerReload);
            serviceListView.addFooterView(listFooter);

            squareNearByListAdapter = new SquareNearByListAdapter(context, new JSONArray(), new JSONArray());
            squareNearByListAdapter.setGezhu(isGezhu);
            serviceListView.setAdapter(squareNearByListAdapter);
            serviceListView.setDivider(new ColorDrawable(Color.WHITE));
            serviceListView.setDividerHeight((int) Helper.convertDpToPixel(8, context));

            ViewGroup.LayoutParams layoutParams = categoryListView.getLayoutParams();
            layoutParams.height = (int) Helper.convertDpToPixel(42, context);
            categoryListView.setLayoutParams(layoutParams);
            catList = new ArrayList<SquareCategoryItemDO>();
            categoryTagRecyclerAdapter = new CategoryTagRecyclerAdapter(context, catList, CategoryTagRecyclerAdapter.LIFE_COLLECT);
            categoryListView.setAdapter(categoryTagRecyclerAdapter);

            //设置布局管理器
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
            categoryListView.setLayoutManager(linearLayoutManager);

            listFooter.setVisibility(View.GONE);
            hideContentView();

            page = 0;
            isComplete = false;
            isLoad = false;
            showStatusLoading();

            initListener();

        }

        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // if (!hasInitData)
        isFirstLoad = true;
        getData(GET_DATA_REFRESH, true);
        // hasInitData = true;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }


    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    public void onEvent(SquareRefreshEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isRefresh) {
            //isJoined = event.isJoined;
            isGezhu = event.isGezhu;

            squareNearByListAdapter.setGezhu(isGezhu);
            getData(GET_DATA_REFRESH, true);
        }
    }

    private void initListener() {
        cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData(GET_DATA_REFRESH, true);
            }
        });
        cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getData(GET_DATA_REFRESH, true);
            }
        });

        serviceListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                BaseEvent message = new BaseEvent();
                final View topChildView = serviceListView.getChildAt(0);
                if (scrollState == SCROLL_STATE_IDLE && serviceListView.getFirstVisiblePosition() == 0
                        && topChildView.getTop() == 0) {
                    message.eventType = MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                } else {
                    message.eventType = MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                }

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        getData(GET_DATA_LOAD_MORE, false);
                    }
                }

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

        squareNearByListAdapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.addressIcon: {
                        HashMap pos = (HashMap) v.getTag();
                        if (pos == null)
                            return;
                        Bundle bundle = new Bundle();
                        bundle.putDouble(ViewLocationActivity.LOCATION_LNG, (double) pos.get(Constant.GPS_LONG));
                        bundle.putDouble(ViewLocationActivity.LOCATION_LAT, (double) pos.get(Constant.GPS_LAT));
                        Router.sharedRouter().open("viewPosition", bundle);
                        break;
                    }
                    case R.id.callPhone:
                    case R.id.phoneIcon: {
                        if (v.getTag() == null)
                            return;
                        List<MenuVO> menuList = new ArrayList<>();
                        menuList.add(MENU_ITEM_CALL, new MenuVO(getString(R.string.call)));
                        menuList.add(MENU_ITEM_CANCEL, new MenuVO(getString(R.string.cancel)));
                        showOrHidePopMenu(v, menuList, v.getTag());
                        break;
                    }
                    case R.id.pinHandlerView: {   //操作
                        if (v.getTag() == null)
                            return;
                        List<MenuVO> menuList = new ArrayList<>();
                        menuList.add(MENU_ITEM_CALL, new MenuVO(getString(R.string.detail_edit)));
                        menuList.add(MENU_ITEM_CANCEL, new MenuVO(getString(R.string.delete)));
                        menuList.add(MENU_ITEM_UPDATE, new MenuVO(getString(R.string.cancel)));
                        showOrHidePopMenu(v, menuList, v.getTag());
                        break;
                    }
                }

            }
        });

        categoryTagRecyclerAdapter.setOnClickCategoryListener(new CategoryTagRecyclerAdapter.RefreshCategoryView() {
            @Override
            public void refreshCategory(int id) {
                catId = id;
                getData(GET_DATA_REFRESH, true);
            }
        });

    }

    private void initCat(JSONArray cats) {
        catList.clear();
        SquareCategoryItemDO categoryItemDO;
        for (int i = 0; i < cats.size(); i++) {
            categoryItemDO = new SquareCategoryItemDO();
            JSONObject cat = cats.getJSONObject(i);
            if (cat.containsKey("catId"))
                categoryItemDO.setCatId(cat.getIntValue("catId"));
            if (cat.containsKey("catName"))
                categoryItemDO.setCatName(cat.getString("catName"));
            catList.add(categoryItemDO);
        }

        catId = catList.get(0).getCatId();
        categoryListView.setVisibility(View.VISIBLE);
        line.setVisibility(View.VISIBLE);
        categoryTagRecyclerAdapter.setSelectPos(0);
        categoryTagRecyclerAdapter.notifyDataSetChanged();
    }


    /**
     * @param loadType 0:刷新，1：加载更多
     */
    private void getData(final int loadType, boolean showLoading) {
        if (showLoading) {
            serviceListView.setVisibility(View.GONE);
            showStatusLoading();
        }
        if (loadType == GET_DATA_REFRESH) {
            cellStatusErrorNetwork.setVisibility(View.GONE);
            cellStatusErrorServer.setVisibility(View.GONE);
            /*if (isRefresh)
                return;*/
            isRefresh = true;
            page = 0;
            isComplete = false;
        }

        if (loadType == GET_DATA_LOAD_MORE) {
            if (isLoad || isComplete)
                return;
            footerMessage.setText(getString(R.string.text_loading));
            listFooter.setVisibility(View.VISIBLE);
            footerLoading.setVisibility(View.VISIBLE);
            footerMessage.setVisibility(View.VISIBLE);
            footerReload.setVisibility(View.GONE);
            isLoad = true;
            page++;
        }
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        if (catId != Integer.MAX_VALUE) {
            params.put("catId", catId);
        }
        params.put("pageSize", 20);
        params.put("offset", page * 20);
        HttpClient.get("1.0/gezi/yp/gets", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                if (loadType == GET_DATA_REFRESH) {
                    isRefresh = false;
                    hideStatusLoading();
                } else {
                    isLoad = false;
                }
                try {
                    if (isFirstLoad) {
                        JSONArray catList = obj.getJSONArray("catList");
                        if (loadType == GET_DATA_REFRESH && catList != null)
                            initCat(catList);
                        isFirstLoad = false;
                    }

                    com.alibaba.fastjson.JSONArray mobileList = null;
                    if (obj.containsKey("mobileList"))
                        mobileList = obj.getJSONArray("mobileList");
                    com.alibaba.fastjson.JSONArray ypList = obj.getJSONArray("ypList");

                    if (mobileList == null)
                        mobileList = new com.alibaba.fastjson.JSONArray();
                    if (ypList == null)
                        ypList = new com.alibaba.fastjson.JSONArray();

                    if (loadType == GET_DATA_REFRESH) {
                        squareNearByListAdapter.setMobileList(mobileList);
                        squareNearByListAdapter.setYpList(ypList);
                    } else {
                        listFooter.setVisibility(View.GONE);
                        squareNearByListAdapter.addYpList(ypList);
                    }


                    if (mobileList.size() == 0 && ypList.size() == 0) {
                        if (loadType == GET_DATA_REFRESH) {
                            serviceListView.setVisibility(View.GONE);
                            noDataLayout.setVisibility(View.VISIBLE);
                        } else
                            listFooter.setVisibility(View.GONE);
                    } else {
                        noDataLayout.setVisibility(View.GONE);
                        serviceListView.setVisibility(View.VISIBLE);
                        squareNearByListAdapter.notifyDataSetChanged();
                    }

                    if (ypList.size() < 20) {
                        isComplete = true;
                        serviceListView.removeFooterView(listFooter);
                    }
                } catch (JSONException e) {
                    hideContentView();
                    cellStatusErrorServer.setVisibility(View.VISIBLE);
                    e.printStackTrace();
                }

            }

            @Override
            public void onFail(HttpError error) {
                if (loadType == GET_DATA_REFRESH) {
                    isRefresh = false;
                    hideStatusLoading();
                    hideContentView();
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        cellStatusErrorNetwork.setVisibility(View.VISIBLE);
                        return;
                    }
                    if (!TextUtils.isEmpty(error.getMessage())) {
                        textStatusErrorServer.setText(error.getMessage());
                    }
                    cellStatusErrorServer.setVisibility(View.VISIBLE);
                } else {
                    page--;
                    isLoad = false;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);

                    listFooter.setVisibility(View.VISIBLE);
                    footerReload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getData(loadType, false);
                        }
                    });
                }
            }
        });
    }


    private void showOrHidePopMenu(View v, List<MenuVO> menuList, final Object data) {
        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(getActivity(), 0);
        }
        final int size = menuList.size();
        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_CALL: {
                        if (size == 2) {
                            Helper.makeCall(getActivity(), String.valueOf(data));
                        } else if (size == 3) {
                            HashMap tag = (HashMap) data;
                            int type = (int) tag.get("type");
                            int pos = (int) tag.get("pos");
                            if (type == SquareNearByListAdapter.HOLDER_TYPE_PHONE) {
                                Bundle params = new Bundle();
                                JSONObject item = (JSONObject) squareNearByListAdapter.getMobileList().get(pos);
                                params.putInt("id", item.containsKey("id") ? item.getIntValue("id") : Integer.MAX_VALUE);
                                params.putString("name", item.containsKey("name") ? item.getString("name") : "");
                                params.putString("mobile", item.containsKey("mobile") ? item.getString("mobile") : "");
                                Router.sharedRouter().openFormResult("squaremanage/phone/update/" + geziId, params, PUBLISH_REQUEST_CODE, getActivity());
                            } else if (type == SquareNearByListAdapter.HOLDER_TYPE_SERVICE) {
                                Bundle params = new Bundle();
                                JSONObject item = (JSONObject) squareNearByListAdapter.getYpList().get(pos);
                                if (item.containsKey("id"))
                                    Router.sharedRouter().openFormResult("squareNearByPublish/update/" + geziId + "/" + item.getIntValue("id"),
                                            params, PUBLISH_REQUEST_CODE, getActivity());
                            }
                        }
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_CANCEL: {
                        if (size == 3) {
                            HashMap tag = (HashMap) data;
                            int type = (int) tag.get("type");
                            int pos = (int) tag.get("pos");
                            if (type == SquareNearByListAdapter.HOLDER_TYPE_PHONE) {
                                JSONObject item = (JSONObject) squareNearByListAdapter.getMobileList().get(pos);
                                if (item.containsKey("id"))
                                    deleteItem("1.0/gezi/yp/delMobile", item.getIntValue("id"));
                            } else if (type == SquareNearByListAdapter.HOLDER_TYPE_SERVICE) {
                                JSONObject item = (JSONObject) squareNearByListAdapter.getYpList().get(pos);
                                if (item.containsKey("id"))
                                    deleteItem("1.0/gezi/yp/del", item.getIntValue("id"));
                            }
                        }
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_UPDATE:
                        mPopupListMenu.dismiss();
                        break;
                }
            }
        });
        mPopupListMenu.setMenuData(menuList);
        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private void deleteItem(String path, int itemId) {
        showProgressDialog(getString(R.string.text_deleting), true);
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        params.put("id", itemId);
        Log.d("params", geziId + "-" + itemId);
        HttpClient.get(path, params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideProgressDialog();
                getData(GET_DATA_REFRESH, true);
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : getString(R.string.text_delete_fail));
            }
        });
    }

    private void hideContentView() {
        categoryListView.setVisibility(View.GONE);
        line.setVisibility(View.GONE);
        serviceListView.setVisibility(View.GONE);
    }

    private void showStatusLoading() {
        try {
            cellStatusDotLoading.setVisibility(View.VISIBLE);
//            loadingAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.loading_animation);
//            ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
//            loadingImage.setBackgroundDrawable(loadingAnimation);
//            loadingAnimation.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideStatusLoading() {
        try {
            if (cellStatusDotLoading != null) {
                cellStatusDotLoading.setVisibility(View.GONE);
//                if (loadingAnimation != null) {
//                    loadingAnimation.stop();
//                    loadingAnimation = null;
//                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public synchronized void showProgressDialog(String msg, boolean cancelable) {
        if (progressDialog == null) {
            progressDialog = MessageUtils.getProgressDialog(getActivity(), msg);
        }
        progressDialog.setCancelable(cancelable);
        progressDialog.setMessage(msg);
        if (!getActivity().isFinishing()) {
            progressDialog.show();
        }
    }

    public synchronized void hideProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

}
