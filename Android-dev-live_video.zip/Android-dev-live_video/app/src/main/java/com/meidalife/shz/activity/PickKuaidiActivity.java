package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.CitySidebarView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class PickKuaidiActivity extends BaseActivity {

    private LayoutInflater inflater;
    private ViewGroup rootView;
    private RelativeLayout logisticsRoot;
    private LoadUtil mLoadUtil;

    private ListView logisticsList;
    private NavAdapter navAdapter;
    private CitySidebarView sidebarView;
    private TextView dialog;

    private List<String> navCharsList;

    private List<String> otherNavList = Arrays.asList("#", "a", "b", "c", "d", "e", "f", "g", "h", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z");
    List<LogisticsVO> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_logistics);
        initActionBar(R.string.title_order_logistics, true);
        inflater = getLayoutInflater();
        mLoadUtil = new LoadUtil(inflater);

        rootView = (ViewGroup) findViewById(R.id.root_view);
        logisticsRoot = (RelativeLayout) findViewById(R.id.logistics_root_view);
        logisticsList = (ListView) findViewById(R.id.logistics_list);
        dialog = (TextView) findViewById(R.id.dialog);

        initLoadData();
    }

    public void initLoadData() {
        mLoadUtil.loadPre(rootView, logisticsRoot);
        HttpClient.get("1.0/logistics/getCompanys", null, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                mLoadUtil.loadSuccess(logisticsRoot);
                navCharsList = new ArrayList<String>();
                JSONObject companyDatas = obj.getJSONObject("companyMap");
                //热门快递
                JSONArray hotCompanyDatas = obj.getJSONArray("hotCompanys");

                dataList = new ArrayList<LogisticsVO>();
                ArrayList navList = new ArrayList();
                int index = 0;
                if (!hotCompanyDatas.isEmpty()) {
                    navCharsList.add("热");
                    HashMap navPos = new HashMap();
                    navPos.put("name", "热");
                    navPos.put("position", 0);
                    navList.add(navPos);
                    // 正常显示数据
                    LogisticsVO navVO = new LogisticsVO();
                    navVO.type = LogisticsVO.TYPE_NAV;
                    navVO.name = "热门";
                    dataList.add(navVO);
                    for (int i = 0; i < hotCompanyDatas.size(); i++) {
                        dataList.add(parse(hotCompanyDatas.getJSONObject(i)));
                    }
                    index = 1;
                }
                navCharsList.addAll(otherNavList);
                for (int i = index; i < navCharsList.size(); i++) {   //fixme jsonObject无序，因此只能写死遍历
                    String nav = navCharsList.get(i).toUpperCase();
                    JSONArray sameNavData = companyDatas.getJSONArray(nav);
                    if (sameNavData == null)
                        continue;
                    // 记录索引位置
                    HashMap navPos = new HashMap();
                    navPos.put("name", nav);
                    navPos.put("position", dataList.size());
                    navList.add(navPos);
                    // 正常显示数据
                    LogisticsVO navVO = new LogisticsVO();
                    navVO.type = LogisticsVO.TYPE_NAV;
                    navVO.name = nav;
                    dataList.add(navVO);
                    for (int j = 0; j < sameNavData.size(); j++) {
                        dataList.add(parse(sameNavData.getJSONObject(j)));
                    }
                }

                // 设置适配器
                navAdapter = new NavAdapter(dataList);
                logisticsList.setAdapter(navAdapter);
                logisticsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        view.setBackgroundColor(getResources().getColor(R.color.grey_c));
                        Intent intent = new Intent();
                        Bundle bundle = new Bundle();
                        LogisticsVO lv = dataList.get(position);
                        bundle.putString("name", lv.name);
                        bundle.putString("code", lv.code);
                        intent.putExtras(bundle);
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                });

                initSlidebarView(navList);
            }

            @Override
            public void onFail(HttpError error) {
                mLoadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initLoadData();
                    }
                });
            }
        });
    }

    class NavAdapter extends BaseAdapter {

        private List<LogisticsVO> datas;

        public NavAdapter(List<LogisticsVO> datas) {
            this.datas = datas;
        }

        @Override
        public int getCount() {
            return datas.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = inflater.inflate(R.layout.activity_pick_logistics_item, logisticsList, false);
            LogisticsVO lv = datas.get(position);
            TextView logisticsName = (TextView) v.findViewById(R.id.logistics_name);
            logisticsName.setText(lv.name);
            if (lv.type == LogisticsVO.TYPE_CELL) {
                logisticsName.setBackgroundColor(getResources().getColor(R.color.white));
            } else {
                logisticsName.setBackgroundColor(getResources().getColor(R.color.grey_e));
            }
            convertView = v;
            return convertView;
        }
    }


    private void initSlidebarView(final ArrayList data) {
        sidebarView = new CitySidebarView(PickKuaidiActivity.this);
        sidebarView.setLabels(data);
        sidebarView.setTextView(dialog);
        sidebarView.setOnTouchingLetterChangedListener(new CitySidebarView.OnTouchingLetterChangedListener() {
            @Override
            public void onTouchingLetterChanged(String s, int index) {
                HashMap item = (HashMap) data.get(index);
                int position = (int) item.get("position");
                if (position != -1) {
                    logisticsList.setSelection(position);
                }
            }
        });
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(80, ViewGroup.LayoutParams.MATCH_PARENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
        params.topMargin = 100;
        params.bottomMargin = 100;
        logisticsRoot.addView(sidebarView, params);
    }


    private LogisticsVO parse(JSONObject json) {
        LogisticsVO logisticsVO = new LogisticsVO();
        logisticsVO.type = LogisticsVO.TYPE_CELL;
        logisticsVO.code = json.getString("code");
        logisticsVO.name = json.getString("name");
        return logisticsVO;
    }

    class LogisticsVO {
        public static final int TYPE_CELL = 0;
        public static final int TYPE_NAV = 1;
        public int type;
        public String code;
        public String name;
    }
}
