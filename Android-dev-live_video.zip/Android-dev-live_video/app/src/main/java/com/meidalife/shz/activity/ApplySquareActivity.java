package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import android.widget.ScrollView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareApplyQualificationAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.MyListView;
import com.meidalife.shz.widget.CheckableIconText;
import com.meidalife.shz.widget.TutorialPopupWindow;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 申请格子
 */
public class ApplySquareActivity extends BaseActivity {
    private String geziApplyExamUrl;//# 申请答题考试h5页面url
    private String agreementUrl;
    private boolean passed = false;

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.contentView)
    ViewGroup contentView;
    @Bind(R.id.listView)
    MyListView listView;
    @Bind(R.id.agreementLayout)
    ViewGroup agreementLayout;
    @Bind(R.id.agreementCheckBox)
    CheckableIconText agreementCheckBox;
    @Bind(R.id.checkProBtn)
    View agreementLink;
    @Bind(R.id.createBtn)
    View createBtn;

    TutorialPopupWindow tutorialPopupWindow;
    SquareApplyQualificationAdapter qualifyAdapter;
    LoadUtil loadUtilV2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_apply);
        initActionBar("申请格子", true, false);

        ButterKnife.bind(this);

        agreementCheckBox.setDefaultCheckedColor(R.color.brand_b);
        agreementCheckBox.setChecked(true);

        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", geziApplyExamUrl);
                Router.sharedRouter().open("selectSquareAddress", bundle);
            }
        });

        agreementLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleAgreementUrl(agreementUrl);
            }
        });

        agreementLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agreementCheckBox.toggle();
                createBtn.setEnabled(agreementCheckBox.isChecked() && passed);
            }
        });
        loadUtilV2 = new LoadUtil(LayoutInflater.from(this));
    }

    @Override
    public void onResume() {
        super.onResume();

        if (Helper.sharedHelper().hasToken()) {
            xhrQualification();
        } else {
            Bundle bundle = new Bundle();
            bundle.putString("action", "createSquare");
            Router.sharedRouter().open("signin", bundle);
            finish();
        }
    }

    void xhrQualification() {
        loadUtilV2.loadPre(rootView, scrollView);

        HttpClient.get("1.0/gezi/apply/qualification", new JSONObject(), JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject result) {
                        loadUtilV2.loadSuccess(scrollView);
                        hideStatusLoading();
                        updateView(result);
                    }

                    @Override
                    public void onFail(HttpError error) {
                        loadUtilV2.loadFail(error, rootView, new LoadUtil.Callback() {
                            @Override
                            public void retry() {
                                xhrQualification();
                            }
                        });
                    }
                });
    }

    void updateView(JSONObject result) {
        String alertMsg = result.getString("alertMsg");
        geziApplyExamUrl = result.getString("geziApplyExamUrl");

        agreementUrl = result.getString("agreementUrl");

        passed = result.getBoolean("passed");

        JSONArray qualification = result.getJSONArray("qualification");

        qualifyAdapter = new SquareApplyQualificationAdapter(this, qualification);
        listView.setAdapter(qualifyAdapter);

        createBtn.setEnabled(passed && agreementCheckBox.isChecked());

        if (!TextUtils.isEmpty(alertMsg)) {
            showWarnPopup(alertMsg);
        }
    }

    public void handleAgreementUrl(String url) {
        Intent intent = new Intent();
        intent.setClass(this, WebActivity.class);
        intent.putExtra("url", url);
        startActivity(intent);
    }

    private void showWarnPopup(String alertMsg) {
        try {
            if (tutorialPopupWindow == null) {
                tutorialPopupWindow = new TutorialPopupWindow(this,
                        TutorialPopupWindow.TUTORIAL_TYPE_CUSTOMIZE);
                tutorialPopupWindow.addTutorialItems(new TutorialPopupWindow.TutorialItem(null, alertMsg,
                        R.mipmap.emotion_no_item_normal, getString(R.string.i_know)));

                tutorialPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                    @Override
                    public void onDismiss() {
//                        finish();
                    }
                });
            }

            if (!tutorialPopupWindow.isShowing() && !isFinishing()) {
                tutorialPopupWindow.showTutorial(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
