package com.meidalife.shz.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.CommentActivity;
import com.meidalife.shz.activity.ReplyCommentActivity;
import com.meidalife.shz.rest.model.UserOrderDO;
import com.meidalife.shz.rest.request.RequestLotteryList;
import com.meidalife.shz.util.OrderUtil;
import com.meidalife.shz.view.FontTextView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by liujian on 16/4/21.
 */
public class OrderRecordListAdapter extends BaseAdapter implements View.OnClickListener{
    private List<UserOrderDO.Order> orders;
    private LayoutInflater inflater;
    private Context context;

    public OrderRecordListAdapter(Context context, List<UserOrderDO.Order> orders) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.orders = orders;
    }

    @Override
    public int getCount() {
        return orders.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_order_record_list, parent, false);
            holder = new ViewHolder();
            holder.nickName = (TextView) convertView.findViewById(R.id.nickName);
            holder.orderTime = (TextView) convertView.findViewById(R.id.orderTime);
            holder.orderStatus = (TextView) convertView.findViewById(R.id.orderStatus);
            holder.skillName = (TextView) convertView.findViewById(R.id.skillName);
            holder.price = (TextView) convertView.findViewById(R.id.price);
            holder.ownAmount = (TextView) convertView.findViewById(R.id.ownAmount);
            holder.userAvatar = (SimpleDraweeView) convertView.findViewById(R.id.userAvatar);
            holder.oprBtList = (LinearLayout)convertView.findViewById(R.id.order_opr_bt_list);
            holder.oprBtPlacer = (LinearLayout)convertView.findViewById(R.id.order_opr_bt_list);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        UserOrderDO.Order item = orders.get(position);
        holder.nickName.setText(item.getUser().getUserNick());
        if (item.getUser().getAvatar() != null)
            holder.userAvatar.setImageURI(Uri.parse(item.getUser().getAvatar()));
        holder.orderStatus.setText(item.getStatusText());
        holder.orderTime.setText(item.getCreateTime());
        holder.price.setText("消费: " + item.getPrice() + "元");
        if(item.getOwnAmount() == null){
            holder.ownAmount.setVisibility(View.GONE);
        }else{
            holder.ownAmount.setVisibility(View.VISIBLE);
            holder.ownAmount.setText("实付: " + item.getOwnAmount() + "元");
        }
        holder.skillName.setText(item.getSkillName());
        addOprBt(holder,item);
        return convertView;
    }

    /**
     * 增加可操作列表
     *
     * @param holder
     * @param order
     */
    private void addOprBt(ViewHolder holder, UserOrderDO.Order order) {
        holder.oprBtList.removeAllViews();
        List<Object[]> actionList = OrderUtil.getAllOperateList(order.getOperate(), null);
        //卖家回复评论查看评论不共存（为解决卖家能修改买家评论BUG）
        actionList = OrderUtil.removeCommentOpr(actionList);
        if (actionList.size() == 0) {
            holder.oprBtPlacer.setVisibility(View.GONE);
            return;
        } else {
            holder.oprBtPlacer.setVisibility(View.VISIBLE);
        }
        for (int i = 0; i < actionList.size(); i++) {
            TextView bt = new FontTextView(context);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) Helper.convertDpToPixel(70, context),
                    (int) Helper.convertDpToPixel(30, context));
            params.setMargins(0, 0, (int) Helper.convertDpToPixel(10, context), 0);
            bt.setLayoutParams(params);
            bt.setGravity(Gravity.CENTER);
            bt.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
            Object[] data = actionList.get(i);
            if ((int) data[2] == 0) {
                bt.setTextColor(context.getResources().getColor(R.color.grey_a));
                bt.setBackgroundResource(R.drawable.order_list_edit_bg_white);
            } else {
                bt.setTextColor(context.getResources().getColor(R.color.brand_b));
                bt.setBackgroundResource(R.drawable.order_list_edit_bg_red);
            }
            bt.setText((String) data[1]);
            HashMap<String, Object> hashMap = new HashMap<String, Object>();
            hashMap.put("data", order);
            hashMap.put("action", data[0]);
            bt.setTag(hashMap);
            bt.setOnClickListener(this);
            holder.oprBtList.addView(bt);
        }
    }

    @Override
    public void onClick(View v) {
        HashMap<String, Object> hashMap = (HashMap<String, Object>) v.getTag();
        final UserOrderDO.Order order = (UserOrderDO.Order) hashMap.get("data");
        Long operate = (Long) hashMap.get("action");
        if((OrderUtil.OPERATE_BUYER_CAN_COMMENT & operate) == OrderUtil.OPERATE_BUYER_CAN_COMMENT ){  //评价
//            orderNo = getIntent().getStringExtra("orderNo");
//            canModify = getIntent().getIntExtra("canModify", 0);
            Intent intent = new Intent(context, CommentActivity.class);
            intent.putExtra("orderNo",order.getOrderNo());
            context.startActivity(intent);
        }

        if((OrderUtil.OPERATE_SELLER_CAN_COMMENT & operate) == OrderUtil.OPERATE_SELLER_CAN_COMMENT ){  //回复评价
            Intent intent = new Intent(context, ReplyCommentActivity.class);
            intent.putExtra("orderNo",order.getOrderNo());
           // intent.putExtra("roleType", (int) order.getRoleType());
            context.startActivity(intent);
        }

        if((OrderUtil.OPERATE_SEE_COMMENT & operate) == OrderUtil.OPERATE_SEE_COMMENT ){   //查看评价
            Router.sharedRouter().open("orderCommentByOrderId/" + order.getOrderNo(), context);
        }
        /*
            支付
             */
        if ((OrderUtil.OPERATE_BUYER_CAN_PAY & operate) == OrderUtil.OPERATE_BUYER_CAN_PAY) {
            Bundle bundle = new Bundle();
            bundle.putString("orderNo", order.getOrderNo());
            bundle.putString("title", order.getSkillName());
            Router.sharedRouter().open("pay", bundle);
        }
    }

    class ViewHolder {
        SimpleDraweeView userAvatar;
        TextView nickName;
        TextView orderTime;
        TextView orderStatus;
        TextView skillName;
        TextView price;
        TextView ownAmount;
        LinearLayout oprBtList;
        LinearLayout oprBtPlacer;
    }
}
