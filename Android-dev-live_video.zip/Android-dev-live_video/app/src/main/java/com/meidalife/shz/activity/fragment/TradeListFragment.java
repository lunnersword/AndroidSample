package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.TradeAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.TradeItem;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 已去除展示约单信息,后期确认无用可删除此类
 * Created by fufeng on 15/10/21.
 */
@Deprecated
public class TradeListFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    TradeAdapter tradeAdapter;
    private static final int PAGE_SIZE = 10;
    private boolean isLoading = false;

    private int currentPage = 0;
    private long itemId = 0;
    private List<TradeItem> tradeItemList = new ArrayList<>();

    @Bind(android.R.id.list)
    ListView mListView;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.emptyView)
    ViewGroup emptyView;
    @Bind(R.id.description)
    TextView description;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list, container, false);
        ButterKnife.bind(this, view);
        tradeAdapter = new TradeAdapter(getActivity(), tradeItemList);
        mListView.setAdapter(tradeAdapter);
        mListView.setEmptyView(emptyView);
        description.setText(R.string.sell_count_none);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        mListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        loadData(itemId);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

        itemId = getArguments().getLong("itemId");
        loadData(itemId);
        return view;
    }

    private void loadData(long itemId) {
        if (isLoading) {
            return;
        }
        isLoading = true;
        JSONObject params = new JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", PAGE_SIZE);
        params.put("offset", currentPage * PAGE_SIZE);

        HttpClient.get("1.0/item/getTradeList", params, null,
                new HttpClient.HttpCallback<Object>() {
                    @Override
                    public void onSuccess(Object obj) {
                        isLoading = false;
                        mSwipeRefreshLayout.setRefreshing(false);
                        JSONArray data = (JSONArray) obj;
                        for (int i = 0; i < data.size(); i++) {
                            JSONObject item = data.getJSONObject(i);
                            TradeItem tradeItem = new TradeItem();
                            tradeItem.setAvatar(item.getString("avatar"));
                            tradeItem.setNick(item.getString("nick"));
                            tradeItem.setPrice(item.getString("price"));
                            tradeItem.setTradeTime(item.getLong("tradeTime") * 1000);
                            tradeItemList.add(tradeItem);
                        }
                        if (!tradeItemList.isEmpty()) {
                            tradeAdapter.setTradeList(tradeItemList);
                            currentPage++;
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        isLoading = false;
                        mSwipeRefreshLayout.setRefreshing(false);
                    }
                });
    }

    @Override
    public void onRefresh() {
        currentPage = 0;
        tradeItemList.clear();
        loadData(itemId);
    }
}
