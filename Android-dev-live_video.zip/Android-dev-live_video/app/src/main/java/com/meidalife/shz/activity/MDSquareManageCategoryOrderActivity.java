package com.meidalife.shz.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareManageCategoryOrderAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 格子管理中心－服务社类目排序
 * Created by xingchen on 2015/12/22.
 */
public class MDSquareManageCategoryOrderActivity extends BaseActivity implements View.OnClickListener{

    @Bind(R.id.categoryListView)
    ListView categoryListView;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.emptyView)
    View emptyView;

    private int geziId = Integer.MAX_VALUE;
    private SquareManageCategoryOrderAdapter squareManageCategoryOrderAdapter;
    private JSONArray categoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_manage_category_order);

        ButterKnife.bind(this);
        initActionBar(R.string.square_manager_center_category_order, true, true);
        mButtonRight.setText(R.string.confirm);

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(categoryList.size()<2)
                    return;
                updateCategoryList();
            }
        });

        if(!TextUtils.isEmpty(getIntent().getStringExtra("geziId")))
            geziId = Integer.parseInt(getIntent().getStringExtra("geziId"));

        categoryList = new JSONArray();
        squareManageCategoryOrderAdapter = new SquareManageCategoryOrderAdapter(this,categoryList,this);
        categoryListView.setAdapter(squareManageCategoryOrderAdapter);
        categoryListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                squareManageCategoryOrderAdapter.setSelectPos(position);
                squareManageCategoryOrderAdapter.notifyDataSetChanged();
            }
        });

        initData();
    }

    private void initData(){
        categoryListView.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
        showStatusLoading(rootView);
        JSONObject params = new JSONObject();
        params.put("geziId",geziId);
        HttpClient.get("1.0/gezi/categoryList", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                categoryListView.setVisibility(View.VISIBLE);
                categoryList.clear();

                if (obj instanceof JSONArray) {
                    categoryList.addAll((JSONArray) obj);
                } else {
                    JSONObject result = (JSONObject) obj;
                    if(result.containsKey("categoryList")){
                        categoryList.addAll(result.getJSONArray("categoryList"));
                    }else{
                        if(result.containsKey("gezi") && (result.getJSONObject("gezi")).containsKey("categoryList")){
                            categoryList.addAll((result.getJSONObject("gezi")).getJSONArray("categoryList"));
                        }
                    }

                }
                squareManageCategoryOrderAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                }
            }
        });
    }

    private void updateCategoryList(){
        showProgressDialog("正在更新");
        JSONObject params = new JSONObject();
        params.put("geziId",geziId);
        JSONArray catIdList = new JSONArray();
        for(int i=0;i<categoryList.size();i++){
            catIdList.add(categoryList.getJSONObject(i).getIntValue("categoryId")+"");
        }
        params.put("catIdList",catIdList);
        HttpClient.get("1.0/gezi/updateCategoryList", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                hideProgressDialog();
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "更新失败，请稍后再试");
            }
        });

    }

    @Override
    public void onClick(View v) {
        int selectPos = squareManageCategoryOrderAdapter.getSelectPos();
        if(selectPos == -1)
            return;
        switch (v.getId()){
            case R.id.downView:{
                JSONObject selectItem = categoryList.getJSONObject(selectPos+1);
                categoryList.set(selectPos+1,categoryList.getJSONObject(selectPos));
                categoryList.set(selectPos,selectItem);
                squareManageCategoryOrderAdapter.setSelectPos(selectPos + 1);
                squareManageCategoryOrderAdapter.notifyDataSetChanged();
                break;
            }
            case R.id.upView:{
                JSONObject selectItem = categoryList.getJSONObject(selectPos-1);
                categoryList.set(selectPos-1,categoryList.getJSONObject(selectPos));
                categoryList.set(selectPos,selectItem);
                squareManageCategoryOrderAdapter.setSelectPos(selectPos-1);
                squareManageCategoryOrderAdapter.notifyDataSetChanged();
                break;
            }
        }
    }
}
