package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.DynamicNewsListFragment;
import com.meidalife.shz.adapter.FragmentTabAdapter;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 动态消息列表
 *
 * @author zuozheng 16/04/04
 */
public class DynamicNewsListActivity extends BaseActivity implements ViewPager.OnPageChangeListener {

    private final static String COMMENT_LIST = "comment";
    private final static String SUPPORT_LIST = "support";

    @Bind(R.id.commentContainer)
    View commentContainer;
    @Bind(R.id.supportContainer)
    View supportContainer;
    @Bind(R.id.supportTag)
    View supportTag;
    @Bind(R.id.commentTag)
    View commentTag;
    @Bind(R.id.tabViewPager)
    ViewPager tabViewPager;

    private FragmentTabAdapter pagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_news_list);
        initActionBar("消息列表", true, false);
        ButterKnife.bind(this);
        pagerAdapter = new FragmentTabAdapter(getSupportFragmentManager());

        DynamicNewsListFragment commentFragment = DynamicNewsListFragment.newInstance(COMMENT_LIST);
        pagerAdapter.addFragment(commentFragment);
        DynamicNewsListFragment supportFragment = DynamicNewsListFragment.newInstance(SUPPORT_LIST);
        pagerAdapter.addFragment(supportFragment);
        tabViewPager.setOnPageChangeListener(this);
        tabViewPager.setAdapter(pagerAdapter);

        commentContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tabViewPager.setCurrentItem(0);
            }
        });

        supportContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tabViewPager.setCurrentItem(1);
            }
        });

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {
        initCurrentItem(position);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    private void initCurrentItem(int index) {
        supportTag.setVisibility(View.INVISIBLE);
        commentTag.setVisibility(View.INVISIBLE);

        switch (index) {
            case 0:
                commentTag.setVisibility(View.VISIBLE);
                break;

            case 1:
                supportTag.setVisibility(View.VISIBLE);
                break;
        }
    }
}
