package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SearchFilterDo;

import java.util.List;

/**
 * Created by yiyang on 16/4/30.
 */
public class CategoryCateFilterAdapter extends BaseAdapter {
    private LayoutInflater mInflater;
    private List<SearchFilterDo.CateListItem.SubCateListDo> mSubCateListDos;
    private int selectPos;


    public CategoryCateFilterAdapter(Context mContext, List<SearchFilterDo.CateListItem.SubCateListDo> subCateListDos) {
        this.mInflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
        this.mSubCateListDos = subCateListDos;
    }


    @Override
    public int getCount() {
        return (mSubCateListDos.size() + 1 > 8) ? 8 : mSubCateListDos.size() + 1;
    }

    @Override
    public SearchFilterDo.CateListItem.SubCateListDo getItem(int position) {
        return mSubCateListDos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_category_filter_tab, parent, false);
            holder = new ViewHolder();
            holder.filterTab = (TextView) convertView.findViewById(R.id.filterTab);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        if (position == 0) {
            holder.filterTab.setText("全部");
        } else
            holder.filterTab.setText(getItem(position - 1).getSubCateName());
        if (selectPos == position) {
            holder.filterTab.setBackgroundResource(R.drawable.bg_filter_tab_selected);
        } else
            holder.filterTab.setBackgroundResource(R.drawable.bg_filter_tab);

        return convertView;
    }

    static class ViewHolder {
        TextView filterTab;
    }

    public int getSubCatId() {
        if (selectPos == 0) {
            return Integer.MAX_VALUE;
        } else {
            return mSubCateListDos.get(selectPos).getSubCateId();
        }
    }

    public int getSelectPos() {
        return selectPos;
    }

    public void setSelectPos(int selectPos) {
        this.selectPos = selectPos;
    }

    public void setTabList(List<SearchFilterDo.CateListItem.SubCateListDo> subCateListDos) {
        this.mSubCateListDos = subCateListDos;
    }
}
