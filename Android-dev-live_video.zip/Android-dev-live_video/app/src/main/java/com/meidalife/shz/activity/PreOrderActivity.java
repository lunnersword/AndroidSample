package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Paint;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.model.BuyerVO;
import com.meidalife.shz.rest.model.ItemVO;
import com.meidalife.shz.rest.model.PreOrderFormVO;
import com.meidalife.shz.rest.model.PreOrderOutDO;
import com.meidalife.shz.rest.model.SkuOutDO;
import com.meidalife.shz.rest.model.TimeVO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.SelectTimeUtil;
import com.meidalife.shz.view.FontEditText;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zuozheng on 16/03/10.
 * 商品详情弹窗
 */
public class PreOrderActivity extends Activity {

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.scrollView)
    View scrollView;

    @Bind(R.id.itemImageView)
    SimpleDraweeView itemImageView;
    @Bind(R.id.textItemTagView)
    TextView textItemTagView;
    @Bind(R.id.itemServiceTypeView)
    TextView itemServiceTypeView;
    @Bind(R.id.isMcoinView)
    TextView isMcoinView;

    //库存
    @Bind(R.id.itemStockTV)
    TextView itemStockTV;

    @Bind(R.id.servicePriceViewGroup)
    View servicePriceViewGroup;
    @Bind(R.id.promotionTagView)
    View promotionTagView;
    @Bind(R.id.priceView)
    TextView priceView;
    @Bind(R.id.oriPriceView)
    TextView oriPriceView;

    //预定价格view
    @Bind(R.id.earnestViewGroup)
    View earnestViewGroup;
    @Bind(R.id.earnestValue)
    TextView earnestValue;
    @Bind(R.id.finalPayAmountView)
    TextView finalPayAmountView;

    //sku
    @Bind(R.id.itemSkuTitle)
    TextView itemSkuTitle;
    //
    @Bind(R.id.itemSkuViewGroup)
    RelativeLayout itemSkuViewGroup;

    //数量
    @Bind(R.id.cellItemCount)
    View cellItemCount;
    @Bind(R.id.decItemCount)
    View decItemCount;
    @Bind(R.id.itemCountOprView)
    EditText itemCountOprView;
    @Bind(R.id.addItemCount)
    View addItemCount;

    //服务时间
    @Bind(R.id.cellServiceTime)
    View cellServiceTime;
    @Bind(R.id.tipSelectTimeView)
    TextView tipSelectTimeView;

    //买家地址
    @Bind(R.id.textAddressAndUserInfo)
    View textAddressAndUserInfo;
    @Bind(R.id.tipSelectAddressView)
    TextView tipSelectAddressView;
    //
    @Bind(R.id.cellBuyerAddressView)
    View cellBuyerAddressView;

    @Bind(R.id.textAddressTitle)
    View textAddressTitle;
    @Bind(R.id.textContactInfoView)
    TextView textContactInfoView;
    @Bind(R.id.textAddressView)
    TextView textAddressView;

    //单独输入姓名和电话
    @Bind(R.id.contactNameView)
    View contactNameView;
    @Bind(R.id.userNameView)
    FontEditText userNameView;
    @Bind(R.id.contactPhoneView)
    View contactPhoneView;
    @Bind(R.id.userPhoneView)
    FontEditText userPhoneView;

    @Bind(R.id.pre_order_buy_bt)
    TextView preOrderBuyView;


    @Bind(R.id.textStatusErrorServer)
    TextView textStatusErrorServer;
    @Bind(R.id.cellStatusDotLoading)
    LinearLayout cellStatusDotLoading;
    @Bind(R.id.cellStatusErrorNetwork)
    LinearLayout cellStatusErrorNetwork;
    @Bind(R.id.cellStatusErrorServer)
    LinearLayout cellStatusErrorServer;

    //可以统一处理 采用util方式
    List<TimeVO> timeList;

    //最后选中的地址游标
    private int lastSelectIndex = -1;
    AddressItem addressItem = new AddressItem();

    private int startLeft;
    private int startTop;
    private int height;
    private int spaceWidth;
    private int spaceHeight;
    private int screenWidth;

    String itemId = "";
    PreOrderFormVO preOrderFormVO = new PreOrderFormVO();
    SkuOutDO clickedSku;

    private int buyDownLimit;
    private int currentItemCount = 1;

    boolean isShowSelectTime = false;
    boolean isShowSelectQuantity = false;
    boolean isShowSelectAddress = false;
    boolean isShowContactUserName = false;
    boolean isShowContactUserPhone = false;

    List<Button> skuViewsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre_order);
        ButterKnife.bind(this);

//        hideIMM();
        initClickEvent();

        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);//需要添加的语句
        getWindow().setGravity(Gravity.BOTTOM);

        Bundle intentExtras = getIntent().getExtras();
        itemId = intentExtras != null ? intentExtras.getString("itemId") : null;

        xhrOrderForm4Detail();
    }

    private void xhrOrderForm4Detail() {
        preOrderBuyView.setVisibility(View.GONE);
        scrollView.setVisibility(View.GONE);
//        hideStatusErrorNetwork();
//        hideStatusErrorServer();
        showStatusLoading();

        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("itemId", itemId);

        HttpClient.get("1.0/buyerOrder/orderForm4ItemDetail", params, PreOrderOutDO.class, new HttpClient.HttpCallback<PreOrderOutDO>() {
            @Override
            public void onSuccess(PreOrderOutDO result) {
                hideStatusLoading();

                scrollView.setVisibility(View.VISIBLE);

                if (result != null) {
                    timeList = result.getTime();
                    renderView(result);
                }
            }

            @Override
            public void onFail(HttpError error) {
                xhrFailure(error);
            }
        });
    }

    private void showStatusLoading() {
        try {
            if (cellStatusDotLoading != null) {
                cellStatusDotLoading.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideStatusLoading() {
        try {
            if (cellStatusDotLoading != null) {
                cellStatusDotLoading.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void xhrFailure(HttpError error) {
        scrollView.setVisibility(View.GONE);
        preOrderBuyView.setVisibility(View.GONE);
        hideStatusLoading();
        if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
            cellStatusErrorNetwork.setVisibility(View.VISIBLE);
            return;
        }
        if (!TextUtils.isEmpty(error.getMessage())) {
            textStatusErrorServer.setText(error.getMessage());
        }
        cellStatusErrorServer.setVisibility(View.VISIBLE);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if ((requestCode == Constant.REQUEST_CODE_PICK_ADDRESS && resultCode == RESULT_OK)
                || (requestCode == Constant.REQUEST_CODE_CHANGE_ADDRESS && resultCode == RESULT_OK)) {
            if (data != null && data.getExtras() != null) {
                Bundle bundle = data.getExtras();
                addressItem = (AddressItem) bundle.getSerializable(Constant.EXTRA_TAG_ADDRESS);
                if (null != addressItem) {
                    renderAddressInfo(addressItem.getAddressName(), addressItem.getContactorPhone(),
                            addressItem.getContactorName());
                }
                lastSelectIndex = bundle.getInt("lastSelectIndex");
            }
        } else if (requestCode == Constant.REQUEST_CODE_PICK_ADDRESS && resultCode == RESULT_CANCELED) {
            Bundle bundle = data.getExtras();
            if (bundle != null) {
                lastSelectIndex = bundle.getInt("lastSelectIndex");
            }
        }
    }

    private void initClickEvent() {

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        screenWidth = size.x;
        spaceWidth = (int) Helper.convertDpToPixel(10, this);
        spaceHeight = (int) Helper.convertDpToPixel(15, this);
        height = (int) Helper.convertDpToPixel(30, this);
        startLeft = 0;
        startTop = spaceHeight;
        screenWidth -= Helper.convertDpToPixel(15, this) * 2;

        //对选择地址和数量等问题 需要单独处理 和订单页面一样
        findViewById(R.id.iconClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setBackgroundAlpha(1f);
                finish();
            }
        });
    }

    void renderView(final PreOrderOutDO orderOutDO) {

        renderServiceItem(orderOutDO);

        isShowSelectTime = orderOutDO.getShowSelectTime();
        isShowSelectQuantity = orderOutDO.getShowSelectQuantity();
        isShowSelectAddress = orderOutDO.getShowSelectAddress();
        isShowContactUserName = orderOutDO.getShowContactUserName();
        isShowContactUserPhone = orderOutDO.getShowContactUserPhone();

        cellServiceTime.setVisibility(isShowSelectTime ? View.VISIBLE : View.GONE);
        cellItemCount.setVisibility(isShowSelectQuantity ? View.VISIBLE : View.GONE);
        textAddressAndUserInfo.setVisibility(isShowSelectAddress ? View.VISIBLE : View.GONE);
        contactNameView.setVisibility(isShowContactUserName ? View.VISIBLE : View.GONE);
        contactPhoneView.setVisibility(isShowContactUserPhone ? View.VISIBLE : View.GONE);

        tipSelectTimeView.setHint(orderOutDO.getSelectTimeDesc());
        tipSelectAddressView.setHint(orderOutDO.getSelectAddressDesc());

        //买家信息
        BuyerVO buyer = orderOutDO.getBuyer();
        if (isShowSelectAddress && buyer != null) {
            if (isShowSelectAddress) {
                renderAddressInfo(buyer.getAddressName(), buyer.getContactorPhone(), buyer.getContactorName());
                //如果用户有地址 默认选取一个
                addressItem.setAddressId(buyer.getAddressId());
            }

            if (isShowContactUserName) {
                userNameView.setText(buyer.getContactorName());
            }
            if (isShowContactUserPhone) {
                userPhoneView.setText(buyer.getContactorPhone());
            }
        }


        preOrderBuyView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preOrderFormVO.setItemId(itemId);

                //下单增加sku校验
                if (clickedSku == null || TextUtils.isEmpty(clickedSku.getId())) {
                    MessageUtils.showToast(String.format("请选择%s", itemSkuTitle.getText().toString()));
                    return;
                }

                preOrderFormVO.setItemSkuId(clickedSku.getId());

                if (isShowSelectQuantity) {
                    try {
                        if (currentItemCount < buyDownLimit) {
                            MessageUtils.showToast(String.format("最少购买%s件", buyDownLimit));
                            return;
                        }

                        preOrderFormVO.setItemCount(currentItemCount);
                    } catch (Exception e) {
                        MessageUtils.showToast("输入数量错误,请重新输入");
                    }
                }

                if (isShowSelectTime) {
                    preOrderFormVO.setBookTime(tipSelectTimeView.getText().toString());
                }

                if (isShowSelectAddress) {
                    preOrderFormVO.setAddressId(addressItem.getAddressId());
                }

                if (isShowContactUserName) {
                    preOrderFormVO.setContactorName(userNameView.getText().toString().trim());
                }

                if (isShowContactUserPhone) {
                    preOrderFormVO.setContactorPhone(userPhoneView.getText().toString().trim());
                }

                Bundle bundle = new Bundle();
                bundle.putSerializable("preOrderFormVO", preOrderFormVO);
                Router.sharedRouter().open("order", bundle);
                finish();
            }
        });

        addItemCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentItemCount++;

                itemCountOprView.setText("" + currentItemCount);
            }
        });

        decItemCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentItemCount <= buyDownLimit) {
                    MessageUtils.showToast(String.format("最少购买%s件", buyDownLimit));
                    return;
                }
                currentItemCount--;

                itemCountOprView.setText("" + currentItemCount);
            }
        });

        itemCountOprView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    currentItemCount = Integer.parseInt(s.toString());
                } catch (Exception e) {

                }
            }
        });

        itemCountOprView.setInputType(EditorInfo.TYPE_CLASS_NUMBER);
        userPhoneView.setInputType(EditorInfo.TYPE_CLASS_PHONE);
    }

    private void renderServiceItem(PreOrderOutDO orderOutDO) {

        if (orderOutDO != null && orderOutDO.getSeller() != null) {
            boolean isSellerSelf = orderOutDO.getSeller().getUserId().equals(Helper.sharedHelper().getUserId()) ? true : false;
            if (isSellerSelf) {
                preOrderBuyView.setVisibility(View.GONE);
            } else {
                preOrderBuyView.setVisibility(View.VISIBLE);
            }
        }
        ItemVO item = orderOutDO.getItem();
        if (item == null) {
            return;
        }
        buyDownLimit = item.getBuyDownLimit() > 0 ? item.getBuyDownLimit() : 1;
        if (!TextUtils.isEmpty(
                item.getItemImage())) {
            String url = ImgUtil.getCDNUrlWithWidth(item.getItemImage(), itemImageView.getLayoutParams().width);
            if (!TextUtils.isEmpty(url)) {
                itemImageView.setImageURI(Uri.parse(url));
            }
        }
        textItemTagView.setText("我能·" + item.getTitle());
//        itemStockTV.setText(String.format("(库存%s)", item.getQuantitySum()));

        //判断商品服务类型 展示字段
        if (item.getServiceType() == Constant.SERVICE_TYPE_POST) {
            if (item.getIsSpot() == 1) {
                itemServiceTypeView.setText("邮寄(现货)");
            } else {
                itemServiceTypeView.setText("邮寄(定制)");
            }
        } else {
            itemServiceTypeView.setText(item.getServiceTypeText());
        }

        if ("1".equals(item.getSupportPoint())) {
            isMcoinView.setVisibility(View.VISIBLE);
        }

        //todo 活动标示逻辑梳理
//        promotionView.findViewById(R.id.promotion);

        //设置价格区间
        renderPrice(item.getEarnest(), item.getFinalPay(), item.getItemPromotionPriceRange(), item.getItemPriceRange(), item.getQuantitySum());
        renderStock(item);

        renderPromotionTagView(item);
        // 加载sku
        itemSkuTitle.setText(item.getSkuTitle());
        renderSku(item);
    }


    private void renderSku(final ItemVO item) {
        itemSkuViewGroup.removeAllViews();

        if (CollectionUtil.isEmpty(item.getSkuList())) {
            return;
        }

        for (int i = 0; i < item.getSkuList().size(); i++) {
            final SkuOutDO sku = item.getSkuList().get(i);
            // 展开分类
            Button expandButton = (Button) LayoutInflater.from(this).
                    inflate(R.layout.activity_pre_order_sku_item, itemSkuViewGroup, false);
            expandButton.setText("" + sku.getName());
            expandButton.setTag(sku);
            appendMargin(expandButton);
            // 计算位置
            itemSkuViewGroup.addView(expandButton);

            skuViewsList.add(expandButton);
            // 点击事件
            expandButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickedSku = (SkuOutDO) v.getTag();
                    renderPrice(clickedSku.getEarnest(), clickedSku.getFinalPay(), clickedSku.getPromotionPrice(), clickedSku.getPrice(), clickedSku.getQuantity());
                    renderStock(item);
                    //todo 需要实现反选择  可以优化
                    for (int i = 0; i < item.getSkuList().size(); i++) {
                        if (clickedSku.getId() == item.getSkuList().get(i).getId()) {
                            (skuViewsList.get(i)).setBackgroundResource(R.color.brand_b);
                            (skuViewsList.get(i)).setTextColor(getResources().getColor(R.color.white));
                        } else {
                            (skuViewsList.get(i)).setTextColor(getResources().getColor(R.color.black));
                            (skuViewsList.get(i)).setBackgroundResource(R.color.grey_d);
                        }
                    }
                }
            });

        }
        //只有一个sku 默认勾选第一个
        if (item.getSkuList().size() == 1) {
            clickedSku = item.getSkuList().get(0);
            renderPrice(clickedSku.getEarnest(), clickedSku.getFinalPay(), clickedSku.getPromotionPrice(), clickedSku.getPrice(), clickedSku.getQuantity());
            renderStock(item);
            (skuViewsList.get(0)).setBackgroundResource(R.color.brand_b);
            (skuViewsList.get(0)).setTextColor(getResources().getColor(R.color.white));
        }

    }

    void renderStock(ItemVO item) {
        if (item.isServiceCapacity()) {
            itemStockTV.setVisibility(View.GONE);
        } else {
            itemStockTV.setVisibility(View.VISIBLE);
            if (clickedSku != null) {
                itemStockTV.setText(String.format("(库存%s)", clickedSku.getQuantity()));
            } else {
                itemStockTV.setText(String.format("(库存%s)", item.getQuantitySum()));
            }
        }
    }


    void renderPrice(String earnest, String finalPay, String promotionPrice, String oriPrice, int quantity) {

        if (!TextUtils.isEmpty(earnest)) {
            servicePriceViewGroup.setVisibility(View.GONE);
            earnestViewGroup.setVisibility(View.VISIBLE);

            earnestValue.setText(String.format(getString(R.string.tail_yuan), earnest));
            finalPayAmountView.setText(String.format(getString(R.string.final_pay_amount), finalPay));
        } else {
            servicePriceViewGroup.setVisibility(View.VISIBLE);
            earnestViewGroup.setVisibility(View.GONE);

            if (TextUtils.isEmpty(promotionPrice)) {
                priceView.setText(String.format(getString(R.string.tail_yuan), oriPrice));
            } else {
                promotionTagView.setVisibility(View.VISIBLE);
                priceView.setText(String.format(getString(R.string.tail_yuan), promotionPrice));

                oriPriceView.setText((String.format(getString(R.string.tail_yuan), oriPrice)));
                oriPriceView.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
                oriPriceView.setVisibility(View.VISIBLE);
            }

        }
    }


    void renderPromotionTagView(ItemVO item) {
        if (item != null) {
            LinearLayout tagLayout;
            if (!TextUtils.isEmpty(item.getEarnest())) {
                tagLayout = (LinearLayout) findViewById(R.id.earnestPromotionTagLayout);
            } else {
                tagLayout = (LinearLayout) findViewById(R.id.normalPromotionTagLayout);
            }

            if (CollectionUtil.isNotEmpty(item.getPromotionTips())) {
                for (String tag : item.getPromotionTips()) {
                    View promotionView = LayoutInflater.from(this).inflate(R.layout.item_promotion_tag, tagLayout, false);
                    ((TextView) promotionView.findViewById(R.id.textItemTag)).setText(tag);
                    tagLayout.addView(promotionView);
                }
            }
        }
    }


    private void appendMargin(Button button) {
        button.measure(0, 0);
        int width = button.getMeasuredWidth();

        if (startLeft + width > screenWidth) {
            startLeft = 0;
            startTop += height + spaceHeight;
        }

        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) button.getLayoutParams();
        layoutParams.setMargins(startLeft, startTop, 0, 0);
        button.setLayoutParams(layoutParams);
        startLeft += width + spaceWidth;
    }


    /**
     * 设置Popup window 弹起时背景灰度
     *
     * @param bgAlpha
     */
    private void setBackgroundAlpha(float bgAlpha) {
        try {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.alpha = bgAlpha; //0.0-1.0
            getWindow().setAttributes(lp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void handleSelectTime(View view) {
        SelectTimeUtil util = new SelectTimeUtil(this, timeList);
        util.openSelectTimeDialog();

        util.setOnTimeClickListener(new SelectTimeUtil.OnTimeClickListener() {
            @Override
            public void onDelClick(String selectTime) {
                tipSelectTimeView.setText(selectTime);
            }
        });
    }

    public void handleSelectAddress(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("lastSelectIndex", lastSelectIndex);
        Router.sharedRouter().openFormResult("addresses", bundle, Constant.REQUEST_CODE_PICK_ADDRESS, this);
    }

    private void renderAddressInfo(String addressName, String phone, String name) {

        String contactString = "联系人：" + name;
        contactString += "，";
        contactString += phone;
        textContactInfoView.setText(contactString);
        textAddressView.setText(addressName);

        textAddressTitle.setVisibility(View.GONE);
        tipSelectAddressView.setVisibility(View.GONE);
        cellBuyerAddressView.setVisibility(View.VISIBLE);
    }
}
