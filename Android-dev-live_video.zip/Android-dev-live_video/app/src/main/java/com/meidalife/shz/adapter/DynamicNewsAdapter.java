package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.rest.model.DynamicNewsOutDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 16/04/02.
 * 动态消息列表
 */
public class DynamicNewsAdapter extends BaseAdapter {
    public static final int MESSAGE_TYPE_COMMENT = 0;
    public static final int MESSAGE_TYPE_SUPPORT = 1;
    LayoutInflater mInflater;
    Context mContext;
    List<DynamicNewsOutDO> mData;
    private int mType = -1;

    public static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.avatar)
        SimpleDraweeView avatar;

        @Bind(R.id.nickView)
        public TextView nickView;
        @Bind(R.id.iconGender)
        TextView iconGender;

        @Bind(R.id.zanIcon)
        View zanIcon;

        @Bind(R.id.bottomContentTextView)
        TextView bottomContentTextView;

        @Bind(R.id.replay_time_text)
        TextView replay_time_text;
        @Bind(R.id.replyPic)
        SimpleDraweeView replyPic;
        @Bind(R.id.recordLive)
        View recordLive;
        @Bind(R.id.liveVideo)
        View liveVideo;
        @Bind(R.id.voicePic)
        View voicePic;
    }

    public DynamicNewsAdapter(Context context, List<DynamicNewsOutDO> data, int type) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
        mType = type;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public DynamicNewsOutDO getItem(int position) {
        return mData.get(position);
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        DynamicNewsOutDO item = getItem(position);

        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_dynamic_news, parent, false);
            ViewHolder holder = new ViewHolder(convertView);

            convertView.setTag(holder);
        }
        ViewHolder holder = (ViewHolder) convertView.getTag();

        DynamicUserOutDO user = item.getUser();
        if (user != null) {
            // 加载动态用户信息
            holder.nickView.setText(user.getUserNick());
            String gender = "";
            // 设置服务者性别
            if (user.getUserGender() != null) {
                holder.iconGender.setVisibility(View.VISIBLE);
                if (user.getUserGender().equals("woman") || user.getUserGender().equals("F")) {
                    holder.iconGender.setText(mContext.getResources().getString(R.string.icon_female));
                    holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.color_icon_female));
                } else {
                    holder.iconGender.setText(mContext.getResources().getString(R.string.icon_male));
                    holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.color_icon_male));
                }
            } else {
                holder.iconGender.setVisibility(View.GONE);
            }

            ViewGroup.LayoutParams avatarParams = holder.avatar.getLayoutParams();
            if (TextUtils.isEmpty(user.getAvatarUrl())) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(user.getUserId()), gender);
                holder.avatar.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(user.getAvatarUrl(), avatarParams.width));
                holder.avatar.setImageURI(uri);
            }

            if (mType == MESSAGE_TYPE_COMMENT) {
                holder.bottomContentTextView.setText(ChatHelper.getInstance().getExpressionSpanText(item.getContent(), 20));
                holder.bottomContentTextView.setVisibility(View.VISIBLE);
                holder.zanIcon.setVisibility(View.GONE);

            } else if (mType == MESSAGE_TYPE_SUPPORT) {
                holder.zanIcon.setVisibility(View.VISIBLE);
                holder.bottomContentTextView.setVisibility(View.GONE);
            }

            String time = DateUtils.getOffsetDays(System.currentTimeMillis(), item.getCreateTime());
            holder.replay_time_text.setText(time);

            holder.recordLive.setVisibility(View.GONE);
            holder.liveVideo.setVisibility(View.GONE);
            holder.voicePic.setVisibility(View.GONE);
            holder.replyPic.setVisibility(View.GONE);

            //type : //0 图片，1 直播， 2 视频 ， 3 音频
            switch (item.getAdditionalInfo().getPublishType()) {

                case 0:
                    holder.replyPic.setImageURI(Uri.parse(item.getAdditionalInfo().getAudioUrl()));
                    holder.replyPic.setVisibility(View.VISIBLE);
                    break;

                case 1:
                    holder.replyPic.setImageURI(Uri.parse(item.getAdditionalInfo().getAudioUrl()));
                    holder.replyPic.setVisibility(View.VISIBLE);
                    holder.liveVideo.setVisibility(View.VISIBLE);
                    break;

                case 2:
                    holder.replyPic.setImageURI(Uri.parse(item.getAdditionalInfo().getAudioUrl()));
                    holder.replyPic.setVisibility(View.VISIBLE);
                    holder.recordLive.setVisibility(View.VISIBLE);
                    break;

                case 3:
                    holder.voicePic.setVisibility(View.VISIBLE);
                    break;
            }
        }

        return convertView;

    }
}
