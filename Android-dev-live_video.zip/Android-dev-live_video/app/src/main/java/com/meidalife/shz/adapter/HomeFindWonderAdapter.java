package com.meidalife.shz.adapter;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.HomeDiscoveriesDO;
import com.meidalife.shz.view.FlowLayout;
import com.usepropeller.routable.Router;

import java.util.List;

/**
 * Created by lanbo on 16/4/22.
 */
public class HomeFindWonderAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private List<HomeDiscoveriesDO.HomeThemeBlockAds> mThemeAds;

    public HomeFindWonderAdapter(Context context, List<HomeDiscoveriesDO.HomeThemeBlockAds> themeAds) {
        mContext = context;
        mInflater = LayoutInflater.from(mContext);
        mThemeAds = themeAds;
    }

    private void bindViewHolder(Holder holder, final int position) {
        final HomeDiscoveriesDO.Custom custom = mThemeAds.get(position).getCustom();
        holder.draweeView.setImageURI(Uri.parse(custom.getPic()));
        holder.subjectTv.setText(custom.getSubTitle());
        holder.titleTv.setText(custom.getTitle());
        int color = Color.parseColor(custom.getColor());
        holder.subjectTv.setBackgroundColor(color);
        holder.titleTv.setTextColor(color);

        List<HomeDiscoveriesDO.Link> links = custom.getLinks();
        if (links != null) {
            int size = links.size();
            int count = holder.tagLayout.getChildCount();
            for (int i = 0; i < size; i++) {
                HomeDiscoveriesDO.Link link = links.get(i);
                ViewGroup vGroup = (ViewGroup) holder.tagLayout.getChildAt(i);
                if (i < count) {
                    vGroup.setVisibility(View.VISIBLE);
                    TextView tv = (TextView) vGroup.getChildAt(0);
                    SimpleDraweeView draweeView = (SimpleDraweeView) vGroup.getChildAt(1);
                    tv.setText(link.getTagName());
                    final String url = link.getUrl();
                    tv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Bundle bundle = new Bundle();
                            bundle.putString("url", url);
                            Router.sharedRouter().open("web", bundle);
                        }
                    });
                    if (!TextUtils.isEmpty(link.getBgcolor())) {
                        tv.setBackgroundColor(Color.parseColor(link.getBgcolor()));
                    } else {
                        tv.setBackgroundResource(R.color.grey_s);
                    }

                    if (!TextUtils.isEmpty(link.getIcon())) {
                        draweeView.setVisibility(View.VISIBLE);
                        draweeView.setImageURI(Uri.parse(link.getIcon()));
                    } else {
                        draweeView.setVisibility(View.INVISIBLE);
                    }
                } else {
                    vGroup.setVisibility(View.GONE);
                }
            }
        }
    }

    @Override
    public int getCount() {
        return mThemeAds == null ? 0 : mThemeAds.size();
    }

    @Override
    public Object getItem(int position) {
        return mThemeAds == null ? null : mThemeAds.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.view_home_item_find_wonder, parent, false);
            holder = new Holder();

            holder.draweeView = (SimpleDraweeView) convertView.findViewById(R.id.drawee_image);
            holder.subjectTv = (TextView) convertView.findViewById(R.id.tv_subject);
            holder.titleTv = (TextView) convertView.findViewById(R.id.tv_title);
            holder.tagLayout = (FlowLayout) convertView.findViewById(R.id.layout_tags);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        bindViewHolder(holder, position);
        return convertView;
    }

    public static class Holder {
        SimpleDraweeView draweeView;
        TextView subjectTv;
        TextView titleTv;
        FlowLayout tagLayout;
    }
}
