package com.meidalife.shz.activity;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.manager.LiveManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LiveInitDO;
import com.meidalife.shz.rest.model.LiveRewardRankDO;
import com.meidalife.shz.rest.model.LiveVideoFinishDO;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.TimeUtils;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.RankListHead123;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class LiveVideoFinishActivity extends Activity {

    @Bind(R.id.hostAvatar)
    SimpleDraweeView hostAvatar;
    @Bind(R.id.rewardCount)
    FontTextView rewardCount;
    @Bind(R.id.visitorCount)
    FontTextView visitorCount;
    @Bind(R.id.durationLiveVideo)
    FontTextView durationLiveVideo;
    @Bind(R.id.inComeDetail)
    FontTextView inComeDetail;

    @Bind(R.id.rank_list_head_123)
    RankListHead123 rankListHead123;

    @Bind(R.id.listLiveVideo)
    FontTextView listLiveVideo;
    @Bind(R.id.exitLiveVideo)
    FontTextView exitLiveVideo;

    private static final int RANK_LIMIT = 3;
    private LiveManager mLiveManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mLiveManager = LiveManager.getInstance();

        if (mLiveManager.getLiveInitDO().isHost())
            setContentView(R.layout.activity_live_video_finish_host);
        else
            setContentView(R.layout.activity_live_video_finish_guest);
        ButterKnife.bind(this);
        bindListener();

        fetchFinishData();
    }

    private void bindListener() {
        inComeDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("liveVideoFinishDetail/" + mLiveManager.getLiveInitDO().getLiveRoomId());
            }
        });

        exitLiveVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        listLiveVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("liveVideoList");
                finish();
            }
        });
    }

    private void fetchFinishData() {

        JSONObject params = new JSONObject();
        params.put("liveId", mLiveManager.getLiveInitDO().getLiveRoomId());
        params.put("limit", RANK_LIMIT);

        HttpClient.get("1.0/live/detail", params, LiveVideoFinishDO.class, new HttpClient.HttpCallback<LiveVideoFinishDO>() {
            @Override
            public void onSuccess(LiveVideoFinishDO finishDO) {
                initView(finishDO);
            }

            @Override
            public void onFail(HttpError error) {
                if (error != null)
                    MessageUtils.showToast(error.getMessage());
            }
        });
    }

    private void initView(LiveVideoFinishDO finishDO) {

        hostAvatar.setImageURI(Uri.parse(finishDO.getPic()));
        long amount = finishDO.getAmount() / 100;
        if (mLiveManager.getLiveInitDO().isHost()) {
            rewardCount.setText(String.valueOf(amount));
        } else {
            if (amount > 1000)
                amount = amount / 10000;
            String amountStr = amount + "W+";
            rewardCount.setText(amountStr);
        }
        durationLiveVideo.setText(TimeUtils.secToTime((int) (finishDO.getDuration() / 1000)));
        visitorCount.setText("" + finishDO.getCount());

        final List<LiveRewardRankDO> rewardRankDOs = finishDO.getRewards();
        rankListHead123.initRankData(rewardRankDOs, this);
    }

}
