package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.MDSquareManagerSearchAdapter;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 格子管理中心-成员列表
 * Created by xingchen on 2015/12/22.
 */
public class MDSquareManageSearchActivity extends BaseActivity {
    private static int GET_DATA_REFRESH = 0;  // 刷新数据
    private static int GET_DATA_LOAD_MORE = 1;  //加载更多数据
    private boolean isComplete;
    private int page = 0;
    private boolean isRefresh = false;
    private boolean isLoad = false;

    private boolean isSearchComplete;
    private int searchPage = 0;
    private boolean isSearchRefresh = false;
    private boolean isSearchLoad = false;

    private int dataType = 0;

    @Bind(R.id.memberListView)
    ListView memberListView;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.action_bar_button_back)
    Button mButtonBack;
    @Bind(R.id.noDataLayout)
    View noDataLayout;
    @Bind(R.id.searchHint)
    EditText searchHint;

    private View listFooter;
    private ProgressBar footerLoading;
    private Button footerReload;
    private TextView footerMessage;


    private MDSquareManagerSearchAdapter mdSquareManagerSearchAdapter;
    private JSONArray userList;
    private int geziId = Integer.MAX_VALUE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_manage_search);

        ButterKnife.bind(this);
        if (!TextUtils.isEmpty(getIntent().getStringExtra("geziId")))
            geziId = Integer.parseInt(getIntent().getStringExtra("geziId"));

        mButtonBack.setTypeface(Helper.sharedHelper().getIconFont());

        listFooter = View.inflate(this, R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);
        memberListView.addFooterView(listFooter);
        listFooter.setVisibility(View.GONE);

        userList = new JSONArray();
        mdSquareManagerSearchAdapter = new MDSquareManagerSearchAdapter(this, userList);
        memberListView.setAdapter(mdSquareManagerSearchAdapter);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                initData(false, GET_DATA_REFRESH);
            }
        });

        searchHint.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    sureSearch(null);
                    return true;
                }
                return false;
            }
        });
        initListener();
        initData(true, GET_DATA_REFRESH);
    }

    private void initListener() {
        memberListView.setOnScrollListener(new AbsListView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        if (dataType == 0) {
                            initData(false, GET_DATA_LOAD_MORE);
                        } else
                            getSearchData(false, GET_DATA_LOAD_MORE);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }
        });
    }

    private void initData(final boolean isShowLoading, final int loadType) {
        dataType = 0;
        if (isShowLoading) {
            swipeRefreshLayout.setVisibility(View.GONE);
            showStatusLoading(rootView);
        }

        if (loadType == GET_DATA_REFRESH) {
            hideStatusErrorServer();
            hideStatusErrorNetwork();
            /*if(isHostRefresh)
                return;*/
            isRefresh = true;
            page = 0;
            isComplete = false;
        }
        if (loadType == GET_DATA_LOAD_MORE) {
            if (isComplete || isLoad) {
                return;
            }
            footerMessage.setText("正在加载");
            listFooter.setVisibility(View.VISIBLE);
            footerLoading.setVisibility(View.VISIBLE);
            footerMessage.setVisibility(View.VISIBLE);
            footerReload.setVisibility(View.GONE);
            isLoad = true;
            page++;
        }

        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        //params.put("keyword",);
        params.put("offset", page * 20);
        params.put("pageSize", 20);
        HttpClient.get("1.0/gezi/initSearchUser", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                if (isShowLoading)
                    hideStatusLoading();
                swipeRefreshLayout.setVisibility(View.VISIBLE);
                swipeRefreshLayout.setRefreshing(false);

                JSONArray newData;
                if (obj instanceof JSONArray) {
                    newData = (JSONArray) obj;
                } else {
                    newData = ((JSONObject) obj).getJSONArray("userList");
                }

                if (loadType == GET_DATA_REFRESH) {
                    isRefresh = false;
                    userList.clear();
                    if (newData.size() == 0) {
                        noDataLayout.setVisibility(View.VISIBLE);
                        swipeRefreshLayout.setVisibility(View.GONE);
                    } else {
                        noDataLayout.setVisibility(View.GONE);
                    }
                } else {
                    isLoad = false;
                    listFooter.setVisibility(View.GONE);

                }
                userList.addAll(newData);
                mdSquareManagerSearchAdapter.notifyDataSetChanged();
                if (newData.size() < 20) {
                    isComplete = true;
                    memberListView.removeFooterView(listFooter);
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (isShowLoading)
                    hideStatusLoading();
                swipeRefreshLayout.setRefreshing(false);
                swipeRefreshLayout.setVisibility(View.GONE);
                if (loadType == GET_DATA_REFRESH) {
                    isRefresh = false;
                    if (userList.size() > 0)
                        userList.clear();
                    mdSquareManagerSearchAdapter.notifyDataSetChanged();
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        showStatusErrorNetwork(rootView, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                initData(true, loadType);
                            }
                        });
                    } else {
                        showStatusErrorServer(rootView, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                initData(true, loadType);
                            }
                        });
                        if (!TextUtils.isEmpty(error.getMessage())) {
                            setTextErrorServer(error.getMessage());
                        }
                    }
                } else {
                    isLoad = false;
                    page--;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);

                    listFooter.setVisibility(View.VISIBLE);
                    footerReload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData(false, loadType);
                        }
                    });
                }
            }
        });


    }

    private void getSearchData(final boolean isShowLoading, final int loadType) {
        if (isShowLoading) {
            swipeRefreshLayout.setVisibility(View.GONE);
            showStatusLoading(rootView);
        }

        if (loadType == GET_DATA_REFRESH) {
            hideStatusErrorServer();
            hideStatusErrorNetwork();
            /*if(isHostRefresh)
                return;*/
            isSearchRefresh = true;
            searchPage = 0;
            isSearchComplete = false;
        }
        if (loadType == GET_DATA_LOAD_MORE) {
            if (isSearchComplete || isSearchLoad) {
                return;
            }
            footerMessage.setText("正在加载");
            listFooter.setVisibility(View.VISIBLE);
            footerLoading.setVisibility(View.VISIBLE);
            footerMessage.setVisibility(View.VISIBLE);
            footerReload.setVisibility(View.GONE);
            isLoad = true;
            searchPage++;
        }

        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        params.put("keyword", searchHint.getText().toString() == null ? "" : searchHint.getText().toString());
        params.put("offset", searchPage * 20);
        params.put("pageSize", 20);

        HttpClient.get("1.0/gezi/searchUser", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                if (isShowLoading)
                    hideStatusLoading();
                swipeRefreshLayout.setVisibility(View.VISIBLE);
                swipeRefreshLayout.setRefreshing(false);

                JSONArray newData;
                if (obj instanceof JSONArray) {
                    newData = (JSONArray) obj;
                } else {
                    newData = ((JSONObject) obj).getJSONArray("userList");
                }

                if (loadType == GET_DATA_REFRESH) {
                    isSearchRefresh = false;
                    userList.clear();
                    if (newData.size() == 0) {
                        noDataLayout.setVisibility(View.VISIBLE);
                        swipeRefreshLayout.setVisibility(View.GONE);
                    } else {
                        noDataLayout.setVisibility(View.GONE);
                    }
                } else {
                    isSearchLoad = false;
                    listFooter.setVisibility(View.GONE);

                }
                userList.addAll(newData);
                mdSquareManagerSearchAdapter.notifyDataSetChanged();
                if (newData.size() < 20) {
                    isSearchComplete = true;
                    memberListView.removeFooterView(listFooter);
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (isShowLoading)
                    hideStatusLoading();
                swipeRefreshLayout.setRefreshing(false);
                swipeRefreshLayout.setVisibility(View.GONE);
                if (loadType == GET_DATA_REFRESH) {
                    isSearchRefresh = false;
                    if (userList.size() > 0)
                        userList.clear();
                    mdSquareManagerSearchAdapter.notifyDataSetChanged();
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        showStatusErrorNetwork(rootView, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                getSearchData(true, loadType);
                            }
                        });
                    } else {
                        showStatusErrorServer(rootView, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                getSearchData(true, loadType);
                            }
                        });
                        if (!TextUtils.isEmpty(error.getMessage())) {
                            setTextErrorServer(error.getMessage());
                        }
                    }
                } else {
                    isSearchLoad = false;
                    searchPage--;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);

                    listFooter.setVisibility(View.VISIBLE);
                    footerReload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getSearchData(false, loadType);
                        }
                    });
                }
            }
        });
    }

    //搜索
    public void sureSearch(View view) {
        dataType = 1;
        getSearchData(true, GET_DATA_REFRESH);
    }

}
