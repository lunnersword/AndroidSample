package com.meidalife.shz.activity.fragment;

import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.OrderListActivity;
import com.meidalife.shz.activity.QRCodeCreateActivity;
import com.meidalife.shz.adapter.ProfileAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.MyPageDO;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.ShareActivity;
import com.umeng.socialize.media.UMImage;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/12/23.
 */
public class ProfileFragment extends BaseFragment {
    private View rootView;
    final String ZERO = "0";
    String kefuPhone;
    String kefuId;
    private List<MyPageDO.ProfileItem> buyerOrderItems = new ArrayList<>();
    private List<MyPageDO.ProfileItem> buyerExtraItems = new ArrayList<>();
    private List<MyPageDO.ProfileItem> sellerItems = new ArrayList<>();
    private List<MyPageDO.ProfileItem> addtionalElementItems = new ArrayList<>();
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;

    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.profileBannerLayout)
    ViewGroup profileBannerLayout;
    @Bind(R.id.profileBanner)
    TextView profileBanner;
    @Bind(R.id.profileBannerImage)
    SimpleDraweeView profileBannerImage;

    @Bind(R.id.profileGroup)
    ViewGroup profileGroup;
    @Bind(R.id.profileAvatar)
    SimpleDraweeView profileAvatar;
    @Bind(R.id.userName)
    TextView userName;
    @Bind(R.id.notSignInLabel)
    TextView notSignInLabel;
    @Bind(R.id.zmCredit)
    ViewGroup zmCreditLayout;
    @Bind(R.id.zmIcon)
    TextView zmIcon;
    @Bind(R.id.zmScore)
    TextView zmScore;
    @Bind(R.id.genderIcon)
    TextView genderIcon;

    @Bind(R.id.profileCompleteLayout)
    ViewGroup profileCompleteLayout;
    @Bind(R.id.completeRate)
    TextView completeRate;
    @Bind(R.id.moneyAmountLayout)
    ViewGroup moneyAmountLayout;
    @Bind(R.id.moneyValue)
    TextView moneyValue;
    @Bind(R.id.redpaperAmountLayout)
    ViewGroup redpaperAmountLayout;
    @Bind(R.id.redpaperValue)
    TextView redpaperValue;
    @Bind(R.id.mcoinAmountLayout)
    ViewGroup mcoinAmountLayout;
    @Bind(R.id.mcoinValue)
    TextView mcoinValue;

    @Bind(R.id.banner1)
    TextView bmoneyValueanner1;

    @Bind(R.id.banner2)
    TextView banner2;

    @Bind(R.id.buyerOrderGrid)
    GridView buyerOrderGrid;
    @Bind(R.id.buyerExtraGrid)
    GridView buyerExtraGrid;
    @Bind(R.id.sellerGrid)
    GridView sellerGrid;
    @Bind(R.id.addtionalElementGrid)
    GridView addtionalElementGrid;
    @Bind(R.id.title)
    TextView title;
    @Bind(R.id.guide_group)
    View guideGroup;
    @Bind(R.id.orderAllLayout)
    View orderAllLayout;
    private ProfileAdapter buyerOrderAdapter;
    private ProfileAdapter buyerExtraAdapter;
    private ProfileAdapter sellerAdapter;
    private ProfileAdapter addtionalElementAdapter;
    private String userAvatar;
    private String nickName;

    private LoadUtil loadHelper;

    AdapterView.OnItemClickListener profileItemListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            View iconView = view.findViewById(R.id.profileIcon);
            MyPageDO.ProfileItem profileItem = (MyPageDO.ProfileItem) iconView.getTag();
            if (!TextUtils.isEmpty(profileItem.getAction()) && profileItem.getAction().startsWith("http://")) {
                Bundle bundle = new Bundle();
                bundle.putString("url", profileItem.getAction());
                Router.sharedRouter().open("web", bundle);
            } else if ("doBuyService".equals(profileItem.getAction())) {
                openActivity("buyOrders/" + OrderListActivity.ROLE_TYPE_BUY);
            } else if ("doGezi".equals(profileItem.getAction())) {
                openActivity("mysquares");
            } else if ("doSellService".equals(profileItem.getAction())) {
                openActivity("saleOrders/" + OrderListActivity.ROLE_TYPE_SELL);
            } else if ("doCertificate".equals(profileItem.getAction())) {
                openActivity("certificationlist");
            } else if ("deployedItem".equals(profileItem.getAction())) {
                openActivity("serviceListPublish");
            } else if ("doPhone".equals(profileItem.getAction())) {
                Helper.makeCall(getActivity(), kefuPhone);
            } else if ("doSetting".equals(profileItem.getAction())) {
                Router.sharedRouter().open("setting");
            } else if ("doFavorites".equals(profileItem.getAction())) {
                openActivity("favorites");
            } else if ("doPosts".equals(profileItem.getAction())) {
                openActivity("serviceListPublish");
            } else if ("doPublish".equals(profileItem.getAction())) {
                openActivity("publish");
            } else if ("doChat".equals(profileItem.getAction())) {
                String action = "chat/" + kefuId;
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open(action);
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString("action", action);
                    Router.sharedRouter().open("signin", bundle);
                }
            } else if (!TextUtils.isEmpty(profileItem.getAction()) && profileItem.getAction().startsWith("imlifer://")) {
                Router.sharedRouter().open(profileItem.getAction());
            } else if ("doDuoBao".equals(profileItem.getAction())) {
                openActivity("mylottery/all");
            } else if (!TextUtils.isEmpty(profileItem.getAction()) && profileItem.getAction().startsWith("orderlist")) {
                openActivity(profileItem.getAction());
            } else if ("doLike".equals(profileItem.getAction())) {
                openActivity(profileItem.getAction());
            } else if ("doCashierQRCode".equals(profileItem.getAction())) {
                openCashierQRCode();
            } else if ("doCashierIncome".equals(profileItem.getAction())) {
                openActivity(profileItem.getAction() + "/2");
            } else if ("doCashierExpense".equals(profileItem.getAction())) {
                openActivity(profileItem.getAction() + "/1");
            } else if ("doFeedback".equals(profileItem.getAction())) {
                openActivity(profileItem.getAction());
            } else if ("doCareer".equals(profileItem.getAction())) {
                openActivity("careerManage");
            }else if("doUserProfile".equals(profileItem.getAction())){
                openActivity(profileItem.getAction());
            }
        }
    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_profile, container, false);
            ButterKnife.bind(this, rootView);
            loadHelper = new LoadUtil(inflater);
            buyerOrderAdapter = new ProfileAdapter(getActivity(), buyerOrderItems);
            buyerOrderAdapter.setHasLine(false);
            buyerOrderGrid.setAdapter(buyerOrderAdapter);

            buyerExtraAdapter = new ProfileAdapter(getActivity(), buyerExtraItems);
            buyerExtraGrid.setAdapter(buyerExtraAdapter);

            sellerAdapter = new ProfileAdapter(getActivity(), sellerItems);
            sellerGrid.setAdapter(sellerAdapter);

            addtionalElementAdapter = new ProfileAdapter(getActivity(), addtionalElementItems);
            addtionalElementGrid.setAdapter(addtionalElementAdapter);

//            for(int i = 0;i<5;i++){
//                ProfileAdapter.ProfileItem profileItem = new ProfileAdapter.ProfileItem();
//                profileItem.setAction("setting");
//                profileItem.setBadge("8");
//                profileItem.setIconUrl("http://img.shenghuozhe.net/shz/2015/12/20/75w_75h_0DAE61450603121.png");
//                profileItem.setTitle("待支付");
//                buyerOderProfileItems.add(profileItem);
//            }

        }
        return rootView;
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void onResume() {
        super.onResume();
        getMyProfile();
    }

    private void getMyProfile() {
        loadHelper.loadPre(rootLayout, scrollView);
        HttpClient.get("1.1/user/getUserMyPage", null, MyPageDO.class,
                new HttpClient.HttpCallback<MyPageDO>() {
                    @Override
                    public void onSuccess(MyPageDO myPageDO) {
                        if (null == getActivity() || isDetached()) {
                            return;
                        }
                        loadHelper.loadSuccess(scrollView);
                        if (myPageDO != null) {
                            loadHeader(myPageDO.getBase());
                            loadAssetLayout(myPageDO.getBase());
                            loadContent(myPageDO.getSectionsVer1());
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        if (null == getActivity() || isDetached()) {
                            return;
                        }
                        loadHelper.loadFail(error, rootLayout, new LoadUtil.Callback() {
                            @Override
                            public void retry() {
                                getMyProfile();
                            }
                        });
                    }
                });
    }

    private void loadHeader(MyPageDO.Base base) {
        if (base == null) {
            return;
        }
        userAvatar = base.getUserAvatar();
        nickName = base.getUserNick();
        final boolean isAuth = !TextUtils.isEmpty(base.getZmScore());

        kefuId = null == base.getKefuId() ? null : base.getKefuId() + "";
        //设置头像
        String userId = null == base.getUserId() ? null : base.getUserId() + "";
        String gender = base.getGender();
        String cdnUrl = ImgUtil.getCDNUrlWithWidth(base.getUserAvatar(),
                getResources().getDimensionPixelSize(R.dimen.profile_normal_avatar_size));
        if (TextUtils.isEmpty(cdnUrl)) {
            Uri uri = ImgUtil.getDefaultAvatarUri(getActivity(), userId, gender);
            profileAvatar.setImageURI(uri);
        } else {
            profileAvatar.setImageURI(Uri.parse(cdnUrl));
        }

        //是指昵称和芝麻信用
        if (Helper.sharedHelper().hasToken()) {
            userName.setText(base.getUserNick());
            notSignInLabel.setVisibility(View.GONE);
            zmCreditLayout.setVisibility(View.VISIBLE);
            if (isAuth) {
                zmIcon.setTextColor(getResources().getColor(R.color.zm_credit));
                zmScore.setTextColor(getResources().getColor(R.color.zm_credit));
                zmScore.setText("芝麻信用: " + base.getZmScore());
            } else {
                zmIcon.setTextColor(getResources().getColor(R.color.grey_c));
                zmScore.setTextColor(getResources().getColor(R.color.grey_c));
                zmScore.setText("绑定芝麻信用");
            }
            if (TextUtils.isEmpty(base.getTitle())) {
                title.setVisibility(View.GONE);
            } else {
                title.setText(base.getTitle());
                title.setVisibility(View.VISIBLE);
            }
            //设置性别
            if (Constant.GENDER_MAN.equals(gender)) {
                genderIcon.setText(R.string.icon_gender_m);
                genderIcon.setTextColor(getResources().getColor(R.color.brand_i));
            } else if (Constant.GENDER_WOMAN.equals(gender)) {
                genderIcon.setText(R.string.icon_gender_f);
                genderIcon.setTextColor(getResources().getColor(R.color.brand_b));
            } else {
                genderIcon.setVisibility(View.GONE);
            }

        } else {
            userName.setText(R.string.not_signin);
            notSignInLabel.setText(R.string.click_to_signin);
            notSignInLabel.setVisibility(View.VISIBLE);
            zmCreditLayout.setVisibility(View.GONE);
            genderIcon.setVisibility(View.GONE);
        }

        zmCreditLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://shenghuozhe.net/events/app_zmxy.html"; // 若未授权，跳转到授权页面
                if (isAuth) {
                    url = "https://xy.alipay.com/auth/whatszhima.htm?view=mobile";
                }
                Bundle bundle = new Bundle();
                bundle.putString("url", url);
                Router.sharedRouter().open("web", bundle);
            }
        });

        kefuPhone = base.getKefuPhone();
        Helper.sharedHelper().setStringUserInfo(Constant.CUSTOMER_SERVICE_TEL, kefuPhone);

        profileGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open("profile/" + Helper.sharedHelper().getUserId());
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });

        if (!TextUtils.isEmpty(base.getInfoCount())) {
            String infoCount = base.getInfoCount();
            completeRate.setText("完善度" + infoCount + "%");
            profileCompleteLayout.setVisibility(View.VISIBLE);
        } else {
            profileCompleteLayout.setVisibility(View.GONE);
        }

        orderAllLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity("buyOrders/" + OrderListActivity.ROLE_TYPE_BUY);
            }
        });

        loadBanner(base.getBanner());
    }

    private void loadBanner(MyPageDO.Banner banner) {
        if (banner == null) {
            return;
        }
        profileBanner.setText(banner.getText());
        String cdnUrl = ImgUtil.getCDNUrlWithHeight(banner.getImageUrl(),
                getResources().getDimensionPixelSize(R.dimen.action_bar_height));
        profileBannerImage.setImageURI(Uri.parse(cdnUrl));
        final String linkUrl = banner.getUrl();
        if (!TextUtils.isEmpty(banner.getUrl())) {
            profileBannerLayout.setVisibility(View.VISIBLE);
            profileBannerLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", linkUrl);
                    Router.sharedRouter().open("web", bundle);
                }
            });
        } else {
            profileBannerLayout.setVisibility(View.GONE);
        }
    }

    private void loadAssetLayout(MyPageDO.Base base) {
        if (base == null) {
            return;
        }
        final String moneySum = TextUtils.isEmpty(base.getFundSum()) ? ZERO : base.getFundSum();
        moneyValue.setText(moneySum);
        moneyAmountLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open("profile_money/" + moneySum);
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });
        String bonusNum = TextUtils.isEmpty(base.getBonusNum()) ? ZERO : base.getBonusNum();
        redpaperValue.setText(bonusNum);
        redpaperAmountLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open("redpaper");
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });
        mcoinValue.setText(TextUtils.isEmpty(base.getPointSum()) ? ZERO : base.getPointSum());
        mcoinAmountLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    //Router.sharedRouter().open("money_coin_detail/" + MoneyCoinDetailActivity.COIN_TYPE);
                    Router.sharedRouter().open("passphrase_input");
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });
    }

    public void openActivity(String action) {
        if (Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().open(action);
        } else {
            Bundle bundle = new Bundle();
            bundle.putString("action", action);
            Router.sharedRouter().open("signin", bundle);
        }
    }


    private void loadContent(MyPageDO.SectionsVer1 sections) {
        if (null == sections) {
            return;
        }
        buyerOrderGrid.setOnItemClickListener(profileItemListener);
        buyerExtraGrid.setOnItemClickListener(profileItemListener);
        sellerGrid.setOnItemClickListener(profileItemListener);
        addtionalElementGrid.setOnItemClickListener(profileItemListener);

//        for (int i = 0; i < sections.getJSONArray(0).size(); i++) {
//            JSONObject item = sections.getJSONArray(0).getJSONObject(i);
//            ProfileAdapter.ProfileItem profileItem = new ProfileAdapter.ProfileItem();
//            profileItem.setTitle(item.getString("text"));
//            profileItem.setBadge(item.getString("badge"));
//            profileItem.setIconUrl(item.getString("iconURL"));
//            profileItem.setAction(item.getString("action"));
//            buyerProfileItems.add(profileItem);
//        }

        if (sections.getBuyerOrder() != null && sections.getBuyerOrder().size() != 0) {
            buyerOrderItems = sections.getBuyerOrder();
            buyerOrderAdapter.setData(buyerOrderItems);
            buyerOrderAdapter.notifyDataSetChanged();
        }
        if (sections.getBuyerExtra() != null && sections.getBuyerExtra().size() != 0) {
            buyerExtraItems = sections.getBuyerExtra();
            buyerExtraAdapter.setData(buyerExtraItems);
            buyerExtraAdapter.notifyDataSetChanged();
        }
        if (sections.getSeller() != null && sections.getSeller().size() != 0) {
            sellerItems = sections.getSeller();
            sellerAdapter.setData(sellerItems);
            guideGroup.setVisibility(View.GONE);
            banner2.setVisibility(View.VISIBLE);
            sellerGrid.setVisibility(View.VISIBLE);
            sellerAdapter.notifyDataSetChanged();
        } else {
            banner2.setVisibility(View.GONE);
            sellerGrid.setVisibility(View.GONE);
            guideGroup.setVisibility(View.VISIBLE);
        }

        if (sections.getAddtionalElement() != null && sections.getAddtionalElement().size() != 0) {
            addtionalElementItems = sections.getAddtionalElement();
            addtionalElementAdapter.setData(addtionalElementItems);
            addtionalElementAdapter.notifyDataSetChanged();
        }

        guideGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("careerSelect");
            }
        });
//
//        if (!buyerProfileItems.isEmpty()) {
//            profileAdapter1.setData(buyerProfileItems);
//        }
//
//        if (sections.size() > 1) {
//            for (int i = 0; i < sections.getJSONArray(1).size(); i++) {
//                JSONObject item = sections.getJSONArray(1).getJSONObject(i);
//                ProfileAdapter.ProfileItem profileItem = new ProfileAdapter.ProfileItem();
//                profileItem.setTitle(item.getString("text"));
//                profileItem.setBadge(item.getString("badge"));
//                profileItem.setIconUrl(item.getString("iconURL"));
//                profileItem.setAction(item.getString("action"));
//                sellerProfileItems.add(profileItem);
//            }
//        }
//
//        if (!sellerProfileItems.isEmpty()) {
//            profileAdapter2.setData(sellerProfileItems);
//        }
//
//        if (sections.size() > 2) {
//            for (int i = 0; i < sections.getJSONArray(2).size(); i++) {
//                JSONObject item = sections.getJSONArray(2).getJSONObject(i);
//                ProfileAdapter.ProfileItem profileItem = new ProfileAdapter.ProfileItem();
//                profileItem.setTitle(item.getString("text"));
//                profileItem.setBadge(item.getString("badge"));
//                profileItem.setIconUrl(item.getString("iconURL"));
//                profileItem.setAction(item.getString("action"));
//                settingProfileItems.add(profileItem);
//            }
//        }
//        if (!settingProfileItems.isEmpty()) {
//            profileAdapter3.setData(settingProfileItems);
//        }


    }

    private void openCashierQRCode() {

        Bundle params = new Bundle();
        params.putString("iconUrl", getQRCodeImage().toUrl());
        params.putString("content", Helper.getPayUrl(Helper.sharedHelper().getUserId() + ""));
        params.putString("title", nickName != null ? nickName : "");
        params.putInt("type", QRCodeCreateActivity.QRCODE_TYPE_PAY);
        Router.sharedRouter().open("qrCodeCreate", params);
    }

    private UMImage getQRCodeImage() {
        if (userAvatar != null && !TextUtils.isEmpty(userAvatar))
            return new UMImage(getContext(), ImgUtil.getCDNUrlWithWidth(userAvatar, 200));
        return new UMImage(getContext(), R.mipmap.ic_launcher);
    }
}

