package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.BuildConfig;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.av.TencentConstants;
import com.meidalife.shz.av.control.QavsdkControl;
import com.meidalife.shz.manager.LiveManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LiveInitDO;
import com.meidalife.shz.rest.model.TencentImMsgDO;
import com.tencent.TIMCallBack;
import com.tencent.TIMConnListener;
import com.tencent.TIMConversation;
import com.tencent.TIMConversationType;
import com.tencent.TIMCustomElem;
import com.tencent.TIMElem;
import com.tencent.TIMElemType;
import com.tencent.TIMGroupManager;
import com.tencent.TIMManager;
import com.tencent.TIMMessage;
import com.tencent.TIMMessageListener;
import com.tencent.TIMValueCallBack;
import com.tencent.av.sdk.AVEndpoint;
import com.tencent.av.sdk.AVError;
import com.tencent.av.sdk.AVRoomMulti;
import com.tencent.av.sdk.AVView;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by LanBo on 16/4/6.
 * 主播步骤：init -> startContext -> enterRoom -> enterRoomFinish -> create surface -> create surface finish ->
 * 观众步骤：init -> startContext -> enterRoom -> startLive(When Surface Created) ->
 */
public class EnterLiveRoom {
    private static final String TAG = "EnterLiveRoom";
    private int mLiveId;
    private Activity mActivity;
    private QavsdkControl mController;
    private Handler mHandler = new Handler();

    //boolean mLiving = false;

    volatile private LiveInitDO mLiveInitDO;
    private boolean mHost;
    private String mHostIdentifier = "";

    public EnterLiveRoom(Activity activity) {
        mActivity = activity;
        mController = LiveManager.getInstance().getQavsdkControl();
    }

    public void enter(int liveId) {
        mLiveId = liveId;
        initLive();
    }

    public LiveInitDO getLiveInitDO() {
        return mLiveInitDO;
    }

    private void initLive() {
        JSONObject params = new JSONObject();
        params.put("liveId", mLiveId);
        HttpClient.get("1.0/live/init", params, LiveInitDO.class, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                if (null == obj) {
                    Log.e(TAG, "live/init return null");
                    return;
                }

                mLiveInitDO = (LiveInitDO) obj;
                mLiveInitDO.setCreateTime(mLiveInitDO.getCreateTime() / 1000);
                LiveManager.getInstance().setLiveInitDO(mLiveInitDO);
                mHost = mLiveInitDO.isHost();
                mGroupId = mLiveInitDO.getChatRoomId().toString();
                mHostIdentifier = mLiveInitDO.getHost().getUserId();
                if (BuildConfig.DEBUG) {
                    Log.i(TAG, mLiveInitDO.toString());
                }

                if (mOnEnterRoomListener != null) {
                    mOnEnterRoomListener.onInitFinished();
                }

                startContext();
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(TAG, "live/init failure");
                return;
            }
        });
    }

    private void startContext() {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "startContext");
            Log.i(TAG, "initAVSDKStep -1 : hasAVContext " + mController.hasAVContext());
            Log.i(TAG, "LiveInitDO = " + mLiveInitDO.toString());
        }

        String identifier = mLiveInitDO.getIdentifier();
        String usersig = mLiveInitDO.getToken();

        if (TextUtils.isEmpty(usersig)) {
            Log.e(TAG, "usersig is empty!");
            return;
        }

        if (BuildConfig.DEBUG) {
            Log.i(TAG, "import identifier: " + identifier + "  usersig   " + usersig);
        }
        int errorCode = mController.startContext(identifier, usersig);
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "startContext error code " + errorCode);
        }
        if (errorCode != AVError.AV_OK) {
            MessageUtils.showToastCenter("startContext error code " + errorCode);
        }
    }

    private void stopContext() {
        if (mController.hasAVContext()) {
            mController.stopContext();
        }
    }

    private void enterRoom() {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "enterRoom");
        }
        if (mLiveInitDO != null) {
            int liveRoomId = mLiveInitDO.getLiveRoomId().intValue();
            if (!mController.getIsInStartContext()) {
                mController.enterRoom(liveRoomId);
            }
        } else {
            Log.d(TAG, "mLiveInitDO = null");
        }
    }

    private Runnable mStartLiveRunnable = new Runnable() {
        @Override
        public void run() {
            tryStartLive();
        }
    };

    private void onEnterRoomCompleted(final int errorCode) {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "onEnterRoomCompleted errorCode " + errorCode);
        }
        if (errorCode == AVError.AV_OK) {
            mEnterRoomOK = true;
            mHandler.removeCallbacks(mStartLiveRunnable);
            mHandler.postDelayed(mStartLiveRunnable, 1000);
        } else {
            MessageUtils.showToastCenter("创建房间失败 " + errorCode);
        }
    }

    boolean mEnterRoomOK = false;
    boolean mSurfaceCreated = false;

    private void tryStartLive() {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "tryStartLive");
            Log.i(TAG, "mEnterRoomOK " + mEnterRoomOK + " mSurfaceCreated " + mSurfaceCreated);
        }
        if (mEnterRoomOK && !mSurfaceCreated) {
            if (mHost) {
                if (BuildConfig.DEBUG) {
                    Log.i(TAG, "主播create~~");
                }
                // 开启 IM
                if (mOnEnterRoomListener != null) {
                    mOnEnterRoomListener.onEnterRoomFinished();
                }
            } else {
                // 开启 IM
                if (BuildConfig.DEBUG) {
                    Log.i(TAG, "观众create~~");
                }
                if (mOnEnterRoomListener != null) {
                    mOnEnterRoomListener.onEnterRoomFinished();
                }
            }
        } else if (mEnterRoomOK && mSurfaceCreated) {
            if (mHost) {
                if (BuildConfig.DEBUG) {
                    Log.i(TAG, "主播开始预览啦~~");
                }
                boolean isEnabled = mController.getIsEnableCamera();
                if (!isEnabled) {
                    mController.toggleEnableCamera();
                }
            } else {
                if (BuildConfig.DEBUG) {
                    Log.i(TAG, "观众开始啦~~");
                }
                requestRemoteView();
            }
        }

        /*if (mEnterRoomOK) {
            if (mOnEnterRoomListener != null) {
                mOnEnterRoomListener.onEnterRoomFinished();
            }
        }*/
    }

    boolean mIsBeautyEnabled = false;
    public boolean getIsBeautyEnabled() {
        return mIsBeautyEnabled;
    }

    private void enableCameraCompleted(int errorCode, boolean isEnable) {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "enableCameraCompleted errorCode " + errorCode + " isEnable " + isEnable);
        }
        if (!mHost) return;
        mIsBeautyEnabled = mController.getAVContext().getVideoCtrl().enableBeauty(true);
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "isbeauty = " + mIsBeautyEnabled);
            Log.d(TAG, "onClick ACTION_ENABLE_CAMERA_COMPLETE " + " status " + mController.getIsEnableCamera());
        }

        if (errorCode == AVError.AV_OK) {
            // 摄像头打开成功, 进入预览
            // 界面在前端时, 显示本地摄像头的画面
            mPreviewing = true;
            updateLocalVideo();
            if (mOnEnterRoomListener != null) {
                mOnEnterRoomListener.onEnableCameraCompleted();
            }
        } else {
            MessageUtils.showToastCenter(isEnable ? "打开摄像头失败 " + errorCode : "关闭摄像头失败 " + errorCode);
        }
    }


    boolean mPreviewing = false;

    private void updateLocalVideo() {
        // 界面在前端时, 显示本地摄像头的画面
        if (mHost && mPreviewing) {
            String identifier = mLiveInitDO.getIdentifier();
            mController.setSelfId(identifier);
            mController.setLocalVideo(!mIsPaused, mLiveInitDO.getIdentifier());
        }
    }

    boolean mHasRemoteVideo = false;

    private void updateRemoteVideo() {
        if (!mHost && !TextUtils.isEmpty(mHostIdentifier)) {
            mController.setRemoteVideo(mHasRemoteVideo, mHostIdentifier);
            if (mHasRemoteVideo && mOnEnterRoomListener != null) {
                mOnEnterRoomListener.onRemoteVideoShow();
            }
        }

        //TODO mEditTextInputMsg.setClickable(true);
        //TODO 发消息通知大家 自己上线了
    }

    private void onLiveStarted() {
        if (mHost) {
            // 开始录像
            // startDefaultRecord();
        }
    }

    private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BuildConfig.DEBUG) {
                Log.i(TAG, "onReceive action = " + action + " " + EnterLiveRoom.this);
            }
            if (TencentConstants.ACTION_START_CONTEXT_COMPLETE.equals(action)) {
                // startContext 的回调, 并且进入房间
                enterRoom();
            } else if (action.equals(TencentConstants.ACTION_ROOM_CREATE_COMPLETE)) {
                // enterRoom 加入房间的回调
                int errorCode = intent.getIntExtra(TencentConstants.EXTRA_AV_ERROR_RESULT, AVError.AV_OK);
                onEnterRoomCompleted(errorCode);
            } else if (TencentConstants.ACTION_CREATE_GROUP_ID_COMPLETE.equals(action)) {
                initTIM(mGroupId);
            } else if (action.equals(TencentConstants.ACTION_SURFACE_CREATED)) {
                // 界面初始化完成,打开摄像头
                mSurfaceCreated = true;

                mHandler.removeCallbacks(mStartLiveRunnable);
                mHandler.postDelayed(mStartLiveRunnable, 100);
                //tryStartLive();
            } else if (action.equals(TencentConstants.ACTION_ENABLE_CAMERA_COMPLETE)) {
                // 打开关闭摄像头完成, 可能成功, 也可能失败
                int errorCode = intent.getIntExtra(TencentConstants.EXTRA_AV_ERROR_RESULT, AVError.AV_OK);
                boolean isEnable = intent.getBooleanExtra(TencentConstants.EXTRA_IS_ENABLE, false);
                enableCameraCompleted(errorCode, isEnable);
            } else if (action.equals(TencentConstants.ACTION_SWITCH_CAMERA_COMPLETE)) {
                // 切换了前后摄像头
                Log.d(TAG, " onSwitchCamera!! ACTION_SWITCH_CAMERA_COMPLETE  " + mController.getIsInOnOffCamera());
                int mSwitchCameraErrorCode = intent.getIntExtra(TencentConstants.EXTRA_AV_ERROR_RESULT, AVError.AV_OK);
                boolean isFront = intent.getBooleanExtra(TencentConstants.EXTRA_IS_FRONT, false);
                if (mSwitchCameraErrorCode != AVError.AV_OK) {
                    MessageUtils.showToastCenter(isFront ? "切换前置摄像头失败" : "切换后置摄像头失败");
                } else {
                    boolean currentCameraIsFront = mController.getIsFrontCamera();
                    Log.d(TAG, "onSwitchCamera  " + currentCameraIsFront);
                }
                mController.updateCameraSwitched();
            /*} else if (action.equals(TencentConstants.ACTION_VIDEO_CLOSE)) {
                // 成员关闭视频
                mHasRemoteVideo = false;
                updateRemoteVideo();*/
            } else if (action.equals(TencentConstants.ACTION_VIDEO_SHOW)) {
                // 成员模式加入视频聊天室
                mHasRemoteVideo = true;
                updateRemoteVideo();
            } else if (action.equals(TencentConstants.ACTION_CLOSE_ROOM_COMPLETE)) {
                // exitRoom 的回调
                if (mOnEnterRoomListener != null) {
                    mOnEnterRoomListener.onExitRoomCompleted();
                }
            } else if (action.equals(TencentConstants.ACTION_SHOW_VIDEO_MEMBER_INFO)) {
                String identifier = intent.getStringExtra(TencentConstants.EXTRA_IDENTIFIER);
                //showVideoMemberInfo(identifier);
            } else if (action.equals(TencentConstants.ACTION_CLOSE_MEMBER_VIDEOCHAT)) {
                String identifier = intent.getStringExtra(TencentConstants.EXTRA_IDENTIFIER);
                //closeVideoMemberByHost(identifier);
            }
        }
    };


    private void requestRemoteView() {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "request " + mHostIdentifier);
        }
        AVEndpoint endpoint = null;
        if (mController != null && mController.getAVContext() != null && mController.getAVContext().getRoom() != null) {
            endpoint = ((AVRoomMulti) mController.getAVContext().getRoom()).getEndpointById(mHostIdentifier);
        }
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "requestRemoteView identifier " + mHostIdentifier + " endpoint " + endpoint);
        }
        if (endpoint != null) {
            AVView view = new AVView();
            view.videoSrcType = AVView.VIDEO_SRC_TYPE_CAMERA;//SDK1.2版本只支持摄像头视频源，所以当前只能设置为VIDEO_SRC_TYPE_CAMERA。
            view.viewSizeType = AVView.VIEW_SIZE_TYPE_BIG;

            AVEndpoint.requestViewList(new String[]{mHostIdentifier}, new AVView[]{view}, MAX_REQUEST_VIEW_COUNT,
                    new AVEndpoint.RequestViewListCompleteCallback() {
                        protected void OnComplete(String identifierList[], int count, int result) {
                            Log.d(TAG, "OnComplete");
                        }
                    });
            // 成员模式请求界面
            mActivity.sendBroadcast(new Intent(TencentConstants.ACTION_VIDEO_SHOW));
        }
    }

    private static final int MAX_REQUEST_VIEW_COUNT = 1;

    public void onCreate() {
        registerReceiver();
    }

    boolean mIsPaused = true;

    public void onPause() {
        mIsPaused = true;
        updateLocalVideo();
    }

    public void onResume() {
        mIsPaused = false;
        updateLocalVideo();
    }

    public void onDestroy() {
        unregisterReceiver();
        destroyTIM();
        mHandler.removeCallbacksAndMessages(null);
        stopContext();
    }

    private void registerReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(TencentConstants.ACTION_ROOM_CREATE_COMPLETE);
        //intentFilter.addAction(TencentConstants.ACTION_CLOSE_ROOM_COMPLETE);
        intentFilter.addAction(TencentConstants.ACTION_CREATE_GROUP_ID_COMPLETE);
        //intentFilter.addAction(TencentConstants.ACTION_CREATE_ROOM_NUM_COMPLETE);
        intentFilter.addAction(TencentConstants.ACTION_SURFACE_CREATED);
        intentFilter.addAction(TencentConstants.ACTION_VIDEO_SHOW);
        intentFilter.addAction(TencentConstants.ACTION_MEMBER_VIDEO_SHOW);
        intentFilter.addAction(TencentConstants.ACTION_VIDEO_CLOSE);
        intentFilter.addAction(TencentConstants.ACTION_ENABLE_CAMERA_COMPLETE);
        intentFilter.addAction(TencentConstants.ACTION_SWITCH_CAMERA_COMPLETE);
        intentFilter.addAction(TencentConstants.ACTION_INSERT_ROOM_TO_SERVER_COMPLETE);
        intentFilter.addAction(TencentConstants.ACTION_INVITE_MEMBER_VIDEOCHAT);
        intentFilter.addAction(TencentConstants.ACTION_MEMBER_CHANGE);
        intentFilter.addAction(TencentConstants.ACTION_SHOW_VIDEO_MEMBER_INFO);
        intentFilter.addAction(TencentConstants.ACTION_CLOSE_MEMBER_VIDEOCHAT);
        intentFilter.addAction(TencentConstants.ACTION_CLOSE_ROOM_COMPLETE);

        intentFilter.addAction(TencentConstants.ACTION_START_CONTEXT_COMPLETE);
        mActivity.registerReceiver(mBroadcastReceiver, intentFilter);
    }

    private void unregisterReceiver() {
        if (mBroadcastReceiver != null)
            mActivity.unregisterReceiver(mBroadcastReceiver);
    }

    private OnEnterRoomListener mOnEnterRoomListener = null;

    public void setEnterRoomListener(OnEnterRoomListener l) {
        mOnEnterRoomListener = l;
    }

    public interface OnEnterRoomListener {
        void onInitFinished();

        void onEnterRoomFinished();

        void onEnableCameraCompleted();

        void onRemoteVideoShow();

        void onExitRoomCompleted();

        void onNewMessage(TencentImMsgDO msgDO);
    }

    /************************
     *         IM
     ************************/
    boolean mImSuccess = true;
    public void initIM() {
        mImSuccess = true;
        if (mHost) {
            createGroup();
        } else if (!mHost) {
            joinTIM(mGroupId);
            initTIM(mGroupId);
        }
    }

    private String mGroupId = "";
    /**
     * IMSDK创建聊天室
     */
    private void createGroup() {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "createGroup: Create IMChatRoom");
        }
        ArrayList<String> list = new ArrayList<String>();
        list.add(mLiveInitDO.getHost().getUserName());
        TIMGroupManager.getInstance().createGroup("ChatRoom", list, mLiveInitDO.getItem().getTitle(), mGroupId,
                new TIMValueCallBack<String>() {
            @Override
            public void onError(int i, String s) {
                if (BuildConfig.DEBUG) {
                    Log.e(TAG, "create group failed: " + i + " :" + s);
                }
                MessageUtils.showToastCenter("创建群失败:" + i + ":" + s);
            }

            @Override
            public void onSuccess(String s) {
                if (BuildConfig.DEBUG) {
                    Log.d(TAG, "create group success: " + s);
                }
                mActivity.sendBroadcast(new Intent(TencentConstants.ACTION_CREATE_GROUP_ID_COMPLETE));
            }
        });
    }

    private void joinTIM(String groupId) {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "joinTIM groupId" + groupId);
        }
        TIMGroupManager.getInstance().applyJoinGroup(groupId, "申请加入" + groupId, new TIMCallBack() {
            @Override
            public void onError(int i, String s) {
//                TIMManager.getInstance().logout();
                if (BuildConfig.DEBUG) {
                    Log.e(TAG, "applyJoinGroup fail " + i + ":" + s);
                }
                MessageUtils.showToastCenter("加群失败,失败原因：" + i + ":" + s);
            }

            @Override
            public void onSuccess() {
                Log.i(TAG, "applyJoinGroup success");
            }
        });
    }

    private void initTIM(String groupId) {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "initTIM groupId" + groupId);
        }
        if (groupId != null) {
            mConversation = TIMManager.getInstance().getConversation(TIMConversationType.Group, groupId);
            if (BuildConfig.DEBUG) {
                Log.d(TAG, "initTIM mConversation" + mConversation);
            }
        } else {

        }
        mSystemConversation = TIMManager.getInstance().getConversation(TIMConversationType.System, "");
//        testConversation = TIMManager.getInstance().getConversation(TIMConversationType.C2C, "18602833226");

        TIMManager.getInstance().addMessageListener(msgListener);
        TIMManager.getInstance().setConnectionListener(new TIMConnListener() {
            @Override
            public void onConnected() {
                Log.i(TAG, "onConnected");
            }

            @Override
            public void onDisconnected(int i, String s) {
                Log.i(TAG, "onDisconnected");
            }

            @Override
            public void onWifiNeedAuth(String s) {
                Log.i(TAG, "onWifiNeedAuth");
            }
        });
    }

    private void destroyTIM() {
        TIMManager.getInstance().removeMessageListener(msgListener);
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "destroyTIM");
        }
        if (mGroupId != null && mImSuccess) {
            if (mHost) {
                TIMGroupManager.getInstance().deleteGroup(mGroupId, new TIMCallBack() {
                    @Override
                    public void onError(int i, String s) {
                        Log.e(TAG, "quit group error " + i + " " + s);
                    }

                    @Override
                    public void onSuccess() {
                        Log.e(TAG, "delete group success");
                    }
                });
            } else {
                TIMGroupManager.getInstance().quitGroup(mGroupId, new TIMCallBack() {
                    @Override
                    public void onError(int i, String s) {
                        Log.e(TAG, "quit group error " + i + " " + s);
                    }

                    @Override
                    public void onSuccess() {
                        Log.i(TAG, "delete group success");
                    }
                });
            }
            TIMManager.getInstance().deleteConversation(TIMConversationType.Group, mGroupId);
        }
    }

    /**
     * 处理定制消息
     * @param elem
     */
    private void handleCustomMsg(TIMElem elem) {
        if (elem instanceof TIMCustomElem) { // 自定义消息体解析
            TIMCustomElem e = (TIMCustomElem) elem;
            byte[] data = e.getData();
            try {
                Charset cs = Charset.forName("UTF-8");
                TencentImMsgDO msgDO = JSONObject.parseObject(data, 0, data.length, cs.newDecoder(), TencentImMsgDO.class);

                if (msgDO != null) {
                    if (BuildConfig.DEBUG) {
                        Log.i(TAG, msgDO.toJsonString());
                    }
                    // 处理消息
                    if (mOnEnterRoomListener != null) {
                        mOnEnterRoomListener.onNewMessage(msgDO);
                    }
                } else {
                    String str = new String(data, "UTF-8");
                    Log.i(TAG, str);
                }
            } catch (UnsupportedEncodingException e1) {
                e1.printStackTrace();
            }
        }
    }

    private TIMMessageListener msgListener = new TIMMessageListener() {
        @Override
        public boolean onNewMessages(List<TIMMessage> list) {
            if (list != null) {
                if (BuildConfig.DEBUG) {
                    Log.i(TAG, "new message");
                }

                for (int i = 0; i < list.size(); i++) {
                    TIMMessage timMessage = list.get(i);
                    for (int j = 0; j < timMessage.getElementCount(); j++) {
                        TIMElem elem = timMessage.getElement(j);
                        TIMElemType type = elem.getType();
                        // 系统消息
                        if (type == TIMElemType.GroupSystem) {

                        }

                        // 定制消息
                        if (type == TIMElemType.Custom) {
                            handleCustomMsg(elem);
                            continue;
                        }
                    }
                }
            }
            return false;
        }
    };

    public void sendText(String msg) {
        if (TextUtils.isEmpty(msg)) return;

        byte[] data;
        try {
            data = msg.getBytes("utf8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return;
        }

        TIMMessage Nmsg = new TIMMessage();
        TIMCustomElem customElem = new TIMCustomElem();
        customElem.setData(data);
        customElem.setDesc("chat");
        if (Nmsg.addElement(customElem) != 0) {
            return;
        }

        mConversation.sendMessage(Nmsg, new TIMValueCallBack<TIMMessage>() {
            @Override
            public void onError(int i, String s) {
                String reason = "";
                if (i == 85) {
                    reason = "消息太长";
                } else if (i == 6011) {
                    reason = "ERROR_ACCOUNT_NOT_EXIT";
                }
                MessageUtils.showToastCenter("发送失败 " + reason + " " + s);
                Log.e(TAG, "send message failed. code: " + i + " errmsg: " + s);
            }

            @Override
            public void onSuccess(TIMMessage timMessage) {
                Log.i(TAG, "Send text Msg ok");
            }
        });

    }
    TIMConversation mConversation;
    TIMConversation mSystemConversation;
}
