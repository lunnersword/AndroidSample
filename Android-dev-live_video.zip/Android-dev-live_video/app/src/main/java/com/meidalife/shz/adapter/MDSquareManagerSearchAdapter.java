package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.util.DateUtils;
import com.usepropeller.routable.Router;

/**
 * Created by xingchen on 2015/12/22.
 */
public class MDSquareManagerSearchAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater mInflater;
    private JSONArray userList;

    public MDSquareManagerSearchAdapter(Context context, JSONArray userList) {
        this.context = context;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.userList = userList;
    }

    @Override
    public int getCount() {
        return userList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_square_manage_search, parent, false);
            holder = new ViewHolder();
            holder.chatText = (TextView) convertView.findViewById(R.id.chatText);
            holder.headPic = (SimpleDraweeView) convertView.findViewById(R.id.headPic);
            holder.iconGender = (TextView) convertView.findViewById(R.id.iconGender);
            holder.line = convertView.findViewById(R.id.line);
            holder.nickName = (TextView) convertView.findViewById(R.id.nickName);
            holder.statusView = (TextView)convertView.findViewById(R.id.statusView);
            holder.userIntro = (TextView)convertView.findViewById(R.id.userIntro);
            holder.squareHostTagView = convertView.findViewById(R.id.squareHostTagView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final JSONObject item = userList.getJSONObject(position);
        if (item.containsKey("userGender"))
            if ("M".equals(item.getString("userGender"))) {
                holder.iconGender.setText(R.string.icon_gender_m);
                holder.iconGender.setTextColor(context.getResources().getColor(R.color.gender_m));
            } else {
                holder.iconGender.setText(R.string.icon_gender_f);
                holder.iconGender.setTextColor(context.getResources().getColor(R.color.pink_a));
            }
        if (item.containsKey("userNick"))
            holder.nickName.setText(item.getString("userNick"));
        if (item.containsKey("userPicUrl"))
            holder.headPic.setImageURI(Uri.parse(item.getString("userPicUrl")));
        if(item.containsKey("userInstruction"))
            holder.userIntro.setText(item.getString("userInstruction"));
        if(item.containsKey("isOnline")){
            if(item.getBoolean("isOnline")){
                holder.statusView.setText(context.getResources().getString(R.string.text_online_status));
                holder.chatText.setTextColor(context.getResources().getColor(R.color.brand));
            }else{
                String time = DateUtils.getOffsetDays(System.currentTimeMillis(), item.getLongValue("lastOnlineTime")*1000);
                holder.statusView.setText(String.format(context.getResources().getString(R.string.text_offline_status),time));
                holder.chatText.setTextColor(context.getResources().getColor(R.color.grey_n));
            }
        }
        if(item.containsKey("isGezhu") && item.getBooleanValue("isGezhu")){
            holder.squareHostTagView.setVisibility(View.VISIBLE);
        }else
            holder.squareHostTagView.setVisibility(View.GONE);
        if (position == userList.size() - 1) {
            holder.line.setVisibility(View.INVISIBLE);
        } else
            holder.line.setVisibility(View.VISIBLE);
        holder.chatText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(item.containsKey("userId"))
                    Router.sharedRouter().open("chat/"+item.getIntValue("userId"));

            }
        });
        if(Helper.sharedHelper().getUserId().equals(item.getIntValue("userId")+"")){
            holder.chatText.setVisibility(View.INVISIBLE);
        }else
            holder.chatText.setVisibility(View.VISIBLE);
        return convertView;
    }

    static class ViewHolder {
        SimpleDraweeView headPic;
        TextView iconGender;
        TextView nickName;
        TextView chatText;
        View line;
        TextView userIntro;
        TextView statusView;
        View squareHostTagView;
    }
}
