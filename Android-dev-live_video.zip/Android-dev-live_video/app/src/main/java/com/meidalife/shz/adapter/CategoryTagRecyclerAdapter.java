package com.meidalife.shz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SquareCategoryItemDO;

import java.util.List;


/**
 * Created by xingchen on 2015/12/15.
 */
public class CategoryTagRecyclerAdapter extends RecyclerView.Adapter<CategoryTagRecyclerAdapter.ViewHolder> {

    public static int LIFE_COLLECT = 11;   //汇生活，互助站,闲话厅
    public static int SERVICE_COMMUNITY = 22;  //服务社

    private Context context;
    private LayoutInflater mInflater;
    private List<SquareCategoryItemDO> categoryItemDOs;
    private int selectPos = 0;
    private int type = 11;
    private RefreshCategoryView mRefreshCategoryCallback;


    public CategoryTagRecyclerAdapter(Context context, List<SquareCategoryItemDO> categoryItemDOs,int type) {
        this.context = context;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.categoryItemDOs = categoryItemDOs;
        this.type = type;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.item_category_tag, parent, false);
        ViewHolder holder = new ViewHolder(itemView);
        holder.tagName = (TextView) itemView.findViewById(R.id.tagName);
        holder.tagLine = itemView.findViewById(R.id.tagLine);
        holder.tagLayout = itemView.findViewById(R.id.tagLayout);
        holder.rootView = itemView.findViewById(R.id.rootView);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        try {
            SquareCategoryItemDO item = categoryItemDOs.get(position);
            final String desc = item.getCatName();
            if (type == SERVICE_COMMUNITY) {  //服务社

                if (selectPos == position) {
                    holder.tagLine.setVisibility(View.VISIBLE);
                } else
                    holder.tagLine.setVisibility(View.GONE);
            } else {  //汇生活，闲话厅
                if (selectPos == position) {
                   // holder.tagLayout.setBackgroundResource(R.drawable.bg_filter_tab_selected);
                    holder.tagName.setTextColor(context.getResources().getColor(R.color.brand_c));
                } else
                    //holder.tagLayout.setBackgroundResource(R.color.white);
                    holder.tagName.setTextColor(context.getResources().getColor(R.color.grey_l));
            }

            holder.tagName.setText(desc);

            holder.rootView.setTag(position);
            holder.rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = (int) v.getTag();
                    if (pos != selectPos) {
                        selectPos = pos;
                        notifyDataSetChanged();

                        SquareCategoryItemDO categoryItemDO = categoryItemDOs.get(pos);
                        mRefreshCategoryCallback.refreshCategory(categoryItemDO.getCatId());
                    }
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return categoryItemDOs.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tagName;
        View tagLine;
        View tagLayout;
        View rootView;

        public ViewHolder(View itemView) {
            super(itemView);
        }
    }

    public void setTabList(List<SquareCategoryItemDO> categoryItemDOs) {
        this.categoryItemDOs = categoryItemDOs;
    }

    public void setSelectPos(int selectPos) {
        this.selectPos = selectPos;
    }


    //点击类目时刷新内容 回调接口
    public interface RefreshCategoryView {
        void refreshCategory(int catId);
    }

    public void setOnClickCategoryListener(RefreshCategoryView callback) {
        mRefreshCategoryCallback = callback;
    }
}
