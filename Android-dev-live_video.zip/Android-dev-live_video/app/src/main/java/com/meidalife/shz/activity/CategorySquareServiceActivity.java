package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.CategoryFilterTabAdapter;
import com.meidalife.shz.adapter.CategoryTagRecyclerAdapter;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.ServiceListOutDo;
import com.meidalife.shz.rest.model.SquareCategoryItemDO;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.StrUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 服务社-二级类目
 * Created by xingchen on 2015/12/15.
 */
public class CategorySquareServiceActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener {

    private int geziId = Integer.MAX_VALUE;
    private int catId = Integer.MAX_VALUE;
    private int stdCatId = Integer.MAX_VALUE;
    private int tabId = Integer.MAX_VALUE;
    private boolean isComplete;
    private int page = 0;
    private boolean isLoading = false;

    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.serviceList)
    ListView serviceListView;
    @Bind(R.id.rootView)
    ViewGroup rootView;

    private GridView tagGridView;
    private View tagLine;
    private RecyclerView categorySlidingTab;
    private View cellStatusErrorNetwork;
    private View cellStatusErrorServer;
    //private LinearLayout cellStatusLoading;
    private LinearLayout cellStatusDotLoading;
    private TextView textStatusErrorServer;
    private View noDataLayout;
    private View headView;
    private View footerView;

    private CategoryTagRecyclerAdapter categoryTagRecyclerAdapter;
    private CategoryFilterTabAdapter categoryFilterTabAdapter;
    private ArrayList<ServiceListOutDo> serviceItemList;
    private ServicesAdapter servicesAdapter;
    private List<SquareCategoryItemDO> tabList;
    private com.alibaba.fastjson.JSONArray tagList;
    //private AnimationDrawable loadingAnimation;
    private boolean isInitData = false;
    private LoadUtil loadUtilV2;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_service_comm);
        ButterKnife.bind(this);

        initActionBar("服务社", true, false);

        if (!TextUtils.isEmpty(getIntent().getStringExtra("geziId")))
            geziId = Integer.parseInt(getIntent().getStringExtra("geziId"));
        if (!TextUtils.isEmpty(getIntent().getStringExtra("categoryId")))
            catId = Integer.parseInt(getIntent().getStringExtra("categoryId"));

        loadUtilV2 = new LoadUtil(LayoutInflater.from(this));
        initView();
        initListener();
        loadData(true);
    }

    public void initView() {

        headView = LayoutInflater.from(this).inflate(R.layout.view_category_square_service_head, null);
        tagGridView = (GridView) headView.findViewById(R.id.tagGridView);
        tagLine = headView.findViewById(R.id.tagLine);
        categorySlidingTab = (RecyclerView) headView.findViewById(R.id.categorySlidingTab);

        footerView = LayoutInflater.from(this).inflate(R.layout.view_category_square_service_footer, null);
        cellStatusErrorNetwork = footerView.findViewById(R.id.cellStatusErrorNetwork);
        cellStatusErrorServer = footerView.findViewById(R.id.cellStatusErrorServer);
        textStatusErrorServer = (TextView) footerView.findViewById(R.id.textStatusErrorServer);
        noDataLayout = footerView.findViewById(R.id.noDataLayout);
        cellStatusDotLoading = (LinearLayout) footerView.findViewById(R.id.cellStatusDotLoading);

        tagList = new com.alibaba.fastjson.JSONArray();
        tabList = new ArrayList<SquareCategoryItemDO>();
        categoryTagRecyclerAdapter = new CategoryTagRecyclerAdapter(this, tabList, CategoryTagRecyclerAdapter.SERVICE_COMMUNITY);
        categorySlidingTab.setAdapter(categoryTagRecyclerAdapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        categorySlidingTab.setLayoutManager(linearLayoutManager);

        categoryFilterTabAdapter = new CategoryFilterTabAdapter(this, tagList);
        categoryFilterTabAdapter.setTagNameKey("stdCatName");
        tagGridView.setAdapter(categoryFilterTabAdapter);
        swipeRefreshLayout.setOnRefreshListener(this);

        serviceListView.addHeaderView(headView);
        serviceListView.addFooterView(footerView);
        serviceItemList = new ArrayList<ServiceListOutDo>();
        servicesAdapter = new ServicesAdapter(this, serviceItemList);
        serviceListView.setAdapter(servicesAdapter);

        page = 0;
        isComplete = false;
    }

    private void initListener() {
        cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isInitData) {
                    loadData(true);
                } else
                    getListData(true, true);
            }
        });
        cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isInitData) {
                    loadData(true);
                } else
                    getListData(true, true);
            }
        });
        categorySlidingTab.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                swipeRefreshLayout.setEnabled(newState == RecyclerView.SCROLL_STATE_IDLE);
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }
        });
        serviceListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                View first = view.getChildAt(0);
                if (scrollState == SCROLL_STATE_IDLE && view.getFirstVisiblePosition() == 0
                        && first.getTop() == 0) {
                    swipeRefreshLayout.setEnabled(true);
                } else {
                    swipeRefreshLayout.setEnabled(false);
                }
                if (view.getLastVisiblePosition() == view.getCount() - 1) {
                    getListData(false, false);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });
        categoryTagRecyclerAdapter.setOnClickCategoryListener(new CategoryTagRecyclerAdapter.RefreshCategoryView() {
            @Override
            public void refreshCategory(int catId) {
                tabId = catId;
                getListData(true, true);
            }
        });

        tagGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int selectPos = categoryFilterTabAdapter.getSelectPos();
                if (selectPos == position) {
                    categoryFilterTabAdapter.setSelectPos(-1);
                    stdCatId = Integer.MAX_VALUE;
                } else {
                    categoryFilterTabAdapter.setSelectPos(position);
                    stdCatId = categoryFilterTabAdapter.getDefaultCatId();
                }
                categoryFilterTabAdapter.notifyDataSetChanged();
                getListData(true, true);
            }
        });


    }

    private void loadData(boolean showLoading) {
        if (showLoading) {
            loadUtilV2.loadPre(rootView, swipeRefreshLayout);
        }
        isInitData = true;
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        params.put("catId", catId);
        HttpClient.get("1.0/gezi/item/category/header", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                isInitData = false;
                if (obj.getString("categoryName") != null)
                    setActionBarTitle(obj.getString("categoryName"));
                try {
                    if (obj.getJSONArray("tabList") != null && obj.getJSONArray("tabList").size() > 0) {
                        initCat(obj.getJSONArray("tabList"));
                    }
                } catch (JSONException e) {
                    isInitData = true;
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                    headView.setVisibility(View.GONE);
                    footerView.setVisibility(View.VISIBLE);
                    cellStatusErrorServer.setVisibility(View.VISIBLE);
                    e.printStackTrace();
                }

                if (obj.getJSONArray("tagList") != null && !obj.getJSONArray("tagList").isEmpty()) {
                    tagList.addAll(obj.getJSONArray("tagList"));
                    categoryFilterTabAdapter.setSelectPos(-1);
                    categoryFilterTabAdapter.notifyDataSetChanged();
                    tagGridView.setVisibility(View.VISIBLE);
                    tagLine.setVisibility(View.VISIBLE);
                } else {
                    tagGridView.setVisibility(View.GONE);
                    tagLine.setVisibility(View.GONE);
                }
                headView.setVisibility(View.VISIBLE);
                getListData(true, false);
            }

            @Override
            public void onFail(HttpError error) {
                loadUtilV2.hideStatusLoading();
                swipeRefreshLayout.setVisibility(View.VISIBLE);
                headView.setVisibility(View.GONE);
                footerView.setVisibility(View.VISIBLE);
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    cellStatusErrorNetwork.setVisibility(View.VISIBLE);
                    return;
                }
                if (!TextUtils.isEmpty(error.getMessage())) {
                    textStatusErrorServer.setText(error.getMessage());
                }
                cellStatusErrorServer.setVisibility(View.VISIBLE);
            }
        });
    }

    private void initCat(JSONArray cats) {
        SquareCategoryItemDO categoryItemDO;
        for (int i = 0; i < cats.size(); i++) {
            categoryItemDO = new SquareCategoryItemDO();
            JSONObject cat = cats.getJSONObject(i);
            if (cat.containsKey("tabId"))
                categoryItemDO.setCatId(cat.getIntValue("tabId"));
            if (cat.containsKey("desc"))
                categoryItemDO.setCatName(cat.getString("desc"));
            tabList.add(categoryItemDO);
        }

        tabId = tabList.get(0).getCatId();
        categoryTagRecyclerAdapter.setSelectPos(0);
        categoryTagRecyclerAdapter.notifyDataSetChanged();
    }

    /**
     * @param refresh true:刷新
     */
    public void getListData(final boolean refresh, final boolean showLoading) {
        if (isLoading)
            return;
        isLoading = true;
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.GONE);
        noDataLayout.setVisibility(View.GONE);
        if (refresh) {
            page = 0;
            isComplete = false;
            if (showLoading) {
                showStatusLoading();
            }
        } else {
            if (isComplete) {
                isLoading = false;
                return;
            }
            page++;
        }

        HttpClient.get("1.0/gezi/item/category/list", getParams(page), null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                swipeRefreshLayout.setRefreshing(false);
                loadUtilV2.hideStatusLoading();
                hideStatusLoading();
                isLoading = false;
                swipeRefreshLayout.setVisibility(View.VISIBLE);

                try {
//                    ArrayList<ServiceListOutDo> newData = (ArrayList<ServiceItem>) JSON.parseArray(obj.getString("itemList"), ServiceItem.class);

                    if (refresh)
                        serviceItemList.clear();
                    serviceItemList.addAll(null);
                    if (serviceItemList.size() == 0) {
                        noDataLayout.setVisibility(View.VISIBLE);
                    }
                    servicesAdapter.notifyDataSetChanged();
                    if (serviceItemList.size() < 20)
                        isComplete = true;

                } catch (JSONException e) {
                    hideListContent();
                    cellStatusErrorNetwork.setVisibility(View.VISIBLE);
                    e.printStackTrace();
                }

            }

            @Override
            public void onFail(HttpError error) {
                swipeRefreshLayout.setVisibility(View.VISIBLE);
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                loadUtilV2.hideStatusLoading();
                if (!refresh)
                    page--;
                hideListContent();
                hideStatusLoading();
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    cellStatusErrorNetwork.setVisibility(View.VISIBLE);
                    return;
                }
                if (!TextUtils.isEmpty(error.getMessage())) {
                    textStatusErrorServer.setText(error.getMessage());
                }
                cellStatusErrorServer.setVisibility(View.VISIBLE);
            }
        });
    }

    private void hideListContent() {
        if (serviceItemList.size() > 0) {
            serviceItemList.clear();
            servicesAdapter.notifyDataSetChanged();
        }
    }

    private JSONObject getParams(int page) {
        JSONObject params = new JSONObject();
        try {
            /*if (geziId != Integer.MAX_VALUE)
                params.put("geziId", geziId);*/
            params.put("geziId", geziId);
            params.put("catId", catId);
            if (stdCatId != Integer.MAX_VALUE)
                params.put("stdCatId", stdCatId);
            params.put("tabId", tabId);
            LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();
            params.put("longitude", String.valueOf(location.getLongitude()));
            params.put("latitude", String.valueOf(location.getLatitude()));
            String locateCode = location.getCityCode();
            String selectCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
            params.put("cityCode", StrUtil.isEmpty(selectCode) ? locateCode : selectCode);  // 优先用户选择，其次自动定位
            params.put("pageSize", 20);
            params.put("offset", page * 20);
        } catch (com.alibaba.fastjson.JSONException e) {
            params = null;
        }
        return params;
    }

    @Override
    public void onRefresh() {
        getListData(true, true);
    }

    private void showStatusLoading() {
        try {
            hideListContent();
            cellStatusDotLoading.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void hideStatusLoading() {
        if (cellStatusDotLoading != null) {
            cellStatusDotLoading.setVisibility(View.GONE);
        }
    }

}
