package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ProfileDataListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ProfileDataDO;
import com.meidalife.shz.util.LoadUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 个人主页-关注的人
 * Created by liujian on 16/4/12.
 */
public class FavoritePersonActivity extends BaseActivity{

    @Bind(R.id.myListView)
    ListView myListView;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.emptyView)
    View emptyView;

    private ProfileDataListAdapter profileDataListAdapter;
    private List<ProfileDataDO.User> users;
    private LoadUtil loadUtil;
    private final int pageSize = 15;
    private int page;
    private boolean isComplete;
    private boolean isLoading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite_person);

        ButterKnife.bind(this);
        initActionBar(R.string.title_favorite_person, true);
        loadUtil = new LoadUtil(LayoutInflater.from(this));
        users = new ArrayList<ProfileDataDO.User>();
        profileDataListAdapter = new ProfileDataListAdapter(this, users);
        profileDataListAdapter.setType(0);
        profileDataListAdapter.setOnFollowListener(new ProfileDataListAdapter.OnFollowListener() {
            @Override
            public void onFollow(int position, boolean isAttention) {
                handlerFollow(position, isAttention);
            }
        });
        myListView.setAdapter(profileDataListAdapter);
        initListener();
        initData(true);
    }

    private void initListener() {
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Router.sharedRouter().open("profile/"+users.get(position).getUserId());
            }
        });
        myListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        initData(false);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
            }
        });
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                initData(true);
            }
        });
    }

    private void initData(final boolean refresh){
        if (isLoading)
            return;
        isLoading = true;
        if (refresh) {
            page = 0;
            isComplete = false;
            loadUtil.loadPre(rootView, swipeRefreshLayout);
        } else {
            if (isComplete) {
                isLoading = false;
                return;
            }
            page++;
        }
        JSONObject params = new JSONObject();
        params.put("type", 0);
        params.put("offset", pageSize * page);
        params.put("pageSize", pageSize);
        HttpClient.get("1.0/user/dataOverView", params, ProfileDataDO.class, new HttpClient.HttpCallback<ProfileDataDO>() {
            @Override
            public void onSuccess(ProfileDataDO obj) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                loadUtil.loadSuccess(swipeRefreshLayout);
                if (refresh)
                    users.clear();
                if (obj != null && obj.getUserData() != null) {
                    users.addAll(obj.getUserData());
                }

                if (users.size() == 0) {
                    swipeRefreshLayout.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                }
                profileDataListAdapter.notifyDataSetChanged();
                if (obj.getUserData() != null && obj.getUserData().size() < pageSize)
                    isComplete = true;
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                if (!refresh)
                    page--;
                loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initData(true);
                    }
                });
            }
        });
    }

    private void handlerFollow(final int position, boolean isAttention) {
        JSONObject params = new JSONObject();
        params.put("attentionUserId", users.get(position).getUserId() == null ? "" : users.get(position).getUserId() + "");
        HttpClient.get(isAttention ? "1.0/attention/delUserAttention" : "1.0/attention/addUserAttention", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                initData(true);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error.getMessage());
            }
        });
    }
}
