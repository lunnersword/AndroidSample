package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.github.curioustechizen.ago.RelativeTimeTextView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.rest.model.ConversationDO;
import com.meidalife.shz.rest.model.NotifyDO;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

/**
 * Created by taber on 15/6/23.
 */
public class MessageAdapter extends BaseAdapter {

    LayoutInflater mInflater;
    Context mContext;
    List<?> mData;

    public MessageAdapter(Context context, List<?> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    public void add(List list) {
        this.mData.addAll(list);
    }

    public void remove(int position) {
        this.mData.remove(position);
    }

    public void removeAll() {
        this.mData.clear();
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        /*
        message 入口页面
         */
        if (mData.get(position) instanceof ConversationDO) {

            ConversationDO conversation = (ConversationDO) mData.get(position);
            int type = conversation.getType();

            /*
            聊天会话列表
             */
            if (type == ConversationDO.TYPE_IM) {
                View v = mInflater.inflate(R.layout.message_list_item, null);
                convertView = v;

                SimpleDraweeView avatar = (SimpleDraweeView) v.findViewById(R.id.message_item_usr_avatar);
                TextView title = (TextView) v.findViewById(R.id.message_item_title);
                TextView content = (TextView) v.findViewById(R.id.message_item_content);
                TextView messagePrefix = (TextView) v.findViewById(R.id.message_prefix);
                RelativeTimeTextView time = (RelativeTimeTextView) v.findViewById(R.id.message_item_time);
                TextView badge = (TextView) v.findViewById(R.id.badge_with_number);

                if (TextUtils.isEmpty(conversation.getDraftMessage())) {
                    messagePrefix.setVisibility(View.GONE);
                    content.setText(ChatHelper.getInstance().getExpressionSpanText(conversation.getSubTitle(), 16));
                } else {
                    messagePrefix.setVisibility(View.VISIBLE);
                    content.setText(ChatHelper.getInstance().getExpressionSpanText(conversation.getDraftMessage(), 16));
                }

                time.setReferenceTime(conversation.getTime());
                if(!TextUtils.isEmpty(conversation.getAvatar())) {
                    Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(conversation.getAvatar(), avatar.getLayoutParams().width));
                    avatar.setImageURI(uri);
                }else {
                    avatar.setImageURI(ImgUtil.getDefaultAvatarUri(mContext, conversation.getUserId(), null));
                }

                title.setText(conversation.getUserName());

                if (conversation.getUnread() > 0) {
                    if (conversation.getUnread() < 100) {
                        badge.setText(String.valueOf(conversation.getUnread()));
                    } else {
                        badge.setText("99+");
                    }
                    badge.setVisibility(View.VISIBLE);
                } else {
                    badge.setVisibility(View.GONE);
                }
            }

            /*
            通知类别的列表
             */
            else {
                View v = mInflater.inflate(R.layout.notification_list_item, null);
                convertView = v;

                SimpleDraweeView ntIcon = (SimpleDraweeView) v.findViewById(R.id.notification_icon);
                if (!TextUtils.isEmpty(conversation.getAvatar())) {
                    ImgUtil.load(mContext, conversation.getAvatar(), ntIcon.getLayoutParams(), ntIcon);
                } else {
                    ntIcon.setImageURI(ImgUtil.getDefaultAvatarUri(mContext, conversation.getUserId(), null));
                }

                TextView ntTag = (TextView) v.findViewById(R.id.notification_tag);
                ntTag.setText(conversation.getTitle());
                TextView content = (TextView) v.findViewById(R.id.notification_content);
                content.setText(conversation.getSubTitle());
                TextView unread = (TextView) v.findViewById(R.id.notification_unread);

                if (conversation.getUnread() > 0 && conversation.getUnread() < 100) {
                    unread.setText(String.valueOf(conversation.getUnread()));
                } else if (conversation.getUnread() >= 100) {
                    unread.setText("99+");
                } else {
                    unread.setVisibility(View.GONE);
                }
            }

            convertView.setTag(conversation);
            return convertView;
        }

        /*
        某种通知的详细列表
         */
        else {
            MessageHolder holder;
            if (convertView == null) {
                View v = mInflater.inflate(R.layout.notification_item, null);
                holder = new MessageHolder();
                holder.avatar = (ImageView) v.findViewById(R.id.message_item_usr_avatar);
                holder.title = (TextView) v.findViewById(R.id.message_item_title);
                holder.content = (TextView) v.findViewById(R.id.message_item_content);
                holder.time = (RelativeTimeTextView) v.findViewById(R.id.message_item_time);
                holder.badge = (TextView) v.findViewById(R.id.badge_red_dot);
                convertView = v;
                convertView.setTag(holder);
            } else {
                holder = (MessageHolder) convertView.getTag();
            }

            NotifyDO notify = (NotifyDO) mData.get(position);
            holder.content.setText(notify.getSubTitle());
            holder.time.setReferenceTime(notify.getTime());
            holder.title.setText(notify.getTitle());
            holder.item = notify;
            ////todo set default avatar
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(notify.getAvatar(), holder.avatar.getLayoutParams().width));
            holder.avatar.setImageURI(uri);

            if (notify.getUnread() > 0) {
                holder.badge.setVisibility(View.VISIBLE);
            } else {
                holder.badge.setVisibility(View.GONE);
            }

            return convertView;
        }
    }

    public class MessageHolder {
        public ImageView avatar;
        public TextView title;
        public TextView messagePrefix;
        public TextView content;
        public RelativeTimeTextView time;
        public TextView badge;
        public Object item;
    }

}
