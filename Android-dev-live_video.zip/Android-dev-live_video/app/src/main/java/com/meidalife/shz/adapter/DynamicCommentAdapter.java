package com.meidalife.shz.adapter;


import android.content.Context;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.rest.model.DynamicBottomDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 15/12/20.
 * 动态留言列表
 */
public class DynamicCommentAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    List<DynamicBottomDO> mData;
    private ChatHelper mChatHelper;
    private boolean isProfileAction;

    static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.textView)
        TextView textView;
        @Bind(R.id.content)
        TextView content;
    }

    public DynamicCommentAdapter(Context context, List<DynamicBottomDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
        mChatHelper = ChatHelper.getInstance();
    }

    public void setIsProfileAction(boolean isProfileAction) {
        this.isProfileAction = isProfileAction;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public DynamicBottomDO getItem(int position) {
        return mData.get(position);
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        DynamicBottomDO item = mData.get(position);

        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_dynamic_comment_singleline, parent, false);
            ViewHolder holder = new ViewHolder(convertView);

            convertView.setTag(holder);
        }
        ViewHolder holder = (ViewHolder) convertView.getTag();

        DynamicUserOutDO user = item.getUser();

        String replyUserNick = item.getReplyNick();
        String userNick = item.getUser() != null ? item.getUser().getUserNick() : "我";
        if (TextUtils.isEmpty(replyUserNick)) {
            Spannable wordtoSpan = new SpannableString(userNick + "：");
            wordtoSpan.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.grey_k)), 0, userNick.length() + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//            wordtoSpan.setSpan(new RelativeSizeSpan(1.0f), 0, userNick.length() + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            holder.textView.setText(wordtoSpan);

        } else {
            Spannable wordtoSpan = new SpannableString(userNick + "回复@" + replyUserNick + "：");
            wordtoSpan.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.grey_k)), 0, userNick.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            wordtoSpan.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.grey_k)), userNick.length() + 2, userNick.length() + 2 + replyUserNick.length() + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//            wordtoSpan.setSpan(new RelativeSizeSpan(1.0f), userNick.length() + 3, replyUserNick.length() + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            holder.textView.setText(wordtoSpan);
        }
        if(!TextUtils.isEmpty(item.getContent()))
            holder.content.setText(mChatHelper.getExpressionSpanText(item.getContent(), 12));

        if(isProfileAction){
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)holder.textView.getLayoutParams();
            layoutParams.setMargins(0,0,0,0);
            holder.textView.setLayoutParams(layoutParams);
        }

        return convertView;
    }
}
