package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.view.FontButton;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/4/27.
 */
public class NoCareerHintActivity extends BaseActivity {
    @Bind(R.id.closeButton)
    TextView closeButton;
    @Bind(R.id.selectCareerButton)
    TextView selectCareerButton;
    @Bind(R.id.careerEmptyView)
    ViewGroup careerEmptyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_career_hint);
        ButterKnife.bind(this);
        careerEmptyView.setVisibility(View.VISIBLE);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        selectCareerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().openFormResult("careerSelect",
                        Constant.REQUEST_CODE_SELECT_CAREER, NoCareerHintActivity.this);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (Constant.REQUEST_CODE_SELECT_CAREER == requestCode) {
            setResult(resultCode);
            finish();
        }
    }
}
