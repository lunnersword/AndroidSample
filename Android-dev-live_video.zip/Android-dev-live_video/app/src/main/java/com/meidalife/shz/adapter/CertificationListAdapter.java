package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.common.util.UriUtil;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CertificationBean;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

public class CertificationListAdapter extends BaseAdapter {
    Context context;
    List<CertificationBean> mOrderList;
    LayoutInflater mInflater;
    DeleteListener mListener;

    public void setmListener(DeleteListener mListener) {
        this.mListener = mListener;
    }

    public CertificationListAdapter(Context context, List<CertificationBean> data) {
        this.context = context;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mOrderList = data;
    }

    public void updateData(List<CertificationBean> data) {
        mOrderList = data;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mOrderList.size();
    }

    @Override
    public Object getItem(int position) {
        return mOrderList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        OrderItemHolder holder = new OrderItemHolder();


        if (convertView != null) {
            holder = (OrderItemHolder) convertView.getTag();
        } else {
            View itemView = mInflater.inflate(R.layout.activity_auth_list_item, null);
            holder.userPic = (SimpleDraweeView) itemView.findViewById(R.id.auth_item_pic);
            holder.picCount = (TextView) itemView.findViewById(R.id.auth_item_pic_count);
            holder.title = (TextView) itemView.findViewById(R.id.auth_item_title);
            holder.statusIcon = (TextView) itemView.findViewById(R.id.auth_status_icon);
            holder.status = (TextView) itemView.findViewById(R.id.auth_item_status);
            holder.desc = (TextView) itemView.findViewById(R.id.auth_item_desc);
            holder.updateTime = (TextView) itemView.findViewById(R.id.auth_update_time);
            holder.deleteButton = (TextView) itemView.findViewById(R.id.auth_delete);

            convertView = itemView;
            convertView.setTag(holder);
        }

        final CertificationBean auth = mOrderList.get(position);
//        int picCount = 0;
        if (auth.isAlipayAuth()) {
            Uri avatarImg = new Uri.Builder()
                    .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.pic_zm)).build();
            holder.userPic.setImageURI(avatarImg);
        } else {
            List<String> imgList = auth.getPicUrlList();
            if (imgList != null && imgList.size() > 0) {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(imgList.get(0), holder.userPic.getLayoutParams().width));
                holder.userPic.setImageURI(uri);
//                picCount = imgList.size();
            } else {

                if (auth.isRealUser) {
                    // 根据性别 设置默认头像
                    String gender = Helper.sharedHelper().getStringUserInfo(Constant.USER_GENDER);
                    Uri avatarImg;
                    if (gender.equals("M") || gender.equals("male")) {
                        avatarImg = new Uri.Builder()
                                .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.default_pic_m)).build();
                        holder.userPic.setImageURI(avatarImg);
                    } else {
                        avatarImg = new Uri.Builder()
                                .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.default_pic_fm)).build();
                        holder.userPic.setImageURI(avatarImg);
                    }
                    holder.userPic.setImageURI(avatarImg);
                } else {
                    //set default pic
                    Uri avatarImg = new Uri.Builder()
                            .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.avatar)).build();
                    holder.userPic.setImageURI(avatarImg);
                }
            }
        }
        if (auth.getPicCount() > 0) {
            holder.picCount.setText(String.format("共%s张", auth.getPicCount()));
            holder.picCount.setVisibility(View.VISIBLE);
        } else {
            holder.picCount.setText("");
            holder.picCount.setVisibility(View.GONE);
        }

        holder.title.setText(auth.getTitle());
        holder.desc.setText(auth.getDesc());
        holder.updateTime.setText(auth.getTime());

        int status = auth.getStatus();

        if (status == Constant.CERT_STATUS_AUDIT) {
            holder.statusIcon.setText(R.string.icon_checking);
            holder.statusIcon.setTextColor(context.getResources().getColor(R.color.brand_k));
            holder.status.setTextColor(context.getResources().getColor(R.color.brand_k));
        } else if (status == Constant.CERT_STATUS_PASS) {
            holder.statusIcon.setText(R.string.icon_success);
            holder.statusIcon.setTextColor(context.getResources().getColor(R.color.green_a));
            holder.status.setTextColor(context.getResources().getColor(R.color.green_a));
        } else if (status == Constant.CERT_STATUS_DENY) {
            holder.statusIcon.setText(R.string.icon_fail);
            holder.statusIcon.setTextColor(context.getResources().getColor(R.color.pink_a));
            holder.status.setTextColor(context.getResources().getColor(R.color.pink_a));
        } else {
            holder.statusIcon.setText(R.string.icon_checking);
            holder.statusIcon.setTextColor(context.getResources().getColor(R.color.brand_k));
            holder.status.setTextColor(context.getResources().getColor(R.color.brand_k));
        }

        holder.statusIcon.setTypeface(Helper.sharedHelper().getIconFont());

        holder.status.setText(auth.getStatusStr());

        if (status == Constant.CERT_STATUS_DENY) {
            holder.deleteButton.setVisibility(View.VISIBLE);
            holder.deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.onDeleteClick(auth.getCertId());
                }
            });
        } else {
            holder.deleteButton.setVisibility(View.GONE);
        }

        return convertView;
    }


    private void loadImg(String url, ViewGroup.LayoutParams layoutParams, SimpleDraweeView img) {
        int height = layoutParams.height;
        int width = layoutParams.width;
        if (url != null) {
            String reqUrl = url;
            if (width > 0) {
                reqUrl = ImgUtil.getCDNUrlWithWidth(url, width);
            } else if (height > 0) {
                reqUrl = ImgUtil.getCDNUrlWithHeight(url, height);
            }
            img.setImageURI(Uri.parse(reqUrl));
        }
    }

    class OrderItemHolder {
        public SimpleDraweeView userPic;
        public TextView picCount;
        public TextView title;
        public TextView statusIcon;
        public TextView status;
        public TextView desc;
        public TextView updateTime;
        public TextView deleteButton;

    }

    public interface DeleteListener {
        public void onDeleteClick(int certId);
    }
}
