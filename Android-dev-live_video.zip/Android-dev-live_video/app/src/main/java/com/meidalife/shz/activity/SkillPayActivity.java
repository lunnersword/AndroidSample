package com.meidalife.shz.activity;

import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.SpannedString;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SkillPayListAdapter;
import com.meidalife.shz.im.Message;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SkillPayDO;
import com.meidalife.shz.util.LoadUtil;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 技能支付页面
 * Created by liujian on 16/4/21.
 */
public class SkillPayActivity extends BaseActivity {

    @Bind(R.id.userAvatar)
    SimpleDraweeView userAvatar;
    @Bind(R.id.iconGender)
    TextView iconGender;
    @Bind(R.id.nickName)
    TextView nickName;
    @Bind(R.id.jobIcon)
    SimpleDraweeView jobIcon;
    @Bind(R.id.jobName)
    TextView jobName;
    @Bind(R.id.jobTitle)
    TextView jobTitle;
    @Bind(R.id.selectLayout)
    LinearLayout selectLayout;
    @Bind(R.id.selectSkill)
    TextView selectSkill;
    @Bind(R.id.expandIcon)
    TextView expandIcon;
    @Bind(R.id.skillListLayout)
    View skillListLayout;
    @Bind(R.id.skillListView)
    ListView skillListView;
    @Bind(R.id.contentView)
    View contentView;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.commitView)
    Button commitView;
    @Bind(R.id.inputMoney)
    EditText inputMoney;
    @Bind(R.id.redpackHintLayout)
    View redpackHintLayout;
    @Bind(R.id.icon)
    SimpleDraweeView icon;
    @Bind(R.id.redpackHint)
    TextView redpackHint;

    private String sellerId;
    private LoadUtil loadUtil;
    private SkillPayListAdapter skillPayListAdapter;
    private boolean isExpand;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skill_pay);

        ButterKnife.bind(this);
        initActionBar(R.string.title_activity_input_money, true);
        loadUtil = new LoadUtil(LayoutInflater.from(this));
        sellerId = getIntent().getStringExtra("sellerId");
        initEditTextHint();
        initListener();
        initData();
    }

    private void initEditTextHint(){
        SpannableString ss = new SpannableString("询问服务者后输入");
        AbsoluteSizeSpan ass = new AbsoluteSizeSpan(12,true);
        ss.setSpan(ass, 0, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        inputMoney.setHint(new SpannedString(ss));
    }

    private void initListener(){
        commitView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (skillPayListAdapter == null || skillPayListAdapter.getSelectItemId() == null) {
                    MessageUtils.showToastCenter("请选择服务技能");
                    return;
                }
                if (TextUtils.isEmpty(inputMoney.getText())) {
                    MessageUtils.showToastCenter("请输入消费金额");
                    return;
                }
                handlerCommit();
            }
        });

        selectLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isExpand) {
                    closeSkills();
                } else
                    expandSkills();
            }
        });
    }

    private void initData() {
        loadUtil.loadPre(rootView, contentView);
        commitView.setVisibility(View.GONE);
        commitView.setEnabled(false);
        JSONObject params = new JSONObject();
        params.put("sellerId", sellerId == null ? "" : sellerId);
        HttpClient.get("1.1/buyerOrder/bill", params, SkillPayDO.class, new HttpClient.HttpCallback<SkillPayDO>() {
            @Override
            public void onSuccess(SkillPayDO skillPayDO) {
                loadUtil.loadSuccess(contentView);
                commitView.setVisibility(View.VISIBLE);
                commitView.setEnabled(true);
                if (skillPayDO != null)
                    handlerInitData(skillPayDO);
            }

            @Override
            public void onFail(HttpError error) {
                loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initData();
                    }
                });
            }
        });
    }

    private void handlerInitData(final SkillPayDO skillPayDO) {
        if (!TextUtils.isEmpty(skillPayDO.getUserAvatar()))
            userAvatar.setImageURI(Uri.parse(skillPayDO.getUserAvatar()));
        if(!TextUtils.isEmpty(skillPayDO.getRedpackHint())){
            redpackHintLayout.setVisibility(View.VISIBLE);
            redpackHint.setText(skillPayDO.getRedpackHint());
            if(!TextUtils.isEmpty(skillPayDO.getIconurl())){
                icon.setImageURI(Uri.parse(skillPayDO.getIconurl()));
                icon.setVisibility(View.VISIBLE);
            }else
                icon.setVisibility(View.GONE);
        }else{
            redpackHintLayout.setVisibility(View.GONE);
        }
        nickName.setText(skillPayDO.getUserNick());
        // 设置性别
        if (skillPayDO.getGender() != null) {
            iconGender.setVisibility(View.VISIBLE);
            if (skillPayDO.getGender().equals("woman") || skillPayDO.getGender().equals("F")) {
                iconGender.setText(getResources().getString(R.string.icon_gender_f));
                iconGender.setBackgroundResource(R.drawable.bg_circle_profile_red);
            } else {
                iconGender.setText(getResources().getString(R.string.icon_gender_m));
                iconGender.setBackgroundResource(R.drawable.bg_circle_profile_brand_i);
            }
        } else {
            iconGender.setVisibility(View.GONE);
        }
        if (skillPayDO.getJobTitle() != null) {
            jobTitle.setVisibility(View.VISIBLE);
            jobTitle.setText(skillPayDO.getJobTitle());
        } else
            jobTitle.setVisibility(View.GONE);

        if (skillPayDO.getJobs() != null && skillPayDO.getJobs().size() != 0) {
            jobName.setVisibility(View.VISIBLE);
            jobIcon.setVisibility(View.VISIBLE);
            jobName.setText(skillPayDO.getJobs().get(0).getTitle());
            if(skillPayDO.getJobs().get(0).getIconUrl() != null)
                jobIcon.setImageURI(Uri.parse(skillPayDO.getJobs().get(0).getIconUrl()));
        } else{
            jobName.setVisibility(View.GONE);
            jobIcon.setVisibility(View.GONE);
        }
        if(skillPayDO.getSkills() != null && skillPayDO.getSkills().size() != 0){
            expandSkills();
            skillPayListAdapter = new SkillPayListAdapter(this,skillPayDO.getSkills());
            skillListView.setAdapter(skillPayListAdapter);
            skillListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    skillPayListAdapter.setSelectItemId(skillPayDO.getSkills().get(position).getId());
                    selectSkill.setText(skillPayDO.getSkills().get(position).getName());
                    skillPayListAdapter.notifyDataSetChanged();
                }
            });
        }else{
            closeSkills();
        }


    }

    private void handlerCommit(){
        JSONObject params = new JSONObject();
        params.put("sellerId",sellerId);
        params.put("skillId",skillPayListAdapter.getSelectItemId());
        params.put("skillName",selectSkill.getText().toString());
        params.put("amount",Double.parseDouble(inputMoney.getText().toString())*100);
        commitView.setEnabled(false);
        HttpClient.get("1.0/skill/buyerOrder/order", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                if (result.containsKey("orderNo")) {
                    String orderNo = result.getString("orderNo");
                    Bundle bundle = new Bundle();
                    bundle.putString("orderNo", orderNo);
                    if (result.containsKey("title")) {
                        bundle.putString("title", result.getString("title"));
                    }
                    Router.sharedRouter().open("pay", bundle);
                    finish();
                }
            }

            @Override
            public void onFail(HttpError error) {
                commitView.setEnabled(true);
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "操作失败，请稍后再试");
            }
        });
    }

    private void expandSkills(){
        skillListLayout.setVisibility(View.VISIBLE);
        isExpand = true;
        expandIcon.setText(getString(R.string.icon_arrow_collapse));
    }

    private void closeSkills(){
        skillListLayout.setVisibility(View.GONE);
        isExpand = false;
        expandIcon.setText(getString(R.string.icon_arrow_expand));
    }

}
