package com.meidalife.shz.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentTabHost;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Editable;
import android.text.Spannable;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.ChatExpressionFragment;
import com.meidalife.shz.adapter.SquareAskDetailAdapter;
import com.meidalife.shz.adapter.SquareBbsDetailAdapter;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.rest.model.SquareBbsDetailDO;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.rest.request.RequestSquareAsk;
import com.meidalife.shz.view.FontEditText;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;
import com.meidalife.shz.widget.PopupListMenu;
import com.usepropeller.routable.Router;

import org.json.JSONException;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.greenrobot.event.EventBus;

public class SquareBbsDetailActivity extends BaseActivity {

    private String topicId;
    private SquareBbsDetailAdapter squareBbsDetailAdapter;
    private ListView mListView;
    private ArrayList<SquareBbsDetailDO> mReplyList;
    private View listFooter;
    private ProgressBar footerLoading;
    private TextView footerMessage;
    private Button footerReload;
    private ViewGroup mTabcontent;
    private FragmentTabHost mTabHost;
    private IconTextView anonymousView;
    private FontEditText inputEdit;
    private IconTextView chatFaceIcon;
    private IconTextView openAttach;
    private FontTextView chatSend;
    private View attachImgContainer;
    private View chatFaceContainer;
    private IconTextView photoIcon;
    private boolean isAnonymousSend = false;
    private ChatHelper chatHelper;
    private String picUrl;

    private View photoIconContainer;
    private SimpleDraweeView picView;
    private View picContainer;
    private IconTextView cancelPic;
    private String resultUrl;
    private String textContent;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ViewGroup statusView;
    private View replyView;

    private int previous = 0;
    boolean loading = false;
    boolean complete = false;
    int PAGE_SIZE = 20;
    int page = 0;
    boolean isFirstEnter = true;
    private JSONObject squareBbsItem;
    private boolean otherContentLoadDone = false;
    private boolean hasComment = false;
    private boolean hasHandlerPin = false;
    private static final int MENU_ITEM_ACTION_PIN = 0;
    private static final int MENU_ITEM_ACTION_DEL = 1;
    private static final int MENU_ITEM_CANCEL = 2;
    private PopupListMenu mPopupListMenu;
    private boolean pin = false;
    private int geziId = Integer.MAX_VALUE;
    private boolean isGeZhu = false;
    private boolean isJoined = false;
    private boolean isReplyUser = false;
    private PopupListMenu mPopupReplyMenu;
    private static final int MENU_ITEM_REPLY_OTHER = 1;
    private int mReplyCommentId = -1;
    private int mLastReplyPosition = 0;
    private InputMethodManager imm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_bbs_detail);
        initActionBar(R.string.title_activity_square_bbs_detail, true);
        chatHelper = ChatHelper.getInstance();
        EventBus.getDefault().register(this);

        topicId = getIntent().getStringExtra("topicid");
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            geziId = bundle.getInt("geziId", Integer.MAX_VALUE);
            isGeZhu = bundle.getBoolean("isGeZhu", false);
            isJoined = bundle.getBoolean("isJoined", false);
            pin = bundle.getBoolean("pin", false);
        }
        Log.d("mzLog", "topicId: " + topicId);
        findView();
        bindListener();
        // chatSend.setVisibility(View.GONE);
        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mReplyList = new ArrayList<>();
        mTabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);
        mTabHost.addTab(getTabSpecView("home", R.layout.item_single_image), ChatExpressionFragment.class, null);
        otherContentLoadDone = false;
        isFirstEnter = false;
        fetchData(true);
    }

    private void fetchData(boolean showLoading) {
        hideStatusErrorNetwork();
        hideStatusErrorServer();
        hideStatusLoading();
        if (showLoading) {
            showStatusLoading(statusView);
            swipeRefreshLayout.setVisibility(View.GONE);
            replyView.setVisibility(View.GONE);
        }
        page = 0;
        complete = false;
        getTopicItem();

        // fetchDetailItem();
        isFirstEnter = false;
    }

    private void initListView() {
        squareBbsDetailAdapter = new SquareBbsDetailAdapter(this, squareBbsItem, mReplyList);
        squareBbsDetailAdapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHidePopMenu(v);
            }
        });
        mListView.setAdapter(squareBbsDetailAdapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {

            case Constant.REQUEST_CODE_PICK_PHOTO: {
                // 选择图片
                if (resultCode == RESULT_OK) {
                    Bundle bundle = data.getExtras();
                    ArrayList paths = bundle.getStringArrayList("images");
                    if (paths.size() > 0) {
                        Log.d("mzLog", "paths.get(0): " + paths.get(0));
                        picUrl = (String) paths.get(0);
                        syncAvatar(picUrl);
                        picContainer.setVisibility(View.VISIBLE);
                        photoIconContainer.setVisibility(View.GONE);
                    }
                }
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (hasHandlerPin || hasComment || (squareBbsDetailAdapter != null && squareBbsDetailAdapter.getHasUpdateVote())) {
            setResult(RESULT_OK);
        }
        super.onBackPressed();
    }

    public void onEventMainThread(ChatExpressionFragment.ChatExpressionEvent event) {
        Editable edit = inputEdit.getEditableText();//获取EditText的文字
        int index = inputEdit.getSelectionStart();
        if (index < 0 || index >= edit.length()) {
            edit.append(event.expressionName);
        } else {
            edit.insert(index, event.expressionName);//光标所在位置插入文字
        }
        ImageSpan expressionPan = chatHelper.getImageSpan(event.expressionName, 20);
        if (null != expressionPan) {
            edit.setSpan(expressionPan, index, index + event.expressionName.length(),
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    private void findView() {
        statusView = (ViewGroup) findViewById(R.id.statusView);
        replyView = findViewById(R.id.replyView);
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        mListView = (ListView) findViewById(R.id.listView);
        mTabcontent = (ViewGroup) findViewById(android.R.id.tabcontent);
        mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        anonymousView = (IconTextView) findViewById(R.id.anonymousView);
        inputEdit = (FontEditText) findViewById(R.id.inputEdit);
        chatFaceIcon = (IconTextView) findViewById(R.id.chatFaceIcon);
        openAttach = (IconTextView) findViewById(R.id.openAttach);
        chatSend = (FontTextView) findViewById(R.id.chatSend);
        photoIcon = (IconTextView) findViewById(R.id.photoIcon);
        attachImgContainer = findViewById(R.id.attachImgContainer);
        chatFaceContainer = findViewById(R.id.chatFaceContainer);
        photoIconContainer = findViewById(R.id.photoIconContainer);
        picView = (SimpleDraweeView) findViewById(R.id.picView);
        picContainer = findViewById(R.id.picContainer);
        cancelPic = (IconTextView) findViewById(R.id.cancelPic);
        listFooter = getLayoutInflater().inflate(R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);
        mListView.addFooterView(listFooter);
        listFooter.setVisibility(View.GONE);
    }

    private void bindListener() {

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("mzLog", "mListView click " + position);
                if (position != 1) {
                    textContent = inputEdit.getText().toString();
                    textContent = textContent.trim();
                    //原内容不为空时
                    if ((picUrl != null && !picUrl.isEmpty()) || textContent.length() > 0) {
                        if (position != mLastReplyPosition) {
                            if (position == 0 || mLastReplyPosition == 0) {
                                showPopopReplyMenu(view, position);
                            } else if (mReplyList.get(position - 2).getUserId() != mReplyList.get(mLastReplyPosition - 2).getUserId()) {
                                showPopopReplyMenu(view, position);
                            }
                        }

                    } else {
                        //原内容为空
                        refreshInputEdit(position);

                    }
                }

            }
        });

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                fetchData(false);
            }
        });

        cancelPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                picUrl = null;
                picContainer.setVisibility(View.GONE);
                photoIconContainer.setVisibility(View.VISIBLE);
            }
        });

        inputEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //  chatSend.setVisibility(View.GONE);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                if (s.toString().length() > 0) {
//                    chatSend.setVisibility(View.VISIBLE);
//                } else {
//                    chatSend.setVisibility(View.GONE);
//                }
                if (inputEdit.getTag() != null && (Boolean) inputEdit.getTag()) {
                    inputEdit.setTag(false);
                    return; // 是表情输入，忽略此次内容变化
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        inputEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attachImgContainer.setVisibility(View.GONE);
                chatFaceContainer.setVisibility(View.GONE);
                chatFaceIcon.setText(getString(R.string.icon_chat_face));
            }
        });

        inputEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    attachImgContainer.setVisibility(View.GONE);
                    chatFaceContainer.setVisibility(View.GONE);
                    chatFaceIcon.setText(getString(R.string.icon_chat_face));
                }
            }
        });

        photoIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putBoolean("isCheckbox", false);
                Router.sharedRouter().openFormResult("pick/photo", bundle,
                        Constant.REQUEST_CODE_PICK_PHOTO, SquareBbsDetailActivity.this);
            }
        });

        anonymousView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isAnonymousSend) {
                    anonymousView.setText(R.string.icon_anonymous);
                    anonymousView.setTextColor(getResources().getColor(R.color.brand_b));
                    isAnonymousSend = true;
                    MessageUtils.showToastCenter("已开启匿名回复");
                } else {
                    anonymousView.setText(R.string.icon_no_anonymous);
                    anonymousView.setTextColor(getResources().getColor(R.color.grey_b));
                    isAnonymousSend = false;
                    MessageUtils.showToastCenter("已关闭匿名回复");
                }
            }
        });

        chatFaceIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (chatFaceContainer.getVisibility() == View.GONE) {
                    attachImgContainer.setVisibility(View.GONE);
                    chatFaceContainer.setVisibility(View.VISIBLE);
                    chatFaceIcon.setText(getString(R.string.icon_chat_keyboard));
                    hideKeyboard();
                } else {
                    inputEdit.requestFocus();
                    chatFaceIcon.setText(getString(R.string.icon_chat_face));
                    chatFaceContainer.setVisibility(View.GONE);
                    attachImgContainer.setVisibility(View.GONE);
                }
            }
        });

        openAttach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (attachImgContainer.getVisibility() == View.GONE) {
                    chatFaceContainer.setVisibility(View.GONE);
                    attachImgContainer.setVisibility(View.VISIBLE);
                    hideKeyboard();

                } else {
                    attachImgContainer.setVisibility(View.GONE);
                    chatFaceContainer.setVisibility(View.GONE);

                }
            }
        });

        chatSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Helper.sharedHelper().hasToken()) {
                    if (isJoined) {
                        chatSend();
                    } else {
                        showJoinDialog(R.string.square_bbs_add_comment_warn);
                    }
                } else {
                    showLoginDialog(R.string.square_bbs_login_comment_warn);
                }
            }
        });

        mListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView absListView, int scrollState) {
                if (scrollState == SCROLL_STATE_IDLE && mListView.getFirstVisiblePosition() == 0
                        && mListView.getTop() == 0) {
                    swipeRefreshLayout.setEnabled(true);
                } else {
                    swipeRefreshLayout.setEnabled(false);
                }

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (absListView.getLastVisiblePosition() == absListView.getCount() - 1) {
                        loadDetailItem();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }
        });
    }

    private void refreshInputEdit(int position) {
        inputEdit.requestFocus();
        imm.showSoftInput(inputEdit, InputMethodManager.SHOW_FORCED);
        if (position == 0) {
            mLastReplyPosition = 0;
            isReplyUser = false;
            inputEdit.setHint("输入你想说的......");
        } else {
            if (position > 1) {
                mLastReplyPosition = position;
                isReplyUser = true;
                SquareBbsDetailDO replyCommentDO = mReplyList.get(position - 2);
                mReplyCommentId = replyCommentDO.getId();
                inputEdit.setHint("@" + replyCommentDO.getUserNick());
            }
        }
    }

    private void chatSend() {
        textContent = inputEdit.getText().toString();
        textContent = textContent.trim();

        if (textContent.length() > 0) {
            if (picUrl != null && !picUrl.isEmpty()) {
                showProgressDialog("回复中", false);
                xhrUploadPic(picUrl);
            } else {
                showProgressDialog("回复中", false);
                JSONObject params = new JSONObject();
                params.put("topicId", topicId);
                params.put("content", textContent);
                if (isAnonymousSend) {
                    params.put("anonymous", 1);
                } else {
                    params.put("anonymous", 0);
                }
                if (isReplyUser) {
                    params.put("replyCommentId", mReplyCommentId);
                }
                uploadReply(params);
            }
        } else {
            MessageUtils.showToastCenter("还没有输入内容哦");
        }
    }

    private void getTopicItem() {
        JSONObject params = new JSONObject();
        params.put("topicId", topicId);
        HttpClient.get("1.0/gezi/bbs/topicDetail", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                Log.d("mzLog", "jsTopic: " + obj.toString());
                squareBbsItem = (JSONObject) obj;

                if (otherContentLoadDone) {
                    hideStatusLoading();
                    hideStatusErrorNetwork();
                    hideStatusErrorServer();
//                    replyView.setVisibility(View.VISIBLE);
//                    swipeRefreshLayout.setVisibility(View.VISIBLE);
//                    squareBbsDetailAdapter.notifyDataSetChanged();
//                    swipeRefreshLayout.setRefreshing(false);
                } else {
                    otherContentLoadDone = true;
                }
                initListView();
                fetchDetailItem(true);
            }

            @Override
            public void onFail(HttpError error) {
                swipeRefreshLayout.setRefreshing(false);
                replyView.setVisibility(View.GONE);
                swipeRefreshLayout.setVisibility(View.GONE);
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(statusView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fetchData(true);
                        }
                    });
                } else {
                    showStatusErrorServer(statusView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fetchData(true);
                        }
                    });
                    setTextErrorServer(error.getMessage());
                }
            }
        });
    }

    private void xhrUploadPic(String path) {
        RequestSign.upload(path, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                org.json.JSONObject json = (org.json.JSONObject) result;
                try {
                    resultUrl = json.getString("data");
                    Log.d("mzLog", "resultUrl: " + resultUrl);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                JSONObject params = new JSONObject();
                params.put("topicId", topicId);
                params.put("content", textContent);
                if (isAnonymousSend) {
                    params.put("anonymous", 1);
                } else {
                    params.put("anonymous", 0);
                }
                JSONArray picArr = new JSONArray();
                picArr.add(resultUrl);
                params.put("pics", picArr);
                uploadReply(params);

            }

            @Override
            public void onFailure(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "图片上传失败，请重试");

            }
        });
    }

    private void uploadReply(JSONObject params) {

        Log.d("mzLog", "uploadReply params: " + params.toString());
        HttpClient.get("1.0/gezi/bbs/addComment", params, null, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object result) {
                hasComment = true;
                hideProgressDialog();
                MessageUtils.showToastCenter("回复成功");
                page = 0;
                complete = false;
                if (squareBbsItem != null)
                    squareBbsItem.put("commentCount", squareBbsItem.getIntValue("commentCount") + 1);
                fetchDetailItem(true);
                anonymousView.setText(R.string.icon_no_anonymous);
                anonymousView.setTextColor(getResources().getColor(R.color.grey_b));
                isAnonymousSend = false;
                inputEdit.setText("");
                inputEdit.setHint("输入你想说的......");
                mLastReplyPosition = 0;
                attachImgContainer.setVisibility(View.GONE);
                chatFaceContainer.setVisibility(View.GONE);
                picContainer.setVisibility(View.GONE);
                photoIconContainer.setVisibility(View.VISIBLE);

                picUrl = null;
                isReplyUser = false;
                hideKeyboard();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "回复失败，请重试");

            }
        });
    }

    private void syncAvatar(String path) {
        Uri uri = Uri.fromFile(new File(path));
        photoIconContainer.setVisibility(View.GONE);
        picView.setImageURI(uri);
    }

    private FragmentTabHost.TabSpec getTabSpecView(String tag, int layoutId) {
        return mTabHost.newTabSpec(tag).setIndicator(getLayoutInflater().inflate(layoutId, null));
    }

    private void loadDetailItem() {
        if (!complete && !loading) {
            page++;
            fetchDetailItem(false);
        }
    }

    private void fetchDetailItem(final boolean isRefresh) {

        loading = true;
        listFooter.setVisibility(View.VISIBLE);

        HttpClient.get("1.0/gezi/bbs/getComments", getDetailItemParams(), null, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object result) {
                listFooter.setVisibility(View.GONE);
                loading = false;
                JSONArray detailArr = (JSONArray) result;

                Log.d("mzLog detailArr: ", detailArr.toString());
                int size = detailArr.size();
                if (isRefresh)
                    mReplyList.clear();
                for (int i = 0; i < size; i++) {
                    SquareBbsDetailDO squareBbsDetailDO = new SquareBbsDetailDO();
                    JSONObject detailItem = (JSONObject) detailArr.get(i);

                    squareBbsDetailDO.setId(detailItem.getInteger("id"));
                    squareBbsDetailDO.setContent(detailItem.getString("content"));
                    squareBbsDetailDO.setCreateTime(detailItem.getLong("createTime"));
                    if (detailItem.containsKey("userId")) {
                        squareBbsDetailDO.setUserId(detailItem.getInteger("userId"));
                    }
                    squareBbsDetailDO.setUserNick(detailItem.getString("userNick"));
                    squareBbsDetailDO.setUserAvatar(detailItem.getString("userAvatar"));
                    squareBbsDetailDO.setUserGender(detailItem.getString("userGender"));
                    squareBbsDetailDO.setAnonymous(detailItem.getInteger("anonymous"));

                    if (detailItem.containsKey("replyUserId")) {
                        squareBbsDetailDO.setReplyUserId(detailItem.getInteger("replyUserId"));
                        squareBbsDetailDO.setReplyUserNick(detailItem.getString("replyUserNick"));
                        squareBbsDetailDO.setReplyUserAvatar(detailItem.getString("replyUserAvatar"));
                        squareBbsDetailDO.setReplyUserGender(detailItem.getString("replyUserGender"));
                    }
                    ArrayList<String> picsArr = new ArrayList<>();

                    if (detailItem.containsKey("pics")) {
                        JSONArray jsonArray = detailItem.getJSONArray("pics");
                        int picsSize = jsonArray.size();
                        for (int j = 0; j < picsSize; j++) {
                            picsArr.add((String) jsonArray.get(j));
                        }
                    }

                    squareBbsDetailDO.setPics(picsArr);
                    mReplyList.add(squareBbsDetailDO);
                }

                if (otherContentLoadDone) {
                    hideStatusLoading();
                    hideStatusErrorNetwork();
                    hideStatusErrorServer();
                    //   initListView();
                    replyView.setVisibility(View.VISIBLE);
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                    squareBbsDetailAdapter.notifyDataSetChanged();
                    swipeRefreshLayout.setRefreshing(false);
                } else {
                    otherContentLoadDone = true;
                }

                if (size < PAGE_SIZE) {
                    complete = true;
                    mListView.removeFooterView(listFooter);
                }
            }

            @Override
            public void onFail(HttpError error) {
                loading = false;
                if (page != 0) {
                    page--;
                }
                swipeRefreshLayout.setRefreshing(false);
                replyView.setVisibility(View.GONE);
                swipeRefreshLayout.setVisibility(View.GONE);
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(statusView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fetchData(true);
                        }
                    });
                } else {
                    showStatusErrorServer(statusView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fetchData(true);
                        }
                    });
                    setTextErrorServer(error.getMessage());
                }
            }
        });
    }

    private void showPopopReplyMenu(View view, final int position) {
        List<MenuVO> options = new ArrayList<>();
        if (position == 0) {
            options.add(0, new MenuVO("回复话题"));
        } else if (position > 1) {
            String userNick = mReplyList.get(position - 2).getUserNick();
            options.add(0, new MenuVO("回复 " + userNick));
        }
        options.add(1, new MenuVO(getString(R.string.cancel)));
        if (null == mPopupReplyMenu) {
            mPopupReplyMenu = new PopupListMenu(this,0);
        }
        mPopupReplyMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int menuPosition, long id) {
                switch (menuPosition) {
                    case 0:
                        picUrl = null;
                        picContainer.setVisibility(View.GONE);
                        photoIconContainer.setVisibility(View.VISIBLE);
                        attachImgContainer.setVisibility(View.GONE);
                        chatFaceContainer.setVisibility(View.GONE);
                        chatFaceIcon.setText(getString(R.string.icon_chat_face));
                        inputEdit.setText("");
                        refreshInputEdit(position);
                        mPopupReplyMenu.dismiss();
                        inputEdit.requestFocus();
                        imm.showSoftInput(inputEdit, InputMethodManager.SHOW_FORCED);
                        break;

                    case 1:
                        mPopupReplyMenu.dismiss();
                        inputEdit.requestFocus();
                        imm.showSoftInput(inputEdit, InputMethodManager.SHOW_FORCED);
                        break;

                }
            }
        });
        mPopupReplyMenu.setMenuData(options);
        mPopupReplyMenu.showAtLocation(view, Gravity.BOTTOM, 0, 0);
    }

    @Override
    protected void showOrHidePopMenu(View v) {
        if (v.getTag() == null)
            return;
        HashMap params = (HashMap) v.getTag();
        final int type = (int) params.get("type");
        final int delId = (int) params.get("id");
        final boolean isOwn = (boolean) params.get("isOwn");
        List<MenuVO> options = new ArrayList<>();
        if (type == SquareBbsDetailAdapter.VIEW_TYPE_TOPIC) {
            if (isGeZhu) {
                options.add(MENU_ITEM_ACTION_PIN, new MenuVO(getString(pin ? R.string.square_cancel_pin : R.string.square_pin)));
                options.add(MENU_ITEM_ACTION_DEL, new MenuVO(isOwn ? getString(R.string.delete) : getString(R.string.report)));
                options.add(MENU_ITEM_CANCEL, new MenuVO(getString(R.string.cancel)));
            } else {
                options.add(MENU_ITEM_ACTION_PIN, new MenuVO(isOwn ? getString(R.string.delete) : getString(R.string.report)));
                options.add(MENU_ITEM_ACTION_DEL, new MenuVO(getString(R.string.cancel)));
            }
        } else {
            options.add(MENU_ITEM_ACTION_PIN, new MenuVO(isOwn ? getString(R.string.delete) : getString(R.string.report)));
            options.add(MENU_ITEM_ACTION_DEL, new MenuVO(getString(R.string.cancel)));
        }
        final int size = options.size();
        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(this,0);
        }

        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_ACTION_PIN:
                        if (size == 3) {
                            handlerPin(delId);
                        } else {
                            if (isOwn) {
                                deleteItem(type, delId);
                            } else
                                report(type, delId);
                        }
                        mPopupListMenu.dismiss();
                        break;
                    case MENU_ITEM_ACTION_DEL:
                        if (size == 3) {
                            if (isOwn) {
                                deleteItem(type, delId);
                            } else
                                report(type, delId);
                        }
                        mPopupListMenu.dismiss();
                        break;
                    case MENU_ITEM_CANCEL:
                        mPopupListMenu.dismiss();
                        break;
                }
            }
        });


        mPopupListMenu.setMenuData(options);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private void handlerPin(int itemId) {
        if (!isGeZhu) {
            MessageUtils.showToastCenter("非格主不能操作");
            return;
        }
        String path = pin ? "1.0/gezi/pin/del" : "1.0/gezi/pin/add";
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("bizType", Constant.SQUARE_LIST_PIN_TYPE_BBS);
        params.put("geziId", geziId);
        params.put("bizId", itemId);
        HttpClient.get(path, params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                pin = !pin;
                hasHandlerPin = true;
                MessageUtils.showToastCenter("操作成功");
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "操作失败");
            }
        });
    }

    private void deleteItem(final int type, int delId) {

        showProgressDialog(getString(R.string.text_deleting));
        JSONObject params = new JSONObject();
        String urlPath = "";
        if (type == SquareBbsDetailAdapter.VIEW_TYPE_TOPIC) {
            urlPath = "1.0/gezi/bbs/deleteTopic";
            params.put("topicId", delId);
        } else if (type == SquareBbsDetailAdapter.VIEW_TYPE_REPLY) {
            urlPath = "1.0/gezi/bbs/deleteComment";
            params.put("commentId", delId);
        }

        HttpClient.get(urlPath, params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideProgressDialog();
                if (type == SquareAskDetailAdapter.VIEW_TYPE_DEMAND) {
                    //需要通知列表页更新
                    setResult(RESULT_OK);
                    finish();
                } else {
                    //更新当前页面
                    // fetchData(true);
                    page = 0;
                    complete = false;
                    if (squareBbsItem != null)
                        squareBbsItem.put("commentCount", squareBbsItem.getIntValue("commentCount") - 1);
                    fetchDetailItem(true);
                }
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "操作失败");
            }
        });
    }

    //举报
    private void report(final int type, int id) {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", String.valueOf(id));
        intent.putExtra("target", type == SquareBbsDetailAdapter.VIEW_TYPE_TOPIC ?
                Constant.REPORT_TYPE_SQUARE_BBS : Constant.REPORT_TYPE_SQUARE_BBS_REPLY);
        startActivity(intent);
    }

    private JSONObject getDetailItemParams() {
        JSONObject params = new JSONObject();
        params.put("topicId", topicId);
        params.put("offset", PAGE_SIZE * page);
        params.put("pageSize", PAGE_SIZE);
        return params;
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(inputEdit.getWindowToken(), 0);
    }

    void showLoginDialog(int resId) {
        MessageUtils.showDialog(this, this.getResources().getString(R.string.square_warn),
                this.getResources().getString(resId), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Router.sharedRouter().openFormResult("signin", SquareBbsDetailActivity.this);
                    }
                }, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
    }

    void showJoinDialog(int resId) {
        MessageUtils.showDialog(this, this.getResources().getString(R.string.square_warn),
                this.getResources().getString(resId), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        joinCurrentGeZi();
                    }
                }, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
    }

    private void joinCurrentGeZi() {
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        RequestSquareAsk.joinGezi(params, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                MessageUtils.showToast("你已成功加入该格子");
                isJoined = true;
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToast(error != null ? error.getMessage() : "加入格子失败，请稍后再试");
            }
        });
    }

    @Override
    public boolean isShouldHideInput(View v, MotionEvent event) {
        if (v != null && (v instanceof EditText)) {
            int[] leftTop = {0, 0};
            //获取输入框当前的location位置
            v.getLocationInWindow(leftTop);
            int left = leftTop[0];
            int top = leftTop[1];
            int bottom = top + v.getHeight();
            int right = left + v.getWidth();

            int[] leftTopAnony = {0, 0};
            //获取输入框当前的location位置
            anonymousView.getLocationInWindow(leftTopAnony);
            int leftAnony = leftTopAnony[0];
            int topAnony = leftTopAnony[1];
            int bottomAnony = topAnony + anonymousView.getHeight();
            int rightAnony = leftAnony + anonymousView.getWidth();
            if ((event.getX() > left && event.getX() < right
                    && event.getY() > top && event.getY() < bottom)
                    || (event.getX() > leftAnony && event.getX() < rightAnony
                    && event.getY() > topAnony && event.getY() < bottomAnony)) {
                // 点击的是输入框区域，保留点击EditText的事件
                return false;
            } else {
                return true;
            }
        }
        return false;
    }
}
