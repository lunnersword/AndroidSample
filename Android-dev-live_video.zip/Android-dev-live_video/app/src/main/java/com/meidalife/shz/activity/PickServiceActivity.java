package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ServiceListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.PickServiceDo;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.util.LoadUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class PickServiceActivity extends BaseActivity implements ServiceListAdapter.OnServiceSelectListener {
    int PAGE_SIZE = 20;
    int page = 0;
    boolean loading = true;
    String selectItemId;
    List<PickServiceDo> data = new ArrayList<>();

    @Bind(R.id.listView)
    ListView listView;
    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.cellEmptyData)
    RelativeLayout cellEmptyData;
    @Bind(R.id.publishListEmptyIcon)
    TextView publishListEmptyIcon;

    ServiceListAdapter serviceListAdapter;
    LoadUtil mLoadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_service);
        initActionBar(R.string.title_activity_pick_service, true);
        ButterKnife.bind(this);
        selectItemId = getIntent().getStringExtra("itemId");

        mLoadUtil = new LoadUtil(LayoutInflater.from(this));
        serviceListAdapter = new ServiceListAdapter(this, data);
        serviceListAdapter.setOnServiceSelectListener(this);
        listView.setAdapter(serviceListAdapter);

        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            private boolean moveToBottom = false;
            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (previous < firstVisibleItem) {
                    moveToBottom = true;
                } else if (previous > firstVisibleItem) {
                    moveToBottom = false;
                }
                previous = firstVisibleItem;

                if (totalItemCount == firstVisibleItem + visibleItemCount && moveToBottom) {
                    getService(false);
                }
            }
        });
        getService(true);
    }

    private void getService(boolean reload) {
        if (reload) {
            mLoadUtil.loadPre(rootView, listView);
            page = 0;
        }
        JSONObject params = new JSONObject();
        params.put("userId", Helper.sharedHelper().getUserId());
        params.put("pageSize", PAGE_SIZE);
        params.put("offset", page * PAGE_SIZE);
        params.put("showBlock", 0);

        HttpClient.get("1.0/item/getItemSell", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        try {
                            mLoadUtil.loadSuccess(listView);
                            if (null != obj && obj.containsKey("itemSell")) {
                                JSONArray itemArray = obj.getJSONArray("itemSell");
                                data.addAll(JSON.parseArray(itemArray.toJSONString(), PickServiceDo.class));
                                serviceListAdapter.notifyDataSetChanged();
                                page++;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            HttpError error = new HttpError(HttpError.ERR_CODE_UNKNOWN, e.getMessage());
                            mLoadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                                @Override
                                public void retry() {
                                    getService(true);
                                }
                            });
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        mLoadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                            @Override
                            public void retry() {
                                getService(true);
                            }
                        });
                    }
                });
    }

    @Override
    public void onServiceSlect(PickServiceDo pickServiceDo) {
        Intent intent = new Intent();
        intent.putExtra(Constant.EXTRA_TAG_PICKED_SERVICE, pickServiceDo);
        setResult(RESULT_OK, intent);
        finish();
    }
}
