package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.FontTextView;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yiyang on 16/3/28.
 */
public class LiveServiceRecyclerAdapter extends RecyclerView.Adapter<LiveServiceRecyclerAdapter.ViewHolder> {

    private int selectedIndex = -1;

    private Context mContext;
    private List<ServiceItem> mData;
    private LayoutInflater mInflater;
    private IServiceIndex iServiceIndex;

    public LiveServiceRecyclerAdapter(Context context, List<ServiceItem> data) {
        mContext = context;
        mData = data;
        mInflater = LayoutInflater.from(context);
    }

    public void setIServiceIndex(IServiceIndex iServiceIndex) {
        this.iServiceIndex = iServiceIndex;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_live_service_recycler, null);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        ServiceItem item = mData.get(position);
        holder.canDo.setText(item.getTag());
        holder.category.setText(item.getStdCatName());
        Uri imageUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getImages().get(0), holder.picView.getLayoutParams().width));
        holder.picView.setImageURI(imageUri);
        holder.rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedIndex = position;
                notifyDataSetChanged();
                iServiceIndex.serviceSelect(position);
            }
        });

        if (selectedIndex != -1 && selectedIndex == position) {
            holder.greyView.setVisibility(View.GONE);
            holder.rootView.setBackgroundResource(R.color.brand);
            holder.canDo.setTextColor(mContext.getResources().getColor(R.color.grey_a));
            holder.category.setTextColor(mContext.getResources().getColor(R.color.grey_a));
        } else {
            holder.greyView.setVisibility(View.VISIBLE);
            holder.rootView.setBackgroundResource(R.color.grey_a);
            holder.canDo.setTextColor(mContext.getResources().getColor(R.color.brand_e));
            holder.category.setTextColor(mContext.getResources().getColor(R.color.brand_e));
        }
    }


    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View rootView) {
            super(rootView);
            ButterKnife.bind(this, rootView);
        }

        @Bind(R.id.rootView)
        View rootView;
        @Bind(R.id.greyView)
        View greyView;
        @Bind(R.id.picView)
        SimpleDraweeView picView;
        @Bind(R.id.canDo)
        FontTextView canDo;
        @Bind(R.id.category)
        FontTextView category;
    }

    public interface IServiceIndex {

        public void serviceSelect(int index);

    }
}
