package com.meidalife.shz.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CommentAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CommentDO;
import com.meidalife.shz.rest.request.RequestCommentOpr;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.OnResizeListener;
import com.meidalife.shz.view.ResizeRelativeLayout;
import com.usepropeller.routable.Router;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by xiaoweilc on 15/6/23.
 */
public class CommentListActivity extends BaseActivity implements AbsListView.OnScrollListener {

    private Context context;
    private LayoutInflater inflater;
    private ViewGroup rootView;
    private ResizeRelativeLayout contentRoot;
    private InputMethodManager keyboard;
    private LoadUtil loadHelper;

    private String itemId;

    private ListView commentList;
    private View noDataView;
    private SwipeRefreshLayout swipeList;
    private ProgressBar footPb;
    private CommentAdapter commentAdapter;
    private List<CommentDO> mDataList = new LinkedList<>();
    private int pageSize = 20;
    private int page = 0;


    private boolean isMoreData = true;
    private boolean isLoading = false;
    private int previous;

    private EditText inputText;
    private CommentAdapter.PJViewHolder preHolder;
    private int preItemIndex = 0;
    private int itemHeight = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment_list);
        initActionBar(R.string.title_comment_list, true);

        context = getApplicationContext();
        inflater = getLayoutInflater();
        keyboard = (InputMethodManager) getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = (ResizeRelativeLayout) findViewById(R.id.content_root_view);
        loadHelper = new LoadUtil(inflater);

        Bundle extras = getIntent().getExtras();
        itemId = extras.getString("itemId");

        if (!Helper.sharedHelper().hasToken()) {
            Bundle bundle = new Bundle();
            bundle.putString("action", "commentList/" + itemId);
            Router.sharedRouter().open("signin", bundle);
            finish();
        }

        commentList = (ListView) findViewById(R.id.comment_list_view);
        noDataView = findViewById(R.id.comment_list_no_data);
        View foot = inflater.inflate(R.layout.fragment_comment_foot, null);
        commentList.addFooterView(foot);
        footPb = (ProgressBar) foot.findViewById(R.id.detail_comment_foot_pb);
        swipeList = (SwipeRefreshLayout) findViewById(R.id.comment_list_swipe);
        swipeList.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refresh();
            }
        });


        commentList.setOnItemClickListener(new CommentItemOnClickListener());
        commentList.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                keyboard.hideSoftInputFromWindow(v.getWindowToken(), 0);
                return false;
            }
        });

        inputText = (EditText) findViewById(R.id.comment_input_text);
        TextView inputCommit = (TextView) findViewById(R.id.comment_input_commit);
        CommentInputActionListener commentInputActionListener = new CommentInputActionListener();
        inputCommit.setOnClickListener(commentInputActionListener);

        // 监听布局变化
        final View commentListBar = findViewById(R.id.comment_list_bar);
        contentRoot.setOnResizeListener(new OnResizeListener() {
            @Override
            public void onResize(int w, int h, int oldw, int oldh) {
                if (oldw == 0 || oldh == 0)
                    return;
                if (h > oldh)
                    return;
                int offset = (h - commentListBar.getHeight() - itemHeight);
                commentList.smoothScrollToPositionFromTop(preItemIndex, offset);
            }
        });

        // 初始化数据
        initLoadData();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        // 必不可少，否则所有的组件都不会有TouchEvent了
        if (getWindow().superDispatchTouchEvent(ev)) {
            return true;
        }
        return onTouchEvent(ev);
    }

    public void initLoadData() {

        loadHelper.loadPre(rootView, contentRoot);
        RequestCommentOpr.commentList(genParams(0), new HttpClient.HttpCallback<List<CommentDO>>() {
            @Override
            public void onSuccess(List<CommentDO> dataList) {
                loadHelper.loadSuccess(contentRoot);
                if (CollectionUtil.isNotEmpty(dataList)) {
                    mDataList.addAll(dataList);
                }
                commentAdapter = new CommentAdapter(context, inflater, mDataList);
                commentList.setAdapter(commentAdapter);
                if (CollectionUtil.isEmpty(mDataList)) {
                    TextView icon = (TextView) findViewById(R.id.detail_comment_no_data_icon);
                    icon.setTypeface(Helper.sharedHelper().getIconFont());
                    noDataView.setVisibility(View.VISIBLE);
                } else {
                    commentList.setOnScrollListener(CommentListActivity.this);
                }
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(ServiceDetailActivity.class.getName(), "req comment data fail, itemId=" + itemId + ", " + error.toString());
                loadHelper.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        initLoadData();
                    }
                });
            }
        });
    }

    public void refresh() {
        RequestCommentOpr.commentList(genParams(0), new HttpClient.HttpCallback<List<CommentDO>>() {
            @Override
            public void onSuccess(List<CommentDO> dataList) {
                swipeList.setRefreshing(false);
                if (CollectionUtil.isNotEmpty(dataList)) {
                    mDataList.addAll(dataList);
                }
//                commentAdapter.set(dataList);
                commentAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                swipeList.setRefreshing(false);
                Log.e(ServiceDetailActivity.class.getName(), "req comment data fail, itemId=" + itemId + ", " + error.toString());
                MessageUtils.showToastCenter("code=" + error.getCode() + ", msg : " + error.getMessage());
            }
        });
    }


    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (!isMoreData) {
            return;
        }
        if (isLoading) { // 若已经在加载中，则忽略
            return;
        }
        boolean moveToBottom = false;
        if (previous <= firstVisibleItem) {
            moveToBottom = true;
        }
        previous = firstVisibleItem;
        if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
            isLoading = true;
            footPb.setVisibility(View.VISIBLE);
            page++;
            RequestCommentOpr.commentList(genParams(page), new HttpClient.HttpCallback<List<CommentDO>>() {
                @Override
                public void onSuccess(List<CommentDO> dataList) {
                    isLoading = false;
                    if (CollectionUtil.isEmpty(dataList)) {
                        isMoreData = false;
                        footPb.setVisibility(View.GONE);
                    } else {
                        mDataList.addAll(dataList);
                        commentAdapter.notifyDataSetChanged();
                        footPb.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    isLoading = false;
                    MessageUtils.showToastCenter(error.getMessage());
                    page--;
                    footPb.setVisibility(View.GONE);
                }
            });
        }
    }

    public JSONObject genParams(int page) {
        JSONObject params = new JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", pageSize);
        params.put("offset", page * pageSize);
        params.put("typeList", "2,4");
        return params;
    }


    class CommentInputActionListener implements TextView.OnClickListener {

        @Override
        public void onClick(View v) {

            keyboard.hideSoftInputFromWindow(v.getWindowToken(), 0);
            String content = inputText.getText().toString();

            if (content == null || "".equals(content.trim())) {
                Toast.makeText(context, "请输入内容", Toast.LENGTH_LONG).show();
                return;
            }

            String commentId = null;
            Integer type = 4;             // 默认，普通留言
            if (preHolder != null) {       // 普通回复
                commentId = preHolder.commentId;
                type = 2;
            }
            RequestCommentOpr.addComment(itemId, null, commentId, null, content, null, type, new HttpClient.HttpCallback<CommentDO>() {
                @Override
                public void onSuccess(CommentDO obj) {
                    commentAdapter.addHead(obj);
                    commentAdapter.notifyDataSetChanged();
                    commentList.setVisibility(View.VISIBLE);
                    commentList.setSelection(0);
                    noDataView.setVisibility(View.GONE);
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "发表评论失败");
                }
            });
            inputText.setText(null);    // 清空数据
            inputText.setHint(null);
            preHolder = null;
        }
    }

    class CommentItemOnClickListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
            inputText.setHint(null);
            if (preHolder != null) {
                keyboard.hideSoftInputFromWindow(inputText.getWindowToken(), 0);
                preHolder = null;
            } else {
                CommentAdapter.PJViewHolder curr = (CommentAdapter.PJViewHolder) view.getTag();
                if (curr.type == CommentDO.TYPE_BUY) {
                    //todo 若是卖家，跳转到评论页面
                    Toast.makeText(context, "不允许评论交易订单", Toast.LENGTH_LONG).show();
                } else if (curr.type == CommentDO.TYPE_SELL) {
                    //已完结，不允许回复
                    Toast.makeText(context, "交易评价已完结，不能再评价", Toast.LENGTH_LONG).show();
                } else {
                    inputText.setFocusable(true);
                    inputText.setFocusableInTouchMode(true);
                    inputText.requestFocus();
                    String nick = curr.buyNick.getText().toString();
                    inputText.setHint("回复:" + nick);
                    keyboard.showSoftInput(inputText, InputMethodManager.SHOW_IMPLICIT);
                    preHolder = curr;
                    preItemIndex = position;
                    itemHeight = view.getHeight();
                }
            }
        }
    }


}
