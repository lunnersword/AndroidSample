package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.BaseAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lanbo on 16/4/30.
 */
public abstract class CheckableGridAdapter<T> extends BaseAdapter {
    protected Context mContext;
    protected LayoutInflater mInflater;
    protected List<T> mData;
    protected int lastPosition = -1; // 记录上一次选中的位置，-1表示未选中任何位置
    protected boolean multiChoose; // 表示当前适配器是否允许多选
    protected List<Boolean> mSelected = new ArrayList<Boolean>(); // 定义一个向量作为选中与否容器
    protected List<Integer> mSelectItems = new ArrayList<Integer>();

    public CheckableGridAdapter(Context context, List<T> data, Boolean isMulti) {
        mContext = context;
        mInflater = LayoutInflater.from(context);
        mData = data;
        multiChoose = isMulti;

        for (int i = 0; i < mData.size(); i++)
            mSelected.add(false);
    }

    protected void changeState(int position) {
        if (multiChoose) {
            mSelected.set(position, !mSelected.get(position));
        } else {
            if (lastPosition != -1 && lastPosition != position) {
                mSelected.set(lastPosition, false);
            }
            mSelected.set(position, true);
        }
        lastPosition = position;
    }

    protected boolean isSelected(int position) {
        return mSelected.get(position);
    }

    @Override
    public int getCount() {
        return mData == null ? 0 : mData.size();

    }

    @Override
    public Object getItem(int position) {
        return mData == null ? null : mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

}
