package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SkuCommentAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CommentDO;
import com.meidalife.shz.rest.model.CommentTabOutDO;
import com.meidalife.shz.rest.model.SkuCommentOutDO;
import com.meidalife.shz.rest.request.RequestCommentOpr;
import com.meidalife.shz.util.LoadUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 已合并到TradeAndCommentListActivity.java  后期确认无用可删除此类
 * Created by fufeng on 15/10/23.
 * <p/>
 * update by zuozheng 16/03/14
 */
public class CommentListFragment extends BaseFragment implements SwipeRefreshLayout.OnRefreshListener {
    private static final int PAGE_SIZE = 10;
    private boolean isLoading = false;
    private int currentPage = 0;
    private String itemId;
    private int level;

    @Bind(android.R.id.list)
    ListView mListView;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.emptyView)
    ViewGroup emptyView;
    @Bind(R.id.description)
    TextView description;
    @Bind(R.id.cellStatusErrorServer)
    ViewGroup cellStatusErrorServer;
    @Bind(R.id.cellStatusErrorNetwork)
    ViewGroup cellStatusErrorNetwork;

    private SkuCommentAdapter commentAdapter;
    private List<CommentDO> commentList = new ArrayList<>();
    LoadUtil mLoadUtil;

    View rootView;

    public static CommentListFragment newInstance(String itemId, CommentTabOutDO outDO) {
        CommentListFragment orderListFragment = new CommentListFragment();

        Bundle params = new Bundle();
        params.putString("itemId", itemId);
        params.putInt("level", outDO.getLevel());
        params.putString("count", outDO.getCount());
        params.putString("title", outDO.getTitle());
        orderListFragment.setArguments(params);

        return orderListFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_list, container, false);
        }

        View actionBarView = rootView.findViewById(R.id.action_bar);
        actionBarView.setVisibility(View.GONE);
        ButterKnife.bind(this, rootView);

        mLoadUtil = new LoadUtil(inflater);


        commentAdapter = new SkuCommentAdapter(getActivity(), inflater, commentList);
        mListView.setAdapter(commentAdapter);
        description.setText(R.string.comment_count_none);

        mSwipeRefreshLayout.setOnRefreshListener(this);
        mListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        loadComments(false);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

        itemId = getArguments().getString("itemId");
        level = getArguments().getInt("level");
        return rootView;
    }

    @Override
    public void onResume() {
        loadComments(true);
        super.onResume();
    }

    public void loadComments(boolean reload) {
        if (!Helper.isNetworkConnected(getActivity())) {
            showNetWorkError();
            return;
        }
        if (isLoading) {
            return;
        }

        if (reload) {
            currentPage = 0;
            commentList.clear();

//            mLoadUtil.loadPre((ViewGroup) rootView, mSwipeRefreshLayout);
        }

        isLoading = true;
        JSONObject params = new JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", PAGE_SIZE);
        params.put("offset", currentPage * PAGE_SIZE);
        params.put("typeList", "1");
        //全部类目不设置level
        if (level != -1) {
            params.put("level", level);
        }

        RequestCommentOpr.skuCommentList(params, new HttpClient.HttpCallback<SkuCommentOutDO>() {
            @Override
            public void onSuccess(SkuCommentOutDO outDO) {
                isLoading = false;
                if (getActivity() == null) {
                    return;
                }
                mSwipeRefreshLayout.setRefreshing(false);
//                mLoadUtil.hideStatusLoading();

                commentList.addAll(outDO.getComments());

                if (!commentList.isEmpty()) {
                    commentAdapter.set(commentList);
                    commentAdapter.notifyDataSetChanged();
                    currentPage++;

                    emptyView.setVisibility(View.GONE);
                } else {
                    showEmptyView();
                }
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                mSwipeRefreshLayout.setRefreshing(false);
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showNetWorkError();
                } else {
                    showServerError();
                }
            }
        });
    }

    @Override
    public void onRefresh() {
        loadComments(true);
    }

    private void showNetWorkError() {
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.VISIBLE);
        mSwipeRefreshLayout.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
    }

    private void showServerError() {
        cellStatusErrorServer.setVisibility(View.VISIBLE);
        cellStatusErrorNetwork.setVisibility(View.GONE);
        mSwipeRefreshLayout.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
    }

    private void showEmptyView() {
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.GONE);
        mSwipeRefreshLayout.setVisibility(View.GONE);
        emptyView.setVisibility(View.VISIBLE);
    }
}
