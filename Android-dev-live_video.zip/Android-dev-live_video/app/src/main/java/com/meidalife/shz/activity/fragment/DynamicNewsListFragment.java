package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.DynamicNewsAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicNewsOutDO;
import com.meidalife.shz.util.LoadUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yiyang on 16/5/5.
 */
public class DynamicNewsListFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private static final String TAG_TYPE = "type";

    private LoadUtil mLoadUtil;
    ArrayList<DynamicNewsOutDO> newsList;
    DynamicNewsAdapter adapter;
    private final static int PAGE_SIZE = 20;
    private int page = 0;
    private boolean isLoading;
    private boolean isCompleted;
    private String paramsType;

    private View view;

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.listView)
    ListView listView;
    View emptyView;

    public static DynamicNewsListFragment newInstance(String type) {
        DynamicNewsListFragment fragment = new DynamicNewsListFragment();

        Bundle params = new Bundle();
        params.putString(TAG_TYPE, type);
        fragment.setArguments(params);

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (view == null) {
            view = inflater.inflate(R.layout.fragment_dynamic_news_list, null);
            ButterKnife.bind(this, view);
            paramsType = getArguments().getString(TAG_TYPE);

            mLoadUtil = new LoadUtil(inflater);
            newsList = new ArrayList();
            if (paramsType.equals("comment"))
                adapter = new DynamicNewsAdapter(getActivity(), newsList, DynamicNewsAdapter.MESSAGE_TYPE_COMMENT);
            else if (paramsType.equals("support"))
                adapter = new DynamicNewsAdapter(getActivity(), newsList, DynamicNewsAdapter.MESSAGE_TYPE_SUPPORT);

            emptyView = inflater.inflate(R.layout.empty_layout, null);
            listView.setEmptyView(emptyView);
            listView.setAdapter(adapter);
            bindListener();
            xhrAddresses();
        }
        return view;
    }

    private void bindListener() {
        mSwipeRefreshLayout.setOnRefreshListener(this);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Router.sharedRouter().open("dynamic/" + newsList.get(position).getFeedId());
            }
        });
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView absListView, int scrollState) {
                if (scrollState == SCROLL_STATE_IDLE && listView.getFirstVisiblePosition() == 0
                        && listView.getChildAt(0).getTop() == 0) {
                    mSwipeRefreshLayout.setEnabled(true);
                } else {
                    mSwipeRefreshLayout.setEnabled(false);
                }

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (absListView.getLastVisiblePosition() == absListView.getCount() - 1 && !isCompleted) {
                        xhrAddresses();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }
        });
    }

    private void xhrAddresses() {
        if (isLoading)
            return;
        isLoading = true;
        mLoadUtil.loadPre(rootView, mSwipeRefreshLayout);
        JSONObject params = new JSONObject();
        params.put("offset", page * PAGE_SIZE);
        params.put("pageSize", PAGE_SIZE);
        params.put("name", paramsType);

        //实现翻页
        HttpClient.searchEnv("1.0/user/message", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                String resultData;
                if (!result.containsKey("result"))
                    return;

                resultData = result.getString("result");
                List<DynamicNewsOutDO> dynamicNewsOutDOs = JSON.parseArray(resultData, DynamicNewsOutDO.class);
                listView.setVisibility(View.VISIBLE);
                newsList.addAll(dynamicNewsOutDOs);
                adapter.notifyDataSetChanged();
                mLoadUtil.loadSuccess(mSwipeRefreshLayout);
                mSwipeRefreshLayout.setRefreshing(false);
                if (result.size() < PAGE_SIZE)
                    isCompleted = true;
                page++;
                isLoading = false;
            }

            @Override
            public void onFail(HttpError error) {
                mLoadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        xhrAddresses();
                    }
                });
                mSwipeRefreshLayout.setRefreshing(false);
                isLoading = false;
            }
        });
    }

    @Override
    public void onRefresh() {
        refresh();
    }

    private void refresh() {
        page = 0;
        isCompleted = false;
        newsList.clear();
        xhrAddresses();
    }


}
