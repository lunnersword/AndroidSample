package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ConstellationAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.UserFullDO;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.StrUtil;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.usepropeller.routable.Router;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;

public class AboutMeActivity extends BaseActivity {

    @Bind(R.id.avatar)
    SimpleDraweeView imageAvatar;
    @Bind(R.id.avatariRight)
    TextView avatarRight;

    @Bind(R.id.nicknameArrow)
    TextView nicknameArrow;
    @Bind(R.id.nickname)
    TextView textNick;

    @Bind(R.id.sex)
    TextView sex;
    @Bind(R.id.genderArrow)
    TextView genderArrow;

    @Bind(R.id.city)
    TextView city;
    @Bind(R.id.cityArrow)
    TextView cityArrow;

    @Bind(R.id.phone)
    TextView textPhone;

    @Bind(R.id.constellation)
    TextView constellation;
    @Bind(R.id.constellationRight)
    TextView constellationRight;

    @Bind(R.id.workNumber)
    TextView workNumber;
    @Bind(R.id.workNumberArrow)
    TextView workNumberArrow;


    @Bind(R.id.wxStatus)
    TextView wxStatus;
    @Bind(R.id.weiboStatus)
    TextView weiboStatus;
    @Bind(R.id.qqStatus)
    TextView qqStatus;

    @Bind(R.id.completeLayout)
    View completeLayout;
    @Bind(R.id.completeRate)
    TextView completeRate;
    @Bind(R.id.verify)
    TextView verify;

    String avatarUrl;
    private String cityCode;
    private String cityName;

    //是否实名实证用户
    Boolean isRealUser;

    private ArrayList<HashMap<String, String>> constellationData;
    private int constellationIndex;

    private UMShareAPI mController;

    private ViewGroup rootView;
    private View contentRoot;
    private File cropImage;
    private UserFullDO userFullDO;
    private boolean isRefrsh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_me);
        ButterKnife.bind(this);
        initActionBar(R.string.text_user_info, true);
        hideIMM();

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);

        constellationData = SignUpActivity.getConstellationData(this);

        avatarRight.setTypeface(Helper.sharedHelper().getIconFont());
        nicknameArrow.setTypeface(Helper.sharedHelper().getIconFont());
        genderArrow.setTypeface(Helper.sharedHelper().getIconFont());
        cityArrow.setTypeface(Helper.sharedHelper().getIconFont());
        constellationRight.setTypeface(Helper.sharedHelper().getIconFont());
        workNumberArrow.setTypeface(Helper.sharedHelper().getIconFont());

        mController = UMShareAPI.get(this);

        initListener();
//        放到onStart()中刷新
        xhrProfile();

    }

    @Override
    protected void onStart() {
        super.onStart();
      //  xhrProfile();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(isRefrsh){
            xhrProfile();
            isRefrsh = false;
        }
    }

    private void initListener(){
        completeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AboutMeActivity.this, ProfileCompleteRateActivity.class);
                startActivity(intent);
                isRefrsh = true;
            }
        });
    }

    public void handlePickAvatar(View view) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", false);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, AboutMeActivity.this);
    }

    public void handleNickname(View view) {
        String gender = textNick.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putString("nickname", gender);
        Router.sharedRouter().openFormResult("changeNickname", bundle,
                Constant.REQUEST_CODE_CHANGE_NICKNAME, AboutMeActivity.this);
    }

    public void handleGender(View view) {
        String gender = sex.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putString(Constant.DATA_GENDER, gender);
        bundle.putBoolean("isRealUser", isRealUser);
        Router.sharedRouter().openFormResult("chooseGender", bundle,
                Constant.REQUEST_CODE_CHANGE_GENDER, AboutMeActivity.this);
    }

    public void handleCity(View view) {
        Router.sharedRouter().openFormResult("pick/city", Constant.REQUEST_CODE_PICK_CITY, this);
    }

    public void handleSelectConstellation(final View view) {
        final AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.show();
        view.setEnabled(false);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                view.setEnabled(true);
            }
        });
        int deviceWidth = this.getResources().getDisplayMetrics().widthPixels;
        int deviceHeight = this.getResources().getDisplayMetrics().heightPixels;
        deviceWidth -= deviceWidth / 10;
        deviceHeight /= 2;
        dialog.getWindow().setLayout(deviceWidth, deviceHeight);
        View rootView = getLayoutInflater().inflate(R.layout.view_select_constellation, null);
        dialog.getWindow().setContentView(rootView);
        // init view
        ListView listView = (ListView) rootView.findViewById(R.id.optionConstellation);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                dialog.dismiss();
                constellationIndex = position + 1;
                HashMap<String, String> item = constellationData.get(position);
                constellation.setText(item.get("name"));
                constellation.setVisibility(View.VISIBLE);
                xhrUpdateProfile();
            }
        });
        ConstellationAdapter adapter = new ConstellationAdapter(this, constellationData);
        listView.setAdapter(adapter);
        if (constellationIndex > 0) {
            listView.setItemChecked(constellationIndex - 1, true);
        }
    }

    //处理加V认证
    public void handleVerify(View view){
        if(userFullDO == null)
            return;
        isRefrsh = true;
        Bundle bundle = new Bundle();
        bundle.putInt("type", Constant.TYPE_OFFICIAL);
        bundle.putBoolean("realUser", userFullDO.getRealStatus() == 2);
        if(userFullDO.getVipStatus() == 0){  //未加V认证
            if(userFullDO.getRealStatus() == 2){   //已实名认证
                bundle.putInt("tid", StrUtil.parseIntCleanNull(userFullDO.getVipTid()));
                bundle.putInt("id",StrUtil.parseIntCleanNull(userFullDO.getCertVipId()));
                Router.sharedRouter().open("certify", bundle);
                return;
            }
            bundle.putInt("tid", StrUtil.parseIntCleanNull(userFullDO.getRealTid()));
            bundle.putInt("id", StrUtil.parseIntCleanNull(userFullDO.getCertRealId()));
            if(userFullDO.getRealStatus() == 0){  // 未经过实名认证
                showDialog("请先前往实名认证,才能继续加V认证哦.","certify",bundle);
            }else if(userFullDO.getRealStatus() == 1){  // 实名认证审核中
                showDialog("请等候实名认证结果哦,通过即可继续加V认证哦.","certify",bundle);
            }else if(userFullDO.getRealStatus() == 3){   //实名认证拒绝
                showDialog("未通过实名认证哦,请重新认证.","certify",bundle);
            }
        }else{
            bundle.putInt("tid", StrUtil.parseIntCleanNull(userFullDO.getVipTid()));
            bundle.putInt("id", StrUtil.parseIntCleanNull(userFullDO.getCertVipId()));
            Router.sharedRouter().open("certify", bundle);
        }
    }

    private void showDialog(String tip,final String action,final Bundle bundle){
        MessageUtils.createDialog(AboutMeActivity.this, "提醒", tip, R.string.confirm, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Router.sharedRouter().open(action, bundle);
            }
        }, R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        }).show();
    }


    public void handleWorkNumber(View view) {
        String data = workNumber.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putString("workCellphone", data);
        Router.sharedRouter().openFormResult("workCellphone", bundle,
                Constant.REQUEST_CODE_CHANGE_WORK_NUMBER, AboutMeActivity.this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_PICK_PHOTO && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            ArrayList images = bundle.getStringArrayList("images");
            if (images.size() > 0) {
                avatarUrl = (String) images.get(0);
                Bundle params = new Bundle();
                params.putString("image_path", avatarUrl);
                params.putBoolean("return-data", false);

                cropImage = new File(ImgUtil.getEditedImagePath(this) +
                        File.separator + "cropped_avatar_" + System.currentTimeMillis() + ".jpg");
                params.putParcelable(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cropImage));
                Router.sharedRouter().openFormResult("cropImage", params,
                        Constant.REQUEST_CODE_CROP_PHOTO, AboutMeActivity.this);
            }
        } else if (requestCode == Constant.REQUEST_CODE_CROP_PHOTO && resultCode == RESULT_OK) {
            if (cropImage != null && cropImage.exists()) {
                syncAvatar(cropImage.getAbsolutePath());
                xhrUploadAvatar(cropImage.getAbsolutePath());
            } else {
                syncAvatar(avatarUrl);
                xhrUploadAvatar(avatarUrl);
            }

        } else if (requestCode == Constant.REQUEST_CODE_CHANGE_GENDER && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            String gender = bundle.getString(Constant.DATA_GENDER);
            if (gender != null)
                sex.setText(gender);

        } else if (Constant.REQUEST_CODE_PICK_CITY == requestCode && resultCode == RESULT_OK) {
            Bundle bundle;
            bundle = data.getExtras();
            cityCode = bundle.getString("code");
            cityName = bundle.getString("name");
            xhrUpdateProfile();
        } else if (Constant.REQUEST_CODE_CHANGE_NICKNAME == requestCode && resultCode == RESULT_OK) {
            Bundle bundle;
            bundle = data.getExtras();
            textNick.setText(bundle.getString("nickname"));
            xhrUpdateProfile();
        }
        else if (Constant.REQUEST_CODE_CHANGE_WORK_NUMBER == requestCode && resultCode == RESULT_OK) {
            Bundle bundle;
            bundle = data.getExtras();
            workNumber.setText(bundle.getString("workCellphone"));
        }

        try {
            mController.onActivityResult(requestCode, resultCode, data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void syncAvatar(String path) {
        Uri uri = Uri.fromFile(new File(path));
        imageAvatar.setImageURI(uri);
    }

    private void xhrUploadAvatar(String path) {
        RequestSign.upload(path, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                JSONObject json = (JSONObject) result;
                try {
                    avatarUrl = json.getString("data");
                    xhrUpdateProfile();
                } catch (JSONException e) {
                }
                hideProgressDialog();
                if (cropImage != null && cropImage.exists()) {
                    syncAvatar(cropImage.getAbsolutePath());
                } else {
                    syncAvatar(avatarUrl);
                }

            }

            @Override
            public void onFailure(HttpError error) {
                avatarUrl = null;
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "头像上传失败，请重试");
            }
        });
    }


    private void xhrProfile() {

        loadPre(rootView, contentRoot);
        HttpClient.get("2.0/user/getUserFull", null, UserFullDO.class, new HttpClient.HttpCallback<UserFullDO>() {
            @Override
            public void onSuccess(UserFullDO objDO) {
                loadSuccess(contentRoot);
                userFullDO = objDO;
                //加V认证相关
                if (userFullDO.getVipStatus() == 2) {
                    verify.setText("已认证");
                }else{
                    verify.setText("未认证");
                }
                if (userFullDO.getBase() == null)
                    return;
                UserFullDO.Base obj = userFullDO.getBase();
                if (!TextUtils.isEmpty(obj.getPicUrl())) {
                    ViewGroup.LayoutParams layoutParams = imageAvatar.getLayoutParams();
                    avatarUrl = obj.getPicUrl();
                    String imageUrl = ImgUtil.getCDNUrlWithWidth(avatarUrl, layoutParams.width);
                    //add default avatar
                    if (TextUtils.isEmpty(imageUrl)) {
                        String gender = obj.getGender() == null ? "" : obj.getGender();
                        String userId = Helper.sharedHelper().getUserId();
                        Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(AboutMeActivity.this, userId, gender);
                        imageAvatar.setImageURI(getDefaultAvatarUri);
                    } else {
                        imageAvatar.setImageURI(Uri.parse(imageUrl));
                    }
                }

                textNick.setText(obj.getNick());
                if (obj.getGender() != null) {
                    String gender = obj.getGender();
                    if (Constant.GENDER_MAN.equals(gender)) {
                        sex.setText("男");
                    } else if (Constant.GENDER_WOMAN.equals(gender)) {
                        sex.setText("女");
                    }
                }
                if (obj.getCityName() != null) {
                    city.setText(obj.getCityName());
                }

                if (obj.getCompleteness() != Constant.DO_UNDEFINE_INT_TYPE) {
                    completeLayout.setVisibility(View.VISIBLE);
                    completeRate.setText(obj.getCompleteness() + "%");
                } else
                    completeLayout.setVisibility(View.GONE);

                if (obj.getConstellation() > 0) {
                    constellationIndex = obj.getConstellation();
                    Map<String, String> value = constellationData.get(constellationIndex - 1);
                    constellation.setText(value.get("name"));
                }
                String phone = obj.getMobile();
                textPhone.setText(phone);
                if (obj.getWorkMobile() != null) {
                    workNumber.setText(obj.getWorkMobile());
                } else {
                    workNumber.setText(phone);
                }

                bindStatusToString(wxStatus, TextUtils.isEmpty(obj.getWeixinAccount()), SHARE_MEDIA.WEIXIN);
                bindStatusToString(weiboStatus, TextUtils.isEmpty(obj.getWeiboAccount()), SHARE_MEDIA.SINA);
                bindStatusToString(qqStatus, TextUtils.isEmpty(obj.getQqAccount()), SHARE_MEDIA.QQ);

                isRealUser = obj.isRealUser();

            }

            @Override
            public void onFail(HttpError error) {
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrProfile();
                        }
                    });
                } else if (error.getCode() == HttpError.ERR_CODE_NOT_LOGIN) {
                    finish();
                }
            }
        });

    }

    public void bindStatusToString(TextView view, boolean isEmpty, final SHARE_MEDIA shareMedia){

        if (!isEmpty) {
            view.setBackgroundColor(getResources().getColor(R.color.white));
            view.setTextColor(getResources().getColor(R.color.brand_b));
            view.setText("解绑");
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    unBind(shareMedia, (TextView)v);
                }
            });
        } else {
            view.setBackgroundResource(R.drawable.about_me_button);
            view.setTextColor(getResources().getColor(R.color.white));
            view.setText("绑定");
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    bind(shareMedia, v);
                }
            });
        }
    }

    private void xhrUpdateProfile() {
        try {
            JSONObject params = new JSONObject();
            if (avatarUrl != null) {
                params.put("picUrl", avatarUrl);
            //    params.put("backgroundUrl", avatarUrl);
            }

          //  params.put("instruction", textDescription.getText().toString());
            if (constellationIndex > 0) {
                params.put("constellation", constellationIndex);
            }

            if(!TextUtils.isEmpty(cityCode)){
                params.put("cityCode",cityCode);
            }

            showProgressDialog("正在保存");
            RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter("保存成功");
//                    finish();
                    Helper.sharedHelper().setStringUserInfo("nick", textNick.getText().toString());
                    if (avatarUrl != null) {
                        Helper.sharedHelper().setStringUserInfo("picUrl", avatarUrl);
                    }
//                    if(!TextUtils.isEmpty(cityName))
//                        city.setText(cityName);
                    xhrProfile();
                }

                @Override
                public void onFailure(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败");
                }
            });
        } catch (JSONException e) {
        }
    }

    public void unBind(final SHARE_MEDIA shareMedia,final TextView view){
        showProgressDialog("正在解绑");
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        int type = 0;
        if(shareMedia == SHARE_MEDIA.WEIXIN){
            type = 1;
        }else if(shareMedia == SHARE_MEDIA.QQ){
            type = 2;
        }else if(shareMedia == SHARE_MEDIA.SINA){
            type = 3;
        }
        params.put("type",type);
        HttpClient.get("1.0/user/unbind", params, com.alibaba.fastjson.JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                hideProgressDialog();
                view.setBackgroundResource(R.drawable.about_me_button);
                view.setTextColor(getResources().getColor(R.color.white));
                view.setText("绑定");
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        bind(shareMedia, v);
                    }
                });
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "解绑失败，请稍后再试");
            }
        });
    }

    public void bind(SHARE_MEDIA shareMedia, View view) {
        oAuth(shareMedia, (TextView) view);
    }

    public void oAuth(final SHARE_MEDIA shareMedia, final TextView view) {

        showProgressDialog("正在请求授权", false);
        mController.doOauthVerify(AboutMeActivity.this, shareMedia, new UMAuthListener() {
            @Override
            public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
                showProgressDialog("授权成功，绑定中...");
                StringBuffer logBuffer = new StringBuffer();

                JSONObject params = new JSONObject();
                try {
                    if (shareMedia == SHARE_MEDIA.WEIXIN) {
                        params.put("weixinAccount", data.get("openid"));
                    } else if (shareMedia == SHARE_MEDIA.SINA) {
                        params.put("weiboAccount", data.get("uid"));
                    } else if (shareMedia == SHARE_MEDIA.QQ) {
                        params.put("qqAccount", data.get("openid"));
                    }
                    RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
                        @Override
                        public void onSuccess(Object result) {
                            hideProgressDialog();
                            view.setBackgroundColor(getResources().getColor(R.color.white));
                            view.setTextColor(getResources().getColor(R.color.grey_c));
                            view.setText("已绑定");
                        }

                        @Override
                        public void onFailure(HttpError error) {
                            hideProgressDialog();
                            MessageUtils.showToastCenter(error != null ? error.getMessage() : "绑定失败");
                        }
                    });
                } catch (Exception e) {
                    Log.e(AboutMeActivity.class.getName(), "bind third account fail", e);
                    MessageUtils.showToastCenter(getString(R.string.error_server_500));
                }
            }

            @Override
            public void onError(SHARE_MEDIA platform, int action, Throwable t) {
                hideProgressDialog();
                MessageUtils.showToastCenter("授权失败");
            }

            @Override
            public void onCancel(SHARE_MEDIA platform, int action) {
                MessageUtils.showToastCenter("授权取消");
            }
        });
    }


}
