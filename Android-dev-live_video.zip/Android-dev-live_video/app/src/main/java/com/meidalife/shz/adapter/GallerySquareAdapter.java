package com.meidalife.shz.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.net.Uri;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.facebook.common.util.UriUtil;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.model.SquareCateDO;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.rest.model.SquareDynamicDO;
import com.meidalife.shz.rest.model.UserDO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.IconTextView;
import com.meidalife.shz.widget.SquareDividerItemDecoration;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 15/12/22.
 * 我加入的格子list对应adapter
 */
public class GallerySquareAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    LayoutInflater mInflater;
    Context mContext;
    List<SquareDO> mData;

    private final int userAvatarMaxSize = 10;
    private final int serviceMaxSize = 3;
    private final int dynamicMaxSize = 2;

    private boolean isFirst = true;

    private int joinedSquareCount = 0;

    static enum ITEM_TYPE {
        ITEM_TYPE_GEZHU, ITEM_TYPE_NORMAL, ITEM_TYPE_MORE
    }


    static class NormalViewHolder extends RecyclerView.ViewHolder {
        public NormalViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.rootView)
        View rootView;

        @Bind(R.id.join_status)
        ImageView join_status;

        @Bind(R.id.squareNme)
        TextView squareNme;
        @Bind(R.id.squareType)
        TextView squareType;

        //服务数
        @Bind(R.id.serviceCount)
        TextView serviceCount;
        @Bind(R.id.serviceCountDynamic)
        View serviceCountDynamic;
        @Bind(R.id.squareServiceIncCount)
        TextView squareServiceIncCount;
        @Bind(R.id.squareServiceIncStatus)
        IconTextView squareServiceIncStatus;
        //人气
        @Bind(R.id.squarePopular)
        TextView squarePopular;

        //人数
        @Bind(R.id.userCount)
        TextView userCount;
        @Bind(R.id.userCountDynamic)
        View userCountDynamic;
        @Bind(R.id.userIncCount)
        TextView userIncCount;
        @Bind(R.id.squareUserCountIncStatus)
        IconTextView squareUserCountIncStatus;

        //成员头像列表

        @Bind(R.id.avatar_recycler_view)
        RecyclerView recyclerView;


        @Bind(R.id.service_recycler_view)
        RecyclerView serviceRecyclerView;

        //格子动态
        @Bind(R.id.dynamicListView)
        ListView dynamicListView;

    }

    static class TipViewHolder extends RecyclerView.ViewHolder {
        public TipViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.rootView)
        View rootView;

        @Bind(R.id.squareNme)
        TextView squareNme;
        @Bind(R.id.squareType)
        TextView squareType;

        @Bind(R.id.imageAvatar)
        SimpleDraweeView imageAvatar;

        @Bind(R.id.userNick)
        TextView userNick;

        //格子动态
        @Bind(R.id.tipListView)
        ListView tipListView;

    }

    static class MoreViewHolder extends RecyclerView.ViewHolder {
        public MoreViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.rootView)
        View rootView;

        @Bind(R.id.squareCountView)
        TextView squareCountView;

    }

    public GallerySquareAdapter(Context context, List<SquareDO> data, int joinedSquareCount) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
        this.joinedSquareCount = joinedSquareCount;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder holder;
        final View convertView;
        if (viewType == ITEM_TYPE.ITEM_TYPE_GEZHU.ordinal()) {
            convertView = mInflater.inflate(R.layout.item_square_gezhu, parent, false);
            holder = new TipViewHolder(convertView);
        } else if (viewType == ITEM_TYPE.ITEM_TYPE_MORE.ordinal()) {
            convertView = mInflater.inflate(R.layout.item_square_more, parent, false);
            holder = new MoreViewHolder(convertView);
        } else {
            convertView = mInflater.inflate(R.layout.item_square, parent, false);
            holder = new NormalViewHolder(convertView);
        }

        //计算多图每栏宽度
        Activity activity = (Activity) mContext;
        Display display = activity.getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        float margin = Helper.convertDpToPixel(20, mContext);

        width -= margin * 3;
        convertView.getLayoutParams().width = width;

        if (holder instanceof NormalViewHolder) {
            final LinearLayoutManager layoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);
            ((NormalViewHolder) holder).serviceRecyclerView.setLayoutManager(layoutManager);

            int spacingInPixels = mContext.getResources().getDimensionPixelSize(R.dimen.margin_10);
            ((NormalViewHolder) holder).serviceRecyclerView.addItemDecoration(new SquareDividerItemDecoration(spacingInPixels));
        }

        return holder;
    }

    @Override
    public int getItemViewType(int position) {
        if (joinedSquareCount > 5 && position > 4) {
            return ITEM_TYPE.ITEM_TYPE_MORE.ordinal();
        }
        return mData.get(position).isShowTips() ? ITEM_TYPE.ITEM_TYPE_GEZHU.ordinal() : ITEM_TYPE.ITEM_TYPE_NORMAL.ordinal();
    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder myHolder, int position) {

        final SquareDO item = mData.get(position);
        if (myHolder instanceof NormalViewHolder) {
            NormalViewHolder holder = (NormalViewHolder) myHolder;
            holder.squareNme.setText(item.getGeziName());
            holder.squareType.setText("[" + item.getGeziTypeDesc() + "]");
            holder.serviceCount.setText("服务数：" + item.getItemCount());
            holder.squareServiceIncCount.setText("(" + item.getItemCountIncrement());

            //
            if (item.isGezhu()) {
                holder.join_status.setImageDrawable(mContext.getResources().getDrawable(R.mipmap.square_status_gezhu));
            } else {
                holder.join_status.setImageDrawable(mContext.getResources().getDrawable(R.mipmap.square_status_joined));
            }

            if (item.getItemCountIncrement() > 0) {
                holder.serviceCountDynamic.setVisibility(View.VISIBLE);
            } else {
                holder.serviceCountDynamic.setVisibility(View.GONE);
            }

            if (item.getItemCountArrow() == 1) {
                holder.squareServiceIncStatus.setText(mContext.getResources().getString(R.string.icon_increase));
            } else if (item.getItemCountArrow() == -1) {
                holder.squareServiceIncStatus.setText(mContext.getResources().getString(R.string.icon_decrease));
            } else {
                holder.squareServiceIncStatus.setText("");
            }

            holder.squarePopular.setText("人   气：" + item.getPopularity());
            holder.userCount.setText("成   员：" + item.getUserCount());
            holder.userIncCount.setText("(" + item.getUserCountIncrement());

            if (item.getUserCountArrow() == 1) {
                holder.squareUserCountIncStatus.setText(mContext.getResources().getString(R.string.icon_increase));
            } else if (item.getUserCountArrow() == -1) {
                holder.squareUserCountIncStatus.setText(mContext.getResources().getString(R.string.icon_decrease));
            } else {
                holder.squareUserCountIncStatus.setText("");
            }

            if (item.getUserCountIncrement() > 0) {
                holder.userCountDynamic.setVisibility(View.VISIBLE);
            } else {
                holder.userCountDynamic.setVisibility(View.GONE);
            }

            //设置头像
            showUserAvatar(holder.recyclerView, item.getUserList());

            //服务
            showCategories(holder.serviceRecyclerView, item.getCategoryList());

            //
            showDynamic(holder.dynamicListView, item.getDynamicList());

            holder.recyclerView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("squareindex/" + item.getGeziId());
                }
            });
            holder.serviceRecyclerView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("squareindex/" + item.getGeziId());
                }
            });
            holder.dynamicListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Router.sharedRouter().open("squareindex/" + item.getGeziId());
                }

            });

            holder.rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("squareindex/" + item.getGeziId());

                    try {
                        LogParam param = new LogParam();
                        param.setType(LogUtil.TYPE_CUSTOMIZE);
                        param.setEid(LogUtil.EVENT_ID_SQUARE_HOME_ITEM_CLICK);
                        param.setGeziid(String.valueOf(item.getGeziId()));
                        LogUtil.log(param);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        } else if (myHolder instanceof TipViewHolder) {
            TipViewHolder holder = (TipViewHolder) myHolder;
            holder.squareNme.setText(item.getGeziName());
            holder.squareType.setText("[" + item.getGeziTypeDesc() + "]");

            UserDO gezhu = item.getGezhu();
            if (gezhu == null ||
                    TextUtils.isEmpty(gezhu.getUserPicUrl()) ||
                    TextUtils.isEmpty(ImgUtil.getCDNUrlWithWidth(gezhu.getUserPicUrl(), holder.imageAvatar.getLayoutParams().width))) {
                Uri uri = new Uri.Builder()
                        .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.avatar)).build();
                holder.imageAvatar.setImageURI(uri);
            } else {
                holder.imageAvatar.setImageURI(Uri.parse(ImgUtil.getCDNUrlWithWidth(gezhu.getUserPicUrl(), holder.imageAvatar.getLayoutParams().width)));
            }

            if (gezhu != null) {
                holder.userNick.setText(gezhu.getUserNick());
            } else {
                holder.userNick.setText("");
            }

            if (item.getTips() == null || item.getTips().size() <= 0) {
                List tips = new ArrayList();
                tips.add(new String("格子成员超过5人"));
                tips.add(new String("格子内服务数超过10个"));
                tips.add(new String("汇生活信息超过5条"));
                item.setTips(tips);
            }

            SquareGezhuTipAdapter qualifyAdapter = new SquareGezhuTipAdapter(mContext, item.getTips());
            holder.tipListView.setAdapter(qualifyAdapter);
            holder.tipListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    jumpToGeZi(item.getGeziId());
                }
            });

            holder.rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    jumpToGeZi(item.getGeziId());
                }
            });

        } else if (myHolder instanceof MoreViewHolder) {
            MoreViewHolder holder = (MoreViewHolder) myHolder;
            holder.squareCountView.setText("共" + joinedSquareCount + "个");
            holder.rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("mysquares", mContext);
                }
            });
        }
    }

    void jumpToGeZi(long geziId) {
        Router.sharedRouter().open("squareindex/" + geziId);
        try {
            LogParam param = new LogParam();
            param.setType(LogUtil.TYPE_CUSTOMIZE);
            param.setEid(LogUtil.EVENT_ID_SQUARE_HOME_ITEM_CLICK);
            param.setGeziid(String.valueOf(geziId));
            LogUtil.log(param);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void showUserAvatar(RecyclerView recyclerView, List<UserDO> dataList) {

        recyclerView.removeAllViews();
        if (CollectionUtil.isEmpty(dataList)) {
            recyclerView.setVisibility(View.GONE);
            return;
        }
        recyclerView.setVisibility(View.VISIBLE);

        recyclerView.setHasFixedSize(true);

        final LinearLayoutManager layoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

        int end = Math.min(userAvatarMaxSize, dataList.size());
        dataList = dataList.subList(0, end);

        recyclerView.setAdapter(new UserAvatarAdapter(mContext, dataList));
    }

    void showCategories(RecyclerView recyclerView, List<SquareCateDO> dataList) {

        recyclerView.removeAllViews();
        if (CollectionUtil.isEmpty(dataList)) {

            int margin = (int) Helper.convertDpToPixel(10, mContext);
            recyclerView.getLayoutParams().height = margin;
            recyclerView.setVisibility(View.INVISIBLE);
            return;
        }

        int end = Math.min(serviceMaxSize, dataList.size());
        dataList = dataList.subList(0, end);

        recyclerView.setVisibility(View.VISIBLE);
        recyclerView.setHasFixedSize(true);

//        int spanCount = 1; // 只显示一行
//        final LinearLayoutManager layoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);
//        recyclerView.setLayoutManager(layoutManager);

//        if (isFirst) {
//        int spacingInPixels = mContext.getResources().getDimensionPixelSize(R.dimen.margin_10);
//        recyclerView.addItemDecoration(new SquareDividerItemDecoration(spacingInPixels));
//            isFirst = false;
//        }

        recyclerView.setAdapter(new SquareServiceAdapter(mContext, dataList));
    }


    void showDynamic(ListView viewGroup, List<SquareDynamicDO> dataList) {
//        viewGroup.removeAllViews();

        if (dataList == null || dataList.size() <= 0) {
            viewGroup.setVisibility(View.INVISIBLE);
            return;
        }
        viewGroup.setVisibility(View.VISIBLE);

        int end = Math.min(dynamicMaxSize, dataList.size());
        dataList = dataList.subList(0, end);

        viewGroup.setAdapter(new SquareDynamicAdapter(mContext, dataList));
    }

}
