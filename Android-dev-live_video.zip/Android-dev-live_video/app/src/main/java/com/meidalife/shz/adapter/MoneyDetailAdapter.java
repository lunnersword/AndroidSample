package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.MoneyCoinDetailActivity;
import com.meidalife.shz.rest.model.MoneyDetailDO;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by shijian on 15/7/8.
 */
public class MoneyDetailAdapter extends BaseAdapter {

    private LayoutInflater inflater;
    private Context context;
    private List<MoneyDetailDO> dataList = new ArrayList<>();
    private String type;

    private NumberFormat formatter = new DecimalFormat("#0.00");


    public MoneyDetailAdapter(LayoutInflater inflater, List<MoneyDetailDO> dataList, String type) {
        this.inflater = inflater;
        this.context = inflater.getContext();
        this.dataList = dataList;
        this.type = type;
    }

    public void setDataList(List<MoneyDetailDO> dataList) {
        this.dataList = dataList;
    }

    public void add(List<MoneyDetailDO> newdata) {
        this.dataList.addAll(newdata);
    }


    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        MoneyDetailHolder holder = null;

        if (convertView == null) {
            View v = inflater.inflate(R.layout.money_coin_detail_item, null);
            holder = new MoneyDetailHolder();
            holder.title = (TextView) v.findViewById(R.id.detail_title);
            holder.price = (TextView) v.findViewById(R.id.detail_price);
            holder.restPrice = (TextView) v.findViewById(R.id.detail_rest_price);
            holder.time = (TextView) v.findViewById(R.id.detail_time);
            convertView = v;
            convertView.setTag(holder);
        } else {
            holder = (MoneyDetailHolder) convertView.getTag();
        }

        String unit = "元";
        if (MoneyCoinDetailActivity.COIN_TYPE.equals(type)) {
            unit = "个";
        }

        MoneyDetailDO detail = dataList.get(position);
        holder.title.setText(detail.getComment());
        if (detail.getFundNum() > 0) {
            holder.price.setTextColor(context.getResources().getColor(R.color.brand_h));
            holder.price.setText("+" + formatter.format(detail.getFundNum()) + unit);
        } else {
            holder.price.setTextColor(context.getResources().getColor(R.color.brand_b));
            holder.price.setText(formatter.format(detail.getFundNum()) + unit);
        }
        holder.restPrice.setText(formatter.format(detail.getFundSum()) + unit);
        holder.time.setText(detail.getFundDate());

        return convertView;
    }

    public class MoneyDetailHolder {
        public TextView title;
        public TextView price;
        public TextView restPrice;
        public TextView time;
    }


}
