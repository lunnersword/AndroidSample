package com.meidalife.shz.activity;

public interface AttentionListener {

//    public void cancelFollowClick(String userId, int position);

    public void addFollowClick(String userId, int position);
}