package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ProfileCommentGridAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CommentByServerDO;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.view.FlowLayout;
import com.usepropeller.routable.Router;


import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by shijian on 15/7/17.
 * 订单评价列表
 *
 */
public class OrderCommentListActivity extends BaseActivity {

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    View contentView;

    @Bind(R.id.userAvatar)
    SimpleDraweeView userAvatar;
    @Bind(R.id.iconGender)
    TextView iconGender;
    @Bind(R.id.userNick)
    TextView userNick;
    @Bind(R.id.jobIcon)
    SimpleDraweeView jobIcon;
    @Bind(R.id.jobName)
    TextView jobName;
    @Bind(R.id.jobTitle)
    TextView jobTitle;
    @Bind(R.id.commentTime)
    TextView commentTime;
    @Bind(R.id.title)
    TextView title;
    @Bind(R.id.commentContent)
    TextView commentContent;
    @Bind(R.id.tagLayout)
    FlowLayout tagLayout;
    @Bind(R.id.commentStarGroup)
    LinearLayout commentStarGroup;
    @Bind(R.id.imageList)
    GridView imageList;

    @Bind(R.id.replyLayout)
    View replyLayout;
    @Bind(R.id.replyAvatar)
    SimpleDraweeView replyAvatar;
    @Bind(R.id.replyNick)
    TextView replyNick;
    @Bind(R.id.replyStarGroup)
    LinearLayout replyStarGroup;
    @Bind(R.id.replyContent)
    TextView replyContent;
    @Bind(R.id.replyImageList)
    GridView replyImageList;


    private String orderNum;
    private LoadUtil loadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_comment_list);

        ButterKnife.bind(this);
        initActionBar(R.string.tab_title_comment, true);

        Bundle extras = getIntent().getExtras();
        if (extras.get("orderNum") != null) {
            orderNum = extras.getString("orderNum");
        }
        loadUtil = new LoadUtil(LayoutInflater.from(this));
        initLoadData();
    }

    public void initLoadData() {

        loadUtil.loadPre(rootView, contentView);

        JSONObject params = new JSONObject();

        if (!StrUtil.isEmpty(orderNum)) {
            params.put("orderNumber", orderNum);
            HttpClient.get("1.1/comment/getCommentByOrder", params, CommentByServerDO.class, new HttpClient.HttpCallback<CommentByServerDO>() {
                @Override
                public void onSuccess(final CommentByServerDO obj) {
                    loadUtil.loadSuccess(contentView);

                    handlerCommentData(obj);
                    if (obj.getReply() != null) {
                        handlerReplyData(obj.getReply());
                    } else
                        replyLayout.setVisibility(View.GONE);

                    if (obj.getCanModify() == 0) {  //可修改评论
                        showActionBarRightButton();
                        mButtonRight.setText(R.string.btn_change_address);
                        mButtonRight.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Helper.sharedHelper().hasToken()) {
                                    Router.sharedRouter().open("orderJudge/" + CommentActivity.COMMENT_UPDATE_TYPE + "/" + orderNum);
                                    finish();
                                } else
                                    Router.sharedRouter().open("signin");
                            }
                        });
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    loadUtil.loadFail(error, rootView, new LoadUtil.Callback() {
                        @Override
                        public void retry() {
                            initLoadData();
                        }
                    });
                }
            });

        }
    }

    private void handlerCommentData(CommentByServerDO item) {
        if (item == null)
            return;
        title.setText("[" + item.getTitle() + "]");
        userAvatar.setImageURI(Uri.parse(item.getUser().getAvatar()));
        // 设置性别
        if (item.getUser().getUserGender() != null) {
            iconGender.setVisibility(View.VISIBLE);
            if (item.getUser().getUserGender().equals("woman") || item.getUser().getUserGender().equals("F")) {
                iconGender.setText(getResources().getString(R.string.icon_gender_f));
            } else {
                iconGender.setText(getResources().getString(R.string.icon_gender_m));
            }
        } else {
            iconGender.setVisibility(View.GONE);
        }
        //设置标签
        if (item.getTags() != null && item.getTags().size() != 0) {
            tagLayout.setVisibility(View.VISIBLE);
            initTag(tagLayout, item.getTags());
        } else
            tagLayout.setVisibility(View.GONE);
        userNick.setText(item.getUser().getUserNick());
        if (item.getUser().getJobs() != null && item.getUser().getJobs().size() != 0) {
            jobName.setVisibility(View.VISIBLE);
            jobIcon.setVisibility(View.VISIBLE);
            jobName.setText(item.getUser().getJobs().get(0).getTitle());
            if (item.getUser().getJobs().get(0).getIconUrl() != null)
                jobIcon.setImageURI(Uri.parse(item.getUser().getJobs().get(0).getIconUrl()));
        } else {
            jobName.setVisibility(View.GONE);
            jobIcon.setVisibility(View.GONE);
        }
        if (item.getUser().getJobTitle() != null) {
            jobTitle.setVisibility(View.VISIBLE);
            jobTitle.setText(item.getUser().getJobTitle());
        } else
            jobTitle.setVisibility(View.GONE);
        commentTime.setText(DateUtils.profileCommentTime(System.currentTimeMillis(), item.getCreateTime() * 1000));
        if (item.getComment() != null) {
            commentContent.setVisibility(View.VISIBLE);
            commentContent.setText(item.getComment());
        } else
            commentContent.setVisibility(View.GONE);

        //评论星级
        View starsView = LayoutInflater.from(this).inflate(R.layout.view_grade_stars, commentStarGroup, false);
        ViewGroup starsRed = (ViewGroup) starsView.findViewById(R.id.star_red_group);
        ViewGroup starsGrey = (ViewGroup) starsView.findViewById(R.id.star_grey_group);
        for (int i = 0; i < 5; i++) {
            TextView iconTextView = (TextView) starsRed.getChildAt(i);
            iconTextView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);

            TextView iconTextView1 = (TextView) starsGrey.getChildAt(i);
            iconTextView1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
        }
        starsRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(14 * 5, this) * item.getLevel() / 5);
        commentStarGroup.removeAllViews();
        commentStarGroup.addView(starsView);

        //评论图片
        if (item.getImages() != null && item.getImages().size() != 0) {
//            imageList.setVisibility(View.VISIBLE);
//            ArrayList<String> showImgList = new ArrayList<>();
//            if (item.getImages().size() > 0) {
//                int endIndex = Math.min(4, item.getImages().size());
//                for (int i = 0; i < endIndex; i++) {
//                    showImgList.add(item.getImages().get(i));
//                }
//            }
            imageList.setAdapter(new ProfileCommentGridAdapter(this, item.getImages()));
        } else {
            imageList.setVisibility(View.GONE);
        }
    }

    private void handlerReplyData(CommentByServerDO.Reply reply) {
        replyLayout.setVisibility(View.VISIBLE);
        replyAvatar.setImageURI(Uri.parse(reply.getUser().getAvatar()));
        replyNick.setText(reply.getUser().getUserNick() + "回复");
        // 回复星级
        View starsReplyView = LayoutInflater.from(this).inflate(R.layout.view_grade_stars, replyStarGroup, false);
        ViewGroup starsReplyRed = (ViewGroup) starsReplyView.findViewById(R.id.star_red_group);
        ViewGroup starsReplyGrey = (ViewGroup) starsReplyView.findViewById(R.id.star_grey_group);
        for (int i = 0; i < 5; i++) {
            TextView iconTextView = (TextView) starsReplyRed.getChildAt(i);
            iconTextView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);

            TextView iconTextView1 = (TextView) starsReplyGrey.getChildAt(i);
            iconTextView1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
        }
        starsReplyRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(14 * 5, this) * reply.getLevel() / 5);
        replyStarGroup.removeAllViews();
        replyStarGroup.addView(starsReplyView);

        replyContent.setText(reply.getComment());

        //回复图片
        if (reply.getReplyImgUrl() != null && reply.getReplyImgUrl().size() != 0) {
//            replyImageList.setVisibility(View.VISIBLE);
//            ArrayList<String> showImgList = new ArrayList<>();
//            if (reply.getReplyImgUrl().size() > 0) {
//                int endIndex = Math.min(4, reply.getReplyImgUrl().size());
//                for (int i = 0; i < endIndex; i++) {
//                    showImgList.add(reply.getReplyImgUrl().get(i));
//                }
//            }
            replyImageList.setAdapter(new ProfileCommentGridAdapter(this, reply.getReplyImgUrl()));
        } else {
            replyImageList.setVisibility(View.GONE);
        }
    }

    private void initTag(FlowLayout tagLayout, List<CommentByServerDO.Tag> tags) {
        tagLayout.removeAllViews();
        if (tags.size() > 0) {
            for (CommentByServerDO.Tag tag : tags) {
                if (TextUtils.isEmpty(tag.getTagName()))
                    break;
                TextView itemView = (TextView) LayoutInflater.from(this).inflate(R.layout.item_comment_tag, tagLayout, false);
                itemView.setText(String.format(getString(R.string.text_comment_tag), tag.getTagName().trim()));
                tagLayout.addView(itemView);
            }
        }
    }

}
