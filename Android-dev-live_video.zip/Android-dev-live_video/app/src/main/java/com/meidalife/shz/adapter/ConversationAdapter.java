package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.github.curioustechizen.ago.RelativeTimeTextView;
import com.meidalife.shz.R;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.im.Conversation;
import com.meidalife.shz.im.constants.ImConstants;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/4/9.
 */
public class ConversationAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    List<Conversation> mData;

    public ConversationAdapter(Context context, List<Conversation> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    public void add(List<Conversation> list) {
        this.mData.addAll(list);
    }

    public void remove(int position) {
        this.mData.remove(position);
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        Conversation conversation = mData.get(position);
        ConversationHolder viewHolder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.message_list_item, parent, false);
            viewHolder = new ConversationHolder(convertView);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ConversationHolder) convertView.getTag();
        }
        //2为保留ID，表示粉丝关注
        if (conversation.getRemoteId() == ImConstants.ATTENTION_REMOTE_ID) {
            viewHolder.conversationDescLayout.setVisibility(View.GONE);
        } else {
            viewHolder.conversationDescLayout.setVisibility(View.VISIBLE);
            if (TextUtils.isEmpty(conversation.getDraftMessage())) {
                viewHolder.messagePrefix.setVisibility(View.GONE);
                viewHolder.content.setText(ChatHelper.getInstance().getExpressionSpanText(conversation.getLastMessage(), 16));
            } else {
                viewHolder.messagePrefix.setVisibility(View.VISIBLE);
                viewHolder.content.setText(ChatHelper.getInstance().getExpressionSpanText(conversation.getDraftMessage(), 16));
            }
        }

        viewHolder.time.setReferenceTime(conversation.getTimestamp());
        if (!TextUtils.isEmpty(conversation.getRemoteAvatar())) {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(conversation.getRemoteAvatar(), viewHolder.avatar.getLayoutParams().width));
            viewHolder.avatar.setImageURI(uri);
        } else {
            viewHolder.avatar.setImageURI(ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(conversation.getRemoteId()), null));
        }

        viewHolder.title.setText(conversation.getRemoteNick());

        if (conversation.getUnreadMessageCount() > 0) {
            if (conversation.getUnreadMessageCount() < 100) {
                viewHolder.badge.setText(String.valueOf(conversation.getUnreadMessageCount()));
            } else {
                viewHolder.badge.setText("99+");
            }
            viewHolder.badge.setVisibility(View.VISIBLE);
        } else {
            viewHolder.badge.setVisibility(View.GONE);
        }

        return convertView;
    }

    public class ConversationHolder {
        @Bind(R.id.message_item_usr_avatar)
        ImageView avatar;
        @Bind(R.id.message_item_title)
        TextView title;
        @Bind(R.id.message_prefix)
        TextView messagePrefix;
        @Bind(R.id.message_item_content)
        TextView content;
        @Bind(R.id.message_item_time)
        RelativeTimeTextView time;
        @Bind(R.id.badge_with_number)
        TextView badge;
        @Bind(R.id.conversationDescLayout)
        ViewGroup conversationDescLayout;

        public ConversationHolder(View itemView) {
            ButterKnife.bind(this, itemView);
        }
    }
}
