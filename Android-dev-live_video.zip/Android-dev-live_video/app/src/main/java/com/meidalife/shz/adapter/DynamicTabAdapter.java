package com.meidalife.shz.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.DynamicTabDO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ConvertToUtils;

import java.util.ArrayList;


/**
 * Created by zuozheng on 16/3/31.
 * 动态tab导航
 */
public class DynamicTabAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private ArrayList<DynamicTabDO> tabList;

    Context mContext;

    int itemWidth;

    public DynamicTabAdapter(Context mContext, ArrayList<DynamicTabDO> tabList) {
        this.mInflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
        this.tabList = tabList;
        this.mContext = mContext;

        Activity activity = (Activity) mContext;
        Display display = activity.getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        itemWidth = size.x;
        if (CollectionUtil.isNotEmpty(tabList)) {
//            itemWidth -= Helper.convertDpToPixel(10, mContext) * (tabList.size() - 1);
            itemWidth = itemWidth / tabList.size();
        }
    }

    @Override
    public int getCount() {
        return tabList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        DynamicTabDO cate = tabList.get(position);
        if (convertView == null) {
            //todo 需要使用相对布局 实现小红点更新逻辑
            convertView = mInflater.inflate(R.layout.item_dynamic_tab, parent, false);
            holder = new ViewHolder();
            holder.filterTab = (TextView) convertView.findViewById(R.id.filterTab);
            holder.unReadView = convertView.findViewById(R.id.badge);

            convertView.setLayoutParams(new GridView.LayoutParams(itemWidth, ConvertToUtils.dip2px(mContext, 44)));

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.filterTab.setText(cate.getTabName());
        if (cate.isSelected()) {
            holder.filterTab.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.bind_service_bottom));
        } else {
            holder.filterTab.setBackgroundColor(mContext.getResources().getColor(R.color.white));
        }

        holder.unReadView.setVisibility(cate.getCount() > 0 ? View.VISIBLE : View.GONE);

        return convertView;
    }

    static class ViewHolder {
        TextView filterTab;
        View unReadView;
    }
}
