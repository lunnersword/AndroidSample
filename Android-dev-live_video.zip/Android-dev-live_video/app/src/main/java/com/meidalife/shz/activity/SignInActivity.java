package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.media.Image;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import com.meidalife.shz.BuildConfig;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.im.AuthManager;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.im.ImClient;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.BitmapVagueUtil;
import com.meidalife.shz.view.FontButton;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.usepropeller.routable.Router;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;

public class SignInActivity extends BaseActivity {
    private static final String LOG_TAG = "SignInActivity";
    private String STRING_SIGN_IN_ERROR = "登录失败，请重试";
    private String STRING_OAUTH_ERROR = "授权失败";
    private String STRING_OAUTH_START = "正在请求授权";
    private String STRING_OAUTH_INFO = "正在获取个人资料";
    private String STRING_SMS_CODE_RETRY = "重新获取";
    private int MOBILE_PHONE_LENGTH = 11;
    private int SMS_CODE_LENGTH = 4;
    private int LOGIN_TYPE_MOBILE = 1;
    private int LOGIN_TYPE_OAUTH = 2;
    private int LOGIN_TYPE_BIND = 3;
    private String action;

    @Bind(R.id.redPaperTipsLayout)
    ViewGroup redPaperTipsLayout;
    @Bind(R.id.redPaperTips)
    TextView redPaperTips;
    @Bind(R.id.photoNumber)
    EditText phoneView;
    @Bind(R.id.smsCode)
    EditText codeView;

    @Bind(R.id.btnGetSmsCode)
    FontButton btnGetSmsCode;

    //试试语音验证码 隐藏和显示区域
    @Bind(R.id.voiceCodeLL)
    View voiceCodeLL;
    //试试语音验证码 点击区域
    @Bind(R.id.voiceCode)
    View voiceCode;

    @Bind(R.id.voiceCodeTips)
    TextView voiceCodeTips;

    @Bind(R.id.btnSignIn)
    Button btnSignIn;
    @Bind(R.id.cellQuickSignInLabel)
    View cellQuickSignInLabel;
    @Bind(R.id.cellQuickSignInPanel)
    RelativeLayout cellQuickSignInPanel;
    @Bind(R.id.myVideoView)
    VideoView myVideoView;
    @Bind(R.id.backgroundView)
    ImageView backgroundView;
    @Bind(R.id.bindPhoneTipView)
    View bindPhoneTipView;


    private boolean isBind;
    int accountType;
    String account;

    String redpackIds;
    boolean isRedpackExist;
    String totalRedpackMoney;

    Bundle nextBundle;
    Bundle userInfo;

    UMShareAPI mController;
    String weixinUnid = "";

    private boolean isSending = false;
    private String playUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_new);
        ButterKnife.bind(this);

        Bundle intentExtras = getIntent().getExtras();

        if (intentExtras != null) {
            nextBundle = intentExtras.getBundle("bundle");
            action = intentExtras.getString("action");
        }

//        if(Helper.sharedHelper().getBooleanUserInfo(Constant.USER_FIRST_SIGN,true)){
//            //第一次登陆
//            Intent intent = new Intent(this,SignInFirstActivity.class);
//            intent.putExtra("bundle",nextBundle);
//            intent.putExtra("action",action);
//            startActivity(intent);
//            Helper.sharedHelper().setBooleanUserInfo(Constant.USER_FIRST_SIGN,false);
//        }

        isBind = false;
        cellQuickSignInLabel.setVisibility(View.VISIBLE);
        cellQuickSignInPanel.setVisibility(View.VISIBLE);
        bindPhoneTipView.setVisibility(View.GONE);

        hideIMM();

        playUri = "android.resource://" + getPackageName() + "/" + R.raw.sign_bg;
        initBackground();

        if (Helper.sharedHelper().getStringUserInfo("mobile") != null &&
                !Helper.sharedHelper().getStringUserInfo("mobile").equals("")) {
            phoneView.setText(Helper.sharedHelper().getStringUserInfo("mobile"));
            setBtnEnabled(true);
            voiceCode.setEnabled(true);
        }

        mController = UMShareAPI.get(this);

        initPhoneListener();
        checkForRedpaper();
    }

    private void setBtnEnabled(boolean enabled){
        btnGetSmsCode.setEnabled(enabled);
        if(enabled){
            btnGetSmsCode.setBackgroundResource(R.drawable.button_large_brand);
        }else
            btnGetSmsCode.setBackgroundResource(R.drawable.button_large_grey);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constant.REQUEST_CODE_PERFECT_INFO) {
            Intent intent = new Intent();
            intent.putExtra("isRedpackExist", isRedpackExist);
            intent.putExtra("redpackIds", redpackIds);
            intent.putExtra("totalMoney", totalRedpackMoney);
            setResult(RESULT_OK, intent);
            finish();
        }

        try {
            mController.onActivityResult(requestCode, resultCode, data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if(!TextUtils.isEmpty(playUri)){
            myVideoView.setVideoURI(Uri.parse(playUri));
            myVideoView.start();
        }
    }

    private void initBackground(){
        Bitmap  bitmap = BitmapFactory.decodeResource(this.getResources(), R.mipmap.bg_sign_in);
        backgroundView.setImageBitmap(BitmapVagueUtil.getTransparentBitmap(BitmapVagueUtil.fastblur(this, bitmap, 18), 80));
        myVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                myVideoView.start();
            }
        });
    }

    private void initPhoneListener() {
        voiceCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSendVoiceCode(v);
            }
        });
        phoneView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (isSending)
                    return;
                String contents = Helper.formatMobileNumber(s.toString().trim());
                if (contents.length() != s.toString().length()) {
                    phoneView.setText(contents);
                    phoneView.setSelection(contents.length());
                }

                if (contents.replace(" ", "").length() == MOBILE_PHONE_LENGTH) {
                    setBtnEnabled(true);
                    voiceCode.setEnabled(true);
                } else {
                    setBtnEnabled(false);
                    voiceCode.setEnabled(false);
                }
            }
        });
    }

    public void handleSendSmsCode(View view) {
        codeView.requestFocus();
        if (codeView.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        setBtnEnabled(false);
        btnGetSmsCode.setText("获取中");
        voiceCode.setEnabled(false);
        isSending = true;
//        voiceCodeLL.setText("语音验证码");
//        voiceCodeLL.setVisibility(View.INVISIBLE);
        String mobile = phoneView.getText().toString().replace(" ", "");
        try {
            JSONObject params = new JSONObject();
            params.put("mobile", mobile);
            RequestSign.getSmsCode(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    MessageUtils.showToastCenter("验证码已发送至你的手机，请注意查收");
                    btnGetSmsCode.setText("60秒可重发");
                    new CountDownTimer(60000, 1000) {

                        public void onTick(long millisUntilFinished) {
                            btnGetSmsCode.setText(millisUntilFinished / 1000 + "秒可重发");
                        }

                        public void onFinish() {
                            btnGetSmsCode.setText(STRING_SMS_CODE_RETRY);
                            setBtnEnabled(true);
                            voiceCode.setEnabled(true);
                            isSending = false;
//                            voiceCodeLL.setVisibility(View.VISIBLE);
                        }
                    }.start();
                }

                @Override
                public void onFailure(HttpError error) {
                    if (error != null) {
                        MessageUtils.showToastCenter(error.getMessage());
                    } else {
                        MessageUtils.showToastCenter("发送验证码失败，请重试");
                    }
                    btnGetSmsCode.setText(STRING_SMS_CODE_RETRY);
                    setBtnEnabled(true);
                    voiceCode.setEnabled(true);
                    isSending = false;
//                    voiceCodeLL.setVisibility(View.VISIBLE);
                }
            });
        } catch (JSONException e) {
            MessageUtils.showToastCenter("发送验证码失败，请重试");
            btnGetSmsCode.setText(STRING_SMS_CODE_RETRY);
            setBtnEnabled(true);
            voiceCode.setEnabled(true);
            isSending = false;
//            voiceCodeLL.setVisibility(View.VISIBLE);
        }
    }

    public void handleSendVoiceCode(View view) {
        codeView.requestFocus();
        if (codeView.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        setBtnEnabled(false);
        btnGetSmsCode.setText("短信验证码");
        voiceCode.setEnabled(false);
        isSending = true;
//        btnGetYuyinCode.setText("获取中");
        voiceCodeLL.setVisibility(View.GONE);
        voiceCodeTips.setVisibility(View.VISIBLE);
        voiceCodeTips.setText("获取中");
        String mobile = phoneView.getText().toString().replace(" ", "");
        try {
            JSONObject params = new JSONObject();
            params.put("mobile", mobile);
            RequestSign.getVoiceToken(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    MessageUtils.showToastCenter("验证码已发送，请注意接听");
                    voiceCodeTips.setText("60秒可重发");
                    new CountDownTimer(60000, 1000) {

                        public void onTick(long millisUntilFinished) {
                            voiceCodeTips.setText(millisUntilFinished / 1000 + "秒可重发");
                        }

                        public void onFinish() {
                            voiceCodeTips.setText(STRING_SMS_CODE_RETRY);
                            setBtnEnabled(true);
                            voiceCode.setEnabled(true);
                            isSending = false;
                            voiceCodeLL.setVisibility(View.VISIBLE);
                            voiceCodeTips.setVisibility(View.GONE);
                        }
                    }.start();
                }

                @Override
                public void onFailure(HttpError error) {
                    if (error != null) {
                        MessageUtils.showToastCenter(error.getMessage());
                    } else {
                        MessageUtils.showToastCenter("发送验证码失败，请重试");
                    }
                    setBtnEnabled(true);
                    voiceCode.setEnabled(true);
                    isSending = false;
                    voiceCodeLL.setVisibility(View.VISIBLE);
                    voiceCodeTips.setVisibility(View.GONE);
                }
            });
        } catch (JSONException e) {
            MessageUtils.showToastCenter("发送验证码失败，请重试");
            setBtnEnabled(true);
            voiceCode.setEnabled(true);
            isSending = false;
            voiceCodeLL.setVisibility(View.VISIBLE);
            voiceCodeTips.setVisibility(View.GONE);
        }
    }

    public void handleSignIn(View view) {
        final String phoneNum = phoneView.getText().toString().trim();
        String shortPhoneNum = phoneNum.replace(" ", "");
        if (shortPhoneNum.length() == 0) {
            MessageUtils.showToastCenter("未填写手机号码哦");
            return;
        } else if (shortPhoneNum.length() != MOBILE_PHONE_LENGTH) {
            MessageUtils.showToastCenter("请填写正确的手机号码哦");
            return;
        }

        String code = codeView.getText().toString();
        if (code.length() == 0) {
            MessageUtils.showToastCenter("未填写验证码哦");
            return;
        } else if (code.length() != SMS_CODE_LENGTH) {
            MessageUtils.showToastCenter("验证码有误");
            return;
        }

        showProgressDialog("正在登录", false);
        btnSignIn.setEnabled(false);

        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("mobile", phoneView.getText().toString().replace(" ", ""));
        params.put("smsToken", codeView.getText().toString());

        if (isBind) {
            params.put("loginType", LOGIN_TYPE_BIND);
            params.put("accountType", accountType);

            params.put("account", account);
        }

        if (accountType == Constant.OAUTH_TYPE_WECHAT && weixinUnid != null && weixinUnid.length() > 0) {
            params.put("weixinUnid", weixinUnid);
        }

        RequestSign.signIn(params, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {

            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject data) {
                hideProgressDialog();

                // 存储手机号到本地
                Helper.sharedHelper().setStringUserInfo(Constant.USER_MOBILE, phoneNum);

                Boolean isNew = "true".equals(data.getString("isNew"));
                String token = data.getString("returnToken");
                String userId = data.getString("userId");
                signInSuccess(isNew, token, userId);

                btnSignIn.setEnabled(true);
            }

            @Override
            public void onFail(HttpError error) {
                btnSignIn.setEnabled(true);
                hideProgressDialog();
                if (HttpError.ERR_CODE_ACCOUNT_FREEZE == error.getCode()) {
                    showErrorDialog(error.getMessage());
                    return;
                } else {
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : STRING_SIGN_IN_ERROR);
                }
            }
        });
    }

    public void handleOpenAgreement(View view) {
        Bundle bundle = new Bundle();
        bundle.putString("url", Constant.URL_XIEYI);
        Router.sharedRouter().open("web", bundle);
    }

    public void handleSignInWithQQ(View view) {
        if (!Helper.isPackageExist(this, "com.tencent.mobileqq")) {
            MessageUtils.showToast("QQ未安装");
            return;
        }
        OAuth(SHARE_MEDIA.QQ);
    }

    public void handleSignInWithWechat(View view) {
        OAuth(SHARE_MEDIA.WEIXIN);
    }

    public void handleSignInWithSina(View view) {
        OAuth(SHARE_MEDIA.SINA);
    }

    private void xhrProfile(final String userId) {
        RequestSign.getUserInfo(userId, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                try {
                    JSONObject json = (JSONObject) result;
                    JSONObject data = json.getJSONObject("data");

                    Helper.sharedHelper().setStringUserInfo(Constant.USER_NICK, data.getString(Constant.USER_NICK));
                    Helper.sharedHelper().setStringUserInfo(Constant.USER_ID, userId);
                    Helper.sharedHelper().setStringUserInfo(Constant.USER_AVATAR, data.getString(Constant.USER_AVATAR));
                    if (data.has(Constant.USER_GENDER)) {
                        Helper.sharedHelper().setStringUserInfo(Constant.USER_GENDER, data.getString(Constant.USER_GENDER));
                    }
                } catch (JSONException e) {

                }
            }

            @Override
            public void onFailure(HttpError error) {

            }
        });
    }

    private void xhrOAuthSignIn(com.alibaba.fastjson.JSONObject params) {
        showProgressDialog("正在登录", false);
        RequestSign.signIn(params, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {

            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject data) {
                hideProgressDialog();
                // 需要绑定手机号
                if (data.containsKey("needRegister")) {
                    isBind = true;
                    cellQuickSignInLabel.setVisibility(View.GONE);
                    cellQuickSignInPanel.setVisibility(View.GONE);
                    bindPhoneTipView.setVisibility(View.VISIBLE);
                }
                // 已绑定过手机号，正常登录成功流程
                else {
                    Boolean isNew = "true".equals(data.getString("isNew"));//data.has("isNew") ? data.getString("isNew").equals("true") : false;
                    String token = data.getString("returnToken");
                    String userId = data.getString("userId");

                    //ut init userInfo
                    signInSuccess(isNew, token, userId);
                }
            }

            @Override
            public void onFail(HttpError error) {
                btnSignIn.setEnabled(true);
                hideProgressDialog();
                if (error != null && HttpError.ERR_CODE_ACCOUNT_FREEZE == error.getCode()) {
                    showErrorDialog(error.getMessage());
                } else {
                    MessageUtils.showToastCenter(error != null ? error.toString() : STRING_SIGN_IN_ERROR);
                }
            }
        });
    }

    private void signInSuccess(Boolean isNew, String token, String userId) {

        Helper.sharedHelper().setToken(token);
        Helper.sharedHelper().setUserId(userId);

        // 如果不是新用户，登录成功后调用获取个人资料将缓存到本地
        if (!isNew) {
            xhrProfile(Helper.sharedHelper().getUserId());
        }

        //authWuKong(userId);
        ChatHelper.getInstance().authWuKong(userId);

        ImClient.getImService(AuthManager.class).login();
        if (isNew) {
            Bundle bundle = new Bundle();
            bundle.putString("action", action);
            bundle.putBundle("bundle", nextBundle);
            bundle.putBundle("userInfo", userInfo);
            Router.sharedRouter().openFormResult("signup", bundle,
                    Constant.REQUEST_CODE_PERFECT_INFO, SignInActivity.this);
        } else {
            if (action != null) {
                Router.sharedRouter().open(action, nextBundle);
            }
            Intent intent = new Intent();
            intent.putExtra("isRedpackExist", isRedpackExist);
            intent.putExtra("redpackIds", redpackIds);
            intent.putExtra("totalMoney", totalRedpackMoney);
            setResult(RESULT_OK, intent);
            finish();
        }
    }

    private void checkForRedpaper() {

        HttpClient.get("1.0/redpack/checkChanel", null, com.alibaba.fastjson.JSONObject.class, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                if (null == obj) {
                    return;
                }
                try {
                    redpackIds = obj.getString("redpackIds");
                    isRedpackExist = obj.getBoolean("isExist");
                    totalRedpackMoney = obj.getString("totalMoney");
                    if (totalRedpackMoney != null && isRedpackExist) {
                        redPaperTipsLayout.setVisibility(View.VISIBLE);
                        redPaperTips.setText(String.format("现在注册，领取%s元新人红包买买买吧！", totalRedpackMoney));
                    } else {
                        redPaperTipsLayout.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFail(HttpError error) {
                Log.d(LOG_TAG, error.getMessage());
            }
        });
    }


    private void OAuth(final SHARE_MEDIA shareMedia) {
        try {
            showProgressDialog(STRING_OAUTH_START, true);
            mController.doOauthVerify(this, shareMedia, new UMAuthListener() {
                @Override
                public void onComplete(SHARE_MEDIA share_media, int i, Map<String, String> map) {
                    Log.d(LOG_TAG, "doOauthVerify i=" + i);
                    if (map == null) {
                        hideProgressDialog();
                        MessageUtils.showToastCenter(STRING_OAUTH_ERROR);
                    } else {
                        //获取相关授权信息
                        showProgressDialog(STRING_OAUTH_INFO, false);
                        getPlatformInfo(shareMedia);
                    }
                }

                @Override
                public void onError(SHARE_MEDIA share_media, int i, Throwable throwable) {
                    MessageUtils.showToastCenter(STRING_OAUTH_ERROR + ":" + i);
                    Log.e(LOG_TAG, "OAuth onError failed:" + throwable);
                    hideProgressDialog();
                }

                @Override
                public void onCancel(SHARE_MEDIA share_media, int i) {
                    hideProgressDialog();
                }
            });

        } catch (Exception e) {
            MessageUtils.showToastCenter(STRING_SIGN_IN_ERROR);
            Log.e(LOG_TAG, "OAuth failed" + e.getMessage());
            hideProgressDialog();
            e.printStackTrace();
        }
    }

    private void getPlatformInfo(final SHARE_MEDIA shareMedia) {
        mController.getPlatformInfo(SignInActivity.this, shareMedia, new UMAuthListener() {
            @Override
            public void onComplete(SHARE_MEDIA share_media, int i, Map<String, String> map) {
                if (map != null) {
                    userInfo = new Bundle();

                    if (shareMedia == SHARE_MEDIA.QQ) {
                        userInfo.putString(Constant.USER_NICK, map.get("screen_name"));
                        userInfo.putString(Constant.USER_AVATAR, map.get("profile_image_url"));
                        userInfo.putString(Constant.USER_GENDER, map.get("gender").equals("男") ?
                                Constant.GENDER_MAN :
                                Constant.GENDER_WOMAN);
                        accountType = Constant.OAUTH_TYPE_QQ;
                        account = map.get("openid");
                    } else if (shareMedia == SHARE_MEDIA.WEIXIN) {
                        //unionid 微信概念
                        weixinUnid = map.get("unionid");
                        userInfo.putString(Constant.USER_NICK, map.get("nickname"));
                        userInfo.putString(Constant.USER_AVATAR, map.get("headimgurl"));
                        if (map.get("sex") != null) {
                            userInfo.putString(Constant.USER_GENDER, Integer.valueOf(map.get("sex")) == 1 ?
                                    Constant.GENDER_MAN :
                                    Constant.GENDER_WOMAN);
                            accountType = Constant.OAUTH_TYPE_WECHAT;
                        }
                        account = map.get("openid");
                    } else {
                        userInfo.putString(Constant.USER_NICK, map.get("screen_name"));
                        userInfo.putString(Constant.USER_AVATAR, map.get("profile_image_url"));
                        if (map.get("gender") != null) {
                            userInfo.putString(Constant.USER_GENDER, Integer.valueOf(map.get("gender")) == 1 ?
                                    Constant.GENDER_MAN :
                                    Constant.GENDER_WOMAN);
                        }
                        accountType = Constant.OAUTH_TYPE_SINA;
                        account = map.get("uid");
                    }

                    //openId
                    try {
                        final com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
                        if (accountType == Constant.OAUTH_TYPE_WECHAT && weixinUnid != null && weixinUnid.length() > 0) {
                            params.put("weixinUnid", weixinUnid);
                        }
                        params.put("accountType", accountType);
                        params.put("loginType", LOGIN_TYPE_OAUTH);
                        params.put("account", account);

                        //微博登陆此代码运行在非主线程，因此在UI线程执行此代码
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                xhrOAuthSignIn(params);
                            }
                        });
                    } catch (Exception e) {
                        hideProgressDialog();
                        Log.e(LOG_TAG, "getPlatformInfo error:", e);
                        MessageUtils.showToastCenter(STRING_SIGN_IN_ERROR);
                    }
                } else {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(STRING_OAUTH_ERROR);
                    Log.e(LOG_TAG, "Get empty platform info.");
                }
            }

            @Override
            public void onError(SHARE_MEDIA share_media, int i, Throwable throwable) {
                MessageUtils.showToast("授权失败：" + i);
                Log.e(LOG_TAG, null != throwable ? throwable.toString() : "auth fail.");
            }

            @Override
            public void onCancel(SHARE_MEDIA share_media, int i) {
                MessageUtils.showToast("授权取消：" + i);
                Log.e(LOG_TAG, "auth cancel.");
            }
        });
    }

    private void showErrorDialog(String message) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setMessage(message).setTitle(R.string.error_login_failed)
                .setPositiveButton(R.string.btn_i_known, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setNegativeButton(R.string.btn_contact_us, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Helper.makeCall(SignInActivity.this, Constant.KE_FU_TEL);
                    }
                }).create();

        dialog.show();
    }
}
