package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.zxing.Result;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.util.QRCodeUtil;
import com.meidalife.shz.view.ScannerView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class BarcodeScannerActivity extends BaseActivity implements ZXingScannerView.ResultHandler {
    @Bind(R.id.scannerView)
    ScannerView  mScannerView;
    @Bind(R.id.backButton)
    TextView backButton;
    @Bind(R.id.photoIcon)
    TextView photoIcon;
    @Bind(R.id.flashIcon)
    TextView flashIcon;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_barcode_scanner); // Set the scanner view as the content view
        ButterKnife.bind(this);
        initComponent();
    }

    @Override
    public void onResume() {
        super.onResume();

        try {
            mScannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
            mScannerView.startCamera();          // Start camera on resume
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            mScannerView.stopCamera();           // Stop camera on pause
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void handleResult(Result result) {
        if (null != result) {
            Intent returnIntent = new Intent();
            returnIntent.putExtra("result", result.getText());
            setResult(RESULT_OK, returnIntent);
        }

        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_PICK_PHOTO && RESULT_OK == resultCode) {
            try {
                Bundle bundle = data.getExtras();
                ArrayList images = bundle.getStringArrayList("images");

                if (null != images && images.size() > 0) {
                    String imagePath = (String) images.get(0);
                    new QRCodeReadTask().execute(imagePath);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void initComponent() {
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        photoIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putBoolean("isCheckbox", false);
                Router.sharedRouter().openFormResult("pick/photo", bundle,
                        Constant.REQUEST_CODE_PICK_PHOTO, BarcodeScannerActivity.this);
            }
        });

        flashIcon.setText(mScannerView.getFlash() ? R.string.icon_flash_on : R.string.icon_flash_off);
        flashIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScannerView.setFlash(!mScannerView.getFlash());
                flashIcon.setText(mScannerView.getFlash() ? R.string.icon_flash_on : R.string.icon_flash_off);
            }
        });
    }

    public class QRCodeReadTask extends AsyncTask<String, String, Result> {

        @Override
        protected Result doInBackground(String... params) {
            String path = params[0];

            return QRCodeUtil.decodeFromFile(path);
        }

        @Override
        protected void onPostExecute(Result result) {
            if (null != result) {
                handleResult(result);
            } else {
                MessageUtils.showToast("无法识别该图片");
            }
        }
    }
}
