package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CareerRecyclerAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CareerDo;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.view.OnServicePublishListener;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/4/18.
 */
public class PublishSkillFragment extends BaseFragment {

    private List<CareerDo> careerDoList = new ArrayList<>();
    View rootView;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.skillRecyclerView)
    RecyclerView skillRecyclerView;

    private LoadUtil mLoadUtil;
    private CareerRecyclerAdapter skillRecyclerAdapter;
    private OnServicePublishListener onServicePublishListener;

    public static PublishSkillFragment newInstance(Bundle arg) {
        PublishSkillFragment fragment = new PublishSkillFragment();
        fragment.setArguments(arg);
        return fragment;
    }

    public void setOnServicePublishListener(OnServicePublishListener onServicePublishListener) {
        this.onServicePublishListener = onServicePublishListener;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (null == rootView) {
            rootView = inflater.inflate(R.layout.fragment_publish_skill, container, false);
            ButterKnife.bind(this, rootView);
            initComponents();
            getSkills();
        }
        return rootView;
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    private void initComponents() {
        mLoadUtil = new LoadUtil(LayoutInflater.from(getActivity()));

        skillRecyclerAdapter = new CareerRecyclerAdapter(getActivity(), careerDoList);
        skillRecyclerAdapter.setOnServicePublishListener(onServicePublishListener);
        skillRecyclerAdapter.setSelectedCareerId(getArguments().getString(Constant.EXTRA_TAG_CAREER_ID));
        skillRecyclerAdapter.setSelectedSkillId(getArguments().getString(Constant.EXTRA_TAG_SKILL_ID));

        skillRecyclerView.setAdapter(skillRecyclerAdapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        skillRecyclerView.setLayoutManager(linearLayoutManager);
    }

    private void getSkills() {
        mLoadUtil.loadPre(rootLayout, skillRecyclerView);
        HttpClient.get("1.0/item/getSkill", null, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject skillsJSON) {
                try {
                    mLoadUtil.loadSuccess(skillRecyclerView);
                    careerDoList = JSON.parseArray(skillsJSON.getJSONArray("skills").toJSONString(), CareerDo.class);
                    skillRecyclerAdapter.setCareerDoList(careerDoList);
                    skillRecyclerAdapter.notifyDataSetChanged();
                    if (careerDoList.isEmpty() && onServicePublishListener != null) {
                        onServicePublishListener.onSkillEmpty();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFail(HttpError error) {
                mLoadUtil.loadFail(error, rootLayout, new LoadUtil.Callback() {
                    @Override
                    public void retry() {
                        getSkills();
                    }
                });
            }
        });
    }
}
