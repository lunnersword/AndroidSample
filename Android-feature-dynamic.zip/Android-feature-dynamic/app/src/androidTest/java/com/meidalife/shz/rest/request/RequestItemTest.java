package com.meidalife.shz.rest.request;

import android.util.Log;

import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ServiceItem;

/**
 * Created by xiaoweilc on 15/6/15.
 */
public class RequestItemTest {

    public static void main(String[] args) {
        String[] array = "hello".split("/");
        System.out.println(array.length);
    }

}
