package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareAskDO;
import com.meidalife.shz.rest.model.SquareAskServiceItemDo;
import com.meidalife.shz.rest.request.RequestSquareAsk;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.RemainTimeUtils;
import com.meidalife.shz.view.FontEditText;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;
import com.usepropeller.routable.Router;

public class SquareAskReplyActivity extends BaseActivity {

    private final static int REQUST_ASSOCIATE_SERVICE = 10;
    private final static int MAX_DESC_NUMS = 50;
    private FontEditText desc;
    private FontTextView remainDescCount;
    private int descLength;
    private SimpleDraweeView userAvatar;
    private FontTextView demandTitle;
    private FontTextView remainDays;
    private IconTextView iconGender;
    private FontTextView textNick;
    private FontTextView commentCount;
    private FontTextView description;
    private View serviceContent;
    private SimpleDraweeView imageService;
    private IconTextView iconGenderService;
    private FontTextView textNickService;
    private SimpleDraweeView imageAvatarService;
    private FontTextView titleService;
    private FontTextView commitSend;
    private int mGeziId;
    private String mDemandId;
    private SquareAskServiceItemDo mResultServiceItem;
    private boolean isGeZhu = false;
    private SquareAskDO squareAskDO;
    private ViewGroup statusView;
    private View contentView;
    private TextView serviceTypeView;
    private TextView removeImage;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUST_ASSOCIATE_SERVICE:
                if (resultCode == RESULT_OK) {
                    Bundle resultBundle = data.getExtras();
                    if (resultBundle != null) {
                        mResultServiceItem = (SquareAskServiceItemDo) resultBundle
                                .getSerializable(SquareAskChooseServiceActivity.KEY_RETURN_SERVICE_ITEM);
                    } else {
                        Log.d("mzLog", "resultBundle is null");
                    }

                    if (mResultServiceItem != null) {
                        Log.d("mzLog", "result mResultServiceItem");
                        serviceContent.setVisibility(View.VISIBLE);
                        imageService.setImageURI(Uri.parse(mResultServiceItem.getImages().get(0)));
                        String gender = mResultServiceItem.getUserGender();

                        // 设置服务者性别
                        if (mResultServiceItem.getUserGender() != null) {
                            iconGenderService.setVisibility(View.VISIBLE);
                            if (mResultServiceItem.getUserGender().equals("woman") || mResultServiceItem.getUserGender().equals("F")) {
                                iconGenderService.setText(getResources().getString(R.string.icon_gender_f));
                                iconGenderService.setTextColor(getResources().getColor(R.color.brand_b));
                            } else {
                                iconGenderService.setText(getResources().getString(R.string.icon_gender_m));
                                iconGenderService.setTextColor(getResources().getColor(R.color.brand_i));
                            }
                        } else {
                            iconGenderService.setVisibility(View.GONE);
                        }

                        // 加载发布者头像
                        ViewGroup.LayoutParams avatarParams = imageAvatarService.getLayoutParams();
                        String userPicUrl = mResultServiceItem.getUserAvatar();
                        if (TextUtils.isEmpty(userPicUrl) || userPicUrl.equals("null")) {
                            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(mResultServiceItem.getUserId()), gender);
                            imageAvatarService.setImageURI(getDefaultAvatarUri);

                        } else {
                            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(userPicUrl, avatarParams.width));
                            imageAvatarService.setImageURI(uri);
                        }

                        textNickService.setText(mResultServiceItem.getUserName());
                        titleService.setText(mResultServiceItem.getItemTitle());
                    } else {
                        Log.d("mzLog", "mResultServiceItem is null");
                        serviceContent.setVisibility(View.GONE);
                    }
                }
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_ask_help);

        initActionBar(R.string.title_activity_ican_help, true);
        hideIMM();
        mDemandId = getIntent().getStringExtra("askid");
        findView();
        fetchAskData();


        desc.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                descLength = desc.length();
                remainDescCount.setText(descLength + "/" + MAX_DESC_NUMS);
                if (descLength > MAX_DESC_NUMS) {
                    desc.setText(desc.getText().toString().substring(0, MAX_DESC_NUMS));
                    MessageUtils.showToast("已超出" + MAX_DESC_NUMS + "个字符。");
                }
            }
        });

        commitSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String content = desc.getText().toString();
                content = content.trim();
                if (content.length() == 0) {
                    MessageUtils.showToast("你还没有输入内容哦");
                    return;
                }
                JSONObject params = new JSONObject();
                params.put("demandId", mDemandId);
                params.put("reply", desc.getText().toString());
                if (mResultServiceItem != null) {
                    params.put("itemId", mResultServiceItem.getItemId());
                }
                commitSend.setEnabled(false);
                RequestSquareAsk.addComment(params, new HttpClient.HttpCallback() {
                    @Override
                    public void onSuccess(Object obj) {
                        MessageUtils.showToast("回复成功");
                        setResult(RESULT_OK);
                        finish();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(error != null ? error.getMessage() : "回复失败，请稍后再试");
                        commitSend.setEnabled(true);
                    }
                });
            }
        });
        removeImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceContent.setVisibility(View.GONE);
                mResultServiceItem = null;
            }
        });
    }

    private void fetchAskData() {
        hideStatusErrorNetwork();
        hideStatusErrorServer();
        showStatusLoading(statusView);
        contentView.setVisibility(View.GONE);
        JSONObject params = new JSONObject();
        params.put("demandId", mDemandId);
        RequestSquareAsk.getDemandDetail(params, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                Log.d("mzLog", "detail: " + obj.toString());
                JSONObject demandDetail = (JSONObject) obj;
                try {

                    if (demandDetail.containsKey("isGezhu")) {
                        isGeZhu = demandDetail.getBoolean("isGezhu");
                        if (isGeZhu) {
                            serviceTypeView.setText(SquareAskReplyActivity.this.getString(R.string.title_activity_square_ask_choose_service_gezhu));
                        } else
                            serviceTypeView.setText(SquareAskReplyActivity.this.getString(R.string.title_activity_square_ask_choose_service));
                    }

                    squareAskDO = new SquareAskDO();
                    if (demandDetail.containsKey("demand")) {
                        JSONObject demandJB = (JSONObject) demandDetail.get("demand");
                        if (demandJB.containsKey("id"))
                            squareAskDO.setId(demandJB.getInteger("id"));
                        if (demandJB.containsKey("geziId"))
                            mGeziId = demandJB.getInteger("geziId");
                        squareAskDO.setGeziId(mGeziId);
                        if (demandJB.containsKey("title"))
                            squareAskDO.setTitle(demandJB.getString("title"));
                        if (demandJB.containsKey("description"))
                            squareAskDO.setDescription(demandJB.getString("description"));
                        if (demandJB.containsKey("closeTime"))
                            squareAskDO.setCloseTime(demandJB.getInteger("closeTime"));
                        if (demandJB.containsKey("remainTime"))
                            squareAskDO.setRemainTime(demandJB.getInteger("remainTime"));
                        if (demandJB.containsKey("user")) {
                            JSONObject user = demandJB.getJSONObject("user");
                            squareAskDO.setUserInstruction(user.getString("userInstruction"));
                            squareAskDO.setUserId(user.getInteger("userId"));
                            squareAskDO.setUserNick(user.getString("userNick"));
                            squareAskDO.setUserPicUrl(user.getString("userPicUrl"));
                            squareAskDO.setUserGender(user.getString("userGender"));
                        }
                        if (demandJB.containsKey("commentCount"))
                            squareAskDO.setCommentCount(demandJB.getInteger("commentCount"));
                    }

                    initData();
                    hideStatusLoading();
                    hideStatusErrorNetwork();
                    hideStatusErrorServer();
                    contentView.setVisibility(View.VISIBLE);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.d("mzLog squareAskDO", squareAskDO.toString());

            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(statusView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fetchAskData();
                        }
                    });
                } else {
                    showStatusErrorServer(statusView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fetchAskData();
                        }
                    });
                    setTextErrorServer(error.getMessage());
                }
            }
        });

    }

    private void findView() {
        statusView = (ViewGroup) findViewById(R.id.statusView);
        contentView = findViewById(R.id.contentView);
        desc = (FontEditText) findViewById(R.id.desc);
        remainDescCount = (FontTextView) findViewById(R.id.remainDescCount);
        userAvatar = (SimpleDraweeView) findViewById(R.id.imageAvatar);
        demandTitle = (FontTextView) findViewById(R.id.demandTitle);
        remainDays = (FontTextView) findViewById(R.id.remainDays);
        iconGender = (IconTextView) findViewById(R.id.iconGender);
        textNick = (FontTextView) findViewById(R.id.textNick);
        commentCount = (FontTextView) findViewById(R.id.commentCount);
        description = (FontTextView) findViewById(R.id.description);
        commitSend = (FontTextView) findViewById(R.id.commitSend);
        serviceContent = findViewById(R.id.serviceContent);
        imageService = (SimpleDraweeView) findViewById(R.id.imageService);
        iconGenderService = (IconTextView) findViewById(R.id.iconGenderService);
        textNickService = (FontTextView) findViewById(R.id.textNickService);
        imageAvatarService = (SimpleDraweeView) findViewById(R.id.imageAvatarService);
        titleService = (FontTextView) findViewById(R.id.titleService);
        serviceTypeView = (TextView) findViewById(R.id.serviceTypeView);
        removeImage = (TextView) findViewById(R.id.removeImage);
    }

    public void handleAssociateService(View view) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isGeZhu", isGeZhu);
        bundle.putInt("geziId", mGeziId);
        Router.sharedRouter().openFormResult("squareAskChooseService", bundle, REQUST_ASSOCIATE_SERVICE, this);
    }

    private void initData() {
        String gender = squareAskDO.getUserGender();
        // 设置服务者性别
        if (gender != null) {
            iconGender.setVisibility(View.VISIBLE);
            if (gender.equals("woman") || gender.equals("F")) {
                iconGender.setText(this.getResources().getString(R.string.icon_gender_f));
                iconGender.setTextColor(this.getResources().getColor(R.color.brand_b));
            } else {
                iconGender.setText(this.getResources().getString(R.string.icon_gender_m));
                iconGender.setTextColor(this.getResources().getColor(R.color.brand_i));
            }
        } else {
            iconGender.setVisibility(View.GONE);
        }

        // 加载发布者头像
        ViewGroup.LayoutParams avatarParams = userAvatar.getLayoutParams();
        if (TextUtils.isEmpty(squareAskDO.getUserPicUrl())) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(squareAskDO.getUserId()), gender);
            userAvatar.setImageURI(getDefaultAvatarUri);
        } else {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(squareAskDO.getUserPicUrl(), avatarParams.width));
            userAvatar.setImageURI(uri);
        }

        demandTitle.setText("我要·" + squareAskDO.getTitle());
        String remainTime = RemainTimeUtils.transTime(squareAskDO.getRemainTime());
        remainDays.setText("剩余天数：" + remainTime);
        textNick.setText(squareAskDO.getUserNick() == null ? "" : squareAskDO.getUserNick());
        commentCount.setText("回答数：" + squareAskDO.getCommentCount());
        description.setText(squareAskDO.getDescription());
    }


}
