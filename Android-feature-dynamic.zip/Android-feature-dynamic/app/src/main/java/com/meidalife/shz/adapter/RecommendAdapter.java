package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.JobDO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zuozheng on 16/3/29.
 *
 * @description 动态推荐
 */
public class RecommendAdapter extends BaseAdapter {
    private static final String LOG_TAG = "RecommendAdapter";
    private static final int TYPE_COUNT = 2;

    LayoutInflater mInflater;
    Context mContext;
    List<DynamicUserOutDO> mData;

    OnClickListener onClickListener;

    public void setOnClickListener(OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public interface OnClickListener {
//        public void cancelFollowClick(String userId, int position);

        public void addFollowClick(DynamicUserOutDO dynamic, int position);
    }

    static class ViewHolder {

        @Bind(R.id.rootView)
        ViewGroup rootView;

        @Bind(R.id.avatar)
        SimpleDraweeView avatar;

        @Bind(R.id.iconGender)
        TextView iconGender;

        @Bind(R.id.nickView)
        TextView nickView;

        @Bind(R.id.jobsViewGroup)
        LinearLayout jobsViewGroup;

        @Bind(R.id.jobTitleView)
        TextView jobTitleView;

        @Bind(R.id.likeUserCountView)
        TextView likeUserCountView;

        @Bind(R.id.unFocusView)
        View unFocusView;
        @Bind(R.id.focusedView)
        TextView focusedView;

        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }


    public RecommendAdapter(Context context, List<DynamicUserOutDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public DynamicUserOutDO getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final DynamicUserOutDO item = mData.get(position);
        final ViewHolder holder;
        if (convertView == null || convertView.getTag() == null) {
            convertView = mInflater.inflate(R.layout.item_dynamic_recommend, parent, false);
            holder = new ViewHolder(convertView);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        String gender = item.getUserGender();
        if (TextUtils.isEmpty(gender)) {
            holder.iconGender.setText("");
            holder.iconGender.setVisibility(View.GONE);
        } else {
            if (gender.equals("woman") || gender.equals("F")) {
                holder.iconGender.setText(mContext.getResources().getString(R.string.icon_female));
                holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.color_icon_female));
            } else {
                holder.iconGender.setText(mContext.getResources().getString(R.string.icon_male));
                holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.color_icon_male));
            }
            holder.iconGender.setVisibility(View.VISIBLE);
        }

        if (TextUtils.isEmpty(item.getAvatarUrl())) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, item.getUserId(), gender);
            holder.avatar.setImageURI(getDefaultAvatarUri);
        } else {
            holder.avatar.setVisibility(View.VISIBLE);
            holder.avatar.setImageURI(Uri.parse(item.getAvatarUrl()));
        }

        holder.nickView.setText(item.getUserNick());

        holder.jobsViewGroup.removeAllViews();
        if (CollectionUtil.isNotEmpty(item.getJobs())) {
            for (JobDO job : item.getJobs()) {
                View jobView = mInflater.inflate(R.layout.item_dynamic_user_job, null);
                SimpleDraweeView icon = (SimpleDraweeView) jobView.findViewById(R.id.avatar);
                TextView titleView = (TextView) jobView.findViewById(R.id.title);
                ViewGroup.LayoutParams iconParams = icon.getLayoutParams();

                if (!TextUtils.isEmpty(job.getIconUrl())) {
                    Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getAvatarUrl(), iconParams.width));
                    icon.setImageURI(uri);
                    icon.setVisibility(View.VISIBLE);
                } else {
                    icon.setImageURI(null);
                    icon.setVisibility(View.GONE);
                }
                titleView.setText(job.getTitle());
//        jobsView.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, context) * item.getGrade() / 5);
                holder.jobsViewGroup.addView(jobView);
            }
            holder.jobsViewGroup.setVisibility(View.VISIBLE);
        } else {
            holder.jobsViewGroup.removeAllViews();
            holder.jobsViewGroup.setVisibility(View.GONE);
        }

        holder.jobTitleView.setText(item.getJobTitle());

        holder.likeUserCountView.setText(String.format("%s 粉丝", item.getFunsCount()));


        if (item.isFocused()) {
            holder.unFocusView.setVisibility(View.GONE);
            holder.focusedView.setVisibility(View.VISIBLE);
        } else {
            holder.unFocusView.setVisibility(View.VISIBLE);
            holder.focusedView.setVisibility(View.GONE);
        }

        holder.unFocusView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //todo 注册 监听事件 如果点击关注按钮 发起关注请求并添加关注
                onClickListener.addFollowClick(item, position);
            }
        });

//        holder.focusedView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                //todo 注册 监听事件 如果点击不在关注按钮 发起请求并取消关注
//                onClickListener.cancelFocusClick(item.getUserId(), position);
//            }
//        });

        return convertView;
    }
}
