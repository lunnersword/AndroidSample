package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSchedule;
import com.meidalife.shz.view.ArcView;

import java.util.ArrayList;
import java.util.HashMap;

public class TimeManageActivity extends BaseActivity {
    LayoutInflater mInflater;
    LinearLayout listPanel;
    LinearLayout topPanel;
    LinearLayout rootView;
    ScrollView scrollView;

    ArrayList mData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_manage);
        initActionBar(R.string.title_activity_time_manage, true, true);

        mButtonRight.setText("确定");
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String timeString = formatScheduleTime(mData);
                if (TextUtils.isEmpty(timeString) || !timeString.contains("1")) {
                    MessageUtils.showToast(TimeManageActivity.this, "请至少设置一个服务时间段");
                    return;
                }
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putString("scheduleTime", timeString);

                intent.putExtras(bundle);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        mInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        listPanel = (LinearLayout) findViewById(R.id.listPanel);
        topPanel = (LinearLayout) findViewById(R.id.topPanel);
        rootView = (LinearLayout) findViewById(R.id.rootView);
        scrollView = (ScrollView) findViewById(R.id.scrollView);

        Bundle bundle = getIntent().getExtras();

        if (bundle != null && bundle.getString("scheduleTime") != null) {
            mData = RequestSchedule.parseScheduleString(bundle.getString("scheduleTime"));
            renderListPanel();
        } else {
            xhrSchedule();
        }
    }

    private void xhrSchedule() {
        scrollView.setVisibility(View.GONE);
        topPanel.setVisibility(View.GONE);
        showStatusLoading(rootView);
        RequestSchedule.getSchedule(new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                hideStatusLoading();
                scrollView.setVisibility(View.VISIBLE);
                topPanel.setVisibility(View.VISIBLE);
                mData = (ArrayList) result;
                renderListPanel();
                xhrSave();
            }

            @Override
            public void onFailure(HttpError error) {
                hideStatusLoading();
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView);
                } else {
                    showStatusErrorServer(rootView);
                }
            }
        });
    }

    private String formatScheduleTime(ArrayList data) {
        if (null == data || data.isEmpty()) {
            return "";
        }
        String[] parts = new String[data.size()];
        for (int i = 0; i < data.size(); i++) {
            HashMap item = (HashMap) data.get(i);
            String[] buckets = new String[3];
            buckets[0] = (Boolean) item.get("am") ? "1" : "0";
            buckets[1] = (Boolean) item.get("pm") ? "1" : "0";
            buckets[2] = (Boolean) item.get("ni") ? "1" : "0";
            parts[i] = TextUtils.join("-", buckets);
        }
        return TextUtils.join("|", parts);
    }

    private void xhrSave() {
        try {
            RequestSchedule.updateSchedule(formatScheduleTime(mData), new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                }

                @Override
                public void onFailure(HttpError error) {
                    if (error != null) {
                        MessageUtils.showToastCenter(error.getMessage());
                    } else {
                        MessageUtils.showToastCenter("设置空闲时间，保存失败");
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void renderListPanel() {
        float deviceWidth = this.getResources().getDisplayMetrics().widthPixels;
        int lableWidth = Math.round(deviceWidth / 7);
        int labelHeight = topPanel.getLayoutParams().height;

        for (int i = 0; i < mData.size(); i++) {
            HashMap item = (HashMap) mData.get(i);
            String week = (String) item.get("title");
            Boolean amValue = (Boolean) item.get("am");
            Boolean pmValue = (Boolean) item.get("pm");
            Boolean niValue = (Boolean) item.get("ni");

            final View itemView = mInflater.inflate(R.layout.schedule_item, null);
            TextView headerView = (TextView) itemView.findViewById(R.id.week);
            Switch am = (Switch) itemView.findViewById(R.id.enabledAM);
            Switch pm = (Switch) itemView.findViewById(R.id.enabledPM);
            Switch ni = (Switch) itemView.findViewById(R.id.enabledNight);
            am.setChecked(amValue);
            pm.setChecked(pmValue);
            ni.setChecked(niValue);
            headerView.setText(week);
            initSwitchListener(am, i, "am");
            initSwitchListener(pm, i, "pm");
            initSwitchListener(ni, i, "ni");
            listPanel.addView(itemView);

            final View labelView = mInflater.inflate(R.layout.schedule_label, null);
            ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(lableWidth, labelHeight);
            labelView.setLayoutParams(layoutParams);
            renderLabel(labelView, item);
            topPanel.addView(labelView);
            labelView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ScrollView scrollView = (ScrollView) findViewById(R.id.scrollView);
                    scrollView.smoothScrollTo(0, itemView.getTop());
                }
            });
        }
    }

    private void initSwitchListener(Switch sw, final int week, final String tag) {
        sw.setTag(tag);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                HashMap item = (HashMap) mData.get(week);
                item.put(tag, isChecked);

                View labelView = topPanel.getChildAt(week);
                renderLabel(labelView, item);

                xhrSave();
            }
        });
    }

    private void renderLabel(View labelView, HashMap item) {
        Boolean amValue = (Boolean) item.get("am");
        Boolean pmValue = (Boolean) item.get("pm");
        Boolean niValue = (Boolean) item.get("ni");
        TextView textWeek = (TextView) labelView.findViewById(R.id.week);
        ArcView arcView = (ArcView) labelView.findViewById(R.id.arcView);

        textWeek.setText((String) item.get("title"));
        arcView.setData(amValue, pmValue, niValue);

        if (amValue || pmValue || niValue) {
            textWeek.setTextColor(getResources().getColor(R.color.brand_b));
        } else {
            textWeek.setTextColor(getResources().getColor(R.color.grey_b));
        }
    }
}
