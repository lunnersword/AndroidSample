package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.UserItem;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by fufeng on 15/12/20.
 */
public class SquareUserListAdapter extends RecyclerView.Adapter<SquareUserListAdapter.ViewHolder> {
    private List<UserItem> data = new ArrayList<>();
    private Context mContext;

    public SquareUserListAdapter(Context context, List<UserItem> data) {
        mContext = context;
        setData(data);
    }

    public void setData(List<UserItem> data) {
        this.data = data;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_square_user, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final UserItem item = data.get(position);
        if (!TextUtils.isEmpty(item.getUserAvatar())) {
            String cdnUrl = ImgUtil.getCDNUrlWithWidth(item.getUserAvatar(),
                    mContext.getResources().getDimensionPixelSize(R.dimen.square_user_icon_size));
            holder.userAvatar.setImageURI(Uri.parse(cdnUrl));
        } else {
            holder.userAvatar.setImageURI(ImgUtil.getDefaultAvatarUri(mContext,
                    item.getUserId(), item.getUserGender()));
        }
        holder.userName.setText(item.getUserName());

        if (!TextUtils.isEmpty(item.getUserDesc())) {
            holder.userDesc.setText(item.getUserDesc());
            holder.userDesc.setVisibility(View.VISIBLE);
        } else {
            holder.userDesc.setVisibility(View.GONE);
        }

        if (Constant.GENDER_MAN.equals(item.getUserGender())) {
            holder.genderIcon.setText(R.string.icon_gender_m);
            holder.genderIcon.setTextColor(mContext.getResources().getColor(R.color.brand_i));
        } else if (Constant.GENDER_WOMAN.equals(item.getUserGender())) {
            holder.genderIcon.setText(R.string.icon_gender_f);
            holder.genderIcon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
        } else {
            holder.genderIcon.setVisibility(View.GONE);
        }
        if (item.getIsGezhu() != null) {
            holder.isSquareOwner.setVisibility(item.getIsGezhu() ? View.VISIBLE : View.GONE);
        } else {
            holder.isSquareOwner.setVisibility(View.GONE);
        }

        if (item.getIsOnline() != null && item.getIsOnline()) {
            holder.onlineStatus.setText("在线");
        } else if (item.getLastOnlineTime() != null) {
            Long onlineTime = item.getLastOnlineTime() * 1000;
            holder.onlineStatus.setText(DateUtils.getOffsetDays(new Date().getTime(), onlineTime) + "在线");
        } else {
            holder.onlineStatus.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(item.getUserId())) {
            if (!item.getUserId().equals(Helper.sharedHelper().getUserId())) {
                holder.chatButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Router.sharedRouter().open("chat/" + item.getUserId());
                    }
                });
                holder.chatButton.setVisibility(View.VISIBLE);

                if (item.getIsOnline() != null && item.getIsOnline()) {
                    holder.chatButton.setTextColor(mContext.getResources().getColor(R.color.brand));
                } else {
                    holder.chatButton.setTextColor(mContext.getResources().getColor(R.color.grey_c));
                }
            } else {
                holder.chatButton.setVisibility(View.INVISIBLE);
            }

            holder.userAvatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("profile/" + item.getUserId());
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private SimpleDraweeView userAvatar;
        private TextView isSquareOwner;
        private TextView onlineStatus;
        private TextView userName;
        private TextView userDesc;
        private TextView chatButton;
        private TextView genderIcon;

        public ViewHolder(View itemView) {
            super(itemView);
            userDesc = (TextView) itemView.findViewById(R.id.userDesc);
            userAvatar = (SimpleDraweeView) itemView.findViewById(R.id.userAvatar);
            userName = (TextView) itemView.findViewById(R.id.userName);
            chatButton = (TextView) itemView.findViewById(R.id.chatButton);
            genderIcon = (TextView) itemView.findViewById(R.id.genderIcon);
            isSquareOwner = (TextView) itemView.findViewById(R.id.isSquareOwner);
            onlineStatus = (TextView) itemView.findViewById(R.id.onlineStatus);
        }
    }
}
