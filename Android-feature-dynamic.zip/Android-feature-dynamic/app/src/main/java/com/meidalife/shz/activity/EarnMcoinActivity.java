package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.usepropeller.routable.Router;

/**
 * Created by shijian on 15/7/9.
 */
public class EarnMcoinActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.earn_mcoin);
        initActionBar(R.string.title_earn_mcoin, true);

        if (!Helper.sharedHelper().hasToken()) {
            Bundle bundle = new Bundle();
            bundle.putString("action", "earn_mcoin");
            Router.sharedRouter().open("signin", bundle);
            finish();
        }

        TextView contactsIcon = (TextView) findViewById(R.id.earn_contacts_icon);
        contactsIcon.setTypeface(Helper.sharedHelper().getIconFont());
        View contacts = findViewById(R.id.earn_contacts);
        contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("earn_mcoin_contacts_intro");
            }
        });

        TextView shareIcon = (TextView) findViewById(R.id.earn_share_icon);
        shareIcon.setTypeface(Helper.sharedHelper().getIconFont());
        View share = findViewById(R.id.earn_share);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        TextView passphraseIcon = (TextView) findViewById(R.id.earn_passphrase_icon);
        passphraseIcon.setTypeface(Helper.sharedHelper().getIconFont());
        View passphrase = findViewById(R.id.earn_passphrase);
        passphrase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }
}
