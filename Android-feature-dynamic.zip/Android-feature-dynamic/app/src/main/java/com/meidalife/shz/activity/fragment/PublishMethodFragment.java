package com.meidalife.shz.activity.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.AddressesActivity;
import com.meidalife.shz.activity.PickMultiCityActivity;
import com.meidalife.shz.activity.ServiceJoinSquareActivity;
import com.meidalife.shz.activity.TimeScheduleActivity;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.model.CityItem;
import com.meidalife.shz.rest.model.ScheduleDo;
import com.meidalife.shz.rest.model.ServiceCityDo;
import com.meidalife.shz.rest.model.ServiceSquareDo;
import com.meidalife.shz.rest.model.ServiceTypeDo;
import com.meidalife.shz.rest.model.ServiceTypePropDo;
import com.meidalife.shz.rest.model.SquareItem;
import com.meidalife.shz.view.FlowLayout;
import com.meidalife.shz.widget.CheckableIconText;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by fufeng on 16/3/4.
 */
public class PublishMethodFragment extends BaseFragment {
    private int serviceType = 0;
    private String addressId;
    private boolean noScopeRestrict = true;
    private int lastSelectIndex = -1;
    private boolean isEditMode = false;
    private boolean isTimeSet = false;

    ArrayList<CityItem> cityItemArrayList = new ArrayList<>();
    ArrayList<SquareItem> squareItemArrayList = new ArrayList<>();
    View rootView;

    @Bind(R.id.cellServiceType1)
    LinearLayout cellServiceType1;
    @Bind(R.id.cellServiceType2)
    LinearLayout cellServiceType2;
    @Bind(R.id.cellServiceType3)
    LinearLayout cellServiceType3;
    @Bind(R.id.cellServiceType4)
    LinearLayout cellServiceType4;
    @Bind(R.id.imageArrowServiceType1)
    ImageView imageArrowServiceType1;
    @Bind(R.id.imageArrowServiceType2)
    ImageView imageArrowServiceType2;
    @Bind(R.id.imageArrowServiceType3)
    ImageView imageArrowServiceType3;
    @Bind(R.id.imageArrowServiceType4)
    ImageView imageArrowServiceType4;

    @Bind(R.id.cellTime)
    ViewGroup cellTime;
    @Bind(R.id.textTimeContent)
    TextView textTimeContent;
    @Bind(R.id.cellAddress)
    ViewGroup cellAddress;
    @Bind(R.id.textAddressContent)
    TextView textAddressContent;

    @Bind(R.id.serviceScopeLayout)
    ViewGroup serviceScopeLayout;
    @Bind(R.id.serviceScopeRestrict)
    TextView serviceScopeRestrict;
    @Bind(R.id.serviceNoRestrict)
    TextView serviceNoRestrict;
    @Bind(R.id.serviceCityRestrict)
    ViewGroup serviceCityRestrict;
    @Bind(R.id.serviceScopeOption)
    ViewGroup serviceScopeOption;
    @Bind(R.id.serviceCityCheckBox)
    CheckableIconText serviceCityCheckBox;
    @Bind(R.id.selectLabelTags)
    FlowLayout selectCityLabelTags;
    @Bind(R.id.serviceSquareRestrict)
    ViewGroup serviceSquareRestrict;
    @Bind(R.id.squareHelp)
    TextView squareHelp;
    @Bind(R.id.serviceSquareCheckBox)
    CheckableIconText serviceSquareCheckBox;
    @Bind(R.id.selectSquareLabelTags)
    FlowLayout selectSquareLabelTags;

    private ServiceTypeDo serviceTypeDo;

    public static PublishMethodFragment newInstance(Bundle arg) {
        PublishMethodFragment fragment = new PublishMethodFragment();
        fragment.setArguments(arg);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (null == rootView) {
            rootView = inflater.inflate(R.layout.fragment_publish_method, container, false);
            ButterKnife.bind(this, rootView);
            initComponent();
        }
        return rootView;
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bundle bundle;
        switch (requestCode) {
            case Constant.REQUEST_CODE_TIME_MANAGE:
                if (resultCode == Activity.RESULT_OK) {
                    bundle = data.getExtras();
                    ArrayList<ScheduleDo> schedule = bundle.getParcelableArrayList("schedule");
                    if (null != schedule && !schedule.isEmpty()) {
                        serviceTypeDo.setSchedule(schedule);
                        textTimeContent.setText("设置完成");
                        isTimeSet = true;
                    }
                }
                break;
            case Constant.REQUEST_CODE_PICK_ADDRESS:
                if (resultCode == Activity.RESULT_OK) {
                    bundle = data.getExtras();
                    AddressItem addressItem = (AddressItem) bundle.getSerializable(Constant.EXTRA_TAG_ADDRESS);
                    addressId = addressItem.getAddressId();
                    textAddressContent.setText(addressItem.getAddressName());
                    lastSelectIndex = bundle.getInt("lastSelectIndex");
                }
                if (resultCode == Activity.RESULT_CANCELED) {
                    bundle = data.getExtras();
                    if (bundle != null) {
                        lastSelectIndex = bundle.getInt("lastSelectIndex");
                    }
                }

                break;
            case Constant.REQUEST_CODE_PICK_MULTI_CITY: {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    cityItemArrayList = data.getParcelableArrayListExtra(Constant.EXTRA_TAG_CITY_LIST);
                    updateCityTags();
                }
                break;
            }
            case Constant.REQUEST_CODE_PICK_SQUARE: {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    squareItemArrayList = data.getParcelableArrayListExtra(Constant.EXTRA_TAG_SQUARE_LIST);
                    updateSquareTags();
                }
                break;
            }
            default:
        }
    }

    @OnClick(R.id.cellServiceType1)
    public void handleSelectType1(View view) {
        ServiceTypePropDo serviceTypePropDo = (ServiceTypePropDo) view.getTag();

        if (!serviceTypePropDo.isEnable()) {
            MessageUtils.showToast("该类目不支持去TA那");
            return;
        }
        initServiceSupportOption(serviceTypePropDo);
        cellServiceType1.setSelected(true);
        cellServiceType2.setSelected(false);
        cellServiceType3.setSelected(false);
        cellServiceType4.setSelected(false);
        imageArrowServiceType1.setVisibility(View.VISIBLE);
        imageArrowServiceType2.setVisibility(View.INVISIBLE);
        imageArrowServiceType3.setVisibility(View.INVISIBLE);
        imageArrowServiceType4.setVisibility(View.INVISIBLE);
        serviceType = Constant.SERVICE_TYPE_VISIT;
    }

    @OnClick(R.id.cellServiceType2)
    public void handleSelectType2(View view) {
        ServiceTypePropDo serviceTypePropDo = (ServiceTypePropDo) view.getTag();
        if (!serviceTypePropDo.isEnable()) {
            MessageUtils.showToast("该类目不支持来我这");
            return;
        }
        initServiceSupportOption(serviceTypePropDo);

        cellServiceType1.setSelected(false);
        cellServiceType2.setSelected(true);
        cellServiceType3.setSelected(false);
        cellServiceType4.setSelected(false);
        imageArrowServiceType1.setVisibility(View.INVISIBLE);
        imageArrowServiceType2.setVisibility(View.VISIBLE);
        imageArrowServiceType3.setVisibility(View.INVISIBLE);
        imageArrowServiceType4.setVisibility(View.INVISIBLE);
        serviceType = Constant.SERVICE_TYPE_COME;
    }

    @OnClick(R.id.cellServiceType3)
    public void handleSelectType3(View view) {
        ServiceTypePropDo serviceTypePropDo = (ServiceTypePropDo) view.getTag();
        if (!serviceTypePropDo.isEnable()) {
            MessageUtils.showToast("该类目不支持线上");
            return;
        }
        initServiceSupportOption(serviceTypePropDo);
        cellServiceType1.setSelected(false);
        cellServiceType2.setSelected(false);
        cellServiceType3.setSelected(true);
        cellServiceType4.setSelected(false);
        imageArrowServiceType1.setVisibility(View.INVISIBLE);
        imageArrowServiceType2.setVisibility(View.INVISIBLE);
        imageArrowServiceType3.setVisibility(View.VISIBLE);
        imageArrowServiceType4.setVisibility(View.INVISIBLE);
        serviceType = Constant.SERVICE_TYPE_ONLINE;
    }

    @OnClick(R.id.cellServiceType4)
    public void handleSelectType4(View view) {
        ServiceTypePropDo serviceTypePropDo = (ServiceTypePropDo) view.getTag();
        if (!serviceTypePropDo.isEnable()) {
            MessageUtils.showToast("该类目不支持邮寄");
            return;
        }
        initServiceSupportOption(serviceTypePropDo);
        cellServiceType1.setSelected(false);
        cellServiceType2.setSelected(false);
        cellServiceType3.setSelected(false);
        cellServiceType4.setSelected(true);
        imageArrowServiceType1.setVisibility(View.INVISIBLE);
        imageArrowServiceType2.setVisibility(View.INVISIBLE);
        imageArrowServiceType3.setVisibility(View.INVISIBLE);
        imageArrowServiceType4.setVisibility(View.VISIBLE);
        serviceType = Constant.SERVICE_TYPE_POST;
    }

    @OnClick(R.id.cellTime)
    public void handlePickTime(View view) {
        Intent intent = new Intent();
        intent.putParcelableArrayListExtra("schedule", serviceTypeDo.getSchedule());
        intent.setClass(getActivity(), TimeScheduleActivity.class);
        startActivityForResult(intent, Constant.REQUEST_CODE_TIME_MANAGE);
    }

    @OnClick(R.id.serviceScopeRestrict)
    public void serviceScopeRestrictOnClick(View view) {
        serviceScopeRestrict.setSelected(true);
        serviceScopeRestrict.setTextColor(getResources().getColor(R.color.brand_c));
        serviceNoRestrict.setTextColor(getResources().getColor(R.color.grey_f));
        serviceNoRestrict.setSelected(false);
        serviceScopeLayout.setVisibility(View.VISIBLE);
        serviceScopeOption.setVisibility(View.VISIBLE);
        noScopeRestrict = false;
    }

    @OnClick(R.id.serviceNoRestrict)
    public void serviceNoRestrictOnClick(View view) {
        serviceScopeRestrict.setSelected(false);
        serviceScopeRestrict.setTextColor(getResources().getColor(R.color.grey_f));
        serviceNoRestrict.setTextColor(getResources().getColor(R.color.brand_c));
        serviceNoRestrict.setSelected(true);
        serviceScopeOption.setVisibility(View.GONE);
        noScopeRestrict = true;
    }

    @OnClick(R.id.serviceCityRestrict)
    public void handleServiceCityRestrict(View view) {
        serviceCityCheckBox.setChecked(!serviceCityCheckBox.isChecked());
        if (serviceCityCheckBox.isChecked()) {
            updateCityTags();
            selectCityLabelTags.setVisibility(View.VISIBLE);
            serviceSquareCheckBox.setChecked(false);
            selectSquareLabelTags.setVisibility(View.GONE);
        } else {
            selectCityLabelTags.setVisibility(View.GONE);
        }
    }

    @OnClick(R.id.serviceSquareRestrict)
    public void handleServiceSquareRestrict(View view) {
        serviceSquareCheckBox.setChecked(!serviceSquareCheckBox.isChecked());
        if (serviceSquareCheckBox.isChecked()) {
            updateSquareTags();
            selectSquareLabelTags.setVisibility(View.VISIBLE);
            serviceCityCheckBox.setChecked(false);
            selectCityLabelTags.setVisibility(View.GONE);
        } else {
            selectSquareLabelTags.setVisibility(View.GONE);
        }
    }

    @OnClick(R.id.cellAddress)
    public void selectServiceAddress() {
        Intent intent = new Intent();
        intent.setClass(getActivity(), AddressesActivity.class);
        intent.putExtra("lastSelectIndex", lastSelectIndex);
        startActivityForResult(intent, Constant.REQUEST_CODE_PICK_ADDRESS);
    }

    private void initServiceType(ServiceTypePropDo serviceTypePropDo) {
        switch (serviceTypePropDo.getType()) {
            case Constant.SERVICE_TYPE_VISIT: {
                cellServiceType1.setTag(serviceTypePropDo);
                if (serviceTypePropDo.isSelected()) {
                    handleSelectType1(cellServiceType1);
                }
                if (!serviceTypePropDo.isEnable()) {
                    cellServiceType1.setVisibility(View.INVISIBLE);
                    imageArrowServiceType1.setVisibility(View.INVISIBLE);
                }
                break;
            }
            case Constant.SERVICE_TYPE_COME: {
                cellServiceType2.setTag(serviceTypePropDo);
                if (serviceTypePropDo.isSelected()) {
                    handleSelectType2(cellServiceType2);
                }
                if (!serviceTypePropDo.isEnable()) {
                    cellServiceType2.setVisibility(View.INVISIBLE);
                    imageArrowServiceType2.setVisibility(View.INVISIBLE);
                }
                break;
            }
            case Constant.SERVICE_TYPE_ONLINE: {
                cellServiceType3.setTag(serviceTypePropDo);
                if (serviceTypePropDo.isSelected()) {
                    handleSelectType3(cellServiceType3);
                }
                if (!serviceTypePropDo.isEnable()) {
                    cellServiceType3.setVisibility(View.INVISIBLE);
                    imageArrowServiceType3.setVisibility(View.INVISIBLE);
                }
                break;
            }
            case Constant.SERVICE_TYPE_POST: {
                cellServiceType4.setTag(serviceTypePropDo);
                if (serviceTypePropDo.isSelected()) {
                    handleSelectType4(cellServiceType4);
                }
                if (!serviceTypePropDo.isEnable()) {
                    cellServiceType4.setVisibility(View.INVISIBLE);
                    imageArrowServiceType4.setVisibility(View.INVISIBLE);
                }
                break;
            }
        }
    }

    private void initServiceSupportOption(ServiceTypePropDo serviceTypePropDo) {
        cellTime.setVisibility((serviceTypePropDo.getSupport() & ServiceTypePropDo.SUPPORT_TIME)
                == ServiceTypePropDo.SUPPORT_TIME ? View.VISIBLE : View.GONE);

        cellAddress.setVisibility((serviceTypePropDo.getSupport() & ServiceTypePropDo.SUPPORT_ADDRESS)
                == ServiceTypePropDo.SUPPORT_ADDRESS ? View.VISIBLE : View.GONE);
        if ((serviceTypePropDo.getSupport() & ServiceTypePropDo.SUPPORT_CITY) == ServiceTypePropDo.SUPPORT_CITY
                || (serviceTypePropDo.getSupport() & ServiceTypePropDo.SUPPORT_SQUARE)
                == ServiceTypePropDo.SUPPORT_SQUARE) {
            serviceScopeLayout.setVisibility(View.VISIBLE);
            serviceCityRestrict.setVisibility((serviceTypePropDo.getSupport() & ServiceTypePropDo.SUPPORT_CITY)
                    == ServiceTypePropDo.SUPPORT_CITY ? View.VISIBLE : View.GONE);
            serviceSquareRestrict.setVisibility((serviceTypePropDo.getSupport() & ServiceTypePropDo.SUPPORT_SQUARE)
                    == ServiceTypePropDo.SUPPORT_SQUARE ? View.VISIBLE : View.GONE);

            if (!noScopeRestrict) {
                serviceScopeOption.setVisibility(View.VISIBLE);
            } else {
                serviceScopeOption.setVisibility(View.GONE);
            }
        } else {
            serviceScopeLayout.setVisibility(View.GONE);
        }
    }

    private void initComponent() {
        serviceTypeDo = getArguments().getParcelable(Constant.EXTRA_TAG_SERVICE_TYPE);
        isEditMode = getArguments().getBoolean(Constant.EXTRA_TAG_EDIT_MODE);
        if (null == serviceTypeDo) {
            return;
        }

        List<ServiceTypePropDo> serviceTypePropDoList = serviceTypeDo.getTypeList();
        for (ServiceTypePropDo serviceTypePropDo : serviceTypePropDoList) {
            initServiceType(serviceTypePropDo);
        }

        if (isEditMode) {
            if (serviceTypeDo.getGeziScope() == 0 && serviceTypeDo.getCities() != null
                    && !serviceTypeDo.getCities().isEmpty()) {
                cityItemArrayList.clear();
                for (ServiceCityDo serviceCityDo : serviceTypeDo.getCities()) {
                    CityItem item = new CityItem();
                    item.setName(serviceCityDo.getName());
                    item.setCode(serviceCityDo.getCode());
                    cityItemArrayList.add(item);
                }
                serviceScopeRestrictOnClick(null);
                handleServiceCityRestrict(null);
            } else if (serviceTypeDo.getGeziScope() == 1 && serviceTypeDo.getGezis() != null
                    && !serviceTypeDo.getGezis().isEmpty()) {
                squareItemArrayList.clear();
                for (ServiceSquareDo serviceSquareDo : serviceTypeDo.getGezis()) {
                    SquareItem item = new SquareItem();
                    item.setGeziId(serviceSquareDo.getGeziId());
                    item.setGeziName(serviceSquareDo.getGeziName());
                    squareItemArrayList.add(item);
                }
                serviceScopeRestrictOnClick(null);
                handleServiceSquareRestrict(null);
            } else {
                serviceNoRestrictOnClick(null);
            }

            if (serviceTypeDo.getAddress() != null) {
                addressId = serviceTypeDo.getAddress().getAddressId();
                textAddressContent.setText(serviceTypeDo.getAddress().getAddressName());
            }
        } else {
            serviceScopeLayout.setVisibility(View.GONE);
            cellTime.setVisibility(View.GONE);
            cellAddress.setVisibility(View.GONE);
        }

        squareHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", Constant.KONGGE_BASE_URL + "support/publish_gezi.html");
                Router.sharedRouter().open("web", bundle);
            }
        });
    }

    private void updateCityTags() {
        selectCityLabelTags.removeAllViews();
        for (CityItem cityItem : cityItemArrayList) {
            selectCityLabelTags.addView(getTagView(selectCityLabelTags, cityItem.getName(),
                    R.color.brand, R.color.brand_c, null));
        }
        selectCityLabelTags.addView(getTagView(selectCityLabelTags, "编辑", R.color.grey_d,
                R.color.grey_l, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent();
                        intent.setClass(getActivity(), PickMultiCityActivity.class);
                        intent.putParcelableArrayListExtra(Constant.EXTRA_TAG_CITY_LIST, cityItemArrayList);
                        startActivityForResult(intent, Constant.REQUEST_CODE_PICK_MULTI_CITY);
                    }
                }));
    }

    private void updateSquareTags() {
        selectSquareLabelTags.removeAllViews();
        for (SquareItem squareItem : squareItemArrayList) {
            selectSquareLabelTags.addView(getTagView(selectSquareLabelTags, squareItem.getGeziName(),
                    R.color.brand, R.color.brand_c, null));
        }
        selectSquareLabelTags.addView(getTagView(selectSquareLabelTags, "编辑", R.color.grey_d,
                R.color.grey_l, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent();
                        intent.setClass(getActivity(), ServiceJoinSquareActivity.class);
                        intent.putParcelableArrayListExtra(Constant.EXTRA_TAG_SQUARE_LIST, squareItemArrayList);
                        intent.putExtra("type", ServiceJoinSquareActivity.SELECT_SQUARES);
                        startActivityForResult(intent, Constant.REQUEST_CODE_PICK_SQUARE);
                    }
                }));
    }

    private View getTagView(FlowLayout parent, String name, int bgColorId,
                            int fontColorId, View.OnClickListener listener) {
        TextView title = (TextView) LayoutInflater.from(getActivity()).
                inflate(R.layout.item_service_scope_tag, parent, false);
        title.setBackgroundColor(getResources().getColor(bgColorId));
        title.setTextColor(getResources().getColor(fontColorId));
        title.setText(name);
        title.setOnClickListener(listener);
        return title;
    }

    public boolean checkParam() {
        if (serviceType <= 0) {
            MessageUtils.showToastCenter("请选择服务方式");
            return false;
        }
        if (serviceCityCheckBox.isChecked() && (cityItemArrayList == null
                || cityItemArrayList.isEmpty())) {
            MessageUtils.showToastCenter("请选择服务城市");
            return false;
        }
        if (serviceSquareCheckBox.isChecked() && (squareItemArrayList == null
                || squareItemArrayList.isEmpty())) {
            MessageUtils.showToastCenter("请选择可服务格子");
            return false;
        }
        for (ServiceTypePropDo serviceTypePropDo : serviceTypeDo.getTypeList()) {
            if (serviceType == serviceTypePropDo.getType()) {
                if (((serviceTypePropDo.getSupport() & ServiceTypePropDo.SUPPORT_TIME)
                        == ServiceTypePropDo.SUPPORT_TIME)) {
                    if (!isEditMode && !isTimeSet) {
                        MessageUtils.showToastCenter("请设置选择服务时间");
                        return false;
                    }
                }
                if (((serviceTypePropDo.getSupport() & ServiceTypePropDo.SUPPORT_ADDRESS)
                        == ServiceTypePropDo.SUPPORT_ADDRESS) && TextUtils.isEmpty(addressId)) {
                    MessageUtils.showToastCenter("请选择服务地址");
                    return false;
                }
            }
        }
        return true;
    }

    public JSONObject getServiceTypeParam() {
        JSONObject params = new JSONObject();
        if (serviceType > 0) {
            params.put("serviceType", serviceType);
        }
        params.put("addressId", addressId);

        if (!cityItemArrayList.isEmpty() && !noScopeRestrict &&
                serviceCityCheckBox.isChecked()) {
            JSONArray cityArray = new JSONArray();
            for (CityItem item : cityItemArrayList) {
                cityArray.add(item.getCode());
            }
            params.put("cityCodes", cityArray);
        }

        if (!squareItemArrayList.isEmpty() && !noScopeRestrict
                && serviceSquareCheckBox.isChecked()) {
            JSONArray squareArray = new JSONArray();
            for (SquareItem item : squareItemArrayList) {
                squareArray.add(item.getGeziId());
            }
            params.put("geziScope", 1);
            params.put("geziIds", squareArray);
        }

        if (!serviceTypeDo.getSchedule().isEmpty()) {
            JSONArray scheduleArray = new JSONArray();
            for (int i = 0; i < serviceTypeDo.getSchedule().size(); i++) {
                JSONObject jsonObject = new JSONObject();
                ScheduleDo scheduleDo = serviceTypeDo.getSchedule().get(i);
                jsonObject.put("type", scheduleDo.getType());
                jsonObject.put("value", scheduleDo.getValue());
                jsonObject.put("capability", scheduleDo.getCapability());
                scheduleArray.add(jsonObject);
            }
            params.put("schedule", scheduleArray.toJSONString());
        }
        return params;
    }
}
