package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.DynamicTabDO;

import java.util.ArrayList;


/**
 * Created by zuozheng on 16/04/02.
 * 动态详情tab导航
 */
public class DynamicDetailNavTabAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private ArrayList<DynamicTabDO> tabList;
    private Context mContext;

//    private boolean hasNewMsg;

    public DynamicDetailNavTabAdapter(Context mContext, ArrayList<DynamicTabDO> tabList) {
        this.mInflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
        this.tabList = tabList;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return tabList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        DynamicTabDO cate = tabList.get(position);
        if (convertView == null) {
            //需要使用相对布局 实现小红点更新逻辑
            convertView = mInflater.inflate(R.layout.item_dynamic_detail_nav_tab, parent, false);
            holder = new ViewHolder();
            holder.filterTab = (TextView) convertView.findViewById(R.id.filterTab);
            holder.countView = (TextView) convertView.findViewById(R.id.countView);
            holder.bottomView = convertView.findViewById(R.id.bottomView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.filterTab.setText(cate.getTabName());
        if (cate.getCount() > 0) {
            holder.countView.setText(String.valueOf(cate.getCount()));
        } else {
            holder.countView.setText("");
        }

        if (cate.isSelected()) {
            holder.bottomView.setVisibility(View.VISIBLE);
            holder.filterTab.setTextColor(mContext.getResources().getColor(R.color.brand_c));
            holder.countView.setTextColor(mContext.getResources().getColor(R.color.brand_c));
        } else {
            holder.bottomView.setVisibility(View.INVISIBLE);
            holder.filterTab.setTextColor(mContext.getResources().getColor(R.color.grey_j));
            holder.countView.setTextColor(mContext.getResources().getColor(R.color.grey_j));
        }

        return convertView;
    }

    static class ViewHolder {
        TextView filterTab;
        TextView countView;
        View bottomView;
    }
}
