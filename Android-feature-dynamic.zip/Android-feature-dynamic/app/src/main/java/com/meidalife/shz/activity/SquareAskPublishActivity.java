package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.request.RequestSquareAsk;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.FontEditText;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.widget.TutorialPopupWindow;
import com.usepropeller.routable.Router;

public class SquareAskPublishActivity extends BaseActivity {

    private final static int REQUEST_CATEGORY = 10;
    private final static int MAX_TITLE_NUMS = 5;
    private final static int MAX_DESC_NUMS = 120;

    private SimpleDraweeView imageAvatar;
    private FontEditText title;
    private FontTextView remainTitleCount;
    private FontEditText desc;
    private FontTextView remainDescCount;
    private FontTextView catName;
    private View catLine;
    private View catView;
    private int catid;
    private int geziId = -1;
    private FontTextView validDays;
    private TextView validDaysWarn;
    //默认为3天
    private int validDaysNum = 3;
    private FontTextView publishDemand;
    private int titleLength;
    private int descLength;
    private int lastSelectIndex = -1;
    private TutorialPopupWindow tutorialPopupWindow;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CATEGORY && resultCode == RESULT_OK) {
            if (data != null) {
                Bundle bundle = data.getExtras();
                catName.setText(bundle.getString("catName"));
                catName.setTextColor(getResources().getColor(R.color.gezi_blue));
                catid = bundle.getInt("catid");
                lastSelectIndex = bundle.getInt("lastSelectIndex");
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_ask_publish);
        initActionBar(R.string.title_activity_publish_demand, true);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            geziId = TextUtils.isEmpty(bundle.getString("geziId"))?geziId:Integer.parseInt(bundle.getString("geziId"));
        }
        findView();
        bindListener();
        initCatView();
        RequestSquareAsk.getUserAvatar(new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                Log.d("mzLog", "userData: " + obj.toString());
                JSONObject data = (JSONObject) obj;
                String avatarUrl = data.getString("picUrl");

                //头像图片为空 显示默认图片
                if (TextUtils.isEmpty(avatarUrl)) {
                    String gender = data.getString("gender");
                    Uri uri = ImgUtil.getDefaultAvatarUri(SquareAskPublishActivity.this, data.getString("userId"), gender);
                    imageAvatar.setImageURI(uri);
                } else {
                    imageAvatar.setImageURI(Uri.parse(avatarUrl));
                }
            }

            @Override
            public void onFail(HttpError error) {
                Log.d("mzLog", "userData: fetch failed");
            }
        });

    }

    private void findView() {

        imageAvatar = (SimpleDraweeView) findViewById(R.id.imageAvatar);
        title = (FontEditText) findViewById(R.id.title);
        remainTitleCount = (FontTextView) findViewById(R.id.remainTitleCount);
        desc = (FontEditText) findViewById(R.id.desc);
        remainDescCount = (FontTextView) findViewById(R.id.remainDescCount);
        catName = (FontTextView) findViewById(R.id.catId);
        validDays = (FontTextView) findViewById(R.id.validDays);
        publishDemand = (FontTextView) findViewById(R.id.publishDemand);
        catLine = findViewById(R.id.catLine);
        catView = findViewById(R.id.catView);
        validDaysWarn = (TextView)findViewById(R.id.validDaysWarn);

    }

    //判断是否该显示类型选择
    private void initCatView(){
        RequestSquareAsk.getCategoryList(new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                if(obj == null)
                    return;
                if(obj instanceof JSONArray){
                    if(((JSONArray)obj).size() > 0){
                        catLine.setVisibility(View.VISIBLE);
                        catView.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onFail(HttpError error) {
            }
        });
    }

    private void bindListener() {

        title.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                titleLength = title.length();
                remainTitleCount.setText(titleLength + "/" + MAX_TITLE_NUMS);
                if (titleLength > MAX_TITLE_NUMS) {
                    title.setText(title.getText().toString().substring(0, MAX_TITLE_NUMS));
                    MessageUtils.showToast("已超出" + MAX_TITLE_NUMS + "个字符。");
                }

            }
        });

        desc.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                descLength = desc.length();
                remainDescCount.setText(descLength + "/" + MAX_DESC_NUMS);
                if (descLength > MAX_DESC_NUMS) {
                    desc.setText(desc.getText().toString().substring(0, MAX_DESC_NUMS));
                    MessageUtils.showToast("已超出" + MAX_DESC_NUMS + "个字符。");
                }
            }
        });

        publishDemand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkStatus()) {
                    showProgressDialog("正在发布", false);
                    JSONObject params = new JSONObject();
                    params.put("title", title.getText());
                    params.put("desc", desc.getText());
                    params.put("catId", catid);
                    params.put("validDays", validDaysNum);
                    params.put("geziId", geziId);
                    Log.d("mzLog", "params: " + params.toString());

                    RequestSquareAsk.addDemand(params, new HttpClient.HttpCallback() {
                        @Override
                        public void onSuccess(Object obj) {
                            hideProgressDialog();
                            showTutorial();
                            setResult(RESULT_OK);
                            //finish();
                        }

                        @Override
                        public void onFail(HttpError error) {
                            hideProgressDialog();
                            MessageUtils.showToast(error.getMessage());
                        }
                    });
                }
            }
        });
    }

    public void handleCatId(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("lastSelectIndex", lastSelectIndex);
        Router.sharedRouter().openFormResult("squareAskChooseCategory", bundle, REQUEST_CATEGORY, this);

    }

    public void handleValidDay(View view) {
        Dialog dialog = createValidDays();
        dialog.show();
    }

    private Dialog createValidDays() {
        final String[] chooseItem = {"1天", "2天", "3天", "4天", "5天", "6天", "7天"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setItems(chooseItem, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                validDays.setText(chooseItem[which]);
                validDays.setTextColor(getResources().getColor(R.color.gezi_blue));
                validDaysWarn.setText(String.format(getResources().getString(R.string.text_square_ask_valid_days_warn), chooseItem[which]));
                validDaysNum = which + 1;
                Log.d("mzLog: ", "" + which);
            }
        });

        return builder.create();
    }

    private boolean checkStatus() {

        if (title.getText().length() == 0) {
            MessageUtils.showToast("还没有输入标题哦");
            return false;
        }
        if (desc.getText().length() == 0) {
            MessageUtils.showToast("还没有输入服务描述哦");
            return false;
        }
//        if (catName.getText().equals("未选择")) {
//            MessageUtils.showToast("还没有选择服务类型哦");
//            return false;
//        }
        if (validDays.getText().equals("未选择")) {
            MessageUtils.showToast("还没有选择有效日哦");
            return false;
        }
        return true;
    }

    private void showTutorial() {
        try {
            if (tutorialPopupWindow == null) {
                tutorialPopupWindow = new TutorialPopupWindow(this,
                        TutorialPopupWindow.TUTORIAL_TYPE_CUSTOMIZE);
                tutorialPopupWindow.addTutorialItems(new TutorialPopupWindow.TutorialItem(null,
                        getString(R.string.tutorial_response), null,
                        R.mipmap.tutorial_response, getString(R.string.i_know)));
                tutorialPopupWindow.setOnFinishListener(new TutorialPopupWindow.OnFinishListener() {
                    @Override
                    public void onFinish() {
                        finish();
                    }
                });
            }
            if (!tutorialPopupWindow.isShowing() && !isFinishing()) {
                tutorialPopupWindow.showTutorial(title);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
