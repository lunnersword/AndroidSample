package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;

/**
 * Created by xingchen on 2015/12/23.
 */
public class SquareManageTelephoneAdapter extends BaseAdapter{

    private LayoutInflater mInflater;
    private JSONArray phoneList;

    public SquareManageTelephoneAdapter(Context context,JSONArray phoneList){
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.phoneList = phoneList;
    }

    @Override
    public int getCount() {
        return phoneList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.item_square_manage_telephone,parent,false);
            holder = new ViewHolder();
            holder.textPhone = (TextView)convertView.findViewById(R.id.textPhone);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder)convertView.getTag();
        }
        JSONObject item = phoneList.getJSONObject(position);
        StringBuffer sb = new StringBuffer();
        if(item.containsKey("name"))
            sb.append(item.getString("name")+"：");
        if(item.containsKey("mobile"))
            sb.append(item.getString("mobile"));
        holder.textPhone.setText(sb.toString());
        return convertView;
    }

    static class ViewHolder{
        TextView textPhone;
    }
}
