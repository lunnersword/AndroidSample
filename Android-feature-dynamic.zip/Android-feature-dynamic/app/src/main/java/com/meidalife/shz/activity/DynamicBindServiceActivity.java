package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.DynamicBindMyPaidServiceFragment;
import com.meidalife.shz.activity.fragment.DynamicBindMyPubServiceFragment;
import com.meidalife.shz.rest.model.Service4DynamicDO;
import com.usepropeller.routable.Router;

import java.util.HashMap;
import java.util.Map;

import butterknife.OnClick;

/**
 * 选择关联服务
 * Created by zuozheng on 16/04／06
 */

public class DynamicBindServiceActivity extends BaseActivity {


    public final int TYPE_SERVICE_ME = 1; // 我发布服务
    public final int TYPE_SERVICE_PAY = 2; //我购买的服务

    private FragmentManager mFragmentManager;

    private int selectType = TYPE_SERVICE_ME;

    public DynamicBindMyPubServiceFragment mServiceFragment;
    public DynamicBindMyPaidServiceFragment mPaidServiceFragment;

    private Map<View, TextView> barMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_bind_service);

        initActionBar("选择关联服务", true, true);//统一继承BaseActivity风格

        mButtonRight.setText(R.string.save);
        mButtonRight.setBackgroundColor(getResources().getColor(R.color.brand));

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handlePick(v);
            }
        });

        mFragmentManager = getSupportFragmentManager();
        initBar();
        updateContentView(selectType);
    }

    void initBar() {

        View.OnClickListener orderTypeClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (Map.Entry<View, TextView> e : barMap.entrySet()) {
                    View onView = e.getKey();
                    TextView label = e.getValue();
                    if (onView == v) {
                        onView.setBackgroundResource(R.drawable.order_list_type_bottom);
                        label.setTextColor(getResources().getColor(R.color.brand_c));
                        selectType = (Integer) onView.getTag();
                    } else {
                        onView.setBackgroundResource(R.color.white);
                        label.setTextColor(getResources().getColor(R.color.grey_a));
                    }
                }
                updateContentView(selectType);
            }
        };

        View officialAuthView = findViewById(R.id.title_left);
        TextView allLabel = (TextView) findViewById(R.id.title_left_label);
        barMap.put(officialAuthView, allLabel);
        officialAuthView.setTag(TYPE_SERVICE_ME);
        officialAuthView.setBackgroundResource(R.drawable.order_list_type_bottom);
        allLabel.setTextColor(getResources().getColor(R.color.brand_c));
        officialAuthView.setOnClickListener(orderTypeClick);


        View personalAuthView = findViewById(R.id.title_right);
        TextView acceptLabel = (TextView) findViewById(R.id.title_right_label);
        barMap.put(personalAuthView, acceptLabel);
        personalAuthView.setTag(TYPE_SERVICE_PAY);
        personalAuthView.setBackgroundResource(R.color.white);
        acceptLabel.setTextColor(getResources().getColor(R.color.grey_a));
        personalAuthView.setOnClickListener(orderTypeClick);
    }

    private void updateContentView(int selectType) {

        if (selectType == TYPE_SERVICE_ME) {
            mServiceFragment = new DynamicBindMyPubServiceFragment();
            mFragmentManager.beginTransaction().replace(R.id.content_frame, mServiceFragment)
                    .commitAllowingStateLoss();

        } else {
            mPaidServiceFragment = new DynamicBindMyPaidServiceFragment();
            mFragmentManager.beginTransaction().replace(R.id.content_frame, mPaidServiceFragment)
                    .commitAllowingStateLoss();

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().openFormResult("signin", Constant.REQUEST_CODE_SIGNIN,
                    DynamicBindServiceActivity.this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (Constant.REQUEST_CODE_SIGNIN == requestCode && resultCode == RESULT_OK) {
            updateContentView(selectType);
        } else if (Constant.REQUEST_CODE_SIGNIN == requestCode && resultCode == RESULT_CANCELED) {
            finish();
        }
    }

    @OnClick(R.id.action_bar_button_right)
    public void handlePick(View view) {
        Service4DynamicDO item = null;

        if (selectType == TYPE_SERVICE_ME) {
            item = mServiceFragment.getClickedItem();
        } else {
            item = mPaidServiceFragment.getClickedItem();
        }

        String itemId = "";
        String title = "";
        if (item != null && item.isSelected()) {
            itemId = item.getItemId();
            title = item.getItemName();
        }
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putString("itemId", itemId);
        bundle.putString("title", title);
        intent.putExtras(bundle);
        setResult(RESULT_OK, intent);
        finish();
    }


    @Override
    protected void onDestroy() {
        mFragmentManager = null;
        mPaidServiceFragment = null;
        mServiceFragment = null;
        super.onDestroy();
    }
}
