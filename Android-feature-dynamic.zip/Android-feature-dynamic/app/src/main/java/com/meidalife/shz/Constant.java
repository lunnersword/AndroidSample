package com.meidalife.shz;

import android.os.Environment;

/**
 * Created by taber on 15/6/13.
 */
public class Constant {
    public static final String KE_FU_TEL = "4006999980";
    public static final int REQUEST_CODE_PICK_ADDRESS = 10;
    public static final int REQUEST_CODE_PICK_LOCATION = 13;
    public static final int REQUEST_CODE_CREATE_ADDRESS = 11;
    public static final int REQUEST_CODE_CHANGE_ADDRESS = 14;
    public static final int REQUEST_CODE_CHANGE_GENDER = 12;
    public static final int REQUEST_CODE_CHANGE_NICKNAME = 15;
    public static final int REQUEST_CODE_CHANGE_PERSONAL_INTRODUCE = 16;
    public static final int REQUEST_CODE_CHANGE_PROFILE_LABEL = 18;
    public static final int REQUEST_CODE_CHANGE_WORK_NUMBER = 17;
    public static final int REQUEST_CODE_PICK_SERVICE = 20;
    public static final int REQUEST_CODE_PICK_PHOTO = 30;
    public static final int REQUEST_CODE_CROP_PHOTO = 31;
    public static final int REQUEST_CODE_PICK_CITY = 40;
    public static final int REQUEST_CODE_PICK_MULTI_CITY = 41;
    public static final int REQUEST_CODE_PICK_SQUARE = 42;

    public static final int REQUEST_CODE_TIME_MANAGE = 50;
    public static final int REQUEST_CODE_BARCODE_SCAN = 60;
    public static final int REQUEST_CODE_EXPRESS_COMPANY = 70;
    public static final int REQUEST_CODE_PUBLISH_OPUS = 19;
    public static final int REQUEST_CODE_PUBLISH_SERVICE = 21;

    public static final int REQUEST_CODE_REWARD = 80;
    public static final int REQUEST_CODE_REWARD_PAY = 81;
    public static final int REQUEST_CODE_SQUARE_EXAM = 90;
    public static final int REQUEST_CODE_JOIN_SQUARE = 100;
    public static final int REQUEST_CODE_ASK_DETAIL = 101;
    public static final int REQUEST_CODE_SET_SERVICE_PROP = 110;

    public static final int ADDRESS_ADAPTER_TYPE_DEFAULT = 1;
    public static final int ADDRESS_ADAPTER_TYPE_MANAGE = 2;

    public static final int REPORT_TYPE_IM = 1;
    public static final int REPORT_TYPE_USER = 2;
    public static final int REPORT_TYPE_OPUS = 3;
    public static final int REPORT_TYPE_SERVICE = 4;
    public static final int REPORT_TYPE_SERVICE_LEAVE_MESSAGE = 5;
    public static final int REPORT_TYPE_SQUARE_ASK = 6;
    public static final int REPORT_TYPE_SQUARE_ASK_REPLY = 7;
    public static final int REPORT_TYPE_SQUARE_BBS = 8;
    public static final int REPORT_TYPE_SQUARE_BBS_REPLY = 9;
    public static final int REPORT_TYPE_DYNAMIC = 10;


    public static final String DATA_GENDER = "dataGender";

    public static final String MAIN_DOMAIN_KONGGE = "kongge.com";
    public static final String KONGGE_BASE_URL = "http://www.kongge.com/";
    public static final String MAIN_DOMAIN_SHENGHUOZHE = "shenghuozhe.net";
    public static final String SHENGHUOZHE_BASE_URL = "http://www.shenghuozhe.net/";

    public static final String URL_XIEYI = "http://www.shenghuozhe.net/events/user_agreement.html";
    public static final String URL_EXPLORE = "http://www.shenghuozhe.net/market/im-explore.html";
    public static final String URL_AGGREEMENT = "http://www.shenghuozhe.net/events/app_agreement.html";
    public static final String URL_ANNOUNCEMENT = "http://www.shenghuozhe.net/market/im-announcement.html";
    public static final String URL_SPECIFICATION = "http://shenghuozhe.net/events/app_publish.html";
    public static final String URL_DOWNLOAD = "http://www.shenghuozhe.net/events/m_coin_share.html";
    public static final String URL_OFFICIAL_WEIBO = "http://m.weibo.cn/d/imshenghuozhe?jumpfrom=wapv4&tip=1";
    public static final String URL_MBILL_RULE = "http://www.shenghuozhe.net/events/m_coin.html";
    public static final String URL_CONTACTS_PRIVILEGE_INTRO = "http://www.shenghuozhe.net/events/android_contacts_privilege.html";
    public static final String URL_LOCATION_INTRO = "http://www.shenghuozhe.net/support/location_intro.html?cityName=";

    public static final String URL_CATEGORY = "http://kongge.com/category.html?_jump=cate/";

    public static final String CANCEL_ORDER_TYPE_CANCEL = "cancel";
    public static final String CANCEL_ORDER_TYPE_REJECT = "reject";

    /**
     * 从OrderDetailActivity拷贝常量值。用于未登录的状态。
     */
    public static final int REQUEST_CODE_SIGNIN = 300;
    public static final int REQUEST_CODE_PERFECT_INFO = 301;

    /**
     * 缓存在SharedPreferences中用户信息
     */
    public static final String USER_ID = "userid";
    public static final String USER_NICK = "nick";
    public static final String USER_MOBILE = "mobile";
    public static final String USER_AVATAR = "picUrl";
    public static final String USER_GENDER = "gender";

    public static final int OAUTH_TYPE_WECHAT = 1;
    public static final int OAUTH_TYPE_QQ = 2;
    public static final int OAUTH_TYPE_SINA = 3;

    public static final String GENDER_MAN = "M";
    public static final String GENDER_WOMAN = "F";
    public static final String GENDER_WOMAN_ALIAS = "woman";
    public static final String USER_PIC = "picUrl";

    public static final String APP_ID_WECHAT = "wx7fdeb2627318e526";
    public static final String APP_SECRET_WECHAT = "eaea1eb5a3cebf52b618961fde692743";
    public static final String APP_ID_QQ = "1104671453";
    public static final String APP_SECRET_QQ = "f2mEEqpglvevLQhp";

    public static final String GPS_LAT = "latitude";
    public static final String GPS_LONG = "longitude";
    public static final String LBS_NAME = "lbsName";
    //
//    public static final String LOCATE_ON = "locate_on";
//    public static final String LOCATE_CITY_CODE = "locate_city_code";
    public static final String SELECT_CITY_CODE = "select_city_code";
    public static final String SELECT_CITY_NAME = "select_city_name";
    public static final String SEARCH_HISTORY_KW = "search_history_kw";
    public static final String SELECT_CITY_CONFIRMED = "select_city_confirmed";

    public static final String UUID = "X-SHZ-UDID";

    public static final String GUIDE_INDEX = "guide_index";
    public static final String GUIDE_PROFILE = "guide_profile";
    public static final String GUIDE_SELF = "guide_self";

    public static final String AD_PICTURE_URL = "ad_picture_url";
    public static final String AD_PICTURE_LINK = "ad_picture_link";

    /**
     * Boolean 类型SharePreference值，判断是否首次打开应用
     */
    public static final String SP_FIRST_START = "first_start";

    public static final int REQUEST_CODE_PICK_RED_PAPER = 80;

    public static int MAX_IMAGE_LENGTH = 9;

    public static final int TYPE_OFFICIAL = 1; // (官方认证)
    public static final int TYPE_PERSONAL = 2; // (个人认证))


    public static final int CERT_STATUS_UNCOMMIT = -1; // 自定义状态
    public static final int CERT_STATUS_AUDIT = 1; // (审核中)
    public static final int CERT_STATUS_PASS = 2; // (审核成功)
    public static final int CERT_STATUS_DENY = 3; // (审核失败)

    public static final String TAG_DEVICE_ID = "DEVICE_ID";
    public static final String TAG_BB_ID = "BB_ID";//blackbox id

    public static final String EXTRA_TAG_SHARE_TITLE = "shareTitle";
    public static final String EXTRA_TAG_SHARE_CONTENT = "shareContent";
    public static final String EXTRA_TAG_SHARE_ICON = "shareIcon";
    public static final String EXTRA_TAG_SHARE_URL = "shareUrl";
    public static final String EXTRA_TAG_ORDER_NO = "orderNo";
    public static final String EXTRA_TAG_AMOUNT = "amount";
    public static final String EXTRA_TAG_DESC = "desc";
    public static final String EXTRA_TAG_REMARK_FLAG = "remarkFlag";
    public static final String EXTRA_TAG_REMARK_CONTENT = "remarkContent";
    public static final String EXTRA_TAG_SQUARE_ID = "geziId";

    public static final String EXTRA_TAG_ADDRESS = "address";
    public static final String EXTRA_TAG_ADDRESS_ID = "addressId";
    public static final String EXTRA_TAG_ADDRESS_STATUS = "addressStatus";

    public static final String EXTRA_TAG_CATEGORY_ID = "catId";
    public static final String EXTRA_TAG_STD_CATEGORY_ID = "stdCatId";
    public static final String EXTRA_TAG_SQUARE_LIST = "squareList";
    public static final String EXTRA_TAG_CITY_LIST = "cityList";
    public static final String EXTRA_TAG_PROP_LIST = "propList";
    public static final String EXTRA_TAG_SERVICE_CONTENT = "serviceContent";
    public static final String EXTRA_TAG_SERVICE_TYPE = "serviceType";
    public static final String EXTRA_TAG_EDIT_MODE = "editMode";
    public static final String EXTRA_TAG_TITLE = "title";
    public static final String SF_H5_ACTIVITY_STATUS = "channelH5ActivityStatus";

    public static final String REQUEST_PARAM_OFFSET = "offset";
    public static final String REQUEST_PARAM_PAGE_SIZE = "pageSize";

    public static final String SQUARE_FIRST_IN = "square_first_in";
    public static final String SQUARE_HOME_FIRST_IN = "square_home_first_in";


    public static final int SQUARE_LIST_PIN_TYPE_SERVICE = 1;  //找找看置顶
    public static final int SQUARE_LIST_PIN_TYPE_ASK = 2;   //帮帮忙置顶
    public static final int SQUARE_LIST_PIN_TYPE_BBS = 3;   //聊聊天置顶

    public static final String LOCATION_SQUARE_ENABLED = "square_enabled";
    public static final String SELECT_CITY_SQUARE_ENABLED = "select_city_square_enabled";

    public static final int SQUARE_SURROUND_ITEM_TYPE_SERVICE = 1;
    public static final int SQUARE_SURROUND_ITEM_TYPE_ASK = 2;
    public static final int SQUARE_SURROUND_ITEM_TYPE_BBS = 3;

    //格子求助状态类型
    public static final int SQUARE_ASK_ITEM_TYPE_STALE = -1;  //超时关闭
    public static final int SQUARE_ASK_ITEM_TYPE_GOING = 0;   //未结束
    public static final int SQUARE_ASK_ITEM_TYPE_PASS = 1;   //后台审核通过
    public static final int SQUARE_ASK_ITEM_TYPE_COMPLETE = -2;    //已采纳

    //格子tab类型
    public static final int SQUARE_TAB_SERVICE = 1;
    public static final int SQUARE_TAB_ASK = 2;
    public static final int SQUARE_TAB_BBS = 3;
    public static final int SQUARE_TAB_NEARBY = 4;
    public static final int SQUARE_TAB_MISC = 5;

    public static final String CUSTOMER_SERVICE_TEL = "customerServicesTel";

    public static final int SERVICE_TYPE_VISIT = 1; // 上门
    public static final int SERVICE_TYPE_COME = 2;  // 到店
    public static final int SERVICE_TYPE_ONLINE = 3;// 线上
    public static final int SERVICE_TYPE_POST = 4;  // 邮寄

    public static final int SKU_INPUT_TYPE_TEXT = 0;//文本
    public static final int SKU_INPUT_TYPE_FLOAT = 1;//浮点
    public static final int SKU_INPUT_TYPE_INT = 2;

    public static final int SEARCH_TOP_LIST_TYPE_GEZI = 1;
    public static final int SEARCH_TOP_LIST_TYPE_USER = 2;
    public static final int SEARCH_TOP_LIST_TYPE_PROMOTION = 3;

    public static String[] DAY_OF_WEEK = {"星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"};
}
