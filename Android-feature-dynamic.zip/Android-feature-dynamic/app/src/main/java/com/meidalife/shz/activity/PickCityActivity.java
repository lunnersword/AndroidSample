package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.CityAdapter;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CityItem;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.request.RequestAddress;
import com.meidalife.shz.view.CitySidebarView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;

public class PickCityActivity extends BaseActivity {

    private ListView cityListView;
    private CityAdapter cityAdapter;
    private CitySidebarView sidebarView;
    private TextView textView;
    private RelativeLayout pickCityRootView;
    LocationDO mLocation = new LocationDO();

    private String from = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_city);
        initActionBar(R.string.title_activity_pick_city, true);

        pickCityRootView = (RelativeLayout) findViewById(R.id.pickCityRootView);
        cityListView = (ListView) findViewById(R.id.cityList);
        textView = (TextView) findViewById(R.id.dialog);

        Bundle intentExtras = getIntent().getExtras();
        if (intentExtras != null) {
            from = intentExtras.getString("from");
        }

        initLBSInfo();
    }

    void initLBSInfo() {

        AMapLocationManager mLocationManager = SHZApplication.getInstance().getLocationManager();
        LocationDO mLocation = mLocationManager.getLocation();

        if (mLocation != null && mLocation.getLongitude() > 0) {
            buildParams(mLocation);
        } else {
            //如果定位失败 请求重新定位
            mLocationManager.updateLocation(mLocationChangedListener);
        }
    }

    private AMapLocationManager.LocationChangedListener mLocationChangedListener = new AMapLocationManager.LocationChangedListener() {

        @Override
        public void onLocationUpdateFailed() {
            buildParams(mLocation);
        }

        @Override
        public void onLocationChanged(LocationDO location) {
            //定位成功 重新请求数据
            mLocation = location;
            buildParams(mLocation);
        }
    };

    void buildParams(LocationDO mLocation) {
        try {
            JSONObject poiParams = new JSONObject();
            if (mLocation != null) {
                poiParams.put("poiLongitude", "" + mLocation.getLongitude());
                poiParams.put("poiLatitude", "" + mLocation.getLatitude());

                poiParams.put("gdCityCode", "" + mLocation.getCityCode());
                poiParams.put("gdCityName", "" + mLocation.getCityName());
            }

            cityListByLBS(poiParams);
        } catch (JSONException e) {
        }
    }

    void cityListByLBS(JSONObject params) {
        RequestAddress.getCityList(params, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object result) {
                HashMap data = (HashMap) result;

                cityAdapter = new CityAdapter(PickCityActivity.this, (ArrayList) data.get("cityList"));
                cityListView.setAdapter(cityAdapter);
                cityAdapter.setOnClickCellListener(new CityAdapter.OnClickListener() {
                    public void onClick(View v, CityItem item) {
                        if ("splash".equals(from)) {
                            Helper.sharedHelper().setStringUserInfo(Constant.SELECT_CITY_CODE, String.valueOf(item.getCode()));
                            Helper.sharedHelper().setStringUserInfo(Constant.SELECT_CITY_NAME, item.getName());

                            Router.sharedRouter().open("main");
                        } else {
                            Intent intent = new Intent();
                            Bundle bundle = new Bundle();
                            bundle.putString("name", item.getName());
                            try {
                                bundle.putInt("code", Integer.parseInt(item.getCode()));
                            } catch (NumberFormatException e) {
                                e.printStackTrace();
                            }
                            bundle.putString("code", item.getCode());
                            bundle.putBoolean("openGezi", item.isOpenGezi());
                            bundle.putDouble("lng", item.getLongitude());
                            bundle.putDouble("lat", item.getLatitude());
                            intent.putExtras(bundle);
                            setResult(RESULT_OK, intent);
                            finish();
                        }
                    }
                });

                initSlidebarView((ArrayList) data.get("navList"));
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter("获取城市数据失败");
                showStatusErrorServer(pickCityRootView);
            }
        });
    }

    private void initSlidebarView(final ArrayList data) {
        sidebarView = new CitySidebarView(PickCityActivity.this);
        sidebarView.setLabels(data);
        sidebarView.setTextView(textView);
        sidebarView.setOnTouchingLetterChangedListener(new CitySidebarView.OnTouchingLetterChangedListener() {
            @Override
            public void onTouchingLetterChanged(String s, int index) {
                HashMap item = (HashMap) data.get(index);
                int position = (int) item.get("position");
                if (position != -1) {
                    cityListView.setSelection(position);
                }
            }
        });
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                50, ViewGroup.LayoutParams.MATCH_PARENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
        params.topMargin = 100;
        params.bottomMargin = 100;
        pickCityRootView.addView(sidebarView, params);
    }
}
