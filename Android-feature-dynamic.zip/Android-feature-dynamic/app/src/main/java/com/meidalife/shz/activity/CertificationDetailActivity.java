package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CertificationGridAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.AuthDetailBean;
import com.meidalife.shz.rest.model.AuthPictureDO;
import com.meidalife.shz.rest.model.CertDO;
import com.meidalife.shz.rest.model.CertificationCertDO;
import com.meidalife.shz.rest.model.TemplateDO;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.view.MyGridView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
//import us.pinguo.edit.sdk.PGEditActivity;
//import us.pinguo.edit.sdk.base.PGEditResult;
//import us.pinguo.edit.sdk.base.PGEditSDK;

/**
 * Created by zuozheng 15/11/16
 * 认证详情页
 */

public class CertificationDetailActivity extends BaseActivity {

    private static final String TAG = "CertificationDetail";
    int TEXT_LENGTH_LIMIT_TAG = 10;
    int TEXT_LENGTH_LIMIT_REAL_NAME = 7;
    int TEXT_LENGTH_LIMIT_SERIAL_NUM = 30;
    int TEXT_LENGTH_LIMIT_DESC = 140;


    //认证状态
    @Bind(R.id.authStatusRL)
    View authStatusRL;
    @Bind(R.id.authStatus)
    TextView authStatus;

    //认证称号
    @Bind(R.id.tagView)
    View tagView;
    @Bind(R.id.tagContent)
    TextView tagContent;
    @Bind(R.id.tagTitleLimit)
    TextView tagTitleLimit;

    //真实姓名
    @Bind(R.id.realNameContent)
    TextView realNameContent;
    @Bind(R.id.realNameLimit)
    TextView realNameLimit;

    //证件编号
    @Bind(R.id.serialNumberTitle)
    TextView serialNumberTitle;
    @Bind(R.id.serialNumberContent)
    TextView serialNumberContent;
    @Bind(R.id.serialNumberLimit)
    TextView serialNumberLimit;


    //附加说明
    @Bind(R.id.addDescView)
    View addDescView;
    @Bind(R.id.addDescContent)
    TextView addDescContent;
    //附加说明字数限制
    @Bind(R.id.addDesLimit)
    TextView addDesLimit;

    //图片
    @Bind(R.id.imageView)
    MyGridView imageView;


    //提交审核
    @Bind(R.id.btnSubmit)
    TextView btnSubmit;
    @Bind(R.id.submitView)
    View submitView;

    //图片示例
    @Bind(R.id.exampleView)
    View exampleView;

    @Bind(R.id.tipsView)
    SimpleDraweeView tipsView;

    @Bind(R.id.disappearView)
    ImageView disappearView;

    //浮层
    @Bind(R.id.guide_group)
    View guide_group;

    // 模版id
    private int tid;
    //证书id
    private int certId;
    //认证类型
    private int authType;
    //是否实名认证
    private boolean realUser = false;

    //用户真实姓名
    private String realName = "";
    private int mClickedPosition;
//    private static String EDITED_IMAGE_DIRECTORY;
//    private static final String EDITED_IMAGE_PREFIX = "editedImage";

    //更新界面相关adapter
    ArrayList<AuthPictureDO> picDOList;
    CertificationGridAdapter adapter;
    AuthDetailBean bean = new AuthDetailBean();

    //已经上传图片list
    private List<String> picList = new ArrayList<String>();

    ArrayList waitingUploadPicQueue = new ArrayList();
    boolean uploadComplete = false;
    boolean submit = false;
    boolean uploading = false;

//    boolean isRealNameCert = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth_detail);
        initActionBar("", true, true);

        mButtonRight.setVisibility(View.GONE);
        mButtonRight.setText("提交");
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSubmit(v);
            }
        });

//        EDITED_IMAGE_DIRECTORY = ImgUtil.getEditedImagePath(this);

        ButterKnife.bind(this);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            tid = bundle.getInt("tid");
            certId = bundle.getInt("id");
            authType = bundle.getInt("type", Constant.TYPE_PERSONAL);
            realUser = bundle.getBoolean("realUser");
            realName = bundle.getString("realName");
//            isRealNameCert = bundle.getBoolean("isRealNameCert");

            if (authType == Constant.TYPE_OFFICIAL) {
                setActionBarTitle(R.string.auth_official_title);
                //设置认证称号和附加说明不可见
                tagView.setVisibility(View.GONE);
                addDescView.setVisibility(View.GONE);
            } else {
                setActionBarTitle(R.string.auth_skill_title);
            }
        }

        picDOList = new ArrayList();

        adapter = new CertificationGridAdapter(this, picDOList, Constant.MAX_IMAGE_LENGTH, CertificationGridAdapter.TYPE_OTHER);
        adapter.setOnClickListener(new CertificationGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                mClickedPosition = position;
                addImg(mClickedPosition);
            }
        });
        adapter.setOnClickRemoveListener(new CertificationGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                if (position < picDOList.size()) {
                    //todo 设置图片为空 然后更新列表
                    picDOList.get(position).setUrl("");
                    adapter.notifyDataSetChanged();
                }
            }
        });
        imageView.setAdapter(adapter);

        initView();

        if (certId > 0 || tid > 0) {
            authDetail(certId, tid);
        } else {
            if (picDOList.size() == 0) {
                AuthPictureDO picDO = new AuthPictureDO();
                picDO.setUrl("");
                picDO.setDesc("证件正面照片");
                AuthPictureDO picDO2 = new AuthPictureDO();
                picDO2.setUrl("");
                picDO2.setDesc("证件反面照片");
                AuthPictureDO picDO3 = new AuthPictureDO();
                picDO3.setUrl("");
                picDO3.setDesc("手持证件本人照片");
                picDOList.add(picDO);
                picDOList.add(picDO2);
                picDOList.add(picDO3);
            }
            updateView();
        }
    }

    void initView() {

        tagContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tagTitleLimit.setText("" + s.toString().length());
                if (s.toString().length() > TEXT_LENGTH_LIMIT_TAG) {
                    tagTitleLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    tagTitleLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        realNameContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                realNameLimit.setText("" + s.toString().length());
                if (s.toString().length() > TEXT_LENGTH_LIMIT_REAL_NAME) {
                    realNameLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    realNameLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        serialNumberContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                serialNumberLimit.setText("" + s.toString().length());
                if (s.toString().length() > TEXT_LENGTH_LIMIT_SERIAL_NUM) {
                    serialNumberLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    serialNumberLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        addDescContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                addDesLimit.setText("" + s.toString().length());
                if (s.toString().length() > TEXT_LENGTH_LIMIT_DESC) {
                    addDesLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    addDesLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        disappearView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guide_group.setVisibility(View.GONE);
            }
        });
    }

    void addImg(int position) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", 1);
        bundle.putInt("position", position);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, CertificationDetailActivity.this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case Constant.REQUEST_CODE_PICK_PHOTO:
                    Bundle bundle = data.getExtras();
                    ArrayList paths = bundle.getStringArrayList("images");
                    if (paths == null || paths.size() == 0)
                        return;

                    // 刷新图片和更新view分离 便于逻辑控制
                    if (picDOList != null && picDOList.size() > 0) {
                        picDOList.get(mClickedPosition).setUrl((String) paths.get(0));
                    }

                    if (!waitingUploadPicQueue.contains(paths.get(0))) {
                        waitingUploadPicQueue.add(paths.get(0));
                    }
                    break;
            }

            adapter.notifyDataSetChanged();
            uploading = false;
            uploadComplete = false;
            uploadImages();
        }
    }

    private void authDetail(final int certId, int templateId) {
        showProgressDialog("正在获取数据", false);
        try {
            com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();

            if (certId > 0) {
                params.put("certId", certId);
            }
            if (templateId > 0) {
                params.put("tid", templateId);
            }

            String userId = Helper.sharedHelper().getUserId();
            params.put("userId", userId);

            HttpClient.get("1.0/cert/get", params, CertificationCertDO.class, new HttpClient.HttpCallback<CertificationCertDO>() {
                @Override
                public void onSuccess(CertificationCertDO certificationCertDO) {
                    hideProgressDialog();
                    if (certificationCertDO != null) {
                        CertDO cert = certificationCertDO.getCert();
                        TemplateDO template = certificationCertDO.getTemplate();

                        if (template != null) {
                            bean.setTid(template.getId());
                            bean.setPicsTip(template.getPicsTip());
                        }

                        if (cert != null) {
                            bean.setCertId(cert.getId());

                            //证书状态和文案 对状态和tag重新赋值
                            int status = cert.getStatus();
                            bean.setStatus(status);

                            if (status == Constant.CERT_STATUS_AUDIT) {
                                bean.setStatusStr("审核中");
                            } else if (status == Constant.CERT_STATUS_DENY) {
                                bean.setStatusStr(cert.getAuditReason());
                            }

                            bean.setTagName(cert.getTagName());
                            bean.setSerialNum(cert.getNumValue());
                            bean.setExtraValue(cert.getExtraValue());

                            //图片解析
                            bean.setPicUrlList(cert.getPicsValue());


                            //更新图片逻辑和提示
                            List<String> picUrlList = bean.getPicUrlList();
                            List<String> picTipLit = bean.getPicsTip();
                            if (CollectionUtil.isNotEmpty(picUrlList)) {
                                for (int i = 0; i < picUrlList.size(); i++) {
                                    AuthPictureDO picDO = new AuthPictureDO();

                                    if (bean.getStatus() == Constant.CERT_STATUS_UNCOMMIT || bean.getStatus() == Constant.CERT_STATUS_DENY) {
                                        picDO.setEditble(true);
                                    }
                                    picDO.setUrl(picUrlList.get(i));
                                    picList.add(picUrlList.get(i));

                                    if (CollectionUtil.isNotEmpty(picTipLit) && i < picTipLit.size()) {
                                        picDO.setDesc(picTipLit.get(i));
                                    } else {
                                        picDO.setDesc("");
                                    }
                                    picDOList.add(picDO);
                                }
                            }
                        } else if (template != null) {
                            //用户没有进行任何认证 解析template字段 展现模版

                            bean.setTid(template.getId());

                            bean.setStatus(Constant.CERT_STATUS_UNCOMMIT);
                            bean.setStatusStr("未认证");

                            bean.setTagName(template.getTagName());
                            bean.setSerialNumName(template.getNumName());
                            bean.setSerialNumTip(template.getNumTip());

                            //图片提示
                            bean.setPicsTip(template.getPicsTip());

                            bean.setExamplePicUrl(template.getExample());

                            //未实名认证或者是个人认证
                            if (CollectionUtil.isNotEmpty(bean.getPicsTip())) {
                                for (String tip : bean.getPicsTip()) {
                                    AuthPictureDO picDO = new AuthPictureDO();
                                    picDO.setDesc(tip);
                                    picDOList.add(picDO);
                                }
                            }
                        }
                    }
                    updateView();
                }

                @Override
                public void onFail(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "获取认证数据失败");
                }
            });

        } catch (Exception e) {

        }
    }

    void updateView() {

        if (bean.getStatus() == Constant.CERT_STATUS_DENY) {
            btnSubmit.setText("重新认证");
        }

        if (bean.getStatus() == Constant.CERT_STATUS_AUDIT || bean.getStatus() == Constant.CERT_STATUS_PASS) {
            //认证成功状态或者审核中 提交按钮和导航右侧按钮不可见
            submitView.setVisibility(View.GONE);
            mButtonRight.setVisibility(View.GONE);

            //认证成功状态或者审核中 字段不可以编辑
            tagContent.setFocusable(false);
            realNameContent.setFocusable(false);
            serialNumberContent.setFocusable(false);
            addDescContent.setFocusable(false);
            adapter.setOnClickListener(null);
            adapter.setOnClickRemoveListener(null);
        } else {
            submitView.setVisibility(View.VISIBLE);
            mButtonRight.setVisibility(View.VISIBLE);

            String picUrl = bean.getExamplePicUrl();
            if (authType == Constant.TYPE_OFFICIAL && !TextUtils.isEmpty(picUrl)) {
                exampleView.setVisibility(View.VISIBLE);

            }
        }

        //审核中和拒绝显示状态
        if (bean.getStatus() == Constant.CERT_STATUS_DENY || bean.getStatus() == Constant.CERT_STATUS_AUDIT) {
            authStatusRL.setVisibility(View.VISIBLE);
            authStatus.setText(bean.getStatusStr());
        }

        //如果是官方认证 隐藏认证称号
        if (authType == Constant.TYPE_OFFICIAL) {
            tagView.setVisibility(View.GONE);
            addDescView.setVisibility(View.GONE);

            if (!TextUtils.isEmpty(bean.getTagName())) {
                setActionBarTitle(bean.getTagName());
            }

        } else {
            if (!TextUtils.isEmpty(bean.getTagName())) {
                tagContent.setText(bean.getTagName());
            }

            if (!TextUtils.isEmpty(bean.getExtraValue())) {
                addDescContent.setText(bean.getExtraValue());
            }

        }

        realNameContent.setText(realName);

        //已经进行实名认证  真实姓名不可以编辑
        if (!TextUtils.isEmpty(realName) && realUser) {
            realNameContent.setFocusable(false);
        }

        //认证编号
        if (!TextUtils.isEmpty(bean.getSerialNumName())) {
            serialNumberTitle.setText(bean.getSerialNumName());
        }

        if (!TextUtils.isEmpty(bean.getSerialNum())) {
            serialNumberContent.setText(bean.getSerialNum());
        }

        if (!TextUtils.isEmpty(bean.getSerialNumTip())) {
            serialNumberContent.setHint(bean.getSerialNumTip());
        }

        if (picDOList.isEmpty()) {
            imageView.setVisibility(View.GONE);
        } else {
            imageView.setVisibility(View.VISIBLE);
        }

        adapter.notifyDataSetChanged();

    }


    @OnClick(R.id.action_bar_button_right)
    public void handleSubmit(View view) {
        if (authType == Constant.TYPE_PERSONAL && TextUtils.isEmpty(tagContent.getText().toString().trim())) {
            MessageUtils.showToastCenter("认证称号不能为空");
            return;
        }

        if (authType == Constant.TYPE_OFFICIAL && TextUtils.isEmpty(realNameContent.getText().toString().trim())) {
            MessageUtils.showToastCenter("真实姓名不能为空");
            return;
        }

        if (TextUtils.isEmpty(serialNumberContent.getText().toString().trim())) {
            MessageUtils.showToastCenter("证件编号不能为空");
            return;
        }

        //todo 遍历list判断图片内容;如果为空 提示添加图片
        if (picDOList.size() == 0) {
            MessageUtils.showToastCenter("还未选择图片哦");
            return;
        } else {
            boolean havePicIsNone = false;
            for (AuthPictureDO pic : picDOList) {
                if (TextUtils.isEmpty(pic.getUrl())) {
                    havePicIsNone = true;
                    break;
                }
            }

            if (havePicIsNone) {
                MessageUtils.showToastCenter("图片添加不全哦");
                return;
            }
        }

        if (!submit) {
            submit = true;

            if (waitingUploadPicQueue.size() > 0 && !uploadComplete) {
                uploadImages();
            } else {
                xhrSubmit();
            }
        }
    }

    private void xhrSubmit() {
        JSONObject params = new JSONObject();

        try {
            if (bean.getCertId() > 0) {
                params.put("certId", bean.getCertId());
            }
            if (bean.getTid() > 0) {
                params.put("templateId", bean.getTid());
            }

            //如果是官方认证 获取官方认证tag or 从字段获取
            if (!TextUtils.isEmpty(bean.getTagName()) && authType == Constant.TYPE_OFFICIAL) {
                params.put("tagName", bean.getTagName());
            } else {
                params.put("tagName", tagContent.getText().toString().trim());
            }

            if (TextUtils.isEmpty(realName)) {
                params.put("userName", realNameContent.getText().toString().trim());
            } else {
                params.put("userName", realName);
            }

            params.put("numValue", serialNumberContent.getText().toString().trim());
            if (!TextUtils.isEmpty(addDescContent.getText().toString().trim())) {
                params.put("extraValue", addDescContent.getText().toString().trim());
            }

            //图片
            params.put("picsValue", picList);

            showProgressDialog("正在认证", false);

            HttpClient.get("1.0/cert/add", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject obj) {
                    hideProgressDialog();
                    submit = false;
                    finish();
                }

                @Override
                public void onFail(HttpError error) {

                    hideProgressDialog();
                    submit = false;
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "认证提交失败，请重试");
                }
            });

        } catch (Exception e) {

        }
    }

    private void uploadImages() {
        if (!uploading) {
            uploading = true;

            xhrUpdateImages(waitingUploadPicQueue, 0);
        }
    }

    private void xhrUpdateImages(final ArrayList paths, final int index) {
        if (paths.size() > 0) {
            final String path = (String) paths.get(index);
            RequestSign.upload(path, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    org.json.JSONObject json = (org.json.JSONObject) result;
                    try {
                        //如果图片列表不是空 进行更新操作 or添加
                        if (mClickedPosition < picList.size()) {
                            picList.remove(mClickedPosition);
                            picList.add(mClickedPosition, json.getString("data"));
                        } else {
                            picList.add(json.getString("data"));
                        }

                        if (index == paths.size() - 1) {
                            uploadComplete = true;
                            //上传完成 清空待上传列表
                            waitingUploadPicQueue.clear();

                            if (submit) {
                                xhrSubmit();
                            }
                        } else {
                            uploadComplete = false;
                            xhrUpdateImages(paths, index + 1);
                        }
                    } catch (Exception e) {
                        uploading = false;
                        uploadComplete = false;
                        MessageUtils.showToastCenter(e.getMessage());
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    uploading = false;
                    uploadComplete = false;
                    submit = false;
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败");
                }
            });
        } else {
            uploadComplete = true;
            if (submit) {
                xhrSubmit();
            }
        }
    }

    public void handleExample(View view) {
        guide_group.setVisibility(View.VISIBLE);
        String picUrl = bean.getExamplePicUrl();
        if (!TextUtils.isEmpty(picUrl)) {
            if (picUrl.matches("http://.*")) {
                tipsView.setImageURI(Uri.parse(picUrl));
            }
        }

    }
}
