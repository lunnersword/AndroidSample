package com.meidalife.shz.activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareUserListAdapter;
import com.meidalife.shz.event.SquarePortalRefreshEvent;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.rest.model.UserItem;
import com.meidalife.shz.widget.PopupListMenu;
import com.meidalife.shz.widget.RecyclerViewEmptySupport;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by fufeng on 15/12/20.
 */
public class SquareUserListActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener, View.OnClickListener {
    private static final int PAGE_SIZE = 10;
    private static final int MENU_ITEM_EXIT_SQUARE = 0;
    private static final int MENU_ITEM_CANCEL = 1;

    private int currentPage = 0;
    private String squareId;
    private boolean isLoading = false;
    private String kgStationLatitude;
    private String kgStationLongitude;
    private String geziPicUrl;
    private List<UserItem> userListData = new ArrayList<>();

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.stageContentLayout)
    ViewGroup stageContentLayout;
    @Bind(R.id.qrcodeShareIcon)
    TextView qrcodeShareIcon;
    @Bind(R.id.serviceCountValue)
    TextView serviceCountValue;
    @Bind(R.id.serviceCountTrend)
    TextView serviceCountTrend;
    @Bind(R.id.hitsValue)
    TextView hitsValue;
    @Bind(R.id.userCountTrend)
    TextView userCountTrend;
    @Bind(R.id.userCountValue)
    TextView userCountValue;
    @Bind(R.id.locationIcon)
    TextView locationIcon;

    @Bind(R.id.circularContent)
    TextView circularContent;
    @Bind(R.id.stageContent)
    TextView stageContent;
    @Bind(R.id.menuButton)
    TextView menuButton;

    @Bind(R.id.userList)
    RecyclerViewEmptySupport squareUserList;
    SquareUserListAdapter squareUserListAdapter;
    LinearLayoutManager linearLayoutManager;
    private PopupListMenu mPopupListMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_user_list);
        initActionBar("", true, false);
        ButterKnife.bind(this);
        squareId = getIntent().getStringExtra("squareId");
        boolean isOwner = getIntent().getBooleanExtra("isOwner", false);
        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        squareUserList.setLayoutManager(linearLayoutManager);
        squareUserListAdapter = new SquareUserListAdapter(this, userListData);
        squareUserList.setAdapter(squareUserListAdapter);
        swipeRefreshLayout.setOnRefreshListener(this);

        squareUserList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                swipeRefreshLayout.setEnabled(linearLayoutManager.findFirstCompletelyVisibleItemPosition() == 0 &&
                        newState == RecyclerView.SCROLL_STATE_IDLE);
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (linearLayoutManager.findLastCompletelyVisibleItemPosition() == (squareUserListAdapter.getItemCount() - 1)) {
                    loadSquareMemberList(false);
                }
            }
        });
        if (isOwner) {
            menuButton.setVisibility(View.GONE);
        } else {
            menuButton.setVisibility(View.VISIBLE);
            menuButton.setOnClickListener(this);
        }
        loadSquareMemberList(true);
    }

    private void loadSquareMemberList(boolean showLoading) {
        if (isLoading) {
            return;
        }
        isLoading = true;
        if (showLoading) {
            showStatusLoading(rootLayout);
            swipeRefreshLayout.setVisibility(View.GONE);
        }
        JSONObject params = new JSONObject();
        params.put("geziId", squareId);
        params.put("pageSize", PAGE_SIZE);
        params.put("offset", currentPage * PAGE_SIZE);
        HttpClient.get("1.0/gezi/userList", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        hideStatusLoading();
                        hideStatusErrorNetwork();
                        hideStatusErrorServer();
                        swipeRefreshLayout.setRefreshing(false);
                        swipeRefreshLayout.setVisibility(View.VISIBLE);
                        isLoading = false;
                        if (obj != null) {
                            loadHeader(obj);
                            loadUserList(obj);
                        }
                        currentPage++;
                    }

                    @Override
                    public void onFail(HttpError error) {
                        hideStatusLoading();
                        isLoading = false;
                        swipeRefreshLayout.setRefreshing(false);
                        swipeRefreshLayout.setVisibility(View.GONE);
                        if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                            showStatusErrorNetwork(rootLayout, new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    loadSquareMemberList(true);
                                }
                            });
                        } else {
                            showStatusErrorServer(rootLayout, new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    loadSquareMemberList(true);
                                }
                            });
                        }
                    }
                });
    }

    private void loadHeader(JSONObject obj) {
        serviceCountValue.setText(obj.getString("itemCount"));
        hitsValue.setText(obj.getString("popularity"));
        userCountValue.setText(obj.getString("userCount"));

        if (!TextUtils.isEmpty(obj.getString("notice"))) {
            circularContent.setText("公告：" + obj.getString("notice"));
        } else {
            circularContent.setText(getString(R.string.default_square_circular));
        }

        if (obj.containsKey("kgStationAddress")) {
            stageContent.setText("空格驿站：" + obj.getString("kgStationAddress"));
            stageContentLayout.setVisibility(View.VISIBLE);
        } else {
            stageContentLayout.setVisibility(View.GONE);
        }
        final String squareName = obj.getString("geziName");
        setActionBarTitle(squareName);
        Integer userCountArrow = obj.getInteger("userCountArrow");
        if (userCountArrow > 0) {
            userCountTrend.setText(String.format("(%s)", obj.getString("userCountIncrement") + getString(R.string.icon_increase)));
            userCountTrend.setTextColor(getResources().getColor(R.color.brand_b));
        } else if (userCountArrow < 0) {
            userCountTrend.setText(String.format("(%s)", obj.getString("userCountIncrement") + getString(R.string.icon_decrease)));
            userCountTrend.setTextColor(getResources().getColor(R.color.gezi_green));
        } else {
            userCountTrend.setVisibility(View.GONE);
        }

        Integer itemCountArrow = obj.getInteger("itemCountArrow");
        if (itemCountArrow > 0) {
            serviceCountTrend.setText(String.format("(%s)", obj.getString("itemCountIncrement") + getString(R.string.icon_increase)));
            serviceCountTrend.setTextColor(getResources().getColor(R.color.brand_b));
        } else if (itemCountArrow < 0) {
            serviceCountTrend.setText(String.format("(%s)", obj.getString("itemCountIncrement") + getString(R.string.icon_decrease)));
            serviceCountTrend.setTextColor(getResources().getColor(R.color.gezi_green));
        } else {
            serviceCountTrend.setVisibility(View.GONE);
        }
        kgStationLatitude = obj.getString("kgStationLatitude");
        kgStationLongitude = obj.getString("kgStationLongitude");
        geziPicUrl = obj.getString("geziPicUrl");

        qrcodeShareIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle params = new Bundle();
                params.putString("id", squareId);
                params.putString("name", squareName);
                params.putString("picUrl", geziPicUrl);
                params.putString("latitude", kgStationLatitude);
                params.putString("longitude", kgStationLongitude);
                Router.sharedRouter().open("squareQRCode", params);
            }
        });
        if (!TextUtils.isEmpty(kgStationLongitude) && !TextUtils.isEmpty(kgStationLatitude)) {
            locationIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    try {
                        bundle.putDouble(ViewLocationActivity.LOCATION_LNG, Double.parseDouble(kgStationLongitude));
                        bundle.putDouble(ViewLocationActivity.LOCATION_LAT, Double.parseDouble(kgStationLatitude));
                        Router.sharedRouter().open("viewPosition", bundle);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    private void loadUserList(JSONObject userList) {
        JSONArray userArray = userList.getJSONArray("userList");
        for (int i = 0; i < userArray.size(); i++) {
            JSONObject userObj = userArray.getJSONObject(i);
            UserItem item = new UserItem();
            item.setUserAvatar(userObj.getString("userPicUrl"));
            item.setUserName(userObj.getString("userNick"));
            item.setUserDesc(userObj.getString("userInstruction"));
            item.setUserGender(userObj.getString("userGender"));
            item.setUserId(userObj.getString("userId"));
            item.setIsGezhu(userObj.getBoolean("isGezhu"));
            item.setIsOnline(userObj.getBoolean("isOnline"));
            item.setLastOnlineTime(userObj.getLong("lastOnlineTime"));
            userListData.add(item);
        }

        if (!userListData.isEmpty()) {
            squareUserListAdapter.setData(userListData);
            squareUserListAdapter.notifyDataSetChanged();
        }
    }

    private void showExitSquareMenu(View v) {
        if (mPopupListMenu == null)
            mPopupListMenu = new PopupListMenu(this,0);
        List<MenuVO> items = new ArrayList<>();
        items.add(MENU_ITEM_EXIT_SQUARE, new MenuVO(getResources().getString(R.string.text_square_exit)));
        items.add(MENU_ITEM_CANCEL, new MenuVO(getResources().getString(R.string.cancel)));
        mPopupListMenu.setMenuData(items);
        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_EXIT_SQUARE:
                        //退出格子
                        MessageUtils.showDialog(SquareUserListActivity.this, "确定要退出格子？",
                                "退出后也将把服务从格子退出", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        exitSquare();
                                    }
                                }, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        mPopupListMenu.dismiss();
                        break;
                    case MENU_ITEM_CANCEL:
                        mPopupListMenu.dismiss();
                        break;
                }
            }
        });
        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private void exitSquare() {
        showProgressDialog("正在退出");
        JSONObject params = new JSONObject();
        params.put("geziId", squareId);
        HttpClient.get("1.0/gezi/quit", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideProgressDialog();

                //推出格子成功 请求刷新事件
                EventBus.getDefault().post(new SquarePortalRefreshEvent());
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "退出失败，请稍后再试");
            }
        });
    }

    @Override
    public void onRefresh() {
        currentPage = 0;
        userListData.clear();
        squareUserListAdapter.notifyDataSetChanged();
        loadSquareMemberList(true);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.menuButton:
                showExitSquareMenu(v);
                break;
        }
    }
}
