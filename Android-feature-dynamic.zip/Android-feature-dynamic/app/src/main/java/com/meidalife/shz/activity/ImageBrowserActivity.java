package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.curioustechizen.ago.RelativeTimeTextView;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.PhotoPagerAdapter;
import com.usepropeller.routable.Router;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import uk.co.senab.photoview.PhotoViewAttacher;

public class ImageBrowserActivity extends BaseActivity {

    int index;

    @Bind(R.id.textDescription)
    TextView textDescription;
    @Bind(R.id.fromService)
    TextView textSource;
    @Bind(R.id.textCreateTime)
    RelativeTimeTextView textCreateTime;
    @Bind(R.id.serviceTitle)
    TextView serviceTitle;
    @Bind(R.id.serviceInfoLayout)
    LinearLayout serviceInfoLayout;

    long itemId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_browser);
        initActionBar(R.string.title_activity_image_browser);
        hideActionBar();

        ButterKnife.bind(this);

        Bundle bundle = getIntent().getExtras();
        ArrayList<String> photos = bundle.getStringArrayList("photos");
        index = bundle.getInt("index");

        ViewPager viewPager = (ViewPager) findViewById(R.id.viewPager);
        PhotoPagerAdapter adapter = new PhotoPagerAdapter(this, photos);
        adapter.setOnPhotoTapListener(new PhotoViewAttacher.OnPhotoTapListener() {
            @Override
            public void onPhotoTap(View view, float v, float v1) {
                ImageBrowserActivity.this.finish();
            }
        });
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(index);

        if (bundle.getLong("time") > 0) {
            textCreateTime.setReferenceTime(bundle.getLong("time"));
        } else {
            textCreateTime.setVisibility(View.GONE);
        }
        if (bundle.getString("description") != null) {
            textDescription.setText(bundle.getString("description"));
            textDescription.setVisibility(View.VISIBLE);
        } else {
            textDescription.setVisibility(View.GONE);
        }
        if (bundle.getString("title") != null) {
            itemId = bundle.getLong("itemId");
            textSource.setVisibility(View.VISIBLE);
            serviceTitle.setVisibility(View.VISIBLE);
            serviceTitle.setText(bundle.getString("title"));
            serviceInfoLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("detail/" + itemId);
                }
            });
        } else {
            textSource.setVisibility(View.GONE);
            serviceTitle.setVisibility(View.GONE);
        }
    }
}
