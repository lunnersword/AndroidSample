package com.meidalife.shz.adapter;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.event.CategoryFilterEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.model.SecondCategoryFilterTabDO;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;
import com.meidalife.shz.widget.ItemDislikePopupWindow;
import com.meidalife.shz.widget.SecondCategorySortPopupWindow;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.greenrobot.event.EventBus;

/**
 * Created by yiyang on 16/3/15.
 */
public class CategoryRecyclerFilterAdapter extends RecyclerView.Adapter<CategoryRecyclerFilterAdapter.ViewHolder> {

    private static final int TYPE_POP_MENU = 0;
    private static final int TYPE_ONE_SITUATION = 1;
    private static final int TYPE_TWO_SITUATIONS = 2;

    Context mContext;
    List<SecondCategoryFilterTabDO> mDataList;
    private LayoutInflater mInflater;

    private SecondCategorySortPopupWindow sortPopupWindow;
    private int selectedIndex = 0;
    private boolean noRefresh = false;  //用于主动调用数据刷新时，不清除TYPE_TWO_SITUATIONS的记录


    public CategoryRecyclerFilterAdapter(Context context, List<SecondCategoryFilterTabDO> dataList) {
        this.mContext = context;
        this.mDataList = dataList;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_search_recycler_view, null);
        ViewHolder viewHolder = new ViewHolder(view);

        viewHolder.rootView = view;
        viewHolder.dividerLine = view.findViewById(R.id.dividerLine);
        viewHolder.title = (FontTextView) view.findViewById(R.id.titleText);
        viewHolder.icon = (IconTextView) view.findViewById(R.id.icon);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        final SecondCategoryFilterTabDO tabItem = mDataList.get(position);

        final int tabType = Integer.valueOf(tabItem.getTabType());
        String title = tabItem.getTitle();

        if (selectedIndex == position) {
            viewHolder.title.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            viewHolder.icon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
        } else {
            viewHolder.title.setTextColor(mContext.getResources().getColor(R.color.grey_a));
            viewHolder.icon.setTextColor(mContext.getResources().getColor(R.color.grey_a));
        }
        viewHolder.title.setText(title);

        if (!noRefresh) {
            switch (tabType) {
                case TYPE_POP_MENU:

                    viewHolder.rootView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (sortPopupWindow != null && sortPopupWindow.isShowing()) {
                                sortPopupWindow.dismiss();
                                return;
                            }
                            if (sortPopupWindow == null) {
                                sortPopupWindow = new SecondCategorySortPopupWindow((Activity) mContext);
                                if (tabItem.getChilds() != null && tabItem.getChilds().size() > 0)
                                    sortPopupWindow.setData(tabItem.getChilds());
                            }
                            sortPopupWindow.showAsDropDown((View) v.getParent(), 0, (int) Helper.convertDpToPixel(1, mContext));
                            sortPopupWindow.setIndexChangeListener(new SecondCategorySortPopupWindow.IPopupSelectIndexChangeListener() {
                                @Override
                                public void setIndex(int index) {
                                    viewHolder.title.setText(tabItem.getChilds().get(index).getTitle());
                                    selectedIndex = position;
                                    noRefresh = true;
                                    notifyDataSetChanged();
                                }
                            });
                        }
                    });
                    viewHolder.dividerLine.setVisibility(View.GONE);
                    viewHolder.icon.setText(R.string.icon_search_sort);
                    viewHolder.icon.setVisibility(View.VISIBLE);
                    break;

                case TYPE_ONE_SITUATION:
                    viewHolder.rootView.setTag(tabItem.getTabId());
                    viewHolder.rootView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Integer tabId = (Integer) v.getTag();
                            EventBus.getDefault().post(new CategoryFilterEvent(MsgTypeEnum.TYPE_SECOND_CATEGORY_TAB_ID, tabId));
                            selectedIndex = position;
                            noRefresh = true;
                            notifyDataSetChanged();
                        }
                    });
                    viewHolder.dividerLine.setVisibility(View.GONE);
                    viewHolder.icon.setVisibility(View.GONE);
                    break;

                case TYPE_TWO_SITUATIONS:

                    Map<String, Integer> mapTag = new HashMap<>();
                    mapTag.put("isDown", 1);
                    mapTag.put("firstTabId", tabItem.getChilds().get(0).getTabId());
                    mapTag.put("secondTabId", tabItem.getChilds().get(1).getTabId());

                    viewHolder.rootView.setTag(mapTag);
                    viewHolder.rootView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Map<String, Integer> mapTag = (Map<String, Integer>) v.getTag();
                            Integer isDown = mapTag.get("isDown");
                            Integer tabId;

                            if (isDown.equals(1)) {
                                viewHolder.icon.setText(R.string.icon_search_up);
                                tabId = mapTag.get("secondTabId");
                                EventBus.getDefault().post(new CategoryFilterEvent(MsgTypeEnum.TYPE_SECOND_CATEGORY_TAB_ID, tabId));
                                mapTag.put("isDown", 0);
                            } else {
                                viewHolder.icon.setText(R.string.icon_expan);
                                tabId = mapTag.get("firstTabId");
                                EventBus.getDefault().post(new CategoryFilterEvent(MsgTypeEnum.TYPE_SECOND_CATEGORY_TAB_ID, tabId));
                                mapTag.put("isDown", 1);
                            }
                            v.setTag(mapTag);
                            selectedIndex = position;
                            noRefresh = true;
                            notifyDataSetChanged();
                        }
                    });

                    viewHolder.dividerLine.setVisibility(View.GONE);
                    viewHolder.icon.setText(R.string.icon_expan);
                    viewHolder.icon.setVisibility(View.VISIBLE);

                    break;

            }
        }
        if (position == getItemCount() - 1) {
            noRefresh = false;
        }

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View arg0) {
            super(arg0);
        }

        View rootView;
        View dividerLine;
        FontTextView title;
        IconTextView icon;
    }


}
