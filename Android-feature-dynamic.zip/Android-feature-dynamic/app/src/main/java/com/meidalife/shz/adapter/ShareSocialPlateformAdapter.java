package com.meidalife.shz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SocialShareDO;
import com.usepropeller.routable.Router;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zuozheng on 16/4/4.
 */
public class ShareSocialPlateformAdapter extends RecyclerView.Adapter<ShareSocialPlateformAdapter.ViewHolder> {
    private LayoutInflater mInflater;
    Context mContext;
    List<SocialShareDO> mList;

//    int avatarImgWidth;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }

        @Bind(R.id.rootView)
        TextView rootView;

        @Bind(R.id.shareIcon)
        TextView shareIcon;

        @Bind(R.id.icon_selected)
        TextView icon_selected;
    }

    public ShareSocialPlateformAdapter(Context context, List<SocialShareDO> mList) {
        mContext = context;
        this.mInflater = LayoutInflater.from(context);
        this.mList = mList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = mInflater.inflate(R.layout.item_share_social_plateform, null);
        return new ViewHolder(convertView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        SocialShareDO share = mList.get(position);

        holder.rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/");
            }
        });

        if (share.isSelect()) {
            holder.icon_selected.setVisibility(View.VISIBLE);
        } else {
            holder.icon_selected.setVisibility(View.GONE);
        }

        if (share.getType() == 1) {
            holder.shareIcon.setText(mContext.getResources().getText(R.string.icon_wechat));
        } else if (share.getType() == 2) {
            holder.shareIcon.setText(mContext.getResources().getText(R.string.icon_weibo));
        } else {
            holder.shareIcon.setText(mContext.getResources().getText(R.string.icon_qq));
        }
    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }
}
