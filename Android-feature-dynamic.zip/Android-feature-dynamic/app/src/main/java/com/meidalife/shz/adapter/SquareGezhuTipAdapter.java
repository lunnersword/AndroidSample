package com.meidalife.shz.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.text.TextUtils;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 15/12/20.
 */
public class SquareGezhuTipAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    List<String> mData;

    static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.num)
        TextView num;

        @Bind(R.id.content)
        TextView content;
    }

    public SquareGezhuTipAdapter(Context context, List<String> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getCount() {
        return mData == null ? 0 : mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_square_gezhu_tip, parent, false);

            Activity activity = (Activity) mContext;
            Display display = activity.getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);
            int width = size.x;
            float margin = Helper.convertDpToPixel(20, mContext);

            width -= margin * 2;
            convertView.getLayoutParams().width = width;

            convertView.setTag(new ViewHolder(convertView));
        }


        ViewHolder holder = (ViewHolder) convertView.getTag();

        String tip = mData.get(position);

        holder.num.setText((position + 1) + "");
        if (TextUtils.isEmpty(tip)) {
            holder.content.setText("");
        } else {
            holder.content.setText(tip);
        }
        return convertView;
    }
}
