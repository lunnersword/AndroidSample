package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareManageTelephoneAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 格子管理中心-便民电话
 * Created by xingchen on 2015/12/23.
 */
public class MDSquareManageTelephoneActivity extends BaseActivity{

    private static int PUBLISH_SUCCESS = 80;

    @Bind(R.id.phoneListView)
    ListView phoneListView;
    @Bind(R.id.emptyView)
    View emptyView;
    @Bind(R.id.rootView)
    ViewGroup rootView;

    private int geziId = Integer.MAX_VALUE;
    private SquareManageTelephoneAdapter squareManageTelephoneAdapter;
    private JSONArray phoneList;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK && requestCode == PUBLISH_SUCCESS)
            initData();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_manage_telephone);

        ButterKnife.bind(this);
        initActionBar(R.string.phone, true, true);
        mButtonRight.setText(R.string.tab_item_publish_icon);
        mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().openFormResult("squaremanage/phone/update/" + geziId, PUBLISH_SUCCESS,MDSquareManageTelephoneActivity.this);
            }
        });

        if(!TextUtils.isEmpty(getIntent().getStringExtra("geziId")))
            geziId = Integer.parseInt(getIntent().getStringExtra("geziId"));
        phoneList = new JSONArray();
        squareManageTelephoneAdapter = new SquareManageTelephoneAdapter(this,phoneList);
        phoneListView.setAdapter(squareManageTelephoneAdapter);

        phoneListView.setOnCreateContextMenuListener(new View.OnCreateContextMenuListener() {
            @Override
            public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
                menu.add(0, 0, 0, R.string.square_delete_phone);
            }
        });

        phoneListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle params = new Bundle();
                JSONObject item = (JSONObject)phoneList.get(position);
                params.putInt("id", item.containsKey("id") ? item.getIntValue("id") : Integer.MAX_VALUE);
                params.putString("name", item.containsKey("name") ? item.getString("name") : "");
                params.putString("mobile", item.containsKey("mobile") ? item.getString("mobile") : "");
                Router.sharedRouter().openFormResult("squaremanage/phone/update/" + geziId, params,PUBLISH_SUCCESS,MDSquareManageTelephoneActivity.this);
            }
        });

        initData();
    }



    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = (int) info.id;
        switch (item.getItemId()) {
            case 0:
                deletePhone(position);
                break;
        }
        return super.onContextItemSelected(item);
    }

    private void initData(){
        phoneListView.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
        showStatusLoading(rootView);
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        HttpClient.get("1.0/gezi/yp/getMobiles", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                phoneListView.setVisibility(View.VISIBLE);

                if (obj instanceof JSONArray) {
                    phoneList.clear();
                    phoneList.addAll((JSONArray) obj);
                    if(phoneList.size() == 0){
                        emptyView.setVisibility(View.VISIBLE);
                        phoneListView.setVisibility(View.GONE);
                    }
                    squareManageTelephoneAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                }
            }
        });
    }

    private void deletePhone(final int position){
        showProgressDialog("正在删除");
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("geziId", geziId);
        params.put("id", phoneList.getJSONObject(position).containsKey("id")?phoneList.getJSONObject(position).getIntValue("id"):Integer.MAX_VALUE);
        HttpClient.get("1.0/gezi/yp/delMobile", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideProgressDialog();
                phoneList.remove(position);
                squareManageTelephoneAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "删除失败，请稍后再试");
            }
        });
    }
}
