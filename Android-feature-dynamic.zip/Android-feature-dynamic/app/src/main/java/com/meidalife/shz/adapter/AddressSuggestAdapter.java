package com.meidalife.shz.adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.activity.PickAddressActivity;
import com.meidalife.shz.rest.model.PositionOutDO;

import java.util.ArrayList;
import java.util.List;

public class AddressSuggestAdapter extends BaseAdapter {

    private List<PositionOutDO> data = new ArrayList<PositionOutDO>();
    private ItemClick mItemClickListener;
    private boolean mIsShowSelected = false;
    private int currentPosition = 0;
    private Context mContext;

    public AddressSuggestAdapter(Context context) {
        this.mContext = context;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(SHZApplication.getInstance());
            convertView = inflater.inflate(R.layout.shz_location_hint_item, null);
        }
        PositionOutDO mAddress = data.get(position);
        TextView txt = (TextView) convertView.findViewById(R.id.addressTitle);
        if (txt != null) {

            if (position == 0 && mContext instanceof PickAddressActivity) {
                txt.setText("[" + "当前" + "]" + mAddress.getName());
            } else {
                txt.setText(mAddress.getName());
            }
        }
        txt = (TextView) convertView.findViewById(R.id.addressDesc);
        if (txt != null) {
            txt.setText(mAddress.getAddress());
        }
        if (null != mItemClickListener) {
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mItemClickListener.onItemClick(getItem(position));
//					TBS.Page.ctrlClicked(CT.ListItem ,"点击“提供的联想结果”");
                }
            });
        }
        View icon = convertView.findViewById(R.id.icon_address_selected);
        if (mIsShowSelected && currentPosition == position) {
            icon.setVisibility(View.VISIBLE);
        } else {
            icon.setVisibility(View.GONE);
        }
        return convertView;
    }

    public void setItemClick(ItemClick itemClick) {
        this.mItemClickListener = itemClick;
    }

    public interface ItemClick {
        public void onItemClick(PositionOutDO address);
    }


    public void setData(List<PositionOutDO> addresses) {
        data.clear();
        data.addAll(addresses);
        this.notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public PositionOutDO getItem(int position) {
        return data.get(position);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    public void clear() {
        data.clear();
        notifyDataSetChanged();
    }

    ;

    public void setIsShowSelected(boolean isSelected) {
        mIsShowSelected = isSelected;
    }

    public void setCurrentPosition(int position) {
        currentPosition = position;
    }
}

