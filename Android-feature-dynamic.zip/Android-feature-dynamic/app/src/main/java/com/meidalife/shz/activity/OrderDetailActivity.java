package com.meidalife.shz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.OrderAttentionListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.BuyerVO;
import com.meidalife.shz.rest.model.ItemDO;
import com.meidalife.shz.rest.model.OrderDO;
import com.meidalife.shz.rest.model.SellerDO;
import com.meidalife.shz.rest.request.RequestOrder;
import com.meidalife.shz.rest.request.RequestOrderOpr;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.OrderUtil;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.MyWarnDialog;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class OrderDetailActivity extends BaseActivity {

    final int REQUEST_CODE_NEED_REFRESH = 200;

    String orderId;
    String tradeId;
    Boolean fromPayActivity = false;
    boolean buyerConfirmOk = false;
    //    String itemId;
//    String snapshotId;
    OrderDO mOrder;
    ItemDO mFirstItem;
    HttpClient.HttpCallback<OrderDO> getOrderCallback;
    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.cellOperateBar)
    RelativeLayout cellOperateBar;
    @Bind(R.id.cellExpress)
    RelativeLayout cellExpress;
    @Bind(R.id.cellReason)
    LinearLayout cellReason;
    @Bind(R.id.cellInnerPayways)
    LinearLayout cellInnerPayways;
    @Bind(R.id.cellServiceTime)
    RelativeLayout cellServiceTime;
    @Bind(R.id.cellServiceAddress)
    RelativeLayout cellServiceAddress;
    @Bind(R.id.tradeTimeDetail)
    LinearLayout tradeTimeDetail;
    @Bind(R.id.userGroup)
    ViewGroup userGroup;

    @Bind(R.id.sellerRemarkLayout)
    ViewGroup sellerRemarkLayout;
    @Bind(R.id.sellerRemarkFlag)
    TextView sellerRemarkFlag;
    @Bind(R.id.sellerInnerRemark)
    TextView sellerInnerRemark;

    @Bind(R.id.textTips)
    TextView textTips;
    @Bind(R.id.textServiceMessage)
    TextView textServiceMessage;
    @Bind(R.id.textServiceAddress)
    TextView textServiceAddress;
    @Bind(R.id.textServiceTime)
    TextView textServiceTime;
    @Bind(R.id.textServiceType)
    TextView textServiceType;
    @Bind(R.id.textServiceContact)
    TextView textServiceContact;
    @Bind(R.id.textServiceUser)
    TextView textServiceUser;
    //支付合计
    @Bind(R.id.textSumCostNumber)
    TextView textSumCostNumber;
    @Bind(R.id.sumCostTitle)
    TextView sumCostTitle;
    @Bind(R.id.cellPaywayAlipay)
    RelativeLayout cellPaywayAlipay;
    @Bind(R.id.cellPaywayWeChat)
    RelativeLayout cellPaywayWeChat;
    @Bind(R.id.cellPaywayFund)
    RelativeLayout cellPaywayFund;
    @Bind(R.id.cellPaywayPoint)
    RelativeLayout cellPaywayPoint;
    @Bind(R.id.textPaywayFundNumber)
    TextView textPaywayFundNumber;
    @Bind(R.id.squareFeeLayout)
    ViewGroup squareFeeLayout;
    @Bind(R.id.squareFeeDesc)
    TextView squareFeeDesc;
    @Bind(R.id.squareFeeValue)
    TextView squareFeeValue;
    @Bind(R.id.squareFeeLink)
    TextView squareFeeLink;

    //派单相关
    @Bind(R.id.paiDanLayout)
    ViewGroup paiDanLayout;
    @Bind(R.id.paiDanContactTitle)
    TextView paiDanContactTitle;
    @Bind(R.id.paiDanContactContent)
    TextView paiDanContactContent;
    @Bind(R.id.paiDanContactButton)
    TextView paiDanContactButton;

    //红包抵扣
    @Bind(R.id.cellPaywayCouponRL)
    RelativeLayout cellPayWayCouponRL;
    @Bind(R.id.textPaywayCouponAmount)
    TextView textPaywayCouponAmount;

    @Bind(R.id.textPaywayPointNumber)
    TextView textPaywayPointNumber;
    @Bind(R.id.textPaywayAlipayNumber)
    TextView textPaywayAlipayNumber;
    @Bind(R.id.textPaywayWeChatNumber)
    TextView textPaywayWeChatNumber;
    @Bind(R.id.textOrderReason)
    TextView textOrderReason;
    //宝贝价格 总计
    @Bind(R.id.textItemPrice)
    TextView textItemPrice;
    @Bind(R.id.squareOrder)
    TextView squareOrder;
    //    @Bind(R.id.textNick)
//    TextView textNick;
    @Bind(R.id.textExpress)
    TextView textExpress;
    @Bind(R.id.textOrderStatus)
    TextView textOrderStatus;
    @Bind(R.id.cellSubOperate)
    LinearLayout cellSubOperate;
    @Bind(R.id.cellMainOperate)
    LinearLayout cellMainOperate;
    @Bind(R.id.cellOrderNo)
    RelativeLayout cellOrderNo;
    @Bind(R.id.textOrderNo)
    TextView textOrderNo;
    @Bind(R.id.cellPhoneLayout)
    RelativeLayout cellPhoneLayout;

//    @Bind(R.id.textServiceQuantity)
//    TextView textServiceQuantity;

    //定金
    @Bind(R.id.earnestLayout)
    ViewGroup earnestLayout;
    @Bind(R.id.earnestTitle)
    TextView earnestTitle;
    @Bind(R.id.earnestValue)
    TextView earnestValue;
    //尾款
    @Bind(R.id.finalPayLayout)
    ViewGroup finalPayLayout;
    @Bind(R.id.finalPayTitle)
    TextView finalPayTitle;
    @Bind(R.id.finalPayValue)
    TextView finalPayValue;

    //改价区域
    @Bind(R.id.changedAmountView)
    View changedAmountView;

    @Bind(R.id.changedAmount)
    TextView changedAmount;

    @Bind(R.id.bargainAmount)
    TextView bargainAmount;
    @Bind(R.id.bargainAmountView)
    RelativeLayout bargainAmountView;
    @Bind(R.id.changeLine)
    View changeLine;

    @Bind(R.id.bonusReturnLayout)
    ViewGroup bonusReturnLayout;
    @Bind(R.id.bonusReturnTitle)
    TextView bonusReturnTitle;
    @Bind(R.id.bonusReturnDesc)
    TextView bonusReturnDesc;
    @Bind(R.id.bonusShareButton)
    TextView bonusShareButton;
    @Bind(R.id.bonusReturnCancel)
    TextView bonusReturnCancel;
    @Bind(R.id.snapshotItem)
    TextView snapshotItem;
    CountDownTimer timer;
    @Bind(R.id.textGeziName)
    TextView textGeziName;
    @Bind(R.id.chatLayout)
    View chatLayout;
    @Bind(R.id.callText)
    TextView callText;
    @Bind(R.id.shzTagView)
    View shzTagView;

    @Bind(R.id.serviceItemGroup)
    LinearLayout serviceItemGroup;
    @Bind(R.id.imageAvatar)
    SimpleDraweeView imageAvatar;
    @Bind(R.id.textSellerName)
    TextView textSellerName;
    @Bind(R.id.cellServiceContact)
    View cellServiceContact;
    @Bind(R.id.cellServiceUser)
    View cellServiceUser;


    String name = null;
    String code = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        initActionBar(R.string.title_activity_order_detail, true);
        ButterKnife.bind(this);

        Bundle intentExtras = getIntent().getExtras();
        orderId = intentExtras.getString("orderId");
        tradeId = intentExtras.getString("tradeId");
        fromPayActivity = intentExtras.getBoolean("fromPayActivity", false);
        if (!Helper.sharedHelper().hasToken()) {
            Bundle bundle = new Bundle();
            String url = null;
            if (orderId != null) url = "orders/" + orderId;
            if (tradeId != null) url = "ordersByTradeNo/" + tradeId;
            bundle.putString("action", url);
            Router.sharedRouter().open("signin", bundle);
            finish();
        }

        Log.i("Taber", "orderId: " + orderId);
        Log.i("Taber", "tradeId: " + tradeId);

        getOrderCallback = new HttpClient.HttpCallback<OrderDO>() {
            @Override
            public void onSuccess(OrderDO result) {
                hideStatusLoading();
                scrollView.setVisibility(View.VISIBLE);
                cellOperateBar.setVisibility(View.VISIBLE);
                mOrder = (OrderDO) result;
                renderOrder();
                if (buyerConfirmOk) {
                    buyerConfirmOk = false;
                    Router.sharedRouter().open("orderJudge/" + OrderJudgeActivity.ADD + "/" + mFirstItem.getItemId() + "/" + orderId);
                }
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();

                if (error != null) {
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        showStatusErrorNetwork(rootView);
                        setOnClickErrorNetwork(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                xhrOrder();
                            }
                        });
                    } else {
                        showStatusErrorServer(rootView);
                        setTextErrorServer(error.getMessage());
                        setOnClickErrorServer(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                xhrOrder();
                            }
                        });
                    }
                } else {
                    showStatusErrorServer(rootView);
                    setTextErrorServer("获取数据失败，请点击重试");
                    setOnClickErrorServer(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrOrder();
                        }
                    });
                }
            }
        };
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        xhrOrder();
    }

    private void xhrOrder() {
        if (orderId != null || tradeId != null) {
            showStatusLoading(rootView);
            hideStatusErrorNetwork();
            hideStatusErrorServer();
            scrollView.setVisibility(View.GONE);
            cellOperateBar.setVisibility(View.GONE);

            if (orderId != null) {
                RequestOrder.getOrder(orderId, getOrderCallback);
            } else if (tradeId != null) {
                RequestOrder.getOrderByTradeNo(tradeId, getOrderCallback);
            }
        } else {
            showStatusErrorServer(rootView);
            setTextErrorServer("缺少入参，没有订单或交易号");
        }
    }

    private void renderOrder() {

        final SellerDO seller = mOrder.getUser();
        final BuyerVO buyer = mOrder.getBuyer();
        orderId = mOrder.getOrderNo();

        //多服务
        if (CollectionUtil.isNotEmpty(mOrder.getItemList())) {
            addServiceItem(mOrder.getItemList());
            mFirstItem = mOrder.getItemList().get(0);
        }

        // Tips & countdown
        if (mOrder.getCountdownText() != null && mOrder.getCountdown() > 0) {
            textTips.setVisibility(View.VISIBLE);
            if (timer != null) {
                timer.cancel();
            }
            timer = new CountDownTimer(mOrder.getCountdown() * 1000);
            timer.start();
        } else if (!TextUtils.isEmpty(mOrder.getTips())) {
            textTips.setVisibility(View.VISIBLE);
            textTips.setText(mOrder.getTips());
        } else {
            textTips.setVisibility(View.GONE);
        }

        if (mOrder.getRoleType() == OrderUtil.ROLE_TYPE_BUY) {
            if (seller != null) {
                if (TextUtils.isEmpty(seller.getSellerPhone()) || seller.getSellerPhone().contains("*")) {
                    cellPhoneLayout.setVisibility(View.GONE);
                }
            }
        } else {
            if (buyer != null) {
                if (TextUtils.isEmpty(buyer.getContactorPhone()) || buyer.getContactorPhone().contains("*")) {
                    cellPhoneLayout.setVisibility(View.GONE);
                }
            }
            if (mOrder.getGezi() != null && mOrder.getGezi().getGeziName() != null
                    && !mOrder.getGezi().getGeziName().trim().equals("")) {
                StringBuilder geziSB = new StringBuilder();
                textGeziName.setVisibility(View.VISIBLE);
                geziSB.append("来自：");
                geziSB.append(mOrder.getGezi().getGeziName());
                if (mOrder.getGezi().getGeziTypeDesc() != null && !mOrder.getGezi().getGeziTypeDesc().trim().equals("")) {
                    geziSB.append(String.format("[%s]", mOrder.getGezi().getGeziTypeDesc()));
                }
                textGeziName.setText(geziSB.toString());
            } else {
                textGeziName.setVisibility(View.GONE);
            }
        }

        //卖家备注
        try {
            if (mOrder.getRoleType() == OrderUtil.ROLE_TYPE_SELL && !TextUtils.isEmpty(mOrder.getSellerInnerRemark())) {
                sellerRemarkLayout.setVisibility(View.VISIBLE);
                sellerInnerRemark.setText("备注：" + mOrder.getSellerInnerRemark());
                if (null != mOrder.getSellerInnerFlag() &&
                        mOrder.getSellerInnerFlag() > 0) {
                    sellerRemarkFlag.setTextColor(getResources().getColor(OrderUtil.
                            getRemarkFlagColor(mOrder.getSellerInnerFlag() - 1)));
                }
            } else {
                sellerRemarkLayout.setVisibility(View.GONE);
            }
        } catch (Resources.NotFoundException e) {
            sellerRemarkLayout.setVisibility(View.GONE);
            e.printStackTrace();
        }

        if (mOrder.getUser() != null) {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(mOrder.getUser().getAvatar(), imageAvatar.getLayoutParams().width));
            imageAvatar.setImageURI(uri);
            textSellerName.setText(mOrder.getUser().getUserNick());
        }

        // 订单状态
        textOrderStatus.setText(mOrder.getStatusText());

        // 物流
        if (mOrder.getDeliverNo() != null && mOrder.getLogisticsCompany() != null) {
            cellExpress.setVisibility(View.VISIBLE);
            try {
                JSONObject company = mOrder.getLogisticsCompany();

                if (company.containsKey("name")) {
                    name = company.getString("name");
                }
                if (company.containsKey("code")) {
                    code = company.getString("code");
                }
                final String deliverNo = mOrder.getDeliverNo();
                if ("#".equals(code)) {
                    textExpress.setText(name);
                } else {
                    textExpress.setText(name + "-" + deliverNo);
                    cellExpress.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // http://m.kuaidi100.com/index_all.html?type=%E5%85%A8%E5%B3%B0&postid=123456789
                            Bundle bundle = new Bundle();
                            bundle.putString("url", "http://m.kuaidi100.com/index_all.html?type=" + code + "&postid=" + deliverNo);
                            Router.sharedRouter().open("web", bundle);
                        }
                    });
                }
            } catch (JSONException e) {
            }
        } else {
            cellExpress.setVisibility(View.GONE);
        }

        textItemPrice.setText(mOrder.getItemAmountStr() + "元");

        //增加以优惠内容 （已优惠0元，追加付款0元）
        userGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!mOrder.getIsPaidan() && seller != null) {
                    Router.sharedRouter().open("profile/" + seller.getUserId());
                }
            }
        });

        if (mOrder.getGezi() != null && !TextUtils.isEmpty(mOrder.getGezi().getGeziId())) {
            squareOrder.setVisibility(View.VISIBLE);
        } else {
            squareOrder.setVisibility(View.GONE);
        }

        // 理由
        if (!TextUtils.isEmpty(mOrder.getReason())) {
            textOrderReason.setText(mOrder.getReason());
            cellReason.setVisibility(View.VISIBLE);
        } else {
            cellReason.setVisibility(View.GONE);
        }

        // 支付详情
        if (mOrder.getPaywayList() != null && mOrder.getRoleType() == OrderUtil.ROLE_TYPE_BUY) {
            cellInnerPayways.setVisibility(View.VISIBLE);
            cellPaywayAlipay.setVisibility(View.GONE);
            cellPaywayFund.setVisibility(View.GONE);
            cellPaywayPoint.setVisibility(View.GONE);
            cellPaywayWeChat.setVisibility(View.GONE);

            //红包抵扣
//            cellPayWayCouponRL.setVisibility(View.GONE); 需要完善 接口连调
            JSONArray paywayList = mOrder.getPaywayList();
            try {
                if (CollectionUtil.isNotEmpty(paywayList)) {
                    for (int i = 0; i < paywayList.size(); i++) {
                        JSONObject payway = paywayList.getJSONObject(i);
                        switch (payway.getIntValue("payway")) {
                            case Pay.PAY_WAY_ALIPAY:
                                cellPaywayAlipay.setVisibility(View.VISIBLE);
                                textPaywayAlipayNumber.setText(StrUtil.doubleFormat(payway.getIntValue("amount") / 100.0) + "元");
                                break;
                            case Pay.PAY_WAY_WECHAT:
                                cellPaywayWeChat.setVisibility(View.VISIBLE);
                                textPaywayWeChatNumber.setText(StrUtil.doubleFormat(payway.getIntValue("amount") / 100.0) + "元");
                                break;
                            case Pay.PAY_WAY_FUND:
                                cellPaywayFund.setVisibility(View.VISIBLE);
                                textPaywayFundNumber.setText(StrUtil.doubleFormat(payway.getIntValue("amount") / 100.0) + "元");
                                break;
                            case Pay.PAY_WAY_MCOIN:
                                cellPaywayPoint.setVisibility(View.VISIBLE);
                                textPaywayPointNumber.setText(StrUtil.doubleFormat(payway.getIntValue("amount") / 100.0) + "个");
                                break;
                            case Pay.PAY_WAY_COUPON:
                                cellPayWayCouponRL.setVisibility(View.VISIBLE);
                                textPaywayCouponAmount.setText(StrUtil.doubleFormat(payway.getIntValue("amount") / 100.0) + "元");
                                break;
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            cellInnerPayways.setVisibility(View.GONE);
        }

        if (mOrder.getGezi() != null && !TextUtils.isEmpty(mOrder.getGezi().getGeziFeeAmount())) {
            squareFeeLayout.setVisibility(View.VISIBLE);
            int amount = Integer.parseInt(mOrder.getGezi().getGeziFeeAmount());
            squareFeeDesc.setText(String.format("格子服务费（%s）", mOrder.getGezi().getGeziFeeRate()));
            squareFeeValue.setText(String.format("- %s 元", StrUtil.doubleFormat(amount / 100.0)));
            squareFeeLink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", mOrder.getGezi().getGeziFeeUrl());
                    Router.sharedRouter().open("web", bundle);
                }
            });
        } else {
            squareFeeLayout.setVisibility(View.GONE);
        }

        //显示追加付款
        if (!"0.00".equals(mOrder.getAddAmount())) {
            changedAmountView.setVisibility(View.VISIBLE);
            changeLine.setVisibility(View.VISIBLE);
            changedAmount.setText("+" + mOrder.getAddAmount() + "元");
        }

        //显示修改价格
        if (!"0.00".equals(mOrder.getBargainAmount())) {
            bargainAmountView.setVisibility(View.VISIBLE);
            changeLine.setVisibility(View.VISIBLE);
            bargainAmount.setText(mOrder.getBargainAmount() + "元");
        }

        textSumCostNumber.setText(mOrder.getAmountStr() + "元");
        sumCostTitle.setText(mOrder.getRoleType() == OrderUtil.ROLE_TYPE_BUY ? "订单总价: " : "收入合计: ");

        // IM & 电话

        // 联系人和联系方式
        if (mOrder.getBuyer() != null) {
            cellServiceUser.setVisibility(View.VISIBLE);
            cellServiceContact.setVisibility(View.VISIBLE);
            textServiceUser.setText(mOrder.getBuyer().getContactorName());
            textServiceContact.setText(mOrder.getBuyer().getContactorPhone());
        } else {
            cellServiceUser.setVisibility(View.GONE);
            cellServiceContact.setVisibility(View.GONE);
        }

        View cellServiceGroup = findViewById(R.id.cellServiceMessage);
        if (StrUtil.isEmpty(mOrder.getBuyerRemark())) {
            cellServiceGroup.setVisibility(View.GONE);
        } else {
            cellServiceGroup.setVisibility(View.VISIBLE);
            textServiceMessage.setText(mOrder.getBuyerRemark());
        }

        if (!TextUtils.isEmpty(mOrder.getBookTime())) {
            cellServiceTime.setVisibility(View.VISIBLE);
            textServiceTime.setText(mOrder.getBookTime());
        } else {
            cellServiceTime.setVisibility(View.GONE);
        }


        if (buyer != null && buyer.getAddressName() != null) {
            textServiceAddress.setText(buyer.getAddressName());
            cellServiceAddress.setVisibility(View.VISIBLE);
        } else {
            cellServiceAddress.setVisibility(View.GONE);
        }

        // 订单号
        textOrderNo.setText(mOrder.getOrderNo());

        // 交易信息
        if (mOrder.getStatusSteps() != null) {
            try {
                tradeTimeDetail.removeAllViews();
                JSONArray statusSteps = mOrder.getStatusSteps();
                if (CollectionUtil.isNotEmpty(statusSteps)) {
                    for (int i = 0; i < statusSteps.size(); i++) {
                        String stepsString = "";
                        JSONObject item = statusSteps.getJSONObject(i);
                        stepsString += item.getString("timeName") + "：" + item.getString("timeText");
                        FontTextView tradeTime = new FontTextView(OrderDetailActivity.this);
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT);
                        tradeTime.setLayoutParams(lp);
                        tradeTime.setTextColor(getResources().getColor(R.color.grey_a));
                        tradeTime.setTextSize(14);
                        tradeTime.setBackgroundResource(R.drawable.border_bottom);
                        int padding = getResources().getDimensionPixelSize(R.dimen.activity_vertical_margin);
                        tradeTime.setPadding(padding, padding, padding, padding);
                        tradeTime.setText(stepsString);
                        tradeTimeDetail.addView(tradeTime);
                    }
                }
            } catch (JSONException e) {

            }
        }

        // 设置操作
        List<Object[]> mainOprList = OrderUtil.getMainOperateList(mOrder.getOperate(), mOrder);

        //卖家回复评论与才看评论不共存（为解决卖家能修改买家评论BUG）
        mainOprList = OrderUtil.removeCommentOpr(mainOprList);

        List<Object[]> subOprList = OrderUtil.getSubOperateList(mOrder.getOperate());

        if (mainOprList == null || mainOprList.size() == 0) {
            cellOperateBar.setVisibility(View.GONE);
        } else {
            cellOperateBar.setVisibility(View.VISIBLE);
            addMainOperateButton(mainOprList);
        }

        if (subOprList == null || subOprList.size() == 0) {
            cellSubOperate.setVisibility(View.GONE);
        } else {
            cellSubOperate.setVisibility(View.VISIBLE);
            addSubOperateButton(subOprList);
        }

        initRedpaperReturnLayout();

        snapshotItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 默认跳转到第一个宝贝快照
                Router.sharedRouter().open("service_snapshot/" + mFirstItem.getItemId() + "/" + mFirstItem.getSnapshotItemId());
            }
        });

        renderPresellSection();
        renderPaiDanLayout();
    }

    private void addServiceItem(List<ItemDO> itemDOs) {
        serviceItemGroup.removeAllViews();
        for (ItemDO item : itemDOs) {
            textServiceType.setText(item.getServiceTypeText());
            View itemView = LayoutInflater.from(this).inflate(R.layout.view_order_service_item, serviceItemGroup, false);
            SimpleDraweeView imageItem = (SimpleDraweeView) itemView.findViewById(R.id.imageItem);
            if (!TextUtils.isEmpty(item.getItemImage())) {
                String url = ImgUtil.getCDNUrlWithWidth(item.getItemImage(), imageItem.getLayoutParams().width);
                if (!TextUtils.isEmpty(url)) {
                    imageItem.setImageURI(Uri.parse(url));
                }
            }
            ((TextView) itemView.findViewById(R.id.textItemTag)).setText("我能·" + item.getTitle());
            if (item.getSku() != null) {
                ((TextView) itemView.findViewById(R.id.skuName)).setText("服务规格：" + item.getSku().getName());
                TextView oriPriceItemPrice = (TextView) itemView.findViewById(R.id.oriPriceItemPrice);
                if (item.getSku().getPromotionPrice() != null) {
                    oriPriceItemPrice.setVisibility(View.VISIBLE);
                    oriPriceItemPrice.setText(item.getSku().getPrice() + "元");
                    ((TextView) itemView.findViewById(R.id.textItemPrice)).setText(item.getSku().getPromotionPrice() + "元");
                    oriPriceItemPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
                } else {
                    oriPriceItemPrice.setVisibility(View.GONE);
                    ((TextView) itemView.findViewById(R.id.textItemPrice)).setText(item.getSku().getPrice() + "元");
                }
            }
            TextView count = (TextView) itemView.findViewById(R.id.count);
            count.setText("x" + item.getCount());
            View itemInfoView = itemView.findViewById(R.id.itemInfoView);
            itemInfoView.setTag(item.getItemId());
            itemInfoView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String id = (String) v.getTag();
                    if (id == null)
                        return;
                    if ((null == mOrder.getOrderType() || mOrder.getOrderType() != 3) && (mOrder.getIsPaidan() != null && !mOrder.getIsPaidan())) {  //一元夺宝活动订单,派单,屏蔽点击查看
                        Router.sharedRouter().open("services/" + id);
                    }
                }
            });
            //服务类型
            if (null != item.getServiceTypeText()) {
                TextView itemServiceType = (TextView) itemView.findViewById(R.id.itemServiceType);
                itemServiceType.setVisibility(View.VISIBLE);
                itemServiceType.setText(item.getServiceTypeText());
            }

            //线上服务 隐藏电话
            if (null != item.getServiceType() && Constant.SERVICE_TYPE_ONLINE == item.getServiceType()) {
                cellPhoneLayout.setVisibility(View.GONE);
            }
            //活动标
            ViewGroup promotionLayout = (ViewGroup) itemView.findViewById(R.id.promotionLayout);
            promotionLayout.removeAllViews();
            if (null != item.getPromotionTips() && item.getPromotionTips().size() > 0) {
                for (String str : item.getPromotionTips()) {
                    View promotionView = LayoutInflater.from(this).inflate(R.layout.view_promotion, promotionLayout, false);
                    ((TextView) (promotionView.findViewById(R.id.promotion))).setText(str);
                    promotionLayout.addView(promotionView);
                }
            }
            serviceItemGroup.addView(itemView);
        }
    }

    private void renderPaiDanLayout() {
        try {
            if (mOrder.getIsPaidan() != null && mOrder.getIsPaidan()) {
                chatLayout.setVisibility(View.GONE);
                snapshotItem.setVisibility(View.GONE);
                shzTagView.setVisibility(View.VISIBLE);
                if (null != mOrder.getCsPhone()) {
                    cellPhoneLayout.setVisibility(View.VISIBLE);
                    callText.setText(getResources().getString(R.string.btn_contact_us));
                    cellPhoneLayout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Helper.makeCall(OrderDetailActivity.this, mOrder.getCsPhone());
                        }
                    });
                }

                if (mOrder.getPaidan() != null && mOrder.getPaidan().containsKey("spPhone")) {
                    paiDanLayout.setVisibility(View.VISIBLE);
                    final String tel = mOrder.getPaidan().getString("spPhone");
                    paiDanContactTitle.setText(mOrder.getPaidan().getString("spName"));
                    paiDanContactContent.setText(mOrder.getPaidan().getString("spPhone"));
                    paiDanContactButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Helper.makeCall(OrderDetailActivity.this, tel);
                        }
                    });
                } else if (mOrder.getPaidan() != null) {
                    paiDanLayout.setVisibility(View.VISIBLE);
                    paiDanContactTitle.setText(mOrder.getPaidan().getString("statusText"));
                    paiDanContactContent.setText(mOrder.getPaidan().getString("tipsText"));
                    paiDanContactButton.setVisibility(View.GONE);
                } else {
                    paiDanLayout.setVisibility(View.GONE);
                }
            } else {
                paiDanLayout.setVisibility(View.GONE);
                snapshotItem.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            paiDanLayout.setVisibility(View.GONE);
        }
    }

    private void renderPresellSection() {
        try {
            if (CollectionUtil.isNotEmpty(mOrder.getPresellPayList())) {
                earnestLayout.setVisibility(View.VISIBLE);
                earnestTitle.setText(mOrder.getPresellPayList().getJSONObject(0).getString("title"));
                earnestValue.setText(mOrder.getPresellPayList().getJSONObject(0).getString("money"));

                if (mOrder.getPresellPayList().size() > 1) {
                    finalPayLayout.setVisibility(View.VISIBLE);
                    finalPayTitle.setText(mOrder.getPresellPayList().getJSONObject(1).getString("title"));
                    finalPayValue.setText(mOrder.getPresellPayList().getJSONObject(1).getString("money"));
                }
            } else {
                earnestLayout.setVisibility(View.GONE);
                finalPayLayout.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initRedpaperReturnLayout() {
        try {
            if (null != mOrder.getRedpack()) {
                final String shareTitle = mOrder.getRedpack().getString("shareTitle");
                final String shareUrl = mOrder.getRedpack().getString("shareUrl");
                final String shareIcon = mOrder.getRedpack().getString("shareIcon");
                final String shareContent = mOrder.getRedpack().getString("shareContent");

                final String subText = mOrder.getRedpack().getString("subText");
                final String amount = mOrder.getRedpack().getString("value");
                if (!TextUtils.isEmpty(amount)) {
                    String returnRedPaperTitle = String.format(getString(R.string.get_return_redpaper), amount);
                    final Intent intent = new Intent();
                    intent.setClass(OrderDetailActivity.this, OrderRedpaperReturnActivity.class);
                    intent.putExtra(Constant.EXTRA_TAG_SHARE_TITLE, shareTitle);
                    intent.putExtra(Constant.EXTRA_TAG_AMOUNT, amount);
                    intent.putExtra(Constant.EXTRA_TAG_DESC, subText);
                    intent.putExtra(Constant.EXTRA_TAG_SHARE_URL, shareUrl);
                    intent.putExtra(Constant.EXTRA_TAG_SHARE_ICON, shareIcon);
                    intent.putExtra(Constant.EXTRA_TAG_SHARE_CONTENT, shareContent);
                    intent.putExtra(Constant.EXTRA_TAG_ORDER_NO, mOrder.getOrderNo());

                    if (fromPayActivity) {
                        startActivity(intent);
                        fromPayActivity = false;
                        return;
                    }
                    bonusReturnTitle.setText(StrUtil.getDigitSpanText(returnRedPaperTitle,
                            getResources().getColor(R.color.brand_b),
                            getResources().getDimensionPixelSize(R.dimen.font_size_large)));
                    bonusReturnLayout.setVisibility(View.VISIBLE);
                    bonusReturnCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            bonusReturnLayout.setVisibility(View.GONE);
                        }
                    });
                    bonusShareButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            startActivity(intent);
                        }
                    });
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isPriceChanged() {
        return !mOrder.getAmountStr().equals(mOrder.getDealAmountDtr());
    }


    /**
     * 增加可操作列表
     */
    private void addMainOperateButton(List<Object[]> oprList) {
        cellMainOperate.removeAllViews();

        if (mOrder.getRoleType() == OrderUtil.ROLE_TYPE_SELL) {
            TextView button = new FontTextView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) Helper.convertDpToPixel(74, this), (int) Helper.convertDpToPixel(40, this));
            params.setMargins((int) Helper.convertDpToPixel(10, this), 0, 0, 0);
            button.setLayoutParams(params);
            button.setGravity(Gravity.CENTER);
            button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            button.setText("备注");
            button.setTag(R.id.order_list_opr, OrderUtil.OPEN_REMARK);
            button.setTextColor(getResources().getColor(R.color.grey_a));
            button.setBackgroundResource(R.drawable.order_list_edit_bg_white);
            OperateClickListener oprListener = new OperateClickListener();
            button.setOnClickListener(oprListener);
            cellMainOperate.addView(button);
        }
        for (int i = oprList.size() - 1; i >= 0; i--) {
            Object[] data = oprList.get(i);
            TextView button = new FontTextView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) Helper.convertDpToPixel(74, this), (int) Helper.convertDpToPixel(40, this));
            params.setMargins((int) Helper.convertDpToPixel(10, this), 0, 0, 0);
            button.setLayoutParams(params);
            button.setGravity(Gravity.CENTER);
            button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            button.setText((String) data[1]);
            button.setTag(R.id.order_list_opr, (Long) data[0]);
            if ((int) data[2] == 0) {
                button.setTextColor(getResources().getColor(R.color.grey_a));
                button.setBackgroundResource(R.drawable.order_list_edit_bg_white);
            } else {
                button.setTextColor(getResources().getColor(R.color.brand_b));
                button.setBackgroundResource(R.drawable.order_list_edit_bg_red);
            }
            OperateClickListener oprListener = new OperateClickListener();
            button.setOnClickListener(oprListener);
            cellMainOperate.addView(button);
        }
    }

    /**
     * 添加退款操作
     */
    private void addSubOperateButton(List<Object[]> oprList) {
        cellSubOperate.removeAllViews();

        for (int i = 0; i < oprList.size(); i++) {
            Object[] data = oprList.get(i);
            TextView button = new FontTextView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) Helper.convertDpToPixel(74, this), (int) Helper.convertDpToPixel(30, this));
            params.setMargins((int) Helper.convertDpToPixel(10, this), 0, 0, 0);
            button.setLayoutParams(params);
            button.setGravity(Gravity.CENTER);
            button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            button.setText((String) data[1]);
            button.setTag(R.id.order_list_opr, (Long) data[0]);
            button.setTextColor(getResources().getColor(R.color.brand_b));
            button.setBackgroundResource(R.drawable.order_list_edit_bg_red);
            OperateClickListener oprListener = new OperateClickListener();
            button.setOnClickListener(oprListener);
            cellSubOperate.addView(button);
        }
    }

//    public void handleOpenServiceDetail(View view) {
//        //Router.sharedRouter().open("service_snapshot/" + itemId + "/" + mOrder.getSnapshotItemId());
//        Router.sharedRouter().open("services/" + itemId);
//    }

    public void handleOpenChat(View view) {
        if (mOrder != null && mOrder.getUser() != null) {
            Router.sharedRouter().open("chat/" + mOrder.getUser().getUserId() + "/orderNo/" + mOrder.getOrderNo());
        }
    }

    public void handleCallPhone(View view) {
        if (mOrder.getRoleType() == OrderUtil.ROLE_TYPE_BUY) {
            if (mOrder != null && mOrder.getUser() != null) {
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + mOrder.getUser().getSellerPhone()));
                startActivity(intent);
            }
        } else {
            if (mOrder != null && mOrder.getBuyer() != null) {
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + mOrder.getBuyer().getContactorPhone()));
                startActivity(intent);
            }
        }
    }

    public void operateBuyerConfirmOrder(final boolean needDeliver) {
        String msg = "";
        if (needDeliver) {
            msg = "确认收货后，" + mOrder.getAmountStr() + "元将立即到卖家账户，请务必在收到货后再确认";
        } else {
            msg = "确认服务后，" + mOrder.getAmountStr() + "元将立即到卖家账户，请务必在服务完成后确认";
        }
        tip(msg, new TipCallback() {
            @Override
            public void execute() {
                showProgressDialog("正在确认");
                RequestOrderOpr.confirm(orderId, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
                    @Override
                    public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                        buyerConfirmOk = true;
                        RequestOrder.getOrder(orderId, getOrderCallback);
                        hideProgressDialog();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter(error != null ? error.getMessage() : "确认服务失败，请重试");
                        hideProgressDialog();
                    }
                });
            }
        });
    }

    public void operateBuyerComment() {
        Router.sharedRouter().openFormResult("orderJudge/" + OrderJudgeActivity.ADD + "/" + mFirstItem.getItemId() + "/" + orderId, REQUEST_CODE_NEED_REFRESH, OrderDetailActivity.this);
    }

    public void operatePay() {
        if (isPriceChanged()) {
            String tipsContent = "订单总价由" + mOrder.getAmountStr() + "元被修改为" + mOrder.getDealAmountDtr() + "元";
            MessageUtils.createDialog(OrderDetailActivity.this, "订单价格有变动 是否要继续付款？", tipsContent, R.string.confirm, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dealOperatePay();
                }
            }, R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    hideProgressDialog();
                }
            }).show();
        } else {
            dealOperatePay();
        }

    }

    void dealOperatePay() {
        Bundle bundle = new Bundle();
        bundle.putString("orderNo", mOrder.getOrderNo());
        if (CollectionUtil.isNotEmpty(mOrder.getItemList())) {
            bundle.putString("title", mOrder.getItemList().get(0).getTitle());
        }
        Router.sharedRouter().openFormResult("pay", bundle, REQUEST_CODE_NEED_REFRESH, OrderDetailActivity.this);
    }

    public void operateBuyerCancel() {
        tip("确认取消订单？取消后需重新下单", new TipCallback() {
            @Override
            public void execute() {
                showProgressDialog("正在取消订单");
                RequestOrderOpr.cancel(orderId, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
                    @Override
                    public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                        RequestOrder.getOrder(orderId, getOrderCallback);
                        hideProgressDialog();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter(error != null ? error.getMessage() : "取消订单失败，请重试");
                        hideProgressDialog();
                    }
                });
            }
        });
    }

    public void operateBuyerRefund() {
        Router.sharedRouter().openFormResult("orderCancel/" + orderId + "/cancel", REQUEST_CODE_NEED_REFRESH, OrderDetailActivity.this);
    }

    public void operateBuyerAppendCost() {
        Router.sharedRouter().openFormResult("orderAdd/" + orderId, REQUEST_CODE_NEED_REFRESH, OrderDetailActivity.this);
    }

    public void operateSellerRejectOrder() {
        Router.sharedRouter().openFormResult("orderCancel/" + orderId + "/reject", REQUEST_CODE_NEED_REFRESH, OrderDetailActivity.this);
    }

    public void operateSellerAcceptOrder() {
        showProgressDialog("正在接单");
        RequestOrderOpr.sellConfirm(orderId, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                RequestOrder.getOrder(orderId, getOrderCallback);
                hideProgressDialog();
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "确认接单失败，请重试");
                hideProgressDialog();
            }
        });
    }

    public void operateSellerComment() {
        String commentId = null;
        try {
            JSONObject json = JSONObject.parseObject(mOrder.getComment());
            commentId = json.getString("commentId");
            Router.sharedRouter().openFormResult("orderReply/" + OrderJudgeActivity.REPLY + "/" + commentId + "/" + orderId, REQUEST_CODE_NEED_REFRESH, OrderDetailActivity.this);
        } catch (Exception e) {
            MessageUtils.showToastCenter(e.getMessage());
        }
    }

    public void operateOpenComments() {
        Router.sharedRouter().openFormResult("orderCommentByOrderId/" + orderId, REQUEST_CODE_NEED_REFRESH, OrderDetailActivity.this);
    }

    public void operateDelivery() {
        Router.sharedRouter().openFormResult("orderDelivery/" + mOrder.getOrderNo(), REQUEST_CODE_NEED_REFRESH, OrderDetailActivity.this);
    }

    public void operateDelete() {
        tip("确认删除订单？删除之后无法恢复", new TipCallback() {
            @Override
            public void execute() {
                com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
                params.put("orderNo", mOrder.getOrderNo());
                showProgressDialog("正在删除", false);
                HttpClient.get("1.0/buyerOrder/delete", params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
                    @Override
                    public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                        finish();
                        hideProgressDialog();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter(error.toString());
                        hideProgressDialog();
                    }
                });
            }
        });
    }

    public void operateExtendConfirm(boolean isSeller) {
        String msg = "";
        if (!isSeller) {
            msg = "点击确定，自动确认收货时间将再延长3天。";
        } else {
            msg = "点击确定，自动确认服务时间将再延长3天。";
        }
        tip(msg, new TipCallback() {
            @Override
            public void execute() {
                showProgressDialog("正在延长确认时间", false);
                com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
                params.put("orderNo", mOrder.getOrderNo());
                HttpClient.get("1.0/userOrder/extend", params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
                    @Override
                    public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                        RequestOrder.getOrder(orderId, getOrderCallback);
                        hideProgressDialog();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter("延长失败, " + error.toString());
                        hideProgressDialog();
                    }
                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_NEED_REFRESH) {
            xhrOrder();
        }
    }

    private void tip(String msg, final TipCallback callback) {
        MessageUtils.createDialog(OrderDetailActivity.this, "提醒", msg, R.string.confirm, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                callback.execute();
            }
        }, R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                hideProgressDialog();
            }
        }).show();
    }

    /**
     * 检测操作是否在提醒范围中
     *
     * @return true 需要提醒
     */
    private boolean checkAttention(Long operate) {
        try {
            JSONArray oprAttention = mOrder.getOprAttention();
            for (int i = 0; i < oprAttention.size(); i++) {
                if (operate == Long.parseLong(oprAttention.get(i).toString())) {
                    return true;
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 获取提醒内容
     *
     * @param operate
     */
    private void getAttentionInfo(final Long operate) {

        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("orderNo", mOrder.getOrderNo());
        params.put("operate", operate.toString());
        HttpClient.get("1.0/sellerOrder/getOprAttention", params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                if (result.getBoolean("isAttention")) {
                    showAcceptWarnDialog(result.getJSONObject("attention"), operate);
                } else {
                    // MessageUtils.showToastCenter("获取提醒信息失败, isAttention:" + false);
                    if (OrderUtil.OPERATE_SELLER_CAN_CONFIRM == operate) {//接单
                        operateSellerAcceptOrder();
                    } else if (OrderUtil.OPERATE_SELLER_CAN_DELIVER == operate) {  //发货
                        operateDelivery();
                    }
                }
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter("获取提醒信息失败, " + error.toString());
            }
        });
    }

    private void showAcceptWarnDialog(com.alibaba.fastjson.JSONObject result, final Long typeOperate) {
        //com.alibaba.fastjson.JSONObject attention = result.getJSONObject("attention");
        MyWarnDialog.Builder builder = new MyWarnDialog.Builder(this);
        builder.setTitle(result.getString("title"));
        View messageLayout = View.inflate(this, R.layout.dialog_sure_buyer, null);
        OrderAttentionListAdapter orderAttentionListAdapter = new OrderAttentionListAdapter(this,
                result.getJSONArray("tipList"), result.getJSONArray("warnList"));
        ((ListView) messageLayout.findViewById(R.id.dialog_message_listView)).setAdapter(orderAttentionListAdapter);
        builder.setContentView(messageLayout);
        final List<Object[]> operates = getAttentionOperate(Long.parseLong(result.get("operate").toString()));
        if (operates.size() > 0) {
            builder.setPositiveButton(operates.get(0)[1].toString(), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    attentionBtnClick((Long) operates.get(0)[0], typeOperate, dialog);
                }
            });
            if (operates.size() > 1) {
                builder.setNegativeButton(operates.get(1)[1].toString(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        attentionBtnClick((Long) operates.get(1)[0], typeOperate, dialog);
                    }
                });
            }
        }
        builder.create().show();
    }

    private void attentionBtnClick(Long operate, Long typeOperate, DialogInterface dialog) {
        dialog.dismiss();
        if (OrderUtil.OPERATE_ATTENTION_ACCEPT == operate) { //继续接单
            if (OrderUtil.OPERATE_SELLER_CAN_CONFIRM == typeOperate) {//接单
                operateSellerAcceptOrder();
            } else if (OrderUtil.OPERATE_SELLER_CAN_DELIVER == typeOperate) {  //发货
                operateDelivery();
            }
        } else if (OrderUtil.OPERATE_ATTENTION_CANCEL == operate) { //取消

        } else if (OrderUtil.OPERATE_ATTENTION_CHECK_PROFILE == operate) { //去看主页
            if (mOrder != null && mOrder.getUser() != null) {
                Router.sharedRouter().open("profile/" + mOrder.getUser().getUserId());
            }
        } else if (OrderUtil.OPERATE_ATTENTION_GO_CONFIRM == operate) { //去认证
            Router.sharedRouter().open("certificationlist");
        }
    }

    private List<Object[]> getAttentionOperate(Long operate) {
        List<Object[]> operates = new ArrayList<Object[]>();
        if ((OrderUtil.OPERATE_ATTENTION_ACCEPT & operate) == OrderUtil.OPERATE_ATTENTION_ACCEPT) {
            operates.add(new Object[]{OrderUtil.OPERATE_ATTENTION_ACCEPT, "继续接单"});
        }
        if ((OrderUtil.OPERATE_ATTENTION_CHECK_PROFILE & operate) == OrderUtil.OPERATE_ATTENTION_CHECK_PROFILE) {
            operates.add(new Object[]{OrderUtil.OPERATE_ATTENTION_CHECK_PROFILE, "去看主页"});
        }
        if ((OrderUtil.OPERATE_ATTENTION_GO_CONFIRM & operate) == OrderUtil.OPERATE_ATTENTION_GO_CONFIRM) {
            operates.add(new Object[]{OrderUtil.OPERATE_ATTENTION_GO_CONFIRM, "去认证"});
        }
        if ((OrderUtil.OPERATE_ATTENTION_CANCEL & operate) == OrderUtil.OPERATE_ATTENTION_CANCEL) {
            operates.add(new Object[]{OrderUtil.OPERATE_ATTENTION_CANCEL, "取消"});
        }
        return operates;
    }

    public static interface TipCallback {
        public void execute();
    }

    class OperateClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            final Long operate = (Long) v.getTag(R.id.order_list_opr);
            if (operate == OrderUtil.OPEN_REMARK) {
                Intent intent = new Intent();
                intent.putExtra(Constant.EXTRA_TAG_ORDER_NO, orderId);
                intent.putExtra(Constant.EXTRA_TAG_REMARK_CONTENT, mOrder.getSellerInnerRemark());
                intent.putExtra(Constant.EXTRA_TAG_REMARK_FLAG, mOrder.getSellerInnerFlag());
                intent.setClass(OrderDetailActivity.this, OrderRemarkActivity.class);
                startActivity(intent);
                return;
            }
            // 支付
            if ((OrderUtil.OPERATE_BUYER_CAN_PAY & operate) == OrderUtil.OPERATE_BUYER_CAN_PAY) {
                operatePay();
            }
            // 取消
            else if ((OrderUtil.OPERATE_BUYER_CAN_CANCEL & operate) == OrderUtil.OPERATE_BUYER_CAN_CANCEL) {
                operateBuyerCancel();
            }
            // 取消：已付款，卖家未接单
            else if ((OrderUtil.OPERATE_BUYER_CAN_REFUND & operate) == OrderUtil.OPERATE_BUYER_CAN_REFUND) {
                operateBuyerRefund();
            }
            // 拒单
            else if ((OrderUtil.OPERATE_SELLER_CAN_REFUSE & operate) == OrderUtil.OPERATE_SELLER_CAN_REFUSE) {
                operateSellerRejectOrder();
            }
            // 接单
            else if ((OrderUtil.OPERATE_SELLER_CAN_CONFIRM & operate) == OrderUtil.OPERATE_SELLER_CAN_CONFIRM) {
                if (checkAttention(OrderUtil.OPERATE_SELLER_CAN_CONFIRM)) {
                    getAttentionInfo(OrderUtil.OPERATE_SELLER_CAN_CONFIRM);
                } else
                    operateSellerAcceptOrder();
            }
            // 追加付款
            else if ((OrderUtil.OPERATE_BUYER_CAN_ADD & operate) == OrderUtil.OPERATE_BUYER_CAN_ADD) {
                operateBuyerAppendCost();
            }
            // 服务完成
            else if ((OrderUtil.OPERATE_BUYER_CAN_CONFIRM & operate) == OrderUtil.OPERATE_BUYER_CAN_CONFIRM) {
                showProgressDialog("正在确认服务完成");
                operateBuyerConfirmOrder(false);
            }
            // 买家可评论
            else if ((OrderUtil.OPERATE_BUYER_CAN_COMMENT & operate) == OrderUtil.OPERATE_BUYER_CAN_COMMENT) {
                operateBuyerComment();
            }
            // 卖家可评论
            else if ((OrderUtil.OPERATE_SELLER_CAN_COMMENT & operate) == OrderUtil.OPERATE_SELLER_CAN_COMMENT) {
                operateSellerComment();
            }
            // 买家可延长确认截至时间
            else if ((OrderUtil.OPERATE_BUYER_CAN_EXTEND & operate) == OrderUtil.OPERATE_BUYER_CAN_EXTEND) {
                operateExtendConfirm(false);
            }
            // 卖家可延长确认截至时间
            else if ((OrderUtil.OPERATE_SELLER_CAN_EXTEND & operate) == OrderUtil.OPERATE_SELLER_CAN_EXTEND) {
                operateExtendConfirm(true);
            }
            // 买家可删除
            else if ((OrderUtil.OPERATE_BUYER_CAN_DELETE & operate) == OrderUtil.OPERATE_BUYER_CAN_DELETE) {
                operateDelete();
            }
            // 卖家可发货
            else if ((OrderUtil.OPERATE_SELLER_CAN_DELIVER & operate) == OrderUtil.OPERATE_SELLER_CAN_DELIVER) {
                if (checkAttention(OrderUtil.OPERATE_SELLER_CAN_DELIVER)) {
                    getAttentionInfo(OrderUtil.OPERATE_SELLER_CAN_DELIVER);
                } else
                    operateDelivery();
            }
            // 买家可确认收货
            else if ((OrderUtil.OPERATE_BUYER_CAN_CONFIRM_MAIL & operate) == OrderUtil.OPERATE_BUYER_CAN_CONFIRM_MAIL) {
                showProgressDialog("正在确认收货");
                operateBuyerConfirmOrder(true);
            }
            // 买家可申请售中退款
            else if ((OrderUtil.OPERATE_BUYER_CAN_APPLY_REFUND & operate) == OrderUtil.OPERATE_BUYER_CAN_APPLY_REFUND) {
                if (mFirstItem.getServiceType() != null && OrderRefundActivity.TYPE_DELIVERY == mFirstItem.getServiceType()) {
                    Router.sharedRouter().open("orderRefund/" + OrderRefundActivity.TYPE_DELIVERY + "/" + mOrder.getOrderNo());
                } else {
                    Router.sharedRouter().open("orderRefund/" + OrderRefundActivity.TYPE_SERVICE + "/" + mOrder.getOrderNo());
                }
            }
            // 可查看退款记录
            else if ((OrderUtil.OPERATE_CAN_VIEW_APPLY_REFUND & operate) == OrderUtil.OPERATE_CAN_VIEW_APPLY_REFUND) {
                Router.sharedRouter().open("orderRefundDetail/" + mOrder.getOrderNo());
            }
            // 买家可申请客服介入
            else if ((OrderUtil.OPERATE_BUYER_CAN_APPLY_CS & operate) == OrderUtil.OPERATE_BUYER_CAN_APPLY_CS) {
                Router.sharedRouter().open("orderRefund/" + OrderRefundActivity.TYPE_KEFU_HANDLE + "/" + mOrder.getOrderNo());
            } else if (OrderUtil.OPERATE_OPEN_COMMENT == operate) {
                operateOpenComments();
                //卖家修改价格
            } else if ((OrderUtil.OPERATE_SELLER_CAN_BARGAIN & operate) == OrderUtil.OPERATE_SELLER_CAN_BARGAIN) {
                Router.sharedRouter().open("orderUpdatePrice/" + mOrder.getOrderNo());
            } else if ((OrderUtil.OPERATE_FINAL_PAY & operate) == OrderUtil.OPERATE_FINAL_PAY) {
                operatePay();
            } else if ((OrderUtil.OPERATE_EARNEST & operate) == OrderUtil.OPERATE_EARNEST) {
                operatePay();
            }
        }
    }

    class CountDownTimer extends android.os.CountDownTimer {

        public CountDownTimer(long time) {
            super(time, 1000);
        }

        public void onTick(long millisUntilFinished) {
            String timeString = "";
            long minutes = 0;
            long hours = 0;
            long days = 0;
            long seconds = millisUntilFinished / 1000;
            if (seconds > 0) {
                minutes = seconds / 60;
                seconds = seconds % 60;
                timeString = seconds + "秒";
            }
            if (minutes > 0) {
                hours = minutes / 60;
                minutes = minutes % 60;
                timeString = minutes + "分" + timeString;
            }
            if (hours > 0) {
                days = hours / 24;
                hours = hours % 24;
                timeString = hours + "小时" + timeString;
            }
            if (days > 0) {
                timeString = days + "天" + timeString;
            }

            if (mOrder.getCountdownText() != null) {
                textTips.setText(mOrder.getCountdownText().replace("%@", timeString));
            } else {
                textTips.setText("");
            }
        }

        public void onFinish() {
            xhrOrder();
        }
    }
}
