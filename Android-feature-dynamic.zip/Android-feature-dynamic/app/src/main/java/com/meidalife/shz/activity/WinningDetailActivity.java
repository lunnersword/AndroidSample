package com.meidalife.shz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.view.StepsView;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.umeng.socialize.media.UMImage;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/1/20.
 */
public class WinningDetailActivity extends BaseActivity {
    private boolean serviceConfirmed = false;
    private boolean identityConfirmed = false;
    private boolean isEffectiveRedpack = true;
    private String itemId;
    private boolean isLoading = false;
    String imageUrl;

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    View contentView;
    @Bind(R.id.stepsView)
    StepsView stepsView;
    @Bind(R.id.winningImage)
    SimpleDraweeView winningImage;
    @Bind(R.id.winningTitle)
    TextView winningTitle;
    @Bind(R.id.winningDetail)
    TextView winningDetail;
    @Bind(R.id.continueWin)
    TextView continueWin;
    @Bind(R.id.shareRedPaper)
    TextView shareRedPaper;
    @Bind(R.id.issueRedPaper)
    TextView issueRedPaper;
    @Bind(R.id.customerServices)
    TextView customerServices;

    private SocialSharePopupWindow socialSharePopupWindow;
    private LoadUtilV2 loadUtil;
    private ShareActivity shareActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winning_detail);
        ButterKnife.bind(this);

        initActionBar("中奖信息", true, false);
        String steps[] = new String[]{"身份确认", "获得奖品", "服务完成"};
        String bottomLabels[] = new String[]{"确认中", "联系中"};
        stepsView.setLabels(steps).setBottomLabels(bottomLabels).drawView();

        loadUtil = new LoadUtilV2(LayoutInflater.from(this));
        itemId = getIntent().getStringExtra("itemId");
        shareActivity = new ShareActivity(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        getDetail();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void getDetail() {
        if (isLoading) {
            return;
        }
        loadUtil.loadPre(rootView, contentView);
        isLoading = true;
        JSONObject params = new JSONObject();
        params.put("itemId", itemId);
        HttpClient.get("1.0/duobao/getAwardDetail", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                loadUtil.loadSuccess(contentView);
                renderViews(obj);
                isLoading = false;
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToast(error.toString());
                loadUtil.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        getDetail();
                    }
                });
                isLoading = false;
            }
        });
    }

    private void renderViews(JSONObject data) {
        JSONArray imageArrays = data.getJSONArray("images");
        if (null != imageArrays && !imageArrays.isEmpty()) {
            JSONObject image = imageArrays.getJSONObject(0);
            if (null != image && image.containsKey("uri")) {
                imageUrl = image.getString("uri");
                String cdnUrl = ImgUtil.getCDNUrlWithWidth(image.getString("uri"),
                        getResources().getDisplayMetrics().widthPixels * 2 / 3);
                winningImage.setImageURI(Uri.parse(cdnUrl));
                ImgUtil.changeBrightness(winningImage, -30);
            }
        }

        winningTitle.setText(data.getString("title"));
        final String linkUrl = data.getString("detailUrl");
        if (!TextUtils.isEmpty(linkUrl)) {
            winningDetail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", linkUrl);
                    Router.sharedRouter().open("web", bundle);
                }
            });
            winningDetail.setVisibility(View.VISIBLE);
        } else {
            winningDetail.setVisibility(View.GONE);
        }

        if (data.getFloat("redpackBudget") != null) {
            shareRedPaper.setText(StrUtil.getDigitSpanText(String.format(getString(R.string.winning_share_redpaper),
                            data.getFloat("redpackBudget") / 100f), getResources().getColor(R.color.brand_b),
                    getResources().getDimensionPixelSize(R.dimen.font_size_large)));
        }

        if (data.containsKey("duobaoHomeUrl")) {
            final String duobaoHomeUrl = data.getString("duobaoHomeUrl");
            continueWin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", duobaoHomeUrl);
                    Router.sharedRouter().open("web", bundle);
                }
            });
            continueWin.setVisibility(View.VISIBLE);
        } else {
            continueWin.setVisibility(View.GONE);
        }


        final String title = data.getString("title");
        final String content = data.getString("description");
        final String shareUrl = data.getString("redpackUrl");
        issueRedPaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHideShareList(v, title, content, shareUrl, imageUrl);
            }
        });

        final String kefuTel = Helper.sharedHelper().getStringUserInfo(Constant.CUSTOMER_SERVICE_TEL);
        if (!TextUtils.isEmpty(kefuTel)) {
            customerServices.setText(Constant.KE_FU_TEL);
        }
        customerServices.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG); //下划线
        customerServices.getPaint().setAntiAlias(true);//抗锯齿
        customerServices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Helper.makeCall(WinningDetailActivity.this, (TextUtils.isEmpty(kefuTel) ? Constant.KE_FU_TEL : kefuTel));
            }
        });

        identityConfirmed = data.getBoolean("identityConfirmed");
        isEffectiveRedpack = data.getBoolean("isEffectiveRedpack");
        if (identityConfirmed) {
            serviceConfirmed = data.getBoolean("serviceConfirmed");

            if (serviceConfirmed) {
                stepsView.setCompletedPosition(2);
            } else {
                stepsView.setCompletedPosition(1);
            }
        } else {
            stepsView.setCompletedPosition(0);
        }
    }

    private void showOrHideShareList(View v, String title, String content, String url, String imageUrl) {
        if (!isEffectiveRedpack) {
            MessageUtils.showDialog(this, "红包已过期", "红包已超过七天了再去夺个大奖吧!",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }, false);
            return;
        }

        if (socialSharePopupWindow == null) {
            socialSharePopupWindow = new SocialSharePopupWindow(this, shareActivity, 0);
            socialSharePopupWindow.setShareUrl(url);
            socialSharePopupWindow.setShareTitle(title);
            socialSharePopupWindow.setShareDescription(content);
            if (!TextUtils.isEmpty(imageUrl)) {
                socialSharePopupWindow.setShareImage(new UMImage(this, imageUrl));
            } else {
                socialSharePopupWindow.setShareImage(new UMImage(this, R.mipmap.ic_launcher));
            }
        }
        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }
}
