package com.meidalife.shz.adapter;

import android.content.Context;
import android.media.Image;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.event.SquareHandlerPinEvent;
import com.meidalife.shz.rest.model.SquareAskDO;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.RemainTimeUtils;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;

import java.util.ArrayList;

/**
 * Created by mzzcy on 2015/12/15.
 */
public class SquareAskAdapter extends BaseAdapter {

    private Context mContext;
    private LayoutInflater mInflater;
    private ArrayList<SquareAskDO> mData;
    private SquareHandlerPinEvent squareHandlerPinEvent;
    private boolean isGezhu;

    static class ViewHolder {
        private View view;

        SimpleDraweeView userAvatar;
        FontTextView demandTitle;
        FontTextView remainDays;
        IconTextView iconGender;
        FontTextView textNick;
        FontTextView commentCount;
        FontTextView description;
        TextView pinHandlerView;
        View pinView;
        FontTextView gezhuLogo;
        ImageView askFallLogo;
        ImageView askOverLogo;


        public ViewHolder(View view) {
            this.view = view;
            Log.d("mzLog helpAdapter", "start find ");
            userAvatar = (SimpleDraweeView) this.view.findViewById(R.id.imageAvatar);
            demandTitle = (FontTextView) this.view.findViewById(R.id.demandTitle);
            remainDays = (FontTextView) this.view.findViewById(R.id.remainDays);
            iconGender = (IconTextView) this.view.findViewById(R.id.iconGender);
            textNick = (FontTextView) this.view.findViewById(R.id.textNick);
            commentCount = (FontTextView) this.view.findViewById(R.id.commentCount);
            description = (FontTextView) this.view.findViewById(R.id.description);
            pinHandlerView = (TextView) this.view.findViewById(R.id.pinHandlerView);
            pinView = this.view.findViewById(R.id.pinView);
            gezhuLogo = (FontTextView) this.view.findViewById(R.id.gezhuLogo);
            askFallLogo = (ImageView) this.view.findViewById(R.id.askFallLogo);
            askOverLogo = (ImageView) this.view.findViewById(R.id.askOverLogo);
        }
    }

    public SquareAskAdapter(Context context, ArrayList<SquareAskDO> data, boolean geZhu) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        isGezhu = geZhu;
        mContext = context;
    }

    public void setSquareHandlerPinEvent(SquareHandlerPinEvent squareHandlerPinEvent) {
        this.squareHandlerPinEvent = squareHandlerPinEvent;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public SquareAskDO getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View converView, ViewGroup parent) {

        SquareAskDO squareAskDO = getItem(position);
        ViewHolder viewHolder;
        View view;
        if (converView == null) {
            Log.d("mzLog helpAdapter", "position: " + position);
            view = mInflater.inflate(R.layout.item_square_ask, parent, false);
            viewHolder = new ViewHolder(view);
            view.setTag(viewHolder);
        } else {
            view = converView;
            viewHolder = (ViewHolder) view.getTag();
        }

        String gender = squareAskDO.getUserGender();
        // 设置服务者性别
        if (squareAskDO.getUserGender() != null) {
            viewHolder.iconGender.setVisibility(View.VISIBLE);
            if (squareAskDO.getUserGender().equals("woman") || squareAskDO.getUserGender().equals("F")) {
                viewHolder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_f));
                viewHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            } else {
                viewHolder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_m));
                viewHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
            }
        } else {
            viewHolder.iconGender.setVisibility(View.GONE);
        }

        if (squareAskDO.getIsGezhu()) {
            viewHolder.gezhuLogo.setVisibility(View.VISIBLE);
        } else {
            viewHolder.gezhuLogo.setVisibility(View.GONE);
        }

        // 加载发布者头像
        ViewGroup.LayoutParams avatarParams = viewHolder.userAvatar.getLayoutParams();
        String userPicUrl = squareAskDO.getUserPicUrl();
        if (TextUtils.isEmpty(userPicUrl) || userPicUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(squareAskDO.getUserId()), gender);
            viewHolder.userAvatar.setImageURI(getDefaultAvatarUri);

        } else {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(userPicUrl, avatarParams.width));
            viewHolder.userAvatar.setImageURI(uri);
        }

        viewHolder.demandTitle.setText("我要·" + squareAskDO.getTitle());
        switch (squareAskDO.getStatus()) {
            case Constant.SQUARE_ASK_ITEM_TYPE_STALE:
                viewHolder.remainDays.setVisibility(View.GONE);
                viewHolder.askFallLogo.setVisibility(View.VISIBLE);
                viewHolder.askOverLogo.setVisibility(View.GONE);
                break;
            case Constant.SQUARE_ASK_ITEM_TYPE_COMPLETE:
                viewHolder.remainDays.setVisibility(View.GONE);
                viewHolder.askFallLogo.setVisibility(View.GONE);
                viewHolder.askOverLogo.setVisibility(View.VISIBLE);
                break;
            default:
                String remainTime = RemainTimeUtils.transTime(squareAskDO.getRemainTime());
                if(remainTime.trim().equals("0")){
                    viewHolder.remainDays.setVisibility(View.GONE);
                    viewHolder.askFallLogo.setVisibility(View.VISIBLE);
                    viewHolder.askOverLogo.setVisibility(View.GONE);
                }else{
                    viewHolder.remainDays.setVisibility(View.VISIBLE);
                    viewHolder.askFallLogo.setVisibility(View.GONE);
                    viewHolder.askOverLogo.setVisibility(View.GONE);
                    viewHolder.remainDays.setText("剩余时间：" + remainTime);
                }
                break;
        }

        viewHolder.textNick.setText(squareAskDO.getUserNick() == null ? "" : squareAskDO.getUserNick());
        viewHolder.commentCount.setText("回答：" + squareAskDO.getCommentCount());
        viewHolder.description.setText(squareAskDO.getDescription());

        //格子页是否置顶
        if (squareAskDO.getPin()) {
            viewHolder.pinView.setVisibility(View.VISIBLE);
        } else
            viewHolder.pinView.setVisibility(View.GONE);
        viewHolder.pinHandlerView.setVisibility(View.GONE);
        return view;
    }
}
