package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.laiwang.protocol.util.StringUtils;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by shijian on 15/8/24.
 */
public class OrderRefundActivity extends BaseActivity {

    private LayoutInflater inflater;
    private Context context;

    private ViewGroup rootView;
    private View contentRoot;
    private LoadUtilV2 loadUtilV2;

    private ListView reasonList;
    private GridView selectImagesGrid;

    EditText mRefundCommentET;

    public static int TYPE_DELIVERY = 4;    // 邮寄
    public static int TYPE_SERVICE = 5;     // 服务
    public static int TYPE_KEFU_HANDLE = 6; // 客服介入
    private int itemType;
    private String orderNo;

    private Integer refundType;
    private String reason;
    private String express;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_refund);
        initActionBar(R.string.title_order_refund, true);

        inflater = getLayoutInflater();
        context = getApplicationContext();

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);
        loadUtilV2 = new LoadUtilV2(inflater);

        mRefundCommentET = (EditText) findViewById(R.id.refund_comment);

        Bundle extras = getIntent().getExtras();
        itemType = Integer.parseInt(extras.getString("type"));
        orderNo = extras.getString("orderNo");

        if (itemType == TYPE_KEFU_HANDLE) {
            TextView textRefundReasonLabel = (TextView) findViewById(R.id.textRefundReasonLabel);
//            EditText refundComment = (EditText)findViewById(R.id.refund_comment);
            setActionBarTitle(R.string.title_order_refund_cs);
            textRefundReasonLabel.setText("申请客服介入原因");
            mRefundCommentET.setHint("请输入申请客服介入说明");
        }

        reasonList = (ListView) findViewById(R.id.refund_reason_list);
        selectImagesGrid = (GridView) findViewById(R.id.selectImages);

        View refundTypeGroup = findViewById(R.id.refund_type_group);
        final View deliveryGroup = findViewById(R.id.refund_delivery_group);
        if (itemType == TYPE_SERVICE || itemType == TYPE_KEFU_HANDLE) {
            refundTypeGroup.setVisibility(View.GONE);
            deliveryGroup.setVisibility(View.GONE);
            refundType = (itemType == TYPE_SERVICE ? 1 : 3);  // 1=仅退款，3=客服介入
        } else {
            final TextView moneyType = (TextView) findViewById(R.id.refund_money_type);
            final TextView goodsType = (TextView) findViewById(R.id.refund_goods_type);
            View moneyTypeGroup = findViewById(R.id.refund_money_group);
            moneyTypeGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    moneyType.setTextColor(getResources().getColor(R.color.brand_b));
                    goodsType.setTextColor(getResources().getColor(R.color.grey_c));
                    deliveryGroup.setVisibility(View.GONE);
                    refundType = 1; // 仅退款
                }
            });
            View goodsTypeGroup = findViewById(R.id.refund_goods_group);
            goodsTypeGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goodsType.setTextColor(getResources().getColor(R.color.brand_b));
                    moneyType.setTextColor(getResources().getColor(R.color.grey_c));
                    deliveryGroup.setVisibility(View.VISIBLE);
                    refundType = 2; // 退货退款
                }
            });
        }

        reasonList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView selectReason = (TextView) view.findViewById(R.id.refund_reason);
                reason = selectReason.getText().toString();
            }
        });

        EditText kuaidiNo = (EditText) findViewById(R.id.kuaidi_no);
        kuaidiNo.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
                    return true;
                }
                return false;
            }
        });
        View kuaidiGroup = findViewById(R.id.kuaidi_group);
        kuaidiGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().openFormResult("pickKuaidi",
                        Constant.REQUEST_CODE_EXPRESS_COMPANY, OrderRefundActivity.this);
            }
        });

        TextView barcodeScannerIcon = (TextView) findViewById(R.id.barcode_scanner_icon);
        barcodeScannerIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(OrderRefundActivity.this, BarcodeScannerActivity.class);
                startActivityForResult(intent, Constant.REQUEST_CODE_BARCODE_SCAN);
            }
        });


        View refundCommit = findViewById(R.id.refund_commit);
        refundCommit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (uploading) {
                    MessageUtils.showToastCenter("图片正在上传中，请稍等");
                    return;
                }
                if (refundType == null) {
                    MessageUtils.showToastCenter("请选择退款类型");
                    return;
                }

                if (reason == null) {
                    MessageUtils.showToastCenter("请选择退款原因");
                    return;
                }

                String otherState = mRefundCommentET.getText() == null ? null : mRefundCommentET.getText().toString().trim();
//                if (StringUtils.isEmpty(otherState)) {
//                    MessageUtils.showToastCenter("补充说明不能为空");
//                    return;
//                }

                EditText kuaidiNo = (EditText) findViewById(R.id.kuaidi_no);

                if (refundType == 2) {   // 若退货，必须填写快递信息
                    if (StrUtil.isEmpty(express)) {
                        MessageUtils.showToastCenter("请选择快递公司");
                        return;
                    }
                    if (!"#".equals(express) && (kuaidiNo.getText() == null || StrUtil.isEmpty(kuaidiNo.getText().toString()))) {
                        MessageUtils.showToastCenter("请填写快递单号");
                        return;
                    }
                }

                JSONObject params = new JSONObject();
                params.put("orderNo", orderNo);
                params.put("type", refundType);
                params.put("reason", reason);
                params.put("comment", otherState);
                params.put("pic", uploadedImgs.values());
                params.put("express", express);
                params.put("expressNo", kuaidiNo.getText().toString());

                HttpClient.get("1.0/refund/add", params, null, new HttpClient.HttpCallback<Object>() {
                    @Override
                    public void onSuccess(Object obj) {
                        Router.sharedRouter().open("orderRefundDetail/" + orderNo);
                        finish();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter("申请退款失败, " + error.toString());
                    }
                });
            }
        });

        initLoadData();
    }

    public void initLoadData() {
        loadUtilV2.loadPre(rootView, contentRoot);
        JSONObject params = new JSONObject();
        params.put("orderNo", orderNo);
        HttpClient.get("1.0/refund/initRefund", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject datas) {
                loadUtilV2.loadSuccess(contentRoot);
                Double payNum = datas.getDouble("payNum");
                TextView payNumView = (TextView) findViewById(R.id.pay_num);
                payNumView.setText(StrUtil.doubleFormat(payNum / 100) + "元");
                JSONArray reasonJson = datas.getJSONArray("reasonList");
                String[] reasonArray = new String[reasonJson.size()];
                reasonArray = reasonJson.toArray(reasonArray);
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(context, R.layout.activity_order_refund_reason_item, R.id.refund_reason, reasonArray);
                reasonList.setAdapter(adapter);
                initSelectImagesGrid();
            }

            @Override
            public void onFail(HttpError error) {
                loadUtilV2.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        initLoadData();
                    }
                });
            }
        });
    }


    /*
    =========== 处理图片 ============
     */

    private ArrayList<String> selectedImgs = new ArrayList<>();
    private int MAX_IMAGE_LENGTH = 3;
    private PublishGridAdapter adapter;
    private boolean uploading = false;
    private Map<String, String> uploadedImgs = new HashMap();

    private void initSelectImagesGrid() {
        adapter = new PublishGridAdapter(this, selectedImgs, MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_OTHER);
        selectImagesGrid.setAdapter(adapter);
        adapter.setOnClickPlusListener(new PublishGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                if (uploading) {
                    Toast.makeText(OrderRefundActivity.this, "图片正在上传中，请稍等", Toast.LENGTH_LONG).show();
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putBoolean("isCheckbox", true);
                bundle.putInt("maxLength", MAX_IMAGE_LENGTH - selectedImgs.size());
                Router.sharedRouter().openFormResult("pick/photo", bundle,
                        Constant.REQUEST_CODE_PICK_PHOTO, OrderRefundActivity.this);
            }
        });
        adapter.setOnClickRemoveListener(new PublishGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                if (position < selectedImgs.size()) {
                    selectedImgs.remove(position);
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constant.REQUEST_CODE_PICK_PHOTO && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            List<String> paths = bundle.getStringArrayList("images");
            for (int i = 0; i < paths.size(); i++) {
                String img = paths.get(i);
                if (selectedImgs.contains(img)) {
                    continue;
                } else {
                    selectedImgs.add(img);  // 如果图片列表中没有当前选中的照片，则添加到图片列表中
                }
            }
            adapter.notifyDataSetChanged();
            uploadImages();
        } else if (requestCode == Constant.REQUEST_CODE_EXPRESS_COMPANY) {
            if (resultCode == RESULT_OK) {
                Bundle extras = data.getExtras();
                TextView kuaidiName = (TextView) findViewById(R.id.kuaidi_name);
                kuaidiName.setText(extras.getString("name"));
                express = extras.getString("code");
                View kuaidiNoGroup = findViewById(R.id.kuaidi_no_group);
                if ("#".equals(express)) {
                    kuaidiNoGroup.setVisibility(View.GONE);
                } else {
                    kuaidiNoGroup.setVisibility(View.VISIBLE);
                }
            }
        } else if (requestCode == Constant.REQUEST_CODE_BARCODE_SCAN) {
            if (resultCode == RESULT_OK && null != data) {
                String result = data.getStringExtra("result");
                EditText kuaidiNo = (EditText) findViewById(R.id.kuaidi_no);
                kuaidiNo.setText(result);
            }
        }
    }

    private void uploadImages() {
        final ArrayList<String> needUploadList = new ArrayList();
        for (int i = 0; i < selectedImgs.size(); i++) {
            String img = selectedImgs.get(i);
            if (!uploadedImgs.containsKey(img)) {
                needUploadList.add(img);  //如果图片列表中没有当前选中的照片，则添加到需上传图片列表中
            }
        }
        if (needUploadList.size() > 0) {
            showProgressDialog("图片上传中...");
            uploading = true;
            xhrUpdateImages(needUploadList, 0);
        }
    }

    private void xhrUpdateImages(final ArrayList needUploadList, final int index) {
        if (needUploadList.size() > 0) {
            final String path = (String) needUploadList.get(index);
            RequestSign.upload(path, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    org.json.JSONObject json = (org.json.JSONObject) result;
                    try {
                        uploadedImgs.put(path, json.getString("data"));
                        if (index == needUploadList.size() - 1) {
                            hideProgressDialog();
                            uploading = false;
                            //Toast.makeText(context, "图片上传成功...", Toast.LENGTH_SHORT).show();
                        } else {
                            xhrUpdateImages(needUploadList, index + 1);
                        }
                    } catch (JSONException e) {
                        uploading = false;
                        hideProgressDialog();
                        failTip();
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    uploading = false;
                    hideProgressDialog();
                    failTip();
                }
            });
        }
    }

    private void failTip() {
        MessageUtils.showToastCenter("图片上传过程中有错误，请重新选择");
        selectedImgs.clear();
        selectedImgs.addAll(uploadedImgs.keySet());
        adapter.notifyDataSetChanged();
    }

}
