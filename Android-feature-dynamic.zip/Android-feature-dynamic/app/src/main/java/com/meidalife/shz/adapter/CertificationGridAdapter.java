package com.meidalife.shz.adapter;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.common.util.UriUtil;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.AuthPictureDO;

import java.io.File;
import java.util.ArrayList;

/**
 * 认证页面图片adapter
 */
public class CertificationGridAdapter extends BaseAdapter {

    //    private static final String LOG_TAG = "AuthGridAdapter";
    public static int TYPE_OTHER = 2;

    private static final int TYPE_COUNT = 2;

    private ArrayList<AuthPictureDO> mImages;
    private LayoutInflater mInflater;
    private CertificationGridAdapter.OnClickListener mOnClickImgListener;
    private CertificationGridAdapter.OnClickListener mOnClickRemoveListener;

    static class ImageHolder {
        public TextView desc;
        public SimpleDraweeView image;
        public TextView button;
    }

    public CertificationGridAdapter(Activity c, ArrayList<AuthPictureDO> images, int max, int type) {
        mImages = images;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public void setOnClickListener(CertificationGridAdapter.OnClickListener listener) {
        mOnClickImgListener = listener;
    }

    public void setOnClickRemoveListener(CertificationGridAdapter.OnClickListener listener) {
        mOnClickRemoveListener = listener;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    public int getCount() {
        return mImages.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(final int position, View convertView, ViewGroup parent) {
        ImageHolder imageHolder = new ImageHolder();

        if (convertView != null) {
            imageHolder = (ImageHolder) convertView.getTag();
        } else {
            convertView = mInflater.inflate(R.layout.auth_grid_item_image, parent, false);
            imageHolder.image = (SimpleDraweeView) convertView.findViewById(R.id.serviceGridImage);
            imageHolder.desc = (TextView) convertView.findViewById(R.id.picDesc);
            imageHolder.button = (TextView) convertView.findViewById(R.id.removeImage);
            convertView.setTag(imageHolder);
        }

        //删除图片
        imageHolder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnClickRemoveListener != null) {
                    mOnClickRemoveListener.onClick(v, position);
                }
            }
        });


        //编辑或者添加图片
        imageHolder.image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnClickImgListener != null) {
                    mOnClickImgListener.onClick(v, position);
                }
            }
        });

        AuthPictureDO pictureDO = mImages.get(position);
        String desc = pictureDO.getDesc();
        String path = pictureDO.getUrl();
//        ViewGroup.LayoutParams layoutParams = imageHolder.image.getLayoutParams();
        Uri uri;
        if (TextUtils.isEmpty(path)) {
            uri = new Uri.Builder()
                    .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.pic_service_default)).build();
            imageHolder.image.setImageURI(uri);
        } else {
            if (path.matches("http://.*")) {
                uri = Uri.parse(path);
            } else {
                uri = Uri.fromFile(new File(path));
            }
            imageHolder.image.setImageURI(uri);
            imageHolder.button.setVisibility(View.VISIBLE);
        }

        if (pictureDO.isEditble()) {
            imageHolder.button.setVisibility(View.VISIBLE);
        } else {
            imageHolder.button.setVisibility(View.GONE);
        }

        imageHolder.desc.setText(desc);

        return convertView;
    }

    public interface OnClickListener {
        void onClick(View v, int position);
    }
}
