package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.SquareHomeActivity;
import com.meidalife.shz.adapter.CategoryTagRecyclerAdapter;
import com.meidalife.shz.adapter.SquareBbsListAdapter;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.SquareRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareCategoryItemDO;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 闲话厅-格子
 * Created by xingchen on 2015/12/18.
 */
public class SquareBbsFragment extends BaseFragment {
    private View rootView;
    private int geziId = Integer.MAX_VALUE;
    private int catId = Integer.MAX_VALUE;
    private Context context;
    private boolean hasInitData = false;
    private boolean isComplete;
    private int page = 0;
    private boolean isRefresh = false;
    private boolean isLoad = false;
    private static int GET_DATA_REFRESH = 0;  // 刷新数据
    private static int GET_DATA_LOAD_MORE = 1;  //加载更多数据
    private static int PUBLISH_REQUEST_CODE = 88;

    private View listFooter;
    private ProgressBar footerLoading;
    private Button footerReload;
    private TextView footerMessage;
    private com.alibaba.fastjson.JSONArray allTopicList;
    private List<SquareCategoryItemDO> catList;

    @Bind(R.id.serviceList)
    ListView serviceListView;
    @Bind(R.id.cellStatusErrorNetwork)
    LinearLayout cellStatusErrorNetwork;
    @Bind(R.id.cellStatusErrorServer)
    LinearLayout cellStatusErrorServer;
    @Bind(R.id.cellStatusDotLoading)
    LinearLayout cellStatusDotLoading;
    @Bind(R.id.noDataLayout)
    LinearLayout noDataLayout;
    @Bind(R.id.hint_message)
    TextView hintMessage;
    @Bind(R.id.textStatusErrorServer)
    TextView textStatusErrorServer;
    @Bind(R.id.nearByHintLayout)
    LinearLayout nearByHintLayout;
    @Bind(R.id.categoryList)
    RecyclerView categoryListView;
    @Bind(R.id.line)
    View line;

    private CategoryTagRecyclerAdapter categoryTagRecyclerAdapter;
    private AnimationDrawable loadingAnimation;
    private SquareBbsListAdapter squareBbsListAdapter;
    private boolean isFirstLoad = false;
    private boolean isGezhu;

//    private static final int MENU_ITEM_BLACK_LIST = 0;
//    private static final int MENU_ITEM_CANCEL = 1;

    public static SquareBbsFragment newInstance(Bundle params) {
        SquareBbsFragment squareBbsFragment = new SquareBbsFragment();
        squareBbsFragment.setArguments(params);
        return squareBbsFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        EventBus.getDefault().register(this);
        if (rootView == null) {
            Bundle params = getArguments();
            if (params != null) {
                geziId = params.getInt("geziId", Integer.MAX_VALUE);
                isGezhu = params.getBoolean("isGezhu",false);
            }
            rootView = inflater.inflate(R.layout.fragment_square_list, container, false);
            context = getActivity();
            ButterKnife.bind(this, rootView);

//            publishIcon.setText(R.string.icon_square_publish_bbs);
//            publishText.setText(R.string.bbs_publish);
            hintMessage.setText(R.string.square_bbs_no_data);

            listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
            footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
            footerMessage = (TextView) listFooter.findViewById(R.id.message);
            footerReload = (Button) listFooter.findViewById(R.id.footerReload);
            serviceListView.addFooterView(listFooter);

            allTopicList = new com.alibaba.fastjson.JSONArray();
            squareBbsListAdapter = new SquareBbsListAdapter(context, allTopicList);
            squareBbsListAdapter.setIsGezhu(isGezhu);
            squareBbsListAdapter.setIsJoined(((SquareHomeActivity)getActivity()).isJoined);
            serviceListView.setAdapter(squareBbsListAdapter);
            serviceListView.setDividerHeight(0);

            ViewGroup.LayoutParams layoutParams = categoryListView.getLayoutParams();
            layoutParams.height = (int) Helper.convertDpToPixel(42, context);
            categoryListView.setLayoutParams(layoutParams);
            catList = new ArrayList<SquareCategoryItemDO>();
            categoryTagRecyclerAdapter = new CategoryTagRecyclerAdapter(context, catList, CategoryTagRecyclerAdapter.LIFE_COLLECT);
            categoryListView.setAdapter(categoryTagRecyclerAdapter);

            //设置布局管理器
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
            categoryListView.setLayoutManager(linearLayoutManager);

            listFooter.setVisibility(View.GONE);

            hideContentView();

            page = 0;
            isComplete = false;
            isLoad = false;

            initListener();
        }

        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        isFirstLoad = true;
        getData(GET_DATA_REFRESH, true);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    public void onEvent(SquareRefreshEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isRefresh) {
            if (null != event.isGezhu) {
                isGezhu = event.isGezhu;
            }
            squareBbsListAdapter.setIsGezhu(isGezhu);
            getData(GET_DATA_REFRESH, event.showLoading);
        }
    }

    private void initListener() {
        cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getData(GET_DATA_REFRESH,true);
            }
        });
        cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData(GET_DATA_REFRESH,true);
            }
        });
        serviceListView.setOnScrollListener(new AbsListView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                BaseEvent message = new BaseEvent();
                final View topChildView = serviceListView.getChildAt(0);
                if (scrollState == SCROLL_STATE_IDLE && serviceListView.getFirstVisiblePosition() == 0
                        && topChildView.getTop() == 0) {
                    message.eventType = MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                } else {
                    message.eventType = MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                }

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        getData(GET_DATA_LOAD_MORE, false);
                    }
                }

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }
        });

        serviceListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                JSONObject squareBbsItem = (JSONObject) allTopicList.get(position);
                Bundle params = new Bundle();
                params.putInt("geziId", geziId);
                params.putBoolean("isGeZhu", isGezhu);
                params.putBoolean("isJoined", ((SquareHomeActivity)getActivity()).isJoined);
                params.putBoolean("pin",squareBbsItem.getBooleanValue("pin"));
                Router.sharedRouter().openFormResult("squarebbsdetail/" + squareBbsItem.getString("id"), params, PUBLISH_REQUEST_CODE, getActivity());
            }
        });

        categoryTagRecyclerAdapter.setOnClickCategoryListener(new CategoryTagRecyclerAdapter.RefreshCategoryView() {
            @Override
            public void refreshCategory(int id) {
                catId = id;
                getData(GET_DATA_REFRESH, true);
            }
        });


    }

    private void initCat(JSONArray cats){
        catList.clear();
        SquareCategoryItemDO categoryItemDO;
        for (int i = 0; i < cats.size(); i++) {
            categoryItemDO = new SquareCategoryItemDO();
            JSONObject cat = cats.getJSONObject(i);
            if (cat.containsKey("catId"))
                categoryItemDO.setCatId(cat.getIntValue("catId"));
            if (cat.containsKey("catName"))
                categoryItemDO.setCatName(cat.getString("catName"));
            catList.add(categoryItemDO);
        }

        catId = catList.get(0).getCatId();
        categoryListView.setVisibility(View.VISIBLE);
        line.setVisibility(View.VISIBLE);
        categoryTagRecyclerAdapter.setSelectPos(0);
        categoryTagRecyclerAdapter.notifyDataSetChanged();
    }

    /**
     * @param loadType 0:刷新，1：加载更多
     */
    private void getData(final int loadType, final boolean showLoading) {
        if (showLoading) {
            serviceListView.setVisibility(View.GONE);
            showStatusLoading();
        }
        if (loadType == GET_DATA_REFRESH) {
            cellStatusErrorNetwork.setVisibility(View.GONE);
            cellStatusErrorServer.setVisibility(View.GONE);
           /* if (isRefresh)
                return;*/
            isRefresh = true;
            page = 0;
            isComplete = false;
        }

        if (loadType == GET_DATA_LOAD_MORE) {
            if (isLoad || isComplete)
                return;
            footerMessage.setText(getString(R.string.text_loading));
            listFooter.setVisibility(View.VISIBLE);
            footerLoading.setVisibility(View.VISIBLE);
            footerMessage.setVisibility(View.VISIBLE);
            footerReload.setVisibility(View.GONE);
            isLoad = true;
            page++;
        }
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        if (catId != Integer.MAX_VALUE) {
            params.put("catId", catId);
        }
        //params.put("catId", 1);
        params.put("pageSize", 20);
        params.put("offset", page * 20);

        HttpClient.get("1.0/gezi/bbs/getTopics", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                if (loadType == GET_DATA_REFRESH) {
                    isRefresh = false;
                    hideStatusLoading();
                } else {
                    isLoad = false;
                }
                try {
                    JSONArray topicList = obj.getJSONArray("topicList");
                    if(isFirstLoad){
                        JSONArray catList = obj.getJSONArray("catList");
                        if(loadType == GET_DATA_REFRESH && catList != null)
                            initCat(catList);
                        isFirstLoad = false;
                    }

                    if (topicList.size() == 0) {
                        if (loadType == GET_DATA_REFRESH)
                            noDataLayout.setVisibility(View.VISIBLE);
                    } else {
                        if (loadType == GET_DATA_REFRESH) {
                            allTopicList.clear();
                            noDataLayout.setVisibility(View.GONE);
                        } else
                            listFooter.setVisibility(View.GONE);
                        serviceListView.setVisibility(View.VISIBLE);
                        allTopicList.addAll(topicList);
                        squareBbsListAdapter.notifyDataSetChanged();
                    }

                    if (topicList.size() < 20) {
                        isComplete = true;
                        serviceListView.removeFooterView(listFooter);
                    }
                } catch (JSONException e) {
                    hideContentView();
                    cellStatusErrorServer.setVisibility(View.VISIBLE);
                    e.printStackTrace();
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (loadType == GET_DATA_REFRESH) {
                    isRefresh = false;
                    hideStatusLoading();
                    hideContentView();
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        cellStatusErrorNetwork.setVisibility(View.VISIBLE);
                        return;
                    }
                    if (!TextUtils.isEmpty(error.getMessage())) {
                        textStatusErrorServer.setText(error.getMessage());
                    }
                    cellStatusErrorServer.setVisibility(View.VISIBLE);
                } else {
                    page--;
                    isLoad = false;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);

                    listFooter.setVisibility(View.VISIBLE);
                    footerReload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getData(loadType, false);
                        }
                    });
                }
            }
        });
    }

    private void hideContentView() {
        categoryListView.setVisibility(View.GONE);
        line.setVisibility(View.GONE);
        serviceListView.setVisibility(View.GONE);
    }


    private void showStatusLoading() {
        try {
            cellStatusDotLoading.setVisibility(View.VISIBLE);
//            loadingAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.loading_animation);
//            ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
//            loadingImage.setBackgroundDrawable(loadingAnimation);
//            loadingAnimation.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideStatusLoading() {
        try {
            if (cellStatusDotLoading != null) {
                cellStatusDotLoading.setVisibility(View.GONE);
//                if (loadingAnimation != null) {
//                    loadingAnimation.stop();
//                    loadingAnimation = null;
//                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
