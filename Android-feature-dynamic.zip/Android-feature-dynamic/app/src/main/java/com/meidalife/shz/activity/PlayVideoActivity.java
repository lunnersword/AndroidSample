package com.meidalife.shz.activity;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.widget.VideoView;
import com.usepropeller.routable.Router;
import com.yixia.camera.util.DeviceUtils;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 视频预览
 *
 * @author zuozheng.zhq
 */
public class PlayVideoActivity extends BaseActivity implements VideoView.OnPlayStateListener, MediaPlayer.OnPreparedListener {


    public static final int PROGRESS_CHANGED = 0;

    /**
     * 窗体宽度
     */
    private int mWindowWidth;
    /**
     * 视频信息
     */

    /**
     * 是否需要恢复视频播放
     */
//    private boolean mNeedResume;

    @Bind(R.id.video_player_view)
    VideoView mVideoView;

    @Bind(R.id.video_player_button)
    TextView mPlayButton;


    @Bind(R.id.seekBar)
    SeekBar seekBar;

    @Bind(R.id.timeTip)
    TextView timeTip;


    @Bind(R.id.resetVideoView)
    TextView resetVideoView;

    @Bind(R.id.deleteVideoView)
    TextView deleteVideoView;


    private volatile boolean isPlaying = false;
    //    View rowView;
    int currentLength;

    private Thread mPlayThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_video);

        initActionBar("视频播放", true, false);

        mWindowWidth = DeviceUtils.getScreenWidth(this);
//        LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

//        rowView = inflater.inflate(R.layout.activity_play_video, null);

        //绑定控件
        ButterKnife.bind(this);

        Bundle bundle = getIntent().getExtras();
        String videoUrl = Uri.decode(bundle.getString("videoUrl"));

        //播放器默认不循环
        mVideoView.setLooping(false);
        mVideoView.setVideoPath(videoUrl);
        timeTip.setText(0 + "/" + (int) Math.floor(mVideoView.getDuration() / 1000));

        mVideoView.setOnPreparedListener(this);
        mVideoView.setOnPlayStateListener(this);

        // 为进度条添加进度更改事件
        seekBar.setOnSeekBarChangeListener(change);

        //初始数据
//        findViewById(R.id.record_layout).getLayoutParams().height = mWindowWidth;//设置1：1预览范围


        //绑定事件
        mPlayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playVideo();
            }
        });

        resetVideoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("video", PlayVideoActivity.this);
                finish();
            }
        });

        deleteVideoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteVideo();
            }
        });

    }

    private SeekBar.OnSeekBarChangeListener change = new SeekBar.OnSeekBarChangeListener() {

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            int progress = seekBar.getProgress();
            if (mVideoView != null && mVideoView.isPlaying()) {
                // 设置当前播放的位置
                mVideoView.seekTo(progress);
            }
        }
    };

    @Override
    public void onPrepared(MediaPlayer mp) {
//        mVideoView.start();
//        mVideoView.setLooping(false);
    }

    public void playVideo() {
        if (isPlaying) {
            currentLength = mVideoView.getCurrentPosition();
            mVideoView.pause();
        } else {
            mVideoView.start();
            updateSeekBar();
        }
        isPlaying = !isPlaying;
    }

    void updateSeekBar() {
        // 按照初始位置播放
        mVideoView.seekTo(currentLength);
        // 设置进度条的最大进度为视频流的最大播放时长
        seekBar.setMax(mVideoView.getDuration());

        // 开始线程，更新进度条的刻度
        mPlayThread = new Thread(recordThread);
        mPlayThread.start();
    }

    private Runnable recordThread = new Runnable() {
        @Override
        public void run() {
            while (isPlaying) {
                if (mVideoView.getCurrentPosition() == mVideoView.getDuration()) {
                    break;
                }
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                myHandler.sendEmptyMessage(PROGRESS_CHANGED);
            }
        }
    };


    Handler myHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case PROGRESS_CHANGED:
                    int current = mVideoView.getCurrentPosition();
                    seekBar.setProgress(current);
                    timeTip.setText(formatDurationTime((int) Math.floor(current / 1000)) + "/" + formatDurationTime((int) Math.floor(mVideoView.getDuration() / 1000)));
                    break;
            }
        }
    };

    private String formatDurationTime(int time) {
        if (time < 10) {
            return "00:0" + time;
        }
        return "00:" + time;
    }

    public void onStateChanged(boolean isPlaying) {
        //todo 如果是播放状态 修改播放按钮样式
        if (isPlaying) {
            mPlayButton.setText(getResources().getString(R.string.icon_pause));
        } else {
            mPlayButton.setText(getResources().getString(R.string.icon_play));
        }
    }

    public static boolean isExternalStorageRemovable() {
        if (DeviceUtils.hasGingerbread())
            return Environment.isExternalStorageRemovable();
        else
            return Environment.MEDIA_REMOVED.equals(Environment.getExternalStorageState());
    }

    public void stop() {
        mPlayThread.interrupt();
        isPlaying = false;
        mVideoView.release();
    }

    void deleteVideo() {
        //todo upload
        HttpClient.get("1.0/user/delUserVideo", null, String.class, new HttpClient.HttpCallback<String>() {
            @Override
            public void onSuccess(String obj) {
//                coverFlowAdapter.setVideoUrl("");
//                coverFlowAdapter.setVideoPicUrl("");
//                syncCoverFlowAdapter();
                finish();
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }


}
