package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;

/**
 * Created by liujian on 16/1/6.
 */
public class SquareServiceBannerAdapter extends BaseAdapter{
    private JSONArray banners;
    private Context context;
    private LayoutInflater mInflater;

    public SquareServiceBannerAdapter(Context context,JSONArray banners) {
        this.banners = banners;
        this.context = context;
        this.mInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return banners.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.item_square_service_banner,parent,false);
            holder = new ViewHolder();
            holder.picView = (SimpleDraweeView)convertView.findViewById(R.id.picView);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder)convertView.getTag();
        }
        JSONObject item = banners.getJSONObject(position);
        holder.picView.setImageURI(Uri.parse(item.getString("picUrl")));
        return convertView;
    }

    static class ViewHolder{
        SimpleDraweeView picView;
    }
}
