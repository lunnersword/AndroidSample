package com.meidalife.shz.activity.fragment;

import android.support.v4.app.Fragment;
import android.view.KeyEvent;

import com.meidalife.shz.analysis.LogUtil;


/**
 * Created by zhq on 15/10/22.
 */
public class BaseFragment extends Fragment {

    @Override
    public void onResume() {
        super.onResume();
        reportResume();
    }

    public void reportResume() {
        LogUtil.log(LogUtil.TYPE_START_PAGE, this.getClass().getName());
    }

    @Override
    public void onPause() {
        super.onPause();
        reportPause();
    }

    public void reportPause() {
        LogUtil.log(LogUtil.TYPE_EXIT_PAGE, this.getClass().getName());
    }

    public boolean onFragmentKeyDown(int keyCode, KeyEvent event) {
        return false;
    }
}
