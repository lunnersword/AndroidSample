package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ShareSocialPlateformAdapter;
import com.meidalife.shz.event.DynamicListRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.media.AudioRecorder;
import com.meidalife.shz.media.PlayMediaService;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicOutDO;
import com.meidalife.shz.rest.model.SocialShareDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.view.RecordTextView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.greenrobot.event.EventBus;

/**
 * Created by zhq on 16/4/4.
 */
public class PublishVoiceDynamicActivity extends BaseActivity {

    String itemId;
    //    boolean uploadComplete = false;
    boolean submit = false;

    boolean isPlaying = false;

    //    private int dynTime = 0;
//    private int newTime = 0;
    AudioRecorder audioRecorder;
    Intent playIntent;
    String voiceFilePath;
    long voiceRecordTime;
    private String voiceFileUrl;

    @Bind(R.id.textDescription)
    EditText textDescription;
    @Bind(R.id.textDescLimit)
    TextView textDescLimit;

    @Bind(R.id.recordView)
    ViewGroup recordView;
    @Bind(R.id.voiceRecord)
    RecordTextView voiceRecord;
    @Bind(R.id.recordTipTV)
    TextView recordTipTV;

    @Bind(R.id.playView)
    ViewGroup playView;
    @Bind(R.id.voiceTimeSpan)
    TextView voiceTimeSpan;
    @Bind(R.id.resetView)
    View resetView;

    @Bind(R.id.selectServiceTips)
    TextView selectServiceTips;
    @Bind(R.id.selectServiceTipsDesc)
    TextView selectServiceTipsDesc;

    @Bind(R.id.relativeServiceViewGroup)
    ViewGroup relativeServiceViewGroup;
    @Bind(R.id.textRelativeService)
    TextView textRelativeService;
    @Bind(R.id.iconRight)
    TextView iconRight;

    @Bind(R.id.rootView)
    ViewGroup rootView;

    @Bind(R.id.share_recycler_view)
    RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish_voice_dynamic);
        initActionBar("发布语音", true, true);

        ButterKnife.bind(this);
        renderPubButtonView(false);

        hideIMM();
        playIntent = new Intent(this, PlayMediaService.class);

        iconRight.setTypeface(Helper.sharedHelper().getIconFont());

        audioRecorder = new AudioRecorder();
        voiceRecord.setAudioRecord(audioRecorder);
        voiceRecord.setMaxRecordTimeLength(120);
        voiceRecord.setRecordListener(new VoiceRecordListener());
        voiceRecord.setMaxEms(120);

        initListener();
        //todo 初始化社会化分享数据 默认都不勾选
        showSocialShareView(recyclerView, new ArrayList<SocialShareDO>());
    }

    private void renderPubButtonView(boolean pubButtonEnable) {
        if (pubButtonEnable) {
            mButtonRight.setEnabled(true);
            mButtonRight.setBackgroundColor(getResources().getColor(R.color.brand));
            mButtonRight.setTextColor(getResources().getColor(R.color.brand_c));
        } else {
            mButtonRight.setEnabled(false);
            mButtonRight.setBackgroundColor(getResources().getColor(R.color.grey_s));
            mButtonRight.setTextColor(getResources().getColor(R.color.grey_j));
        }
    }

    void initListener() {
        playView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!isPlaying) {
                    playIntent.putExtra(PlayMediaService.INTENT_MEDIA_PLAY, voiceFilePath);
                    startService(playIntent);
                } else {
                    stopService(playIntent);
                }
                isPlaying = !isPlaying;
            }
        });

        resetView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(playIntent);
                recordView.setVisibility(View.VISIBLE);
                playView.setVisibility(View.GONE);
                audioRecorder.deleteOldFile();

                voiceFileUrl = "";
            }
        });

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handlePublish(v);
            }
        });

        textDescription.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
                    return true;
                }
                return false;
            }
        });

        textDescription.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textDescLimit.setText(String.valueOf(s.toString().length()));
                if (s.toString().length() > 300) {
                    textDescLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textDescLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    public void showSocialShareView(RecyclerView recyclerView, List<SocialShareDO> dataList) {

        recyclerView.removeAllViews();
        if (CollectionUtil.isEmpty(dataList)) {
            recyclerView.setVisibility(View.GONE);
            return;
        }
        recyclerView.setVisibility(View.VISIBLE);

        recyclerView.setHasFixedSize(true);

        final LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(new ShareSocialPlateformAdapter(this, dataList));
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Bundle bundle;
        switch (requestCode) {
            case Constant.REQUEST_CODE_PICK_SERVICE:
                if (resultCode == RESULT_OK) {
                    bundle = data.getExtras();
                    itemId = bundle.getString("itemId");
                    textRelativeService.setText(bundle.getString("title"));
                    if (TextUtils.isEmpty(itemId)) {
                        relativeServiceViewGroup.setVisibility(View.GONE);
                        selectServiceTips.setVisibility(View.VISIBLE);
                        selectServiceTipsDesc.setVisibility(View.VISIBLE);
                    } else {
                        relativeServiceViewGroup.setVisibility(View.VISIBLE);
                        selectServiceTips.setVisibility(View.GONE);
                        selectServiceTipsDesc.setVisibility(View.GONE);
                    }
                }
                break;
            default:
                break;
        }
    }

    public void handleSelectService(View view) {
        if (itemId != null) {
            Bundle bundle = new Bundle();
            bundle.putString("itemId", itemId);
            Router.sharedRouter().openFormResult("bind/service", bundle,
                    Constant.REQUEST_CODE_PICK_SERVICE, this);
        } else {
            Router.sharedRouter().openFormResult("bind/service",
                    Constant.REQUEST_CODE_PICK_SERVICE, this);
        }
    }

    @OnClick(R.id.action_bar_button_right)
    public void handlePublish(View view) {
        if (TextUtils.isEmpty(voiceFileUrl)) {
            xhrUploadVoiceFile();
        } else {
            xhrPublish();
        }
    }

    //todo 增加录音1-120秒限制
    class VoiceRecordListener implements RecordTextView.RecordListener {
        @Override
        public void recordStart() {
            Log.d("mylisten", "start");
//            volumeGroup.setVisibility(View.VISIBLE);
            recordTipTV.setText("松开结束");

            //设置录音button背景
        }

        @Override
        public void recording(double voiceValue, float time) {
//            setDialogImage(voiceValue);

//            newTime = (int) time;
//            if (newTime != dynTime) {
//                voiceTimeSpan.setText("00:" + newTime);
//                dynTime = newTime;
//            }

//            Log.d("mylisten", String.valueOf(dynTime));
        }

        @Override
        public void recordCancel() {
//            volumeGroup.setVisibility(View.INVISIBLE);
            recordTipTV.setText("按住录音");
            voiceTimeSpan.setText("00:00");
            //设置录音button背景
        }

        @Override
        public void recordEnd(String filePath, long recordTime) {
            Log.e(ChatActivity.class.getName(), "record voice end, file = " + filePath + ", record time = " + recordTime);
            Log.d("mylisten", "end");
            //录音界面结束  显示播放界面

            voiceFilePath = filePath;
            voiceRecordTime = recordTime;

            recordTipTV.setText("录音结束");
            recordView.setVisibility(View.GONE);

            playView.setVisibility(View.VISIBLE);
            //todo 秒数转变成分钟
            voiceTimeSpan.setText("" + recordTime);

            xhrUploadVoiceFile();
        }

    }


    public void xhrUploadVoiceFile() {
        if (TextUtils.isEmpty(voiceFilePath)) {
            MessageUtils.showToast("语音文件为空 请重新录制");
            return;
        }
        RequestSign.uploadVoice(voiceFilePath, new HttpClient.HttpCallback<String>() {
            @Override
            public void onSuccess(String voiceUrl) {
                voiceFileUrl = voiceUrl;
                renderPubButtonView(true);
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }


    private void xhrPublish() {
        if (submit) {
            return;
        } else {
            submit = true;
            showProgressDialog("正在发布", false);
        }

        JSONObject params = new JSONObject();

        try {
            if (itemId != null) {
                params.put("itemId", itemId);
            }
            if (textDescription.getText() != null) {
                params.put("description", textDescription.getText().toString());
            }

            params.put("audioURL", voiceFilePath);
            params.put("audioLength", voiceRecordTime);
            params.put("type", 1);//1:音频

            RequestDynamic.createFeed(params, new HttpClient.HttpCallback<DynamicOutDO>() {
                @Override
                public void onSuccess(DynamicOutDO dynamic) {
                    submit = false;
                    hideProgressDialog();
                    //发布成功 关联服务插动态list
                    if (dynamic != null) {
                        DynamicListRefreshEvent updateItemEvent = new DynamicListRefreshEvent();
                        updateItemEvent.eventType = MsgTypeEnum.TYPE_PUBLISH;
                        updateItemEvent.dynamic = dynamic;
                        EventBus.getDefault().post(updateItemEvent);
                    }
                    finish();
                }

                @Override
                public void onFail(HttpError error) {
                    submit = false;
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败，请重试");
                }
            });
        } catch (JSONException e) {

        }
    }



}
