package com.meidalife.shz.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.SearchResActivity;
import com.meidalife.shz.event.SearchParamsChanceEvent;
import com.meidalife.shz.rest.model.SearchFilterDO;
import com.meidalife.shz.rest.model.TabItem;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;
import com.meidalife.shz.widget.SearchFilterPopupWindow;
import com.meidalife.shz.widget.SearchSortPopupWindow;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.greenrobot.event.EventBus;

/**
 * Created by yiyang on 16/3/10.
 */
public class SearchRecyclerViewAdapter extends RecyclerView.Adapter<SearchRecyclerViewAdapter.ViewHolder> {

    private static final int TYPE_POP_MENU = 0;
    private static final int TYPE_ONE_SITUATION = 1;
    private static final int TYPE_TWO_SITUATIONS = 2;

    private LayoutInflater mInflater;
    private List<TabItem> mDatas;
    private Activity mContext;

    private SearchSortPopupWindow searchSortPopupWindow;
    private SearchFilterPopupWindow searchFilterPopupWindow;
    private SearchFilterDO mSearchFilterDO;

    private int selectedIndex = 0;
    private boolean noRefresh = false;  //用于主动调用数据刷新时，不清除TYPE_TWO_SITUATIONS的记录
    private int popupIndex = -1;

    public void setSearchFilterDO(SearchFilterDO searchFilterDO) {
        this.mSearchFilterDO = searchFilterDO;
        if (searchFilterPopupWindow != null) {
            searchFilterPopupWindow.setFilterOptionses(mSearchFilterDO.getFilterOptions());
            searchFilterPopupWindow.setCateProps(mSearchFilterDO.getCateProp());
            searchFilterPopupWindow.clearFilterDate();
        }
    }

    public void setSelectedIndex(int index) {
        selectedIndex = index;
    }


    public SearchRecyclerViewAdapter(Activity context, List<TabItem> datats) {
        mInflater = LayoutInflater.from(context);
        mDatas = datats;
        mContext = context;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View arg0) {
            super(arg0);
        }

        View rootView;
        View dividerLine;
        FontTextView title;
        IconTextView icon;

    }

    @Override
    public int getItemCount() {
        return mDatas.size();
    }

    /**
     * 创建ViewHolder
     */
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int position) {
        View view = mInflater.inflate(R.layout.item_search_recycler_view, null);
        ViewHolder viewHolder = new ViewHolder(view);

        viewHolder.rootView = view;
        viewHolder.dividerLine = view.findViewById(R.id.dividerLine);
        viewHolder.title = (FontTextView) view.findViewById(R.id.titleText);
        viewHolder.icon = (IconTextView) view.findViewById(R.id.icon);
        return viewHolder;
    }

    /**
     * 设置值
     */
    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        int tagType = 0;

        final TabItem typeItem = mDatas.get(position);
        tagType = typeItem.getTagType();

        String title = typeItem.getName();
        if (selectedIndex == position) {
            viewHolder.title.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            viewHolder.icon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
        } else if (popupIndex != position) {
            viewHolder.title.setTextColor(mContext.getResources().getColor(R.color.grey_a));
            viewHolder.icon.setTextColor(mContext.getResources().getColor(R.color.grey_a));
        }
        viewHolder.title.setText(title);

        if (!noRefresh) {

            switch (tagType) {
                case TYPE_POP_MENU:

                    viewHolder.rootView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (searchSortPopupWindow != null && searchSortPopupWindow.isShowing()) {
                                searchSortPopupWindow.dismiss();
                                return;
                            }
                            if (searchSortPopupWindow == null) {
                                searchSortPopupWindow = new SearchSortPopupWindow(mContext);
                                if (typeItem.getChilds() != null && typeItem.getChilds().size() > 0)
                                    searchSortPopupWindow.setData(typeItem.getChilds());
                            }

                            searchSortPopupWindow.showAsDropDown((View) v.getParent(), 0, (int) Helper.convertDpToPixel(1, mContext));
                            searchSortPopupWindow.setIndexChangeListener(new SearchSortPopupWindow.IPopupSelectIndexChangeListener() {
                                @Override
                                public void setIndex(int index) {
                                    viewHolder.title.setText(typeItem.getChilds().get(index).getName());
                                    selectedIndex = position;
                                    noRefresh = true;
                                    notifyDataSetChanged();
                                }
                            });

                        }
                    });

                    viewHolder.dividerLine.setVisibility(View.GONE);
                    viewHolder.icon.setText(R.string.icon_search_sort);
                    viewHolder.icon.setVisibility(View.VISIBLE);

                    break;

                case TYPE_ONE_SITUATION:

                    if (title.equals("筛选")) {

                        viewHolder.title.setText(title);
                        viewHolder.rootView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (mSearchFilterDO != null)
                                    showFilterPop();
                            }
                        });
                        ((SearchResActivity) mContext).setIFilterChangeListener(new SearchResActivity.IFilterChangeListener() {
                            @Override
                            public void changeStatus(boolean isChecked, int popupIndex) {
//// TODO: 筛选有bug待修复
//                                if (isChecked) {
//                                    viewHolder.title.setTextColor(mContext.getResources().getColor(R.color.brand_b));
//                                    viewHolder.icon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
//                                } else {
//                                    viewHolder.title.setTextColor(mContext.getResources().getColor(R.color.grey_a));
//                                    viewHolder.icon.setTextColor(mContext.getResources().getColor(R.color.grey_a));
//                                }
                            }
                        });
                        viewHolder.dividerLine.setVisibility(View.VISIBLE);
                        viewHolder.icon.setText(R.string.icon_search_filter);
                        viewHolder.icon.setVisibility(View.VISIBLE);
                    } else {

                        viewHolder.rootView.setTag(typeItem.getType());
                        viewHolder.rootView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String type = (String) v.getTag();
                                SearchParamsChanceEvent searchParamsChanceEvent = new SearchParamsChanceEvent(type);
                                EventBus.getDefault().post(searchParamsChanceEvent);
                                selectedIndex = position;
                                noRefresh = true;
                                notifyDataSetChanged();
                            }
                        });
                        viewHolder.dividerLine.setVisibility(View.GONE);
                        viewHolder.icon.setVisibility(View.GONE);
                    }

                    break;

                case TYPE_TWO_SITUATIONS:
                    Map<String, Integer> mapTag = new HashMap<>();
                    mapTag.put("isDown", 1);
                    mapTag.put("firstTag", typeItem.getChilds().get(0).getType());
                    mapTag.put("secondTag", typeItem.getChilds().get(1).getType());

                    viewHolder.rootView.setTag(mapTag);
                    viewHolder.rootView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Map<String, Integer> mapTag = (Map<String, Integer>) v.getTag();
                            Integer isDown = mapTag.get("isDown");
                            String type;

                            if (isDown.equals(1)) {
                                viewHolder.icon.setText(R.string.icon_expan);
                                type = String.valueOf(mapTag.get("secondTag"));
                                EventBus.getDefault().post(new SearchParamsChanceEvent(type));
                                mapTag.put("isDown", 0);
                            } else {
                                viewHolder.icon.setText(R.string.icon_search_up);
                                type = String.valueOf(mapTag.get("firstTag"));
                                EventBus.getDefault().post(new SearchParamsChanceEvent(type));
                                mapTag.put("isDown", 1);
                            }
                            v.setTag(mapTag);
                            selectedIndex = position;
                            noRefresh = true;
                            notifyDataSetChanged();
                        }
                    });

                    viewHolder.dividerLine.setVisibility(View.GONE);
                    viewHolder.icon.setText(R.string.icon_expan);
                    viewHolder.icon.setVisibility(View.VISIBLE);
                    break;

            }
        }

        if (position == getItemCount() - 1) {
            noRefresh = false;
        }
    }

    private void showFilterPop() {
        if (searchFilterPopupWindow != null && searchFilterPopupWindow.isShowing()) {
            searchFilterPopupWindow.dismiss();
            return;
        }
        if (searchFilterPopupWindow == null) {
            searchFilterPopupWindow = new SearchFilterPopupWindow(mContext);
            searchFilterPopupWindow.setFilterOptionses(mSearchFilterDO.getFilterOptions());
            searchFilterPopupWindow.setCateProps(mSearchFilterDO.getCateProp());
        }
        searchFilterPopupWindow.showAtLocation(mContext.getWindow().getDecorView(), Gravity.BOTTOM, 0, 0);
    }
}
