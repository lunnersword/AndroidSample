package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.OrderListFragment;
import com.meidalife.shz.adapter.FragmentTabAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.OrderListOutDO;
import com.meidalife.shz.rest.model.OrderTabTypeOutDO;
import com.meidalife.shz.rest.request.RequestOrderList;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.widget.SlidingTabLayout;
import com.usepropeller.routable.Router;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/12/1.
 */
public class OrderListActivity extends BaseActivity implements ViewPager.OnPageChangeListener {
    public static final int ROLE_TYPE_BUY = 1;
    public static final int ROLE_TYPE_SELL = 2;
    private int roleType = 1;
    private int page = 1;
    private int pageSize = 5;

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.orderSlidingTab)
    SlidingTabLayout orderSlidingTab;
    @Bind(R.id.orderTabViewPager)
    ViewPager orderTabViewPager;

    @Bind(R.id.action_bar_button_right)
    Button searchButton;
    FragmentTabAdapter orderPagerAdapter;

    private LoadUtil mLoadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_list);
        ButterKnife.bind(this);

        Bundle extras = getIntent().getExtras();
        String roleTypeObj = extras.getString("type");
        String url = "buyOrders/" + ROLE_TYPE_BUY;
        if (!TextUtils.isEmpty(roleTypeObj)) roleType = Integer.parseInt(roleTypeObj);
        if (roleType == ROLE_TYPE_BUY) {
            initActionBar(R.string.title_activity_orders_buy, true, true);    //统一继承BaseActivity风格
            url = "buyOrders/" + ROLE_TYPE_BUY;

        } else if (roleType == ROLE_TYPE_SELL) {
            initActionBar(R.string.title_activity_orders_sale, true, true);
            url = "saleOrders/" + ROLE_TYPE_SELL;
        }

        if (!Helper.sharedHelper().hasToken()) {
            Bundle bundle = new Bundle();
            bundle.putString("action", url);
            Router.sharedRouter().open("signin", bundle);
            finish();
        }

        searchButton = (Button) findViewById(R.id.action_bar_button_right);
        searchButton.setTypeface(Helper.sharedHelper().getIconFont());
        searchButton.setText(R.string.icon_search);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("orderSearch/" + roleType);
            }
        });
        mLoadUtil = new LoadUtil(getLayoutInflater());
        orderPagerAdapter = new FragmentTabAdapter(getSupportFragmentManager());
        initData();
    }

    private void initData() {
        mLoadUtil.loadPre(rootView, orderTabViewPager);
        RequestOrderList.get(roleType, 0, page, pageSize, new HttpClient.HttpCallback<OrderListOutDO>() {
            @Override
            public void onSuccess(OrderListOutDO result) {
                mLoadUtil.loadSuccess(orderTabViewPager);
                if (result != null && CollectionUtil.isNotEmpty(result.getOrderCounts())) {
                    loadOrderTab(result.getOrderCounts());
                }
            }

            @Override
            public void onFail(HttpError error) {
                mLoadUtil.loadFail(error, rootView, OrderListActivity.this, new LoadUtil.LoadCallback() {
                    @Override
                    public void execute() {
                        initData();
                    }
                });
            }
        });
    }

    private void loadOrderTab(List<OrderTabTypeOutDO> list) {
        for (int i = 0; i < list.size(); i++) {
            OrderTabTypeOutDO orderTabTypeDO = list.get(i);
            OrderListFragment orderListFragment = OrderListFragment.newInstance(orderTabTypeDO, roleType);

            orderListFragment.setOnDataChangeListener(new OrderListFragment.OnDataChangeListener() {
                @Override
                public void onDataChange(List<OrderTabTypeOutDO> orderTabTypeDOList) {
                    //更新订单数字
                    for (int index = 0; index < orderTabTypeDOList.size(); index++) {
                        OrderTabTypeOutDO orderTabTypeDO = orderTabTypeDOList.get(index);
                        TextView orderCountView = (TextView) (orderSlidingTab.
                                getChildTabView(index).findViewById(R.id.orderCount));

                        if (null != orderTabTypeDO.getCount() &&
                                orderTabTypeDO.getCount() > 0) {
                            orderCountView.setText(String.valueOf(orderTabTypeDO.getCount()));
                            orderCountView.setVisibility(View.VISIBLE);
                        } else {
                            orderCountView.setVisibility(View.GONE);
                        }
                    }
                }
            });

            orderPagerAdapter.addFragment(orderListFragment);
        }

        orderPagerAdapter.notifyDataSetChanged();
        orderTabViewPager.setAdapter(orderPagerAdapter);
        orderSlidingTab.setCustomTabView(R.layout.item_order_tab, R.id.orderTabName);
        orderSlidingTab.setSelectedIndicatorColors(getResources().getColor(R.color.brand_b));
        orderSlidingTab.setSelectedTabTitleColorId(R.color.brand_b);
        orderSlidingTab.setTabTitleColorId(R.color.black);
        orderSlidingTab.setViewPager(orderTabViewPager);
        orderSlidingTab.setDividerColors(android.R.color.transparent);
        orderSlidingTab.setOnPageChangeListener(this);
        orderSlidingTab.setCalculateWidthByTitle(false);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        ((OrderListFragment) (orderPagerAdapter.getItem(position))).loadData(true);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
