package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;

/**
 * Created by xingchen on 2015/12/22.
 */
public class SquareManageActionAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater mInflater;
    private JSONArray actionList;

    public SquareManageActionAdapter(Context context, JSONArray actionList) {
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.actionList = actionList;
    }

    @Override
    public int getCount() {
        return actionList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_square_manager_action, parent, false);
            holder = new ViewHolder();
            holder.icon = (SimpleDraweeView) convertView.findViewById(R.id.icon);
            holder.desc = (TextView) convertView.findViewById(R.id.desc);
            holder.number = (TextView) convertView.findViewById(R.id.number);
            holder.numberLayout = convertView.findViewById(R.id.numberLayout);
            holder.tips = (TextView) convertView.findViewById(R.id.tips);
            holder.line = convertView.findViewById(R.id.line);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        JSONObject item = actionList.getJSONObject(position);
        if (item.containsKey("icon"))
            holder.icon.setImageURI(Uri.parse(item.getString("icon")));
        if (item.containsKey("desc"))
            holder.desc.setText(item.getString("desc"));

        if (item.containsKey("tips")) {
            holder.tips.setVisibility(View.VISIBLE);
            holder.tips.setText(item.getString("tips"));
            holder.numberLayout.setVisibility(View.GONE);
        } else
            holder.tips.setVisibility(View.GONE);

        if (item.containsKey("number")) {
            holder.numberLayout.setVisibility(View.VISIBLE);
            if (item.getIntValue("number") > 99) {
                holder.number.setText("99+");
            }else if(item.getIntValue("number") == 0){
                holder.numberLayout.setVisibility(View.GONE);
            }
            else
                holder.number.setText(item.getIntValue("number") + "");
            holder.tips.setVisibility(View.GONE);
        } else
            holder.numberLayout.setVisibility(View.GONE);

        if(!item.containsKey("tips")&& (!item.containsKey("number") || item.getIntValue("number") == 0)){
            holder.tips.setVisibility(View.VISIBLE);
            holder.tips.setText("");
        }

        if (actionList.size() == position + 1) {
            holder.line.setVisibility(View.GONE);
        } else
            holder.line.setVisibility(View.VISIBLE);
        return convertView;
    }

    static class ViewHolder {
        SimpleDraweeView icon;
        TextView desc;
        TextView tips;
        View numberLayout;
        TextView number;
        View line;
    }
}
