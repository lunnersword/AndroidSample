package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;


import java.util.HashMap;

/**
 * Created by xingchen on 2015/12/21.
 */
public class SquareListAdapter extends BaseAdapter {
    private static int HOLDER_TYPE_TITLE = 1;
    private static int HOLDER_TYPE_CONTENT = 2;

    public static final int DATA_TYPE_HOST = 1;
    public static final int DATA_TYPE_MEMBER = 2;

    private Context context;
    private LayoutInflater mInflater;
    private JSONArray hostList;
    private JSONArray memberList;

    private View.OnClickListener onClickListener;

    public SquareListAdapter(Context context, JSONArray hostList, JSONArray memberList) {
        this.memberList = memberList;
        this.hostList = hostList;
        this.context = context;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return (hostList.size() > 0 ? hostList.size() + 1 : 0) + (memberList.size() > 0 ? memberList.size() + 1 : 0);

    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (hostList.size() > 0 && position == 0) {
            convertView = getTitleViewHolder(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            TitleViewHolder holder = (TitleViewHolder) tag.get("holder");
            holder.title.setText(context.getResources().getString(R.string.square_my_host));
            return convertView;
        }
        if (memberList.size() > 0
                && (hostList.size() > 0 && position == hostList.size() + 1)
                || (hostList.size() == 0 && position == 0)) {
            convertView = getTitleViewHolder(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            TitleViewHolder holder = (TitleViewHolder) tag.get("holder");
            holder.title.setText(context.getResources().getString(R.string.square_my_join));
            return convertView;
        }

        convertView = getContentViewHolder(convertView, parent);
        HashMap tag = (HashMap) convertView.getTag();
        ContentViewHolder holder = (ContentViewHolder) tag.get("holder");
        JSONObject item = null;
        int dataType = 0;
        if (hostList.size() > 0 && (position < hostList.size() + 1)) {
            item = hostList.getJSONObject(position - 1);
            dataType = DATA_TYPE_HOST;
        }
        if (memberList.size() > 0) {
            if (hostList.size() == 0) {
                item = memberList.getJSONObject(position - 1);
                dataType = DATA_TYPE_MEMBER;
            } else {
                if (position > hostList.size() + 1){
                    item = memberList.getJSONObject(position - 2 - hostList.size());
                    dataType = DATA_TYPE_MEMBER;
                }
            }
        }
        if (item == null)
            return convertView;
        if (item.containsKey("geziPicUrl")) {
            holder.picView.setImageURI(Uri.parse(item.getString("geziPicUrl")));
        } else {
            holder.picView.setImageURI(Uri.parse(""));
        }
        holder.textName.setText(item.getString("geziName"));
        holder.textTypeDesc.setText("[" + item.getString("geziTypeDesc") + "]");
        if (item.containsKey("statusDesc")) {
            holder.statusDesc.setText(item.getString("statusDesc"));
        } else
            holder.statusDesc.setText("");
        if(item.getIntValue("itemCount") == 0){
            holder.serviceCountLayout.setVisibility(View.GONE);
        }else{
            holder.serviceCountLayout.setVisibility(View.VISIBLE);
            holder.itemCount.setText("服务数："+item.getIntValue("itemCount"));
            holder.itemCountIncrement.setVisibility(View.VISIBLE);
            if (item.getIntValue("itemCountArrow") == 1) {
                holder.itemCountIncrement.setText(String.format(context.getResources().getString(R.string.square_member_status_up), item.getIntValue("itemCountIncrement") + ""));
            } else if (item.getIntValue("itemCountArrow") == -1) {
                holder.itemCountIncrement.setText(String.format(context.getResources().getString(R.string.square_member_status_down), item.getIntValue("itemCountIncrement") + ""));
            } else
                holder.itemCountIncrement.setVisibility(View.GONE);
        }

        holder.userCount.setText("成员数："+item.getIntValue("userCount") + "");
        holder.userCountIncrement.setVisibility(View.VISIBLE);
        if (item.getIntValue("userCountArrow") == 1) {
            holder.userCountIncrement.setText(String.format(context.getResources().getString(R.string.square_member_status_up), item.getIntValue("userCountIncrement") + ""));
        } else if (item.getIntValue("userCountArrow") == -1) {
            holder.userCountIncrement.setText(String.format(context.getResources().getString(R.string.square_member_status_down), item.getIntValue("userCountIncrement") + ""));
        } else
            holder.userCountIncrement.setVisibility(View.GONE);
        holder.line.setVisibility(View.VISIBLE);
        if (hostList.size() > 0) {
            if (position == hostList.size())
                holder.line.setVisibility(View.GONE);
        }
        if (memberList.size() > 0) {
            if (hostList.size() == 0) {
                if (position == memberList.size())
                    holder.line.setVisibility(View.GONE);
            } else {
                if (position == hostList.size() + memberList.size() + 1)
                    holder.line.setVisibility(View.GONE);
            }
        }
        if(onClickListener != null){
            HashMap params = new HashMap();
            params.put("position",position);
            params.put("dataType",dataType);
            holder.contentView.setTag(params);
            holder.contentView.setOnClickListener(onClickListener);
        }
        boolean isHost = false;
        if(hostList.size() > 0 && dataType == DATA_TYPE_MEMBER){
            int itemId = item.getIntValue("geziId");
            for(int i=0;i<hostList.size();i++){
                int hostId = ((JSONObject)hostList.get(i)).getIntValue("geziId");
                if(hostId == itemId){
                    isHost = true;
                    break;
                }
            }
        }
        if((item.containsKey("isGezhu") && item.getBoolean("isGezhu")) || isHost){

            holder.squareHostTagView.setVisibility(View.VISIBLE);
        }else
            holder.squareHostTagView.setVisibility(View.GONE);
        return convertView;
    }

    private View getTitleViewHolder(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_square_list_title, parent, false);
            TitleViewHolder holder = new TitleViewHolder();
            holder.title = (TextView) convertView.findViewById(R.id.title);
            HashMap tag = new HashMap();
            tag.put("type", HOLDER_TYPE_TITLE);
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != HOLDER_TYPE_TITLE) {
                return getTitleViewHolder(null, parent);
            }
        }
        return convertView;
    }

    private View getContentViewHolder(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_square_list_content, parent, false);
            ContentViewHolder holder = new ContentViewHolder();
            holder.statusDesc = (TextView) convertView.findViewById(R.id.statusDesc);
            holder.textName = (TextView) convertView.findViewById(R.id.textName);
            holder.textTypeDesc = (TextView) convertView.findViewById(R.id.textTypeDesc);
            holder.itemCount = (TextView) convertView.findViewById(R.id.itemCount);
            holder.itemCountIncrement = (TextView) convertView.findViewById(R.id.itemCountIncrement);
            holder.userCount = (TextView) convertView.findViewById(R.id.userCount);
            holder.userCountIncrement = (TextView) convertView.findViewById(R.id.userCountIncrement);
            holder.picView = (SimpleDraweeView) convertView.findViewById(R.id.picView);
            holder.line = convertView.findViewById(R.id.line);
            holder.squareHostTagView = convertView.findViewById(R.id.squareHostTagView);
            holder.contentView = convertView.findViewById(R.id.contentView);
            holder.serviceCountLayout = convertView.findViewById(R.id.serviceCountLayout);
            HashMap tag = new HashMap();
            tag.put("type", HOLDER_TYPE_CONTENT);
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != HOLDER_TYPE_CONTENT) {
                return getContentViewHolder(null, parent);
            }
        }
        return convertView;
    }

    static class TitleViewHolder {
        TextView title;
    }

    static class ContentViewHolder {
        SimpleDraweeView picView;
        TextView statusDesc;
        TextView textName;
        TextView textTypeDesc;
        TextView itemCount;
        TextView itemCountIncrement;
        TextView userCount;
        TextView userCountIncrement;
        View line;
        View squareHostTagView;
        View contentView;
        View serviceCountLayout;
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }
}
