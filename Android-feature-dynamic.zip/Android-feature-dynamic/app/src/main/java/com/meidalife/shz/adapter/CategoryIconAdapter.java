package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CategoryDO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 15/11/8.
 */
public class CategoryIconAdapter extends BaseAdapter {
    private List<CategoryDO> categories = new ArrayList<>();
    private LayoutInflater mInflater;

    public CategoryIconAdapter(Context context) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void setCategories(List<CategoryDO> data) {
        categories = data;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return categories.size();
    }

    @Override
    public Object getItem(int position) {
        return categories.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (convertView == null || convertView.getTag() == null) {
            convertView = mInflater.inflate(R.layout.item_category_with_icon, null);
            viewHolder = new ViewHolder();
            viewHolder.categoryIcon = (SimpleDraweeView) convertView.findViewById(R.id.categoryIcon);
            viewHolder.categoryName = (TextView) convertView.findViewById(R.id.categoryName);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        CategoryDO category = categories.get(position);
        if (!TextUtils.isEmpty(category.getIconUrl())) {
            viewHolder.categoryIcon.setImageURI(Uri.parse(category.getIconUrl()));
        }
        viewHolder.categoryName.setText(category.getCatName());
        return convertView;
    }

    private static class ViewHolder {
        SimpleDraweeView categoryIcon;
        TextView categoryName;
    }
}
