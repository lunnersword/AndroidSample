package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.DynamicBottomDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.JobDO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 16/04/02.
 * 动态详情底部列表
 */
public class DynamicDetailBottomAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    List<DynamicBottomDO> mData;

    public static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.avatar)
        SimpleDraweeView avatar;
        @Bind(R.id.iconGender)
        TextView iconGender;

        @Bind(R.id.nickView)
        public TextView nickView;
        @Bind(R.id.jobsViewGroup)
        LinearLayout jobsViewGroup;

        @Bind(R.id.jobTitleView)
        TextView jobTitleView;

//        @Bind(R.id.publishTimeView)
//        TextView publishTimeView;

        @Bind(R.id.bottomContentTextView)
        TextView bottomContentTextView;
    }

    public DynamicDetailBottomAdapter(Context context, List<DynamicBottomDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public DynamicBottomDO getItem(int position) {
        if (position - 1 >= 0 && position - 1 < mData.size()) {
            return mData.get(position - 1);
        }
        return null;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        DynamicBottomDO item = mData.get(position);

        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_dynamic_detail_bottom, parent, false);
            ViewHolder holder = new ViewHolder(convertView);

            convertView.setTag(holder);
        }
        ViewHolder holder = (ViewHolder) convertView.getTag();

        DynamicUserOutDO user = item.getUser();
        if (user != null) {
            // 加载动态用户信息
            holder.nickView.setText(user.getUserNick());
            holder.nickView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            holder.nickView.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            String gender = "";
            // 设置服务者性别
            if (user.getUserGender() != null) {
                holder.iconGender.setVisibility(View.VISIBLE);
                if (user.getUserGender().equals("woman") || user.getUserGender().equals("F")) {
                    holder.iconGender.setText(mContext.getResources().getString(R.string.icon_female));
                    holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.color_icon_female));
                } else {
                    holder.iconGender.setText(mContext.getResources().getString(R.string.icon_male));
                    holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.color_icon_male));
                }
            } else {
                holder.iconGender.setVisibility(View.GONE);
            }

            ViewGroup.LayoutParams avatarParams = holder.avatar.getLayoutParams();
            if (TextUtils.isEmpty(user.getAvatarUrl())) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(user.getUserId()), gender);
                holder.avatar.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(user.getAvatarUrl(), avatarParams.width));
                holder.avatar.setImageURI(uri);
            }

            holder.jobsViewGroup.removeAllViews();
            if (CollectionUtil.isNotEmpty(user.getJobs())) {
                for (JobDO job : user.getJobs()) {
                    View jobView = mInflater.inflate(R.layout.item_dynamic_user_job, null);
                    SimpleDraweeView icon = (SimpleDraweeView) jobView.findViewById(R.id.avatar);
                    TextView titleView = (TextView) jobView.findViewById(R.id.title);
                    ViewGroup.LayoutParams iconParams = icon.getLayoutParams();

                    if (!TextUtils.isEmpty(job.getIconUrl())) {
                        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(user.getAvatarUrl(), iconParams.width));
                        icon.setImageURI(uri);
                        icon.setVisibility(View.VISIBLE);
                    } else {
                        icon.setImageURI(null);
                        icon.setVisibility(View.GONE);
                    }
                    titleView.setText(job.getTitle());
//        jobsView.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, context) * item.getGrade() / 5);
                    holder.jobsViewGroup.addView(jobView);
                }
                holder.jobsViewGroup.setVisibility(View.VISIBLE);
            } else {
                holder.jobsViewGroup.removeAllViews();
                holder.jobsViewGroup.setVisibility(View.GONE);
            }

            holder.jobTitleView.setText(user.getJobTitle());
            holder.jobTitleView.setVisibility(View.VISIBLE);
        } else {
            holder.nickView.setText("");
            holder.iconGender.setText("");
            holder.avatar.setImageURI(null);
            holder.jobsViewGroup.removeAllViews();
            holder.jobsViewGroup.setVisibility(View.GONE);
            holder.jobTitleView.setText("");
            holder.jobTitleView.setVisibility(View.GONE);
        }
        //todo 显示 留言发布时间

        holder.bottomContentTextView.setText(item.getContent());
        if (TextUtils.isEmpty(item.getContent())) {
            holder.bottomContentTextView.setVisibility(View.GONE);
        } else {
            holder.bottomContentTextView.setVisibility(View.VISIBLE);
        }

        return convertView;
    }
}
