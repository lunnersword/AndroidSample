package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.util.CollectionUtil;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by taber on 15/6/20.
 */
public class AddressAdapter extends BaseAdapter {
    private static final int TYPE_COUNT = 3;
    private Context mContext;
    private ArrayList mDate;
    private LayoutInflater mInflater;
    private int itemType;

    private String mDefaultAddressLabel;

    int VIEW_TYPE_CREATE = 1;
    int VIEW_TYPE_LABEL = 2;
    int VIEW_TYPE_ITEM = 3;

    static class ItemHolder {
        public TextView content;
        public TextView icon;
        public View parent;
    }

    public AddressAdapter(Context c, ArrayList images) {
        mContext = c;
        mDate = images;
        itemType = Constant.ADDRESS_ADAPTER_TYPE_DEFAULT;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mDefaultAddressLabel = mContext.getString(R.string.default_address_label);
    }

    public AddressAdapter(Context c, ArrayList images, int manageItem) {
        mContext = c;
        mDate = images;
        itemType = manageItem;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mDefaultAddressLabel = mContext.getString(R.string.default_address_label);
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    public int getCount() {
//        Log.i("Taber", "size: " + mImages.size());
        return CollectionUtil.isEmpty(mDate) ? 1 : mDate.size() + 2;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (position == 0) {
            convertView = genCreateAddressView(convertView, parent);
        } else if (position == 1) {
            convertView = genLabelView(convertView, parent);
        } else {
            convertView = genItemView(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            AddressItem item = (AddressItem) mDate.get(position - 2);
            ItemHolder holder = (ItemHolder) tag.get("holder");
            String content = item.getContactorName() + " " + item.getContactorPhone() + "\n";

            if (item.getSelected() == 1) {
                content += mDefaultAddressLabel + item.getAddressName();
                if (itemType == Constant.ADDRESS_ADAPTER_TYPE_MANAGE) {
                    holder.parent.setBackgroundColor(mContext.getResources().getColor(R.color.grey_b));
                    holder.content.setTextColor(mContext.getResources().getColor(R.color.white));
                    holder.icon.setVisibility(View.VISIBLE);
                }
            } else {
                content += item.getAddressName();
                if (itemType == Constant.ADDRESS_ADAPTER_TYPE_MANAGE) {
                    holder.parent.setBackgroundColor(mContext.getResources().getColor(R.color.white));
                    holder.content.setTextColor(mContext.getResources().getColor(R.color.font_color_normal));
                    holder.icon.setVisibility(View.INVISIBLE);
                }
            }
            holder.content.setText(content);
            holder.icon.setText(mContext.getResources().getString(R.string.icon_checkbox_active));

        }
        return convertView;
    }

    private View genCreateAddressView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.address_item_create, parent, false);
            TextView plus = (TextView) convertView.findViewById(R.id.icon);
            TextView right = (TextView) convertView.findViewById(R.id.iconRight);
            plus.setTypeface(Helper.sharedHelper().getIconFont());
            right.setTypeface(Helper.sharedHelper().getIconFont());
            HashMap tag = new HashMap();
            tag.put("type", VIEW_TYPE_CREATE);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != VIEW_TYPE_CREATE) {
                return genCreateAddressView(null, parent);
            }
        }
        return convertView;
    }

    private View genLabelView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.address_item_label, parent, false);
            HashMap tag = new HashMap();
            tag.put("type", VIEW_TYPE_LABEL);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != VIEW_TYPE_LABEL) {
                return genLabelView(null, parent);
            }
        }
        return convertView;
    }

    private View genItemView(View convertView, ViewGroup parent) {
        if (convertView == null) {

            if (itemType == Constant.ADDRESS_ADAPTER_TYPE_DEFAULT) {
                convertView = mInflater.inflate(R.layout.address_item, parent, false);
            } else if (itemType == Constant.ADDRESS_ADAPTER_TYPE_MANAGE) {
                convertView = mInflater.inflate(R.layout.address_manage_item, parent, false);
            }

            ItemHolder holder = new ItemHolder();
            holder.parent = convertView.findViewById(R.id.parent);
            holder.content = (TextView) convertView.findViewById(R.id.textAddressContent);
            holder.icon = (TextView) convertView.findViewById(R.id.textRadioIcon);
            holder.icon.setTypeface(Helper.sharedHelper().getIconFont());
            HashMap tag = new HashMap();
            tag.put("holder", holder);
            tag.put("type", VIEW_TYPE_ITEM);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != VIEW_TYPE_ITEM) {
                return genItemView(null, parent);
            }
        }
        return convertView;
    }
}
