package com.meidalife.shz.activity.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.ServicePropSettingActivity;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.adapter.ServiceGridAdapter;
import com.meidalife.shz.adapter.ServicePropAdapter;
import com.meidalife.shz.adapter.ServicePropRecycleAdapter;
import com.meidalife.shz.rest.model.ServiceCategoryDo;
import com.meidalife.shz.rest.model.ServicePropDo;
import com.meidalife.shz.rest.model.ServicePropValue;
import com.meidalife.shz.rest.model.ServiceRenderDo;
import com.meidalife.shz.rest.model.ServiceSkuPropDo;
import com.meidalife.shz.rest.model.SkuListDo;
import com.meidalife.shz.view.MyGridView;
import com.meidalife.shz.view.OnServicePublishListener;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 发布服务填写服务内容
 * Created by fufeng on 16/3/3.
 */
public class PublishContentFragment extends BaseFragment {
    public static final String EXTRA_SERVICE_CATEGORY = "serviceCategoryName";
    public static final String EXTRA_SECONDARY_SERVICE_CATEGORY = "secondaryCategoryName";

    private static final String LOG_TAG = "PublishContentFragment";

    private int canPickPicCount;
    private int currentPosition = 0;
    private boolean isEditMode = false;

    View rootView;

    @Bind(R.id.categoryLayout)
    ViewGroup categoryLayout;
    @Bind(R.id.categoryName)
    TextView categoryName;
    @Bind(R.id.textServiceTitle)
    TextView textServiceTitle;
    @Bind(R.id.textTitleLimit)
    TextView textTitleLimit;

    @Bind(R.id.textServiceDesc)
    TextView textServiceDesc;
    @Bind(R.id.textDescLimit)
    TextView textDescLimit;

    @Bind(R.id.selectImages)
    MyGridView selectImagesGrid;

    @Bind(R.id.propsLayout)
    ViewGroup propsLayout;
    @Bind(R.id.propListView)
    ListView propListView;
    @Bind(R.id.serviceOptionLayout)
    LinearLayout serviceOptionLayout;

    @Bind(R.id.addOptionView)
    TextView addOptionView;

    private ServiceGridAdapter adapter;
    private OnServicePublishListener onServicePublishListener;
    private ServiceRenderDo serviceRenderDo;
    private ServicePropAdapter servicePropAdapter;
    private ServiceCategoryDo serviceCategoryDo;
    private ServiceCategoryDo.SecondaryCategoryDo secondaryCategoryDo;
    private List<ServicePropDo> props = new ArrayList<>();
    private ArrayList<ServicePropDo> serviceProps = new ArrayList<>();

    public static PublishContentFragment newInstance(Bundle arg) {
        PublishContentFragment fragment = new PublishContentFragment();
        fragment.setArguments(arg);
        return fragment;
    }

    public void setOnServicePublishListener(OnServicePublishListener onServicePublishListener) {
        this.onServicePublishListener = onServicePublishListener;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (null == rootView) {
            rootView = inflater.inflate(R.layout.fragment_publish_content, container, false);
            ButterKnife.bind(this, rootView);
        }

        if (getArguments() != null) {
            renderServiceContent(getArguments());
        }

        initComponent();
        initSelectImagesGrid();
        return rootView;
    }

    private void renderServiceContent(Bundle args) {
        serviceCategoryDo = args.getParcelable(EXTRA_SERVICE_CATEGORY);
        serviceRenderDo = args.getParcelable(Constant.EXTRA_TAG_SERVICE_CONTENT);
        secondaryCategoryDo = args.getParcelable(EXTRA_SECONDARY_SERVICE_CATEGORY);
        isEditMode = args.getBoolean(Constant.EXTRA_TAG_EDIT_MODE);
        if (serviceCategoryDo != null) {
            categoryName.setText("[" + serviceCategoryDo.getCatName() +
                    "-" + secondaryCategoryDo.getCatName() + "]");
        } else if (serviceRenderDo.getStdCat() != null) {
            categoryName.setText(serviceRenderDo.getStdCat().getString("name"));
        }
        if (isEditMode && serviceProps.isEmpty()) {
            serviceProps.addAll(serviceRenderDo.getProps());
        }

        props.clear();
        if (serviceProps == null || serviceProps.isEmpty()) {
            props.addAll(serviceRenderDo.getProps());
        } else {
            props.addAll(serviceProps);
        }

        addOptionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addServiceOption(serviceRenderDo.getSkus().getSkuList().get(0).clone(), true);
            }
        });

        serviceOptionLayout.removeAllViews();
        for (int i = 0; i < serviceRenderDo.getSkus().getSkuList().size(); i++) {
            addServiceOption(serviceRenderDo.getSkus().getSkuList().get(i), false);
        }
        addOptionView.setText("+添加" + serviceRenderDo.getSkus().getSkuTitle());

        if (props != null && !props.isEmpty()) {
            servicePropAdapter = new ServicePropAdapter(getActivity(), props);
            propListView.setAdapter(servicePropAdapter);
            propsLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    if (!isEditMode) {
                        intent.putExtra(Constant.EXTRA_TAG_STD_CATEGORY_ID, secondaryCategoryDo.getCatId());
                        intent.putParcelableArrayListExtra(Constant.EXTRA_TAG_PROP_LIST, serviceProps);
                    } else {
                        intent.putExtra(Constant.EXTRA_TAG_STD_CATEGORY_ID,
                                serviceRenderDo.getStdCat().getString("stdCatId"));
                        intent.putParcelableArrayListExtra(Constant.EXTRA_TAG_PROP_LIST,
                                (ArrayList<? extends Parcelable>) serviceRenderDo.getProps());
                    }

                    intent.putExtra(Constant.EXTRA_TAG_EDIT_MODE, isEditMode);
                    intent.putExtra(Constant.EXTRA_TAG_TITLE, serviceRenderDo.getPropsTitle());
                    intent.setClass(getActivity(), ServicePropSettingActivity.class);
                    startActivityForResult(intent, Constant.REQUEST_CODE_SET_SERVICE_PROP);
                }
            });
        } else {
            propsLayout.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (Activity.RESULT_OK == resultCode && requestCode == Constant.REQUEST_CODE_PICK_PHOTO) {
            Bundle bundle = data.getExtras();
            ArrayList<String> paths = bundle.getStringArrayList("images");
            if (paths != null && paths.size() > 0) {
                for (int i = 0; i < paths.size(); i++) {
                    if (currentPosition < serviceRenderDo.getImages().size() &&
                            TextUtils.isEmpty(serviceRenderDo.getImages().get(currentPosition))) {
                        serviceRenderDo.getImages().set(currentPosition++, paths.get(i));
                        canPickPicCount--;
                    } else {
                        if (serviceRenderDo.getImages().size() < Constant.MAX_IMAGE_LENGTH) {
                            serviceRenderDo.getImages().add(paths.get(i));
                            canPickPicCount--;
                        }
                    }
                }
            }
            if (onServicePublishListener != null) {
                onServicePublishListener.onServiceImageSelected();
            }
            adapter.notifyDataSetChanged();
        } else if (Activity.RESULT_OK == resultCode && requestCode == Constant.REQUEST_CODE_SET_SERVICE_PROP) {
            serviceProps = data.getParcelableArrayListExtra(Constant.EXTRA_TAG_PROP_LIST);
            renderProps();
        }
    }

    private void renderProps() {
        for (ServicePropDo servicePropDo : serviceProps) {
            switch (servicePropDo.getType()) {
                case ServicePropRecycleAdapter.PROP_TYPE_SINGLE_CHOICE: {
                    for (ServicePropValue value : servicePropDo.getValues()) {
                        if (!TextUtils.isEmpty(servicePropDo.getVid())
                                && servicePropDo.getVid().equals(value.getVid())) {
                            servicePropDo.setText(value.getName());
                        }
                    }

                    break;
                }
                case ServicePropRecycleAdapter.PROP_TYPE_MULTI_CHOICE: {
                    servicePropDo.setText("");
                    for (ServicePropValue value : servicePropDo.getValues()) {
                        if (servicePropDo.getVids().contains(value.getVid())) {
                            if (TextUtils.isEmpty(servicePropDo.getText())) {
                                servicePropDo.setText(value.getName());
                            } else {
                                servicePropDo.setText(servicePropDo.getText() + "+" + value.getName());
                            }
                        }
                    }
                    break;
                }
                case ServicePropRecycleAdapter.PROP_TYPE_TEXT: {
                    if (!TextUtils.isEmpty(servicePropDo.getText())) {
                        servicePropDo.setText(servicePropDo.getText());
                    }
                    break;
                }
            }
        }
        servicePropAdapter.setPropList(serviceProps);
        servicePropAdapter.notifyDataSetChanged();
    }

    private void initComponent() {
        textServiceTitle.setText(serviceRenderDo.getTitle());
        textServiceTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                textTitleLimit.setText(String.format("%s/%s", s.length(),
                        getResources().getInteger(R.integer.service_title_max_length)));
            }
        });

        textServiceDesc.setText(serviceRenderDo.getDesc());
        textServiceDesc.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                textDescLimit.setText(String.format("%s/%s", s.length(),
                        getResources().getInteger(R.integer.service_desc_max_length)));
            }
        });

        categoryLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onServicePublishListener != null) {
                    onServicePublishListener.backToCategorySetting();
                }
            }
        });

    }

    private void initSelectImagesGrid() {
        canPickPicCount = Constant.MAX_IMAGE_LENGTH - serviceRenderDo.getImages().size();
        adapter = new ServiceGridAdapter(getActivity(), serviceRenderDo.getImages(),
                Constant.MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_SERVICE);
        selectImagesGrid.setAdapter(adapter);
        adapter.setOnClickListener(new ServiceGridAdapter.OnClickListener() {
            @Override
            public void onAddClick(View v, int position) {
                addImg(position);
            }

            @Override
            public void onEditClick(View v, int position) {
                currentPosition = position;
                addImg(position);
            }

            @Override
            public void onRemoveClick(View v, int position) {
                if (position < serviceRenderDo.getImages().size()) {
                    serviceRenderDo.getImages().set(position, "");
                    canPickPicCount++;
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    void addImg(int position) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", canPickPicCount);
        bundle.putInt("position", position);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, getActivity());
    }

    //添加服务选项
    public void addServiceOption(SkuListDo skuListDo, boolean createNew) {
        ViewGroup optionView = (ViewGroup) LayoutInflater.from(getActivity()).
                inflate(R.layout.view_service_publish_content, serviceOptionLayout, false);
        View deleteIcon = optionView.findViewById(R.id.deleteIcon);
        ViewGroup skuItemsContainer = (ViewGroup) optionView.findViewById(R.id.skuItems);
        optionView.setTag(skuListDo);
        for (ServiceSkuPropDo serviceSkuPropDo : skuListDo.getProps()) {
            View skuItemView = getSkuItemView(optionView, serviceSkuPropDo, createNew);
            skuItemView.setTag(serviceSkuPropDo);
            skuItemsContainer.addView(skuItemView);
        }
        deleteIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewGroup parentView = (ViewGroup) v.getParent().getParent();
                if (parentView != null) {
                    parentView.removeView((ViewGroup) v.getParent());
                    addOptionView.setVisibility(View.VISIBLE);
                }
                if (serviceOptionLayout.getChildCount() == 1) {
                    serviceOptionLayout.getChildAt(0).
                            findViewById(R.id.deleteIcon).setVisibility(View.GONE);
                }
            }
        });
        serviceOptionLayout.addView(optionView);

        for (int i = 0; i < serviceOptionLayout.getChildCount(); i++) {
            serviceOptionLayout.getChildAt(i).findViewById(R.id.deleteIcon).
                    setVisibility(serviceOptionLayout.getChildCount() == 1 ? View.GONE : View.VISIBLE);
        }

        if (serviceOptionLayout.getChildCount() >= serviceRenderDo.getSkus().getMaxSize()) {
            addOptionView.setVisibility(View.GONE);
        }
    }

    @NonNull
    private View getSkuItemView(ViewGroup optionView, ServiceSkuPropDo serviceSkuPropDo, boolean createNew) {
        View skuItemView = LayoutInflater.from(getActivity()).
                inflate(R.layout.item_service_sku, optionView, false);
        TextView skuName = (TextView) skuItemView.findViewById(R.id.skuName);
        skuName.setText(serviceSkuPropDo.getTitle() + "：");
        EditText skuValue = (EditText) skuItemView.findViewById(R.id.skuPropValue);
        switch (serviceSkuPropDo.getType()) {
            case Constant.SKU_INPUT_TYPE_TEXT: {
                skuValue.setInputType(InputType.TYPE_CLASS_TEXT);
                break;
            }
            case Constant.SKU_INPUT_TYPE_FLOAT: {
                skuValue.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                break;
            }
            case Constant.SKU_INPUT_TYPE_INT: {
                skuValue.setInputType(InputType.TYPE_CLASS_NUMBER);
                break;
            }
        }
        if (serviceSkuPropDo.getMaxLength() > 0) {
            final TextView valueLimit = (TextView) skuItemView.findViewById(R.id.valueLimit);
            final int maxLength = serviceSkuPropDo.getMaxLength();
            InputFilter[] filters = {new InputFilter.LengthFilter(maxLength)};
            skuValue.setFilters(filters);
            valueLimit.setText("0/" + maxLength);
            skuValue.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    valueLimit.setText(String.format("%s/%s", s.length(), maxLength));
                }
            });
            valueLimit.setVisibility(View.VISIBLE);
        }

        if (!createNew && !TextUtils.isEmpty(serviceSkuPropDo.getValue())) {
            skuValue.setText(serviceSkuPropDo.getValue());
        } else if (!createNew && !TextUtils.isEmpty(serviceSkuPropDo.getDefaultValue())) {
            skuValue.setText(serviceSkuPropDo.getDefaultValue());
        } else {
            skuValue.setHint(serviceSkuPropDo.getPlaceholder());
        }

        return skuItemView;
    }

    public ServiceRenderDo getServiceRenderDo() {
        //获取标题
        serviceRenderDo.setTitle(textServiceTitle.getText().toString());
        //获取描述
        serviceRenderDo.setDesc(textServiceDesc.getText().toString());
        //获取SKU列表
        List<SkuListDo> skuListDoList = new ArrayList<>();
        for (int i = 0; i < serviceOptionLayout.getChildCount(); i++) {
            View view = serviceOptionLayout.getChildAt(i);
            ViewGroup skuItems = (ViewGroup) view.findViewById(R.id.skuItems);
            SkuListDo skuListDo = new SkuListDo();
            for (int j = 0; j < skuItems.getChildCount(); j++) {
                View skuItemView = skuItems.getChildAt(j);
                if (skuItemView != null) {
                    EditText skuVaule = (EditText) skuItemView.findViewById(R.id.skuPropValue);
                    ServiceSkuPropDo serviceSkuPropDo = (ServiceSkuPropDo) skuItemView.getTag();
                    ServiceSkuPropDo propDo = serviceSkuPropDo.clone();
                    propDo.setValue(skuVaule.getText().toString());
                    skuListDo.getProps().add(propDo);
                }
            }
            skuListDoList.add(skuListDo);
        }
        serviceRenderDo.getSkus().setSkuList(skuListDoList);
        return serviceRenderDo;
    }

    public ArrayList<ServicePropDo> getServiceProps() {
        return serviceProps;
    }

    public void setServiceProps(ArrayList<ServicePropDo> serviceProps) {
        this.serviceProps = serviceProps;
    }
}
