package com.meidalife.shz.adapter;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.wukong.im.Message;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.rest.model.MessageDO;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by taber on 15/6/24.
 */
public class ChatAdapter extends BaseAdapter implements SensorEventListener {

    LayoutInflater mInflater;
    Context mContext;

    String TEXT_MESSAGE = "text";
    String TEXT_MESSAGE_MY = "text_my";
    String IMAGE_MESSAGE = "image";
    String IMAGE_MESSAGE_MY = "image_my";
    String TIME_LABEL = "time";
    String VOICE_MESSAGE = "voice";
    String VOICE_MESSAGE_MY = "voice_my";
    String SERVICE_MESSAGE = "service";
    String SERVICE_MESSAGE_MY = "service_my";
    String ADDRESS_MESSAGE = "address";
    String ADDRESS_MESSAGE_MY = "address_my";
    String REMINDER_MESSAGE = "reminder";
    String REMINDER_MESSAGE_MY = "reminder_my";
    String REWARDS_MESSAGE = "rewards";
    String REWARDS_MESSAGE_MY = "rewards_my";
    int KEY_TYPE = 1 << 26;
    int KEY_HOLDER = 1 << 27;

    private List<MessageDO> mData;
    private MediaPlayer mediaPlayer;
    private SensorManager mManager;
    private AudioManager mAudoManager;
    private ClipboardManager mClipboardManager;
    private ChatHelper chatHelper;

    private MsgClickListener msgClickListener;

    public void setMsgClickListener(MsgClickListener msgClickListener) {
        this.msgClickListener = msgClickListener;
    }

    public ChatAdapter(Context context, List data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
        mClipboardManager = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
        chatHelper = ChatHelper.getInstance(context);
    }

    public void addMessage(MessageDO message) {
        mData.add(message);
        notifyDataSetChanged();
    }

    public void setMessageList(List<MessageDO> messageList) {
        this.mData = messageList;
        notifyDataSetChanged();
    }

    public void addMessageList(List<MessageDO> messageList) {
        this.mData.addAll(messageList);
        notifyDataSetChanged();
    }

    public void headMessageList(List<MessageDO> messageList) {
        this.mData.addAll(0, messageList);
        notifyDataSetChanged();
    }

    public List<MessageDO> getMessageList() {
        return mData;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    private Boolean isMy(MessageDO message) {
        return Helper.sharedHelper().getUserId().equals(message.getSendUserId());
    }

    private void loadAvatar(SimpleDraweeView avatar, String url) {
        ViewGroup.LayoutParams avatarLayoutParams = avatar.getLayoutParams();
        avatar.setImageURI(Uri.parse(ImgUtil.getCDNUrlWithWidth(url, avatarLayoutParams.width)));
    }

    public void release() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        }

        clearProximitySensor();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        final MessageDO messageDO = mData.get(position);
        final String senderAvatar = messageDO.getSendUserAvatar();
        final String sendUserId = messageDO.getSendUserId();

        /*
        判断消息是否对方发送，若未读，调接口设置消息为已读  m.unReadCount()>=1 仅针对发送者
        */
        Message m = messageDO.getMessage();
        if (m != null && !Helper.sharedHelper().getUserId().equals(m.senderId())) {
            m.read();
        }

        /*
        文本类型
         */
        if (messageDO.getType() == MessageDO.MESSAGE_TYPE_TEXT) {
            convertView = getTextMessageView(convertView, isMy(messageDO));
            TextMessageHolder holder = (TextMessageHolder) convertView.getTag(KEY_HOLDER);
            holder.content.setText(chatHelper.getExpressionSpanText(messageDO.getText(), 20));
            loadAvatar(holder.avatar, senderAvatar);

            if (holder.status != null && messageDO.getMessage() != null) {
                holder.status.setText(messageDO.getMessage().unReadCount() <= 0 ? "已读" : "未读");
            }
            if (holder.loading != null) {
                holder.loading.setVisibility(messageDO.getLoading() ? View.VISIBLE : View.GONE);
            }
            holder.avatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    msgClickListener.avatarOnClickListener(sendUserId);
                }
            });

            convertView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    View contextMenu = mInflater.inflate(R.layout.message_delete_dialog, null);
                    final AlertDialog dialog = new AlertDialog.Builder(mContext).create();
                    dialog.setView(contextMenu, 0, 0, 0, 0);
                    dialog.show();
                    TextView deleteTv = (TextView) contextMenu.findViewById(R.id.singleContextMenu);
                    deleteTv.setText(R.string.copy);
                    deleteTv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            ClipData clipData = ClipData.newPlainText(null, messageDO.getText());
                            mClipboardManager.setPrimaryClip(clipData);
                        }
                    });
                    return true;
                }
            });
        }
        /*
        图片类型
         */
        else if (messageDO.getType() == MessageDO.MESSAGE_TYPE_IMG) {

            if (isMy(messageDO)) {
                convertView = getImageMessageView(convertView, true);
            } else {
                convertView = getImageMessageView(convertView, false);
            }

            ImageMessageHolder holder = (ImageMessageHolder) convertView.getTag(KEY_HOLDER);
            final String imgPath = messageDO.getImage();
            int imgWidth = (int) Helper.convertDpToPixel(150, mContext);
            int imgHeight = imgWidth;
            if (imgPath.startsWith("http://")) {
                String imgResizePath = imgPath;
                if (imgPath.contains("laiwang.com")) {    // 说明是来往数据，可增加缩放
                    String[] info = imgPath.split("_");
                    if (info.length == 3) {
                        float width = Float.parseFloat(info[1]);
                        float height = Float.parseFloat(info[2].split("\\.")[0]);
                        imgHeight = (int) ((height * imgWidth) / width);
                    }
                    imgResizePath = imgPath + "_" + imgWidth + "x" + imgHeight + ".jpg";
                } else {
                    imgResizePath = imgPath;
                }
                ViewGroup.LayoutParams layout = holder.content.getLayoutParams();
                layout.width = imgWidth;
                layout.height = imgHeight;
                holder.content.setLayoutParams(layout);
                holder.content.setImageURI(Uri.parse(imgResizePath));
            } else {
                File imgFile = new File(imgPath);
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(imgPath, options);
                float width = options.outWidth;
                float height = options.outHeight;
                imgHeight = (int) ((height * imgWidth) / width);
                ViewGroup.LayoutParams layout = holder.content.getLayoutParams();
                layout.width = imgWidth;
                layout.height = imgHeight;
                holder.content.setLayoutParams(layout);
                holder.content.setImageURI(Uri.fromFile(imgFile));
            }
            loadAvatar(holder.avatar, senderAvatar);

            if (holder.status != null) {
                holder.status.setText(messageDO.getMessage().unReadCount() <= 0 ? "已读" : "未读");
            }
            if (holder.loading != null) {
                holder.loading.setVisibility(messageDO.getLoading() ? View.VISIBLE : View.GONE);
            }
            holder.content.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openImagesBrowser(imgPath);
                }
            });
            holder.content.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    return false;  // todo 增加保存图片
                }
            });
            holder.avatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    msgClickListener.avatarOnClickListener(sendUserId);
                }
            });
        }
        /*
        显示时间分割线
         */
        else if (messageDO.getType() == MessageDO.MESSAGE_TYPE_TIME) {
            convertView = getTimeMessageView(convertView);
            TimeLabelHolder holder = (TimeLabelHolder) convertView.getTag(KEY_HOLDER);
            holder.time.setText(messageDO.getText());
        }
        /*
         * 地址
         */
        else if (messageDO.getType() == MessageDO.MESSAGE_TYPE_ADDRESS) {

            if (isMy(messageDO)) {
                convertView = getAddressMessageView(convertView, true);
            } else {
                convertView = getAddressMessageView(convertView, false);
            }
            AddressMessageHolder holder = (AddressMessageHolder) convertView.getTag(KEY_HOLDER);
            loadAvatar(holder.avatar, senderAvatar);
            int height = (int) Helper.convertDpToPixel(130, mContext);
            int width = (int) Helper.convertDpToPixel(220, mContext);
            ;
            Map<String, String> dataMap = messageDO.getExt();
            String gps = dataMap.get("coordinate");
            String url = "http://api.map.baidu.com/staticimage?width=" + width + "&height=" + height + "&markers=" + gps + "&zoom=18&markerStyles=l,,0xff5e45";
            holder.addressImg.setImageURI(Uri.parse(url));
            String address = dataMap.get("name");
            holder.addressLabel.setText(address);

            holder.avatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    msgClickListener.avatarOnClickListener(sendUserId);
                }
            });

            convertView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    msgClickListener.convertViewOnClickListener(messageDO);
                }
            });
        }
        /*
        语音消息
         */
        else if (messageDO.getType() == MessageDO.MESSAGE_TYPE_VOICE) {
            if (isMy(messageDO)) {
                convertView = getVoiceMessageView(convertView, true);
            } else {
                convertView = getVoiceMessageView(convertView, false);
            }
            VoiceMessageHolder holder = (VoiceMessageHolder) convertView.getTag(KEY_HOLDER);
            holder.time.setText(messageDO.getVoiceTime() + "''");
            final String voiceUrl = messageDO.getVoiceUrl();
            ViewGroup.LayoutParams params = holder.content.getLayoutParams();
            int width = (int) Helper.convertDpToPixel((messageDO.getVoiceTime() * 10 + 55), mContext);
            int maxWidth = holder.content.getResources().getDisplayMetrics().widthPixels - (int) Helper.convertDpToPixel(150, mContext);
            params.width = Math.min(width, maxWidth);
            params.height = (int) Helper.convertDpToPixel(40, mContext);
            holder.content.setLayoutParams(params);
            loadAvatar(holder.avatar, senderAvatar);

            if (holder.status != null) {
                holder.status.setText(messageDO.getMessage().unReadCount() <= 0 ? "已读" : "未读");
            }
            if (holder.loading != null) {
                holder.loading.setVisibility(messageDO.getLoading() ? View.VISIBLE : View.GONE);
            }

            holder.avatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    msgClickListener.avatarOnClickListener(sendUserId);
                }
            });
            // 语音点击后播放
            holder.content.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                            releaseMediaPlayer();
                        } else {
                            mediaPlayer = new MediaPlayer();

                            initProximitySensor(mContext);
                            if (mAudoManager != null && mAudoManager.isWiredHeadsetOn()) {
                                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                            } else {
                                mediaPlayer.setAudioStreamType(AudioManager.STREAM_VOICE_CALL);
                            }
                            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                @Override
                                public void onCompletion(MediaPlayer mp) {
                                    releaseMediaPlayer();
                                    clearProximitySensor();
                                }
                            });
                            mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                                @Override
                                public boolean onError(MediaPlayer mp, int what, int extra) {
                                    releaseMediaPlayer();
                                    clearProximitySensor();
                                    return false;
                                }
                            });
                            String path = voiceUrl;
                            if (!voiceUrl.startsWith("http://"))  //若本地文件，增加前缀
                                path = "file:///" + voiceUrl;
                            mediaPlayer.setDataSource(path);
                            mediaPlayer.prepare();
                            mediaPlayer.start();
                        }
                    } catch (Exception e) {
                        MessageUtils.showToastCenter("播放语音失败, " + e.getClass().getName());
                    }
                }
            });
        }

        /*
        服务类型
         */
        else if (messageDO.getType() == MessageDO.MESSAGE_TYPE_SERVICE) {
            convertView = getServiceMessageView(convertView, isMy(messageDO));
            ServiceMessageHolder holder = (ServiceMessageHolder) convertView.getTag(KEY_HOLDER);
            loadAvatar(holder.avatar, senderAvatar);
            final Map<String, String> data = messageDO.getExt();
            holder.itemImage.setImageURI(Uri.parse(data.get("image")));
            holder.itemTitle.setText("我能·" + data.get("title"));
            holder.itemPrice.setText(data.get("price"));

            try {
                String typeLabel = ServicesAdapter.typeToLabel(Integer.parseInt(data.get("serviceType")), data.get("cityName"));
                holder.itemType.setText(typeLabel);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }

            if ("1".equals(data.get("pointSupport"))) {
                holder.itemMcoin.setVisibility(View.VISIBLE);
            } else {
                holder.itemMcoin.setVisibility(View.GONE);
            }

            if (holder.status != null) {
                holder.status.setText(messageDO.getMessage().unReadCount() <= 0 ? "已读" : "未读");
            }
            if (holder.loading != null) {
                holder.loading.setVisibility(messageDO.getLoading() ? View.VISIBLE : View.GONE);
            }

            holder.avatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    msgClickListener.avatarOnClickListener(sendUserId);
                }
            });
            holder.itemGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    msgClickListener.itemOnClickListener(data.get("itemId"));
                }
            });
        } else if (messageDO.getType() == MessageDO.MESSAGE_TYPE_REMINDER) {
            convertView = inflateReminderMessageView(m, convertView, messageDO);
        } else if (messageDO.getType() == MessageDO.MESSAGE_TYPE_BONUS) {
            convertView = inflateRewardsView(convertView, messageDO);
        }

        return convertView;
    }

    private View getTextMessageView(View convertView, boolean isMy) {
        if (convertView != null && convertView.getTag() != null && convertView.getTag(KEY_TYPE) != null) {
            String type = (String) convertView.getTag(KEY_TYPE);
            if (isMy && TEXT_MESSAGE_MY.equals(type)) {
                return convertView;
            } else if (!isMy && TEXT_MESSAGE.equals(type)) {
                return convertView;
            }
        }
        if (isMy) {
            convertView = mInflater.inflate(R.layout.message_type_text_my, null);
            convertView.setTag(KEY_TYPE, TEXT_MESSAGE_MY);
        } else {
            convertView = mInflater.inflate(R.layout.message_type_text, null);
            convertView.setTag(KEY_TYPE, TEXT_MESSAGE);
        }
        TextMessageHolder holder = new TextMessageHolder();
        holder.avatar = (SimpleDraweeView) convertView.findViewById(R.id.avatar);
        holder.content = (TextView) convertView.findViewById(R.id.content);
        if (isMy) {
            holder.status = (TextView) convertView.findViewById(R.id.status);
            holder.loading = (ProgressBar) convertView.findViewById(R.id.loading);
            holder.retry = (Button) convertView.findViewById(R.id.retry);
        }
        convertView.setTag(KEY_HOLDER, holder);
        return convertView;
    }

    private View getImageMessageView(View convertView, boolean isMy) {
        if (convertView != null && convertView.getTag() != null && convertView.getTag(KEY_TYPE) != null) {
            String type = (String) convertView.getTag(KEY_TYPE);
            if (isMy && IMAGE_MESSAGE_MY.equals(type)) {
                return convertView;
            } else if (!isMy && IMAGE_MESSAGE.equals(type)) {
                return convertView;
            }
        }
        if (isMy) {
            convertView = mInflater.inflate(R.layout.message_type_image_my, null);
            convertView.setTag(KEY_TYPE, IMAGE_MESSAGE_MY);
        } else {
            convertView = mInflater.inflate(R.layout.message_type_image, null);
            convertView.setTag(KEY_TYPE, IMAGE_MESSAGE);
        }
        ImageMessageHolder holder = new ImageMessageHolder();
        holder.avatar = (SimpleDraweeView) convertView.findViewById(R.id.avatar);
        holder.content = (SimpleDraweeView) convertView.findViewById(R.id.content);
        if (isMy) {
            holder.status = (TextView) convertView.findViewById(R.id.status);
            holder.loading = (ProgressBar) convertView.findViewById(R.id.loading);
            holder.retry = (Button) convertView.findViewById(R.id.retry);
        }
        convertView.setTag(KEY_HOLDER, holder);
        return convertView;
    }

    private View getTimeMessageView(View convertView) {
        if (convertView != null &&
                convertView.getTag() != null && convertView.getTag(KEY_TYPE) != null && !TIME_LABEL.equals(convertView.getTag(KEY_TYPE))) {
            return convertView;
        }
        convertView = mInflater.inflate(R.layout.message_type_time, null);
        TimeLabelHolder holder = new TimeLabelHolder();
        holder.time = (TextView) convertView.findViewById(R.id.msg_time_value);
        convertView.setTag(KEY_TYPE, TIME_LABEL);
        convertView.setTag(KEY_HOLDER, holder);
        return convertView;
    }

    private View getVoiceMessageView(View convertView, boolean isMy) {
        if (convertView != null && convertView.getTag() != null && convertView.getTag(KEY_TYPE) != null) {
            String type = (String) convertView.getTag(KEY_TYPE);
            if (isMy && VOICE_MESSAGE_MY.equals(type)) {
                return convertView;
            } else if (!isMy && VOICE_MESSAGE.equals(type)) {
                return convertView;
            }
        }
        if (isMy) {
            convertView = mInflater.inflate(R.layout.message_type_voice_my, null);
            convertView.setTag(KEY_TYPE, VOICE_MESSAGE_MY);
        } else {
            convertView = mInflater.inflate(R.layout.message_type_voice, null);
            convertView.setTag(KEY_TYPE, VOICE_MESSAGE);
        }
        VoiceMessageHolder holder = new VoiceMessageHolder();
        holder.avatar = (SimpleDraweeView) convertView.findViewById(R.id.avatar);
        holder.content = (TextView) convertView.findViewById(R.id.content);
        holder.time = (TextView) convertView.findViewById(R.id.time);
        if (isMy) {
            holder.status = (TextView) convertView.findViewById(R.id.status);
            holder.loading = (ProgressBar) convertView.findViewById(R.id.loading);
            holder.retry = (Button) convertView.findViewById(R.id.retry);
        }
        convertView.setTag(KEY_HOLDER, holder);
        return convertView;
    }

    private View getServiceMessageView(View convertView, boolean isMy) {
        if (convertView != null && convertView.getTag() != null && convertView.getTag(KEY_TYPE) != null) {
            String type = (String) convertView.getTag(KEY_TYPE);
            if (isMy && SERVICE_MESSAGE_MY.equals(type)) {
                return convertView;
            } else if (!isMy && SERVICE_MESSAGE.equals(type)) {
                return convertView;
            }
        }
        if (isMy) {
            convertView = mInflater.inflate(R.layout.message_type_service_my, null);
            convertView.setTag(KEY_TYPE, SERVICE_MESSAGE_MY);
        } else {
            convertView = mInflater.inflate(R.layout.message_type_service, null);
            convertView.setTag(KEY_TYPE, SERVICE_MESSAGE);
        }
        ServiceMessageHolder holder = new ServiceMessageHolder();
        holder.avatar = (SimpleDraweeView) convertView.findViewById(R.id.avatar);
        holder.itemGroup = convertView.findViewById(R.id.itemGroup);
        holder.itemTitle = (TextView) convertView.findViewById(R.id.item_title);
        holder.itemImage = (SimpleDraweeView) convertView.findViewById(R.id.item_image);
        holder.itemPrice = (TextView) convertView.findViewById(R.id.item_price);
        holder.itemType = (TextView) convertView.findViewById(R.id.item_type);
        holder.itemMcoin = (TextView) convertView.findViewById(R.id.item_mcoin);
        if (isMy) {
            holder.status = (TextView) convertView.findViewById(R.id.status);
            holder.loading = (ProgressBar) convertView.findViewById(R.id.loading);
            holder.retry = (Button) convertView.findViewById(R.id.retry);
        }
        convertView.setTag(KEY_HOLDER, holder);
        return convertView;
    }

    private View getAddressMessageView(View convertView, boolean isMy) {
        if (convertView != null && convertView.getTag() != null && convertView.getTag(KEY_TYPE) != null) {
            String type = (String) convertView.getTag(KEY_TYPE);
            if (isMy && ADDRESS_MESSAGE_MY.equals(type)) {
                return convertView;
            } else if (!isMy && ADDRESS_MESSAGE.equals(type)) {
                return convertView;
            }
        }
        if (isMy) {
            convertView = mInflater.inflate(R.layout.message_type_address_my, null);
            convertView.setTag(KEY_TYPE, ADDRESS_MESSAGE_MY);
        } else {
            convertView = mInflater.inflate(R.layout.message_type_address, null);
            convertView.setTag(KEY_TYPE, ADDRESS_MESSAGE);
        }
        AddressMessageHolder holder = new AddressMessageHolder();
        holder.avatar = (SimpleDraweeView) convertView.findViewById(R.id.avatar);
        holder.addressImg = (SimpleDraweeView) convertView.findViewById(R.id.addressImg);
        holder.addressLabel = (TextView) convertView.findViewById(R.id.addressLabel);
        if (isMy) {
            holder.status = (TextView) convertView.findViewById(R.id.status);
            holder.loading = (ProgressBar) convertView.findViewById(R.id.loading);
            holder.retry = (Button) convertView.findViewById(R.id.retry);
        }
        convertView.setTag(KEY_HOLDER, holder);
        return convertView;
    }

    private View inflateReminderMessageView(Message message, View convertView, MessageDO messageDO) {
        boolean isMy = isMy(messageDO);
        if (convertView != null && convertView.getTag() != null && convertView.getTag(KEY_TYPE) != null) {
            String type = (String) convertView.getTag(KEY_TYPE);
            if (isMy && REMINDER_MESSAGE_MY.equals(type)) {
                return convertView;
            } else if (!isMy && REMINDER_MESSAGE.equals(type)) {
                return convertView;
            }
        }

        convertView = mInflater.inflate(R.layout.message_type_remind, null);
        if (isMy) {
            convertView.setTag(KEY_TYPE, REMINDER_MESSAGE_MY);
        } else {
            convertView.setTag(KEY_TYPE, REMINDER_MESSAGE);
        }

        ReminderMessageHolder holder = new ReminderMessageHolder();
        holder.reminderText = (TextView) convertView.findViewById(R.id.remindMessage);
        convertView.setTag(KEY_HOLDER, holder);

        int reminderType = messageDO.getCustomType();
        try {
            if (reminderType == 0) {
                reminderType = Integer.valueOf(messageDO.getExt().get("type"));
            }

            holder.reminderText.setText(getDefaultReminderText(reminderType, message, isMy));
        } catch (Exception e) {
            e.printStackTrace();
            holder.reminderText.setText(mContext.getString(R.string.unknown_remind_type));
        }

        return convertView;
    }

    private String getDefaultReminderText(int type, Message message, boolean isOwner) {
        switch (type) {
            case 1://兼容旧版本稍后删除
            case MessageDO.REMIND_MESSAGE_TYPE_REMINDER: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_reminder_for_owner)
                        : mContext.getResources().getString(R.string.reminder_message_reminder);
            }
            case 2://兼容旧版本稍后删除
            case MessageDO.REMIND_MESSAGE_TYPE_ORDER: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_order_for_owner)
                        : mContext.getResources().getString(R.string.reminder_message_order);
            }
            case 3://兼容旧版本稍后删除
            case MessageDO.REMIND_MESSAGE_TYPE_ORDER_RECEIVE: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_order_receive_for_owner)
                        : mContext.getResources().getString(R.string.reminder_message_order_receive);
            }
            case 4://兼容旧版本稍后删除
            case MessageDO.REMIND_MESSAGE_TYPE_REJECT: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_reject_for_seller)
                        : mContext.getResources().getString(R.string.reminder_message_reject_for_buyer);
            }
            case 5://兼容旧版本稍后删除
            case MessageDO.REMIND_MESSAGE_TYPE_BLOCK: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_block_for_sender)
                        : mContext.getResources().getString(R.string.reminder_message_block_for_receiver);
            }
            case 6://兼容旧版本稍后删除
            case MessageDO.REMIND_MESSAGE_TYPE_UNBLOCK: {
                return isOwner ? mContext.getResources().getString(R.string.reminder_message_unblock_for_sender)
                        : mContext.getResources().getString(R.string.reminder_message_unblock_for_receiver);
            }
            case MessageDO.REMIND_MESSAGE_TYPE_NOTICE: {
                if (null != message && !TextUtils.isEmpty(message.extension("text"))) {
                    return message.extension("text");
                }
            }
            default:
        }
        return mContext.getResources().getString(R.string.unknown_remind_type) + ":" + String.valueOf(type);
    }

    private View inflateRewardsView(View convertView, final MessageDO messageDO) {
        final boolean isMy = isMy(messageDO);
        if (convertView != null && convertView.getTag() != null && convertView.getTag(KEY_TYPE) != null) {
            String type = (String) convertView.getTag(KEY_TYPE);
            if (isMy && REWARDS_MESSAGE_MY.equals(type)) {
                return convertView;
            } else if (!isMy && REWARDS_MESSAGE.equals(type)) {
                return convertView;
            }
        }

        if (isMy) {
            convertView = mInflater.inflate(R.layout.message_type_reward_my, null);
            convertView.setTag(KEY_TYPE, REWARDS_MESSAGE_MY);
        } else {
            convertView = mInflater.inflate(R.layout.message_type_reward, null);
            convertView.setTag(KEY_TYPE, REWARDS_MESSAGE);
        }

        RewardsMessageHolder holder = new RewardsMessageHolder();
        holder.rewardsDesc = (TextView) convertView.findViewById(R.id.rewardsDesc);
        holder.rewardsDesc.setText(messageDO.getExt().get("amountDesc"));
        holder.checkRewards = (TextView) convertView.findViewById(R.id.checkRewards);
        holder.avatar = (SimpleDraweeView) convertView.findViewById(R.id.avatar);
        holder.rewardsLayout = (ViewGroup) convertView.findViewById(R.id.rewardsLayout);
        loadAvatar(holder.avatar, messageDO.getSendUserAvatar());
        convertView.setTag(KEY_HOLDER, holder);

        holder.rewardsLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle params = new Bundle();
                params.putBoolean("showResult", true);

                params.putString("owner", messageDO.getSenderName());
                params.putString("avatar", messageDO.getSendUserAvatar());
                params.putString("amount", messageDO.getExt().get("amount"));
                params.putString("rewardsDesc", messageDO.getExt().get("amountDesc"));
                Router.sharedRouter().open("rewards", params);
            }
        });

        return convertView;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            if (event.values[0] < event.sensor.getMaximumRange()) {
                shutdownSpeaker();
            } else {
                openSpeaker();
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        //do nothing
    }

    private void initProximitySensor(Context context) {
        mManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        mAudoManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (null != mManager) {
            mManager.registerListener(this,
                    mManager.getDefaultSensor(Sensor.TYPE_PROXIMITY),
                    SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    private void releaseMediaPlayer() {
        try {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void clearProximitySensor() {
        if (mManager != null) {
            mManager.unregisterListener(this);
        }
    }

    private void openSpeaker() {
        try {
            if (mAudoManager != null && !mAudoManager.isWiredHeadsetOn()) {
                mAudoManager.setSpeakerphoneOn(true);
                mAudoManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                        mAudoManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL),
                        AudioManager.STREAM_VOICE_CALL);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void shutdownSpeaker() {
        try {
            if (mAudoManager != null && !mAudoManager.isWiredHeadsetOn()) {
                mAudoManager.setSpeakerphoneOn(false);
                mAudoManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                        mAudoManager.getStreamVolume(AudioManager.STREAM_VOICE_CALL),
                        AudioManager.STREAM_VOICE_CALL);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static class TextMessageHolder {
        public SimpleDraweeView avatar;
        public TextView content;
        public TextView status;
        public ProgressBar loading;
        public Button retry;
    }

    static class ImageMessageHolder {
        public SimpleDraweeView avatar;
        public SimpleDraweeView content;
        public TextView status;
        public ProgressBar loading;
        public Button retry;
    }

    static class TimeLabelHolder {
        public TextView time;
    }

    static class VoiceMessageHolder {
        public SimpleDraweeView avatar;
        public TextView content;
        public TextView time;
        public TextView status;
        public ProgressBar loading;
        public Button retry;
    }

    static class ServiceMessageHolder {
        public SimpleDraweeView avatar;
        public View itemGroup;
        public TextView itemTitle;
        public TextView itemPrice;
        public TextView itemType;
        public TextView itemMcoin;
        public SimpleDraweeView itemImage;
        public TextView status;
        public ProgressBar loading;
        public Button retry;
    }

    static class AddressMessageHolder {
        public SimpleDraweeView avatar;
        public SimpleDraweeView addressImg;
        public TextView addressLabel;
        public TextView status;
        public ProgressBar loading;
        public Button retry;
    }

    static class ReminderMessageHolder {
        public TextView reminderText;
    }

    static class RewardsMessageHolder {
        public ViewGroup rewardsLayout;
        public SimpleDraweeView avatar;
        public TextView rewardsDesc;
        public TextView checkRewards;
    }

    private void openImagesBrowser(String selectedUrl) {
        ArrayList<String> images = new ArrayList<String>();
        int index = 0;
        for (int i = 0; i < mData.size(); i++) {
            MessageDO messageDO = mData.get(i);
            String imgUrl = messageDO.getImage();
            if (!StrUtil.isEmpty(imgUrl)) {
                images.add(imgUrl);
                if (imgUrl.equals(selectedUrl)) {
                    index = images.size() - 1;
                }
            }
        }
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("photos", images);
        bundle.putInt("index", index);
        Router.sharedRouter().open("imageBrowser", bundle);
    }

    public interface MsgClickListener {
        public void avatarOnClickListener(String sendUserId);

        public void itemOnClickListener(String itemId);

        public void convertViewOnClickListener(MessageDO msg);
    }
}
