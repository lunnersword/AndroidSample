package com.meidalife.shz.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by taber on 15/8/23.
 */
public class ServiceManageAdapter extends BaseAdapter {

    private static final int TYPE_COUNT = 1;

    LayoutInflater mInflater;
    Context mContext;
    ArrayList<ServiceItem> mData;

    private IServiceStatusListener serviceStatusListener;

    public void setServiceStatusListener(IServiceStatusListener serviceStatusListener) {
        this.serviceStatusListener = serviceStatusListener;
    }

    static class ViewHolder {
        @Bind(R.id.textTime)
        TextView textTime;
        @Bind(R.id.textTag)
        TextView textTag;
        @Bind(R.id.hotPeopleLogo)
        View hotPeopleLogo;
        @Bind(R.id.textType)
        TextView textType;
        @Bind(R.id.promotionPrice)
        TextView promotionPrice;

        @Bind(R.id.textEdit)
        TextView textEdit;
        @Bind(R.id.textDelete)
        TextView textDelete;
        @Bind(R.id.imageItem)
        SimpleDraweeView imageItem;

        @Bind(R.id.textBeginSell)
        TextView mTextBeginSell;
        @Bind(R.id.textStopSell)
        TextView mTextStopSell;

        @Bind(R.id.bookPrice)
        TextView bookPrice;
        @Bind(R.id.oriPrice)
        TextView oriPrice;
        @Bind(R.id.promotionNum)
        TextView promotionNum;

        @Bind(R.id.sellCount)
        TextView sellCount;
        @Bind(R.id.visitorNum)
        TextView visitorNum;
        @Bind(R.id.catName)
        TextView catName;

        @Bind(R.id.detail_judge_star_icon_group)
        ViewGroup starGroup;

        @Bind(R.id.likeCountContainer)
        View likeCountContainer;
        @Bind(R.id.likeCount)
        TextView likeCount;
        @Bind(R.id.orderCountContainer)
        View orderCountContainer;
        @Bind(R.id.orderCount)
        TextView orderCount;

        @Bind(R.id.saleOffLogo)
        View saleOffLogo;


        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }

    public ServiceManageAdapter(Context context, ArrayList<ServiceItem> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    public void addAll(ArrayList<ServiceItem> items) {
        mData.addAll(items);
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public ServiceItem getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ServiceItem item = mData.get(position);
        final String itemId = item.getItemId();
        final String likeNum = item.getLikeCount();
        final String sellNum = item.getSellCount();
//        final String geziFeeRateUrl = item.getGeziFeeRateUrl();
        convertView = genViewHolder(convertView, parent);
        ViewHolder holder = (ViewHolder) convertView.getTag();

        Date date = new Date(item.getUpdateTime());
        SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        holder.textTime.setText(sdformat.format(date));

        //显示所属类目
        if (TextUtils.isEmpty(item.getStdCatName())) {
            holder.catName.setVisibility(View.GONE);
        } else {
            holder.catName.setVisibility(View.VISIBLE);
            holder.catName.setText(String.format(mContext.getResources().getString(R.string.text_service_publish_category), item.getStdCatName()));
//            holder.catName.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (TextUtils.isEmpty(geziFeeRateUrl) || !geziFeeRateUrl.startsWith("http://"))
//                        return;
//                    Bundle bundle = new Bundle();
//                    bundle.putString("url", geziFeeRateUrl);
//                    Router.sharedRouter().open("web", bundle);
//                }
//            });
        }


        if (TextUtils.isEmpty(item.getEarnest())) {
            holder.bookPrice.setVisibility(View.GONE);
        } else {
            holder.bookPrice.setText("订金：" + item.getEarnest());
            holder.bookPrice.setVisibility(View.VISIBLE);
        }

        if (TextUtils.isEmpty(item.getPrice())) {
            holder.oriPrice.setVisibility(View.GONE);
        } else {
            holder.oriPrice.setText("价格：" + item.getPrice());
            holder.oriPrice.setVisibility(View.VISIBLE);
        }

        //显示促销价格
        String promotionStr = item.getPromotionPrice();
        if (TextUtils.isEmpty(promotionStr)) {
            holder.promotionPrice.setVisibility(View.GONE);
        } else {
            int indexF = promotionStr.indexOf("/");
            if (indexF > 0) {
                promotionStr = promotionStr.substring(0, indexF);
            }
            holder.promotionPrice.setText(String.format("折扣价：%s", promotionStr));
            holder.promotionPrice.setVisibility(View.VISIBLE);
            holder.oriPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
        }
        //显示剩余数量
        if (item.getQuantity() > 0) {
            holder.promotionNum.setText(String.format("库存：%s", item.getQuantity()));
            holder.promotionNum.setVisibility(View.VISIBLE);
        } else {
            holder.promotionNum.setText("");
            holder.promotionNum.setVisibility(View.GONE);
        }

        holder.sellCount.setText(String.format("销量：%s", item.getSellCount() != null ? item.getSellCount() : 0));
        holder.visitorNum.setText(String.format("访客量：%s", item.getViewCount() != null ? item.getViewCount() : 0));

        holder.textTag.setText(mContext.getResources().getString(R.string.label_i_can) + " " + item.getTag());

        Uri imageUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getImages().get(0), holder.imageItem.getLayoutParams().width));
        holder.imageItem.setImageURI(imageUri);

        boolean verifyFail = item.getStatus() == 2 && Helper.sharedHelper().hasToken() &&
                Helper.sharedHelper().getUserId().equals(item.getUser() != null ? item.getUser().getUserId() : "") ? true : false;
        if (verifyFail) {
            holder.textType.setText("审核未通过");
        } else {
            switch (item.getServiceType()) {
                case 1:
                    holder.textType.setText("上门");
                    break;
                case 2:
                    holder.textType.setText("到店");
                    break;
                case 3:
                    holder.textType.setText("线上");
                    break;
                case 4:
                    holder.textType.setText("邮寄");
                    break;
            }
        }

        if (item.getStatus() == 3) {
            holder.saleOffLogo.setVisibility(View.VISIBLE);
        } else {
            holder.saleOffLogo.setVisibility(View.GONE);
        }

        // 评分
        View starsView = mInflater.inflate(R.layout.activity_service_detail_stars, null);
        View contentView = starsView.findViewById(R.id.contentView);

        ViewGroup.LayoutParams params = contentView.getLayoutParams();
        params.height = (int) Helper.convertDpToPixel(20, mContext);
        contentView.setLayoutParams(params);
        Double grade;
        if (item.getGrade() != Float.MAX_VALUE) {
            grade = item.getGrade();
        } else {
            grade = 5.0;
        }

        View starsRed = starsView.findViewById(R.id.star_red_group);
        starsRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, mContext) * grade / 5);
        starsRed.getLayoutParams().height = (int) Helper.convertDpToPixel(20, mContext);
        holder.starGroup.removeAllViews();
        holder.starGroup.addView(starsView);

        holder.likeCount.setText(String.format("收藏用户(%s)", likeNum));
        holder.orderCount.setText(String.format("约单历史(%s)", sellNum));

        if (item.getStatus() == 1) {
            //服务处于上架状态

            holder.mTextStopSell.setVisibility(View.VISIBLE);
            holder.mTextBeginSell.setVisibility(View.GONE);
        } else if (item.getStatus() == 3) {
            //服务处于下架状态

            holder.mTextStopSell.setVisibility(View.GONE);
            holder.mTextBeginSell.setVisibility(View.VISIBLE);
        } else if (item.getStatus() == 2) {
            //status=2 审核未通过情况下 隐藏上头条和下架

            holder.mTextStopSell.setVisibility(View.GONE);
            holder.mTextBeginSell.setVisibility(View.GONE);
        } else {
            //status=0 为审核状态  方便测试 需要产品定规则

            holder.mTextStopSell.setVisibility(View.VISIBLE);
            holder.mTextBeginSell.setVisibility(View.GONE);
        }

        holder.textEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("publish/" + itemId);
            }
        });

        holder.textDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceStatusListener.remove(itemId);
            }
        });

        //点击下架 调用下架接口
        holder.mTextStopSell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceStatusListener.downShelf(itemId);
            }
        });

        //点击上架 调用上架接口
        holder.mTextBeginSell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceStatusListener.upShelf(itemId);
            }
        });

        holder.likeCountContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceStatusListener.openLikeCount(Integer.parseInt(likeNum), itemId);
            }
        });

        holder.orderCountContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceStatusListener.openOrderCount(Integer.parseInt(sellNum), itemId);
            }
        });

        return convertView;
    }

    private View genViewHolder(View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_service_manage, parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            if (holder == null) {
                return genViewHolder(null, parent);
            }
        }

        return convertView;
    }


    public interface IServiceStatusListener {


        //收藏人数
        public void openLikeCount(int likeNum, String itemId);

        //约单总数
        public void openOrderCount(int sellNum, String itemId);

        //上头条
        public void touch(String itemId);

        //删除
        public void remove(String itemId);

        //下架
        public void downShelf(String itemId);

        //上架
        public void upShelf(String itemId);

    }
}
