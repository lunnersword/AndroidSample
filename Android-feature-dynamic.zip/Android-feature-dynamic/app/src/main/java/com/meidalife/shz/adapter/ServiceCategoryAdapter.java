package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServiceCategoryDo;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by fufeng on 16/3/6.
 */
public class ServiceCategoryAdapter extends BaseAdapter {
    private Context context;
    private List<ServiceCategoryDo> serviceCategoryList;
    private LayoutInflater mInflater;
    private View.OnClickListener onClickListener;

    public ServiceCategoryAdapter(Context context,
                                  List<ServiceCategoryDo> serviceCategoryList) {
        mInflater = LayoutInflater.from(context);
        this.context = context;
        setServiceCategoryList(serviceCategoryList);
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public List<ServiceCategoryDo> getServiceCategoryList() {
        return serviceCategoryList;
    }

    public void setServiceCategoryList(List<ServiceCategoryDo> serviceCategoryList) {
        this.serviceCategoryList = serviceCategoryList;
    }

    @Override
    public int getCount() {
        return serviceCategoryList.size();
    }

    @Override
    public Object getItem(int position) {
        return serviceCategoryList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_service_category, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.categoryIcon = (SimpleDraweeView) convertView.findViewById(R.id.categoryIcon);
            viewHolder.categoryTitle = (TextView) convertView.findViewById(R.id.categoryTitle);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        ServiceCategoryDo serviceCategoryDo = serviceCategoryList.get(position);
        viewHolder.categoryIcon.setTag(serviceCategoryDo);
        if (null != serviceCategoryDo.getCatIcon()) {
            viewHolder.categoryIcon.setImageURI(Uri.parse(serviceCategoryDo.getCatIcon()));
        }
        viewHolder.categoryTitle.setText(serviceCategoryDo.getCatName());

        convertView.setOnClickListener(onClickListener);
        return convertView;
    }

    public static class ViewHolder {
        SimpleDraweeView categoryIcon;
        TextView categoryTitle;
    }
}
