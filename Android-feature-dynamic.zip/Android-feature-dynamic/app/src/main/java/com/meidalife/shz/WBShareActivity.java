package com.meidalife.shz;

import com.umeng.socialize.media.WBShareCallBackActivity;

/**
 * Created by fufeng on 16/1/24.
 */
public class WBShareActivity extends WBShareCallBackActivity {
}
