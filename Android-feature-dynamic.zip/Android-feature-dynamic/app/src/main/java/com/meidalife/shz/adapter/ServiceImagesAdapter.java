package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by taber on 15/6/1.
 */
public class ServiceImagesAdapter extends BaseAdapter {

    public static int MAX_IMG = 9;

    private Context mContext;
    private List<String> mImages;
    LayoutInflater mInflater;
    private int mWidth;
    private int totalSize;

    static class ImageHolder {
        public ImageView image;
        private TextView imgTotalSize;
    }

    public ServiceImagesAdapter(Context c, List<String> images, int width) {
        this(c, images, width, 0);
    }

    public ServiceImagesAdapter(Context c, List<String> images, int width, int totalSize) {
        mContext = c;
        mImages = images;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mWidth = width;
        this.totalSize = totalSize;
    }

    public int getCount() {
        return mImages.size();
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageHolder imageHolder;
        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            convertView = mInflater.inflate(R.layout.service_grid_item, parent, false);
            ImageView imageView = (ImageView) convertView.findViewById(R.id.serviceGridImage);
            ViewGroup.LayoutParams layoutParams = imageView.getLayoutParams();
            layoutParams.width = mWidth;
            layoutParams.height = mWidth;
            imageView.setLayoutParams(layoutParams);
            imageHolder = new ImageHolder();
            imageHolder.image = imageView;
            imageHolder.imgTotalSize = (TextView) convertView.findViewById(R.id.imgTotalSize);
            convertView.setTag(imageHolder);
        } else {
            imageHolder = (ImageHolder) convertView.getTag();
        }

        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithHeight(mImages.get(position), mWidth));
        try {
            String imgUrl = mImages.get(position);
            String[] arrays = imgUrl.split("/");
            String[] imgWh = arrays[arrays.length - 1].split("_");
            if (imgWh.length == 3) {
                float width = Integer.parseInt(imgWh[0].substring(0, imgWh[0].length() - 1));
                float height = Integer.parseInt(imgWh[1].substring(0, imgWh[1].length() - 1));
                if (width > height) {
                    Uri.parse(ImgUtil.getCDNUrlWithWidth(mImages.get(position), mWidth));
                } else {
                    Uri.parse(ImgUtil.getCDNUrlWithHeight(mImages.get(position), mWidth));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        imageHolder.image.setImageURI(uri);

        if (totalSize > 0 && position == mImages.size() - 1) {
            imageHolder.imgTotalSize.setVisibility(View.VISIBLE);
            imageHolder.imgTotalSize.setText("共" + totalSize + "张");
        } else {
            imageHolder.imgTotalSize.setVisibility(View.GONE);
            imageHolder.imgTotalSize.setText("");
        }

        return convertView;
    }
}
