package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.tencent.mm.sdk.modelbase.BaseResp;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 支付打赏选择界面
 * Created by xingchen on 2015/11/25.
 */
public class RewardPayDialogActivity extends Activity {
    private String receiverId;
    private int rewardAmount;
    private String rewardsDesc;
    private int payWay;
    private String sourceId;
    private String orderNo;
    private boolean isLoading = false;
    @Bind(R.id.iconClose)
    TextView iconClose;
    @Bind(R.id.awardsTitle)
    TextView awardsTitle;
    @Bind(R.id.alipayLayout)
    ViewGroup alipayLayout;
    @Bind(R.id.wechatPayLayout)
    ViewGroup wechatPayLayout;

    private BroadcastReceiver payResultReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int payWay = intent.getIntExtra(Pay.TAG_PAY_WAY, 0);
            int errCode = intent.getIntExtra(Pay.TAG_ERROR_CODE, BaseResp.ErrCode.ERR_COMM);
            if (payWay == Pay.PAY_WAY_WECHAT) {
                Intent data = new Intent();
                data.putExtra(Pay.TAG_PAY_RESULT, errCode == BaseResp.ErrCode.ERR_OK);
                data.putExtra(Pay.TAG_PAY_WAY, Pay.PAY_WAY_WECHAT);
                data.putExtra("amount", rewardAmount);
                data.putExtra("rewardsDesc", rewardsDesc);
                RewardPayDialogActivity.this.setResult(RESULT_OK, data);
                RewardPayDialogActivity.this.finish();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_award_pay_dialog);
        ButterKnife.bind(this);

        receiverId = getIntent().getStringExtra("receiverId");
        rewardAmount = getIntent().getIntExtra("amount", 0);
        rewardsDesc = getIntent().getStringExtra("rewardsDesc");
        sourceId = getIntent().getStringExtra("sourceId");

        createRewardOrder();
        initComponents();

        IntentFilter filter = new IntentFilter();
        filter.addAction(Pay.ACION_PAY_RESULT);

        LocalBroadcastManager.getInstance(this).registerReceiver(payResultReceiver, filter);
        setFinishOnTouchOutside(false);
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(payResultReceiver);
        super.onDestroy();
    }

    private void initComponents() {
        iconClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        alipayLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alipayLayout.setEnabled(false);
                wechatPayLayout.setEnabled(false);
                rewardPay(Pay.PAY_WAY_ALIPAY);
            }
        });

        wechatPayLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alipayLayout.setEnabled(false);
                wechatPayLayout.setEnabled(false);
                rewardPay(Pay.PAY_WAY_WECHAT);
            }
        });
    }

    private void createRewardOrder() {
        JSONObject params = new JSONObject();
        params.put("receiverId", receiverId);
        params.put("amount", rewardAmount);
        params.put("rewardsDesc", rewardsDesc);
        params.put("sourceId", sourceId);//打赏来源ID，选传。例如 视频直播ID

        HttpClient.get("1.0/rewards/createOrder", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        orderNo = obj.getString("orderNo");
                        awardsTitle.setText(obj.getString("title"));
                        //JSONArray outerPayways = obj.getJSONArray("outerPayways");
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(getString(R.string.reward_failed) + error.toString());
                        finish();
                    }
                });
    }

    private void rewardPay(final int payWay) {
        if (isLoading) {
            return;
        }
        isLoading = true;
        JSONObject params = new JSONObject();
        params.put("orderNo", orderNo);
        params.put("gwPayway", payWay);
        params.put("gwPayNum", rewardAmount);
        HttpClient.get("1.0/rewards/pay", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        switch (payWay) {
                            case Pay.PAY_WAY_ALIPAY:
                                String signPayStr = obj.getString("signPayStr");
                                Pay.payWithAlipay(RewardPayDialogActivity.this, signPayStr, new Pay.PayCallback() {
                                    @Override
                                    public void success() {
                                        Intent data = new Intent();
                                        data.putExtra(Pay.TAG_PAY_RESULT, true);
                                        data.putExtra(Pay.TAG_PAY_WAY, Pay.PAY_WAY_ALIPAY);
                                        data.putExtra("amount", rewardAmount);
                                        data.putExtra("rewardsDesc", rewardsDesc);
                                        setResult(RESULT_OK, data);
                                        finish();
                                    }

                                    @Override
                                    public void failure(Error error) {
                                        Intent data = new Intent();
                                        data.putExtra(Pay.TAG_PAY_RESULT, false);
                                        data.putExtra(Pay.TAG_PAY_WAY, Pay.PAY_WAY_ALIPAY);
                                        setResult(RESULT_OK, data);
                                        finish();
                                        MessageUtils.showToastCenter(error.getMessage());
                                    }
                                });
                                break;
                            case Pay.PAY_WAY_WECHAT: {
                                Pay.payWithWechat(RewardPayDialogActivity.this, obj.getJSONObject("wxPay"));
                                break;
                            }
                            default:
                                finish();
                        }
                        isLoading = false;
                        alipayLayout.setEnabled(true);
                        wechatPayLayout.setEnabled(true);
                    }

                    @Override
                    public void onFail(HttpError error) {
                        isLoading = false;
                        MessageUtils.showToast(getString(R.string.pay_error) + error.toString());
                        finish();
                    }
                });
    }
}
