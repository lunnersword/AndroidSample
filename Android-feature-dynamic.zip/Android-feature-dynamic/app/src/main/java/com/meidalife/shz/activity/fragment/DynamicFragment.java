package com.meidalife.shz.activity.fragment;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.BroadcastConstant;
import com.meidalife.shz.Constant;
import com.meidalife.shz.DynamicActionListener;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.ReportActivity;
import com.meidalife.shz.activity.RewardDialogActivity;
import com.meidalife.shz.adapter.DynamicAdapter;
import com.meidalife.shz.adapter.DynamicTabAdapter;
import com.meidalife.shz.adapter.RecommendAdapter;
import com.meidalife.shz.event.DynamicListRefreshEvent;
import com.meidalife.shz.event.type.DynamicRefreshTypeEnum;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicBottomDO;
import com.meidalife.shz.rest.model.DynamicOutDO;
import com.meidalife.shz.rest.model.DynamicTabDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.umeng.socialize.media.UMImage;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by zuozheng on 16/3/29.
 * 动态frag
 */
public class DynamicFragment extends BaseFragment implements ViewPager.OnPageChangeListener {
    //默认推荐人列表是展开状态
    private boolean isListExpanded = true;

    private boolean isLoading = false;
    private boolean isComplete;
    private int page = 0;
    private static int PAGE_SIZE = 10;

    private boolean isRecommendLoading = false;
    private DynamicOutDO clickedDynamic;
    private final int MaxRecommendSize = 3;

    private List<DynamicUserOutDO> mRecommendDataList = new LinkedList<>();
    private List<DynamicUserOutDO> mRecommendDataSource = new LinkedList<>();
    private ArrayList<DynamicTabDO> mTabList = new ArrayList<>();
    private LinkedList<DynamicOutDO> mDynamicDataList = new LinkedList<>();

    private DynamicTabDO mCurrentCate = new DynamicTabDO();

    private View rootView;
    private View dynamicListFooter;
    private View dynamicListHeader;
    private ProgressBar dynamicFooterLoading;
    private TextView dynamicFooterMessage;
    private Button dynamicFooterReload;
    private AnimationDrawable loadingAnimation;

    private ViewGroup noMsgView;
    private TextView noMsgTextView;


    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    //actionbar view
    @Bind(R.id.myAvatar)
    SimpleDraweeView myAvatar;
    @Bind(R.id.action_bar_title)
    TextView actionBarTitleView;
    @Bind(R.id.publishDynamicLayout)
    ViewGroup publishDynamicLayout;

    //content view
    @Bind(R.id.contentLayout)
    ViewGroup contentLayout;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.dynamicListView)
    ListView dynamicListView;
    @Bind(R.id.navTabViewTop)
    GridView navTabViewTop;

    //todo 待完成
    ViewGroup newsViewGroup;
    SimpleDraweeView latestReplayUserAvatar;
    TextView newsCountView;

    //Bind header View
    View dynamicRecommendActionView;
    TextView dynamicRecommendIconView;
    ListView recommendListView;
    GridView navTabView;


    private View recommendListFooter;
    private ProgressBar recommendFooterLoading;
    private TextView recommendFooterRefreshTip;
    private TextView recommendFooterMessage;
    private Button recommendFooterReload;

    private RecommendAdapter mRecommendAdapter;
    private DynamicTabAdapter mTabAdapter;
    private DynamicAdapter mDynamicAdapter;

    private LoadUtilV2 loadUtil;
    private PopupWindow popupWindow;
    private SocialSharePopupWindow socialSharePopupWindow;
    ShareActivity shareActivity;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        if (rootView == null) {
            initView(inflater, container, savedInstanceState);

            page = 0;
            isComplete = false;
            isLoading = false;
            mRecommendAdapter = new RecommendAdapter(getActivity(), mRecommendDataList);
            mTabAdapter = new DynamicTabAdapter(getActivity(), mTabList);
            mDynamicAdapter = new DynamicAdapter(getActivity(), mDynamicDataList);

            recommendListView.setAdapter(mRecommendAdapter);
            dynamicListView.setAdapter(mDynamicAdapter);

//            mDynamicAdapter.setListView(dynamicListView);//单条更新

            shareActivity = new ShareActivity(getActivity());
            initOnClickListener();

            loadUtil = new LoadUtilV2(inflater);

//            xhrRecommend(true);
        }

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        return rootView;
    }

    void initOnClickListener() {
        mRecommendAdapter.setOnClickListener(new RecommendAdapter.OnClickListener() {
//            @Override
//            public void cancelFollowClick(String userId, int position) {
//            }

            @Override
            public void addFollowClick(DynamicUserOutDO dynamic, int position) {
                recommendUserFollow(dynamic, position);
            }
        });

        mDynamicAdapter.setmListener(new DynamicActionListener() {
            @Override
            public void onFollowClick(int position, DynamicOutDO dynamic) {
                //关注之后
                follow(position, dynamic);
            }

            @Override
            public void onCommentClick(int position, DynamicOutDO dynamic) {
                //发送输入事件 弹出键盘 并输入内容
                sendCommentBroadcast(position, dynamic);
            }

            @Override
            public void onCommentListItemClick(int position, DynamicOutDO dynamic, DynamicBottomDO comment) {
                sendItemClickBroadcast(position, dynamic, comment);
            }

            @Override
            public void onSupportClick(int position, DynamicOutDO dynamic) {
                supportOrCancel(dynamic);
            }

            @Override
            public void onRewardClick(int position, DynamicOutDO dynamic) {
                award(dynamic);
            }

            @Override
            public void onMoreActionClick(int position, DynamicOutDO dynamic, View view) {
                //显示popup Window 举报或者xx
                initPopupWindowView(position, dynamic, view);
            }
        });

        newsViewGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("dynamic_news");
            }
        });
    }

    void initPopupWindowView(final int position, final DynamicOutDO dynamic, View view) {
        View popupView = LayoutInflater.from(getActivity()).inflate(R.layout.popup_window_dynamic, null);
        final View leftView = popupView.findViewById(R.id.view_left);
        View rightView = popupView.findViewById(R.id.view_right);
        TextView rightTextView = (TextView) popupView.findViewById(R.id.text_right);

        if (Helper.sharedHelper().getUserId().equals(dynamic.getUser().getUserId())) {
            rightTextView.setText("删除");
        }

        leftView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHideShareList(leftView, dynamic);
                popupWindow.dismiss();
            }
        });

        rightView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().getUserId().equals(dynamic.getUser().getUserId())) {
                    deleteFeed(position, dynamic.getFeedId());
                } else {
                    reportDynamic(dynamic.getFeedId());
                }
                popupWindow.dismiss();
            }
        });

        popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setAnimationStyle(R.style.PopupWindowAnimation);
        popupWindow.showAtLocation(view, Gravity.RIGHT, 0, 175);
    }

    void deleteFeed(final int position, String feedId) {
        JSONObject params = new JSONObject();

        if (!TextUtils.isEmpty(feedId)) {
            params.put("itemId", feedId);
        }

        RequestDynamic.deleteFeed(params, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                //实现列表假删除
                mDynamicDataList.remove(position);
                mDynamicAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    void initView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_dynamic, container, false);

        ButterKnife.bind(this, rootView);
        dynamicListHeader = getLayoutInflater(savedInstanceState).inflate(R.layout.fragment_dynamic_header, null);

        recommendListView = (ListView) dynamicListHeader.findViewById(R.id.recommendListView);
        recommendListFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_dynamic_recommend_list_footer, null);
        recommendFooterLoading = (ProgressBar) recommendListFooter.findViewById(R.id.loading);
        recommendFooterRefreshTip = (TextView) recommendListFooter.findViewById(R.id.refreshTip);
        recommendFooterMessage = (TextView) recommendListFooter.findViewById(R.id.message);
        recommendFooterReload = (Button) recommendListFooter.findViewById(R.id.footerReload);
        recommendFooterLoading.setVisibility(View.GONE);
        recommendFooterMessage.setText("换一换");
        recommendFooterMessage.setTextColor(getResources().getColor(R.color.black));
        recommendListView.addFooterView(recommendListFooter);


        dynamicRecommendActionView = dynamicListHeader.findViewById(R.id.dynamic_recommend_action);
        dynamicRecommendIconView = (TextView) dynamicListHeader.findViewById(R.id.dynamic_recommend_action_icon);
        navTabView = (GridView) dynamicListHeader.findViewById(R.id.navTabView);
        dynamicListView.addHeaderView(dynamicListHeader);

        noMsgView = (ViewGroup) dynamicListHeader.findViewById(R.id.dataEmptyView);
        noMsgTextView = (TextView) dynamicListHeader.findViewById(R.id.dataEmptyTextView);

        newsViewGroup = (ViewGroup) dynamicListHeader.findViewById(R.id.newsViewGroup);
        latestReplayUserAvatar = (SimpleDraweeView) dynamicListHeader.findViewById(R.id.latestReplayUserAvatar);
        newsCountView = (TextView) dynamicListHeader.findViewById(R.id.newsCountView);

        dynamicListFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
        dynamicFooterLoading = (ProgressBar) dynamicListFooter.findViewById(R.id.loading);
        dynamicFooterMessage = (TextView) dynamicListFooter.findViewById(R.id.message);
        dynamicFooterReload = (Button) dynamicListFooter.findViewById(R.id.footerReload);
        dynamicListView.addFooterView(dynamicListFooter);
        dynamicListFooter.setVisibility(View.GONE);

//        dynamicListFooter.setVisibility(View.GONE);


        String avatarUrl = Helper.sharedHelper().getStringUserInfo(Constant.USER_AVATAR);
        if (TextUtils.isEmpty(avatarUrl)) {
            String userId = Helper.sharedHelper().getStringUserInfo(Constant.USER_ID);
            String gender = Helper.sharedHelper().getStringUserInfo(Constant.USER_GENDER);
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(getActivity(), userId, gender);
            myAvatar.setImageURI(getDefaultAvatarUri);
        } else {
            Uri avatarUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, myAvatar.getLayoutParams().width));
            myAvatar.setImageURI(avatarUri);
        }

        myAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open("profile/" + Helper.sharedHelper().getUserId());
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });

        dynamicRecommendActionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击展开按钮 请空推荐数据 并刷新
                pickUpDataOrExpand();
            }
        });

        publishDynamicLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    //跳转到创建动态页面
                    Router.sharedRouter().open("publish/dynamic");
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });

        recommendListFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //刷新数据 实现假的数据刷新 如果内存数据大于3条 不重新请求
//                xhrRecommend(false);
                updateRecommend();
            }
        });

        dynamicFooterReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                xhrDynamic(false);
            }
        });


        dynamicListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        xhrDynamic(false);
                    }
                } else {
                    mSwipeRefreshLayout.setEnabled(true);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (dynamicListView.getFirstVisiblePosition() >= 1) {
                    navTabViewTop.setVisibility(View.VISIBLE);
                } else {
                    navTabViewTop.setVisibility(View.GONE);
                }

            }
        });

        navTabViewTop.setOnItemClickListener(new ItemClickListener());

        navTabView.setOnItemClickListener(new ItemClickListener());

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(false);
                xhrRecommend(true);
            }
        });

    }

    void pickUpDataOrExpand() {
        if (CollectionUtil.isNotEmpty(mRecommendDataList) && isListExpanded) {
            //清空数据 并收起
            mRecommendDataList.clear();
            mRecommendAdapter.notifyDataSetChanged();

            dynamicRecommendIconView.setText(getResources().getText(R.string.icon_arrow_collapse));
            isListExpanded = false;

            recommendListView.removeFooterView(recommendListFooter);
        } else {
//            mRecommendDataList.addAll(mRecommendDataSource);
            updateRecommend();
            recommendListView.addFooterView(recommendListFooter);
            mRecommendAdapter.notifyDataSetChanged();

            dynamicRecommendIconView.setText(getResources().getText(R.string.icon_arrow_expand));
            isListExpanded = true;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        xhrRecommend(true);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {
        mSwipeRefreshLayout.setEnabled(state == ViewPager.SCROLL_STATE_IDLE);
    }

    class ItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            if (position < mTabList.size()) {
                mCurrentCate = mTabList.get(position);

                for (DynamicTabDO item : mTabList) {
                    if (item.getTabName() == mCurrentCate.getTabName()) {
                        if (item.isSelected()) {
                            return;
                        } else {
                            item.setIsSelected(true);
                        }
                    } else {
                        item.setIsSelected(false);
                    }
                }
                mTabAdapter.notifyDataSetChanged();

                //设置当前tabId
                xhrDynamic(true);

//                LogParam param = new LogParam();
//                param.setType(LogUtil.TYPE_CUSTOMIZE);
//                param.setEid(LogUtil.EVENT_ID_HOME_TAB_CLICK);
//                param.setPoid(String.valueOf(position + 1));
//                LogUtil.log(param);
            }
        }
    }

    private void renderRecommendUsers() {
        if (CollectionUtil.isEmpty(mRecommendDataSource)) {
            return;
        }
        mRecommendDataList.clear();
        int end = Math.min(MaxRecommendSize, mRecommendDataSource.size());
        List<DynamicUserOutDO> tmpList = new LinkedList<>();
        tmpList.addAll(mRecommendDataSource.subList(0, end));
        mRecommendDataList.addAll(tmpList);
        mRecommendDataSource.removeAll(tmpList);

        mRecommendAdapter.notifyDataSetChanged();
    }

    private void renderRecommendAfterRequest() {
        if (CollectionUtil.isEmpty(mRecommendDataSource)) {
            return;
        }
        mRecommendDataList.clear();
        int end = Math.min(MaxRecommendSize, mRecommendDataSource.size());
        mRecommendDataList.addAll(mRecommendDataSource.subList(0, end));

        mRecommendAdapter.notifyDataSetChanged();
    }

    private void renderCategoryTabs(List<DynamicTabDO> tabList) {
        if (CollectionUtil.isEmpty(tabList)) {
            return;
        }

        if (CollectionUtil.isNotEmpty(mTabList)) {
            return;
        }

        mTabList.clear();
        mTabList.addAll(tabList);

        navTabViewTop.setNumColumns(tabList.size());
        navTabViewTop.setPadding(getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin)
                , 0, getResources().getDisplayMetrics().widthPixels / tabList.size(), 0);
        navTabView.setNumColumns(tabList.size());
        navTabView.setPadding(getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin)
                , 0, getResources().getDisplayMetrics().widthPixels / tabList.size(), 0);
        navTabViewTop.setAdapter(mTabAdapter);
        navTabView.setAdapter(mTabAdapter);
        mTabAdapter.notifyDataSetChanged();

        //设置“推荐” 默认tab
        mCurrentCate = tabList.get(0);
    }

    void updateRecommend() {
        if (mRecommendDataSource.size() < MaxRecommendSize) {
            xhrRecommend(true);
        } else {
            renderRecommendUsers();
        }
    }

    private void afterFollowRecommendSuccess(int followUserPosition) {
//        mRecommendDataList.remove(followUserPosition);
        if (CollectionUtil.isNotEmpty(mRecommendDataSource) && followUserPosition < mRecommendDataList.size()) {
            mRecommendDataList.set(followUserPosition, mRecommendDataSource.get(0));
        }

        mRecommendAdapter.notifyDataSetChanged();

        if (mRecommendDataSource.size() < MaxRecommendSize) {
            xhrRecommend(false);
        }
    }

    private void renderDynamic(List<DynamicOutDO> dynamicList) {

        if (CollectionUtil.isEmpty(dynamicList) || dynamicList.size() < PAGE_SIZE) {

            isComplete = true;
            dynamicListView.removeFooterView(dynamicListFooter);
        }

        if (CollectionUtil.isNotEmpty(dynamicList)) {
            mDynamicDataList.addAll(dynamicList);
        }

        if (CollectionUtil.isEmpty(mDynamicDataList)) {
            noMsgView.setVisibility(View.VISIBLE);
            switch (mCurrentCate.getTabId()) {
                case "1":
                    noMsgTextView.setText("快去关注牛人吧~");
                    break;
                case "2":
                    noMsgTextView.setText("暂无推荐");
                    break;

                case "3":
                    noMsgTextView.setText("还没有相关直播内容哦~");
                    break;
            }
        } else {
            noMsgView.setVisibility(View.GONE);
        }

        mDynamicAdapter.notifyDataSetChanged();
    }

    //请求推荐数据
    private void xhrRecommend(final boolean refresh) {

        if (isRecommendLoading) {
            return;
        }
        isRecommendLoading = true;

        if (refresh) {
            loadUtil.loadPre(rootLayout, contentLayout);
            mRecommendDataList.clear();
            mRecommendDataSource.clear();
        } else {
            recommendFooterLoading.setVisibility(View.VISIBLE);
            recommendFooterRefreshTip.setVisibility(View.GONE);
            recommendFooterMessage.setText("正在加载");
            recommendFooterMessage.setVisibility(View.VISIBLE);
            recommendFooterReload.setVisibility(View.GONE);
            recommendListFooter.setVisibility(View.VISIBLE);
        }
        JSONObject params = new JSONObject();
        params.put("pageSize", 50);

        HttpClient.searchDevEnv("1.0/user/recommend", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                isRecommendLoading = false;
                mSwipeRefreshLayout.setRefreshing(false);

                if (getActivity() == null || isDetached()) {
                    return;
                }
                //模拟tab数据 实现数据切换
                if (refresh) {
                    loadUtil.loadSuccess(contentLayout);
                    xhrDynamic(true);
                } else {
                    recommendFooterLoading.setVisibility(View.GONE);
                    recommendFooterRefreshTip.setVisibility(View.VISIBLE);
                    recommendFooterMessage.setText("换一换");
                    recommendFooterMessage.setVisibility(View.VISIBLE);
                    recommendFooterReload.setVisibility(View.GONE);
                    recommendListFooter.setVisibility(View.VISIBLE);
                }

                List<DynamicUserOutDO> userList = null;
                if (result != null && result.containsKey("result")) {
                    userList = JSON.parseArray(result.getString("result"), DynamicUserOutDO.class);
                }

                //parse recommend data
                if (CollectionUtil.isNotEmpty(userList)) {
                    mRecommendDataSource.addAll(userList);
//                    mSwipeRefreshLayout.setVisibility(View.VISIBLE);
                } else {
//                    mSwipeRefreshLayout.setVisibility(View.GONE);
                }
                renderRecommendAfterRequest();
            }

            @Override
            public void onFail(HttpError error) {
                isRecommendLoading = false;
                mSwipeRefreshLayout.setRefreshing(false);

                if (getActivity() == null || isDetached()) {
                    return;
                }
                if (refresh) {
                    loadUtil.loadFail(error, rootLayout, new LoadUtilV2.RetryCallback() {
                        @Override
                        public void retry() {
                            xhrRecommend(true);
                        }
                    });
                } else {
                    page--;
                    recommendFooterMessage.setVisibility(View.GONE);
                    recommendFooterLoading.setVisibility(View.GONE);
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            recommendFooterReload.setText("网络异常，点击重试");
                        } else {
                            recommendFooterReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        recommendFooterReload.setText("发生一个未知错误，点击重试");
                    }
                    recommendFooterRefreshTip.setVisibility(View.VISIBLE);
                    recommendListFooter.setVisibility(View.VISIBLE);
                }
            }
        });
    }


    private void xhrDynamic(final boolean refresh) {

        if (isLoading) {
            return;
        }
        isLoading = true;

        if (refresh) {
            loadUtil.loadPre(rootLayout, contentLayout);
            mDynamicDataList.clear();
            page = 0;
            isComplete = false;
            dynamicListFooter.setVisibility(View.GONE);
        } else {
            //load more

            if (isComplete) {
                isLoading = false;
                return;
            }

            dynamicFooterMessage.setText("正在加载");
            dynamicFooterMessage.setVisibility(View.VISIBLE);
            dynamicFooterLoading.setVisibility(View.VISIBLE);
            dynamicFooterReload.setVisibility(View.GONE);
            dynamicListFooter.setVisibility(View.VISIBLE);
            page++;
        }

        HttpClient.searchDevEnv("1.0/feed/", getParams(), JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject json) {
                isLoading = false;
//                mSwipeRefreshLayout.setRefreshing(false);
                if (refresh) {
                    loadUtil.loadSuccess(contentLayout);
                    List<DynamicTabDO> tabList = null;
                    if (json != null && json.containsKey("tabList")) {
                        tabList = JSON.parseArray(json.getString("tabList"), DynamicTabDO.class);
                    }
                    renderCategoryTabs(tabList);
                } else {
                    dynamicListFooter.setVisibility(View.GONE);
                }

                List<DynamicOutDO> dynamicList = null;
                if (json != null && json.containsKey("result")) {
                    dynamicList = JSON.parseArray(json.getString("result"), DynamicOutDO.class);
                }

                renderDynamic(dynamicList);
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
//                mSwipeRefreshLayout.setRefreshing(false);
                if (refresh) {
                    loadUtil.loadFail(error, rootLayout, new LoadUtilV2.RetryCallback() {
                        @Override
                        public void retry() {
                            xhrDynamic(true);
                        }
                    });
                } else {
                    page--;
                    isLoading = false;
                    dynamicFooterMessage.setVisibility(View.GONE);
                    dynamicFooterLoading.setVisibility(View.GONE);
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            dynamicFooterReload.setText("网络异常，点击重试");
                        } else {
                            dynamicFooterReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        dynamicFooterReload.setText("发生一个未知错误，点击重试");
                    }
                    dynamicFooterReload.setVisibility(View.VISIBLE);
                    dynamicListFooter.setVisibility(View.VISIBLE);
                }
            }
        });

    }

    private JSONObject getParams() {
        JSONObject params;
        try {
            params = new JSONObject();
            if (TextUtils.isEmpty(mCurrentCate.getTabId())) {
                params.put("tabId", "");
            } else {
                params.put("tabId", mCurrentCate.getTabId());
            }
            params.put("pageSize", String.valueOf(PAGE_SIZE));
            params.put("offset", String.valueOf(page * PAGE_SIZE));
        } catch (Exception e) {
            params = null;
        }

        return params;
    }

    //关注推荐人
    private void recommendUserFollow(DynamicUserOutDO dynamic, final int position) {
        RequestDynamic.addFollow(dynamic.getUserId(), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                MessageUtils.showToastCenter("关注成功");
                //关注成功之后 当前数据消失 并从内存数据中获取新数据并添加到该位置 并更新界面
                afterFollowRecommendSuccess(position);
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    //关注动态tab中的人
    private void follow(final int position, final DynamicOutDO dynamic) {
        RequestDynamic.addFollow(dynamic.getUser().getUserId(), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                MessageUtils.showToastCenter("关注成功");
                dynamic.getUser().setIsFocused(true);
                mDynamicAdapter.updateItemData(dynamic, DynamicRefreshTypeEnum.TYPE_FOLLOW);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter("关注失败");
            }
        });
    }

    void sendCommentBroadcast(int position, DynamicOutDO dynamic) {
        Intent intent = new Intent();
        intent.setAction(BroadcastConstant.COMMENT);
        intent.putExtra("position", position);
        intent.putExtra("item", dynamic);

        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
    }

    void sendItemClickBroadcast(int position, DynamicOutDO dynamic, DynamicBottomDO comment) {
        Intent intent = new Intent();
        intent.setAction(BroadcastConstant.ITEMCLICK);
        intent.putExtra("position", position);
        intent.putExtra("item", dynamic);
        intent.putExtra("comment", comment);

        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
    }

    private void supportOrCancel(final DynamicOutDO dynamic) {
        try {
            JSONObject params = new JSONObject();
            params.put("feedId", dynamic.getFeedId());
            if (dynamic.isSupported()) {
                params.put("type", 1);
            } else {
                params.put("type", 0);
            }

            RequestDynamic.supportOrCancel(params, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {
                    MessageUtils.showToastCenter("点赞成功");
                    if (dynamic.isSupported()) {
                        dynamic.setSupportCount(dynamic.getSupportCount() - 1);
                        dynamic.setIsSupported(false);
                    } else {
                        dynamic.setIsSupported(true);
                        dynamic.setSupportCount(dynamic.getSupportCount() + 1);
                    }
                    mDynamicAdapter.updateItemData(dynamic, DynamicRefreshTypeEnum.TYPE_SUPPORT);
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToastCenter("点赞失败");
                }
            });
        } catch (Exception e) {
        }
    }

    //弹出打赏popupWindow 如果打赏成功 更新对应adapter=
    private void award(final DynamicOutDO item) {
        clickedDynamic = item;
        Intent intent = new Intent(getActivity(), RewardDialogActivity.class);
        intent.putExtra("receiverId", item.getUser().getUserId());
        intent.putExtra("avatar", item.getUser().getAvatarUrl());
        intent.putExtra("sourceId", item.getFeedId());

        startActivityForResult(intent,
                Constant.REQUEST_CODE_REWARD);
    }


    public void onEvent(DynamicListRefreshEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isLoading) {
            if (event.position >= -1 && event.position < mDynamicDataList.size()) {
                mDynamicAdapter.updateItemData(event.dynamic, event.typeEnum);
            }
        } else if (MsgTypeEnum.TYPE_PUBLISH == event.eventType && !isLoading && mCurrentCate.getTabId().equals("1")) {
            //关注tab
            List<DynamicOutDO> tmpDataList = new LinkedList<>();
            tmpDataList.add(event.dynamic);
            tmpDataList.addAll(mDynamicDataList);
            mDynamicDataList.clear();
            mDynamicDataList.addAll(tmpDataList);
            mDynamicAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_REWARD && data != null) {
            double rewardAmount = data.getIntExtra("amount", 0);
            boolean result = data.getBooleanExtra(Pay.TAG_PAY_RESULT, false);
            if (result && rewardAmount > 0) {
                clickedDynamic.setBonusCount(rewardAmount / 1000 + clickedDynamic.getBonusCount());
                mDynamicAdapter.updateItemData(clickedDynamic, DynamicRefreshTypeEnum.TYPE_REWARD);
            } else {
                MessageUtils.showToast(R.string.reward_failed);
            }
        }
    }

    private void reportDynamic(String feedId) {
        Intent intent = new Intent();
        intent.setClass(getActivity(), ReportActivity.class);
        intent.putExtra("targetId", feedId);
        intent.putExtra("target", Constant.REPORT_TYPE_DYNAMIC);
        startActivity(intent);
    }

    private void showOrHideShareList(View v, DynamicOutDO dynamic) {
        if (socialSharePopupWindow == null) {
            socialSharePopupWindow = new SocialSharePopupWindow(getActivity(), shareActivity, 0);
        }

        socialSharePopupWindow.setShareUrl(null);
        socialSharePopupWindow.setShareTitle(dynamic.getUser().getUserNick());
        socialSharePopupWindow.setShareDescription(dynamic.getContent());
        socialSharePopupWindow.setShareImage(new UMImage(getActivity(), dynamic.getUser().getAvatarUrl()));

        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }
}
