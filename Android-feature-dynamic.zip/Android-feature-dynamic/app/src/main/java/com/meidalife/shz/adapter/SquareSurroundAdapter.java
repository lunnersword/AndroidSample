package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.PortalSquareDO;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.rest.model.SquareDynamicDO;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.IconTextView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 15/12/20.
 * 周边动态adapter
 */
public class SquareSurroundAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    List<SquareDynamicDO> mData;
    PortalSquareDO squareDO;
    int imgWidth;

    int KEY_TYPE = 1 << 26;
    int KEY_HOLDER = 1 << 27;

    String ITEM_TYPE_NORMAL = "normal";
    String ITEM_TYPE_ERROR = "error";

    static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }


        @Bind(R.id.rootView)
        View rootView;


//        @Bind(R.id.bgPublishTime)
//        TextView publishTime;

        @Bind(R.id.squareName)
        TextView squareName;
        @Bind(R.id.squareType)
        TextView squareType;
        @Bind(R.id.distance)
        TextView distance;


        @Bind(R.id.imageAvatar)
        SimpleDraweeView imageAvatar;
        @Bind(R.id.textNick)
        TextView textNick;
        @Bind(R.id.iconGender)
        IconTextView iconGender;
        @Bind(R.id.textTitle)
        TextView textTitle;

        @Bind(R.id.imageSingle)
        SimpleDraweeView imageSingle;
//        @Bind(R.id.imageList)
//        GridView imageList;
        @Bind(R.id.dynamicDesc)
        TextView dynamicDesc;
    }


    static class ErrorViewHolder {
        TextView errorTip;
        View locationTip;
        ImageView no_data_icon;

        View rootView;
    }

    public SquareSurroundAdapter(Context context, List<SquareDynamicDO> data, PortalSquareDO squareDO) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
        this.squareDO = squareDO;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public String getItem(int position) {
        return null;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        final SquareDynamicDO item = mData.get(position);

        if (item.getErrorType() > 0) {
            convertView = getErrorItemView(convertView);
            ErrorViewHolder holder = (ErrorViewHolder) convertView.getTag(KEY_HOLDER);

            holder.errorTip.setText(item.getErrorDesc());

            if (item.getErrorType() == 1) {
                holder.locationTip.setVisibility(View.VISIBLE);
                holder.rootView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Helper.openLocationSetting(mContext);
                    }
                });
            } else {
                holder.locationTip.setVisibility(View.GONE);
                holder.rootView.setOnClickListener(null);
            }

            if (item.getErrorType() == 2) {
                holder.no_data_icon.setImageDrawable(mContext.getResources().getDrawable(R.mipmap.emotion_default_search));
                holder.no_data_icon.setVisibility(View.VISIBLE);
            } else {
                holder.no_data_icon.setImageDrawable(null);
                holder.no_data_icon.setVisibility(View.GONE);
            }

        } else {
            convertView = genViewHolder(convertView, parent);

            ViewHolder holder = (ViewHolder) convertView.getTag();

//            holder.publishTime.setText(item.getCreateTime());
            holder.squareName.setText("来自" + item.getGeziName());
            holder.squareType.setText("[" + item.getGeziTypeDesc() + "]");
            holder.distance.setText(item.getGeziDistance());


            holder.textNick.setText(item.getUserNick());
            String gender = "";
            // 设置服务者性别
            if (item.getUserGender() != null) {
                holder.iconGender.setVisibility(View.VISIBLE);
                if (item.getUserGender().equals("woman") || item.getUserGender().equals("F")) {
                    holder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_f));
                    holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                } else {
                    holder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_m));
                    holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
                }
            } else {
                holder.iconGender.setVisibility(View.GONE);
            }

            if (item.getType() == 1 || item.getType() == 2) {
                if (item.getType() == 1) {
                    holder.textTitle.setText(mContext.getResources().getString(R.string.label_i_can) + item.getItemTitle());
                    holder.textTitle.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                    holder.dynamicDesc.setText("");
                    holder.dynamicDesc.setVisibility(View.GONE);
                } else {
                    holder.textTitle.setText(mContext.getResources().getString(R.string.label_i_want) + item.getDemandTitle());
                    holder.textTitle.setTextColor(mContext.getResources().getColor(R.color.square_i_want_title));
                    holder.dynamicDesc.setText(item.getDemandDesc());
                    holder.dynamicDesc.setVisibility(View.VISIBLE);
                }

                ArrayList<String> images = (ArrayList<String>) item.getItemImages();
                if (images != null && images.size() > 0) {
                    ViewGroup.LayoutParams layoutParmas = holder.imageSingle.getLayoutParams();
                    Uri itemUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(images.get(0), layoutParmas.width));
                    holder.imageSingle.setImageURI(itemUri);
//                    holder.imageList.setVisibility(View.GONE);
                    holder.imageSingle.setVisibility(View.VISIBLE);
//                    if (isSingle) {
//                        ViewGroup.LayoutParams layoutParmas = holder.imageSingle.getLayoutParams();
//                        Uri itemUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(images.get(0), layoutParmas.width));
//                        holder.imageSingle.setImageURI(itemUri);
//                        holder.imageList.setVisibility(View.GONE);
//                        holder.imageSingle.setVisibility(View.VISIBLE);
//                    } else {
//                        ArrayList<String> showImgList = new ArrayList<>();
//                        int endIndex = Math.min(ServiceImagesAdapter.MAX_IMG, images.size());
//                        for (int i = 0; i < endIndex; i++) {
//                            showImgList.add(item.getItemImages().get(i));
//                        }
//                        holder.imageList.setAdapter(new ServiceImagesAdapter(mContext, showImgList, imgWidth, images.size()));
//                        holder.imageSingle.setVisibility(View.GONE);
//                        holder.imageList.setVisibility(View.VISIBLE);
//                    }
                } else {
//                    holder.imageList.setVisibility(View.GONE);
                    holder.imageSingle.setVisibility(View.GONE);
                }
            } else {
                //闲话
                holder.textTitle.setText(item.getTopicTitle());
                holder.textTitle.setTextColor(mContext.getResources().getColor(R.color.brand_c));
                holder.dynamicDesc.setText("");
                holder.dynamicDesc.setVisibility(View.GONE);

                ArrayList<String> topImages = (ArrayList<String>) item.getTopicImages();
                if (topImages != null && topImages.size() > 0) {
                    ViewGroup.LayoutParams layoutParmas = holder.imageSingle.getLayoutParams();
                    Uri itemUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(topImages.get(0), layoutParmas.width));
                    holder.imageSingle.setImageURI(itemUri);
                    holder.imageSingle.setVisibility(View.VISIBLE);
                } else {
                    holder.imageSingle.setVisibility(View.GONE);
                }
//                holder.imageList.setVisibility(View.GONE);
            }

            // 设置服务者头像
            ViewGroup.LayoutParams avatarParams = holder.imageAvatar.getLayoutParams();
            if (TextUtils.isEmpty(item.getUserPicUrl())) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(item.getUserId()), gender);
                holder.imageAvatar.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getUserPicUrl(), avatarParams.width));
                holder.imageAvatar.setImageURI(uri);
            }

            //设置图片


            holder.rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (item.getType() == Constant.SQUARE_SURROUND_ITEM_TYPE_SERVICE) {
                        Router.sharedRouter().open("services/" + item.getItemId());
                    } else if (item.getType() == Constant.SQUARE_SURROUND_ITEM_TYPE_ASK) {
                        Bundle bundle = new Bundle();
                        bundle.putInt("geziId", (int) item.getGeziId());
                        Router.sharedRouter().open("squareaskdetail/" + item.getDemandId(), bundle);
                    } else if (item.getType() == Constant.SQUARE_SURROUND_ITEM_TYPE_BBS) {
                        Bundle bundle = new Bundle();
                        try {
                            for (SquareDO square : squareDO.getGeziList()) {
                                if (null != square && square.getGeziId() == item.getGeziId()) {
                                    bundle.putBoolean("isJoined", square.isJoined());
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        bundle.putInt("geziId", (int) item.getGeziId());
                        Router.sharedRouter().open("squarebbsdetail/" + item.getTopicId(), bundle);
                    }
                }
            });
        }

        return convertView;
    }

    private View genViewHolder(View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_square_surround, parent, false);
            holder = new ViewHolder(convertView);

            //计算多图每栏宽度

//            if (mData != null && mData.size() == 2) {
//                holder.imageList.setColumnWidth(72);
//            } else {
//                holder.imageList.setColumnWidth(108);
//            }

            imgWidth = 108;

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            if (holder == null) {
                return genViewHolder(null, parent);
            }
        }

        return convertView;
    }


    private View getErrorItemView(View convertView) {
        if (convertView != null && convertView.getTag() != null && convertView.getTag(KEY_TYPE) != null) {
            String type = (String) convertView.getTag(KEY_TYPE);
            if (ITEM_TYPE_ERROR.equals(type)) {
                return convertView;
            }
        }

        convertView = mInflater.inflate(R.layout.location_error_view, null);
        convertView.setTag(KEY_TYPE, ITEM_TYPE_ERROR);

        ErrorViewHolder holder = new ErrorViewHolder();
        holder.rootView = convertView.findViewById(R.id.root_view);
        holder.errorTip = (TextView) convertView.findViewById(R.id.nearbyHintLabel);
        holder.locationTip = convertView.findViewById(R.id.locationTip);
        holder.no_data_icon = (ImageView) convertView.findViewById(R.id.no_data_icon);

        convertView.setTag(KEY_HOLDER, holder);
        return convertView;
    }
}
