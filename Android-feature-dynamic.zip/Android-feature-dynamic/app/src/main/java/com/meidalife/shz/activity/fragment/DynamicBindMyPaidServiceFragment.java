package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.meidalife.shz.R;
import com.meidalife.shz.adapter.DynamicBindServiceAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.OrderTabTypeOutDO;
import com.meidalife.shz.rest.model.Service4DynamicDO;
import com.meidalife.shz.rest.model.ServiceList4DynamicDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.LoadUtil;

import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zuozheng on 16/04/06.
 */
public class DynamicBindMyPaidServiceFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    //    private static final String TAG_ROLE_TYPE = "role_type";
//    private static final String TAG_TYPE = "type";
//    private static final String TAG_COUNT = "count";
    private static final String TAG_TITLE = "title";
    private Boolean isLoading = false;
    //    private int roleType = 1;
    private int page = 1;
    private int pageSize = 10;
    private List<Service4DynamicDO> mList = new LinkedList<>();
    private View rootView;

    private DynamicBindServiceAdapter serviceListAdapter;
    private LoadUtil mLoadUtil;

    @Bind(R.id.emptyView)
    View emptyView;
    @Bind(R.id.orderList)
    ListView orderListView;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;

    Service4DynamicDO clickedItem;

    public static DynamicBindMyPaidServiceFragment newInstance(String fragTitle) {
        DynamicBindMyPaidServiceFragment orderListFragment = new DynamicBindMyPaidServiceFragment();

        Bundle params = new Bundle();
        params.putString(TAG_TITLE, fragTitle);
        orderListFragment.setArguments(params);

        return orderListFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_order_list, null);
            ButterKnife.bind(this, rootView);

            //listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
            mLoadUtil = new LoadUtil(inflater);

            orderListView.setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                        if (view.getLastVisiblePosition() == view.getCount() - 1) {
                            loadData(false);
                        }
                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem,
                                     int visibleItemCount, int totalItemCount) {
                }
            });

            orderListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    //todo 需要实现反选 如果是选中状态 点击之后为非选中状态；如果是非选中状态,点击之后为选中状态
                    clickedItem = mList.get(position);
                    for (Service4DynamicDO item : mList) {
                        if (item.getItemId().equals(clickedItem.getItemId())) {
                            //实现反选
                            if (item.isSelected()) {
                                item.setSelected(false);
                            } else {
                                item.setSelected(true);
                            }
                        } else {
                            item.setSelected(false);
                        }
                    }
                    serviceListAdapter.notifyDataSetChanged();
                }
            });

            swipeRefreshLayout.setOnRefreshListener(this);
            serviceListAdapter = new DynamicBindServiceAdapter(getActivity(), mList);
//            orderListAdapter.setOnOrderChangeLister(this);
            orderListView.setAdapter(serviceListAdapter);
        }
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // loadData(true);
    }

    @Override
    public void onResume() {
        // updateOrder();
        loadData(true);
        super.onResume();
    }

    @Override
    public void onDestroyView() {
        try {
            try {
                ViewGroup parent = (ViewGroup) rootView.getParent();
                if (parent != null) {
                    parent.removeView(rootView);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    public void loadData(boolean reload) {
        if (isLoading) {
            return;
        }
        isLoading = true;
        if (reload) {
            page = 1;
            mList.clear();

            mLoadUtil.loadPre((ViewGroup) rootView, swipeRefreshLayout);
        }
        RequestDynamic.myPaidServiceList(page, pageSize, new HttpClient.HttpCallback<ServiceList4DynamicDO>() {
            @Override
            public void onSuccess(ServiceList4DynamicDO orderListVO) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                if (getActivity() == null) {
                    return;
                }
                //listFooter.setVisibility(View.GONE);
                mLoadUtil.hideStatusLoading();

                if (orderListVO != null && CollectionUtil.isNotEmpty(orderListVO.getItemPay())) {
                    mList.addAll(orderListVO.getItemPay());
                }
                if (mList.size() == 0) {
                    swipeRefreshLayout.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                    serviceListAdapter.notifyDataSetChanged();
                    page++;
                }
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                //listFooter.setVisibility(View.GONE);
                mLoadUtil.loadFail(error, (ViewGroup) rootView, getActivity(), new LoadUtil.LoadCallback() {
                    @Override
                    public void execute() {
                        loadData(true);
                    }
                });
            }
        });
    }

//    public void setOnDataChangeListener(OnDataChangeListener onDataChangeListener) {
//        this.onDataChangeListener = onDataChangeListener;
//    }

    @Override
    public void onRefresh() {
        loadData(true);
    }

//    @Override
//    public void onOrderRefresh() {
//        loadData(true);
//    }

//    @Override
//    public void onOrderChange(int position, String orderNo) {
//        if (CollectionUtil.isNotEmpty(mOrderList) && position < mOrderList.size()) {
//            OrderDO orderDO = mOrderList.get(position);
//            currentChangedOrderNo = orderDO.getOrderNo();
//            changedOrderIndex = position;
//        }
//    }

//    private void updateOrder() {
//        if (TextUtils.isEmpty(currentChangedOrderNo) || changedOrderIndex < 0) {
//            return;
//        }
//        RequestOrder.getOrder(currentChangedOrderNo, new HttpClient.HttpCallback<OrderDO>() {
//            @Override
//            public void onSuccess(OrderDO result) {
//                try {
//                    currentChangedOrderNo = null;
////                    OrderDO mOrder = (OrderDO) result;
//                    mOrderList.remove(changedOrderIndex);
//                    mOrderList.add(changedOrderIndex, result);
//                    orderListAdapter.updateData(mOrderList);
//                    changedOrderIndex = -1;
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//
//            @Override
//            public void onFail(HttpError error) {
//                changedOrderIndex = -1;
//                currentChangedOrderNo = null;
//            }
//        });
//    }

    public interface OnDataChangeListener {
        void onDataChange(List<OrderTabTypeOutDO> orderTabTypeDOList);
    }

    public Service4DynamicDO getClickedItem() {
        return clickedItem;
    }
}
