package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.TradeAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.TradeItem;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by LanBo on 16/03/24.
 */
public class TradeListActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener {
    TradeAdapter tradeAdapter;
    private static final int PAGE_SIZE = 10;
    private boolean isLoading = false;

    private int currentPage = 0;
    private String itemId;
    private List<TradeItem> tradeItemList = new ArrayList<>();
    private View headView;

    @Bind(android.R.id.list)
    ListView mListView;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.emptyView)
    ViewGroup emptyView;
    @Bind(R.id.description)
    TextView description;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_list);
        ButterKnife.bind(this);

        initActionBar(R.string.tab_title_trade, true);
        tradeAdapter = new TradeAdapter(this, tradeItemList);
        headView = getLayoutInflater().inflate(R.layout.item_trade_info, mListView, false);
        SimpleDraweeView avatar = (SimpleDraweeView) headView.findViewById(R.id.avatar);
        TextView nickname = (TextView) headView.findViewById(R.id.nickname);
        TextView price = (TextView) headView.findViewById(R.id.tradePrice);
        TextView quantity = (TextView) headView.findViewById(R.id.tradeQuantity);
        TextView date = (TextView) headView.findViewById(R.id.tradeDate);
        TextView time = (TextView) headView.findViewById(R.id.tradeTime);
        avatar.setVisibility(View.INVISIBLE);
        nickname.setText("昵称");
        price.setText("价格");
        quantity.setText("数量");
        date.setText("下单时间");
        time.setVisibility(View.GONE);
        mListView.addHeaderView(headView);
        mListView.setAdapter(tradeAdapter);
        mListView.setEmptyView(emptyView);
        description.setText(R.string.sell_count_none);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        mListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        loadData(itemId);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

        itemId = getIntent().getStringExtra("itemId");
    }

    public void onResume() {
        super.onResume();
        loadData(itemId);
    }

    private void loadData(String itemId) {
        if (isLoading) {
            return;
        }
        isLoading = true;
        JSONObject params = new JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", PAGE_SIZE);
        params.put("offset", currentPage * PAGE_SIZE);

        HttpClient.get("1.0/item/getTradeList", params, null,
                new HttpClient.HttpCallback<Object>() {
                    @Override
                    public void onSuccess(Object obj) {
                        isLoading = false;
                        mSwipeRefreshLayout.setRefreshing(false);
                        JSONArray data = (JSONArray) obj;
                        for (int i = 0; i < data.size(); i++) {
                            JSONObject item = data.getJSONObject(i);
                            TradeItem tradeItem = new TradeItem();
                            tradeItem.setAvatar(item.getString("avatar"));
                            tradeItem.setNick(item.getString("nick"));
                            tradeItem.setPrice(item.getString("price"));
                            tradeItem.setQuantity(item.getInteger("quantity"));
                            tradeItem.setTradeTime(item.getLong("tradeTime") * 1000);
                            tradeItemList.add(tradeItem);
                        }
                        if (!tradeItemList.isEmpty()) {
                            tradeAdapter.setTradeList(tradeItemList);
                            currentPage++;
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        isLoading = false;
                        mSwipeRefreshLayout.setRefreshing(false);
                    }
                });
    }

    @Override
    public void onRefresh() {
        currentPage = 0;
        tradeItemList.clear();
        loadData(itemId);
    }
}
