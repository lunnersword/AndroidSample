package com.meidalife.shz.adapter;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.facebook.common.util.UriUtil;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.backends.pipeline.PipelineDraweeController;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.common.ResizeOptions;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.util.ImgUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by taber on 15/6/11.
 */
public class ServiceGridAdapter extends BaseAdapter {
    private static final String LOG_TAG = "ServiceGridAdapter";
    public static int TYPE_SERVICE = 1;
    public static int TYPE_OTHER = 2;

    private static final int THREE = 3;

    private static final int TYPE_COUNT = 2;
    private static final int VIEW_TYPE_BUTTON = 1;
    private static final int VIEW_TYPE_IMAGE = 2;

    private final String EDITED_IMAGE_DIRECTORY;
    private static final String EDITED_IMAGE_PREFIX = "editedImage";

    private boolean canAdd;
    private int maxLength;

    private Activity mActivity;
    private int type;
    private List<String> mImages;
    private LayoutInflater mInflater;
    private OnClickListener mOnClickListener;
    private String currentSourceImage = null;

    static class ImageHolder {
        public SimpleDraweeView image;
        public TextView removeButton;
        public TextView imgIndex;
    }

    static class ButtonHolder {
        public RelativeLayout addButton;
        public TextView imgIndex;
    }

    public ServiceGridAdapter(Activity c, List<String> images, int max, int type) {
        mActivity = c;
        mImages = images;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        maxLength = max;
        this.type = type;
        checkCanAddItem();
        EDITED_IMAGE_DIRECTORY = ImgUtil.getEditedImagePath(c);
    }

    private void checkCanAddItem() {
        canAdd = mImages.size() < maxLength;
    }

    public void setOnClickListener(OnClickListener mOnClickListener) {
        this.mOnClickListener = mOnClickListener;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    public int getCount() {
        return canAdd ? mImages.size() + 1 : mImages.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public void notifyDataSetChanged() {
        checkCanAddItem();
        super.notifyDataSetChanged();
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(final int position, View convertView, ViewGroup parent) {

        if (canAdd && position == mImages.size()) {
            convertView = genPlusButtonView(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            ButtonHolder buttonHolder = (ButtonHolder) tag.get("holder");
            if (position < THREE) {
                buttonHolder.imgIndex.setVisibility(View.VISIBLE);
                if (type == TYPE_SERVICE) {
                    buttonHolder.imgIndex.setVisibility(View.VISIBLE);
                    buttonHolder.imgIndex.setText("封面" + (position + 1));
                } else {
                    buttonHolder.imgIndex.setVisibility(View.GONE);
                }
            } else {
                buttonHolder.imgIndex.setVisibility(View.GONE);
            }
            buttonHolder.addButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mOnClickListener != null) {
                        mOnClickListener.onAddClick(v, position);
                    }
                }
            });
        } else {
            convertView = genImageView(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            ImageHolder imageHolder = (ImageHolder) tag.get("holder");
            if (position < THREE) {
                imageHolder.imgIndex.setVisibility(View.VISIBLE);
                if (type == TYPE_SERVICE) {
                    imageHolder.imgIndex.setVisibility(View.VISIBLE);
                    imageHolder.imgIndex.setText("封面" + (position + 1));
                } else {
                    imageHolder.imgIndex.setVisibility(View.GONE);
                }
            } else {
                imageHolder.imgIndex.setVisibility(View.GONE);
            }
            imageHolder.removeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mOnClickListener != null) {
                        mOnClickListener.onRemoveClick(v, position);
                    }
                }
            });
            String path = mImages.get(position);
            if (TextUtils.isEmpty(path)) {
                Uri defaultImg = new Uri.Builder()
                        .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.pic_service_default)).build();
                imageHolder.image.setImageURI(defaultImg);
                imageHolder.removeButton.setVisibility(View.GONE);
            } else {
                Uri uri;
                if (path.matches("http://.*")) {
                    uri = Uri.parse(path);
                } else {
                    uri = Uri.fromFile(new File(path));
                }

                Glide.with(SHZApplication.getInstance()).load(uri).centerCrop().into(imageHolder.image);

                imageHolder.removeButton.setVisibility(View.VISIBLE);
            }

            imageHolder.image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mOnClickListener != null) {
                        mOnClickListener.onEditClick(v, position);
                    }
                }
            });

        }
        return convertView;
    }

    private View genPlusButtonView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.publish_plus_button, parent, false);
            ButtonHolder holder = new ButtonHolder();
            holder.addButton = (RelativeLayout) convertView.findViewById(R.id.plusButton);
            holder.imgIndex = (TextView) convertView.findViewById(R.id.img_index);
            HashMap tag = new HashMap();
            tag.put("type", VIEW_TYPE_BUTTON);
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != VIEW_TYPE_BUTTON) {
                return genPlusButtonView(null, parent);
            }
        }
        return convertView;
    }

    private View genImageView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.publish_grid_item_image, parent, false);
            ImageHolder holder = new ImageHolder();
            holder.image = (SimpleDraweeView) convertView.findViewById(R.id.serviceGridImage);
            holder.removeButton = (TextView) convertView.findViewById(R.id.removeImage);
            holder.imgIndex = (TextView) convertView.findViewById(R.id.img_index);
            HashMap tag = new HashMap();
            tag.put("type", VIEW_TYPE_IMAGE);
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != VIEW_TYPE_IMAGE) {
                return genImageView(null, parent);
            }
        }
        return convertView;
    }


//    @Override
//    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//        if (TextUtils.isEmpty(EDITED_IMAGE_DIRECTORY)) {
//            return;
//        }
//        currentSourceImage = mImages.get(position);
//        String outputPath = EDITED_IMAGE_DIRECTORY + File.separator + EDITED_IMAGE_PREFIX + "_" + position;
//        File outputFile = new File(outputPath);
//        if (outputFile.exists()) {
//            boolean result = outputFile.delete();
//            Log.d(LOG_TAG, "Delete previous edited images:" + result);
//        }
//        if (!TextUtils.isEmpty(currentSourceImage)) {
//            PGEditSDK.instance().startEdit(mActivity, PGEditActivity.class, currentSourceImage, outputPath);
//        }
//    }

//    public void handleEditImageResult(Intent data) {
//        PGEditResult editResult = PGEditSDK.instance().handleEditResult(data);
//        String resultPhotoPath = editResult.getReturnPhotoPath();
//        if (!TextUtils.isEmpty(currentSourceImage) && !TextUtils.isEmpty(resultPhotoPath)) {
//            for (int i = 0; i < mImages.size(); i++) {
//                if (currentSourceImage.equals(mImages.get(i))) {
//                    mImages.set(i, resultPhotoPath);
//                }
//            }
//        }
//        notifyDataSetChanged();
//    }

    public List<String> getImageList() {
        return mImages;
    }

    public interface OnClickListener {
        void onAddClick(View v, int position);

        void onEditClick(View v, int position);

        void onRemoveClick(View v, int position);
    }
}
