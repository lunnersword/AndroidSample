package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.SurroundSquareListAdapter;
import com.meidalife.shz.event.SquarePortalRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CityDO;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.PositionOutDO;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.util.CollectionUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 通过拖动地图位置  查看周边格子list
 * Created by zhq on 15/12/20.
 */
public class SurroundSquareListWithMapActivity extends BaseMapActivity implements
        AMap.OnCameraChangeListener, AMap.OnMarkerClickListener {

    private final static String TAG = "SurroundSquareListWithMap";

    List<SquareDO> resultList = new ArrayList<>();

    @Bind(R.id.locationLayout)
    ViewGroup locationLayout;
    @Bind(R.id.locationValue)
    TextView locationValue;
    @Bind(R.id.searchBar)
    ViewGroup searchBar;
//    @Bind(R.id.searchHint)
//    TextView searchHint;

    @Bind(R.id.rootView)
    RelativeLayout rootView;

    @Bind(R.id.recycler_view)
    RecyclerView recyclerView;

    @Bind(R.id.backButton)
    View backButton;

    //红包规则
    @Bind(R.id.createSquare)
    View createSquareButton;

    @Bind(R.id.location_position)
    View mImageArrow;

    @Bind(R.id.location_icon)
    View locationView;

    //格子为空 提示文案
    @Bind(R.id.squareListEmpty)
    View squareListEmpty;

    LinearLayoutManager linearLayoutManager;
    SurroundSquareListAdapter adapter;

    private static final int PAGE_SIZE = 20;
    //开始页数为1
    int page = 1;

    boolean isLoading = false;
    private boolean isComplete = false;

    private AMapLocationManager mLocationManager;
    private boolean needLocation = false;
    LocationDO mLocation = new LocationDO();
    LocationDO mCurrentLocation = new LocationDO();

//    private LoadUtil mLoadUtil;

    private LatLng mLastPosition;

    ArrayList<CityDO> cityList = null;
    Marker mMarker;


    @Override
    public int getLayoutResource() {
        return R.layout.activity_surround_square_list_with_map;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ButterKnife.bind(this);

        initAdapter();
        initListener();

//        mLoadUtil = new LoadUtil(getLayoutInflater());
        executeLocationMethod();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public void onEvent(SquarePortalRefreshEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType) {
            loadData();
        }
    }

    void executeLocationMethod() {
        initLocationData();
        if (mCurrentLocation != null) {
            mCurrentLocation.setCityCode(mLocation.getCityCode());
            mCurrentLocation.setCityName(mLocation.getCityName());
            mCurrentLocation.setLongitude(mLocation.getLongitude());
            mCurrentLocation.setLatitude(mLocation.getLatitude());
            addMark(mCurrentLocation.getLongitude(), mCurrentLocation.getLatitude(), "", "", true);

            updateLBSInfo(mCurrentLocation);
            loadData();
        } else {
            needLocation = true;
            getCurrentLbsLocation();
        }
    }


    @Override
    protected void onSetUpAMap() {
        super.onSetUpAMap();
        aMap.getUiSettings().setZoomControlsEnabled(false);
        aMap.setOnCameraChangeListener(this);

//        initLocationData();
//        if (mLocation != null) {
//            mCurrentLocation.setCityCode(mLocation.getCityCode());
//            mCurrentLocation.setCityName(mLocation.getCityName());
//            mCurrentLocation.setLongitude(mLocation.getLongitude());
//            mCurrentLocation.setLatitude(mLocation.getLatitude());
//            addMark(mCurrentLocation.getLongitude(), mCurrentLocation.getLatitude(), "", "", true);
//        }
    }

    void initLocationData() {
        mLocationManager = SHZApplication.getInstance().getLocationManager();
        mLocation = mLocationManager.getLocation();
    }

    void getCurrentLbsLocation() {
        mLocationManager.updateLocation(mLocationChangedListener);
    }

    private AMapLocationManager.LocationChangedListener mLocationChangedListener = new AMapLocationManager.LocationChangedListener() {

        @Override
        public void onLocationUpdateFailed() {
            needLocation = false;
        }

        @Override
        public void onLocationChanged(LocationDO location) {
            //mLocation = location;
            updateLBSInfo(location);

            //定位成功 重新请求数据
            loadData();

            if (needLocation) {
                needLocation = false;
            }

            LatLng currentLln = new LatLng(location.getLatitude(), location.getLongitude());
            if (mMarker != null) {
//                mMarker.remove();
                mMarker.setPosition(currentLln);
            }
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
            aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        }
    };

    void updateLBSInfo(LocationDO location) {
        if (location != null) {
            locationValue.setText(location.getCityName());
        } else {
            locationValue.setText("全国");
        }
    }

    private void initAdapter() {
//        adapter = new SurroundSquareAdapter(this, serviceItems);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

//        int spacingInPixels = getResources().getDimensionPixelSize(R.dimen.item_horizontal_margin);
//        recyclerView.addItemDecoration(new SurroundSquareDividerItemDecoration(spacingInPixels));
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
//        recyclerView.setAdapter(adapter);

        adapter = new SurroundSquareListAdapter(this, resultList);
        recyclerView.setAdapter(adapter);
    }

    private void initListener() {
        //返回键
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                mLocation = null;
                finish();
            }
        });

        //定位viewGroup
        locationLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CollectionUtil.isNotEmpty(cityList)) {
                    //todo jump to select city for square
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("cityList", cityList);
                    Router.sharedRouter().openFormResult("citylistforsquare", bundle, Constant.REQUEST_CODE_PICK_CITY, SurroundSquareListWithMapActivity.this);
                }
            }
        });
        //搜索Group
        searchBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("cityCode", mCurrentLocation.getCityCode());
                bundle.putString("lng", "" + mCurrentLocation.getLongitude());
                bundle.putString("lat", "" + mCurrentLocation.getLatitude());

                Router.sharedRouter().openFormResult("searchaddresssquare", bundle, Constant.REQUEST_CODE_PICK_ADDRESS, SurroundSquareListWithMapActivity.this);
            }
        });

        //创建格子button
        createSquareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("createSquare", SurroundSquareListWithMapActivity.this);
            }
        });
        //格子list滚动事件
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (linearLayoutManager.findLastCompletelyVisibleItemPosition() == (adapter.getItemCount() - 1)) {
                    xhrServices(false, false);
                }
            }
        });

        locationView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                needLocation = true;
//                getCurrentLbsLocation();
                if (mMarker != null) {
                    mMarker.remove();
                }
                executeLocationMethod();
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mLocationChangedListener = null;
        mLocation = null;
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constant.REQUEST_CODE_PICK_CITY) {
            if (resultCode == Activity.RESULT_OK) {
                Bundle extras = data.getExtras();
                CityDO mSelectCity = (CityDO) extras.getSerializable("cityDO");

                if (mSelectCity != null) {
                    locationValue.setText(mSelectCity.getCityName());
                    mCurrentLocation.setCityCode(mSelectCity.getCityCode());
                    mCurrentLocation.setLongitude(mSelectCity.getLongitude());
                    mCurrentLocation.setLatitude(mSelectCity.getLatitude());
                }

                //todo update location poi && request square list
                updateMarker(mCurrentLocation.getLongitude(), mCurrentLocation.getLatitude());
                isComplete = false;
                loadData();
            }
        } else if (requestCode == Constant.REQUEST_CODE_PICK_ADDRESS) {
            if (resultCode == Activity.RESULT_OK) {
                Bundle extras = data.getExtras();
                PositionOutDO mSelectPosition = (PositionOutDO) extras.getSerializable("positionDO");

                if (mSelectPosition != null) {
                    mCurrentLocation.setLongitude(mSelectPosition.getPoiLongitude());
                    mCurrentLocation.setLatitude(mSelectPosition.getPoiLatitude());
                }
//                Helper.sharedHelper().setStringUserInfo(Constant.SELECT_CITY_CODE, String.valueOf(selectCity));
//                Helper.sharedHelper().setStringUserInfo(Constant.SELECT_CITY_NAME, cityName);
                //todo update location poi && request square list
                updateMarker(mCurrentLocation.getLongitude(), mCurrentLocation.getLatitude());
                isComplete = false;
                loadData();
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }


    private JSONObject getParamsByPage(int page) {
        JSONObject params = new JSONObject();

        try {
            params.put("pageSize", PAGE_SIZE);
            params.put("offset", page * PAGE_SIZE);
            if (mCurrentLocation != null) {
                params.put("cityCode", mCurrentLocation.getCityCode());
                params.put("longitude", mCurrentLocation.getLongitude());
                params.put("latitude", mCurrentLocation.getLatitude());
            }
        } catch (JSONException e) {
            params = null;
        }
        return params;
    }


    private void loadData() {
        page = 0;
        isComplete = false;
        isLoading  = false;
        xhrServices(false, true);
    }

    private void xhrServices(boolean showLoading, final boolean refresh) {
        if (isLoading || isComplete) {
            return;
        }

        isLoading = true;
//        if (showLoading) {
//            mLoadUtil.loadPre(rootView, mSwipeRefreshLayout);
//        }

        requestData(refresh);
    }

    private void requestData(final boolean refresh) {
        HttpClient.get("1.1/gezi/surroundingGezis", getParamsByPage(page), JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                List<SquareDO> list = null;
                if (result != null) {
                    list = JSON.parseArray(result.getString("geziList"), SquareDO.class);
                    cityList = (ArrayList) JSON.parseArray(result.getString("cityList"), CityDO.class);

                    if (CollectionUtil.isEmpty(list) || list.size() < PAGE_SIZE) {
                        isComplete = true;
                    }
                }

                if (refresh) {
                    resultList.clear();
                }

                resultList.addAll(list);
                adapter.setData(resultList);
                adapter.notifyDataSetChanged();

                if (CollectionUtil.isEmpty(resultList)) {
                    squareListEmpty.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                } else {
                    squareListEmpty.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                }

                isLoading = false;
                page++;
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                page--;
            }
        });
    }


    private void addMark(Double Longitude, Double Latitude, String descripe, String snippet, boolean isZoom) {

        try {
            LatLng llA = new LatLng(Latitude, Longitude);
            MarkerOptions markerOption = new MarkerOptions();
            markerOption.position(llA);
            markerOption.title(descripe);
            markerOption.snippet(snippet);
            markerOption.anchor(0.5f, 1f);
            markerOption.draggable(true);
            if ("".equals(snippet))
                markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
            else
                markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
            mMarker = aMap.addMarker(markerOption.draggable(true));
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(llA));
            if (isZoom)
                aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateMarker(double Longitude, double Latitude) {

        try {
            LatLng currentLln = new LatLng(Latitude, Longitude);
            if (mMarker != null) {
                mMarker.setPosition(currentLln);
            }
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
            aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCameraChange(CameraPosition cameraPosition) {
        mImageArrow.setVisibility(View.VISIBLE);
    }

    /**
     * 对移动地图结束事件回调
     */
    @Override
    public void onCameraChangeFinish(CameraPosition cameraPosition) {

        TranslateAnimation animation = getVerticalTranslateAnimation();
        mImageArrow.setAnimation(animation);
        animation.startNow();
        onLocationChanged(cameraPosition.target);
    }

    private TranslateAnimation getVerticalTranslateAnimation() {
        TranslateAnimation animation = new TranslateAnimation(0, 0, 0, -20);
        animation.setInterpolator(new DecelerateInterpolator());
        animation.setDuration(200);//设置动画持续时间
        animation.setStartOffset(0);
        animation.setRepeatCount(1);//设置重复次数
        animation.setRepeatMode(Animation.REVERSE);//设置反方向执行
        return animation;
    }

    private void onLocationChanged(LatLng position) {
        if (mLastPosition != null
                && mLastPosition.equals(position)) {
            //Do not search same address again.
            return;
        }
        mLastPosition = position;
        if (mCurrentLocation != null) {
            mCurrentLocation.setLongitude(position.longitude);
            mCurrentLocation.setLatitude(position.latitude);
        }
        isComplete = false;
        loadData();
    }


    @Override
    public boolean onMarkerClick(Marker marker) {
        if (marker.getPosition().latitude >= 0 && marker.getPosition().longitude >= 0) {
            LatLng currentLln = new LatLng(marker.getPosition().latitude, marker.getPosition().longitude);
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
            aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        }
        return true;
    }
}
