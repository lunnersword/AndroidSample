package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.DynamicNewsOutDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.JobDO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 16/04/02.
 * 动态消息列表
 */
public class DynamicNewsAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    List<DynamicNewsOutDO> mData;
    private final int userAvatarMaxSize = 3;

    public static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.avatar)
        SimpleDraweeView avatar;

        @Bind(R.id.replay_type_text)
        ViewGroup replay_type_text;
        @Bind(R.id.nickView)
        public TextView nickView;
        @Bind(R.id.iconGender)
        TextView iconGender;
        @Bind(R.id.jobsViewGroup)
        LinearLayout jobsViewGroup;
        @Bind(R.id.jobTitleView)
        TextView jobTitleView;

        @Bind(R.id.bottomContentTextView)
        TextView bottomContentTextView;

        @Bind(R.id.replay_type_zan)
        ViewGroup replay_type_zan;
        @Bind(R.id.zan_avatar_recycler_view)
        RecyclerView zan_avatar_recycler_view;

        @Bind(R.id.zan_more_avatar_view)
        View moreZanView;
        @Bind(R.id.zan_count_view)
        TextView zan_count_view;

        @Bind(R.id.type_video_live)
        ViewGroup type_video_live;
        @Bind(R.id.coverImageView)
        SimpleDraweeView coverImageView;

        @Bind(R.id.type_video_finished)
        ViewGroup type_video_finished;
        @Bind(R.id.finishedImageView)
        SimpleDraweeView finishedImageView;

        @Bind(R.id.type_voice)
        View type_voice;

        @Bind(R.id.type_pic)
        SimpleDraweeView type_pic;

        @Bind(R.id.type_text)
        TextView type_text;

        @Bind(R.id.replay_time_text)
        TextView replay_time_text;
    }

    public DynamicNewsAdapter(Context context, List<DynamicNewsOutDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public DynamicNewsOutDO getItem(int position) {
        if (position - 1 >= 0 && position - 1 < mData.size()) {
            return mData.get(position - 1);
        }
        return null;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        DynamicNewsOutDO item = mData.get(position);

        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_dynamic_news, parent, false);
            ViewHolder holder = new ViewHolder(convertView);

            convertView.setTag(holder);
        }
        ViewHolder holder = (ViewHolder) convertView.getTag();
        //todo 需要一个字段标示动态是赞 还是普通文本回复
        if (true) {
            DynamicUserOutDO user = item.getUser();
            if (user != null) {
                // 加载动态用户信息
                holder.nickView.setText(user.getUserNick());
                String gender = "";
                // 设置服务者性别
                if (user.getUserGender() != null) {
                    holder.iconGender.setVisibility(View.VISIBLE);
                    if (user.getUserGender().equals("woman") || user.getUserGender().equals("F")) {
                        holder.iconGender.setText(mContext.getResources().getString(R.string.icon_female));
                        holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.color_icon_female));
                    } else {
                        holder.iconGender.setText(mContext.getResources().getString(R.string.icon_male));
                        holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.color_icon_male));
                    }
                } else {
                    holder.iconGender.setVisibility(View.GONE);
                }

                ViewGroup.LayoutParams avatarParams = holder.avatar.getLayoutParams();
                if (TextUtils.isEmpty(user.getAvatarUrl())) {
                    Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(user.getUserId()), gender);
                    holder.avatar.setImageURI(getDefaultAvatarUri);
                } else {
                    Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(user.getAvatarUrl(), avatarParams.width));
                    holder.avatar.setImageURI(uri);
                }

                holder.jobsViewGroup.removeAllViews();
                if (CollectionUtil.isNotEmpty(user.getJobs())) {
                    for (JobDO job : user.getJobs()) {
                        View jobView = mInflater.inflate(R.layout.item_dynamic_user_job, null);
                        SimpleDraweeView icon = (SimpleDraweeView) jobView.findViewById(R.id.avatar);
                        TextView titleView = (TextView) jobView.findViewById(R.id.title);
                        ViewGroup.LayoutParams iconParams = icon.getLayoutParams();

                        if (!TextUtils.isEmpty(job.getIconUrl())) {
                            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(user.getAvatarUrl(), iconParams.width));
                            icon.setImageURI(uri);
                            icon.setVisibility(View.VISIBLE);
                        } else {
                            icon.setImageURI(null);
                            icon.setVisibility(View.GONE);
                        }
                        titleView.setText(job.getTitle());
//        jobsView.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, context) * item.getGrade() / 5);
                        holder.jobsViewGroup.addView(jobView);
                    }
                    holder.jobsViewGroup.setVisibility(View.VISIBLE);
                } else {
                    holder.jobsViewGroup.removeAllViews();
                    holder.jobsViewGroup.setVisibility(View.GONE);
                }

                holder.jobTitleView.setText(user.getJobTitle());
            } else {
                holder.nickView.setText("");
                holder.iconGender.setText("");
                holder.avatar.setImageURI(null);
                holder.jobsViewGroup.removeAllViews();
                holder.jobTitleView.setText("");
            }
            holder.bottomContentTextView.setText(item.getContent());

            holder.replay_type_text.setVisibility(View.VISIBLE);
            holder.replay_type_zan.setVisibility(View.GONE);

        } else {
            holder.replay_type_text.setVisibility(View.GONE);
            holder.replay_type_text.setVisibility(View.VISIBLE);

            List<DynamicUserOutDO> list = item.getZanUserList();
            if (CollectionUtil.isNotEmpty(list)) {
                int end = Math.min(userAvatarMaxSize, list.size());
                list = list.subList(0, end);
                showUserAvatar(holder.zan_avatar_recycler_view, list);

                if (item.getZanUserList().size() > 3) {
                    holder.moreZanView.setVisibility(View.VISIBLE);
                } else {
                    holder.moreZanView.setVisibility(View.GONE);
                }
            } else {
                holder.zan_avatar_recycler_view.setVisibility(View.GONE);
                holder.moreZanView.setVisibility(View.GONE);
            }

            holder.zan_count_view.setText(String.format("%s人给你点赞", item.getFunsCount()));
        }

        //type : //0 图片，1 直播， 2 视频 ， 3 音频
        switch (item.getType()) {
            case 0:
                holder.type_video_finished.setVisibility(View.GONE);
                holder.type_video_live.setVisibility(View.GONE);
                holder.type_voice.setVisibility(View.GONE);

                if (CollectionUtil.isNotEmpty(item.getImageUrls())) {
                    Uri itemUri = Uri.parse(ImgUtil.getCDNUrlWithHeight(item.getImageUrls().get(0), holder.type_pic.getWidth()));
                    holder.type_pic.setImageURI(itemUri);

                    holder.type_pic.setVisibility(View.VISIBLE);
                    holder.type_text.setVisibility(View.GONE);
                    holder.type_text.setText("");
                } else {
                    holder.type_pic.setVisibility(View.VISIBLE);
                    holder.type_pic.setImageURI(null);
                    holder.type_text.setVisibility(View.GONE);
                    holder.type_text.setText(item.getFeedContent());
                }
                break;
            case 1:
                holder.type_pic.setVisibility(View.GONE);
                holder.type_text.setVisibility(View.GONE);
                holder.type_video_finished.setVisibility(View.GONE);
                holder.type_video_live.setVisibility(View.VISIBLE);
                holder.type_voice.setVisibility(View.GONE);
                break;
            case 2:
                holder.type_pic.setVisibility(View.GONE);
                holder.type_text.setVisibility(View.GONE);
                holder.type_video_finished.setVisibility(View.VISIBLE);
                holder.type_video_live.setVisibility(View.GONE);
                holder.type_voice.setVisibility(View.GONE);
                break;
            case 3:
                holder.type_pic.setVisibility(View.GONE);
                holder.type_text.setVisibility(View.GONE);
                holder.type_video_finished.setVisibility(View.GONE);
                holder.type_video_live.setVisibility(View.GONE);
                holder.type_voice.setVisibility(View.VISIBLE);
                break;
            default:
                holder.type_pic.setVisibility(View.GONE);
                holder.type_text.setVisibility(View.GONE);
                holder.type_video_finished.setVisibility(View.GONE);
                holder.type_video_live.setVisibility(View.GONE);
                holder.type_voice.setVisibility(View.GONE);
        }
        //todo 显示 留言发布时间

        return convertView;
    }

    public void showUserAvatar(RecyclerView recyclerView, List<DynamicUserOutDO> dataList) {

        recyclerView.removeAllViews();
        if (CollectionUtil.isEmpty(dataList)) {
            recyclerView.setVisibility(View.GONE);
            return;
        }
        recyclerView.setVisibility(View.VISIBLE);

        recyclerView.setHasFixedSize(true);

        final LinearLayoutManager layoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);


        recyclerView.setAdapter(new ZanUserAvatarAdapter(mContext, dataList));
    }
}
