package com.meidalife.shz.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.meidalife.shz.R;
import com.meidalife.shz.adapter.DynamicNewsAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicNewsOutDO;

import java.util.ArrayList;
import java.util.List;

/**
 * 动态消息列表
 *
 * @author zuozheng 16/04/04
 */
public class DynamicNewsListActivity extends BaseActivity {

    LinearLayout rootView;
    ListView listView;

    ArrayList newsList;
    DynamicNewsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_news_list);
        initActionBar("消息列表", true, false);

        newsList = new ArrayList();
        listView = (ListView) findViewById(R.id.listView);
        rootView = (LinearLayout) findViewById(R.id.root_view);
        adapter = new DynamicNewsAdapter(this, newsList);
        listView.setAdapter(adapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        xhrAddresses();
    }

    private void xhrAddresses() {
        showStatusLoading(rootView);
        hideStatusErrorServer();
        hideStatusErrorNetwork();

        //实现翻页
        HttpClient.get("1.0/timeline/news", null, DynamicNewsOutDO.class, new HttpClient.HttpCallback<List<DynamicNewsOutDO>>() {
            @Override
            public void onSuccess(List<DynamicNewsOutDO> result) {
                hideStatusLoading();
                listView.setVisibility(View.VISIBLE);
                newsList.clear();
                newsList.addAll(result);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrAddresses();
                        }
                    });
                } else if (error.getCode() == HttpError.ERR_CODE_NOT_LOGIN) {
                    finish();
                } else {
                    showStatusErrorServer(rootView);
                    if (!TextUtils.isEmpty(error.getMessage())) {
                        setTextErrorServer(error.getMessage());
                    }
                }
            }
        });
    }
}
