package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.WithdrawAccountDO;
import com.meidalife.shz.rest.request.RequestWithdraw;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

/**
 * Created by shijian on 15/7/20.
 */
public class WithdrawAccountActivity extends BaseActivity {

    private String accountId;

    private EditText realName;
    private EditText idCard;
    private EditText alipay;
    private EditText alipayRepeat;

    private ViewGroup rootView;
    private View contentRoot;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.money_withdraw_account);
        initActionBar(R.string.title_withdraw_account, true);

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);

        realName = (EditText) findViewById(R.id.account_real_name);
        idCard = (EditText) findViewById(R.id.account_id_card);
        alipay = (EditText) findViewById(R.id.account_alipay);
        alipayRepeat = (EditText) findViewById(R.id.account_alipay_repeat);

        Button commit = (Button) findViewById(R.id.account_commit);
        commit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String realNameV = realName.getText().toString();
                String idCardV = idCard.getText().toString();
                String alipayV = alipay.getText().toString();
                String alipayRepeatV = alipayRepeat.getText().toString();

                if (StrUtil.isEmpty(realNameV)) {
                    MessageUtils.showToastCenter("请填写姓名");
                    setFocus(realName);
                    return;
                }
                if (StrUtil.isEmpty(idCardV)) {
                    MessageUtils.showToastCenter("请填写身份证");
                    setFocus(idCard);
                    return;
                }
                if (StrUtil.isEmpty(alipayV)) {
                    MessageUtils.showToastCenter("请填写支付宝账户");
                    setFocus(alipay);
                    return;
                }
                if (StrUtil.isEmpty(alipayRepeatV)) {
                    MessageUtils.showToastCenter("请确认支付宝账户");
                    setFocus(alipayRepeat);
                    return;
                }
                if (!alipayV.trim().equals(alipayRepeatV.trim())) {
                    MessageUtils.showToastCenter("两次输入支付宝账户不一致，请检查");
                    setFocus(alipay);
                    return;
                }

                /*
                新增
                 */
                if (StrUtil.isEmpty(accountId)) {
                    RequestWithdraw.addAccount(realNameV, idCardV, alipayV, new HttpClient.HttpCallback<JSONObject>() {
                        @Override
                        public void onSuccess(JSONObject result) {
                            Router.sharedRouter().open("money_withdraw");
                            finish();
                        }

                        @Override
                        public void onFail(HttpError error) {
                            MessageUtils.showToastCenter(error.getMessage());
                        }
                    });
                }
                /*
                更新
                 */
                else {
                    RequestWithdraw.updateAccount(accountId, alipayV, new HttpClient.HttpCallback<JSONObject>() {
                        @Override
                        public void onSuccess(JSONObject result) {
                            Router.sharedRouter().open("money_withdraw");
                            finish();
                        }

                        @Override
                        public void onFail(HttpError error) {
                            MessageUtils.showToastCenter(error.getMessage());
                        }
                    });
                }
            }
        });

        // 获取accountId
        Bundle extras = getIntent().getExtras();
        Object aidObj = extras.get("accountId");
        if (extras != null && aidObj != null && !"null".equals((String) aidObj)) {
            accountId = (String) aidObj;
        }

        initLoadData();
    }

    public void initLoadData() {

        if (StrUtil.isEmpty(accountId))
            return;

        loadPre(rootView, contentRoot);
        RequestWithdraw.getAccount(accountId, new HttpClient.HttpCallback<WithdrawAccountDO>() {
            @Override
            public void onSuccess(WithdrawAccountDO account) {
                loadSuccess(contentRoot);
//                WithdrawAccountDO account = (WithdrawAccountDO) result;
                realName.setText(account.getRealName());
                realName.setFocusable(false);
                realName.setFocusableInTouchMode(false);
                realName.setTextColor(getResources().getColor(R.color.grey_c));
                idCard.setText(account.getIdCard());
                idCard.setFocusable(false);
                idCard.setFocusableInTouchMode(false);
                idCard.setTextColor(getResources().getColor(R.color.grey_c));
                alipay.setText(account.getAccount());
                alipayRepeat.setText(account.getAccount());
            }

            @Override
            public void onFail(HttpError error) {
                loadFail(error, rootView, WithdrawAccountActivity.this, new LoadCallback() {
                    @Override
                    public void execute() {
                        initLoadData();
                    }
                });
            }
        });
    }


    public void setFocus(EditText v) {
        v.setFocusable(true);
        v.requestFocus();
    }

}
