package com.meidalife.shz.activity;

/**
 * Created by shijian on 15/7/10.
 */

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ContactsAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ContactDO;
import com.meidalife.shz.rest.request.RequestContacts;
import com.meidalife.shz.view.CitySidebarView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CoinContactsActivity extends BaseActivity {

    private ViewGroup rootView;
    private ViewGroup contentRoot;
    private ViewGroup errorRoot;

    private ContactsAdapter mAdapter = null;
    private ListView listView = null;
    private SwipeRefreshLayout listSwipe;
    private TextView dialog;
    private EditText mSearchText = null;
    private CitySidebarView indexSidebar;

    private List<ContactDO> contactList;
    private List<Object> dataList;

    private ArrayList<HashMap<String, Object>> indexMapUpg = new ArrayList<>();

    private Context context;
    private LayoutInflater inflater;

    private InputMethodManager keyboard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.earn_mcoin_contacts);
        initActionBar(R.string.title_earn_mcoin_contacts, true);

        this.context = getApplicationContext();
        this.inflater = getLayoutInflater();
        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = (ViewGroup) findViewById(R.id.contacts_content_root);
        errorRoot = (ViewGroup) findViewById(R.id.contacts_error_root);

        if (!isContactsPrivilege()) { // 若无通讯录权限，显示错误页面

            contentRoot.setVisibility(View.GONE);
            errorRoot.setVisibility(View.VISIBLE);
            TextView iconPerson = (TextView) findViewById(R.id.contacts_error_icon_person);
            iconPerson.setTypeface(Helper.sharedHelper().getIconFont());

            View privilegeIntro = findViewById(R.id.contacts_privilege_intro);
            privilegeIntro.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", Constant.URL_CONTACTS_PRIVILEGE_INTRO);
                    Router.sharedRouter().open("web", bundle);
                }
            });

            return;
        }

        listView = (ListView) this.findViewById(R.id.contacts_list_view);
        listSwipe = (SwipeRefreshLayout) this.findViewById(R.id.contacts_list_swipe);

        dialog = (TextView) findViewById(R.id.contacts_dialog);
        mSearchText = (EditText) findViewById(R.id.contacts_search_text);

        listView.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (mSearchText.hasFocus())
                    mSearchText.clearFocus();
                return false;
            }
        });

        keyboard = (InputMethodManager) getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);

        //搜索框监听
        mSearchText.addTextChangedListener(new WatchToSearch());

        //下拉更新
        listSwipe.setProgressViewOffset(false, 150, 250);
        listSwipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSearchText.setText("");
                uploadContacts();
            }
        });

        // 加载数据
        initLoadContacts();
    }


    public void initLoadContacts() {
        loadPre(rootView, contentRoot);
        RequestContacts.get(null, new HttpClient.HttpCallback<List<ContactDO>>() {
            @Override
            public void onSuccess(List<ContactDO> result) {
                contactList = result;
                if (contactList.size() == 0) {
                    uploadContacts();
                } else {
                    loadSuccess(contentRoot);
                    showData(contactList);
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initLoadContacts();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initLoadContacts();
                        }
                    });
                }
            }
        });
    }

    private void showData(List<ContactDO> newContactList) {

        this.contactList = newContactList;
        this.indexMapUpg = new ArrayList<>();

        sort(contactList);
        dataList = addIndex(contactList);

        indexSidebar = initSlidebarView(indexMapUpg);

        mAdapter = new ContactsAdapter(inflater, context, dataList);
        listView.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();
    }

    private void uploadContacts() {
        Map<String, String> contacts = loadContacts();
        RequestContacts.get(contacts, new HttpClient.HttpCallback<List<ContactDO>>() {
            @Override
            public void onSuccess(List<ContactDO> result) {
                loadSuccess(contentRoot);
                listSwipe.setRefreshing(false);
                showData(result);
            }

            @Override
            public void onFail(HttpError error) {
                listSwipe.setRefreshing(false);
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            uploadContacts();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            uploadContacts();
                        }
                    });
                }
            }
        });
    }


    class WatchToSearch implements TextWatcher {

        String searchStr = "";

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            searchStr = mSearchText.getText().toString();

            if (searchStr.length() != 0) {
                indexSidebar.setVisibility(View.INVISIBLE);
                List<Object> searchRes = checkSearchStr(searchStr);
                mAdapter = new ContactsAdapter(inflater, context, searchRes);
                listView.setAdapter(mAdapter);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

            if (searchStr.length() == 0) {
                indexSidebar.setVisibility(View.VISIBLE);
                mAdapter = new ContactsAdapter(inflater, context, dataList);
                listView.setAdapter(mAdapter);
                keyboard.hideSoftInputFromInputMethod(mSearchText.getWindowToken(), 0);
            }
            mSearchText.requestFocus();
        }


        public List<Object> checkSearchStr(String search) {

            List<Object> searchList = new ArrayList<>();
            List<Integer> needRemoveIndex = new ArrayList<>();

            //当输入的搜索字符为字母时
            if (search.matches("[a-zA-Z]+")) {
                for (int j = 0; j < contactList.size(); j++) {
                    ContactDO c = (ContactDO) contactList.get(j);
                    String spell = c.getSpell();
                    boolean isHint = false;
                    for (int i = 0; i < search.length(); i++) {
                        String tempChar = String.valueOf(search.charAt(i)).toUpperCase();
                        if (spell.contains(tempChar)) {
                            isHint = true;
                            continue;
                        }
                    }
                    if (!isHint) {
                        needRemoveIndex.add(j);
                    }
                }
                remove(contactList, searchList, needRemoveIndex);
            }


            //当输入的搜索字符为汉字时
            else if (search.matches("[\u4e00-\u9fa5]+")) {
                for (int j = 0; j < contactList.size(); j++) {
                    ContactDO c = (ContactDO) contactList.get(j);
                    String name = c.getName();
                    boolean isHint = false;
                    for (int i = 0; i < search.length(); i++) {
                        String tempChar = search.substring(i, i + 1);
                        if (name.contains(tempChar)) {
                            isHint = true;
                            continue;
                        }
                    }
                    if (!isHint) {
                        needRemoveIndex.add(j);
                    }
                }
                remove(contactList, searchList, needRemoveIndex);
            }

            // 未知字符，显示#数据
            else {
                String key = (String) indexMapUpg.get(0).get("name");
                int position = (Integer) indexMapUpg.get(1).get("position");
                if ("#".equals(key) && position > 0) {
                    for (int i = 0; i < position - 1; i++) {
                        searchList.add(contactList.get(i));
                    }
                }
            }

            return searchList;
        }
    }


    public void remove(List<ContactDO> contactList, List<Object> searchList, List<Integer> removeIndex) {
        for (int i = 0; i < contactList.size(); i++) {
            if (removeIndex.contains(i)) continue;
            searchList.add(contactList.get(i));
        }
    }


    public void sort(List<ContactDO> contactList) {
        for (int i = 0; i < contactList.size(); i++) {
            for (int j = i + 1; j < contactList.size(); j++) {
                ContactDO ci = contactList.get(i);
                int cii = ci.getSpell().charAt(0);
                if (cii < 65 || cii > 90) {
                    break;  // 若cii不是字母，直接跳出比较，放在前面
                }
                ContactDO cj = contactList.get(j);
                int cji = cj.getSpell().charAt(0);
                if ((cii > cji) || (cji < 65 || cji > 90)) {
                    contactList.set(i, cj);
                    contactList.set(j, ci);
                }
            }
        }
    }

    public List<Object> addIndex(List<ContactDO> contactList) {
        Set<String> indexMap = new HashSet<>();
        List<Object> result = new ArrayList<>();
        for (ContactDO c : contactList) {
            String key = null;
            char v = c.getSpell().charAt(0);
            if (65 <= v && v <= 90) {
                key = String.valueOf(v);
            } else {
                key = "#";  // 非字母，统一用#表示
            }
            if (!indexMap.contains(key)) {
                indexMap.add(key);
                result.add(key);
                HashMap<String, Object> index = new HashMap<>();
                index.put("position", result.size() - 1);
                index.put("name", key);
                indexMapUpg.add(index);
            }
            result.add(c);
        }
        return result;
    }


    /**
     * 参考：http://blog.csdn.net/u010800530/article/details/39455347
     *
     * @return
     */
    public Map<String, String> loadContacts() {

        Map<String, String> contacts = new HashMap<>();

        ContentResolver reslover = getApplicationContext().getContentResolver();
        Cursor cursor = reslover.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        while (cursor.moveToNext()) {

            //联系人ID
            String id = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.Contacts._ID));
            //联系人姓名
            String name = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.Contacts.DISPLAY_NAME));
            //手机号码
            Cursor phone = reslover.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=" + id, null, null);

            while (phone.moveToNext()) {
                int phoneFieldColumnIndex = phone.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                String phoneNumber = phone.getString(phoneFieldColumnIndex);
                contacts.put(phoneNumber, name);
            }
            phone.close();
        }
        cursor.close();

        return contacts;
    }

    public boolean isContactsPrivilege() {
        try {
            ContentResolver reslover = getApplicationContext().getContentResolver();
            Cursor cursor = reslover.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
            boolean flag = cursor.moveToNext();
            cursor.close();
            return flag;
        } catch (Exception e) {
            Log.e(CoinContactsActivity.class.getName(), "get contacts fail, may not have permissions", e);
            return false;
        }
    }


    private CitySidebarView initSlidebarView(final ArrayList data) {
        CitySidebarView sidebarView = new CitySidebarView(CoinContactsActivity.this);
        sidebarView.setLabels(data);
        sidebarView.setTextView(dialog);
        sidebarView.setOnTouchingLetterChangedListener(new CitySidebarView.OnTouchingLetterChangedListener() {
            @Override
            public void onTouchingLetterChanged(String s, int index) {
                HashMap item = (HashMap) data.get(index);
                int position = (int) item.get("position");
                if (position != -1) {
                    listView.setSelection(position);
                }
            }
        });
        int height = data.size() * (int) Helper.convertDpToPixel(25, context);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((int) Helper.convertDpToPixel(25, context), height);
        params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
        params.topMargin = (int) Helper.convertDpToPixel(60, context);
        params.bottomMargin = (int) Helper.convertDpToPixel(100, context);
        contentRoot.addView(sidebarView, params);
        return sidebarView;
    }

}
