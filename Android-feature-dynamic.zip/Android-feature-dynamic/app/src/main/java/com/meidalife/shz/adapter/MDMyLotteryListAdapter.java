package com.meidalife.shz.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.WinningDetailActivity;
import com.meidalife.shz.event.LotteryListRefreshEvent;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.request.RequestLotteryList;
import com.meidalife.shz.util.CountDownTimerUtils;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.view.FontTextView;
import com.usepropeller.routable.Router;

import java.util.HashMap;
import java.util.List;

import de.greenrobot.event.EventBus;

/**
 * Created by liujian on 16/1/20.
 */
public class MDMyLotteryListAdapter extends BaseAdapter implements View.OnClickListener {
    private Context context;
    private List<RequestLotteryList.LotteryOrder> lotteryOrders;
    private LayoutInflater inflater;
    private onDataChangeListener onDataChangeListener;

    public MDMyLotteryListAdapter(Context context, List<RequestLotteryList.LotteryOrder> lotteryOrders) {
        this.context = context;
        this.lotteryOrders = lotteryOrders;
        this.inflater = LayoutInflater.from(context);
    }

    public void setOnDataChangeListener(MDMyLotteryListAdapter.onDataChangeListener onDataChangeListener) {
        this.onDataChangeListener = onDataChangeListener;
    }

    @Override
    public int getCount() {
        return lotteryOrders.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_my_lottery_list, parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else
            holder = (ViewHolder) convertView.getTag();
        final RequestLotteryList.LotteryOrder lotteryOrder = lotteryOrders.get(position);
        if (lotteryOrder.getPicUrl() != null)
            holder.picView.setImageURI(Uri.parse(lotteryOrder.getPicUrl()));
        holder.title.setText(lotteryOrder.getTitle());
        holder.winningLayout.setVisibility(View.GONE);
        holder.ingLayout.setVisibility(View.GONE);
        holder.announcingLayout.setVisibility(View.GONE);
        holder.winLine.setVisibility(View.INVISIBLE);
        //todo  状态唯一性 只能有一种情况
        if (lotteryOrder.getStatus() == RequestLotteryList.ORDER_STATUS_WINING   //已中奖
                || lotteryOrder.getStatus() == RequestLotteryList.ORDER_STATUS_ANNOUNCE) {  //未中奖
            holder.winningLayout.setVisibility(View.VISIBLE);
            holder.orderNoLayout.setVisibility(View.VISIBLE);
            holder.failedStatus.setVisibility(View.GONE);
            holder.timeLayout.setVisibility(View.VISIBLE);
            holder.announceText.setText("揭晓时间: ");
            if (lotteryOrder.getStatus() == RequestLotteryList.ORDER_STATUS_WINING) {
                holder.status.setText("已中奖");
                holder.status.setTextColor(context.getResources().getColor(R.color.brand_b));
                holder.winLine.setVisibility(View.VISIBLE);
            } else {
                holder.status.setText("未中奖");
                holder.status.setTextColor(context.getResources().getColor(R.color.brand_c));
            }
            holder.luckyCode.setText(lotteryOrder.getLuckyCode());
            holder.participateCount.setText(lotteryOrder.getJoinCount() + "");
            holder.announceTime.setTextColor(context.getResources().getColor(R.color.grey_b));
            holder.announceTime.setText(DateUtils.time2StringShort1(lotteryOrder.getAnnounceTime()));
        }
        if (lotteryOrder.getStatus() == RequestLotteryList.ORDER_STATUS_DOING) {  //进行中
            holder.ingLayout.setVisibility(View.VISIBLE);
            holder.status.setText("进行中");
            holder.status.setTextColor(context.getResources().getColor(R.color.brand_c));
            int progress = 0;
            if (lotteryOrder.getQuantity() != 0) {
                progress = (int) (lotteryOrder.getParticipateCount() * 100 / lotteryOrder.getQuantity());
                if (lotteryOrder.getParticipateCount() != 0 && progress == 0)
                    progress = 1;
            }
            holder.progressCount.setText(progress + "%");
            holder.progressBar.setProgress(progress);
            holder.ingParticipateCount.setText(lotteryOrder.getJoinCount() + "");
        }
        if (lotteryOrder.getStatus() == RequestLotteryList.ORDER_STATUS_FAILED //启动失败
                || lotteryOrder.getStatus() == RequestLotteryList.ORDER_STATUS_DISORDER) {  //参与失败
            holder.winningLayout.setVisibility(View.VISIBLE);
            if (lotteryOrder.getStatus() == RequestLotteryList.ORDER_STATUS_FAILED) {
                holder.status.setText("启动失败");
                holder.timeLayout.setVisibility(View.VISIBLE);
                holder.announceText.setText("失败时间: ");
                holder.announceTime.setTextColor(context.getResources().getColor(R.color.grey_b));
                holder.announceTime.setText(DateUtils.time2StringShort1(lotteryOrder.getEndTime()));
            } else {
                holder.status.setText("参与失败");
                holder.timeLayout.setVisibility(View.VISIBLE);
            }
            holder.status.setTextColor(context.getResources().getColor(R.color.brand_c));
            holder.orderNoLayout.setVisibility(View.GONE);
            holder.failedStatus.setVisibility(View.VISIBLE);
            holder.failedStatus.setText(lotteryOrder.getRefundText());
            holder.participateCount.setText(lotteryOrder.getJoinCount() + "");
        }
        if (lotteryOrder.getStatus() == RequestLotteryList.ORDER_STATUS_ANNOUNCEING) {  //揭晓中
            holder.announcingLayout.setVisibility(View.VISIBLE);
            holder.status.setText("揭晓中");
            holder.status.setTextColor(context.getResources().getColor(R.color.brand_b));
            CountDownTimerUtils.newInstance().setCountDownTimerView(lotteryOrder, holder.countdown);
            holder.announceParticipateCount.setText(lotteryOrder.getJoinCount() + "");
        }
        if (lotteryOrder.getStatus() == RequestLotteryList.ORDER_STATUS_PAY) {  //待支付
            holder.winningLayout.setVisibility(View.VISIBLE);
            holder.timeLayout.setVisibility(View.VISIBLE);
            holder.status.setText("待支付");
            holder.status.setTextColor(context.getResources().getColor(R.color.brand_b));
            holder.orderNoLayout.setVisibility(View.GONE);
            holder.failedStatus.setVisibility(View.VISIBLE);
            holder.failedStatus.setText("5分钟后将关闭订单");
            holder.announceText.setText("费用合计: ");
            holder.participateCount.setText(lotteryOrder.getJoinCount() + "");
            holder.announceTime.setTextColor(context.getResources().getColor(R.color.brand_b));
            holder.announceTime.setText(lotteryOrder.getJoinCount() + "元");
        }
        addActionBtn(holder, lotteryOrder);
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lotteryOrder.getDetailUrl() != null && lotteryOrder.getDetailUrl().contains("http://")) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", lotteryOrder.getDetailUrl());
                    Router.sharedRouter().open("web", bundle);
                    //  刷新列表页
                    if (onDataChangeListener != null)
                        onDataChangeListener.onDataChange(true);
                }
            }
        });

        return convertView;
    }

    private void addActionBtn(ViewHolder holder, RequestLotteryList.LotteryOrder lotteryOrder) {
        holder.lotteryActionList.removeAllViews();
        List<Object[]> actionList = RequestLotteryList.getLotteryActionList(lotteryOrder.getAction());
        if (actionList.size() == 0) {
            holder.lotteryActionline.setVisibility(View.GONE);
            holder.lotteryActionList.setVisibility(View.GONE);
            return;
        } else {
            holder.lotteryActionline.setVisibility(View.VISIBLE);
            holder.lotteryActionList.setVisibility(View.VISIBLE);
        }
        for (int i = 0; i < actionList.size(); i++) {
            TextView bt = new FontTextView(context);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) Helper.convertDpToPixel(70, context),
                    (int) Helper.convertDpToPixel(30, context));
            params.setMargins(0, 0, (int) Helper.convertDpToPixel(10, context), 0);
            bt.setLayoutParams(params);
            bt.setGravity(Gravity.CENTER);
            bt.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
            Object[] data = actionList.get(i);
            if ((int) data[2] == 0) {
                bt.setTextColor(context.getResources().getColor(R.color.grey_a));
                bt.setBackgroundResource(R.drawable.order_list_edit_bg_white);
            } else {
                bt.setTextColor(context.getResources().getColor(R.color.brand_b));
                bt.setBackgroundResource(R.drawable.order_list_edit_bg_red);
            }
            bt.setText((String) data[1]);
            HashMap<String, Object> hashMap = new HashMap<String, Object>();
            hashMap.put("data", lotteryOrder);
            hashMap.put("action", data[0]);
            bt.setTag(hashMap);
            bt.setOnClickListener(this);
            holder.lotteryActionList.addView(bt);
        }
    }

    @Override
    public void onClick(View v) {
        HashMap<String, Object> hashMap = (HashMap<String, Object>) v.getTag();
        final RequestLotteryList.LotteryOrder lotteryOrder = (RequestLotteryList.LotteryOrder) hashMap.get("data");
        Long action = (Long) hashMap.get("action");
        if (action == RequestLotteryList.ORDER_ACTION_DETAIL) {  //中奖详情
            Intent intent = new Intent(context, WinningDetailActivity.class);
            intent.putExtra("itemId", lotteryOrder.getItemId() + "");
            context.startActivity(intent);
        }
        if (action == RequestLotteryList.ORDER_ACTION_SURE) {  //确认服务
            MessageUtils.createDialog(context, "是否确认服务完成?", "确认后将不可更改", R.string.confirm, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    sureOrder(lotteryOrder.getItemId());
                }
            }, R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            }).show();
        }
        if (action == RequestLotteryList.ORDER_ACTION_ADD) {   //追加
            if (lotteryOrder.getDetailUrl() != null && lotteryOrder.getDetailUrl().contains("http://")) {
                Bundle bundle = new Bundle();
                bundle.putString("url", lotteryOrder.getDetailUrl());
                Router.sharedRouter().open("web", bundle);
                if (onDataChangeListener != null)
                    onDataChangeListener.onDataChange(true);
            }
        }
        if (action == RequestLotteryList.ORDER_ACTION_CHECK_REFUND) {  //查看退款
            Router.sharedRouter().open("orderPayDetail/" + lotteryOrder.getOrderNo());
        }
        if (action == RequestLotteryList.ORDER_ACTION_PAY) {   //立即支付
            Bundle bundle = new Bundle();
            bundle.putString("orderNo", lotteryOrder.getOrderNo());
            bundle.putString("title", lotteryOrder.getTitle());
            Router.sharedRouter().open("pay", bundle);
            //  刷新列表页
            if (onDataChangeListener != null)
                onDataChangeListener.onDataChange(true);
        }
    }

    private void sureOrder(int itemId) {
        JSONObject params = new JSONObject();
        params.put("itemId", itemId);
        HttpClient.get("1.0/duobao/confirmService", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                LotteryListRefreshEvent event = new LotteryListRefreshEvent();
                EventBus.getDefault().post(event);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "确定失败，请稍后再试");
            }
        });
    }

    static class ViewHolder {
        TextView title;
        SimpleDraweeView picView;
        TextView luckyCode;
        TextView participateCount;
        TextView announceTime;
        TextView status;
        View winningLayout;
        LinearLayout lotteryActionList;
        View lotteryActionline;
        View ingLayout;
        TextView progressCount;
        ProgressBar progressBar;
        TextView ingParticipateCount;
        View orderNoLayout;
        TextView failedStatus;
        TextView announceText;
        View announcingLayout;
        TextView countdown;
        TextView announceParticipateCount;
        View winLine;
        View timeLayout;

        public ViewHolder(View convertView) {
            announceTime = (TextView) convertView.findViewById(R.id.announceTime);
            title = (TextView) convertView.findViewById(R.id.title);
            luckyCode = (TextView) convertView.findViewById(R.id.luckyCode);
            participateCount = (TextView) convertView.findViewById(R.id.participateCount);
            picView = (SimpleDraweeView) convertView.findViewById(R.id.picView);
            status = (TextView) convertView.findViewById(R.id.status);
            winningLayout = convertView.findViewById(R.id.winningLayout);
            lotteryActionList = (LinearLayout) convertView.findViewById(R.id.lottery_opr_bt_list);
            lotteryActionline = convertView.findViewById(R.id.lottery_opr_line);
            ingLayout = convertView.findViewById(R.id.ingLayout);
            progressCount = (TextView) convertView.findViewById(R.id.progressCount);
            progressBar = (ProgressBar) convertView.findViewById(R.id.progressBar);
            ingParticipateCount = (TextView) convertView.findViewById(R.id.ingParticipateCount);
            orderNoLayout = convertView.findViewById(R.id.orderNoLayout);
            failedStatus = (TextView) convertView.findViewById(R.id.failedStatus);
            announceText = (TextView) convertView.findViewById(R.id.announceText);
            announcingLayout = convertView.findViewById(R.id.announcingLayout);
            countdown = (TextView) convertView.findViewById(R.id.countdown);
            announceParticipateCount = (TextView) convertView.findViewById(R.id.announceParticipateCount);
            winLine = convertView.findViewById(R.id.winLine);
            timeLayout = convertView.findViewById(R.id.timeLayout);
        }
    }

    public interface onDataChangeListener {
        void onDataChange(boolean dataChange);
    }
}
