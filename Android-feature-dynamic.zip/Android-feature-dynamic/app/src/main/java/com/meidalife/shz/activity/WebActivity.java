package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.lzyzsd.jsbridge.BridgeHandler;
import com.github.lzyzsd.jsbridge.BridgeWebView;
import com.github.lzyzsd.jsbridge.CallBackFunction;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareAddressOutDO;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.meidalife.shz.widget.SocialSharePopupWindow.SocialContent;
import com.meidalife.shz.widget.TutorialPopupWindow;
import com.meidalife.shz.widget.VideoEnabledWebChromeClient;
import com.meidalife.shz.widget.VideoEnabledWebView;
import com.squareup.okhttp.Headers;
import com.umeng.socialize.media.UMImage;
import com.usepropeller.routable.Router;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class WebActivity extends BaseActivity {

    int SIGNIN_REQUEST_CODE = 100;
    int PAY_REQUEST_CODE = 101;

    VideoEnabledWebView webView;
    VideoEnabledWebChromeClient webChromeClient;
    TextView webBack;
    TextView webForward;
    TextView webShare;

    private String url;
    private SquareAddressOutDO squareAddress;
    private String mCityCode;
    private SocialSharePopupWindow socialSharePopupWindow;
    private ShareActivity shareActivity;
    private TutorialPopupWindow tutorialPopupWindow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().requestFeature(Window.FEATURE_PROGRESS);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        initActionBar(R.string.title_activity_loading, true, true);
        Bundle intentExtras = getIntent().getExtras();
        url = intentExtras.getString("url");
        mCityCode = intentExtras.getString("cityCode");
        squareAddress = (SquareAddressOutDO) intentExtras.getSerializable("squareAddress");

        if (TextUtils.isEmpty(url)) {
            MessageUtils.showToastCenter("url is null, please check");
            finish();
            return;
        }

        synCookies(url);

        webView = (VideoEnabledWebView) findViewById(R.id.webView);
        View nonVideoLayout = findViewById(R.id.nonVideoLayout);
        ViewGroup videoLayout = (ViewGroup) findViewById(R.id.videoLayout);
        //noinspection all
        View loadingView = getLayoutInflater().inflate(R.layout.status_loading, null);
        webView.getSettings().setUserAgentString(formatWebViewUserAgent(webView));
        webChromeClient = new VideoEnabledWebChromeClient(nonVideoLayout, videoLayout, loadingView, webView) {
            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                setActionBarTitle(title);
            }

            public void onProgressChanged(WebView view, int progress) {
                // Activities and WebViews measure progress with different scales. The progress meter will automatically disappear when we reach 100%
                WebActivity.this.setProgress(progress * 1000);
            }
        };
        webChromeClient.setOnToggledFullscreen(new VideoEnabledWebChromeClient.ToggledFullscreenCallback() {
            @Override
            public void toggledFullscreen(boolean fullscreen) {
                // Your code to handle the full-screen change, for example showing and hiding the title bar. Example:
                if (fullscreen) {
                    WindowManager.LayoutParams attrs = getWindow().getAttributes();
                    attrs.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
                    attrs.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    getWindow().setAttributes(attrs);
                    if (android.os.Build.VERSION.SDK_INT >= 14) {
                        //noinspection all
                        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE);
                    }
                } else {
                    WindowManager.LayoutParams attrs = getWindow().getAttributes();
                    attrs.flags &= ~WindowManager.LayoutParams.FLAG_FULLSCREEN;
                    attrs.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    getWindow().setAttributes(attrs);
                    if (android.os.Build.VERSION.SDK_INT >= 14) {
                        //noinspection all
                        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                    }
                }

            }
        });

        webView.setWebChromeClient(webChromeClient);

        webView.setWebViewClientListener(new BridgeWebView.WebViewClientListener() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (!TextUtils.isEmpty(url) && url.endsWith(".apk")) {
                    try {
                        Uri uri = Uri.parse(url);
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return false;
                }
                handleUrl(view, url, false);
                return true;    //返回值是true的时候控制去WebView打开，为false调用系统浏览器或第三方浏览器
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                registerHandler();
                String headers = getHeaders();
                webView.loadUrl("javascript: if(window.Tracker){window.Tracker.inject(" + headers + ")};");
            }
        });


        // 清楚webview缓存
        webView.clearHistory();
        webView.clearFormData();
        webView.clearCache(true);
        WebSettings webSettings = webView.getSettings();
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAppCacheEnabled(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setSaveFormData(true);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            if (webView.getContext().getExternalCacheDir() != null) {
                webView.getSettings().setDatabasePath(webView.getContext().getExternalCacheDir().getAbsolutePath());
            }
        }

        // 处理前进后退
        webBack = (TextView) findViewById(R.id.webview_back);
        webForward = (TextView) findViewById(R.id.webview_forward);
        webShare = (TextView) findViewById(R.id.webview_share);
        handViewBackAndForward();

        mButtonRight.setText(R.string.icon_close);
        mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        handleUrl(webView, url, true);
    }

    @Override
    public void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        webView.onPause();
    }


    private void registerHandler() {
        webView.registerHandler("tracker", new BridgeHandler() {
            @Override
            public void handler(String data, CallBackFunction function) {
                LogParam param = new LogParam();
                param.setType(LogUtil.TYPE_H5_TO_NATIVE);
                param.setPid(WebActivity.this.getClass().getName());
                param.setH5Param(data);
                LogUtil.log(param);
            }
        });

        webView.registerHandler("initShare", new BridgeHandler() {

            @Override
            public void handler(String data, CallBackFunction function) {
                initShareList(data);
            }
        });

        webView.registerHandler("hideNativeShare", new BridgeHandler() {

            @Override
            public void handler(String data, CallBackFunction function) {
                hideSocialShareIcon();
            }
        });

        webView.registerHandler("showNativeShare", new BridgeHandler() {

            @Override
            public void handler(String data, CallBackFunction function) {
                showSocialShareIcon();
            }
        });

        webView.registerHandler("showShare", new BridgeHandler() {

            @Override
            public void handler(String data, CallBackFunction function) {
                showShareList();
            }
        });

        webView.registerHandler("square:applyFinish", new BridgeHandler() {

            @Override
            public void handler(String data, CallBackFunction function) {
                applySquare();
            }
        });

        //一元夺宝 支付
        webView.registerHandler("payOrder", new BridgeHandler() {

            @Override
            public void handler(String data, CallBackFunction function) {

                Log.d("payOrderCallBack", data.toString());

                com.alibaba.fastjson.JSONObject json = JSON.parseObject(data);

                if (json.containsKey("orderNo")) {
                    Bundle bundle = new Bundle();
                    bundle.putString("orderNo", json.getString("orderNo"));
//                    bundle.putString("title", json.getString("title"));
                    Router.sharedRouter().openFormResult("pay", bundle, PAY_REQUEST_CODE, WebActivity.this);
//                    finish();
                }
            }
        });

        webView.registerHandler("enableForceRefresh", new BridgeHandler() {

            @Override
            public void handler(String data, CallBackFunction function) {
                webView.reload();
            }
        });
        webView.registerHandler("disableForceRefresh", new BridgeHandler() {

            @Override
            public void handler(String data, CallBackFunction function) {

            }
        });

        webView.registerHandler("hideRefresh", new BridgeHandler() {

            @Override
            public void handler(String data, CallBackFunction function) {

            }
        });
    }

    private void handleUrl(WebView view, String url, boolean close) {
        // 内部唤醒
        Uri parseUri = null;

        String id = null;
        try {
            parseUri = Uri.parse(url);
            id = parseUri.getQueryParameter("id");
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (parseUri == null) {
            finish();
            MessageUtils.showToast(String.format(getString(R.string.err_url_invalid), url));
            return;
        }

        if ("intent".equals(parseUri.getScheme()) || "imlifer".equals(parseUri.getScheme())) {
            try {
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                if (intent.getScheme().equals("imlifer")) {
                    Uri uri = intent.getData();
                    if (uri != null) {
                        String host = uri.getHost();
                        String path = uri.getPath();
                        if (host.equals("login")) {
                            Router.sharedRouter().openFormResult(host + path, SIGNIN_REQUEST_CODE, WebActivity.this);
                        } else {
                            Router.sharedRouter().openFormResult(host + path, WebActivity.this);
                        }
                    }
                } else {
                    WebActivity.this.startActivity(intent);
                }
                if (close) {
                    finish();
                }
            } catch (Exception e) {
                e.printStackTrace();
                MessageUtils.showToast(String.format(getString(R.string.err_url_invalid), url));
            }
        }
        // 支付宝授权回调
        else if (url.startsWith("http://www.shenghuozhe.net/events/app_zmxy_callback.html")) {
            HttpClient.get("1.0/user/updateAuth", null, String.class, new HttpClient.HttpCallback<String>() {
                @Override
                public void onSuccess(String obj) {
                    finish();
                }

                @Override
                public void onFail(HttpError error) {
                    Log.e(WebActivity.class.getName(), "zm auth call, update auth fail, info : " + error.toString());
                }
            });
        } else if (!TextUtils.isEmpty(parseUri.getAuthority())
                && (parseUri.getAuthority().contains(Constant.MAIN_DOMAIN_KONGGE)
                || parseUri.getAuthority().contains(Constant.MAIN_DOMAIN_SHENGHUOZHE))
                && !TextUtils.isEmpty(id)
                && !TextUtils.isEmpty(parseUri.getPath())
                && parseUri.getPathSegments().contains("user.html")) {
            Router.sharedRouter().open("profile/" + id);
            finish();
        } else if (!TextUtils.isEmpty(parseUri.getAuthority())
                && (parseUri.getAuthority().contains(Constant.MAIN_DOMAIN_KONGGE)
                || parseUri.getAuthority().contains(Constant.MAIN_DOMAIN_SHENGHUOZHE))
                && !TextUtils.isEmpty(id)
                && !TextUtils.isEmpty(parseUri.getPath())
                && parseUri.getPath().contains("item.html")) {
            Router.sharedRouter().open("services/" + id);
            finish();
        } else {
            view.loadUrl(url);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == ZmAuthActivity.ZM_AUTH_CLOSE) {
            finish();   // 关闭当前页面
        }
        if (requestCode == SIGNIN_REQUEST_CODE &&
                !TextUtils.isEmpty(Helper.sharedHelper().getToken())) {
            synCookies(url);
            webView.reload();
        }
        if (requestCode == PAY_REQUEST_CODE) {
            webView.reload();
        }
    }

    @Override
    public void onBackPressed() {
        if (!webChromeClient.onBackPressed()) {
            if (webView.canGoBack()) {
                webView.goBack();
            } else {
                finish();
            }
        }
    }

    public void handViewBackAndForward() {
        webBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webView.goBack();
            }
        });
        webForward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webView.goForward();
            }
        });
        webShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHideShareList(v);
            }
        });
    }

    public void synCookies(String url) {
        Uri uri = Uri.parse(url);
        if (url.startsWith("http://") && (uri.getAuthority().contains(Constant.MAIN_DOMAIN_KONGGE)
                || uri.getAuthority().contains(Constant.MAIN_DOMAIN_SHENGHUOZHE))) {  // 仅http类型需要埋cookie
            CookieSyncManager.createInstance(this);
            CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.setAcceptCookie(true);
            cookieManager.removeAllCookie();
            cookieManager.removeSessionCookie();

            if (Helper.sharedHelper().hasToken()) {
                String shzSid = ("sid=" + Helper.sharedHelper().getToken() + "; domain=shenghuozhe.net; expires=Sat, 01 Oct 2016 00:00:00 GMT");
                String kgSid = ("sid=" + Helper.sharedHelper().getToken() + "; domain=kongge.com; expires=Sat, 01 Oct 2016 00:00:00 GMT");
                cookieManager.setCookie(Constant.SHENGHUOZHE_BASE_URL, shzSid);
                cookieManager.setCookie(Constant.KONGGE_BASE_URL, kgSid);
                String esid = "";
                try {
                    esid = URLEncoder.encode(Helper.sharedHelper().getToken(), "utf-8");
                } catch (Exception e) {
                }
                String shzEsid = ("esid=" + esid + "; domain=shenghuozhe.net; expires=Sat, 01 Oct 2016 00:00:00 GMT");
                String kgEsid = ("esid=" + esid + "; domain=kongge.com; expires=Sat, 01 Oct 2016 00:00:00 GMT");
                cookieManager.setCookie(Constant.SHENGHUOZHE_BASE_URL, shzEsid);
                cookieManager.setCookie(Constant.KONGGE_BASE_URL, kgEsid);
                CookieSyncManager.getInstance().sync();
            }
        }
    }

    private String formatWebViewUserAgent(WebView webView) {
        String version = "";
        try {
            version = Helper.sharedHelper().getVersionName();
        } catch (Exception e) {
        }
        return "KongGe/" + version + " " + webView.getSettings().getUserAgentString();
    }

    private void initShareList(String shareDataString) {
        try {
            JSONObject shareJsons = JSONObject.parseObject(shareDataString);
            if (shareJsons == null) {
                return;
            }
            List<SocialContent> data = new ArrayList<>();
            JSONObject wechatSessionJsons = shareJsons.getJSONObject("WechatSession");
            JSONObject wechatTimelineJsons = shareJsons.getJSONObject("WechatTimeline");
            JSONObject weiboShareJsons = shareJsons.getJSONObject("Weibo");
            JSONObject qqShareJsons = shareJsons.getJSONObject("QQ");
            shareActivity = new ShareActivity(this);
            socialSharePopupWindow = new SocialSharePopupWindow(this, shareActivity,
                    SocialSharePopupWindow.SHARE_TYPE_WEB);

            if (wechatSessionJsons != null) {
                SocialContent weChatSocialContent = new SocialContent(SocialSharePopupWindow.WEIXIN,
                        "微信好友", R.string.icon_wechat, R.drawable.bg_share_item);
                weChatSocialContent.setShareTitle(wechatSessionJsons.getString("title"));
                weChatSocialContent.setShareContent(wechatSessionJsons.getString("content"));
                weChatSocialContent.setShareUrl(wechatSessionJsons.getString("url"));
                UMImage umImage;
                if (StrUtil.isEmpty(wechatSessionJsons.getString("iconURL"))) {
                    umImage = new UMImage(WebActivity.this, R.mipmap.ic_launcher);
                } else {
                    umImage = new UMImage(WebActivity.this, wechatSessionJsons.getString("iconURL"));
                }
                weChatSocialContent.setShareImage(umImage);

                data.add(weChatSocialContent);
            }

            if (wechatTimelineJsons != null) {
                SocialContent wxCircle = new SocialContent(SocialSharePopupWindow.WEIXIN_CIRCLE,
                        "朋友圈", R.string.icon_wechat_circle, R.drawable.bg_share_item);
                wxCircle.setShareTitle(wechatTimelineJsons.getString("title"));
                wxCircle.setShareContent(wechatTimelineJsons.getString("content"));
                wxCircle.setShareUrl(wechatTimelineJsons.getString("url"));
                UMImage umImage;
                if (StrUtil.isEmpty(wechatTimelineJsons.getString("iconURL"))) {
                    umImage = new UMImage(WebActivity.this, R.mipmap.ic_launcher);
                } else {
                    umImage = new UMImage(WebActivity.this, wechatTimelineJsons.getString("iconURL"));
                }
                wxCircle.setShareImage(umImage);
                data.add(wxCircle);
            }

            //data.add(new SocialContent(QZONE, "QQ空间", R.drawable.umeng_socialize_qzone_on));
            if (weiboShareJsons != null) {
                SocialContent weiboSocialContent = new SocialContent(
                        SocialSharePopupWindow.WEIBO, "微博", R.string.icon_weibo, R.drawable.bg_share_item);
                weiboSocialContent.setShareTitle(weiboShareJsons.getString("title"));
                weiboSocialContent.setShareContent(weiboShareJsons.getString("content"));
                weiboSocialContent.setShareUrl(weiboShareJsons.getString("url"));
                UMImage umImage;
                if (StrUtil.isEmpty(weiboShareJsons.getString("iconURL"))) {
                    umImage = new UMImage(WebActivity.this, R.mipmap.ic_launcher);
                } else {
                    umImage = new UMImage(WebActivity.this, weiboShareJsons.getString("iconURL"));
                }
                weiboSocialContent.setShareImage(umImage);
                data.add(weiboSocialContent);
            }

            if (qqShareJsons != null) {
                SocialContent qqSocialContent = new SocialContent(SocialSharePopupWindow.QQ,
                        "QQ", R.string.icon_qq, R.drawable.bg_share_item);
                qqSocialContent.setShareTitle(qqShareJsons.getString("title"));
                qqSocialContent.setShareContent(qqShareJsons.getString("content"));
                qqSocialContent.setShareUrl(qqShareJsons.getString("url"));
                UMImage umImage;
                if (StrUtil.isEmpty(qqShareJsons.getString("iconURL"))) {
                    umImage = new UMImage(WebActivity.this, R.mipmap.ic_launcher);
                } else {
                    umImage = new UMImage(WebActivity.this, qqShareJsons.getString("iconURL"));
                }
                qqSocialContent.setShareImage(umImage);
                data.add(qqSocialContent);
            }

            socialSharePopupWindow.setData(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showSocialShareIcon() {
        webShare.setVisibility(View.VISIBLE);
    }

    private void hideSocialShareIcon() {
        webShare.setVisibility(View.GONE);
    }

    private void showOrHideShareList(View v) {
        try {
            if (socialSharePopupWindow.isShowing()) {
                socialSharePopupWindow.dismiss();
            } else {
                socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showShareList() {
        try {
            if (!socialSharePopupWindow.isShowing()) {
                socialSharePopupWindow.showAtLocation(webShare, Gravity.BOTTOM, 0, 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getHeaders() {
        Headers headers = HttpClient.genHeaders("");
        JSONObject json = new JSONObject();
        for (int i = 0; i < headers.size(); i++) {
            json.put(headers.name(i), headers.value(i));
        }
        return json.toJSONString();
    }

    private void applySquare() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("longitude", String.valueOf(squareAddress.getLongitude()));
            jsonObject.put("latitude", String.valueOf(squareAddress.getLatitude()));
            jsonObject.put("bdLongitude", String.valueOf(squareAddress.getBdLatitude()));
            jsonObject.put("bdLatitude", String.valueOf(squareAddress.getBdLatitude()));
            jsonObject.put("bdUid", squareAddress.getBdUid());
            jsonObject.put("name", squareAddress.getName());
            jsonObject.put("address", squareAddress.getAddress());
            jsonObject.put("geziType", String.valueOf(squareAddress.getGeziType()));
            jsonObject.put("cityCode", mCityCode);

            HttpClient.get("1.0/gezi/apply", jsonObject, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject jsonObj) {
                    showWarnPopup(jsonObj.getString("tips1"), jsonObj.getString("tips2"));
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToast("提交格子申请失败: " + error.getMessage());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showWarnPopup(String hintTitle, String hintMessage) {
        if (tutorialPopupWindow == null) {
            tutorialPopupWindow = new TutorialPopupWindow(this,
                    TutorialPopupWindow.TUTORIAL_TYPE_CUSTOMIZE);
            tutorialPopupWindow.addTutorialItems(new TutorialPopupWindow.TutorialItem(hintTitle, hintMessage,
                    R.mipmap.emotion_no_item_normal, getString(R.string.i_know)));

            tutorialPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    Router.sharedRouter().open("mysquares");
                    finish();
                }
            });
        }

        if (!tutorialPopupWindow.isShowing() && !isFinishing()) {
            tutorialPopupWindow.showTutorial(webView);
        }
    }
}