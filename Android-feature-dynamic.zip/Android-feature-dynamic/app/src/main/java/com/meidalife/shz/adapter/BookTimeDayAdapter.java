package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.TimeVO;
import com.meidalife.shz.util.CollectionUtil;

import java.util.List;

/**
 * Created by taber on 15/6/17.
 */
public class BookTimeDayAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private Context mContext;
    private List<?> mData;

    static class ViewHolder {
        public TextView date;
        public TextView text;
    }

    public BookTimeDayAdapter(Context context, List<TimeVO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public int getCount() {
        return CollectionUtil.isNotEmpty(mData) ? mData.size() : 0;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.view_item_date, parent, false);
            TextView date = (TextView) convertView.findViewById(R.id.date);
            TextView text = (TextView) convertView.findViewById(R.id.text);
            holder = new ViewHolder();
            holder.date = date;
            holder.text = text;
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        // set data
        TimeVO timeVO = (TimeVO) mData.get(position);
        holder.date.setText(timeVO.getShowString());
        holder.text.setText(timeVO.getWeek());

        // set layout
        ViewGroup.LayoutParams itemLayout = convertView.getLayoutParams();
        int deviceWidth = mContext.getResources().getDisplayMetrics().widthPixels;
        deviceWidth = deviceWidth - deviceWidth / 10;

        if (mData.size() > 3) {
            itemLayout.width = (deviceWidth - 3) / 4;
        } else {
            itemLayout.width = (deviceWidth - 2) / 3;
        }

        // set selected normal value
        if (position == 0) {
            convertView.setSelected(true);
        }

        return convertView;
    }
}
