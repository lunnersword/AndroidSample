package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;

/**
 * Created by liujian on 16/1/10.
 */
public class SquareMiscCategoryAdapter extends BaseAdapter {
    private Context context;
    private JSONArray categoryList;
    private LayoutInflater mInflater;

    public SquareMiscCategoryAdapter(Context context, JSONArray categoryList) {
        this.context = context;
        this.categoryList = categoryList;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return categoryList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.item_misc_category, parent, false);
            holder = new ViewHolder();
            holder.categoryName = (TextView) convertView.findViewById(R.id.categoryName);
            holder.itemCount = (TextView) convertView.findViewById(R.id.itemCount);
            holder.icon = (SimpleDraweeView) convertView.findViewById(R.id.icon);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder)convertView.getTag();
        }
        final JSONObject item = categoryList.getJSONObject(position);
        if(item.containsKey("picUrl")){
            //  String cdnUrl = ImgUtil.getCDNUrlWithWidth(item.getString("picUrl"), context.getResources().getDimensionPixelSize(R.dimen.emotion_icon_size));
            holder.icon.setImageURI(Uri.parse(item.getString("picUrl")));
        }
        if(item.containsKey("title"))
            holder.categoryName.setText(item.getString("title"));
        if(item.containsKey("itemCount"))
            holder.itemCount.setText(String.format(context.getString(R.string.square_service_category_count),item.getString("itemCount")));

        return convertView;
    }

    static class ViewHolder {
        SimpleDraweeView icon;
        TextView categoryName;
        TextView itemCount;

    }
}

