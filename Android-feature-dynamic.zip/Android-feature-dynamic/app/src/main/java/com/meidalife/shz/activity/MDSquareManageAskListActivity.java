package com.meidalife.shz.activity;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareAskAdapter;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareAskDO;
import com.meidalife.shz.rest.request.RequestSquareAsk;
import com.usepropeller.routable.Router;

import java.util.ArrayList;

import de.greenrobot.event.EventBus;

public class MDSquareManageAskListActivity extends BaseActivity {

    private String geziId;
    private ListView askListView;
    private View listFooter;
    private ProgressBar footerLoading;
    private TextView footerMessage;
    private Button footerReload;
    private View emptyView;

    ArrayList<SquareAskDO> demandList;
    SquareAskAdapter squareAskAdapter;
    private int previous = 0;
    boolean loading = false;
    boolean complete = false;
    int PAGE_SIZE = 20;
    int page = 0;
    boolean isFirstEnter = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mdsquare_manage_ask_list);
        initActionBar(R.string.title_activity_mdsquare_manage_ask_list, true);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            geziId = bundle.getString("geziId");
        }
        askListView = (ListView) findViewById(R.id.askList);
        emptyView = findViewById(R.id.emptyView);

        listFooter = LayoutInflater.from(this).inflate(R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);
        askListView.addFooterView(listFooter);
        listFooter.setVisibility(View.GONE);
        bindListener();

        demandList = new ArrayList<>();
        squareAskAdapter = new SquareAskAdapter(this, demandList, true);
        askListView.setAdapter(squareAskAdapter);
        //首次进入加载
        fetchAskItem();

        isFirstEnter = false;

    }

    private void fetchAskItem() {

        loading = true;
        listFooter.setVisibility(View.VISIBLE);

        RequestSquareAsk.getWaittingComment(getAskItemParams(), new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object result) {
                listFooter.setVisibility(View.GONE);
                loading = false;

                JSONArray jsonArray = (JSONArray) result;
                Log.d("mzLog", "result jsonArray: " + jsonArray.toString());
                int size = jsonArray.size();
                if(size == 0 && demandList.size() == 0){
                    emptyView.setVisibility(View.VISIBLE);
                    return;
                }
                emptyView.setVisibility(View.GONE);
                for (int i = 0; i < size; i++) {
                    SquareAskDO squareAskDO = new SquareAskDO();
                    JSONObject demandJB = (JSONObject) jsonArray.get(i);
                    squareAskDO.setId(demandJB.getInteger("id"));
                    squareAskDO.setGeziId(demandJB.getInteger("geziId"));
                    squareAskDO.setTitle(demandJB.getString("title"));
                    squareAskDO.setDescription(demandJB.getString("description"));
                    squareAskDO.setCloseTime(demandJB.getInteger("closeTime"));
                    squareAskDO.setRemainTime(demandJB.getInteger("remainTime"));
                    JSONObject user = demandJB.getJSONObject("user");
                    squareAskDO.setUserInstruction(user.getString("userInstruction"));
                    squareAskDO.setUserId(user.getInteger("userId"));
                    squareAskDO.setUserNick(user.getString("userNick"));
                    squareAskDO.setUserPicUrl(user.getString("userPicUrl"));
                    squareAskDO.setUserGender(user.getString("userGender"));
                    squareAskDO.setCommentCount(demandJB.getInteger("commentCount"));
                    demandList.add(squareAskDO);
                    Log.d("mzLog squareAskDO", squareAskDO.toString());
                }
                squareAskAdapter.notifyDataSetChanged();

                if (size < PAGE_SIZE) {
                    complete = true;
                    askListView.removeFooterView(listFooter);
                }
            }

            @Override
            public void onFail(HttpError error) {
                page--;
                loading = false;
                if (error != null) {
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        footerReload.setText("网络异常，点击重试");
                    } else {
                        footerReload.setText(error.getMessage() + "，点击重试");
                    }
                } else {
                    footerReload.setText("发生一个未知错误，点击重试");
                }
                footerReload.setVisibility(View.VISIBLE);
                footerLoading.setVisibility(View.GONE);
                footerMessage.setVisibility(View.GONE);
            }
        });
    }

    private void bindListener() {
        askListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView absListView, int i) {
                BaseEvent message = new BaseEvent();
                final View topChildView = askListView.getChildAt(0);
                if (i == SCROLL_STATE_IDLE && askListView.getFirstVisiblePosition() == 0
                        && topChildView.getTop() == 0) {
                    message.eventType = MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                } else {
                    message.eventType = MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                }

                if (i == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (absListView.getLastVisiblePosition() == absListView.getCount() - 1) {
                        //* 需要加载更多数据的代码 *//*
                        loadAskItem();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
//                boolean moveToBottom = false;
//                if (previous <= firstVisibleItem) {
//                    moveToBottom = true;
//                }
//                previous = firstVisibleItem;
//                if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom && !isFirstEnter) {
//                    //* 需要加载更多数据的代码 *//*
//                    loadAskItem();
//                }
            }
        });

        askListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                SquareAskDO squareAskDO = demandList.get(position);
                Router.sharedRouter().open("squareaskdetail/" + squareAskDO.getId());

            }
        });

    }

    private void loadAskItem() {
        if (!complete && !loading) {
            page++;
            fetchAskItem();
        }
    }


    private JSONObject getAskItemParams() {

        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        params.put("catId", 0);
        params.put("offset", page * PAGE_SIZE);
        params.put("pageSize", PAGE_SIZE);
        return params;
    }

}
