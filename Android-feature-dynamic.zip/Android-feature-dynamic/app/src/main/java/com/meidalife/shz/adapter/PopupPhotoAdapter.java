package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 16/3/3.
 * 我加入的格子list对应adapter
 */
public class PopupPhotoAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    List<String> mData;

    static class PhotoViewHolder extends RecyclerView.ViewHolder {
        public PhotoViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.photo)
        SimpleDraweeView photo;

    }

    public PopupPhotoAdapter(Context context, List<String> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mContext = context;
        mData = data;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final PhotoViewHolder holder;
        if (convertView == null || convertView.getTag() == null) {
            convertView = mInflater.inflate(R.layout.item_service_photo, parent, false);
            holder = new PhotoViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (PhotoViewHolder) convertView.getTag();
        }

        holder.photo.setImageURI(Uri.parse(ImgUtil.getCDNUrlWithHeight(mData.get(position), holder.photo.getLayoutParams().height)));

        return convertView;
    }
}
