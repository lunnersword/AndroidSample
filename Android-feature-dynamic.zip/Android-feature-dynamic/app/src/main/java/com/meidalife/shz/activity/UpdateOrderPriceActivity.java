package com.meidalife.shz.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;

import java.math.BigDecimal;
import java.math.RoundingMode;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class UpdateOrderPriceActivity extends BaseActivity {

    private static final String TAG = "ModifyOrderPrice";


    //订单单价
    @Bind(R.id.itemPriceView)
    TextView itemPriceView;

    //订单总价
    @Bind(R.id.totalPriceView)
    TextView totalPriceView;

    //购买数量
    @Bind(R.id.quantityView)
    TextView quantityView;

    //修改后价格
    @Bind(R.id.updatePriceView)
    EditText updatePriceView;

    //价格变动提示
    @Bind(R.id.priceTips)
    TextView priceTipsView;


    //订单id
    private String orderNo;
    //成交总价
    double dealAmount;

    double updatedAmount;

    boolean submit = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_order_price);
        initActionBar(R.string.title_modify_order_price, true, true);

        mButtonRight.setText("确定");

        ButterKnife.bind(this);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            orderNo = bundle.getString("orderNo");
        }

        updatePriceView.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    double price = toDouble(s.toString(), 0.0d);
                    String str = "";
                    boolean isEquals = false;
                    if (price * 100 > dealAmount) {
                        str = "+";
                    } else if (price * 100 == dealAmount) {
                        isEquals = true;
                    }

                    double changedPrice = ((price * 100 - dealAmount) * 10000) / 1000000;
                    BigDecimal bd = new BigDecimal(changedPrice);
                    bd = bd.setScale(2, RoundingMode.HALF_UP);

                    if (isEquals) {
                        priceTipsView.setText("订单价格未改变");
                    } else {
                        priceTipsView.setText(new StringBuilder("订单价格 ").append(str).append(bd).append("元").toString());
                    }
                    priceTipsView.setVisibility(View.VISIBLE);
                } catch (NumberFormatException e) {
                    Log.d(TAG, "textChange" + e.getMessage());
                    MessageUtils.showToast("价格输入错误");
                }

            }
        });
        if (!TextUtils.isEmpty(orderNo)) {
            priceDetail();
        }
    }

    private void priceDetail() {
        showProgressDialog("正在获取数据", false);
        try {
            JSONObject params = new JSONObject();
            params.put("orderNo", orderNo);


            HttpClient.get("1.0/sellerOrder/bargainForm", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject obj) {
                    hideProgressDialog();

                    updateView(obj);
                }

                @Override
                public void onFail(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "获取价格详情失败");
                }
            });

        } catch (Exception e) {

        }
    }


    void updateView(JSONObject obj) {

        double itemPrice = obj.getDouble("price");
        String quantity = obj.getString("quantity");
        dealAmount = obj.getDouble("dealAmount");

        itemPriceView.setText("" + (itemPrice / 100));
        totalPriceView.setText("" + (dealAmount / 100));
        quantityView.setText(quantity);
    }

    @OnClick(R.id.action_bar_button_right)
    public void handleSubmit(View view) {
        String changedPriceStr = updatePriceView.getText().toString().trim();

        //价格不能小于0.01
        try {
            if (Float.parseFloat(changedPriceStr) < 0.01f) {
                MessageUtils.showToastCenter("输入的金额不应小于0.01");
                return;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            MessageUtils.showToastCenter("输入的金额非法");
            return;
        }
        updatedAmount = toDouble(changedPriceStr, 0.0d) * 100;

        if (!submit) {
            submit = true;
            showProgressDialog("正在改价", false);

            xhrSubmit();
        }
    }

    private void xhrSubmit() {
        JSONObject params = new JSONObject();

        try {
            if (!TextUtils.isEmpty(orderNo)) {
                params.put("orderNo", orderNo);
            }
            params.put("dealAmount", updatedAmount);

            HttpClient.get("1.0/sellerOrder/bargain", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject obj) {
                    hideProgressDialog();
                    submit = false;
                    finish();
                }

                @Override
                public void onFail(HttpError error) {
                    hideProgressDialog();
                    submit = false;
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "修改价格失败，请重试");
                }
            });

        } catch (Exception e) {

        }
    }

    public static double toDouble(final String str, final double defaultValue) {
        if (str == null) {
            return defaultValue;
        }
        try {
            return Double.parseDouble(str);
        } catch (final NumberFormatException nfe) {
            return defaultValue;
        }
    }

}
