package com.meidalife.shz.adapter;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.SinglePropValueAdapter;
import com.meidalife.shz.rest.model.ServicePropDo;
import com.meidalife.shz.rest.model.ServicePropValue;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.widget.TextTagView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;

/**
 * Created by fufeng on 16/3/11.
 */
public class ServicePropRecycleAdapter extends RecyclerView.Adapter {
    public static final int PROP_TYPE_SINGLE_CHOICE = 1;
    public static final int PROP_TYPE_MULTI_CHOICE = 2;
    public static final int PROP_TYPE_TEXT = 3;

    private Context context;
    private LayoutInflater mInflater;
    private ArrayList<ServicePropDo> servicePropDoList = new ArrayList<>();

    public ServicePropRecycleAdapter(Context context, ArrayList<ServicePropDo> servicePropDoList) {
        this.context = context;
        this.servicePropDoList = servicePropDoList;
        mInflater = LayoutInflater.from(context);
    }

    public void setServicePropDoList(ArrayList<ServicePropDo> servicePropDoList) {
        this.servicePropDoList = servicePropDoList;
    }

    public ArrayList<ServicePropDo> getServicePropDoList() {
        return servicePropDoList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case PROP_TYPE_SINGLE_CHOICE: {
                return new SinglePropViewHolder(mInflater.inflate(R.layout.item_prop_single_choice, parent, false));
            }
            case PROP_TYPE_MULTI_CHOICE: {
                return new MultiPropViewHolder(mInflater.inflate(R.layout.item_prop_multi_choice, parent, false));
            }
            case PROP_TYPE_TEXT: {
                return new TextPropViewHolder(mInflater.inflate(R.layout.item_prop_text, parent, false));
            }
        }
        return null;
    }

    @Override
    public int getItemViewType(int position) {
        ServicePropDo servicePropDo = servicePropDoList.get(position);
        if (null != servicePropDo) {
            return servicePropDo.getType();
        }
        return super.getItemViewType(position);
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        ServicePropDo servicePropDo = servicePropDoList.get(position);
        final String helpLink = servicePropDo.getLink();
        Set<String> selectedIds = new HashSet<String>();
        switch (holder.getItemViewType()) {
            case PROP_TYPE_SINGLE_CHOICE: {
                if (servicePropDo.getValues() == null) {
                    return;
                }
                SinglePropValueAdapter adapter = new SinglePropValueAdapter(context, servicePropDo.getValues());
                if (!TextUtils.isEmpty(servicePropDo.getVid())) {
                    selectedIds.add(servicePropDo.getVid());
                    adapter.setSelectedIds(selectedIds);
                }
                adapter.setOnPropSelectListener(new SinglePropValueAdapter.OnPropSelectListener() {
                    @Override
                    public void onSelect(ServicePropValue value) {
                        servicePropDoList.get(position).setVid(value.getVid());
                    }
                });

                ((SinglePropViewHolder) holder).singleChoiceProp.setAdapter(adapter);
                if (servicePropDo.isRequired()) {
                    ((SinglePropViewHolder) holder).singleChoiceTitle.setText(StrUtil.getSpanText("<b>*</b>" + servicePropDo.getName(),
                            context.getResources().getColor(R.color.brand_b),
                            context.getResources().getDimensionPixelSize(R.dimen.font_size)));
                } else {
                    ((SinglePropViewHolder) holder).singleChoiceTitle.setText(servicePropDo.getName());
                }
                ((SinglePropViewHolder) holder).helpLink.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", helpLink);
                        Router.sharedRouter().open("web", bundle);
                    }
                });
                break;
            }
            case PROP_TYPE_MULTI_CHOICE: {
                if (servicePropDo.getValues() == null) {
                    return;
                }
                final LinkedHashMap<String, String> categoryTagMap = new LinkedHashMap<>();
                final HashMap<String, ServicePropValue> categoryTagCacheMap = new HashMap<>();
                for (int i = 0; i < servicePropDo.getValues().size(); i++) {
                    categoryTagMap.put(servicePropDo.getValues().get(i).getVid(), servicePropDo.getValues().get(i).getName());
                    categoryTagCacheMap.put(servicePropDo.getValues().get(i).getVid(), servicePropDo.getValues().get(i));
                }

                if (servicePropDo.isRequired()) {
                    ((MultiPropViewHolder) holder).multiChoiceTitle.setText(StrUtil.getSpanText("<b>*</b>" + servicePropDo.getName(),
                            context.getResources().getColor(R.color.brand_b),
                            context.getResources().getDimensionPixelSize(R.dimen.font_size)));
                } else {
                    ((MultiPropViewHolder) holder).multiChoiceTitle.setText(servicePropDo.getName());
                }

                ViewGroup.LayoutParams param = ((MultiPropViewHolder) holder).textTagView.getLayoutParams();
                param.height = (int) ((int) Math.ceil((float) servicePropDo.getValues().size() / 4) *
                        (context.getResources().getDimensionPixelSize(R.dimen.default_text_tag_height) + Helper.convertDpToPixel(10.0f)));
                ((MultiPropViewHolder) holder).textTagView.setLayoutParams(param);
                ((MultiPropViewHolder) holder).textTagView.setTagData(categoryTagMap);

                if (servicePropDo.getVids() != null && !servicePropDo.getVids().isEmpty()) {
                    for (String vid : servicePropDo.getVids()) {
                        //移除vid不再范围内的vid
                        if (categoryTagMap.containsKey(vid)) {
                            selectedIds.add(vid);
                        }
                    }
                    ((MultiPropViewHolder) holder).textTagView.setSelectedIds(selectedIds);
                }

                ((MultiPropViewHolder) holder).textTagView.setOnItemClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        servicePropDoList.get(position).getVids().clear();
                        for (String selectedId : ((MultiPropViewHolder) holder).textTagView.getSelectedIds()) {
                            servicePropDoList.get(position).getVids().add(selectedId);
                        }
                    }
                });
                ((MultiPropViewHolder) holder).helpLink.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", helpLink);
                        Router.sharedRouter().open("web", bundle);
                    }
                });
                break;
            }
            case PROP_TYPE_TEXT: {
                final TextPropViewHolder textPropViewHolder = (TextPropViewHolder) holder;

                if (servicePropDo.isRequired()) {
                    textPropViewHolder.textPropTitle.setText(StrUtil.getSpanText("<b>*</b>" + servicePropDo.getName(),
                            context.getResources().getColor(R.color.brand_b),
                            context.getResources().getDimensionPixelSize(R.dimen.font_size)));
                } else {
                    textPropViewHolder.textPropTitle.setText(servicePropDo.getName());
                }
                if (null != servicePropDo.getText()) {
                    textPropViewHolder.textPropValue.setText(servicePropDo.getText());
                } else if (!TextUtils.isEmpty(servicePropDo.getPlaceholder())) {
                    textPropViewHolder.textPropValue.setHint(servicePropDo.getPlaceholder());
                }
                if (servicePropDo.getMaxLength() > 0) {
                    textPropViewHolder.textLimit.setVisibility(View.VISIBLE);
                    textPropViewHolder.textLimit.setText("0/" + servicePropDo.getMaxLength());
                    InputFilter[] filters = {new InputFilter.LengthFilter(servicePropDo.getMaxLength())};
                    textPropViewHolder.textPropValue.setFilters(filters);
                }

                textPropViewHolder.textPropValue.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        textPropViewHolder.textLimit.setText(String.format("%s/%s", s.length(),
                                servicePropDoList.get(position).getMaxLength()));
                        if (!TextUtils.isEmpty(s.toString())) {
                            servicePropDoList.get(position).setText(s.toString());
                        }
                    }
                });
                textPropViewHolder.helpLink.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", helpLink);
                        Router.sharedRouter().open("web", bundle);
                    }
                });
                break;
            }
        }
    }

    @Override
    public int getItemCount() {
        return servicePropDoList.size();
    }

    class SinglePropViewHolder extends RecyclerView.ViewHolder {
        TextView singleChoiceTitle;
        ListView singleChoiceProp;
        TextView helpLink;

        public SinglePropViewHolder(View itemView) {
            super(itemView);
            singleChoiceTitle = (TextView) itemView.findViewById(R.id.singleChoiceTitle);
            singleChoiceProp = (ListView) itemView.findViewById(R.id.singleChoiceProp);
            helpLink = (TextView) itemView.findViewById(R.id.helpLink);
        }
    }

    class MultiPropViewHolder extends RecyclerView.ViewHolder {
        TextView multiChoiceTitle;
        TextTagView textTagView;
        TextView helpLink;

        public MultiPropViewHolder(View itemView) {
            super(itemView);
            multiChoiceTitle = (TextView) itemView.findViewById(R.id.multiChoiceTitle);
            textTagView = (TextTagView) itemView.findViewById(R.id.multiChoiceTags);
            helpLink = (TextView) itemView.findViewById(R.id.helpLink);
        }
    }

    class TextPropViewHolder extends RecyclerView.ViewHolder {
        TextView textPropTitle;
        EditText textPropValue;
        TextView textLimit;
        TextView helpLink;

        public TextPropViewHolder(View itemView) {
            super(itemView);
            textPropTitle = (TextView) itemView.findViewById(R.id.propTitle);
            textPropValue = (EditText) itemView.findViewById(R.id.propText);
            textLimit = (TextView) itemView.findViewById(R.id.textLimit);
            helpLink = (TextView) itemView.findViewById(R.id.helpLink);
        }
    }
}
