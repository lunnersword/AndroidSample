package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.util.ImgUtil;

import java.util.ArrayList;

public class ViewUsersAdapter extends RecyclerView.Adapter<ViewUsersAdapter.ImageHolder> {

    LayoutInflater mInflater;
    Context mContext;
    ArrayList<ServiceItem.ViewUser> mData;
    OnItemClickListener listener;

    public static class ImageHolder extends RecyclerView.ViewHolder {
        public SimpleDraweeView image;

        public ImageHolder(View itemView) {
            super(itemView);
        }
    }

    public ViewUsersAdapter(Context context, ArrayList<ServiceItem.ViewUser> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public ImageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = mInflater.inflate(R.layout.item_view_user, parent, false);
        ImageHolder imageHolder = new ImageHolder(convertView);
        imageHolder.image = (SimpleDraweeView) convertView.findViewById(R.id.imageAvatar);

        return imageHolder;
    }

    @Override
    public void onBindViewHolder(ImageHolder holder, final int position) {
        ViewGroup.LayoutParams layoutParams = holder.image.getLayoutParams();
        ServiceItem.ViewUser item = mData.get(position);
        if (TextUtils.isEmpty(item.getUserAvatar())) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(item.getUserId()), item.getGender());
            holder.image.setImageURI(getDefaultAvatarUri);
        } else {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getUserAvatar(), layoutParams.width));
            holder.image.setImageURI(uri);
        }

        if (listener != null) {
            holder.image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(v, position, getItemId(position));
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void setOnItemClickListener(OnItemClickListener l) {
        listener = l;
    }

    public interface OnItemClickListener {
        public void onItemClick(View view, int position, long id);
    }
}
