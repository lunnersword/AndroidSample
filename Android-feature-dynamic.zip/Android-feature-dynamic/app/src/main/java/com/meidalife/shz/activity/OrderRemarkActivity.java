package com.meidalife.shz.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.widget.CheckableIconText;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/1/10.
 */
public class OrderRemarkActivity extends BaseActivity {
    private static final int MAX_REMARK_TEXT_LENGTH = 256;

    List<CheckableIconText> remarkFlagList = new ArrayList<>();
    private int currentFlagIndex = 0;
    private String orderNo;
    private String remarkContent;
    private static final Integer[] remarkFlagDrawable = new Integer[]{
            R.drawable.bg_remark_flag_1,
            R.drawable.bg_remark_flag_2,
            R.drawable.bg_remark_flag_3,
            R.drawable.bg_remark_flag_4,
            R.drawable.bg_remark_flag_5
    };
    @Bind(R.id.remarkFlag1)
    CheckableIconText remarkFlag1;
    @Bind(R.id.remarkFlag2)
    CheckableIconText remarkFlag2;
    @Bind(R.id.remarkFlag3)
    CheckableIconText remarkFlag3;
    @Bind(R.id.remarkFlag4)
    CheckableIconText remarkFlag4;
    @Bind(R.id.remarkFlag5)
    CheckableIconText remarkFlag5;

    @Bind(R.id.orderRemarkInput)
    EditText orderRemarkInput;
    @Bind(R.id.textLengthLimits)
    TextView textLengthLimits;

    @Bind(R.id.saveRemark)
    TextView saveRemark;
    @Bind(R.id.deleteRemark)
    TextView deleteRemark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_remark);
        ButterKnife.bind(this);

        initActionBar("备注", true, false);
        initData();
    }

    private void initData() {
        orderNo = getIntent().getStringExtra(Constant.EXTRA_TAG_ORDER_NO);
        currentFlagIndex = getIntent().getIntExtra(Constant.EXTRA_TAG_REMARK_FLAG, 1);
        remarkContent = getIntent().getStringExtra(Constant.EXTRA_TAG_REMARK_CONTENT);
        if (!TextUtils.isEmpty(remarkContent)) {
            orderRemarkInput.setText(remarkContent);
        }
        remarkFlag1.setDefaultCheckedColor(R.color.remark_flag_1);
        remarkFlag1.setDefaultUnCheckedColor(R.color.remark_flag_1);
        remarkFlag1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setFlagSelect(0);
            }
        });
        remarkFlag2.setDefaultCheckedColor(R.color.remark_flag_2);
        remarkFlag2.setDefaultUnCheckedColor(R.color.remark_flag_2);
        remarkFlag2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setFlagSelect(1);
            }
        });

        remarkFlag3.setDefaultCheckedColor(R.color.remark_flag_3);
        remarkFlag3.setDefaultUnCheckedColor(R.color.remark_flag_3);
        remarkFlag3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setFlagSelect(2);
            }
        });

        remarkFlag4.setDefaultCheckedColor(R.color.remark_flag_4);
        remarkFlag4.setDefaultUnCheckedColor(R.color.remark_flag_4);
        remarkFlag4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setFlagSelect(3);
            }
        });

        remarkFlag5.setDefaultCheckedColor(R.color.remark_flag_5);
        remarkFlag5.setDefaultUnCheckedColor(R.color.remark_flag_5);
        remarkFlag5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setFlagSelect(4);
            }
        });

        textLengthLimits.setText(String.format("%s/%s",
                orderRemarkInput.getText() != null ? orderRemarkInput.getText().length() : 0, MAX_REMARK_TEXT_LENGTH));

        orderRemarkInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                textLengthLimits.setText(String.format("%s/%s", s.length(), MAX_REMARK_TEXT_LENGTH));
            }
        });

        saveRemark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addRemark();
            }
        });

        deleteRemark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeRemark();
            }
        });

        remarkFlagList.add(0, remarkFlag1);
        remarkFlagList.add(1, remarkFlag2);
        remarkFlagList.add(2, remarkFlag3);
        remarkFlagList.add(3, remarkFlag4);
        remarkFlagList.add(4, remarkFlag5);

        setFlagSelect(currentFlagIndex - 1);
    }

    private void setFlagSelect(int position) {
        for (int i = 0; i < remarkFlagList.size(); i++) {
            if (i == position) {
                currentFlagIndex = position + 1;
                remarkFlagList.get(i).setChecked(true);
                remarkFlagList.get(i).setBackgroundResource(remarkFlagDrawable[position]);
            } else {
                remarkFlagList.get(i).setChecked(false);
                remarkFlagList.get(i).setBackgroundResource(R.drawable.bg_rect_round_corner_border_grey_d);
            }
        }
    }

    private void addRemark() {
        if (TextUtils.isEmpty(orderRemarkInput.getText())) {
            MessageUtils.showToast("备注不能为空");
            return;
        }
        JSONObject params = new JSONObject();
        params.put("orderNo", orderNo);
        params.put("flag", currentFlagIndex);
        params.put("remark", orderRemarkInput.getText());

        HttpClient.get("1.0/sellerOrder/addInnerRemark", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                MessageUtils.showToast("保存备注成功");
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToast("保存备注失败:" + error);
            }
        });
    }

    private void removeRemark() {
        JSONObject params = new JSONObject();
        params.put("orderNo", orderNo);
        params.put("flag", 0);
        params.put("remark", "");
        HttpClient.get("1.0/sellerOrder/addInnerRemark", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                MessageUtils.showToast("删除备注成功");
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToast("删除备注失败:" + error);
            }
        });
    }
}
