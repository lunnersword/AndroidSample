package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.andraskindler.quickscroll.Scrollable;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CityItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by fufeng on 16/3/14.
 */
public class ExpandableCityListAdapter extends BaseExpandableListAdapter implements Scrollable {
    Context context;
    private List<CityItem> cityItemList = new ArrayList<>();
    private LayoutInflater inflater;
    private Map<String, String> alphaIndexMap = new HashMap<>();
    private List<String> alphaIndex = new ArrayList<>();

    private OnCitySelectListener onCitySelectListener;

    public interface OnCitySelectListener {
        void onSelect(String code);

        void onUnSelect(String code);
    }

    public ExpandableCityListAdapter(Context context, List<CityItem> cityItemList) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.cityItemList = cityItemList;
    }

    @Override
    public int getGroupCount() {
        return cityItemList.size();
    }

    public void setAlphaIndex(List<String> alphaIndex) {
        this.alphaIndex = alphaIndex;
    }

    public void setOnCitySelectListener(OnCitySelectListener onCitySelectListener) {
        this.onCitySelectListener = onCitySelectListener;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return cityItemList.get(groupPosition).subCityList.size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return cityItemList.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        if (((CityItem) getGroup(groupPosition)).subCityList.size() > childPosition) {
            return ((CityItem) getGroup(groupPosition)).subCityList.get(childPosition);
        }
        return null;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_city_item, parent, false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        final CityItem cityItem = (CityItem) getGroup(groupPosition);
        if ("0".equals(cityItem.getCode())) {
            viewHolder.cityIndexLabel.setVisibility(View.VISIBLE);
        } else if (cityItem.isLocationCity()) {
            viewHolder.cityIndexLabel.setVisibility(View.VISIBLE);
            viewHolder.cityIndexLabel.setText("定位城市");
        } else {
            viewHolder.cityIndexLabel.setVisibility(View.GONE);
        }
        if (!cityItem.subCityList.isEmpty()) {
            viewHolder.groupIndicator.setVisibility(View.VISIBLE);
            if (isExpanded) {
                viewHolder.groupIndicator.setText(R.string.icon_arrow_collapse);
            } else {
                viewHolder.groupIndicator.setText(R.string.icon_arrow_expand);
            }
        } else {
            viewHolder.groupIndicator.setVisibility(View.GONE);
        }

        if (cityItem.subCityList.isEmpty()) {
            if (cityItem.getState() == CityItem.STATE_ALL_SELECT) {
                viewHolder.selectIndicator.setText(R.string.icon_checkbox_active);
                viewHolder.selectIndicator.setTextColor(context.getResources().getColor(R.color.brand_b));
            } else if (cityItem.isChildUnSelected()) {
                viewHolder.selectIndicator.setText(R.string.icon_radio);
                viewHolder.selectIndicator.setTextColor(context.getResources().getColor(R.color.grey_b));
            }
        } else {
            if (cityItem.isChildAllSelected()) {
                viewHolder.selectIndicator.setText(R.string.icon_checkbox_active);
                viewHolder.selectIndicator.setTextColor(context.getResources().getColor(R.color.brand_b));
            } else if (cityItem.isChildUnSelected()) {
                viewHolder.selectIndicator.setText(R.string.icon_radio);
                viewHolder.selectIndicator.setTextColor(context.getResources().getColor(R.color.grey_b));
            } else {
                viewHolder.selectIndicator.setText(R.string.icon_radio_select);
                viewHolder.selectIndicator.setTextColor(context.getResources().getColor(R.color.brand_b));
            }
        }

        viewHolder.selectIndicator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cityItem.getState() == CityItem.STATE_UNSELECT) {
                    cityItem.setState(CityItem.STATE_ALL_SELECT);
                    cityItem.selectAll();
                } else if (cityItem.getState() == CityItem.STATE_HALF_SELECT) {
                    cityItem.setState(CityItem.STATE_ALL_SELECT);
                    cityItem.selectAll();
                } else if (cityItem.getState() == CityItem.STATE_ALL_SELECT) {
                    cityItem.setState(CityItem.STATE_UNSELECT);
                    cityItem.unSelectAll();
                }
                notifyDataSetChanged();
            }
        });
        viewHolder.cityName.setText(cityItem.getName());
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_child_city_item, parent, false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        final CityItem cityItem = (CityItem) getChild(groupPosition, childPosition);
        if (cityItem == null) {
            return null;
        }
        if (!alphaIndexMap.containsKey(cityItem.getCapital())
                || alphaIndexMap.get(cityItem.getCapital()).equals(cityItem.getCode())) {
            viewHolder.cityIndexLabel.setText(cityItem.getCapital());
            viewHolder.cityIndexLabel.setVisibility(View.VISIBLE);
            alphaIndexMap.put(cityItem.getCapital(), cityItem.getCode());
        } else {
            viewHolder.cityIndexLabel.setVisibility(View.GONE);
        }

        if (cityItem.subCityList.isEmpty()) {
            if (cityItem.getState() == CityItem.STATE_ALL_SELECT) {
                viewHolder.selectIndicator.setText(R.string.icon_checkbox_active);
                viewHolder.selectIndicator.setTextColor(context.getResources().getColor(R.color.brand_b));
            } else if (cityItem.isChildUnSelected()) {
                viewHolder.selectIndicator.setText(R.string.icon_radio);
                viewHolder.selectIndicator.setTextColor(context.getResources().getColor(R.color.grey_b));
            }
        } else {
            if (cityItem.isChildAllSelected()) {
                viewHolder.selectIndicator.setText(R.string.icon_checkbox_active);
                viewHolder.selectIndicator.setTextColor(context.getResources().getColor(R.color.brand_b));
            } else if (cityItem.isChildUnSelected()) {
                viewHolder.selectIndicator.setText(R.string.icon_radio);
                viewHolder.selectIndicator.setTextColor(context.getResources().getColor(R.color.grey_b));
            } else {
                viewHolder.selectIndicator.setText(R.string.icon_radio_select);
                viewHolder.selectIndicator.setTextColor(context.getResources().getColor(R.color.brand_b));
            }
        }

        viewHolder.selectIndicator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cityItem.getState() == CityItem.STATE_UNSELECT) {
                    cityItem.setState(CityItem.STATE_ALL_SELECT);
                    cityItem.selectAll();
                } else if (cityItem.getState() == CityItem.STATE_HALF_SELECT) {
                    cityItem.setState(CityItem.STATE_ALL_SELECT);
                    cityItem.selectAll();
                } else if (cityItem.getState() == CityItem.STATE_ALL_SELECT) {
                    cityItem.setState(CityItem.STATE_UNSELECT);
                    cityItem.unSelectAll();
                }
                notifyDataSetChanged();
            }
        });
        viewHolder.cityName.setText(cityItem.getName());

        if (!cityItem.subCityList.isEmpty()) {
            CityListAdapter adapter = new CityListAdapter(context, cityItem.subCityList);
            viewHolder.cityList.setAdapter(adapter);
            viewHolder.groupIndicator.setVisibility(View.VISIBLE);
            viewHolder.groupIndicator.setText(viewHolder.cityList.getVisibility() == View.GONE ?
                    R.string.icon_arrow_expand : R.string.icon_arrow_collapse);

            adapter.setOnCitySelectListener(new CityListAdapter.OnCitySelectListener() {
                @Override
                public void onSelcet(CityItem item) {
                    boolean hasUnselectedItem = false;
                    for (CityItem subItem : cityItem.subCityList) {
                        if (subItem.getState() == CityItem.STATE_UNSELECT) {
                            hasUnselectedItem = true;
                        }
                    }
                    cityItem.setState(hasUnselectedItem ? CityItem.STATE_HALF_SELECT : CityItem.STATE_ALL_SELECT);
                    notifyDataSetChanged();
                }

                @Override
                public void unSelcet(CityItem item) {
                    boolean hasSelectedItem = false;
                    for (CityItem subItem : cityItem.subCityList) {
                        if (subItem.getState() == CityItem.STATE_ALL_SELECT) {
                            hasSelectedItem = true;
                        }
                    }
                    cityItem.setState(hasSelectedItem ? CityItem.STATE_HALF_SELECT : CityItem.STATE_UNSELECT);
                    notifyDataSetChanged();
                }
            });

            viewHolder.cityName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    viewHolder.cityList.setVisibility(viewHolder.cityList.getVisibility() == View.GONE
                            ? View.VISIBLE : View.GONE);
                }
            });
            viewHolder.groupIndicator.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    viewHolder.cityList.setVisibility(viewHolder.cityList.getVisibility() == View.GONE
                            ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            viewHolder.cityList.setVisibility(View.GONE);
        }
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return false;
    }

    @Override
    public String getIndicatorForPosition(int childposition, int groupposition) {
        int position = (int) (childposition / (float) getChildrenCount(groupposition) * alphaIndex.size());
        if (position < alphaIndex.size()) {
            return alphaIndex.get(position);
        } else {
            return alphaIndex.get(alphaIndex.size() - 1);
        }
    }

    @Override
    public int getScrollPosition(int childposition, int groupposition) {
        String code = alphaIndexMap.get(getIndicatorForPosition(childposition, groupposition));
        List<CityItem> list = ((CityItem) getGroup(groupposition)).subCityList;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getCode().equals(code)) {
                return i;
            }
        }

        return childposition;
    }

    class ViewHolder {
        TextView cityName;
        TextView groupIndicator;
        TextView selectIndicator;
        TextView cityIndexLabel;
        ListView cityList;

        public ViewHolder(View view) {
            cityName = (TextView) view.findViewById(R.id.cityName);
            groupIndicator = (TextView) view.findViewById(R.id.groupIndicator);
            selectIndicator = (TextView) view.findViewById(R.id.selectIndicator);
            cityIndexLabel = (TextView) view.findViewById(R.id.cityIndexLabel);
            cityList = (ListView) view.findViewById(R.id.cityList);
        }
    }
}
