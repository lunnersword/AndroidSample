package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.view.IconTextView;

import butterknife.Bind;
import butterknife.ButterKnife;

public class OuterPaywayAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    JSONArray mData;

    public OuterPaywayAdapter(Context context, JSONArray data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }


    static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.iconPayway)
        IconTextView iconPayway;
        @Bind(R.id.textPaywayName)
        TextView textPaywayName;
        @Bind(R.id.textPaywayDesc)
        TextView textPaywayDesc;
        @Bind(R.id.iconCheckbox)
        IconTextView iconCheckbox;
    }

    public void updateData(JSONArray data) {
        mData = data;
    }

    @Override
    public int getCount() {
        return mData != null ? mData.size() : 0;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_outer_payway, parent, false);
            ViewHolder holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        }
        ViewHolder holder = (ViewHolder) convertView.getTag();

        try {
            JSONObject item = mData.getJSONObject(position);
            holder.textPaywayName.setText(item.getString("title"));
            holder.textPaywayDesc.setText(item.getString("desc"));
            if (item.getIntValue(Pay.TAG_PAY_TYPE) == Pay.PAY_WAY_ALIPAY) {
                holder.iconPayway.setText(mContext.getResources().getString(R.string.icon_alipay_v2));
                holder.iconPayway.setTextColor(mContext.getResources().getColor(R.color.alipay_color));
            } else if (item.getIntValue(Pay.TAG_PAY_TYPE) == Pay.PAY_WAY_WECHAT) {
                holder.iconPayway.setText(mContext.getResources().getString(R.string.icon_wechat));
                holder.iconPayway.setTextColor(mContext.getResources().getColor(R.color.wechat_color));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return convertView;
    }
}
