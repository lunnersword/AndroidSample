package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.model.UserOutDO;
import com.meidalife.shz.util.ShareActivity;
import com.usepropeller.routable.Router;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ServicePublishCompleteActivity extends BaseActivity {
    private boolean isEditMode = false;
    ShareActivity shareActivity;
    ServiceItem serviceItem;

    @Bind(R.id.backButton)
    TextView backButton;
    @Bind(R.id.publishHintTitle)
    TextView publishHintTitle;
    @Bind(R.id.checkDetailButton)
    TextView checkDetailButton;
    @Bind(R.id.continuePublishButton)
    TextView continuePublishButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_publish_complete);
        ButterKnife.bind(this);
        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            ArrayList<String> images = new ArrayList<String>();
            images.add(bundle.getString("image"));
            serviceItem = new ServiceItem();
            serviceItem.setImages(images);
            serviceItem.setContent(bundle.getString("desc"));
            serviceItem.setItemId(bundle.getString("itemId"));
            serviceItem.setTag(bundle.getString("title"));

            UserOutDO user = new UserOutDO();
            user.setUserId(Helper.sharedHelper().getUserId());
            user.setUserName(Helper.sharedHelper().getStringUserInfo(Constant.USER_NICK));
            serviceItem.setUser(user);

            boolean bindGezi = bundle.getBoolean("bindGezi", false);
            if (bindGezi) {
                Bundle params = new Bundle();
                params.putString("serviceId", serviceItem.getItemId());
                params.putInt("type", ServiceJoinSquareActivity.ADD_SERVICE_TO_SQUARES);
                Router.sharedRouter().open("serviceJoinSquare", params);
            }
        }
        isEditMode = getIntent().getBooleanExtra(Constant.EXTRA_TAG_EDIT_MODE, false);
        publishHintTitle.setText(isEditMode ? "保存成功" : "发布成功");
        shareActivity = new ShareActivity(this);

        checkDetailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handlerCheckServiceDetail(v);
            }
        });

        continuePublishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                continuePublishService(v);
            }
        });
    }

    @OnClick(R.id.backButton)
    public void handleClose(View view) {
        finish();
    }

    public void handleShareCircle(View view) {
        if (serviceItem == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        shareActivity.shareServiceWithWxCircle(this, serviceItem);
    }

    public void handleShareWechat(View view) {
        if (serviceItem == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        shareActivity.shareServiceWithWxChat(this, serviceItem);
    }

    public void handleShareSina(View view) {
        if (serviceItem == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        shareActivity.shareServiceWithWeibo(this, serviceItem);
    }

    public void handleShareQQ(View view) {
        if (serviceItem == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        shareActivity.shareServiceWithQQ(this, serviceItem);
    }

    @OnClick(R.id.checkDetailButton)
    public void handlerCheckServiceDetail(View view) {
        Router.sharedRouter().open("services/" + serviceItem.getItemId());
        finish();
    }

    @OnClick(R.id.continuePublishButton)
    public void continuePublishService(View view) {
        Router.sharedRouter().open("publish");
        finish();
    }
}
