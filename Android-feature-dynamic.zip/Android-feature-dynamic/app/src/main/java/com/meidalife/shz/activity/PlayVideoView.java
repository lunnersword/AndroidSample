package com.meidalife.shz.activity;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.widget.VideoView;
import com.yixia.camera.util.DeviceUtils;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 视频预览
 *
 * @author zuozheng.zhq
 */
public class PlayVideoView extends View implements VideoView.OnPlayStateListener, MediaPlayer.OnPreparedListener {


    public static final int PROGRESS_CHANGED = 0;

    /**
     * 窗体宽度
     */
    private int mWindowWidth;
    /**
     * 视频信息
     */

    /**
     * 是否需要恢复视频播放
     */
    private boolean mNeedResume;

    @Bind(R.id.video_player_close)
    View backView;

    @Bind(R.id.video_player_view)
    VideoView mVideoView;

    @Bind(R.id.video_player_button)
    TextView mPlayButton;

    @Bind(R.id.seekBar)
    SeekBar seekBar;

    @Bind(R.id.timeTip)
    TextView timeTip;

    private Activity mContext;
    private volatile boolean isPlaying = false;
    View rowView;
    int currentLength;

    private Thread mPlayThread;

//    DecimalFormat df = new DecimalFormat("#0");
//
//    NumberFormat ddf = NumberFormat.getNumberInstance();

    public PlayVideoView(Activity context, String videoUrl) {
        super(context);
        this.mContext = context;
        init(videoUrl);
    }

    public View getView() {
        return rowView;
    }

    protected void init(String videoUrl) {
        mWindowWidth = DeviceUtils.getScreenWidth(mContext);
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        rowView = inflater.inflate(R.layout.view_play_video, null);

        //绑定控件
        ButterKnife.bind(this, rowView);

        //播放器默认不循环
        mVideoView.setLooping(false);

        mVideoView.setVideoPath(videoUrl);

        timeTip.setText(formatDurationTime(0) + "/" + formatDurationTime((int) Math.floor(mVideoView.getDuration() / 1000)));

        //绑定事件
//        mPlayButton.setOnClickListener(this);
        mVideoView.setOnPreparedListener(this);
        mVideoView.setOnPlayStateListener(this);

        // 为进度条添加进度更改事件
        seekBar.setOnSeekBarChangeListener(change);

        //初始数据
//        findViewById(R.id.record_layout).getLayoutParams().height = mWindowWidth;//设置1：1预览范围
    }

    private SeekBar.OnSeekBarChangeListener change = new SeekBar.OnSeekBarChangeListener() {

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            int progress = seekBar.getProgress();
            if (mVideoView != null && mVideoView.isPlaying()) {
                // 设置当前播放的位置
                mVideoView.seekTo(progress);
            }
        }
    };

//    public void setData(String url) {
//        mVideoView.setVideoPath(url);
//    }

    @Override
    public void onPrepared(MediaPlayer mp) {
//        mVideoView.start();
//        mVideoView.setLooping(false);
    }

//    @Override
//    public void onClick(View v) {
//        switch (v.getId()) {
//            case R.id.video_player_button:
//                playVideo();
//                break;
//        }
//    }

    public void playVideo() {
        if (isPlaying) {
            mPlayButton.setText(getResources().getString(R.string.icon_pause));
            currentLength = mVideoView.getCurrentPosition();
            mVideoView.pause();
        } else {
            mPlayButton.setText(getResources().getString(R.string.icon_play));
            mVideoView.start();
            updateSeekBar();
        }
        isPlaying = !isPlaying;
    }

    void updateSeekBar() {
        // 按照初始位置播放
        mVideoView.seekTo(currentLength);
        // 设置进度条的最大进度为视频流的最大播放时长
        seekBar.setMax(mVideoView.getDuration());

        // 开始线程，更新进度条的刻度
        mPlayThread = new Thread(recordThread);
        mPlayThread.start();
    }

    private Runnable recordThread = new Runnable() {
        @Override
        public void run() {
            while (isPlaying) {
                if (mVideoView.getCurrentPosition() == mVideoView.getDuration()) {
                    break;
                }
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                myHandler.sendEmptyMessage(PROGRESS_CHANGED);
            }
        }
    };


    Handler myHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case PROGRESS_CHANGED:
                    int current = mVideoView.getCurrentPosition();
                    seekBar.setProgress(current);
                    timeTip.setText(formatDurationTime((int) Math.floor(current / 1000)) + "/" + formatDurationTime((int) Math.floor(mVideoView.getDuration() / 1000)));
                    break;
            }
        }
    };

    public void onStateChanged(boolean isPlaying) {
        //todo 如果是播放状态 修改播放按钮样式
        if (isPlaying) {
            mPlayButton.setText(getResources().getString(R.string.icon_pause));
        } else {
            mPlayButton.setText(getResources().getString(R.string.icon_play));
        }
    }

    public static boolean isExternalStorageRemovable() {
        if (DeviceUtils.hasGingerbread())
            return Environment.isExternalStorageRemovable();
        else
            return Environment.MEDIA_REMOVED.equals(Environment.getExternalStorageState());
    }

    public void stop() {
        try {
            if (mPlayThread != null) {
                mPlayThread.interrupt();
            }
            mVideoView.release();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            isPlaying = false;
        }
    }
//
//    @Override
//    public boolean onError(MediaPlayer mp, int what, int extra) {
//        isPlaying = false;
//        return false;
//    }

    private String formatDurationTime(int time) {
        if (time < 10) {
            return "00:0" + time;
        }
        return "00:" + time;
    }

}
