package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.common.util.UriUtil;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.DelAttentionListener;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.model.UserOutDO;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import java.util.List;

/**
 * Created by zuozheng on 15/11/10.
 * 我的收藏服务的adapter
 */
public class FavoriteServiceAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private List<ServiceItem> serviceItemList;

    DelAttentionListener delAttentionListener;


    public void setDelAttentionListener(DelAttentionListener delAttentionListener) {
        this.delAttentionListener = delAttentionListener;
    }

    public FavoriteServiceAdapter(Context context, List<ServiceItem> serviceItemList) {
        this.mContext = context;
        this.mInflater = LayoutInflater.from(context);
        this.serviceItemList = serviceItemList;
    }

    public void setData(List<ServiceItem> discoverItemList) {
        this.serviceItemList = discoverItemList;
    }

    @Override
    public int getCount() {
        return serviceItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return serviceItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;

        if (convertView == null || convertView.getTag() == null) {
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.favorite_service_card_item, parent, false);
            viewHolder.avatar = (ImageView) convertView.findViewById(R.id.avatar);
            viewHolder.title = (TextView) convertView.findViewById(R.id.item_title);
            viewHolder.serviceType = (TextView) convertView.findViewById(R.id.service_type);
            viewHolder.image = (ImageView) convertView.findViewById(R.id.item_image);
            viewHolder.price = (TextView) convertView.findViewById(R.id.item_price);
            viewHolder.chatView = convertView.findViewById(R.id.buttonChat);
            viewHolder.cancelView = convertView.findViewById(R.id.cancelFavorite);
            viewHolder.rootView = convertView.findViewById(R.id.service_card);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        if (position < serviceItemList.size()) {
            final ServiceItem item = serviceItemList.get(position);

            final UserOutDO user = item.getUser();
            if (user != null) {
                String avatarUrl = ImgUtil.getCDNUrlWithWidth(user.getUserAvatar(),
                        mContext.getResources().getDimensionPixelSize(R.dimen.discover_avatar_size));
                if (TextUtils.isEmpty(avatarUrl)) {
                    Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(user.getUserId()), user.getUserGender());
                    viewHolder.avatar.setImageURI(getDefaultAvatarUri);
                } else {
                    viewHolder.avatar.setImageURI(Uri.parse(avatarUrl));
                }
            }

            viewHolder.title.setText(mContext.getResources().getString(R.string.label_i_can) + " " + item.getTag());

            String typeLabel = typeToLabel(item.getServiceType(), item.getCityName());
            if (typeLabel == null) {
                viewHolder.serviceType.setVisibility(View.GONE);
            } else {
                viewHolder.serviceType.setVisibility(View.VISIBLE);
                viewHolder.serviceType.setText(typeLabel);
            }

            if (item.getImages() != null && item.getImages().size() > 0) {
                viewHolder.image.setImageURI(Uri.parse(item.getImages().get(0)));
            } else {
                //todo 没有图片  显示默认
                Uri img = new Uri.Builder()
                        .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.avatar)).build();
                viewHolder.image.setImageURI(img);
            }
            viewHolder.price.setText(String.valueOf(item.getPrice()));


            viewHolder.chatView.setVisibility(View.VISIBLE);
            viewHolder.chatView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    // 使用 initIm 接口调用 方式
                    String action = "chatFormService/";
                    if (user != null) {
                        action += user.getUserId();
                    }
                    action += "/";
                    action += item.getItemId();

                    if (Helper.sharedHelper().hasToken()) {
                        Router.sharedRouter().open(action);
                        LogParam param = new LogParam();
                        param.setType(LogUtil.TYPE_CUSTOMIZE);
                        param.setEid(LogUtil.EVENT_ID_CHAT_CLICK);
                        param.setPvid(item.getPvid());
                        LogUtil.log(param);
                    } else {
                        Bundle bundle = new Bundle();
                        bundle.putString("action", action);
                        Router.sharedRouter().open("signin", bundle);
                    }
                }
            });

            if (item.isLongClick()) {
                viewHolder.cancelView.setVisibility(View.VISIBLE);
            } else {
                viewHolder.cancelView.setVisibility(View.GONE);
            }

            viewHolder.rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("services/" + item.getItemId());
                }
            });

            //
            viewHolder.rootView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    //todo 修改adapter 记录对应数据的长按状态 长按之后滑动列表 listview的复用机制
                    //设置取消收藏区域可见
//                viewHolder.cancelView.setVisibility(View.VISIBLE);
                    item.setIsLongClick(true);
                    notifyDataSetChanged();
                    return false;
                }
            });

            viewHolder.cancelView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    delAttentionListener.onDelClick(item.getItemId(), position);
                }
            });
        }

        return convertView;
    }

    public static class ViewHolder {
        ImageView avatar;//头像
        TextView title;//宝贝标题
        TextView serviceType;//服务类型
        ImageView image;//图片
        TextView price;//价格
        View chatView;//聊天

        View cancelView;//取消收藏

        View rootView;//item root view
    }

    public static String typeToLabel(int serviceType, String cityName) {
        String label = null;
        switch (serviceType) {
            case 1:
                label = (cityName == null ? "" : cityName) + "上门";
                break;
            case 2:
                label = (cityName == null ? "" : cityName) + "到店";
                break;
            case 3:
                label = "线上";
                break;
            case 4:
                label = "邮寄";
                break;
            default:
                label = null;
        }
        return label;
    }
}
