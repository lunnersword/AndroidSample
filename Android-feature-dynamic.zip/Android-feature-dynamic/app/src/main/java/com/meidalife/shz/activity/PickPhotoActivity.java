package com.meidalife.shz.activity;

import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.AlbumListAdapter;
import com.meidalife.shz.adapter.PhotoGridAdapter;
import com.meidalife.shz.rest.model.Album;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PickPhotoActivity extends BaseActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    private int REQUEST_CODE_CAPTURE_CAMEIA = 2;
    private boolean isCheckbox;
    private int maxLength;
    PhotoGridAdapter adapter;
    ArrayList selectImages;
    String capturePath = null;
    String action = null;
    int position = 0;

    private PopupWindow popupWindow;
    private LinearLayout albumSelector;
    private TextView albumName;

    TextView textSelectCount;
    TextView textMaxLength;
    Button btnConfirm;
    GridView photoGrid;
    private View coverLayer;

    private String currentBucketId = null;
    private String selectedBucketId = null;
    private static final String DEFAULT_WHERE_CLAUSE =
            MediaStore.Images.ImageColumns.SIZE + ">10240";

    private static final String SIZE_RESTRICTION_WHERE_CLAUSE = " and " +
            MediaStore.Images.ImageColumns.WIDTH + ">0 and " +
            MediaStore.Images.ImageColumns.HEIGHT + ">0";
    private static final String ALBUM_SELECTION_WHERE_CLAUSE = DEFAULT_WHERE_CLAUSE +
            " and bucket_id=?";

    private List<Album> albumList = new ArrayList<>();
    private String capturedImagePath = null;

    private static final String[] STORE_IMAGES = {
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media._ID,
            MediaStore.Images.ImageColumns.BUCKET_ID,
            MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME
    };

    @Override
    /**
     * isCheckbox 是否多选
     * maxLength 最多可选图片张数
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_photo);
        initActionBar(R.string.title_activity_pick_photo, true);

        Bundle intentExtras = getIntent().getExtras();
        isCheckbox = intentExtras.getBoolean("isCheckbox");
        maxLength = isCheckbox ? intentExtras.getInt("maxLength") : 1;
        selectImages = new ArrayList();
        action = intentExtras.getString("action");
        //个人主页coverFlow记录位置
        position = intentExtras.getInt("position");

        textSelectCount = (TextView) findViewById(R.id.selectCount);
        textMaxLength = (TextView) findViewById(R.id.maxLength);
        btnConfirm = (Button) findViewById(R.id.btnConfirm);
        photoGrid = (GridView) findViewById(R.id.photoGrid);

        textMaxLength.setText("" + maxLength);
        textSelectCount.setText("" + selectImages.size());

        ArrayList data = new ArrayList();
        initAdatper(data);

        initComponent();
        getLoaderManager().initLoader(0, null, this);

        initAlbumListView();
    }

    public void handleConfirmSelect(View view) {
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("images", selectImages);
        bundle.putInt("position", position);
        intent.putExtras(bundle);

        if (action != null) {
            Router.sharedRouter().open(action, bundle);
        } else {
            setResult(RESULT_OK, intent);
        }
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_CAPTURE_CAMEIA && resultCode == RESULT_OK) {
            // refresh
            //getLoaderManager().restartLoader(0, null, this);
            selectImages.clear();
            selectImages.add(capturedImagePath);
            Intent intent = new Intent();
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("images", selectImages);
            bundle.putInt("position", position);
            intent.putExtras(bundle);

            if (action != null) {
                Router.sharedRouter().open(action, bundle);
            } else {
                setResult(RESULT_OK, intent);
            }
            finish();
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle bundle) {
        String selections = DEFAULT_WHERE_CLAUSE;
        String[] selectionArgs = null;
        if (!TextUtils.isEmpty(currentBucketId)) {
            selections = ALBUM_SELECTION_WHERE_CLAUSE;
            selectionArgs = new String[]{currentBucketId};
        }
//        if (Build.VERSION.SDK_INT >= 16) {
//            selections += SIZE_RESTRICTION_WHERE_CLAUSE;
//        }
        CursorLoader loader = new CursorLoader(this,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, STORE_IMAGES, selections,
                selectionArgs, MediaStore.Images.ImageColumns.DATE_MODIFIED);
        return loader;
    }

    @Override
    public void onLoaderReset(Loader<Cursor> arg0) {
        Log.i("Taber", "reset");
    }

    @Override
    public void onLoadFinished(Loader<Cursor> arg0, Cursor cursor) {
        Log.i("Taber", "cursor finish");

        if (albumList.isEmpty() && cursor != null) {
            Album allAlbum = new Album(null, getResources().getString(R.string.all_images), null);
            allAlbum.setSize(cursor.getCount());
            albumList.add(allAlbum);
        }
        Map<String, Album> albumMap = new HashMap<>();

        if (cursor != null && cursor.moveToFirst()) {

            ArrayList data = new ArrayList();
            Log.i("Taber", "cursor finish  first");
            String imagePath;
            int dataColumn = cursor.getColumnIndex(MediaStore.Images.Media.DATA);
            do {
                imagePath = cursor.getString(dataColumn);

                if (imagePath == null) {
                    continue;
                }
                File image = new File(imagePath);
                if (image != null && image.exists()) {
                    data.add(imagePath);
                }

                String bucketId = cursor.getString(cursor.getColumnIndex(MediaStore.Images.
                        ImageColumns.BUCKET_ID));
                String bucketName = cursor.getString(cursor.getColumnIndex(MediaStore.Images.
                        ImageColumns.BUCKET_DISPLAY_NAME));
                String path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.
                        ImageColumns.DATA));
                Album album = new Album(bucketId, bucketName, path);

                if (albumMap.containsKey(bucketId)) {
                    albumMap.get(bucketId).setSize(albumMap.get(bucketId).getSize() + 1);
                } else {
                    albumMap.put(bucketId, album);
                }
            }
            while (cursor.moveToNext());

            if (!albumMap.isEmpty()) {
                for (String key : albumMap.keySet()) {
                    if (!albumList.contains(albumMap.get(key))) {
                        albumList.add(albumMap.get(key));
                    }
                }
            }

            initAdatper(data);
        }

        updateAlbumListView();
    }

    private void initComponent() {
        albumSelector = (LinearLayout) findViewById(R.id.album_selector);
        albumName = (TextView) findViewById(R.id.album_name);
        albumSelector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHideAlbumList(v);
            }
        });
        albumName.setText(getResources().getString(R.string.all_images));
        coverLayer = findViewById(R.id.cover_layer);
    }

    private void initAlbumListView() {
        View albumView = LayoutInflater.from(this).inflate(R.layout.album_list, null);
        final ListView albumListView = (ListView) albumView.findViewById(R.id.album_list);
        AlbumListAdapter albumListAdapter = new AlbumListAdapter(this, albumList);
        albumListView.setAdapter(albumListAdapter);

        albumListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedBucketId = albumList.get(position).getBucketId();
                albumName.setText(albumList.get(position).getBucketName());
                setActionBarTitle(albumList.get(position).getBucketName());
                popupWindow.dismiss();
            }
        });

        popupWindow = new PopupWindow(albumView, ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setAnimationStyle(R.style.PopupWindowAnimation);

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                coverLayer.setVisibility(View.GONE);
                if (selectedBucketId != null && selectedBucketId.equals(currentBucketId)
                        || (selectedBucketId == null && currentBucketId == null)) {
                    return;
                }
                currentBucketId = selectedBucketId;
                getLoaderManager().destroyLoader(0);
                getLoaderManager().initLoader(0, null, PickPhotoActivity.this);
            }
        });
    }

    private void showOrHideAlbumList(View v) {
        if (null != popupWindow && popupWindow.isShowing()) {
            popupWindow.dismiss();
            return;
        }

        popupWindow.showAtLocation(v, Gravity.BOTTOM, 0,
                getResources().getDimensionPixelSize(R.dimen.action_bar_height));
        coverLayer.setVisibility(View.VISIBLE);
    }

    public void updateAlbumListView() {
        albumSelector.setEnabled(true);

        if (popupWindow != null) {
            int listViewHeight = albumList.size() *
                    getResources().getDimensionPixelSize(R.dimen.album_item_height);
            int maxHeight = (int) (getResources().getDisplayMetrics().heightPixels * 0.7);

            popupWindow.setHeight(maxHeight > listViewHeight ? listViewHeight : maxHeight);
            popupWindow.update();
        }
    }

    public void initAdatper(ArrayList data) {
        adapter = new PhotoGridAdapter(this, data);
        adapter.setOnClickListener(new PhotoGridAdapter.OnClickListener() {
            @Override
            public void onTakePhoto(View v, int position) {
                String state = Environment.getExternalStorageState();
                if (state.equals(Environment.MEDIA_MOUNTED)) {
                    Intent getImageByCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                    // Ensure that there's a camera activity to handle the intent
                    if (getImageByCamera.resolveActivity(getPackageManager()) != null) {
                        // Create the File where the photo should go
//                        Uri imageFileUri = getContentResolver().insert(
//                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new ContentValues());
//                        capturePath = imageFileUri.getPath();
                        capturedImagePath = ImgUtil.getSavedImagePath(PickPhotoActivity.this) + File.separator
                                + "service_" + System.currentTimeMillis() + ".jpg";
                        File imageFile = new File(capturedImagePath);
                        getImageByCamera.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(imageFile));
                        startActivityForResult(getImageByCamera, REQUEST_CODE_CAPTURE_CAMEIA);
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "请确认已经插入SD卡", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onTogglePhoto(View v, int position, String path) {
                TextView checkView = (TextView) v.findViewById(R.id.checkbox);
                int index = selectImages.indexOf(path);
                Boolean check;

                if (index == -1) {
                    if (selectImages.size() < maxLength) {
                        selectImages.add(path);
                        check = true;
                    } else {
                        MessageUtils.showToastCenter("最多只能选择" + maxLength + "张");
                        check = false;
                    }
                } else {
                    selectImages.remove(index);
                    check = false;
                }

                if (checkView != null) {
                    checkView.setText(check ?
                            R.string.icon_checkbox_active :
                            R.string.icon_checkbox_normal);
                    checkView.setTextColor(getResources().getColor(check ?
                            R.color.brand :
                            R.color.grey_d));
                }
                textSelectCount.setText("" + selectImages.size());
            }
        });
        photoGrid.setAdapter(adapter);
        adapter.setSelectImages(selectImages);
    }

}
