package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.AddressSuggestAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.PositionOutDO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.LoadUtilV2;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * @author zhq
 * @createtime 2016/2/3
 * @description 通过关键词，城市code和坐标 搜索地址列表
 */
public class SearchAddressActivity extends BaseActivity {
//    private final String SEARCH_HISTORY_KW_SPLIT = ",";

    //    private int startLeft;
//    private int startTop;
//    private int height;
//    private int spaceWidth;
//    private int spaceHeight;
//    private int screenWidth;
    private static final int PAGE_SIZE = 20;
    //开始页数为1
    int page = 0;

    //地址需要翻页功能
    boolean isLoading = false;
    private boolean isComplete = false;

    private boolean mRefresh = false;
    @Bind(R.id.root_view)
    ViewGroup rootView;
    @Bind(R.id.head_search_back)
    TextView backButton;
    @Bind(R.id.head_search_input)
    EditText searchInput;
    @Bind(R.id.searchKeywordClear)
    TextView searchKeywordClear;
    @Bind(R.id.head_search_commit)
    TextView searchCommit;

    @Bind(R.id.search_list)
    ListView searchListView;

    @Bind(R.id.recommendAddressListEmpty)
    ViewGroup recommendAddressListEmpty;

    private String mCityCode;
    private String mCurLongitude;
    private String mCurLatitude;

    private LoadUtilV2 helperV2;
    private AddressSuggestAdapter mAdapter;

    List<PositionOutDO> resultList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_square_address);

        Bundle extras = getIntent().getExtras();
        mCityCode = extras.getString("cityCode");
        mCurLongitude = extras.getString("lng");
        mCurLatitude = extras.getString("lat");

        ButterKnife.bind(this);
        initData();
    }

    private void initData() {


        mAdapter = new AddressSuggestAdapter(this);
//        mAdapter.setIsShowSelected(true);
        searchListView.setAdapter(mAdapter);

        helperV2 = new LoadUtilV2(getLayoutInflater());


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        //对软键盘搜索处理
        searchInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH
                        || (event != null && KeyEvent.KEYCODE_ENTER == event.getKeyCode() && KeyEvent.ACTION_DOWN == event.getAction())) {
                    String searchWord = searchInput.getText().toString();
//                    if (TextUtils.isEmpty(searchWord) && !TextUtils.isEmpty(hintKeyword)) {
//                        searchWord = hintKeyword;
//                    }
                    commitSearch(searchWord);
                    return true;
                }
                return false;
            }
        });

        searchKeywordClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchInput.setText("");
            }
        });

        searchCommit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchWord = searchInput.getText().toString();
                if (TextUtils.isEmpty(searchWord)) {
                    return;
                }
                commitSearch(searchWord);
            }
        });

        searchListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PositionOutDO currentPosition = mAdapter.getItem(position);
                Log.v("SearchAddressForSquare", "click address: " + currentPosition.getAddress() + currentPosition.getAddress());

                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putSerializable("positionDO", currentPosition);
                intent.putExtras(bundle);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        searchListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == (view.getCount() - 1)) {
                        String searchWord = searchInput.getText().toString();
                        if (TextUtils.isEmpty(searchWord)) {
                            return;
                        }
                        xhrServices(false, false, searchWord);
                    }
                }

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });
    }

    private void commitSearch(String word) {
        searchInput.setText(word);
        searchInput.setSelection(word.length());

        page = 0;
        isLoading = false;
        isComplete = false;
        xhrServices(true, true, word);
    }

    private void xhrServices(boolean showLoading, final boolean refresh, String word) {
        if (isLoading || isComplete) {
            return;
        }

        isLoading = true;
//        if (showLoading) {
//            mLoadUtil.loadPre(rootView, mSwipeRefreshLayout);
//        }
        mRefresh = refresh;
        xhrSearchAddress(word);
    }


    private void xhrSearchAddress(String word) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("poiLongitude", mCurLongitude);
            jsonObject.put("poiLatitude", mCurLatitude);
            jsonObject.put("cityCode", mCityCode);
            jsonObject.put("keyword", word);
            jsonObject.put("offset", page * PAGE_SIZE);
            //type:2 表示格子地址list
            jsonObject.put("type", "2");
            HttpClient.get("1.0/address/search", jsonObject, JSONObject.class, callback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    HttpClient.HttpCallback<JSONObject> callback = new HttpClient.HttpCallback<JSONObject>() {
        @Override
        public void onSuccess(JSONObject jsonObj) {
            List<PositionOutDO> list = JSON.parseArray(jsonObj.getString("results"), PositionOutDO.class);
            if (CollectionUtil.isEmpty(list) || list.size() < PAGE_SIZE) {
                isComplete = true;
            }

            if (mRefresh) {
                resultList.clear();
            }

            resultList.addAll(list);
            mAdapter.setData(resultList);
            mAdapter.notifyDataSetChanged();

            if (CollectionUtil.isEmpty(resultList)) {
                recommendAddressListEmpty.setVisibility(View.VISIBLE);
                searchListView.setVisibility(View.GONE);
            } else {
                recommendAddressListEmpty.setVisibility(View.GONE);
                searchListView.setVisibility(View.VISIBLE);
            }

            isLoading = false;
            page++;
        }

        @Override
        public void onFail(HttpError error) {
            MessageUtils.showToast("获取附近地址失败: " + error.getMessage());
            isLoading = false;
            page--;
        }
    };

}
