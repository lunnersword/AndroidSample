package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.DynamicDetailBottomAdapter;
import com.meidalife.shz.adapter.DynamicDetailNavTabAdapter;
import com.meidalife.shz.adapter.DynamicImagesAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DynamicAdditionDO;
import com.meidalife.shz.rest.model.DynamicBottomDO;
import com.meidalife.shz.rest.model.DynamicDetailOutDO;
import com.meidalife.shz.rest.model.DynamicRelatedServiceDO;
import com.meidalife.shz.rest.model.DynamicTabDO;
import com.meidalife.shz.rest.model.DynamicUserOutDO;
import com.meidalife.shz.rest.model.JobDO;
import com.meidalife.shz.rest.request.RequestDynamic;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.umeng.socialize.media.UMImage;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 动态详情页
 * Created by zuozheng 2016/04/01
 */
public class DynamicDetailActivity extends BaseActivity implements AbsListView.OnScrollListener, ViewPager.OnPageChangeListener {

//    private static final int MENU_ITEM_SHARE = 0;
//    private static final int MENU_ITEM_SEARCH = 1;
//    private static final int MENU_ITEM_HOME = 2;
//    private static final int MENU_ITEM_JUBAO = 3;

    private String feedId;
    private String userId = null;

    private boolean isComplete = false;
    private boolean isLoading = false;
    private int previous;
    private int page = 0;
    private int pageSize = 10;

    private DynamicDetailNavTabAdapter mTabAdapter;
    private DynamicDetailBottomAdapter mBottomAdapter;

    private DynamicDetailOutDO shareDO;
    ArrayList<DynamicTabDO> mTabList = new ArrayList<>();
    List<DynamicBottomDO> mBottomList = new LinkedList<>();
    DynamicTabDO mCurrentCate = new DynamicTabDO();

    private Context context;
    private ShareActivity shareActivity;
    private SocialSharePopupWindow socialSharePopupWindow;
    private CommentItemListener msgBoardItemListener;

    private Handler handler = new Handler();

    View headerView;
    private ProgressBar footProgressBar;
    private View inputViewGroup;

    ViewGroup contentRoot;
    ListView mListView;
    View detailBottom;
    GridView navTabViewTop;

    @Bind(R.id.avatar)
    SimpleDraweeView avatar;
//    @Bind(R.id.vStar)
//    View vStar;

    @Bind(R.id.nickView)
    TextView nickView;
    @Bind(R.id.iconGender)
    TextView iconGender;
    @Bind(R.id.jobsViewGroup)
    LinearLayout jobsViewGroup;

    @Bind(R.id.jobTitleView)
    TextView jobTitleView;

    @Bind(R.id.unFocusView)
    ViewGroup unFocusView;
    @Bind(R.id.focusedView)
    TextView focusedView;

    @Bind(R.id.cellPhotoInfo)
    ViewGroup cellPhotoInfo;
    @Bind(R.id.singleImage)
    SimpleDraweeView singleImage;
    @Bind(R.id.imageList)
    GridView imageList;

    @Bind(R.id.videoCellInfo)
    ViewGroup videoCellInfo;
    @Bind(R.id.coverImageView)
    SimpleDraweeView coverImageView;

    @Bind(R.id.videoPlayButton)
    ViewGroup videoPlayButton;

    @Bind(R.id.liveVideoGroup)
    ViewGroup liveVideoGroup;
    @Bind(R.id.videoTimeView)
    TextView videoTimeView;

    @Bind(R.id.voiceViewGroup)
    ViewGroup voiceViewGroup;
    @Bind(R.id.voiceTimeSpan)
    TextView voiceTimeSpan;

    @Bind(R.id.publishTimeView)
    TextView publishTimeView;
    @Bind(R.id.contentTextView)
    TextView contentTextView;

    //关联服务
    @Bind(R.id.dynamic_relate_service)
    ViewGroup dynamic_relate_service;
    @Bind(R.id.serviceImage)
    SimpleDraweeView serviceImage;
    @Bind(R.id.serviceTagView)
    TextView serviceTagView;

    @Bind(R.id.judgeStarIconGroup)
    ViewGroup starGroup;
    @Bind(R.id.sellCountView)
    TextView sellCountView;

    @Bind(R.id.navTabView)
    GridView navTabView;

    @Bind(R.id.rewardTotalView)
    TextView rewardTotalView;

    private ViewGroup noMsgView;
    private TextView noMsgViewTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_detail);
        initActionBar("动态详情", true, true);

        mButtonRight.setText(R.string.icon_share);
        mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (shareDO != null) {
                    showOrHideShareList(v);
//                    LogParam param = new LogParam();
//                    param.setType(TYPE_CUSTOMIZE);
//                    param.setEid(EVENT_ID_SHARE_CLICK);
//                    param.setPvid(shareDO.getPvid());
//                    log(param);
                }
            }
        });
        context = this;
        Bundle extras = getIntent().getExtras();
        feedId = extras.getString("id");
        shareActivity = new ShareActivity(this);

        initView();
        initData();

        xhrData();
    }

    @Override
    public void onBackPressed() {
        if (inputViewGroup.getVisibility() == View.VISIBLE) {
            inputViewGroup.setVisibility(View.GONE);
            detailBottom.setVisibility(View.VISIBLE);
            return;
        }
        super.onBackPressed();
    }

    private void initData() {
        mTabAdapter = new DynamicDetailNavTabAdapter(this, mTabList);
        mBottomAdapter = new DynamicDetailBottomAdapter(context, mBottomList);   // 为保证head显示，因此无论是否有数据，都设置adapter
        mListView.setAdapter(mBottomAdapter);
    }

    void initView() {

//        ButterKnife.bind(this);
        contentRoot = (ViewGroup) findViewById(R.id.dynamic_detail_content_view);
        mListView = (ListView) findViewById(R.id.detail_listview);
        navTabViewTop = (GridView) findViewById(R.id.navTabViewTop);
        detailBottom = findViewById(R.id.dynamic_detail_bottom);


        LayoutInflater inflater = getLayoutInflater();

        //main view
        headerView = inflater.inflate(R.layout.activity_dynamic_detail_header, null);

        noMsgView = (ViewGroup) headerView.findViewById(R.id.noMsgView);
        noMsgViewTextView = (TextView) headerView.findViewById(R.id.noMsgViewTextView);
        mListView.addHeaderView(headerView);
        ButterKnife.bind(this, headerView);

        View footer = inflater.inflate(R.layout.fragment_comment_foot, null);
        footProgressBar = (ProgressBar) footer.findViewById(R.id.detail_comment_foot_pb);
        mListView.addFooterView(footer);
        footer.setVisibility(View.GONE);

//        detailBottom.setVisibility(View.GONE);


        inputViewGroup = findViewById(R.id.detail_comment_input_group);
        EditText inputText = (EditText) findViewById(R.id.comment_input_text);
        TextView inputCommit = (TextView) findViewById(R.id.comment_input_commit);
        msgBoardItemListener = new CommentItemListener(inputText, inputViewGroup, detailBottom);
        inputCommit.setOnClickListener(msgBoardItemListener);


//        mListView = (ListView) findViewById(R.id.detail_msg_board_listview);

        mListView.setOnItemClickListener(msgBoardItemListener);
//        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
//            @Override
//            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
//                final CommentAdapter.PJViewHolder curr = (CommentAdapter.PJViewHolder) view.getTag();
//
//                if (null != curr) {
//                    View contextMenu = LayoutInflater.from(DynamicDetailActivity.this).inflate(R.layout.message_delete_dialog, null);
//                    final AlertDialog dialog = new AlertDialog.Builder(DynamicDetailActivity.this).create();
//                    dialog.setView(contextMenu, 0, 0, 0, 0);
//                    dialog.show();
//                    TextView deleteTv = (TextView) contextMenu.findViewById(R.id.singleContextMenu);
//                    deleteTv.setText(R.string.report);
//                    deleteTv.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            Intent intent = new Intent();
//                            intent.setClass(DynamicDetailActivity.this, ReportActivity.class);
//                            intent.putExtra("targetId", String.valueOf(curr.commentId));
//                            intent.putExtra("target", Constant.REPORT_TYPE_SERVICE_LEAVE_MESSAGE);
//                            startActivity(intent);
//                        }
//                    });
//
//                    return true;
//                }
//                return false;
//            }
//        });


        //未评价view

        headerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                msgBoardItemListener.hideKeyword();
            }
        });

        unFocusView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                follow();
            }
        });


        navTabViewTop.setOnItemClickListener(new ItemClickListener());

        navTabView.setOnItemClickListener(new ItemClickListener());
    }


    class ItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            if (position < mTabList.size()) {
                mCurrentCate = mTabList.get(position);

                for (DynamicTabDO item : mTabList) {
                    if (item.getSearchKey() == mCurrentCate.getSearchKey()) {
                        if (item.isSelected()) {
//                            return;
                        } else {
                            item.setIsSelected(true);
                        }
                    } else {
                        item.setIsSelected(false);
                    }
                }
                mTabAdapter.notifyDataSetChanged();

                //设置当前tabId
                loadMsg(true);
            }
        }
    }

    private void follow() {
        try {
            RequestDynamic.addFollow(userId, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject obj) {
                    MessageUtils.showToast("关注成功");
                    updateFollowView();
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToast("关注失败");
                }
            });
        } catch (Exception e) {
        }
    }

    private void updateFollowView() {
        unFocusView.setVisibility(View.GONE);
        focusedView.setVisibility(View.VISIBLE);
    }

    private void renderCategoryTabs(DynamicDetailOutDO item) {
//        if (CollectionUtil.isEmpty(tabList)) {
//            return;
//        }
//        mTabList.clear();
//        mTabList.addAll(tabList);

        DynamicTabDO commentTab = new DynamicTabDO();
        commentTab.setTabName("留言");
        commentTab.setIsSelected(true);
        commentTab.setSearchKey("comment");
        commentTab.setCount(item.getCommentCount());
        mTabList.add(commentTab);

        DynamicTabDO supportTab = new DynamicTabDO();
        supportTab.setTabName("赞");
        supportTab.setIsSelected(false);
        supportTab.setSearchKey("support");
        supportTab.setCount(item.getLikeCount());
        mTabList.add(supportTab);

        navTabViewTop.setNumColumns(mTabList.size());
        navTabViewTop.setPadding(getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin)
                , 0, getResources().getDisplayMetrics().widthPixels / mTabList.size(), 0);
        navTabView.setNumColumns(mTabList.size());
        navTabView.setPadding(getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin)
                , 0, getResources().getDisplayMetrics().widthPixels / mTabList.size(), 0);
        navTabViewTop.setAdapter(mTabAdapter);
        navTabView.setAdapter(mTabAdapter);
        mTabAdapter.notifyDataSetChanged();

        //设置“推荐” 默认tab
        mCurrentCate = mTabList.get(0);
    }

    public void xhrData() {
        showStatusLoading(contentRoot);
        RequestDynamic.xhrItem(feedId, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
//                loadSuccess(contentRoot);
//                hideStatusErrorNetwork();
//                hideStatusErrorServer();
                hideStatusLoading();

                if (result != null && result.containsKey("result")) {
                    List<DynamicDetailOutDO> detailList = JSON.parseArray(result.getString("result"), DynamicDetailOutDO.class);
                    if (CollectionUtil.isNotEmpty(detailList)) {
                        renderView(detailList.get(0));

                        loadMsg(true);
                        shareDO = detailList.get(0);
                    }
                }
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(DynamicDetailActivity.class.getName(), "req item data fail, itemId=" +
                        feedId + ", " + error.toString());
                hideStatusLoading();

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(contentRoot, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrData();
                        }
                    });
                }
                showStatusErrorServer(contentRoot, error, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        xhrData();
                    }
                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_REWARD) {
            if (resultCode == RESULT_OK && data != null) {
                int rewardAmount = data.getIntExtra("amount", 0);
                String desc = data.getStringExtra("rewardsDesc");
                boolean result = data.getBooleanExtra(Pay.TAG_PAY_RESULT, false);
                if (result && rewardAmount > 0) {
                    //todo 更新打赏总额
                } else {
                    MessageUtils.showToast(R.string.reward_failed);
                }
            }

        }
    }


    public void renderView(final DynamicDetailOutDO item) {

        renderItemView(item);

        //渲染tab
        renderCategoryTabs(item);

        renderBottomView(item);
    }

    void renderItemView(final DynamicDetailOutDO item) {

        DynamicUserOutDO user = item.getUser();
        if (user != null) {
            userId = user.getUserId();
            // 加载动态用户信息
            nickView.setText(user.getUserNick());
            String gender = "";
            // 设置性别
            if (user.getUserGender() != null) {
                iconGender.setVisibility(View.VISIBLE);
                if (user.getUserGender().equals("woman") || user.getUserGender().equals("F")) {
                    iconGender.setText(getResources().getString(R.string.icon_female));
                    iconGender.setTextColor(getResources().getColor(R.color.color_icon_female));
                } else {
                    iconGender.setText(getResources().getString(R.string.icon_male));
                    iconGender.setTextColor(getResources().getColor(R.color.color_icon_male));
                }
            } else {
                iconGender.setVisibility(View.GONE);
            }

            //头像
            ViewGroup.LayoutParams avatarParams = avatar.getLayoutParams();
            if (TextUtils.isEmpty(user.getAvatarUrl())) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(user.getUserId()), gender);
                avatar.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(user.getAvatarUrl(), avatarParams.width));
                avatar.setImageURI(uri);
            }

            //是否加V

            //职业
            jobsViewGroup.removeAllViews();
            if (CollectionUtil.isNotEmpty(user.getJobs())) {
                for (JobDO job : user.getJobs()) {
                    View jobView = getLayoutInflater().inflate(R.layout.item_dynamic_user_job, null);
                    SimpleDraweeView icon = (SimpleDraweeView) jobView.findViewById(R.id.avatar);
                    TextView titleView = (TextView) jobView.findViewById(R.id.title);
                    ViewGroup.LayoutParams iconParams = icon.getLayoutParams();

                    if (!TextUtils.isEmpty(job.getIconUrl())) {
                        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(user.getAvatarUrl(), iconParams.width));
                        icon.setImageURI(uri);
                        icon.setVisibility(View.VISIBLE);
                    } else {
                        icon.setImageURI(null);
                        icon.setVisibility(View.GONE);
                    }
                    titleView.setText(job.getTitle());
//        jobsView.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, context) * item.getGrade() / 5);
                    jobsViewGroup.addView(jobView);
                }
                jobsViewGroup.setVisibility(View.VISIBLE);
            } else {
                jobsViewGroup.removeAllViews();
                jobsViewGroup.setVisibility(View.GONE);
            }

            jobTitleView.setText(user.getJobTitle());

            if (user.isFocused()) {
                unFocusView.setVisibility(View.GONE);
                focusedView.setVisibility(View.VISIBLE);
            } else {
                unFocusView.setVisibility(View.VISIBLE);
                focusedView.setVisibility(View.GONE);
            }
        }

        //需要优化
        publishTimeView.setText(item.getCreateTime());

        contentTextView.setText(String.format("%s人约单", item.getContent()));


        //计算单张图片和多张图片多宽度
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int screenWidth = size.x;
//        float margin = Helper.convertDpToPixel(77, this);
        float spacing = Helper.convertDpToPixel(10, this);
        float padding = Helper.convertDpToPixel(8, this);
        // width -= margin * 2;
//        screenWidth -= margin;
        screenWidth -= spacing * 2;
        screenWidth -= padding * 2;
        int imgWidth = screenWidth / 3;
        imageList.setColumnWidth(imgWidth);

        DynamicAdditionDO addInfo = item.getAdditionalInfo();
        //type : //0 图片，1 直播， 2 视频 ， 3 音频
        if (addInfo != null) {
            switch (addInfo.getPublicType()) {
                case "0":
                    cellPhotoInfo.setVisibility(View.VISIBLE);
                    voiceViewGroup.setVisibility(View.GONE);
                    videoCellInfo.setVisibility(View.GONE);
                    List<String> images = new LinkedList<>();
                    if (addInfo != null && CollectionUtil.isNotEmpty(addInfo.getImageUrl())) {
                        images.addAll(addInfo.getImageUrl());
                    }

                    if (CollectionUtil.isEmpty(images)) {
                        imageList.setVisibility(View.GONE);
                        singleImage.setVisibility(View.GONE);
                    } else {
                        boolean isSingle = images.size() == 1 ? true : false;

                        if (isSingle) {
                            Uri itemUri = Uri.parse(ImgUtil.getCDNUrlWithHeight(images.get(0), screenWidth));
                            if (itemUri != null) {
                                singleImage.setImageURI(itemUri);
                            } else {
                                singleImage.setImageURI(null);
                            }
                            imageList.setVisibility(View.GONE);
                            singleImage.setVisibility(View.VISIBLE);
                        } else {
                            int endIndex = Math.min(DynamicImagesAdapter.MAX_IMG, images.size());
                            images = images.subList(0, endIndex);
                            imageList.setAdapter(new DynamicImagesAdapter(this, images, imgWidth));

                            singleImage.setVisibility(View.GONE);
                            imageList.setVisibility(View.VISIBLE);
                        }
                    }
                    break;
                case "1":
                    cellPhotoInfo.setVisibility(View.GONE);
                    voiceViewGroup.setVisibility(View.VISIBLE);
                    voiceTimeSpan.setText(addInfo.getAudioLength());
                    liveVideoGroup.setVisibility(View.GONE);
                    break;
                case "2":
                    cellPhotoInfo.setVisibility(View.GONE);
                    voiceViewGroup.setVisibility(View.GONE);
                    videoCellInfo.setVisibility(View.VISIBLE);
                    liveVideoGroup.setVisibility(View.VISIBLE);
                    videoPlayButton.setVisibility(View.GONE);
                    if (TextUtils.isEmpty(addInfo.getVideoPic())) {
                        coverImageView.setImageURI(null);
                        coverImageView.setVisibility(View.GONE);
                    } else {
                        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(addInfo.getVideoPic(), coverImageView.getWidth()));
                        coverImageView.setImageURI(uri);
                        coverImageView.setVisibility(View.VISIBLE);
                    }
                    //转化成十分秒
                    videoTimeView.setText(addInfo.getStartTime());
                    break;
                case "3":
                    cellPhotoInfo.setVisibility(View.GONE);
                    voiceViewGroup.setVisibility(View.GONE);
                    videoCellInfo.setVisibility(View.VISIBLE);
                    liveVideoGroup.setVisibility(View.GONE);
                    videoPlayButton.setVisibility(View.VISIBLE);
                    if (TextUtils.isEmpty(addInfo.getVideoPic())) {
                        coverImageView.setImageURI(null);
                        coverImageView.setVisibility(View.GONE);
                    } else {
                        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(addInfo.getVideoPic(), coverImageView.getWidth()));
                        coverImageView.setImageURI(uri);
                        coverImageView.setVisibility(View.VISIBLE);
                    }
                    break;
                default:
                    cellPhotoInfo.setVisibility(View.GONE);
                    videoCellInfo.setVisibility(View.GONE);
                    voiceViewGroup.setVisibility(View.GONE);
            }
        } else {
            cellPhotoInfo.setVisibility(View.GONE);
            videoCellInfo.setVisibility(View.GONE);
            voiceViewGroup.setVisibility(View.GONE);
        }

//        btnFavCountView.setText(item.getLikeCount());
//        awardCountView.setText(item.getBonusCount());
        DynamicRelatedServiceDO service = item.getLinkedService();
//        List<DynamicRelatedServiceDO> serviceList = item.getLinkedService();
        if (service != null) {
//            DynamicRelatedServiceDO service = serviceList.get(0);
            if (service != null) {
                dynamic_relate_service.setVisibility(View.VISIBLE);
                ViewGroup.LayoutParams serviceImageParams = serviceImage.getLayoutParams();
                if (!TextUtils.isEmpty(service.getFeedIconUrl())) {
                    Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(service.getFeedIconUrl(), serviceImageParams.width));
                    avatar.setImageURI(uri);
                } else {
                    avatar.setImageURI(null);
                }
                serviceTagView.setText(service.getItemTitle());

//                ViewGroup starGroup = (ViewGroup) findViewById(R.id.detail_judge_star_icon_group);
                View starsView = getLayoutInflater().inflate(R.layout.activity_sku_service_detail_stars, null);
                View starsRed = starsView.findViewById(R.id.star_red_group);
                starsRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, context) * service.getLevel() / 5);
                starGroup.removeAllViews();
                starGroup.addView(starsView);

                sellCountView.setText(String.format("%s人约单", service.getSellCount()));
            }
        } else {
            dynamic_relate_service.setVisibility(View.GONE);
        }

        //todo 打赏之后更新
        rewardTotalView.setText(String.format("打赏%s元", item.getBonusCount()));


//        mBottomList.addAll(item.getComments());
//        mBottomAdapter.notifyDataSetChanged();

    }

    private void renderBottomView(final DynamicDetailOutDO itemDO) {

        //点击评论
        ViewGroup commentViewGroup = (ViewGroup) findViewById(R.id.comment_ll);

        commentViewGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                msgBoardItemListener.comment();
            }
        });

        //喜欢
        LinearLayout supportLayout = (LinearLayout) findViewById(R.id.support_ll);
        final TextView supportIconView = (TextView) findViewById(R.id.foot_support_icon);
        if (itemDO.isSupported()) {
            supportIconView.setTextColor(getResources().getColor(R.color.brand_b));
        } else {
            supportIconView.setTextColor(getResources().getColor(R.color.grey_j));
        }

        supportLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    toggleSupport(itemDO, supportIconView);
                } else {
                    jumpToLogin("dynamic/" + feedId);
                    finish();
                }
            }
        });

        View footPLLayout = findViewById(R.id.reward_ll);
        footPLLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    //实现弹窗
                    Bundle params = new Bundle();
                    params.putString("receiverId", itemDO.getUser().getUserId());
                    params.putString("avatar", itemDO.getUser().getAvatarUrl());
                    Router.sharedRouter().openFormResult("rewards", params,
                            Constant.REQUEST_CODE_REWARD, DynamicDetailActivity.this);
                } else {
                    jumpToLogin("dynamic/" + feedId);
                }
            }
        });
    }

    public void updateSupportView(DynamicDetailOutDO itemDO, TextView zanIconView) {
        DynamicTabDO supportTab = mTabList.get(1);
        if (itemDO.isSupported()) {
            zanIconView.setTextColor(getResources().getColor(R.color.brand_b));
            supportTab.setCount(supportTab.getCount() + 1);
        } else {
            zanIconView.setTextColor(getResources().getColor(R.color.grey_j));
            supportTab.setCount(supportTab.getCount() - 1);
        }
        mTabAdapter.notifyDataSetChanged();

        mCurrentCate = mTabList.get(1);
        loadMsg(true);
    }

    private void toggleSupport(final DynamicDetailOutDO dynamic, final TextView icon) {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("feedId", dynamic.getFeedId());
        if (dynamic.isSupported()) {
            params.put("type", 1);
        } else {
            params.put("type", 0);
        }

        RequestDynamic.supportOrCancel(params, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                if (dynamic.isSupported()) {
                    MessageUtils.showToastCenter("成功取消点赞");
                    dynamic.setIsSupported(false);
                } else {
                    MessageUtils.showToastCenter("成功点赞");
                    dynamic.setIsSupported(true);
                }
                updateSupportView(dynamic, icon);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter("点赞失败");
            }
        });

    }

    public JSONObject getBottomParams() {
        JSONObject params = new JSONObject();
        params.put("feedId", feedId);
        params.put("pageSize", pageSize);
        params.put("offset", page * pageSize);
        params.put("name", mCurrentCate.getSearchKey());
        return params;
    }

    public void loadMsg(final boolean reload) {


        if (isLoading) {
            return;
        }
        isLoading = true;
        if (reload) {
            page = 0;
            isComplete = false;
            mBottomList.clear();
        } else {
            //loadMore
            footProgressBar.setVisibility(View.VISIBLE);
        }

        if (isComplete) {
            return;
        }

        RequestDynamic.bottomList(getBottomParams(), new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                isLoading = false;
                detailBottom.setVisibility(View.VISIBLE);
                if (!reload) {
                    footProgressBar.setVisibility(View.GONE);
                }
                List<DynamicBottomDO> dataList = null;
                if (obj != null && obj.containsKey("result")) {
                    dataList = JSON.parseArray(obj.getString("result"), DynamicBottomDO.class);
                }

                if (CollectionUtil.isEmpty(dataList) || dataList.size() < pageSize) {
                    isComplete = true;
                }

                if (CollectionUtil.isNotEmpty(dataList)) {
                    mBottomList.addAll(dataList);
                    page++;
                }

                if (CollectionUtil.isNotEmpty(mBottomList)) {
                    noMsgView.setVisibility(View.GONE);
                    mListView.setOnScrollListener(DynamicDetailActivity.this);
                } else {
                    noMsgView.setVisibility(View.VISIBLE);
                    if (mCurrentCate.getSearchKey().equals("comment")) {
                        noMsgViewTextView.setText(getResources().getString(R.string.dynamic_no_comment));
                    } else {
                        noMsgViewTextView.setText(getResources().getString(R.string.dynamic_no_support));
                    }
                }
                mBottomAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                if (!reload) {
                    footProgressBar.setVisibility(View.GONE);
                }

                detailBottom.setVisibility(View.VISIBLE);

                Log.e(DynamicDetailActivity.class.getName(), "req comment data fail, itemId=" + feedId + ", " + error.toString());

            }
        });
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
            if (view.getLastVisiblePosition() == view.getCount() - 1) {
                loadMsg(false);
            }
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

    }

    private void jumpToLogin(String action) {
        Bundle bundle = new Bundle();
        bundle.putString("action", action);
        Router.sharedRouter().open("signin", bundle);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    public class CommentItemListener implements AdapterView.OnItemClickListener, TextView.OnClickListener {
        //待优化 实现数据和view分离
//        private DynamicDetailBottomAdapter.ViewHolder pre;

        private InputMethodManager keyboard;


        private EditText inputText;
        private View inputViewGroup;
        private View detailFoot;

        private DynamicBottomDO comment;
        private boolean replyItem = false;//区分单条还是回复楼主

        public CommentItemListener(EditText inputText, View inputViewGroup, View detailFoot) {
            keyboard = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            this.inputText = inputText;
            this.inputViewGroup = inputViewGroup;
            this.detailFoot = detailFoot;
        }

        @Override
        public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
            if (!Helper.sharedHelper().hasToken()) {
                finish();
                jumpToLogin("dynamic/" + feedId);
                return;
            }

            inputText.setHint(null);
            DynamicBottomDO bottom = mBottomAdapter.getItem(position);
            if (bottom != null) {
                replyItem = true;

                inputText.setFocusable(true);
                inputText.setFocusableInTouchMode(true);
                inputText.requestFocus();
                inputText.setHint("回复:" + bottom.getUser().getUserNick());
                keyboard.showSoftInput(inputText, InputMethodManager.SHOW_IMPLICIT);
                inputViewGroup.setVisibility(View.VISIBLE);
                detailFoot.setVisibility(View.GONE);
                comment = bottom;
            } else {
                hideKeyword();
            }
        }

        public void onClick(View v) {
            if (!Helper.sharedHelper().hasToken()) {
                finish();
                jumpToLogin("dynamic/" + feedId);
                return;
            }

            keyboard.hideSoftInputFromWindow(v.getWindowToken(), 0);
            final String content = inputText.getText().toString();

            if (StrUtil.isEmpty(content)) {
                Toast.makeText(context, "请输入内容", Toast.LENGTH_LONG).show();
                return;
            }

            addComment(comment, content);

            inputText.setText(null);    // 清空数据
            inputText.setHint(null);
            comment = null;
        }

        public void comment() {
            inputText.setFocusable(true);
            inputText.setFocusableInTouchMode(true);
            inputText.requestFocus();
            inputText.setHint(null);
            keyboard.showSoftInput(inputText, InputMethodManager.SHOW_IMPLICIT);
            inputViewGroup.setVisibility(View.VISIBLE);
            detailFoot.setVisibility(View.GONE);
        }

        public void hideKeyword() {
            keyboard.hideSoftInputFromWindow(inputText.getWindowToken(), 0);
            inputText.setText(null);
            inputViewGroup.setVisibility(View.GONE);
            detailFoot.setVisibility(View.VISIBLE);
            comment = null;
        }

    }

//
//    public void initPopupWindow(final View v) {
//
//        if (null == mPopupListMenu) {
//            mPopupListMenu = new PopupListMenu(this, R.layout.popup_window_share_menu);
//        }
//
//        List<MenuVO> menuList = new ArrayList<>();
//
//        menuList.add(MENU_ITEM_SHARE, new MenuVO(R.string.icon_share, getString(R.string.label_share), 1));
//        menuList.add(MENU_ITEM_SEARCH, new MenuVO(R.string.icon_search, getString(R.string.search), 1));
//        menuList.add(MENU_ITEM_HOME, new MenuVO(R.string.tab_item_home_icon_normal, getString(R.string.tab_item_home_text), 1));
//        menuList.add(MENU_ITEM_JUBAO, new MenuVO(R.string.icon_jubao, getString(R.string.report), 1));
//
//        mPopupListMenu.setMenuData(menuList);
//
//        if (mPopupListMenu.isShowing()) {
//            mPopupListMenu.dismiss();
//        } else {
//            mPopupListMenu.showAsDropDown(v, -50, 0);
//        }
//
//
//        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                switch (position) {
//                    case MENU_ITEM_SHARE: {
//                        shareDynamic(v);
//                        mPopupListMenu.dismiss();
//                        break;
//                    }
//                    case MENU_ITEM_JUBAO: {
//                        reportDynamic();
//                        mPopupListMenu.dismiss();
//                        break;
//                    }
//                }
//            }
//        });
//    }

    private void reportDynamic() {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", String.valueOf(feedId));
        intent.putExtra("target", Constant.REPORT_TYPE_SERVICE);
        startActivity(intent);
    }

    private void showOrHideShareList(View v) {
        if (socialSharePopupWindow == null) {
            socialSharePopupWindow = new SocialSharePopupWindow(this, shareActivity, 0);
        }
        socialSharePopupWindow.setShareUrl(null);
        socialSharePopupWindow.setShareTitle(shareDO.getUser().getUserNick());
        socialSharePopupWindow.setShareDescription(shareDO.getContent());
        socialSharePopupWindow.setShareImage(new UMImage(this, shareDO.getUser().getAvatarUrl()));

        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    void addComment(DynamicBottomDO comment, final String content) {

        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("feed_id", feedId);
        params.put("feed_user_id", shareDO.getUser().getUserId());
        if (comment != null) {
            params.put("reply_user_id", comment.getUser().getUserId());//需要提供回复用户id
        }
        params.put("reply_content", content);

        RequestDynamic.addComment(params, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                Toast.makeText(context, "发表成功", Toast.LENGTH_SHORT).show();
                mListView.setVisibility(View.VISIBLE);
                inputViewGroup.setVisibility(View.GONE);
                detailBottom.setVisibility(View.VISIBLE);
                noMsgView.setVisibility(View.GONE);

                mCurrentCate = mTabList.get(0);
                loadMsg(true);

                DynamicTabDO comment = mTabList.get(0);
                comment.setCount(comment.getCount() + 1);
                mTabAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error.toString());
            }

        });
    }
}
