package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;

import com.alibaba.fastjson.JSON;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.event.SearchParamsChanceEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.SearchFilterDO;
import com.meidalife.shz.rest.model.SearchTopListPromotionDO;
import com.meidalife.shz.rest.model.SearchTopListUserDO;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.rest.request.RequestSearch;
import com.meidalife.shz.util.LoadUtilV2;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by fufeng on 16/1/6.
 */
public class SearchServiceResultFragment extends BaseFragment implements SwipeRefreshLayout.OnRefreshListener {
    public static final String SEARCH_ARG_KEYWORD = "keyword";
    public static final String SEARCH_ARG_TYPE = "type";
    public static final String SEARCH_ARG_EXTRA = "extra";
    public static final String SEARCH_ARG_FIRST_SEARCH = "first_search";

    private static final int PAGE_SIZE = 20;

    protected boolean isVisible;

    private boolean isLoadCompleted = false;
    private int page = 0;
    private String keyword;
    private String type;
    private boolean isLoading = false;
    private boolean hasLoadOnce = false;
    private String defaultOrderValue = "";
    private ArrayList<ServiceItem> items = new ArrayList<>();
    private List<SquareDO> squareDOs = new ArrayList<>();
    private String extraParams;
    private boolean isFirstSearch;
    View rootView;
    View footView;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.searchResultList)
    ListView searchResultList;
    @Bind(R.id.searchEmptyLayout)
    ViewGroup searchEmptyLayout;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;

    ServicesAdapter serviceAdapter;
    SearchCompleteListener searchCompleteListener;
    private LoadUtilV2 helperV2;

    public static SearchServiceResultFragment newInstance() {
        SearchServiceResultFragment fragment = new SearchServiceResultFragment();
        return fragment;
    }

    public void setSearchActionListener(SearchCompleteListener searchCompleteListener) {
        this.searchCompleteListener = searchCompleteListener;
    }

    public void setSearchParams(Bundle bundle) {
        type = bundle.getString(SEARCH_ARG_TYPE);
        keyword = bundle.getString(SEARCH_ARG_KEYWORD);
        extraParams = bundle.getString(SEARCH_ARG_EXTRA);
        isFirstSearch = bundle.getBoolean(SEARCH_ARG_FIRST_SEARCH, false);

        searchService(true);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (null == rootView) {
            rootView = inflater.inflate(R.layout.fragment_search_result, container, false);
            ButterKnife.bind(this, rootView);

            helperV2 = new LoadUtilV2(inflater);

            footView = inflater.inflate(R.layout.fragment_comment_foot, searchResultList, false);
            searchResultList.addFooterView(footView);
            searchResultList.setEmptyView(searchEmptyLayout);
            serviceAdapter = new ServicesAdapter(getActivity(), items);
            searchResultList.setAdapter(serviceAdapter);
            searchResultList.setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                        if (view.getLastVisiblePosition() == view.getCount() - 1 && !isLoadCompleted) {
                            footView.setVisibility(View.VISIBLE);
                            searchService(false);
                        }
                    }

                    final View topChildView = view.getChildAt(0);
                    if (scrollState == SCROLL_STATE_IDLE && view.getFirstVisiblePosition() == 0
                            && topChildView != null && topChildView.getTop() == 0) {
                        mSwipeRefreshLayout.setEnabled(true);
                        searchCompleteListener.onScrollToTop(true);
                    } else {
                        searchCompleteListener.onScrollToTop(false);
                        mSwipeRefreshLayout.setEnabled(false);
                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                }
            });
            mSwipeRefreshLayout.setOnRefreshListener(this);
        }
//        if (isVisible && !hasLoadOnce) {
//            searchService(true);
//        }


        return rootView;
    }

    @Override
    public void onDestroyView() {
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (getUserVisibleHint()) {
            isVisible = true;
            if (null != rootView && !hasLoadOnce) {
                searchService(true);
            }
        } else {
            isVisible = false;
        }
    }

    public List<SquareDO> getSquareListData() {
        return squareDOs;
    }

    private void searchService(final boolean reload) {
        if (isLoading) {
            return;
        }
        if (reload) {
            page = 0;
            helperV2.loadPre(rootLayout, mSwipeRefreshLayout);
        }


        JSONObject searchParams = preParams();

        RequestSearch.search(searchParams, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                if (null == getActivity() || getActivity().isFinishing()) {
                    return;
                }
                if (reload) {
                    items.clear();
                }
                helperV2.loadSuccess(mSwipeRefreshLayout);
                JSONObject json = (JSONObject) result;
                try {
                    Object dataObj = json.get("data");
                    String itemList = null;
                    String squareList = null;
                    String itemFilterItem = null;
                    String additionalData = null;
                    SearchTopListPromotionDO searchTopListPromotionDO = null;
                    SearchTopListUserDO searchTopListUserDO = null;
                    int topListType = -1;
                    if (dataObj instanceof JSONObject) {
                        JSONObject data = (JSONObject) dataObj;
                        JSONArray itemArray;
                        // 正常数据
                        if (data.has("itemList")) {
                            itemList = data.getString("itemList");

                            //设置defaultOrderValue
                            itemArray = data.getJSONArray("itemList");
                            if (itemArray.length() < PAGE_SIZE) {
                                isLoadCompleted = true;
                            } else {
                                isLoadCompleted = false;
                            }
                            if (itemArray.length() > 0) {
                                JSONObject serviceItem = itemArray.getJSONObject(0);
                                if (serviceItem.has("defaultOrderValue"))
                                    defaultOrderValue = serviceItem.getString("defaultOrderValue");
                            }
                        }

                        //排除［］两位字符
                        if (data.has("geziList") && data.getString("geziList").length() > 2) {
                            squareList = data.getString("geziList");
                        } else {
                            squareList = null;
                        }

                        if (data.has("itemFilter")) {
                            itemFilterItem = data.getString("itemFilter");
                            SearchFilterDO searchFilterDO = JSON.parseObject(itemFilterItem, SearchFilterDO.class);
                            searchCompleteListener.onUpdateTabFilter(searchFilterDO);
                        }

                        if (data.has("additionalElement")) {
                            JSONObject additionalElement = data.getJSONObject("additionalElement");
                            if (additionalElement.has("type")) {
                                String type = additionalElement.getString("type");
                                if (type.equals("user")) {
                                    topListType = Constant.SEARCH_TOP_LIST_TYPE_USER;
                                    additionalData = additionalElement.getString("elementInfo");
                                } else if (type.equals("promotion")) {
                                    topListType = Constant.SEARCH_TOP_LIST_TYPE_PROMOTION;
                                    additionalData = additionalElement.getString("elementInfo");
                                }
                            }
                        }
                    } else {
                        itemList = dataObj.toString();
                    }

                    List<ServiceItem> newData = JSON.parseArray(itemList, ServiceItem.class);
                    footView.setVisibility(View.GONE);
                    items.addAll(newData);
                    serviceAdapter.setData(items);
                    serviceAdapter.notifyDataSetChanged();

//                    if (topListType != -1) {
//
//                        switch (topListType) {
//
//                            case Constant.SEARCH_TOP_LIST_TYPE_USER:
//                                searchTopListUserDO = JSON.parseObject(additionalData, SearchTopListUserDO.class);
//                                searchCompleteListener.onUpdateSquareList(searchTopListUserDO, topListType);
//                                break;
//
//                            case Constant.SEARCH_TOP_LIST_TYPE_PROMOTION:
//                                searchTopListPromotionDO = JSON.parseObject(additionalData, SearchTopListPromotionDO.class);
//                                searchCompleteListener.onUpdateSquareList(searchTopListPromotionDO, topListType);
//                                break;
//                        }
//                    } else {
//                        //促销活动  格子 人
//                        if (!TextUtils.isEmpty(squareList)) {
//                            squareDOs = JSON.parseArray(squareList, SquareDO.class);
//                            if (null != squareDOs && !squareDOs.isEmpty()) {
//                                searchCompleteListener.onUpdateSquareList(squareDOs, Constant.SEARCH_TOP_LIST_TYPE_GEZI);
//                            }
//                        }
//                    }

                    if (topListType == Constant.SEARCH_TOP_LIST_TYPE_PROMOTION) {

                        searchTopListPromotionDO = JSON.parseObject(additionalData, SearchTopListPromotionDO.class);
                        searchCompleteListener.onUpdateSquareList(searchTopListPromotionDO, topListType);

                    } else if (!TextUtils.isEmpty(squareList)) {

                        squareDOs = JSON.parseArray(squareList, SquareDO.class);
                        if (null != squareDOs && !squareDOs.isEmpty()) {
                            searchCompleteListener.onUpdateSquareList(squareDOs, Constant.SEARCH_TOP_LIST_TYPE_GEZI);
                        }

                    } else if (topListType == Constant.SEARCH_TOP_LIST_TYPE_USER) {

                        searchTopListUserDO = JSON.parseObject(additionalData, SearchTopListUserDO.class);
                        searchCompleteListener.onUpdateSquareList(searchTopListUserDO, topListType);

                    }
//                    else if (page == 0) {
//                        //刷新topList
//                        searchCompleteListener.onUpdateSquareList(null, -1);
//                    }

                    page++;
                    isFirstSearch = false;
                    hasLoadOnce = true;
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(HttpError error) {
                footView.setVisibility(View.GONE);
                helperV2.loadFail(error, rootLayout, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        searchService(true);
                    }
                });
            }
        });
    }

    private JSONObject preParams() {
        JSONObject params = new JSONObject();
        String cityCode = SHZApplication.getInstance().getLocationManager().getLocation().getCityCode();
        double longitude = SHZApplication.getInstance().getLocationManager().getLocation().getLongitude();
        double latitude = SHZApplication.getInstance().getLocationManager().getLocation().getLatitude();
        try {
            params.put("offset", page * PAGE_SIZE);
            params.put("pageSize", PAGE_SIZE);
            params.put("cityCode", cityCode);
            params.put("longitude", longitude);
            params.put("latitude", latitude);
            params.put("isFirstSearch", isFirstSearch);
            params.put("query", "default:'" + keyword + "'");
            params.put("defaultOrderValue", defaultOrderValue);
            params.put("type", type);

            //拼接两个jsonObject
            if (!TextUtils.isEmpty(extraParams)) {
                String mergeParams = params.toString();
                mergeParams = mergeParams.substring(0, mergeParams.length() - 1); //去最后一个字符 }
                extraParams = extraParams.substring(1, extraParams.length());//去第一个字符 {
                mergeParams = mergeParams + "," + extraParams;
                params = new JSONObject(mergeParams);
            }

            Log.d("mzLog", "params: " + params.toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return params;
    }

    @Override
    public void onRefresh() {
        isFirstSearch = false;
        mSwipeRefreshLayout.setRefreshing(false);
        searchService(true);
    }

    public interface SearchCompleteListener {
        void onUpdateSquareList(Object object, int type);

        void onScrollToTop(boolean top);

        void onUpdateTabFilter(SearchFilterDO searchFilterDO);

    }
}
