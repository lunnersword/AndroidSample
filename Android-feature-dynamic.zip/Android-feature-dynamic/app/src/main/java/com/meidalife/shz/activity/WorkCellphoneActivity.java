package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.view.FontButton;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.Bind;
import butterknife.ButterKnife;

public class WorkCellphoneActivity extends BaseActivity {

    @Bind(R.id.currentWorkCellphone)
    TextView currentWorkCellphone;

    private String STRING_SMS_CODE_RETRY = "重新获取";
    private int MOBILE_PHONE_LENGTH = 11;
    private int SMS_CODE_LENGTH = 4;

    @Bind(R.id.photoNumber)
    EditText phoneView;
    @Bind(R.id.smsCode)
    EditText codeView;

    @Bind(R.id.btnGetSmsCode)
    FontButton btnGetSmsCode;

    //试试语音验证码 隐藏和显示区域
    @Bind(R.id.voiceCodeLL)
    View voiceCodeLL;
    //试试语音验证码 点击区域
    @Bind(R.id.voiceCode)
    View voiceCode;

    @Bind(R.id.voiceCodeTips)
    TextView voiceCodeTips;

    @Bind(R.id.btnBind)
    Button btnBind;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_cellphone);
        initActionBar(R.string.title_activity_change_work_cellphone, true);
        hideIMM();
        ButterKnife.bind(this);

        Bundle bundle = getIntent().getExtras();
        String cellphone = bundle.getString("workCellphone");
        if (cellphone.length() > 0) {
            currentWorkCellphone.setText(cellphone);
        } else {
            currentWorkCellphone.setText("未绑定");
        }
        initPhoneListener();
    }

    public void handleSendSmsCode(View view) {
        codeView.requestFocus();
        if (codeView.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        btnGetSmsCode.setEnabled(false);
        btnGetSmsCode.setText("获取中");
        voiceCode.setEnabled(false);
//        voiceCodeLL.setText("语音验证码");
//        voiceCodeLL.setVisibility(View.INVISIBLE);
        String mobile = phoneView.getText().toString().replace(" ", "");
        try {
            JSONObject params = new JSONObject();
            params.put("mobile", mobile);
            RequestSign.getSmsCode(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    MessageUtils.showToastCenter("验证码已发送至你的手机，请注意查收");
                    btnGetSmsCode.setText("60秒可重发");
                    new CountDownTimer(60000, 1000) {

                        public void onTick(long millisUntilFinished) {
                            btnGetSmsCode.setText(millisUntilFinished / 1000 + "秒可重发");
                        }

                        public void onFinish() {
                            btnGetSmsCode.setText(STRING_SMS_CODE_RETRY);
                            btnGetSmsCode.setEnabled(true);
                            voiceCode.setEnabled(true);
//                            voiceCodeLL.setVisibility(View.VISIBLE);
                        }
                    }.start();
                }

                @Override
                public void onFailure(HttpError error) {
                    if (error != null) {
                        MessageUtils.showToastCenter(error.getMessage());
                    } else {
                        MessageUtils.showToastCenter("发送验证码失败，请重试");
                    }
                    btnGetSmsCode.setText(STRING_SMS_CODE_RETRY);
                    btnGetSmsCode.setEnabled(true);
                    voiceCode.setEnabled(true);
//                    voiceCodeLL.setVisibility(View.VISIBLE);
                }
            });
        } catch (JSONException e) {
            MessageUtils.showToastCenter("发送验证码失败，请重试");
            btnGetSmsCode.setText(STRING_SMS_CODE_RETRY);
            btnGetSmsCode.setEnabled(true);
            voiceCode.setEnabled(true);
//            voiceCodeLL.setVisibility(View.VISIBLE);
        }
    }

    public void handleSendVoiceCode(View view) {
        codeView.requestFocus();
        if (codeView.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        btnGetSmsCode.setEnabled(false);
        btnGetSmsCode.setText("短信验证码");
        voiceCode.setEnabled(false);
//        btnGetYuyinCode.setText("获取中");
        voiceCodeLL.setVisibility(View.GONE);
        voiceCodeTips.setVisibility(View.VISIBLE);
        voiceCodeTips.setText("获取中");
        String mobile = phoneView.getText().toString().replace(" ", "");
        try {
            JSONObject params = new JSONObject();
            params.put("mobile", mobile);
            RequestSign.getVoiceToken(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    MessageUtils.showToastCenter("验证码已发送，请注意接听");
                    voiceCodeTips.setText("60秒可重发");
                    new CountDownTimer(60000, 1000) {

                        public void onTick(long millisUntilFinished) {
                            voiceCodeTips.setText(millisUntilFinished / 1000 + "秒可重发");
                        }

                        public void onFinish() {
                            voiceCodeTips.setText(STRING_SMS_CODE_RETRY);
                            btnGetSmsCode.setEnabled(true);
                            voiceCode.setEnabled(true);
                            voiceCodeLL.setVisibility(View.VISIBLE);
                            voiceCodeTips.setVisibility(View.GONE);
                        }
                    }.start();
                }

                @Override
                public void onFailure(HttpError error) {
                    if (error != null) {
                        MessageUtils.showToastCenter(error.getMessage());
                    } else {
                        MessageUtils.showToastCenter("发送验证码失败，请重试");
                    }
                    btnGetSmsCode.setEnabled(true);
                    voiceCode.setEnabled(true);
                    voiceCodeLL.setVisibility(View.VISIBLE);
                    voiceCodeTips.setVisibility(View.GONE);
                }
            });
        } catch (JSONException e) {
            MessageUtils.showToastCenter("发送验证码失败，请重试");
            btnGetSmsCode.setEnabled(true);
            voiceCode.setEnabled(true);
            voiceCodeLL.setVisibility(View.VISIBLE);
            voiceCodeTips.setVisibility(View.GONE);
        }
    }

    public void handleBind(View view) {
        final String phoneNum = phoneView.getText().toString().trim();
        final String shortPhoneNum = phoneNum.replace(" ", "");
        if (shortPhoneNum.length() == 0) {
            MessageUtils.showToastCenter("未填写手机号码哦");
            return;
        } else if (shortPhoneNum.length() != MOBILE_PHONE_LENGTH) {
            MessageUtils.showToastCenter("请填写正确的手机号码哦");
            return;
        }

        String code = codeView.getText().toString();
        if (code.length() == 0) {
            MessageUtils.showToastCenter("未填写验证码哦");
            return;
        } else if (code.length() != SMS_CODE_LENGTH) {
            MessageUtils.showToastCenter("验证码有误");
            return;
        }

        showProgressDialog("正在绑定", false);
        btnBind.setEnabled(false);

        JSONObject params = new JSONObject();
        try {
            params.put("workMobile", shortPhoneNum);
            params.put("workMobileCode", code);
        } catch (JSONException e) {

        }
        RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                hideProgressDialog();
                MessageUtils.showToastCenter("绑定成功");
                currentWorkCellphone.setText(shortPhoneNum);
                Bundle bundle = new Bundle();
                bundle.putString("workCellphone", shortPhoneNum);
                Intent intent = new Intent().putExtras(bundle);
                setResult(RESULT_OK, intent);
                finish();
            }

            @Override
            public void onFailure(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "绑定失败，请稍后再试");
                btnBind.setEnabled(true);
            }
        });
    }

    private void initPhoneListener() {
        voiceCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSendVoiceCode(v);
            }
        });
        phoneView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String contents = Helper.formatMobileNumber(s.toString().trim());
                if (contents.length() != s.toString().length()) {
                    phoneView.setText(contents);
                    phoneView.setSelection(contents.length());
                }

                if (contents.replace(" ", "").length() == MOBILE_PHONE_LENGTH) {
                    btnGetSmsCode.setEnabled(true);
                    voiceCode.setEnabled(true);
                } else {
                    btnGetSmsCode.setEnabled(false);
                    voiceCode.setEnabled(false);
                }
            }
        });
    }


}
