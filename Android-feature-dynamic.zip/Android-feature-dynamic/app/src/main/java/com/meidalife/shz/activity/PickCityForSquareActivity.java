package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CityDO;

import java.util.ArrayList;
import java.util.HashMap;

public class PickCityForSquareActivity extends BaseActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_city_square);
        initActionBar(R.string.title_activity_pick_city, true);

        ListView cityListView = (ListView) findViewById(R.id.cityList);

        SquareCityAdapter cityAdapter = new SquareCityAdapter(this, (ArrayList) getIntent().getSerializableExtra("cityList"));
        cityListView.setAdapter(cityAdapter);
        cityAdapter.setOnClickCellListener(new SquareCityAdapter.OnClickListener() {
            public void onClick(View v, CityDO item) {
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putSerializable("cityDO", item);
                intent.putExtras(bundle);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }

    public static class SquareCityAdapter extends BaseAdapter {

        private OnClickListener mOnClickCellListener;
        private LayoutInflater mInflater;
        private Context mContext;
        private ArrayList<?> mData;

        class HeaderViewHolder {
            public TextView textView;
        }

        public SquareCityAdapter(Context context, ArrayList<?> data) {
            mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            mData = data;
            mContext = context;
        }

        public void setOnClickCellListener(OnClickListener listener) {
            mOnClickCellListener = listener;
        }

        @Override
        public int getCount() {
            return mData != null ? mData.size() : 0;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public Object getItem(int position) {
            return mData.get(position);
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            CityDO item = (CityDO) mData.get(position);
            convertView = initHeaderView(convertView, parent, item, position);
            return convertView;
        }

        private View initHeaderView(View convertView, ViewGroup parent, final CityDO data, final int position) {
            convertView = genHeaderView(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            HeaderViewHolder holder = (HeaderViewHolder) tag.get("holder");
            holder.textView.setText(data.getCityName());
            holder.textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mOnClickCellListener.onClick(v, data);
                }
            });
            return convertView;
        }

        private View genHeaderView(View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = mInflater.inflate(R.layout.city_item_square, parent, false);
                HeaderViewHolder holder = new HeaderViewHolder();
                holder.textView = (TextView) convertView.findViewById(R.id.cityView);
                HashMap tag = new HashMap();
                tag.put("holder", holder);
                convertView.setTag(tag);
            }

            return convertView;
        }

        public interface OnClickListener {
            void onClick(View v, CityDO item);
        }
    }

}
