package com.meidalife.shz.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SquareCategoryItemDO;
import com.meidalife.shz.view.FontTextView;

import java.util.ArrayList;

/**
 * Created by mzzcy on 2015/12/18.
 */
public class SquareAskCategoryLvAdapter extends ArrayAdapter<SquareCategoryItemDO> {

    public SquareAskCategoryLvAdapter(Context context, int resourceId, ArrayList<SquareCategoryItemDO> dataList) {
        super(context, resourceId, dataList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view;
        //不作优化
        if (convertView == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.item_square_ask_category, parent, false);
        } else {
            view = convertView;
        }
        FontTextView textCategoryContent = (FontTextView) view.findViewById(R.id.textCategoryContent);
        textCategoryContent.setText(getItem(position).getCatName());

        return view;

    }

}
