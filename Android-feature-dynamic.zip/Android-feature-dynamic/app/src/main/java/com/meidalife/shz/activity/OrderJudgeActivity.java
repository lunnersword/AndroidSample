package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONArray;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CommentAdapter;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.CommentDO;
import com.meidalife.shz.rest.request.RequestCommentOpr;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.MyGridView;
import com.usepropeller.routable.Router;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by xiaoweilc on 15/6/20.
 * 订单评价页面
 */
public class OrderJudgeActivity extends BaseActivity {
    public static final String REPLY = "2";
    public static final String ADD = "1";

    private PublishGridAdapter adapter;
    private MyGridView selectImagesGrid;
    private ArrayList<String> selectedImgs = new ArrayList<>();
    private Map<String, String> uploadedImgs = new HashMap<>();
    private int MAX_IMAGE_LENGTH = 9;
    private boolean uploading = false;
    private boolean isCommit = false;

    private int score = 0;
    private String type;
    private String itemId;
    private String orderNo;
    private Long commentId;

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentRoot)
    ViewGroup contentRoot;
    @Bind(R.id.judgeContent)
    RelativeLayout judgeContent;
    @Bind(R.id.orderJudgeInput)
    TextView inputView;

    @Bind(R.id.avatar)
    SimpleDraweeView avatar;
    @Bind(R.id.judgeHint)
    TextView judgeHint;
    @Bind(R.id.judgeScoreLayout)
    ViewGroup judgeScoreLayout;
    @Bind(R.id.judgeHintIcon)
    ImageView judgeHintIcon;
    @Bind(R.id.judgeScoreDesc)
    TextView judgeScoreDesc;
    @Bind(R.id.judgeScoreHint)
    TextView judgeScoreHint;
    @Bind(R.id.judgeScore)
    TextView judgeScore;
    @Bind(R.id.buyerCommentsLayout)
    LinearLayout buyerCommentsLayout;
    @Bind(R.id.buyerCommentList)
    ListView buyerCommentList;
    @Bind(R.id.judgeForBuyerHint)
    TextView judgeForBuyerHint;
    @Bind(R.id.textLengthLimits)
    TextView textLengthLimits;
    @Bind(R.id.orderJudgePicGroup)
    ViewGroup orderJudgePicGroup;

    @Bind(R.id.cellStatusDotLoading)
    ViewGroup loadingLayout;
    @Bind(R.id.cellStatusErrorNetwork)
    ViewGroup networkErrLayout;
    @Bind(R.id.cellStatusErrorServer)
    ViewGroup serverErrLayout;

    private CommentAdapter buyerComentsAdapter;
    private List<CommentDO> commentList = new LinkedList<>();

    private List<TextView> starList = new ArrayList<>();
    private int maxLength;

    private String canModify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_judge);

        ButterKnife.bind(this);
        Bundle extras = getIntent().getExtras();
        type = extras.getString("type");

        // 买家评论
        if (ADD.equals(type)) {
            initActionBar(R.string.title_order_judge, true);
            itemId = extras.getString("itemId");
            orderNo = extras.getString("orderNo");
            canModify = extras.getString("canModify");
            selectImagesGrid = (MyGridView) findViewById(R.id.order_judge_select_imgs);
            initSelectImagesGrid();
            if ("0".equals(canModify))
                loadBuyerComments();
        }
        // 卖家回复
        else if (REPLY.equals(type)) {
            initActionBar(R.string.title_order_judge_for_reply, true);
            commentId = Long.parseLong(extras.getString("commentId"));
            orderNo = extras.getString("orderNo");
            buyerComentsAdapter = new CommentAdapter(OrderJudgeActivity.this, commentList);
            buyerCommentList.setAdapter(buyerComentsAdapter);
            inputView.setHint(R.string.judge_text_hint_for_seller);
            loadBuyerComments();
        }
        // 未知错误
        else {
            Toast.makeText(getApplicationContext(), "未知类型，请返回", Toast.LENGTH_LONG).show();
            return;
        }

        setStarFont();
        initComponents();
        setAvatar();
    }

    private void setAvatar() {
        //todo set default avatar
        String avatarUrl = Helper.sharedHelper().getStringUserInfo(Constant.USER_AVATAR);
        if (TextUtils.isEmpty(avatarUrl)) {
            String userId = Helper.sharedHelper().getStringUserInfo(Constant.USER_ID);
            String gender = Helper.sharedHelper().getStringUserInfo(Constant.USER_GENDER);
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(OrderJudgeActivity.this, userId, gender);
            avatar.setImageURI(getDefaultAvatarUri);
        } else {
            Uri avatarUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl,
                    getResources().getDimensionPixelSize(R.dimen.judge_page_avatar_size)));
            avatar.setImageURI(avatarUri);
        }
    }

    private void initComponents() {
        final Button commitBt = (Button) findViewById(R.id.order_judge_commit_bt);
        CommitBtnOnClickListener commitBtOnClickListener = new CommitBtnOnClickListener();
        commitBt.setOnClickListener(commitBtOnClickListener);
        maxLength = getResources().getInteger(R.integer.edit_text_max_length);
        rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int heightDiff = rootView.getRootView().getHeight() - rootView.getHeight();
                if (heightDiff > 500) {
                    //大小超过100时，一般为显示虚拟键盘事件
                    commitBt.setVisibility(View.GONE);
                } else {
                    //大小小于100时，为不显示虚拟键盘或虚拟键盘隐藏
                    commitBt.setVisibility(View.VISIBLE);
                }
            }
        });

        textLengthLimits.setText(String.format("%s/%s",
                inputView.getText() != null ? inputView.getText().length() : 0, maxLength));
        inputView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                textLengthLimits.setText(String.format("%s/%s", s.length(), maxLength));
            }
        });
    }

    private void setStarFont() {
        StarOnClickListener starOnClickListener = new StarOnClickListener();
        TextView star1 = (TextView) findViewById(R.id.order_judge_grade_1);
        star1.setOnClickListener(starOnClickListener);
        starList.add(star1);
        star1.setTag(1);

        TextView star2 = (TextView) findViewById(R.id.order_judge_grade_2);
        star2.setOnClickListener(starOnClickListener);
        starList.add(star2);
        star2.setTag(2);

        TextView star3 = (TextView) findViewById(R.id.order_judge_grade_3);
        star3.setOnClickListener(starOnClickListener);
        starList.add(star3);
        star3.setTag(3);


        TextView star4 = (TextView) findViewById(R.id.order_judge_grade_4);
        star4.setOnClickListener(starOnClickListener);
        starList.add(star4);
        star4.setTag(4);


        TextView star5 = (TextView) findViewById(R.id.order_judge_grade_5);
        star5.setOnClickListener(starOnClickListener);
        starList.add(star5);
        star5.setTag(5);
    }

    private void initSelectImagesGrid() {
        adapter = new PublishGridAdapter(this, selectedImgs, MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_OTHER);
        selectImagesGrid.setAdapter(adapter);
        adapter.setOnClickPlusListener(new PublishGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                if (uploading) {
                    Toast.makeText(OrderJudgeActivity.this, "图片正在上传中，请稍等", Toast.LENGTH_LONG).show();
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putBoolean("isCheckbox", true);
                bundle.putInt("maxLength", MAX_IMAGE_LENGTH - selectedImgs.size());
                Router.sharedRouter().openFormResult("pick/photo", bundle,
                        Constant.REQUEST_CODE_PICK_PHOTO, OrderJudgeActivity.this);
            }
        });
        adapter.setOnClickRemoveListener(new PublishGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                String img = selectedImgs.remove(position);
                uploadedImgs.remove(img);
                adapter.notifyDataSetChanged();
            }
        });

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constant.REQUEST_CODE_PICK_PHOTO && resultCode == RESULT_OK) {
            if (uploading) {
                Toast.makeText(OrderJudgeActivity.this, "图片正在上传中，请稍等", Toast.LENGTH_LONG).show();
                return;
            }
            Bundle bundle = data.getExtras();
            List<String> paths = bundle.getStringArrayList("images");
            for (int i = 0; i < paths.size(); i++) {
                String img = paths.get(i);
                if (selectedImgs.contains(img)) {
                    continue;
                } else {
                    selectedImgs.add(img);  // 如果图片列表中没有当前选中的照片，则添加到图片列表中
                }
            }
            adapter.notifyDataSetChanged();

            uploadImages();
        }
    }

    private void updateScore() {
        judgeHint.setVisibility(View.GONE);
        judgeHintIcon.setVisibility(View.GONE);
        if (ADD.equals(type)) {
            judgeScoreHint.setVisibility(View.VISIBLE);
        }
        judgeScoreLayout.setVisibility(View.VISIBLE);
        //DecimalFormat decimalFormat = new DecimalFormat(".0");

        judgeScore.setText(String.valueOf(score));
        String[] scoreDesc = getResources().getStringArray(R.array.judgeScoreDescription);

        if (score > 0 && score <= scoreDesc.length) {
            judgeScoreDesc.setText(scoreDesc[score - 1]);
            judgeScoreDesc.setVisibility(View.VISIBLE);
            judgeScoreDesc.setTextColor(getResources().getColor(R.color.brand_b));
        }
    }

    private void uploadImages() {

        final List<String> needUploadList = new ArrayList();
        for (int i = 0; i < selectedImgs.size(); i++) {
            String img = selectedImgs.get(i);
            if (!uploadedImgs.containsKey(img)) {
                needUploadList.add(img);  //如果图片列表中没有当前选中的照片，则添加到图片列表中
            }
        }
        if (needUploadList.size() > 0) {
            uploading = true;
            xhrUpdateImages(needUploadList, 0);
        }
    }

    private void xhrUpdateImages(final List<String> paths, final int index) {
        final String path = paths.get(index);
        RequestSign.upload(path, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                JSONObject json = (JSONObject) result;
                try {
                    uploadedImgs.put(path, json.getString("data"));
                    if (index == paths.size() - 1) {
                        hideProgressDialog();
                        if (uploadedImgs.size() < selectedImgs.size()) {
                            failTip();      // 若有错误，提示用户错误信息
                        } else if (isCommit) { // 若已点击提交，则自动提交
                            commit();
                        }
                        uploading = false;
                    } else {
                        xhrUpdateImages(paths, index + 1);
                    }
                } catch (JSONException e) {
                    Log.e(OrderJudgeActivity.class.getName(), "order judge upload pic fail, path = " + path, e);
                }
            }

            @Override
            public void onFailure(HttpError error) {
                Log.e(OrderJudgeActivity.class.getName(), "order judge upload pic fail, path = " + path + ", " + error.getMessage());
            }
        });
    }

    private void failTip() {
        MessageUtils.showToastCenter("图片上传过程中有错误，请重新选择");
        selectedImgs.clear();
        selectedImgs.addAll(uploadedImgs.keySet());
        adapter.notifyDataSetChanged();
    }

    class StarOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            TextView curr = (TextView) v;
            Integer size = (Integer) curr.getTag();
            for (int i = 0; i < starList.size(); i++) {
                TextView star = starList.get(i);
                if (i < size) {
                    star.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    star.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }
            score = size;
            judgeContent.setVisibility(View.VISIBLE);
            updateScore();
        }
    }

    class CommitBtnOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            isCommit = true;
            if (uploading) {
                showProgressDialog("图片上传中，请稍等", false);
                return;
            }
            commit();
        }
    }

    public void commit() {
        String inputStr = inputView.getText().toString();
        if (TextUtils.isEmpty(inputStr)) {
            Toast.makeText(OrderJudgeActivity.this, "请输入评价内容", Toast.LENGTH_LONG).show();
            return;
        }

        if (score <= 0) {
            Toast.makeText(OrderJudgeActivity.this, R.string.judge_score_empty,
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (ADD.equals(type)) {
            if ("0".equals(canModify)) {  //修改评论
                updateComment(inputStr);
            } else {
                RequestCommentOpr.addComment(itemId, orderNo, null, score, inputStr, uploadedImgs.values(), 1, new HttpClient.HttpCallback<CommentDO>() {
                    @Override
                    public void onSuccess(CommentDO obj) {
                        Router.sharedRouter().open("orders/" + orderNo);
                        finish();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter(error.toString());
                    }
                });
            }
        } else if (REPLY.equals(type)) {
            RequestCommentOpr.updateReply(commentId, score, inputStr, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    Router.sharedRouter().open("orders/" + orderNo);
                    finish();
                }

                @Override
                public void onFailure(HttpError error) {
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "回复评论失败，请重试");
                }
            });
        }
    }

    /**
     * 提交评论修改
     *
     * @param inputStr
     */
    private void updateComment(String inputStr) {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("commentId", commentId);
        params.put("comment", inputStr);
        if (uploadedImgs.values() != null && uploadedImgs.values().size() > 0) {
            JSONArray imgsJson = new JSONArray();
            for (String img : uploadedImgs.values()) {
                imgsJson.add(img);
            }
            params.put("images", imgsJson);
        }
        // params.put("images",uploadedImgs.values());
        params.put("level", score);
        HttpClient.get("1.0/comment/updateComment", params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                Router.sharedRouter().open("orders/" + orderNo);
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error.toString());
            }
        });
    }

    private void loadBuyerComments() {
        if (!Helper.isNetworkConnected(this)) {
            showNetworkError();
            return;
        }
        showLoading();

        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        if (!TextUtils.isEmpty(orderNo)) {
            params.put("orderNumber", orderNo);
            HttpClient.get("1.0/comment/getCommentByOrder", params, CommentDO.class, new HttpClient.HttpCallback<CommentDO>() {
                @Override
                public void onSuccess(CommentDO obj) {
                    if ("0".equals(canModify)) {
                        handlerModifyData(obj);
                    } else {
                        showJudgeContent();
                        commentList.clear();
                        commentList.add(obj);

                        if (CollectionUtil.isNotEmpty(commentList)) {
                            buyerCommentsLayout.setVisibility(View.VISIBLE);
//                            buyerComentsAdapter.set(commentList);
                            buyerComentsAdapter.notifyDataSetChanged();
                        } else {
                            buyerCommentsLayout.setVisibility(View.GONE);
                        }
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    showServerError();
                }
            });
        }
    }

    /**
     * 处理评论修改数据
     *
     * @param obj
     */
    private void handlerModifyData(CommentDO obj) {
        contentRoot.setVisibility(View.VISIBLE);
        judgeContent.setVisibility(View.VISIBLE);
        networkErrLayout.setVisibility(View.GONE);
        serverErrLayout.setVisibility(View.GONE);
        loadingLayout.setVisibility(View.GONE);
        Integer size = obj.getLevel();
        for (int i = 0; i < starList.size(); i++) {
            TextView star = starList.get(i);
            if (i < size) {
                star.setTextColor(getResources().getColor(R.color.brand_b));
            } else {
                star.setTextColor(getResources().getColor(R.color.grey_c));
            }
        }
        score = size;
        updateScore();
        inputView.setText(obj.getComment());
        commentId = obj.getCommentId();
        if (obj.getImages() != null && obj.getImages().size() > 0) {
            selectedImgs.addAll(obj.getImages());
            for (String img : selectedImgs)
                uploadedImgs.put(img, img);
            adapter.notifyDataSetChanged();
        }
    }

    private void showNetworkError() {
        contentRoot.setVisibility(View.GONE);
        networkErrLayout.setVisibility(View.VISIBLE);
        serverErrLayout.setVisibility(View.GONE);
        loadingLayout.setVisibility(View.GONE);

        networkErrLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadBuyerComments();
            }
        });
    }

    private void showServerError() {
        contentRoot.setVisibility(View.GONE);
        networkErrLayout.setVisibility(View.GONE);
        serverErrLayout.setVisibility(View.VISIBLE);
        loadingLayout.setVisibility(View.GONE);
    }

    private void showJudgeContent() {
        contentRoot.setVisibility(View.VISIBLE);
        networkErrLayout.setVisibility(View.GONE);
        serverErrLayout.setVisibility(View.GONE);
        loadingLayout.setVisibility(View.GONE);
        judgeHint.setVisibility(View.GONE);
        judgeScoreDesc.setVisibility(View.GONE);
        judgeContent.setVisibility(View.VISIBLE);
        orderJudgePicGroup.setVisibility(View.GONE);
    }

    private void showLoading() {
        contentRoot.setVisibility(View.GONE);
        networkErrLayout.setVisibility(View.GONE);
        serverErrLayout.setVisibility(View.GONE);
        loadingLayout.setVisibility(View.VISIBLE);
    }
}
