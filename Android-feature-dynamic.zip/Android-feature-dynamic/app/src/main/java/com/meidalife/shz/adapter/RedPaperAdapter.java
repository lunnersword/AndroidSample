package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.RedPaperItem;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by taber on 15/8/23.
 */
public class RedPaperAdapter extends BaseAdapter {

    private static final int TYPE_COUNT = 1;

    LayoutInflater mInflater;
    Context mContext;
    ArrayList<RedPaperItem> mData;

    static class ViewHolder {
        //图片
        @Bind(R.id.imageItem)
        ImageView imageItem;
        //红包状态图
        @Bind(R.id.couponStatusIV)
        ImageView couponStatusIV;
        //红包金额
        @Bind(R.id.couponAmount)
        TextView couponAmount;
        //元
//        @Bind(R.id.moneyType)
//        TextView moneyType;
        //红包标题
        @Bind(R.id.couponTitle)
        TextView couponTitle;
        //红包使用说明
        @Bind(R.id.couponUseRule)
        TextView couponUseRule;
        //红包状态
        @Bind(R.id.couponStatus)
        TextView couponStatus;
        //红包日期
        @Bind(R.id.couponTime)
        TextView couponTime;
        //红包整体
        @Bind(R.id.redPaperRL)
        View redPaperRL;

        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }

    public RedPaperAdapter(Context context, ArrayList<RedPaperItem> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    public void addAll(ArrayList<RedPaperItem> items) {
        mData.addAll(items);
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public RedPaperItem getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        RedPaperItem item = mData.get(position);
//        final String itemId = item.getItemId();
        convertView = genViewHolder(convertView, parent);
        ViewHolder holder = (ViewHolder) convertView.getTag();

        if (item.isSelected()) {
            holder.redPaperRL.setBackgroundResource(R.drawable.coupon_item_selected_bg);
        } else {
            holder.redPaperRL.setBackgroundResource(R.drawable.coupon_item_bg);
        }
//        holder.iconRight.setTypeface(Helper.sharedHelper().getIconFont());
//        Date date = new Date(item.getDurationText());
//        SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (item.getStatus() == 1) {
            //红包未使用
            holder.imageItem.setImageDrawable(mContext.getResources().getDrawable(R.drawable.coupon_unuse));
            holder.couponAmount.setTextColor(mContext.getResources().getColor(R.color.brand_b));
//            holder.moneyType.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            holder.couponTitle.setTextColor(mContext.getResources().getColor(R.color.grey_a));
            holder.couponStatusIV.setVisibility(View.GONE);
        } else {
            holder.imageItem.setImageDrawable(mContext.getResources().getDrawable(R.drawable.coupon_used));
            holder.couponAmount.setTextColor(mContext.getResources().getColor(R.color.grey_c));
//            holder.moneyType.setTextColor(mContext.getResources().getColor(R.color.grey_c));
            holder.couponTitle.setTextColor(mContext.getResources().getColor(R.color.grey_c));
            if (item.getStatus() == 3 || item.getStatus() == 2) {
                //status=2 or status = 3 红包已使用
                holder.couponStatusIV.setImageDrawable(mContext.getResources().getDrawable(R.drawable.coupon_status_used));
            } else if (item.getStatus() == 4) {
                //status=4 已过期
                holder.couponStatusIV.setImageDrawable(mContext.getResources().getDrawable(R.drawable.coupon_status_outtime));
            } else {
                //默认已经过期
                holder.couponStatusIV.setImageDrawable(mContext.getResources().getDrawable(R.drawable.coupon_status_outtime));
            }
            holder.couponStatusIV.setVisibility(View.VISIBLE);
        }
        holder.couponAmount.setText(item.getMoneyText());

        holder.couponTitle.setText(item.getTitle());
        holder.couponUseRule.setText(item.getLimitText());
        holder.couponStatus.setText(item.getStatusText());
        holder.couponTime.setText(item.getDurationText());

        return convertView;
    }

    private View genViewHolder(View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_coupon_list, parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            if (holder == null) {
                return genViewHolder(null, parent);
            }
        }

        return convertView;
    }
}
