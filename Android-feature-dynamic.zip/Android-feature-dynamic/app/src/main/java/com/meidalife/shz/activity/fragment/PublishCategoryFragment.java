package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ServiceCategoryAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ServiceCategoryDo;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.view.OnServicePublishListener;
import com.meidalife.shz.widget.SecondaryCategoryPopup;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 发布服务选择服务类别
 * Created by fufeng on 16/3/3.
 */
public class PublishCategoryFragment extends BaseFragment implements SecondaryCategoryPopup.OnCompleteListener {
    View rootView;
    String cateId;
    String stdCatId;

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.serviceCategory)
    GridView serviceCategory;

    private ServiceCategoryDo confirmedServiceCategory;
    private ServiceCategoryDo preSelectedCategory;
    private ServiceCategoryDo.SecondaryCategoryDo secondaryCategory;
    private List<ServiceCategoryDo> serviceCategoryList = new ArrayList<>();

    private ServiceCategoryAdapter serviceCategoryAdapter;
    private SecondaryCategoryPopup secondaryCategoryPopup;
    private OnServicePublishListener onServicePublishListener;
    private LoadUtilV2 mLoadUtil;

    public static PublishCategoryFragment newInstance(Bundle arg) {
        PublishCategoryFragment fragment = new PublishCategoryFragment();
        fragment.setArguments(arg);
        return fragment;
    }

    public void setOnServicePublishListener(OnServicePublishListener onServicePublishListener) {
        this.onServicePublishListener = onServicePublishListener;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (null == rootView) {
            rootView = inflater.inflate(R.layout.fragment_publish_category, container, false);
            ButterKnife.bind(this, rootView);
            initComponents();
            getServiceCategory();
        }
        return rootView;
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    private void initComponents() {
        mLoadUtil = new LoadUtilV2(LayoutInflater.from(getActivity()));
        serviceCategoryAdapter = new ServiceCategoryAdapter(getActivity(), serviceCategoryList);
        serviceCategory.setAdapter(serviceCategoryAdapter);
        cateId = getArguments().getString(Constant.EXTRA_TAG_CATEGORY_ID);
        stdCatId = getArguments().getString(Constant.EXTRA_TAG_STD_CATEGORY_ID);

        serviceCategoryAdapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View categoryIcon = v.findViewById(R.id.categoryIcon);
                preSelectedCategory = (ServiceCategoryDo) categoryIcon.getTag();
                showCategoryPopupWindow(preSelectedCategory);
            }
        });
    }

    private void getServiceCategory() {
        mLoadUtil.loadPre(rootLayout, serviceCategory);
        HttpClient.get("1.0/item/update/cats", null, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject categories) {
                try {
                    mLoadUtil.loadSuccess(serviceCategory);
                    if (categories.containsKey("categories")) {
                        List<ServiceCategoryDo> dataList = JSON.parseArray(categories.getJSONArray("categories").toString(),
                                ServiceCategoryDo.class);
                        renderCategories(dataList);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFail(HttpError error) {
                mLoadUtil.loadFail(error, rootLayout, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        getServiceCategory();
                    }
                });
            }
        });
    }

    private void renderCategories(List<ServiceCategoryDo> categories) {
        if (!TextUtils.isEmpty(cateId) && !TextUtils.isEmpty(stdCatId)) {
            for (ServiceCategoryDo serviceCategoryDo : categories) {
                if (cateId.equals(serviceCategoryDo.getCatId())) {
                    confirmedServiceCategory = serviceCategoryDo;
                    for (ServiceCategoryDo.SecondaryCategoryDo sDo : serviceCategoryDo.getStdCats()) {
                        if (stdCatId.equals(sDo.getCatId())) {
                            secondaryCategory = sDo;
                            break;
                        }
                    }
                    break;
                }
            }
            if (null != onServicePublishListener) {
                onServicePublishListener.onServiceCategoryUpdated(confirmedServiceCategory, secondaryCategory);
            }
        }
        serviceCategoryAdapter.setServiceCategoryList(categories);
        serviceCategoryAdapter.notifyDataSetChanged();
    }

    private void showCategoryPopupWindow(ServiceCategoryDo serviceCategoryDo) {
        if (secondaryCategoryPopup != null && secondaryCategoryPopup.isShowing()) {
            secondaryCategoryPopup.dismiss();
        }
        secondaryCategoryPopup = new SecondaryCategoryPopup(getActivity(),
                serviceCategoryDo.getCatName(), serviceCategoryDo.getStdCats(), secondaryCategory);
        secondaryCategoryPopup.setOnCompleteListener(this);
        secondaryCategoryPopup.showAtLocation(rootView, Gravity.BOTTOM, 0, 0);
    }

    @Override
    public void onSecondaryCategorySelected(ServiceCategoryDo.SecondaryCategoryDo category) {
        secondaryCategory = category;
        confirmedServiceCategory = preSelectedCategory;
        onServicePublishListener.onServiceCategorySelected(confirmedServiceCategory, category);
    }
}
