package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.Bind;
import butterknife.ButterKnife;

public class ChangePersonalIntroduce extends BaseActivity {

    private static int TEXT_LENGTH_LIMIT_INTRO = 24;

    @Bind(R.id.editIntroduce)
    EditText editIntroduce;
    @Bind(R.id.textLimit)
    TextView textLimit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_personal_introduce);
        initActionBar(R.string.title_activity_change_personal_introduce, true, true);
        ButterKnife.bind(this);
        mButtonRight.setText(R.string.confirm);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(editIntroduce.getText().toString().trim().length() > TEXT_LENGTH_LIMIT_INTRO){
                    MessageUtils.showToastCenter("个人简历不能超过24个字");
                    return;
                }
                mButtonRight.setEnabled(false);
                xhrUpdateProfile();

            }
        });

        Intent intent = getIntent();
        if (intent != null) {
            editIntroduce.setText(intent.getExtras().getString("personalIntroduce"));
            editIntroduce.setSelection(editIntroduce.length());
            textLimit.setText("" + editIntroduce.length());
        }

        editIntroduce.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textLimit.setText("" + s.toString().length());
                if (s.toString().trim().length() > TEXT_LENGTH_LIMIT_INTRO) {
                    textLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    private void xhrUpdateProfile() {



        final String intorduce = editIntroduce.getText().toString().trim();
        JSONObject params = new JSONObject();
        try{
            params.put("instruction",intorduce);
        }catch (JSONException e){
            e.printStackTrace();
            mButtonRight.setEnabled(true);
        }

        showProgressDialog("正在保存");
        RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                hideProgressDialog();
                mButtonRight.setEnabled(true);
                MessageUtils.showToastCenter("保存成功");

                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putString("personalIntroduce", intorduce);
                intent.putExtras(bundle);
                setResult(RESULT_OK, intent);
                finish();
            }

            @Override
            public void onFailure(HttpError error) {
                hideProgressDialog();
                mButtonRight.setEnabled(true);
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败，请稍后再试");
            }
        });

    }


}




