package com.meidalife.shz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.InnerPaywayAdapter;
import com.meidalife.shz.adapter.OuterPaywayAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.view.MyListView;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 支付订单页
 */
public class PayActivity extends BaseActivity {

    String orderNo;
    String orderTitle;
    int oldPointSelected;
    int oldFundSelected;
    JSONObject payInfo;
    JSONObject redPackInfo;//红包对象
    private Integer sellerId;

    private String tradeNumber;

    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.cellToolBar)
    RelativeLayout cellToolBar;
    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.textOrderTitle)
    TextView textOrderTitle;
    @Bind(R.id.textOrderAmount)
    TextView textOrderAmount;
    @Bind(R.id.listViewInnerPayways)
    MyListView listViewInnerPayways;
    @Bind(R.id.listViewOuterPayways)
    MyListView listViewOuterPayways;
    @Bind(R.id.cellProtectionInfo)
    LinearLayout cellProtectionInfo;
    @Bind(R.id.textProtectionInfo)
    TextView textProtectionInfo;
    @Bind(R.id.textOrderPrice)
    TextView textOrderPrice;
    @Bind(R.id.buttonPay)
    Button buttonPay;

    //红包相关
    @Bind(R.id.couponRL)
    RelativeLayout couponRL;
    @Bind(R.id.couponAmount)
    TextView couponAmountTV;
    @Bind(R.id.couponCount)
    TextView couponCountTV;

    private String redpackIssueId = "";
    private boolean selectedNone = false;

    int orderType; //1：普通订单 2：预付订单 3:一元夺宝

    private BroadcastReceiver payResultReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int payWay = intent.getIntExtra(Pay.TAG_PAY_WAY, 0);
            if (payWay == Pay.PAY_WAY_WECHAT) {
                int resultCode = intent.getIntExtra(Pay.TAG_ERROR_CODE, Integer.MAX_VALUE);
                if (resultCode == BaseResp.ErrCode.ERR_OK) {
                    afterPaySuccess(tradeNumber);
                } else {
                    afterPayFail(tradeNumber);
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay);
        initActionBar(R.string.title_activity_pay, true);
        ButterKnife.bind(this);

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            orderNo = bundle.getString("orderNo");
            orderTitle = bundle.getString("title");
        }

        listViewOuterPayways.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                listViewOuterPayways.setItemChecked(position, true);
            }
        });

        //支付选中红包
        couponRL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("redpackIssueId", redpackIssueId);
                bundle.putString("orderNO", orderNo);
                Router.sharedRouter().openFormResult("redPaperList4Order/", bundle,
                        Constant.REQUEST_CODE_PICK_RED_PAPER, PayActivity.this);
            }
        });

        //注册监听外部支付回调
        IntentFilter filter = new IntentFilter();
        filter.addAction(Pay.ACION_PAY_RESULT);
        LocalBroadcastManager.getInstance(getApplication()).registerReceiver(payResultReceiver, filter);

    }

    //处理选择红包回调
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == Constant.REQUEST_CODE_PICK_RED_PAPER) {
            Bundle bundle = data.getExtras();
            redpackIssueId = bundle.getString("redpackIssueId");
            if (TextUtils.isEmpty(redpackIssueId)) {
                selectedNone = true;
            } else {
                selectedNone = false;
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        xhrPayInfo(1, 1);
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(getApplication()).unregisterReceiver(payResultReceiver);
        super.onDestroy();
    }

    @Override
    public void handleBack(View view) {
        MessageUtils.createDialog(PayActivity.this, "提示", "是否确定放弃支付？",
                R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        onBackPressed();
                    }
                }, R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        xhrPayInfo(1, 1);
                    }
                }).show();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
            MessageUtils.createDialog(PayActivity.this, "提示", "是否确定放弃支付？",
                    R.string.confirm, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            onBackPressed();
                        }
                    }, R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            xhrPayInfo(1, 1);
                        }
                    }).show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void sureExitPay() {
        MessageUtils.createDialog(PayActivity.this, "提示", "您是否确定放弃支付？",
                R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                }, R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        xhrPayInfo(1, 1);
                    }
                }).show();
    }

    //获取支付订单数据
    private void xhrPayInfo(int pointSelected, int fundSelected) {
        oldPointSelected = pointSelected;
        oldFundSelected = fundSelected;

        if (payInfo == null) {
            showStatusLoading(rootView);
            hideStatusErrorNetwork();
            hideStatusErrorServer();
            scrollView.setVisibility(View.GONE);
            cellToolBar.setVisibility(View.GONE);
        } else {
            showProgressDialog("正在加载", false);
        }

        try {
            JSONObject params = new JSONObject();
            params.put("orderNo", orderNo);
            params.put("title", orderTitle);
            params.put("pointSelected", pointSelected);
            params.put("fundSelected", fundSelected);
            if (selectedNone) {
                params.put("redpackIssueId", "-1");//代表用户自己放弃使用红包
            } else {
                params.put("redpackIssueId", redpackIssueId);
            }

            //start req
            startPayInfoRequest(params);
        } catch (JSONException e) {
//            failure(new Error(e.getMessage()));
            MessageUtils.showToastCenter("加载数据失败，请重试");
        }
    }

    void startPayInfoRequest(JSONObject params) {
        HttpClient.get("1.2/buyerOrder/payForm", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                if (payInfo == null) {
                    hideStatusLoading();
                    scrollView.setVisibility(View.VISIBLE);
                    cellToolBar.setVisibility(View.VISIBLE);
                } else {
                    hideProgressDialog();
                }
                parseDataAfterReq(result);
            }

            @Override
            public void onFail(HttpError error) {
                failure(error);
            }
        });
    }

    void parseDataAfterReq(JSONObject data) {
        try {
            this.payInfo = data;

            textOrderPrice.setText(payInfo.getIntValue("remain") / 100.0 + "元");
            sellerId = payInfo.getIntValue("sellerId");

            if (payInfo.containsKey("title")) {
                textOrderTitle.setText("订单名称：" + payInfo.getString("title"));
            }
            if (payInfo.containsKey("amount")) {
                textOrderAmount.setText("订单金额：" + payInfo.getString("amount"));
            }
            if (payInfo.containsKey("gurantees")) {
                cellProtectionInfo.setVisibility(View.VISIBLE);
                textProtectionInfo.setText(payInfo.getJSONArray("gurantees").getString(0));
            } else {
                cellProtectionInfo.setVisibility(View.GONE);
            }

            // M豆余额
            if (payInfo.containsKey("innerPayways")) {
                final JSONArray innerList = payInfo.getJSONArray("innerPayways");
                InnerPaywayAdapter innerPaywayAdapter = new InnerPaywayAdapter(PayActivity.this, innerList);
                innerPaywayAdapter.setmOnChange(new InnerPaywayAdapter.OnChange() {
                    @Override
                    public void onChange(int type, int selected) {
                        if (type == 3) {
                            xhrPayInfo(oldPointSelected, selected);
                        } else {
                            xhrPayInfo(selected, oldFundSelected);
                        }
                    }
                });
                listViewInnerPayways.setAdapter(innerPaywayAdapter);
                listViewInnerPayways.setVisibility(View.VISIBLE);
            } else {
                listViewInnerPayways.setVisibility(View.GONE);
            }

            // 三方支付
            if (payInfo.containsKey("outerPayways")) {
                JSONArray outerList = payInfo.getJSONArray("outerPayways");
                OuterPaywayAdapter outerPaywayAdapter = new OuterPaywayAdapter(PayActivity.this, outerList);
                listViewOuterPayways.setAdapter(outerPaywayAdapter);
                for (int i = 0; i < outerList.size(); i++) {
                    JSONObject payway = outerList.getJSONObject(i);
                    if (payway.getIntValue("selected") == 1) {
                        listViewOuterPayways.setItemChecked(i, true);
                    } else {
                        listViewOuterPayways.setItemChecked(i, false);
                    }
                }
                listViewOuterPayways.setVisibility(View.VISIBLE);
            } else {
                listViewOuterPayways.setVisibility(View.GONE);
            }

            //可使用红包解析
            if (payInfo.containsKey("redpackSelector")) {
                redPackInfo = payInfo.getJSONObject("redpackSelector");
                if (redPackInfo != null) {
                    couponRL.setVisibility(View.VISIBLE);
                    String redpackMoneyText = redPackInfo.getString("redpackMoneyText");
                    String availableNum = redPackInfo.getString("availableNum");
                    if (redPackInfo.containsKey("redpackId")) {
                        redpackIssueId = redPackInfo.getString("redpackId");
                    }
                    couponAmountTV.setText(redpackMoneyText);
                    couponCountTV.setText(availableNum);
                }
            }

            buttonPay.setEnabled(true);

            if (payInfo.containsKey("orderType")) {
                orderType = payInfo.getIntValue("orderType");
            }

        } catch (JSONException e) {
            failure(null);
        }
    }

    private void failure(HttpError error) {
        if (payInfo == null) {
            hideStatusLoading();
            hideProgressDialog();

            if (error != null) {
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView);
                    setOnClickErrorNetwork(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrPayInfo(oldPointSelected, oldFundSelected);
                        }
                    });
                } else {
                    showStatusErrorServer(rootView);
                    setTextErrorServer(error.getMessage());
                    setOnClickErrorServer(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrPayInfo(oldPointSelected, oldFundSelected);
                        }
                    });
                }
            } else {
                showStatusErrorServer(rootView);
                setTextErrorServer("获取数据失败，请点击重试");
                setOnClickErrorServer(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        xhrPayInfo(oldPointSelected, oldFundSelected);
                    }
                });
            }
        } else {
            MessageUtils.showToastCenter(error != null ? error.getMessage() : "加载数据失败，请重试");
        }
    }

    //支付逻辑处理
    public void handlePay(View view) {
        if (payInfo == null) {
            return;
        }
        try {

            JSONObject params = new JSONObject();
            params.put("orderNo", orderNo);
            if (!TextUtils.isEmpty(redpackIssueId)) {
                params.put("redpackIssueId", redpackIssueId);
            }

            if (payInfo.containsKey("innerPayways")) {
                JSONArray innerPayways = payInfo.getJSONArray("innerPayways");
                for (int i = 0; i < innerPayways.size(); i++) {
                    JSONObject innerPayway = innerPayways.getJSONObject(i);
                    if (innerPayway.getIntValue("type") == 3) {
                        params.put("fundNum", innerPayway.getIntValue("payNum"));
                    } else {
                        params.put("pointNum", innerPayway.getIntValue("payNum"));
                    }
                }
            }
            if (payInfo.containsKey("outerPayways")) {
                JSONArray outerPayways = payInfo.getJSONArray("outerPayways");
                int index = listViewOuterPayways.getCheckedItemPosition();

                if (outerPayways.size() > index && index >= 0) {
                    JSONObject payWay = outerPayways.getJSONObject(index);
                    params.put("otherNum", payWay.getIntValue("payNum"));
                    params.put("gwPayway", payWay.getInteger(Pay.TAG_PAY_TYPE) == null ? Pay.PAY_WAY_ALIPAY : payWay.getInteger(Pay.TAG_PAY_TYPE));
                }else {
                    for (int i = 0; i < outerPayways.size(); i++) {
                        JSONObject outerPayway = outerPayways.getJSONObject(i);

                        if (outerPayway.getIntValue("selected") == 1) {
                            params.put("otherNum", outerPayway.getIntValue("payNum"));
                            params.put("gwPayway", outerPayway.getInteger(Pay.TAG_PAY_TYPE) == null ?
                                    Pay.PAY_WAY_ALIPAY : outerPayway.getInteger(Pay.TAG_PAY_TYPE));
                        }
                    }
                }
            }
            startPayRequest(params);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void startPayRequest(JSONObject params) {
        showProgressDialog(getString(R.string.paying), false);
        buttonPay.setEnabled(false);
        HttpClient.get("1.2/buyerOrder/pay", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject data) {
                try {
                    hideProgressDialog();
                    tradeNumber = data.containsKey(Pay.TAG_PAY_TRADE_NUMBER) ? data.getString(Pay.TAG_PAY_TRADE_NUMBER) : "";

                    if (data.containsKey(Pay.TAG_NEED_PAY) && !data.getString(Pay.TAG_NEED_PAY).equals("0")) {
                        if (data.getIntValue(Pay.TAG_PAY_WAY) == Pay.PAY_WAY_ALIPAY) {
                            Pay.payWithAlipay(PayActivity.this, data.getString("signPayStr"), new Pay.PayCallback() {
                                @Override
                                public void success() {
                                    afterPaySuccess(tradeNumber);
                                }

                                @Override
                                public void failure(Error error) {
                                    afterPayFail(tradeNumber);
                                }
                            });
                        } else if (data.getIntValue(Pay.TAG_PAY_WAY) == Pay.PAY_WAY_WECHAT) {
                            Pay.payWithWechat(PayActivity.this, data.getJSONObject("wxPay"));
                        }
                    } else {
                        afterPaySuccess(tradeNumber);
                    }

                } catch (JSONException e) {
                    MessageUtils.showToastCenter(e.getMessage());
                    buttonPay.setEnabled(true);
                }
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                if (error != null) {
                    if (error.getMessage() != null && error.getMessage().contains("修改价格")) {
                        MessageUtils.createDialog(PayActivity.this, "支付失败", error.getMessage(),
                                R.string.again_affirm, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        xhrPayInfo(1, 1);
                                    }
                                },
                                R.string.contact_seller, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        if (sellerId == null)
                                            return;
                                        String action = "chat/" + sellerId;
                                        Bundle chatBundle = new Bundle();
                                        chatBundle.putString("orderNo", orderNo);
                                        Router.sharedRouter().open(action, chatBundle);
                                        if (Helper.sharedHelper().hasToken()) {
                                            Router.sharedRouter().open(action, chatBundle);
                                        } else {
                                            Bundle bundle = new Bundle();
                                            bundle.putString("action", action);
                                            bundle.putBundle("bundle", chatBundle);
                                            Router.sharedRouter().open("signin", bundle);
                                        }
                                    }
                                }).show();
                    } else
                        MessageUtils.showToastCenter(error.getMessage());
                } else
                    MessageUtils.showToastCenter(getString(R.string.pay_error));
                buttonPay.setEnabled(true);
            }
        });
    }

    private void afterPaySuccess(String tradeNo) {
//        if (orderType == 3) {
//            jumpToLotteryPayComplete();
//        } else {
//            gotoPayResult(tradeNo);
//        }
        gotoPayResult(tradeNo);
    }

    private void afterPayFail(String tradeNo) {
        gotoOrderDetail(tradeNo);
    }

//    private void jumpToLotteryList() {
//        Router.sharedRouter().open("mylottery/" + "all");
//        finish();
//    }
//
//    private void jumpToLotteryPayComplete() {
//        Router.sharedRouter().open("lotterypayresult", PayActivity.this);
//        setResult(RESULT_OK);
//        finish();
//    }

    private void gotoPayResult(String tradeNo) {
        Bundle params = new Bundle();
        if (!TextUtils.isEmpty(orderNo)) {
            params.putString("orderId", orderNo);
        } else {
            params.putString("tradeId", tradeNo);
        }

        Router.sharedRouter().open("payresult", params);
        finish();
    }

    private void gotoOrderDetail(String tradeNo) {
        Bundle params = new Bundle();
        if (!TextUtils.isEmpty(orderNo)) {
            params.putString("orderId", orderNo);
        } else {
            params.putString("tradeId", tradeNo);
        }
        params.putBoolean("fromPayActivity", true);
        Router.sharedRouter().open("orderDetailAction", params);
        finish();
    }
}
