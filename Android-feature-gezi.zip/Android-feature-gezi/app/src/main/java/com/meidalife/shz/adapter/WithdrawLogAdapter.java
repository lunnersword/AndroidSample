package com.meidalife.shz.adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.WithdrawLogDO;
import com.usepropeller.routable.Router;

import java.util.List;

/**
 * Created by shijian on 15/7/21.
 */
public class WithdrawLogAdapter extends BaseAdapter {

    private LayoutInflater inflater;
    private Context context;

    private List<WithdrawLogDO> dataList;


    public WithdrawLogAdapter(LayoutInflater inflater, Context context, List<WithdrawLogDO> dataList) {
        this.inflater = inflater;
        this.context = context;
        this.dataList = dataList;
    }

    public void setDataList(List<WithdrawLogDO> dataList) {
        this.dataList = dataList;
    }

    public void addDataList(List<WithdrawLogDO> newDataList) {
        this.dataList.addAll(newDataList);
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LogHolder h = null;
        if (convertView == null) {
            View v = inflater.inflate(R.layout.money_withdraw_log_item, null);
            h = new LogHolder();
            h.fundSum = (TextView) v.findViewById(R.id.withdraw_log_fundsum);
            h.time = (TextView) v.findViewById(R.id.withdraw_log_time);
            h.accountType = (TextView) v.findViewById(R.id.withdraw_log_account_type);
            h.account = (TextView) v.findViewById(R.id.withdraw_log_account);
            h.status = (TextView) v.findViewById(R.id.withdraw_log_status);
            h.statusTip = (TextView) v.findViewById(R.id.withdraw_log_status_tip);
            v.setTag(h);
            convertView = v;
        } else {
            h = (LogHolder) convertView.getTag();
        }

        WithdrawLogDO log = dataList.get(position);
        h.fundSum.setText(log.getFundNum());
        h.time.setText(log.getWithdrawDate());
        h.accountType.setText(log.getAccountTypeStr());
        h.account.setText(log.getAccount());
        h.status.setText(log.getStatus());
        if (log.getStatusType() == WithdrawLogDO.STATUS_COMPLETE) {
            h.status.setTextColor(context.getResources().getColor(R.color.brand_h));
        }
        if (log.getStatusType() == WithdrawLogDO.STATUS_BACK) {
            h.statusTip.setTypeface(Helper.sharedHelper().getIconFont());
            h.statusTip.setVisibility(View.VISIBLE);
            h.statusTip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle params = new Bundle();
                    params.putString("url", "http://www.shenghuozhe.net/events/withdraw_help.html");
                    Router.sharedRouter().open("web", params);
                }
            });
        }

        return convertView;
    }


    class LogHolder {
        public TextView fundSum;
        public TextView time;
        public TextView accountType;
        public TextView account;
        public TextView status;
        public TextView statusTip;
    }

}
