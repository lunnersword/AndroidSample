package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

/**
 * Created by zhq on 16/3/25
 */
public class ServiceDetailPhotoViewPageAdapter extends BasePageAdapter {
    private Context mContext;
    List<String> mData;
    private final int imgHeight;


    OnClickListener onClickListener;

    public void setOnClickListener(OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public interface OnClickListener {
        public void onClick();
    }


    public ServiceDetailPhotoViewPageAdapter(Context context, List<String> data) {
        imgHeight = context.getResources().getDimensionPixelSize(R.dimen.service_detail_photo_height);
        mContext = context;
        this.mData = data;
    }

    @Override
    public View newView(int position) {

        String imgUrl = mData.get(position);
        String imgCdn = ImgUtil.getCDNUrlWithHeight(imgUrl, imgHeight);

        SimpleDraweeView imageView = new SimpleDraweeView(mContext);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ViewPager.LayoutParams params = new ViewPager.LayoutParams();
        imageView.setLayoutParams(params);

        imageView.setImageURI(Uri.parse(imgCdn));
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickListener.onClick();
            }
        });
        return imageView;
    }

    @Override
    public int getCount() {
        return mData.size();
    }
}
