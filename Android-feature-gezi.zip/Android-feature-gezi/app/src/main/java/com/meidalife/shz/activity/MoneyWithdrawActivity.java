package com.meidalife.shz.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.WithdrawAccountDO;
import com.meidalife.shz.rest.request.RequestWithdraw;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

/**
 * Created by shijian on 15/7/20.
 *
 * @description 提现
 */
public class MoneyWithdrawActivity extends BaseActivity {

    private ViewGroup rootView;
    private View contentRoot;

    private TextView fundSum;
    private TextView payName;
    private TextView payAccount;
    private TextView withdrawTime;
    private EditText withdrawValue;

    private View withdrawTimeGroup;
    private View withdrawValueGroup;
    private Button withdrawCommit;
    private TextView tips;

    private Long accountId;
    private Double fundSumValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.money_withdraw);
        initActionBar(R.string.title_withdraw, true);

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);

        TextView payIcon = (TextView) findViewById(R.id.withdraw_pay_icon);
        payIcon.setTypeface(Helper.sharedHelper().getIconFont());
        TextView payArrow = (TextView) findViewById(R.id.withdraw_pay_arrow);
        payArrow.setTypeface(Helper.sharedHelper().getIconFont());

        fundSum = (TextView) findViewById(R.id.withdraw_fund_sum);
        payName = (TextView) findViewById(R.id.withdraw_pay_name);
        payAccount = (TextView) findViewById(R.id.withdraw_pay_account);
        withdrawTime = (TextView) findViewById(R.id.withdraw_time);
        withdrawValue = (EditText) findViewById(R.id.withdraw_value);

        withdrawTimeGroup = findViewById(R.id.withdraw_time_group);
        withdrawValueGroup = findViewById(R.id.withdraw_value_group);
        withdrawCommit = (Button) findViewById(R.id.withdraw_commit);
        tips = (TextView) findViewById(R.id.tips);

        View withdrawPay = findViewById(R.id.money_withdraw_pay);
        withdrawPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("withdraw_account/" + accountId);
            }
        });

        final View withdrawCommit = findViewById(R.id.withdraw_commit);
        withdrawCommit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strValue = withdrawValue.getText().toString();
                if (!StrUtil.isNumeric(strValue)) {
                    MessageUtils.showToastCenter("请输入数字");
                    return;
                }
                Double doubleValue = Double.parseDouble(strValue);
                doubleValue = doubleValue * 100; // 转换为分单位
                if (doubleValue > fundSumValue) {
                    MessageUtils.showToastCenter("提现金额必须小于余额");
                    return;
                }
                if (doubleValue < 1) {
                    MessageUtils.showToastCenter("请输入正确的金额");
                    return;
                }
                RequestWithdraw.withdraw(doubleValue.intValue(), accountId, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject result) {
                        Router.sharedRouter().open("withdraw_log");
                        finish();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter(error.getMessage());
                    }
                });
            }
        });

        rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int heightDiff = rootView.getRootView().getHeight() - rootView.getHeight();
                if (heightDiff > 500) {
                    //大小超过100时，一般为显示虚拟键盘事件
                    withdrawCommit.setVisibility(View.GONE);
                } else {
                    //大小小于100时，为不显示虚拟键盘或虚拟键盘隐藏
                    withdrawCommit.setVisibility(View.VISIBLE);
                }
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
        initLoadData();
    }

    public void initLoadData() {

        loadPre(rootView, contentRoot);

        RequestWithdraw.init(new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {

                try {
//                    JSONObject res = (JSONObject) result;
//                    JSONObject obj = res.getJSONObject("data");

                    if (obj.containsKey("tips")) {
                        tips.setText(obj.getString("tips"));
                        tips.setVisibility(View.VISIBLE);
                    } else {
                        tips.setVisibility(View.GONE);
                    }

                    boolean isAuthed = false;
                    if (obj.containsKey("authed")) {
                        isAuthed = obj.getBoolean("authed");
                    }
                    if (!isAuthed) {
                        String url = "http://shenghuozhe.net/events/app_zmxy.html";
                        Bundle bundle = new Bundle();
                        bundle.putString("url", url);
                        Router.sharedRouter().open("web", bundle);
                        finish();
                        return;
                    }

                    loadSuccess(contentRoot);
                    if (obj.containsKey("fundSum")) {
                        fundSumValue = obj.getDouble("fundSum");
                        fundSum.setText(StrUtil.doubleFormat(fundSumValue / 100));
                    }
                    if (obj.containsKey("account") && obj.getJSONArray("account") != null && obj.getJSONArray("account").size() > 0) {
                        String accountJsonStr = obj.getJSONArray("account").getString(0);

                        WithdrawAccountDO account = JSON.parseObject(accountJsonStr, WithdrawAccountDO.class);
//                    WithdrawAccountDO account = JsonUtil.parse(accountJson, WithdrawAccountDO.class);
                        if (StrUtil.isEmpty(account.getAccount())) {
                            withdrawTimeGroup.setVisibility(View.GONE);
                            withdrawValueGroup.setVisibility(View.GONE);
                            withdrawCommit.setVisibility(View.GONE);
                        } else {
                            withdrawTimeGroup.setVisibility(View.VISIBLE);
                            withdrawValueGroup.setVisibility(View.VISIBLE);
                            withdrawCommit.setVisibility(View.VISIBLE);
                            accountId = account.getAccountId();
                            payName.setText(account.getRealName());
                            payAccount.setText(account.getAccount());
                            withdrawTime.setText(obj.getString("authTime"));
                        }
                    }

                } catch (Exception e) {
                    Log.e(MoneyCoinDetailActivity.class.getName(), "get withdraw account fail", e);
                    loadFail(new HttpError(HttpError.ERR_CODE_SERVER_ERROR, getString(R.string.error_server_500)),
                            rootView, MoneyWithdrawActivity.this, new LoadCallback() {
                                @Override
                                public void execute() {
                                    initLoadData();
                                }
                            });
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initLoadData();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initLoadData();
                        }
                    });
                }
            }
        });
    }
}
