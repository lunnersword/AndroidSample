package com.meidalife.shz.adapter;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.common.util.UriUtil;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;

import java.util.ArrayList;

/**
 * Created by zhq on 15/11/30.
 */
public class SelectGridAdapter extends BaseAdapter {
    private static final String LOG_TAG = "SelectGridAdapter";


    private ArrayList<String> mImages;
    private int selectedPosition = 0;
    private Activity mActivity;

    private LayoutInflater mInflater;
    //
    OnClickListener listener;

    public void setListener(OnClickListener listener) {
        this.listener = listener;
    }

    static class ImageHolder {
        public SimpleDraweeView gridImage;
        public TextView selectImage;
    }

    public SelectGridAdapter(Activity c, ArrayList<String> images) {
        mActivity = c;
        mImages = images;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return mImages.size();
    }

    @Override
    public Object getItem(int position) {
        return mImages.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(final int position, View convertView, ViewGroup parent) {
        ImageHolder imageHolder;
        if (convertView == null || convertView.getTag() == null) {
            imageHolder = new ImageHolder();
            convertView = mInflater.inflate(R.layout.select_grid_item_image, parent, false);
            imageHolder.gridImage = (SimpleDraweeView) convertView.findViewById(R.id.gridImage);
            imageHolder.selectImage = (TextView) convertView.findViewById(R.id.selectImage);
            convertView.setTag(imageHolder);
        } else {
            imageHolder = (ImageHolder) convertView.getTag();
        }

        String url = mImages.get(position);
        if (!TextUtils.isEmpty(url)) {
            Uri defaultImg = new Uri.Builder()
                    .scheme(UriUtil.LOCAL_FILE_SCHEME).path(url).build();
            imageHolder.gridImage.setImageURI(defaultImg);
        } else {
            imageHolder.gridImage.setImageURI(null);
        }

        //todo 设置选中状态
        if (selectedPosition == position) {
            imageHolder.selectImage.setText(mActivity.getResources().getText(R.string.icon_checkbox_active));
            imageHolder.selectImage.setTextColor(mActivity.getResources().getColor(R.color.brand_b));
        } else {
            imageHolder.selectImage.setText(mActivity.getResources().getText(R.string.icon_checkbox_normal));
            imageHolder.selectImage.setTextColor(mActivity.getResources().getColor(R.color.white));
        }

        imageHolder.gridImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onImgClick(position);
                setSelectedPosition(position);
                notifyDataSetChanged();
            }
        });

        return convertView;
    }

    public void setSelectedPosition(int position) {
        selectedPosition = position;
    }

    public interface OnClickListener {
        public void onImgClick(int position);
    }
}
