package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CommentAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CommentDO;
import com.meidalife.shz.util.CollectionUtil;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/10/21.
 */
public class TradeAndCommentListActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener {
    private static final int PAGE_SIZE = 10;
    private boolean isLoading = false;
    private int currentPage = 0;
    private String itemId;

    @Bind(android.R.id.list)
    ListView mListView;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.emptyView)
    ViewGroup emptyView;
    @Bind(R.id.description)
    TextView description;
    @Bind(R.id.cellStatusErrorServer)
    ViewGroup cellStatusErrorServer;
    @Bind(R.id.cellStatusErrorNetwork)
    ViewGroup cellStatusErrorNetwork;

    private CommentAdapter commentAdapter;
    private List<CommentDO> commentList = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_trade_comment_list);
        setContentView(R.layout.fragment_list);
        ButterKnife.bind(this);

        initActionBar(R.string.tab_title_comment, true);

        // currentType = getIntent().getIntExtra("type", 0);
//        sellCount = getIntent().getIntExtra("sellCount", 0);
//        evaluationCount = getIntent().getIntExtra("evaluationCount", 0);

        commentAdapter = new CommentAdapter(this, LayoutInflater.from(this), commentList);
        itemId = getIntent().getStringExtra("itemId");
        commentAdapter = new CommentAdapter(this, commentList);

        mListView.setAdapter(commentAdapter);
        description.setText(R.string.comment_count_none);

        mSwipeRefreshLayout.setOnRefreshListener(this);
        mListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        loadComments();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });
        loadComments();

//        fragmentTabHost.setup(this, getSupportFragmentManager(), R.id.realtabcontent);
//
//        Bundle params = new Bundle();
//        try {
//            params.putLong("itemId", getIntent().getLongExtra("itemId", 0));
//        } catch (NumberFormatException e) {
//            e.printStackTrace();
//        }
//        fragmentTabHost.addTab(getTabSpecView(TYPE_TRADE, R.drawable.msg_type_bg_selector),
//                TradeListFragment.class, params);
//        fragmentTabHost.addTab(getTabSpecView(TYPE_COMMENT, R.drawable.msg_type_bg_right_selector),
//                CommentListFragment.class, params);
//        if (currentType == 0) {
//            setActionBarTitle(R.string.tab_title_trade);
//        } else {
//            setActionBarTitle(R.string.tab_title_comment);
//
//        }
//        fragmentTabHost.setCurrentTab(currentType);
//        fragmentTabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
//            @Override
//            public void onTabChanged(String tabId) {
//                if (String.valueOf(TYPE_TRADE).equals(tabId)) {
//                    setActionBarTitle(R.string.tab_title_trade);
//                } else {
//                    setActionBarTitle(R.string.tab_title_comment);
//                }
//            }
//        });
    }

    public void loadComments() {
        if (!Helper.isNetworkConnected(this)) {
            showNetWorkError();
            return;
        }
        isLoading = true;
        JSONObject params = new JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", PAGE_SIZE);
        params.put("offset", currentPage * PAGE_SIZE);
        params.put("typeList", "1,3");
        HttpClient.get("1.0/comment/getComment", params, CommentDO.class, new HttpClient.HttpCallback<List<CommentDO>>() {
            @Override
            public void onSuccess(List<CommentDO> dataList) {
                isLoading = false;
                mSwipeRefreshLayout.setRefreshing(false);
                commentList.addAll(dataList);

                if (CollectionUtil.isNotEmpty(commentList)) {
//                    commentAdapter.set(commentList);
                    commentAdapter.notifyDataSetChanged();
                    currentPage++;
                } else {
                    showEmptyView();
                }
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                mSwipeRefreshLayout.setRefreshing(false);
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showNetWorkError();
                } else {
                    showServerError();
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onRefresh() {
        currentPage = 0;
        commentList.clear();
        loadComments();
    }

    private void showNetWorkError() {
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.VISIBLE);
        mSwipeRefreshLayout.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
    }

    private void showServerError() {
        cellStatusErrorServer.setVisibility(View.VISIBLE);
        cellStatusErrorNetwork.setVisibility(View.GONE);
        mSwipeRefreshLayout.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
    }

    private void showEmptyView() {
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.GONE);
        mSwipeRefreshLayout.setVisibility(View.GONE);
        emptyView.setVisibility(View.VISIBLE);
    }

//    private FragmentTabHost.TabSpec getTabSpecView(int type, int bgResId) {
//        View view = LayoutInflater.from(this).inflate(R.layout.fragment_message_tab, null);
//        View tabGroup = view.findViewById(R.id.tabGroup);
//        TextView tabText = (TextView) view.findViewById(R.id.tabText);
//        if (type == TYPE_TRADE) {
//            tabText.setText(getString(R.string.tab_title_trade) + String.format(getString(R.string.tab_title_count), sellCount));
//        } else {
//            tabText.setText(getString(R.string.tab_title_comment) + String.format(getString(R.string.tab_title_count), evaluationCount));
//        }
//        tabGroup.setBackgroundResource(bgResId);
//        return fragmentTabHost.newTabSpec(String.valueOf(type)).setIndicator(view);
//    }
}
