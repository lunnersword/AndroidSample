package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by taber on 15/6/27.
 */
public class ReasonAdapter extends BaseAdapter {

    LayoutInflater mInflater;
    Context mContext;
    ArrayList<String> mData;
    String mLabel;

    static class ViewHolder {
        TextView radio;
        TextView content;
    }

    public ReasonAdapter(Context context, ArrayList<String> data, String label) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
        mLabel = label;
    }

    @Override
    public int getCount() {
        return mData.size() + 1;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public String getItem(int position) {
        return mData.get(position);
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (position == 0) {
            convertView = genLabelView(convertView, parent);
        } else {
            convertView = genReasonView(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            ViewHolder holder = (ViewHolder) tag.get("holder");
            holder.content.setText(mData.get(position - 1));
        }

        return convertView;
    }

    private View genLabelView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.cancel_order_item_label, parent, false);
            TextView label = (TextView) convertView.findViewById(R.id.reasonLabel);
            label.setText(mLabel);
            HashMap tag = new HashMap();
            tag.put("type", "label");
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((String) tag.get("type") != "label") {
                return genLabelView(null, parent);
            }
        }
        return convertView;
    }

    private View genReasonView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.cancel_order_item, parent, false);
            ViewHolder holder = new ViewHolder();
            holder.radio = (TextView) convertView.findViewById(R.id.reasonRadio);
            holder.content = (TextView) convertView.findViewById(R.id.reasonContent);
            // set iconfont
            holder.radio.setTypeface(Helper.sharedHelper().getIconFont());
            HashMap tag = new HashMap();
            tag.put("type", "reason");
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((String) tag.get("type") != "reason") {
                return genReasonView(null, parent);
            }
        }
        return convertView;
    }

}
