package com.meidalife.shz.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.QRCodeUtil;
import com.meidalife.shz.util.ShareActivity;

import java.io.File;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/12/21.
 */
public class SquareQRCodeActivity extends BaseActivity {
    private int qrCodeSize = 0;
    private String squareId;
    private String squareIconUrl;
    private String latitude;
    private String longitude;

    @Bind(R.id.squareIcon)
    SimpleDraweeView squareIcon;
    @Bind(R.id.squareName)
    TextView squareName;
    @Bind(R.id.qrCodeContent)
    ImageView qrCodeContent;

    @Bind(R.id.shareContents)
    ViewGroup shareContents;
    @Bind(R.id.background)
    SimpleDraweeView background;
    @Bind(R.id.wechatCircleShareLayout)
    ViewGroup wechatCircleShareLayout;
    @Bind(R.id.wechatShareLayout)
    ViewGroup wechatShareLayout;
    @Bind(R.id.weiboShareLayout)
    ViewGroup weiboShareLayout;
    @Bind(R.id.qqShareLayout)
    ViewGroup qqShareLayout;
    @Bind(R.id.saveImageLayout)
    ViewGroup saveImageLayout;

    ShareActivity shareUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_qrcode);
        ButterKnife.bind(this);
        initActionBar("分享格子二维码", true, false);
        initComponents();
    }

    private void initComponents() {
        shareUtils = new ShareActivity(this);
        squareId = getIntent().getStringExtra("id");
        final String name = getIntent().getStringExtra("name");
        squareName.setText(name);

        squareIconUrl = getIntent().getStringExtra("picUrl");
        String cdnUrl = ImgUtil.getCDNUrlWithHeight(squareIconUrl,
                getResources().getDimensionPixelSize(R.dimen.normal_popup_width));
        if (!TextUtils.isEmpty(cdnUrl)) {
            squareIcon.setImageURI(Uri.parse(cdnUrl));
        }
        latitude = getIntent().getStringExtra("latitude");
        longitude = getIntent().getStringExtra("longitude");

        qrCodeSize = getResources().getDimensionPixelSize(R.dimen.square_qrcode_size);
        if (!TextUtils.isEmpty(squareId)) {
            new QRCodeGenerateTask().execute("imlifer://squareindex/" + squareId);
        }
        if (!TextUtils.isEmpty(latitude) && !TextUtils.isEmpty(longitude)) {
            int width = getResources().getDisplayMetrics().widthPixels / 2;
            int height = getResources().getDisplayMetrics().heightPixels / 2;
            String url = "http://api.map.baidu.com/staticimage?width=" + width + "&height=" + height +
                    "&markers=" + longitude + "," + latitude + "&zoom=18&markerStyles=l,,0xff5e45";
            background.setImageURI(Uri.parse(url));
        }

        //此分享格子版本后加，目前待定
        wechatCircleShareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        wechatShareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        weiboShareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        qqShareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        saveImageLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SaveImageTask().execute();
            }
        });
    }

    public class QRCodeGenerateTask extends AsyncTask<String, String, Bitmap> {

        @Override
        protected Bitmap doInBackground(String... params) {
            Bitmap bitmap = null;
            try {
                String content = params[0];

                bitmap = QRCodeUtil.createQRImage(content, qrCodeSize, qrCodeSize,
                        BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (null != bitmap) {
                qrCodeContent.setImageBitmap(bitmap);
            }
        }
    }

    public class SaveImageTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            String imageDir = ImgUtil.getSavedImagePath(SquareQRCodeActivity.this);
            try {
                if (!TextUtils.isEmpty(imageDir)) {
                    String imagePath = ImgUtil.getSavedImagePath(SquareQRCodeActivity.this) + File.separator
                            + "square_qrcode_" + System.currentTimeMillis() + ".jpg";
                    Bitmap bitmap = ImgUtil.getBitmapFromView(shareContents);

                    if (bitmap != null) {
                        ImgUtil.saveBitmap(bitmap, imagePath);
                        return imagePath;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String imagePath) {
            if (!TextUtils.isEmpty(imagePath)) {
                try {
                    File file = new File(imagePath);
                    if (file.exists()) {
                        Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                        Uri uri = Uri.fromFile(file);
                        intent.setData(uri);
                        sendBroadcast(intent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                MessageUtils.showToast(String.format(getString(R.string.image_saved_in),
                        imagePath), Toast.LENGTH_LONG);
            } else {
                MessageUtils.showToast(getString(R.string.save_image_failed), Toast.LENGTH_LONG);
            }
        }
    }
}
