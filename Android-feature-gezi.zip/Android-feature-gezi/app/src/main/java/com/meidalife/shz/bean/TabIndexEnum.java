package com.meidalife.shz.bean;

/**
 * Created by zhq on 15/10/14.
 */
public enum TabIndexEnum {

    COIN_TAB_INDEX(1),
    PUBLISH_TAB_INDEX(2),
    MESSAGE_TAB_INDEX(3);

    public int value;

    private TabIndexEnum(int value) {
        this.value = value;
    }

    public static TabIndexEnum to(int value) {
        for (TabIndexEnum element : values()) {
            if (element.value == value) {
                return element;
            }
        }
        return null;
    }
}
