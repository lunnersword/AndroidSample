package com.meidalife.shz.dexposed.query;

import java.util.ArrayList;

/**
 * Created by zhq on 15/12/9.
 */
public class PatchInfo {
    /**
     * 0: 不适beba版本
     * 1:是beta版本 需要判断当前用户是否在灰度用户列表 如果在进行hotPatch
     */
    public String isBeta;

    public ArrayList<String> users;
    /**
     * Patch apk的md5签名
     */
    public String sign;

    /**
     * Patch apk的下载url
     */
    public String patchURL;

    public String getIsBeta() {
        return isBeta;
    }

    public void setIsBeta(String isBeta) {
        this.isBeta = isBeta;
    }

    public ArrayList<String> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<String> users) {
        this.users = users;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getPatchURL() {
        return patchURL;
    }

    public void setPatchURL(String patchURL) {
        this.patchURL = patchURL;
    }
}
