package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.adapter.SquareServiceCategoryAdapter;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.SquareHandlerPinEvent;
import com.meidalife.shz.event.SquareRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.MenuVO;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.widget.PopupListMenu;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 服务社-格子
 * Created by xingchen on 2015/12/14.
 */
public class SquareServiceFragment extends BaseFragment {
    private View rootView;
    private Context context;
    private int geziId = Integer.MAX_VALUE;
    private boolean hasInitData = false;
    private boolean isComplete;
    private int page = 0;
    private boolean isRefresh = false;
    private boolean isLoad = false;
    private static int GET_DATA_REFRESH = 0;  // 刷新数据
    private static int GET_DATA_LOAD_MORE = 1;  //加载更多数据
    //    private static int PUBLISH_REQUEST_CODE = 88;
//    private static int LOGIN_SUCCESS = 888;
    private boolean isJoined;
    private boolean isGezhu;

    @Bind(R.id.serviceList)
    ListView serviceListView;
    @Bind(R.id.cellStatusErrorNetwork)
    LinearLayout cellStatusErrorNetwork;
    @Bind(R.id.cellStatusErrorServer)
    LinearLayout cellStatusErrorServer;
    @Bind(R.id.cellStatusDotLoading)
    LinearLayout cellStatusDotLoading;
    @Bind(R.id.noDataLayout)
    LinearLayout noDataLayout;
    @Bind(R.id.textStatusErrorServer)
    TextView textStatusErrorServer;
    @Bind(R.id.nearByHintLayout)
    LinearLayout nearByHintLayout;
    @Bind(R.id.categoryList)
    RecyclerView categoryListView;
    @Bind(R.id.line)
    View line;
    @Bind(R.id.nearbyHintLabel)
    TextView nearbyHintLabel;
    //    @Bind(R.id.publishIcon)
//    TextView publishIcon;
//    @Bind(R.id.publishText)
//    TextView publishText;
//    @Bind(R.id.publishLayout)
//    View publishLayout;
    private View listFooter;
    private ProgressBar footerLoading;
    private Button footerReload;
    private TextView footerMessage;
    private AnimationDrawable loadingAnimation;
    // private CategoryRecyclerAdapter categoryRecyclerAdapter;
    private ArrayList<ServiceItem> serviceItemList;
    private ServicesAdapter servicesAdapter;
    private JSONArray categoryList;
    private GridView categoryGridView;
    private SquareServiceCategoryAdapter squareServiceCategoryAdapter;
    private View headView;
    private static final int MENU_ITEM_BLACK_LIST = 0;
    private static final int MENU_ITEM_CANCEL = 1;
    PopupListMenu mPopupListMenu;

    public static SquareServiceFragment newInstance(Bundle params) {
        SquareServiceFragment squareServiceFragment = new SquareServiceFragment();
        squareServiceFragment.setArguments(params);
        return squareServiceFragment;
    }

//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (resultCode == getActivity().RESULT_OK && requestCode == PUBLISH_REQUEST_CODE) {
//            //发布成功 更新格子首页动态
//            EventBus.getDefault().post(new SquarePortalRefreshEvent());
//            getData(GET_DATA_REFRESH);
//        }
//
//        if (resultCode == getActivity().RESULT_OK && requestCode == LOGIN_SUCCESS) {
//            if (getActivity() instanceof SquareHomeActivity)
//                ((SquareHomeActivity) getActivity()).onRefresh();
//        }
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        EventBus.getDefault().register(this);
        if (rootView == null) {
            Bundle params = getArguments();
            if (params != null) {
                geziId = params.getInt("geziId", Integer.MAX_VALUE);
                isJoined = params.getBoolean("isJoined", false);
                isGezhu = params.getBoolean("isGezhu", false);
            }
            rootView = inflater.inflate(R.layout.fragment_square_list, container, false);

            context = getActivity();
            ButterKnife.bind(this, rootView);

//            publishIcon.setText(R.string.icon_square_publish_service);
//            publishText.setText(R.string.title_activity_service_publish);

            categoryListView.setVisibility(View.GONE);
            line.setVisibility(View.GONE);

            headView = getLayoutInflater(savedInstanceState).inflate(R.layout.view_square_service_head, null);
            categoryGridView = (GridView) headView.findViewById(R.id.categoryGridView);
            serviceListView.addHeaderView(headView);

            listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
            footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
            footerMessage = (TextView) listFooter.findViewById(R.id.message);
            footerReload = (Button) listFooter.findViewById(R.id.footerReload);
            serviceListView.addFooterView(listFooter);

            serviceItemList = new ArrayList<ServiceItem>();
            servicesAdapter = new ServicesAdapter(context, serviceItemList);
            servicesAdapter.setIsSquare(true, isGezhu, geziId);
            serviceListView.setAdapter(servicesAdapter);

            categoryList = new JSONArray();
            /*categoryRecyclerAdapter = new CategoryRecyclerAdapter(context, categoryList);
            categoryListView.setAdapter(categoryRecyclerAdapter);*/
            squareServiceCategoryAdapter = new SquareServiceCategoryAdapter(context, categoryList);
            categoryGridView.setAdapter(squareServiceCategoryAdapter);
            //设置布局管理器
            /*LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
            categoryListView.setLayoutManager(linearLayoutManager);*/

            listFooter.setVisibility(View.GONE);
            headView.setVisibility(View.GONE);

            page = 0;
            isComplete = false;
            isLoad = false;
            showStatusLoading();

            initListener();

        }
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // if (!hasInitData)
        getData(GET_DATA_REFRESH);
        //  hasInitData = true;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null)
                parent.removeView(rootView);
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    public void onEvent(SquareRefreshEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isRefresh) {
            isJoined = event.isJoined;
            isGezhu = event.isGezhu;
            servicesAdapter.setIsGezhu(isGezhu);
            showStatusLoading();
            getData(GET_DATA_REFRESH);
        }
    }

    private void initListener() {
        cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStatusLoading();
                getData(GET_DATA_REFRESH);
            }
        });
        cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStatusLoading();
                getData(GET_DATA_REFRESH);
            }
        });
        serviceListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            private boolean moveToBottom = false;
            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                BaseEvent message = new BaseEvent();
                final View topChildView = serviceListView.getChildAt(0);
                if (scrollState == SCROLL_STATE_IDLE && serviceListView.getFirstVisiblePosition() == 0
                        && topChildView.getTop() == 0) {
                    message.eventType = MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                } else {
                    message.eventType = MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                }

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        getData(GET_DATA_LOAD_MORE);
                    }
                }
                /*if (scrollState == SCROLL_STATE_IDLE) {
                    publishLayout.setVisibility(View.VISIBLE);
                }*/
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                //EventBus.getDefault().post(AttachUtil.isAdapterViewAttach(view));
                /*if (firstVisibleItem > 0) {
                    publishLayout.setVisibility(View.GONE);
                }*/

            }
        });

//        publishLayout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                if (Helper.sharedHelper().hasToken()) {
//                    if (isJoined) {
//                        Router.sharedRouter().openFormResult("publish/", PUBLISH_REQUEST_CODE, getActivity());
//                    } else {
//                        MessageUtils.showDialog(context, context.getResources().getString(R.string.square_warn),
//                                context.getResources().getString(R.string.square_service_add_warn), new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialog, int which) {
//                                        joioCurrentGeZi();
//                                    }
//                                }, new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialog, int which) {
//                                    }
//                                });
//                    }
//                } else {
//                    MessageUtils.showDialog(context, context.getResources().getString(R.string.square_warn),
//                            context.getResources().getString(R.string.square_service_login_warn), new DialogInterface.OnClickListener() {
//                                @Override
//                                public void onClick(DialogInterface dialog, int which) {
//                                    Router.sharedRouter().openFormResult("signin", LOGIN_SUCCESS, getActivity());
//                                }
//                            }, new DialogInterface.OnClickListener() {
//                                @Override
//                                public void onClick(DialogInterface dialog, int which) {
//                                }
//                            });
//                }
//            }
//        });

        servicesAdapter.setSquareHandlerPinEvent(new SquareHandlerPinEvent() {
            @Override
            public void handlerPin(View v, int position) {
                showOrHidePopMenu(v, position);
            }
        });

    }

//    private void joioCurrentGeZi() {
//        JSONObject params = new JSONObject();
//        params.put("geziId", geziId);
//        RequestSquareAsk.joinGezi(params, new HttpClient.HttpCallback() {
//            @Override
//            public void onSuccess(Object obj) {
//                MessageUtils.showToast("你已成功加入该格子");
//                isJoined = true;
//                Router.sharedRouter().openFormResult("publish/", PUBLISH_REQUEST_CODE, getActivity());
//            }
//
//            @Override
//            public void onFail(HttpError error) {
//                MessageUtils.showToast(error != null ? error.getMessage() : "加入格子失败，请稍后再试");
//            }
//        });
//    }

    /**
     * @param loadType 0:刷新，1：加载更多
     */
    private void getData(final int loadType) {
        if (loadType == GET_DATA_REFRESH) {
            cellStatusErrorNetwork.setVisibility(View.GONE);
            cellStatusErrorServer.setVisibility(View.GONE);
            /*if(!isRefresh){
                hideStatusLoading();
                return;
            }*/
            isRefresh = true;
            page = 0;
            isComplete = false;
        }
        if (loadType == GET_DATA_LOAD_MORE) {
            if (isLoad || isComplete || !checkLocationSetting())
                return;
            footerMessage.setText("正在加载");
            listFooter.setVisibility(View.VISIBLE);
            footerLoading.setVisibility(View.VISIBLE);
            footerMessage.setVisibility(View.VISIBLE);
            footerReload.setVisibility(View.GONE);
            isLoad = true;
            page++;
        }

        HttpClient.get("1.0/gezi/item/home/list", getParams(page), null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                if (loadType == GET_DATA_REFRESH) {
                    isRefresh = false;
                    serviceListView.setVisibility(View.VISIBLE);
                    hideStatusLoading();
                } else {
                    isLoad = false;
                }

                try {
                    List<ServiceItem> newData = JSON.parseArray("itemList", ServiceItem.class);

                    if (newData.size() == 0) {
                        if (loadType == GET_DATA_REFRESH) {
                            serviceItemList.clear();
                            noDataLayout.setVisibility(View.VISIBLE);
                        }
                    } else {
                        if (loadType == GET_DATA_REFRESH) {
                            serviceItemList.clear();
                            noDataLayout.setVisibility(View.GONE);
                        } else
                            listFooter.setVisibility(View.GONE);
                        serviceItemList.addAll(newData);
                        servicesAdapter.notifyDataSetChanged();
                    }

                    if (result.containsKey("gezi")) {
                        JSONObject gezi = result.getJSONObject("gezi");
                        if (gezi.containsKey("categoryList") && gezi.getJSONArray("categoryList").size() > 0) {
                            categoryList.clear();
                            categoryList.addAll(gezi.getJSONArray("categoryList"));
                        }

                        if (categoryList == null || categoryList.size() == 0) {
                            headView.setVisibility(View.GONE);
                        } else {
                            headView.setVisibility(View.VISIBLE);
                            //  squareServiceCategoryAdapter.setCategoryList(categoryList);
                            squareServiceCategoryAdapter.notifyDataSetChanged();
                        }
                    }

                    if (newData.size() < 20) {
                        isComplete = true;
                        serviceListView.removeFooterView(listFooter);
                    }
                } catch (Exception e) {
                    headView.setVisibility(View.GONE);
                    listFooter.setVisibility(View.GONE);
                    cellStatusErrorServer.setVisibility(View.VISIBLE);
                    e.printStackTrace();
                }

            }

            @Override
            public void onFail(HttpError error) {
                if (loadType == GET_DATA_REFRESH) {
                    isRefresh = false;
                    hideStatusLoading();
                    if (serviceItemList.size() > 0)
                        serviceItemList.clear();
                    servicesAdapter.notifyDataSetChanged();
                    headView.setVisibility(View.GONE);
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        cellStatusErrorNetwork.setVisibility(View.VISIBLE);
                        return;
                    }
                    if (!TextUtils.isEmpty(error.getMessage())) {
                        textStatusErrorServer.setText(error.getMessage());
                    }
                    cellStatusErrorServer.setVisibility(View.VISIBLE);
                } else {
                    page--;
                    isLoad = false;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);

                    listFooter.setVisibility(View.VISIBLE);
                    footerReload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getData(loadType);
                        }
                    });
                }
            }
        });

    }

    private JSONObject getParams(int page) {
        JSONObject params = new JSONObject();
        try {
            if (geziId != Integer.MAX_VALUE)
                params.put("geziId", geziId);
            LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();
            params.put("longitude", String.valueOf(location.getLongitude()));
            params.put("latitude", String.valueOf(location.getLatitude()));
            String locateCode = location.getCityCode();
            String selectCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
            params.put("cityCode", StrUtil.isEmpty(selectCode) ? locateCode : selectCode);  // 优先用户选择，其次自动定位
            params.put("pageSize", 20);
            params.put("offset", page * 20);
        } catch (com.alibaba.fastjson.JSONException e) {
            params = null;
        }
        return params;
    }

    private void showOrHidePopMenu(View v, final int pos) {
        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(getActivity(), 0);
        }

        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_BLACK_LIST: {
                        handlerPin(pos);
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_CANCEL: {
                        mPopupListMenu.dismiss();
                        break;
                    }
                }
            }
        });

        List<MenuVO> menuList = new ArrayList<>();
        boolean pin = serviceItemList.get(pos).getPin();

        menuList.add(MENU_ITEM_BLACK_LIST, new MenuVO(getString(pin ? R.string.square_cancel_pin : R.string.square_pin)));

        menuList.add(MENU_ITEM_CANCEL, new MenuVO(getString(R.string.cancel)));

        mPopupListMenu.setMenuData(menuList);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private void handlerPin(final int position) {
        if (!isGezhu) {
            MessageUtils.showToastCenter("非格主不能操作");
            return;
        }
        String itemId = serviceItemList.get(position).getItemId();
        final boolean pin = serviceItemList.get(position).getPin();
        String path = pin ? "1.0/gezi/pin/del" : "1.0/gezi/pin/add";
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("bizType", Constant.SQUARE_LIST_PIN_TYPE_SERVICE);
        params.put("geziId", geziId);
        params.put("bizId", itemId);
        HttpClient.get(path, params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                /*ServiceItem item = serviceItemList.get(position);
                ServiceItem firstItem = serviceItemList.get(0);
                item.setPin(!pin);
                serviceItemList.set(0, item);
                serviceItemList.set(position,firstItem);
                servicesAdapter.notifyDataSetChanged();*/
                getData(GET_DATA_REFRESH);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "操作失败");
            }
        });
    }

    private boolean checkLocationSetting() {
        String locateCode = SHZApplication.getInstance().getLocationManager().getLocation().getCityCode();
        String selectCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
        if (Helper.isLocationEnabled(getActivity())) {
            if (!TextUtils.isEmpty(locateCode) && (locateCode.equals(selectCode) || TextUtils.isEmpty(selectCode))) {
                nearByHintLayout.setVisibility(View.GONE);
                return true;
            } else {
                nearByHintLayout.setVisibility(View.VISIBLE);
                nearbyHintLabel.setText("选择城市和定位所在城市不一致，无法显示哦");
                return false;
            }
        } else {
            nearByHintLayout.setVisibility(View.VISIBLE);
            nearbyHintLabel.setText("未开启定位，点击设置");
            nearByHintLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Helper.isLocationEnabled(getActivity())) {
                        getData(GET_DATA_REFRESH);
                    } else {
                        Helper.openLocationSetting(getActivity());
                    }
                }
            });
            return false;
        }
    }

    private void showStatusLoading() {
        serviceListView.setVisibility(View.GONE);
        try {
            cellStatusDotLoading.setVisibility(View.VISIBLE);
//            loadingAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.loading_animation);
//            ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
//            loadingImage.setBackgroundDrawable(loadingAnimation);
//            loadingAnimation.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideStatusLoading() {
        try {
            if (cellStatusDotLoading != null) {
                cellStatusDotLoading.setVisibility(View.GONE);
//                if (loadingAnimation != null) {
//                    loadingAnimation.stop();
//                    loadingAnimation = null;
//                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
