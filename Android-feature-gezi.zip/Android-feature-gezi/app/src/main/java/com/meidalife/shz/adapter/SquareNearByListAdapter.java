package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.event.SquareHandlerPinEvent;

import java.text.DecimalFormat;
import java.util.HashMap;

/**
 * Created by xingchen on 2015/12/16.
 */
public class SquareNearByListAdapter extends BaseAdapter {
    public static int HOLDER_TYPE_PHONE = 1;
    public static int HOLDER_TYPE_SERVICE = 2;
    private LayoutInflater mInflater;
    private JSONArray mobileList;
    private JSONArray ypList;
    private View.OnClickListener onClickListener;
    private DecimalFormat df;
    private boolean isGezhu = false;

    public SquareNearByListAdapter(Context context, JSONArray mobileList, JSONArray ypList) {
        df = new java.text.DecimalFormat("#.##");
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.mobileList = mobileList;
        this.ypList = ypList;
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public void setMobileList(JSONArray mobileList) {
        this.mobileList = mobileList;
    }

    public JSONArray getMobileList(){
        return mobileList;
    }

    public void setYpList(JSONArray ypList) {
        this.ypList = ypList;
    }

    public void addMobileList(JSONArray mobileList) {
        this.mobileList.addAll(mobileList);
    }

    public void addYpList(JSONArray ypList) {
        this.mobileList.addAll(ypList);
    }

    public JSONArray getYpList(){
        return ypList;
    }

    public void setGezhu(boolean isGezhu){
        this.isGezhu = isGezhu;
    }

    @Override
    public int getCount() {
        return mobileList.size() + ypList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (position < mobileList.size()) {
            convertView = getPhoneView(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            PhoneHolder holder = (PhoneHolder) tag.get("holder");
            JSONObject mobile = (JSONObject) mobileList.get(position);
            holder.phone.setText(mobile.getString("name") + "：" + mobile.getString("mobile"));
            if(onClickListener != null){
                holder.callPhone.setTag(mobile.getString("mobile"));
                holder.callPhone.setOnClickListener(onClickListener);
                HashMap pos = new HashMap();
                pos.put("type",HOLDER_TYPE_PHONE);
                pos.put("pos",position);
                holder.pinHandlerView.setTag(pos);
                holder.pinHandlerView.setOnClickListener(onClickListener);
            }
//            if(isGezhu){
//                holder.pinHandlerView.setVisibility(View.VISIBLE);
//            }else
                holder.pinHandlerView.setVisibility(View.GONE);
        } else {
            convertView = getServiceView(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            ServiceHolder holder = (ServiceHolder) tag.get("holder");
            JSONObject service = (JSONObject) ypList.get(position - mobileList.size());
            holder.distance.setText("距离本格子"+ df.format(service.getDoubleValue("distance"))+ "公里");
            holder.title.setText(service.getString("title"));
            holder.desc.setText(service.getString("desc"));
            holder.openHour.setText("营业时间：" + service.getString("openHour"));
            JSONArray pics = service.getJSONArray("pics");
            if (pics != null && pics.size() > 0)
                holder.pic.setImageURI(Uri.parse((String) pics.get(0)));
            if (onClickListener != null) {
                HashMap pos = new HashMap();
                pos.put(Constant.GPS_LONG, service.getDoubleValue("poiLongitude"));
                pos.put(Constant.GPS_LAT, service.getDoubleValue("poiLatitude"));
                holder.addressIcon.setTag(pos);
                holder.addressIcon.setOnClickListener(onClickListener);
                if(service.containsKey("phone")){
                    holder.phoneIcon.setTag(service.getString("phone"));
                    holder.phoneIcon.setOnClickListener(onClickListener);
                }
                HashMap posHash = new HashMap();
                posHash.put("type",HOLDER_TYPE_SERVICE);
                posHash.put("pos", position - mobileList.size());
                holder.pinHandlerView.setTag(posHash);
                holder.pinHandlerView.setOnClickListener(onClickListener);
            }
            if(isGezhu){
                holder.pinHandlerView.setVisibility(View.VISIBLE);
            }else
                holder.pinHandlerView.setVisibility(View.GONE);
        }
        return convertView;
    }

    private View getPhoneView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_life_collect_phone, parent, false);
            PhoneHolder phoneHolder = new PhoneHolder();
            phoneHolder.phone = (TextView) convertView.findViewById(R.id.phone);
            phoneHolder.callPhone = convertView.findViewById(R.id.callPhone);
            phoneHolder.pinHandlerView = convertView.findViewById(R.id.pinHandlerView);
            HashMap tag = new HashMap();
            tag.put("type", HOLDER_TYPE_PHONE);
            tag.put("holder", phoneHolder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != HOLDER_TYPE_PHONE) {
                return getPhoneView(null, parent);
            }
        }
        return convertView;
    }

    private View getServiceView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_life_collect_service, parent, false);
            ServiceHolder serviceHolder = new ServiceHolder();

            serviceHolder.distance = (TextView) convertView.findViewById(R.id.distance);
            serviceHolder.addressIcon = (LinearLayout) convertView.findViewById(R.id.addressIcon);
            serviceHolder.phoneIcon = (LinearLayout) convertView.findViewById(R.id.phoneIcon);
            serviceHolder.pic = (SimpleDraweeView) convertView.findViewById(R.id.pic);
            serviceHolder.title = (TextView) convertView.findViewById(R.id.title);
            serviceHolder.desc = (TextView) convertView.findViewById(R.id.desc);
            serviceHolder.openHour = (TextView) convertView.findViewById(R.id.openHour);
            serviceHolder.pinHandlerView = convertView.findViewById(R.id.pinHandlerView);
            HashMap tag = new HashMap();
            tag.put("type", HOLDER_TYPE_SERVICE);
            tag.put("holder", serviceHolder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != HOLDER_TYPE_SERVICE) {
                return getServiceView(null, parent);
            }
        }
        return convertView;
    }

    static class PhoneHolder {
        TextView phone;
        View callPhone;
        View pinHandlerView;
    }

    static class ServiceHolder {
        TextView distance;
        LinearLayout addressIcon;
        LinearLayout phoneIcon;
        SimpleDraweeView pic;
        TextView title;
        TextView desc;
        TextView openHour;
        View pinHandlerView;
    }
}
