package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SquareAskServiceItemDo;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;

import java.util.ArrayList;

/**
 * Created by 一杨 on 2015/12/23.
 * Email: yiyang@meidalife.com
 */
public class SquareAskChooseServiceAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private ArrayList<SquareAskServiceItemDo> mServiceItemArrayList;
    public int selectItemId = -1;

    static class ViewHolder {
        private View view;
        View rootView;
        SimpleDraweeView imageService;
        SimpleDraweeView userAvatar;
        IconTextView iconGender;
        FontTextView textNick;
        FontTextView serviceName;

        public ViewHolder(View view) {
            this.view = view;
            rootView = this.view.findViewById(R.id.rootView);
            imageService = (SimpleDraweeView) this.view.findViewById(R.id.imageService);
            userAvatar = (SimpleDraweeView) this.view.findViewById(R.id.imageAvatar);
            iconGender = (IconTextView) this.view.findViewById(R.id.iconGender);
            textNick = (FontTextView) this.view.findViewById(R.id.textNick);
            serviceName = (FontTextView) this.view.findViewById(R.id.serviceName);
        }
    }

    public SquareAskChooseServiceAdapter(Context context, ArrayList<SquareAskServiceItemDo> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mServiceItemArrayList = data;
        mContext = context;
    }

    @Override
    public int getCount() {
        return mServiceItemArrayList.size();
    }

    @Override
    public SquareAskServiceItemDo getItem(int position) {
        return mServiceItemArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View converView, ViewGroup parent) {

        SquareAskServiceItemDo squareAskServiceItemDo = getItem(position);
        ViewHolder viewHolder;
        View view;
        if (converView == null) {
            Log.d("mzLog", "ChooseServiceAdapter position: " + position);
            view = mInflater.inflate(R.layout.item_square_ask_choose_service, parent, false);
            viewHolder = new ViewHolder(view);
            view.setTag(viewHolder);
        } else {
            view = converView;
            viewHolder = (ViewHolder) view.getTag();
        }

        if (selectItemId != -1 && selectItemId == position) {
            viewHolder.rootView.setBackgroundColor(mContext.getResources().getColor(R.color.brand));
        } else {
            viewHolder.rootView.setBackgroundColor(mContext.getResources().getColor(R.color.white));
        }
        viewHolder.imageService.setImageURI(Uri.parse(squareAskServiceItemDo.getImages().get(0)));

        String gender = squareAskServiceItemDo.getUserGender();
        // 设置服务者性别
        if (gender != null) {
            viewHolder.iconGender.setVisibility(View.VISIBLE);
            if (gender.equals("woman") || gender.equals("F")) {
                viewHolder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_f));
                viewHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            } else {
                viewHolder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_m));
                viewHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
            }
        } else {
            viewHolder.iconGender.setVisibility(View.GONE);
        }

        // 加载发布者头像
        ViewGroup.LayoutParams avatarParams = viewHolder.userAvatar.getLayoutParams();
        String userPicUrl = squareAskServiceItemDo.getUserAvatar();
        if (TextUtils.isEmpty(userPicUrl) || userPicUrl.equals("null")) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(squareAskServiceItemDo.getUserId()), gender);
            viewHolder.userAvatar.setImageURI(getDefaultAvatarUri);

        } else {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(userPicUrl, avatarParams.width));
            viewHolder.userAvatar.setImageURI(uri);
        }
        viewHolder.textNick.setText(squareAskServiceItemDo.getUserName());
        viewHolder.serviceName.setText("我能·" + squareAskServiceItemDo.getItemTitle());

        return view;
    }

}
