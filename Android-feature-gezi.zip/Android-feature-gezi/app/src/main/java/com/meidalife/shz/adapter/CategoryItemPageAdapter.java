package com.meidalife.shz.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.WebActivity;
import com.meidalife.shz.rest.model.CategoryDO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 15/11/9.
 */
public class CategoryItemPageAdapter extends BasePageAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private List<CategoryDO> categoryList = new ArrayList<>();
    private final int PAGE_SIZE = 10;

    public CategoryItemPageAdapter(Context context) {
        mContext = context;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void setCategoryList(List<CategoryDO> data) {
        categoryList = data;
    }

    @Override
    public int getCount() {
        int offset = categoryList.size() % PAGE_SIZE;
        return (offset > 0 ? categoryList.size() / PAGE_SIZE + 1 : categoryList.size() / PAGE_SIZE);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public View newView(int position) {
        View view = mInflater.inflate(R.layout.item_category_page, null);
        GridView categoryGridView = (GridView) view.findViewById(R.id.categoryGridView);
        CategoryIconAdapter categoryIconAdapter = new CategoryIconAdapter(mContext);
        int start = position * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, categoryList.size());

        final List<CategoryDO> onePageCategoryList = categoryList.subList(start, end);
        categoryIconAdapter.setCategories(onePageCategoryList);
        categoryGridView.setAdapter(categoryIconAdapter);
        categoryGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                try {
                    CategoryDO categoryDO = onePageCategoryList.get(position);
                    if (!TextUtils.isEmpty(categoryDO.getLink())) {
                        Intent intent = new Intent();
                        intent.setClass(mContext, WebActivity.class);
                        intent.putExtra("url", categoryDO.getLink());
                        mContext.startActivity(intent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    MessageUtils.showToast("类目稍后上线");
                }
            }
        });
        return view;
    }
}
