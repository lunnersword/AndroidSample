package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SearchTopListPromotionDO;
import com.meidalife.shz.rest.model.SearchTopListUserDO;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.view.FontEditText;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 16/1/31.
 */
public class SearchTopListViewAdapter extends BaseAdapter {
    private List<SquareDO> squareDOList = new ArrayList<>();
    private SearchTopListUserDO searchTopListUserDO;
    private SearchTopListPromotionDO searchTopListPromotionDO;

    private LayoutInflater mInflater;
    private Object mDataObject;
    private int mDataType = -1;
    private Context mContext;

    public SearchTopListViewAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        mContext = context;
    }

    public void setData(Object dataObject, int dataType) {
        this.mDataObject = dataObject;
        mDataType = dataType;
        switch (mDataType) {
            case Constant.SEARCH_TOP_LIST_TYPE_GEZI:
                squareDOList = (List<SquareDO>) mDataObject;
                break;

            case Constant.SEARCH_TOP_LIST_TYPE_USER:
                searchTopListUserDO = (SearchTopListUserDO) mDataObject;
                break;

            case Constant.SEARCH_TOP_LIST_TYPE_PROMOTION:
                searchTopListPromotionDO = (SearchTopListPromotionDO) mDataObject;
                break;
        }

    }

    @Override
    public int getCount() {
        if (mDataType == Constant.SEARCH_TOP_LIST_TYPE_GEZI) {
            return squareDOList.size();
        } else if (mDataType == Constant.SEARCH_TOP_LIST_TYPE_PROMOTION
                || mDataType == Constant.SEARCH_TOP_LIST_TYPE_USER) {
            return 1;
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View contentView = null;

        switch (mDataType) {

            case Constant.SEARCH_TOP_LIST_TYPE_GEZI:

                contentView = mInflater.inflate(R.layout.item_search_result_square, parent, false);
                SimpleDraweeView icon = (SimpleDraweeView) contentView.findViewById(R.id.squareIcon);
                TextView name = (TextView) contentView.findViewById(R.id.squareName);
                TextView serviceCount = (TextView) contentView.findViewById(R.id.serviceCount);
                TextView distance = (TextView) contentView.findViewById(R.id.distance);
                TextView squareType = (TextView) contentView.findViewById(R.id.squareType);
                ImageView joinStatus = (ImageView) contentView.findViewById(R.id.joinStatus);

                final SquareDO squareDO = squareDOList.get(position);

                name.setText(squareDO.getGeziName());
                if (!TextUtils.isEmpty(squareDO.getGeziPicUrl())) {
                    icon.setImageURI(Uri.parse(squareDO.getGeziPicUrl()));
                }
                if (!TextUtils.isEmpty(squareDO.getGeziTypeDesc())) {
                    squareType.setVisibility(View.VISIBLE);
                    squareType.setText(String.format("[%s]", squareDO.getGeziTypeDesc()));
                } else {
                    squareType.setVisibility(View.GONE);
                }
                serviceCount.setText("服务数：" + squareDO.getItemCount());
                distance.setText("距离：" + StrUtil.getDistanceString(squareDO.getGeziDistance()));
                joinStatus.setVisibility(squareDO.isJoined() ? View.VISIBLE : View.GONE);
                contentView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Router.sharedRouter().open("squareindex/" + squareDO.getGeziId());
                    }
                });

                break;

            case Constant.SEARCH_TOP_LIST_TYPE_USER:
                contentView = mInflater.inflate(R.layout.item_search_result_service_user, parent, false);
                SimpleDraweeView imageAvatar = (SimpleDraweeView) contentView.findViewById(R.id.imageAvatar);
                FontTextView textNick = (FontTextView) contentView.findViewById(R.id.textNick);
                IconTextView iconGender = (IconTextView) contentView.findViewById(R.id.iconGender);

                View activityCountContainer = contentView.findViewById(R.id.activityCountContainer);
                FontTextView activityCountText = (FontTextView) contentView.findViewById(R.id.activityCountText);

                View serviceCountContainer = contentView.findViewById(R.id.serviceCountContainer);
                FontTextView serviceCountText = (FontTextView) contentView.findViewById(R.id.serviceCountText);

                View fansCountContainer = contentView.findViewById(R.id.fansCountContainer);
                FontTextView fansCountText = (FontTextView) contentView.findViewById(R.id.fansCountText);

                View rootView = contentView.findViewById(R.id.rootView);

                FontTextView personIntroduce = (FontTextView) contentView.findViewById(R.id.personIntroduce);


                String gender = searchTopListUserDO.getUserGender();

                textNick.setText(searchTopListUserDO.getUserNick());
                // 设置服务者性别
                if (gender != null) {
                    iconGender.setVisibility(View.VISIBLE);
                    if (gender.equals("woman") || gender.equals("F")) {
                        iconGender.setText(mContext.getResources().getString(R.string.icon_gender_f));
                        iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                    } else {
                        iconGender.setText(mContext.getResources().getString(R.string.icon_gender_m));
                        iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
                    }
                } else {
                    iconGender.setVisibility(View.GONE);
                }

                // 加载发布者头像
                ViewGroup.LayoutParams avatarParams = imageAvatar.getLayoutParams();
                if (TextUtils.isEmpty(searchTopListUserDO.getAvaterURL())) {
                    Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(searchTopListUserDO.getUserId()), gender);
                    imageAvatar.setImageURI(getDefaultAvatarUri);
                } else {
                    Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(searchTopListUserDO.getAvaterURL(), avatarParams.width));
                    imageAvatar.setImageURI(uri);
                }


                Integer activityCount = searchTopListUserDO.getActivityCount();
                if (activityCount != null) {
                    activityCountContainer.setVisibility(View.VISIBLE);
                    activityCountText.setText(activityCount.toString());
                } else {
                    activityCountContainer.setVisibility(View.INVISIBLE);
                }

                if (searchTopListUserDO.getServiceCount() != null) {
                    serviceCountContainer.setVisibility(View.VISIBLE);
                    serviceCountText.setText(searchTopListUserDO.getServiceCount().toString());
                } else {
                    serviceCountContainer.setVisibility(View.GONE);
                }

                if (searchTopListUserDO.getFansCount() != null) {
                    fansCountContainer.setVisibility(View.VISIBLE);
                    fansCountText.setText(searchTopListUserDO.getFansCount().toString());
                } else {
                    fansCountContainer.setVisibility(View.GONE);
                }

                String userSign = searchTopListUserDO.getUserSign();
                if (!TextUtils.isEmpty(userSign)) {
                    personIntroduce.setText(userSign);
                } else {
                    personIntroduce.setText(R.string.profile_intro_normal);
                }

                rootView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Router.sharedRouter().open("profile/" + searchTopListUserDO.getUserId());
                    }
                });
                break;

            case Constant.SEARCH_TOP_LIST_TYPE_PROMOTION:
                contentView = mInflater.inflate(R.layout.item_search_result_promotion, parent, false);
                SimpleDraweeView promotionPicture = (SimpleDraweeView) contentView.findViewById(R.id.promotionPicture);
                Uri uri = Uri.parse(searchTopListPromotionDO.getImageURL());
                promotionPicture.setImageURI(uri);

                promotionPicture.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", searchTopListPromotionDO.getActionURL());
                        Router.sharedRouter().open("web", bundle);
                    }
                });
                break;

        }

        return contentView;
    }


}
