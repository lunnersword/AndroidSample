package com.meidalife.shz.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.widget.CropImageLayout;
import com.meidalife.shz.widget.CropImageView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by fufeng on 15/10/28.
 */
public class CropImageActivity extends BaseActivity {
    private static final int DATA_OUTPUT_SIZE_LIMIT = 50 * 1024;
    private int mAspectX, mAspectY;
    private int mOutputX, mOutputY;
    private int mCropShap = CropImageView.CROP_SHAPE_RECT;
    private boolean returnData = true;
    private String imagePath;
    int position = 0;

    private Uri mSaveUri;
    private ProgressDialog progressDialog;
    private ContentResolver mContentResolver;
    private CropImageLayout mClipImageLayout;
    private Button useButton;
    private TextView cancelButton;
    private ViewGroup rootView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_image);
        initData();
    }

    private void initData() {
        Bundle extras = getIntent().getExtras();

        if (null != extras) {
            mSaveUri = extras.getParcelable(MediaStore.EXTRA_OUTPUT);
            mAspectX = extras.getInt("aspectX");
            mAspectY = extras.getInt("aspectY");
            mOutputX = extras.getInt("outputX");
            mOutputY = extras.getInt("outputY");
            returnData = extras.getBoolean("return-data");
            imagePath = extras.getString("image_path");
            mCropShap = extras.getInt("crop_shape", CropImageView.CROP_SHAPE_RECT);
            mCropShap = extras.getInt("crop_shape", CropImageView.CROP_SHAPE_RECT);
            position = extras.getInt("position", 0);
        }

        mContentResolver = getContentResolver();

        if (TextUtils.isEmpty(imagePath) || !(new File(imagePath).exists())) {
            Toast.makeText(this, R.string.err_image_not_exist, Toast.LENGTH_SHORT).show();
            return;
        }

        int minSize = Math.min(Resources.getSystem().getDisplayMetrics().widthPixels,
                Resources.getSystem().getDisplayMetrics().heightPixels);

        //Make sure the bitmap not
        Bitmap bitmap = ImgUtil.decodeFile(imagePath, minSize, minSize);

        if (bitmap == null) {
            Toast.makeText(this, R.string.err_image_damage, Toast.LENGTH_SHORT).show();
            return;
        }
        rootView = (ViewGroup) findViewById(R.id.rootView);
        mClipImageLayout = (CropImageLayout) findViewById(R.id.cropImageayout);
        mClipImageLayout.setBitmap(bitmap);
        mClipImageLayout.setCropShape(mCropShap);

        useButton = ((Button) findViewById(R.id.confirmClipButton));
        useButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showStatusLoading(rootView);
                new SaveCroppedImageTask().execute();
            }
        });

        cancelButton = (TextView) findViewById(R.id.action_bar_button_back);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public class SaveCroppedImageTask extends AsyncTask<Void, Integer, Bitmap> {
        Bitmap clipBitmap;
        public SaveCroppedImageTask(){
            clipBitmap = mClipImageLayout.crop();
        }
        @Override
        protected Bitmap doInBackground(Void... params) {
            OutputStream fileOutputStream = null;
            try {
                Bitmap.CompressFormat format = (mCropShap == CropImageView.CROP_SHAPE_CIRCLE ?
                        Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG);
                if (returnData) {
                    Bitmap limitBitmap = ImgUtil.makeSizeLimitBitmap(clipBitmap,
                            DATA_OUTPUT_SIZE_LIMIT, format);
                    if (!clipBitmap.equals(limitBitmap)) {
                        clipBitmap.recycle();
                    }
                    return limitBitmap;
                }
                fileOutputStream = mContentResolver.openOutputStream(mSaveUri);
                if (null != fileOutputStream) {
                    clipBitmap.compress(format, 100, fileOutputStream);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (null != fileOutputStream) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            hideStatusLoading();

            Intent intent = new Intent();
            intent.putExtra("position", position);
            if (bitmap != null) {
                intent.putExtra("data", bitmap);
            }
            setResult(RESULT_OK, intent);
            finish();
        }
    }
}