package com.meidalife.shz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ScheduleDo;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/3/17.
 */
public class TimeScheduleAdapter extends RecyclerView.Adapter<TimeScheduleAdapter.ViewHolder> {
    private static final int TIME_SCHEDULE_TYPE_INTERVAL = 0;
    private static final int TIME_SCHEDULE_TYPE_DAY = 1;
    private static final String TIME_AVAILABLE = "1";
    private static final String TIME_UNAVAILABLE = "0";
    private Context mContext;
    private ArrayList<ScheduleDo> scheduleDoArrayList = new ArrayList<>();
    private onSettingChangeListener onSettingChangeListener;

    public interface onSettingChangeListener {
        void onSettingUpdate();
    }

    public TimeScheduleAdapter(Context context, ArrayList<ScheduleDo> dataList) {
        mContext = context;
        scheduleDoArrayList = dataList;
    }

    public void setOnSettingChangeListener(TimeScheduleAdapter.onSettingChangeListener onSettingChangeListener) {
        this.onSettingChangeListener = onSettingChangeListener;
    }

    public ArrayList<ScheduleDo> getScheduleDoArrayList() {
        return scheduleDoArrayList;
    }

    public void setScheduleDoArrayList(ArrayList<ScheduleDo> scheduleDoArrayList) {
        this.scheduleDoArrayList = scheduleDoArrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ViewHolder viewHolder = new ViewHolder(LayoutInflater.from(mContext).
                inflate(R.layout.item_time_manage, parent, false));
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final ScheduleDo scheduleDo = scheduleDoArrayList.get(position);
        if (scheduleDo.getType() == TIME_SCHEDULE_TYPE_INTERVAL) {
            holder.daySchedule.setVisibility(View.GONE);
            holder.dayOfWeekLabel.setText(Constant.DAY_OF_WEEK[position]);
            String[] scheduleString = scheduleDo.getValue().split("-");
            if (scheduleString.length == 3) {
                holder.amSwitch.setChecked(TIME_AVAILABLE.equals(scheduleString[0]));
                holder.pmSwitch.setChecked(TIME_AVAILABLE.equals(scheduleString[1]));
                holder.niSwitch.setChecked(TIME_AVAILABLE.equals(scheduleString[2]));
            }

            holder.amSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    scheduleDo.setValue(formatIntervalString(scheduleDo,
                            isChecked ? TIME_AVAILABLE : TIME_UNAVAILABLE, null, null));
                    if (onSettingChangeListener != null) {
                        onSettingChangeListener.onSettingUpdate();
                    }
                }
            });

            holder.pmSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    scheduleDo.setValue(formatIntervalString(scheduleDo, null,
                            isChecked ? TIME_AVAILABLE : TIME_UNAVAILABLE, null));
                    if (onSettingChangeListener != null) {
                        onSettingChangeListener.onSettingUpdate();
                    }
                }
            });

            holder.niSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    scheduleDo.setValue(formatIntervalString(scheduleDo, null, null,
                            isChecked ? TIME_AVAILABLE : TIME_UNAVAILABLE));
                    if (onSettingChangeListener != null) {
                        onSettingChangeListener.onSettingUpdate();
                    }
                }
            });
        } else if (scheduleDo.getType() == TIME_SCHEDULE_TYPE_DAY) {
            holder.dayOfWeekLabel.setVisibility(View.GONE);
            holder.amSchedule.setVisibility(View.GONE);
            holder.pmSchedule.setVisibility(View.GONE);
            holder.niSchedule.setVisibility(View.GONE);
            holder.dayScheduleSwitch.setChecked(TIME_AVAILABLE.equals(scheduleDo.getValue()));
            holder.dayOfWeekSchedule.setText(Constant.DAY_OF_WEEK[position]);
            holder.dayScheduleSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    scheduleDo.setValue(isChecked ? TIME_AVAILABLE : TIME_UNAVAILABLE);
                    if (onSettingChangeListener != null) {
                        onSettingChangeListener.onSettingUpdate();
                    }
                }
            });
        }
        if (scheduleDo.isNeedCapability()) {
            holder.serviceCapabilityLayout.setVisibility(View.VISIBLE);
            holder.serviceCapabilityTitle.setText(scheduleDo.getCapabilityName() + "：");
            holder.serviceCapability.setText(scheduleDo.getCapability());
            holder.serviceCapability.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    scheduleDo.setCapability(s.toString());
                }
            });
        } else {
            holder.serviceCapabilityLayout.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return scheduleDoArrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.dayOfWeekLabel)
        TextView dayOfWeekLabel;
        @Bind(R.id.amSchedule)
        ViewGroup amSchedule;
        @Bind(R.id.amSwitch)
        Switch amSwitch;
        @Bind(R.id.pmSchedule)
        ViewGroup pmSchedule;
        @Bind(R.id.pmSwitch)
        Switch pmSwitch;
        @Bind(R.id.niSchedule)
        ViewGroup niSchedule;
        @Bind(R.id.niSwitch)
        Switch niSwitch;
        @Bind(R.id.daySchedule)
        ViewGroup daySchedule;
        @Bind(R.id.dayOfWeekSchedule)
        TextView dayOfWeekSchedule;
        @Bind(R.id.dayScheduleSwitch)
        Switch dayScheduleSwitch;
        @Bind(R.id.serviceCapabilityLayout)
        ViewGroup serviceCapabilityLayout;
        @Bind(R.id.serviceCapabilityTitle)
        TextView serviceCapabilityTitle;
        @Bind(R.id.serviceCapability)
        EditText serviceCapability;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    private String formatIntervalString(ScheduleDo scheduleDo, String am, String pm, String ni) {
        String[] scheduleString = scheduleDo.getValue().split("-");
        if (scheduleString.length < 3) {
            return scheduleDo.getValue();
        }
        if (!TextUtils.isEmpty(am)) {
            scheduleString[0] = am;
        }

        if (!TextUtils.isEmpty(pm)) {
            scheduleString[1] = pm;
        }

        if (!TextUtils.isEmpty(ni)) {
            scheduleString[2] = ni;
        }
        return String.format("%1$s-%2$s-%3$s", scheduleString[0], scheduleString[1], scheduleString[2]);
    }
}
