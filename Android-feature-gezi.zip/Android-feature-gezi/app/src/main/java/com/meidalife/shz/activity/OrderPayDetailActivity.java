package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.StrUtil;

/**
 * Created by shijian on 15/8/30.
 */
public class OrderPayDetailActivity extends BaseActivity {

    private String orderNo;

    private ViewGroup rootView;
    private View contentRoot;
    private LoadUtilV2 loadUtilV2;

    private RelativeLayout wechatDetailLayout;
    private RelativeLayout alipayDetailLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_pay_detail);
        initActionBar(R.string.title_order_pay_detail, true);

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);
        loadUtilV2 = new LoadUtilV2(getLayoutInflater());

        wechatDetailLayout = (RelativeLayout) findViewById(R.id.wechat_detail);
        alipayDetailLayout = (RelativeLayout) findViewById(R.id.alipay_detail);

        Bundle extras = getIntent().getExtras();
        orderNo = extras.getString("orderNo");

        initLoadData();
    }

    private void initLoadData() {
        loadUtilV2.loadPre(rootView, contentRoot);
        JSONObject params = new JSONObject();
        params.put("orderNo", orderNo);
        HttpClient.get("1.0/userOrder/getPayInfo", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {

                loadUtilV2.loadSuccess(contentRoot);

                TextView payAll = (TextView) findViewById(R.id.pay_all);
                Double amount = obj.getDouble("amount");
                payAll.setText("退还金额：" + StrUtil.doubleFormat(amount / 100) + "元");

                JSONArray payList = obj.getJSONArray("paywayList");
                // 顺序为：生活豆，余额，支付宝。 {"amount":20,"paywayText":"生活豆","status":3,"statusText":"已付款","payway":4}
                for (int i = 0; i < payList.size(); i++) {
                    JSONObject payDetail = payList.getJSONObject(i);
                    int payWay = payDetail.getInteger(Pay.TAG_PAY_WAY);
                    switch (payWay) {
                        case Pay.PAY_WAY_ALIPAY: {
                            JSONObject alipayPayData = payList.getJSONObject(i);
                            TextView alipayNumber = (TextView) findViewById(R.id.pay_alipay);
                            alipayNumber.setText(StrUtil.doubleFormat(alipayPayData.getDouble("amount") / 100) + "元");
                            alipayDetailLayout.setVisibility(View.VISIBLE);
                            break;
                        }
                        case Pay.PAY_WAY_WECHAT: {
                            JSONObject wechatPayData = payList.getJSONObject(i);
                            TextView wechatPayNumber = (TextView) findViewById(R.id.pay_wechat);
                            wechatPayNumber.setText(StrUtil.doubleFormat(wechatPayData.getDouble("amount") / 100) + "元");
                            wechatDetailLayout.setVisibility(View.VISIBLE);
                            break;
                        }
                        case Pay.PAY_WAY_FUND: {
                            JSONObject resPay = payList.getJSONObject(i);
                            TextView res = (TextView) findViewById(R.id.pay_residual);
                            res.setText(StrUtil.doubleFormat(resPay.getDouble("amount") / 100) + "元");
                            break;
                        }
                        case Pay.PAY_WAY_MCOIN: {
                            JSONObject mcoinPay = payList.getJSONObject(i);
                            TextView mcoin = (TextView) findViewById(R.id.pay_mcoin);
                            mcoin.setText(StrUtil.doubleFormat(mcoinPay.getDouble("amount") / 100) + "个");
                            break;
                        }
                    }
                }
            }

            @Override
            public void onFail(HttpError error) {
                loadUtilV2.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        initLoadData();
                    }
                });
            }
        });
    }
}
