package com.meidalife.shz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CertificationListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CertDO;
import com.meidalife.shz.rest.model.CertificationBean;
import com.meidalife.shz.rest.model.CertificationCertDO;
import com.meidalife.shz.rest.model.CertificationDO;
import com.meidalife.shz.rest.model.TemplateDO;
import com.meidalife.shz.util.CollectionUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * add by zuozheng
 * 认证列表
 */
public class CertificationListActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener, CertificationListAdapter.DeleteListener {
    private LayoutInflater inflater;

    private SwipeRefreshLayout mSwipeRefreshLayout;
    private ListView authListView;
    private View noDataView;
    private CertificationListAdapter orderListAdapter;

    private ViewGroup rootView;
    private Button descButton;

    private View addAuthView;

    private Map<View, TextView> authTypeMap = new HashMap<>();

    private int authType = Constant.TYPE_OFFICIAL;

    List<CertificationBean> mAuthList = new ArrayList<CertificationBean>();

    CertificationDO certificationDO = new CertificationDO();

    //是否进行芝麻认证
    private boolean zmAuth = false;
    //芝麻认证时间
    private String zmTime = "";
    //是否实名认证
    private boolean realUser = false;
    //用户真实姓名
    private String realName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);

        inflater = getLayoutInflater();
        rootView = (ViewGroup) findViewById(R.id.root_view);

        initActionBar(R.string.auth_skill_title, true, true);//统一继承BaseActivity风格

        descButton = (Button) findViewById(R.id.action_bar_button_right);
        descButton.setText(R.string.desc);
        descButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Router.sharedRouter().open("orderSearch/" + roleType);
                //todo  jump to h5
                String url = "http://www.shenghuozhe.net/support/cert_rule.html?isRealUser=%s";
                String finalUrl = String.format(url, realUser ? 1 : 0);
                Intent intent = new Intent();
                intent.setClass(CertificationListActivity.this, WebActivity.class);
                intent.putExtra("url", finalUrl);
                startActivity(intent);

            }
        });

        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.list_swipe); //下拉刷新组件
        noDataView = findViewById(R.id.no_data);
        authListView = (ListView) findViewById(R.id.auth_list);

        addAuthView = findViewById(R.id.auth_list_foot);
        addAuthView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (realUser) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("type", authType);
                    bundle.putBoolean("realUser", realUser);
                    bundle.putString("realName", realName);
                    Router.sharedRouter().open("certify", bundle);
                } else {
                    MessageUtils.showToast("芝麻信用或实名认证后才能添加个性认证哦~");
                }
            }
        });

        View listViewHead = inflater.inflate(R.layout.item_home_listview_head, null);
        authListView.addHeaderView(listViewHead);

        orderListAdapter = new CertificationListAdapter(CertificationListActivity.this, mAuthList);

        orderListAdapter.setmListener(this);

        authListView.setAdapter(orderListAdapter);

        mSwipeRefreshLayout.setOnRefreshListener(CertificationListActivity.this); //设置刷新监听器
        mSwipeRefreshLayout.setProgressViewOffset(false, 150, 250);

        authListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //todo 判断类型 如果是芝麻信用认证 跳转到支付宝
                //其他 跳转到详情
                if ((position - 1) < mAuthList.size()) {
                    CertificationBean certificationBean = mAuthList.get(position - 1);

                    if (certificationBean != null) {
                        if (certificationBean.isAlipayAuth()) {
                            String url;
                            if (zmAuth) {
                                url = "https://xy.alipay.com/auth/whatszhima.htm?view=mobile";
                            } else {
                                // 若未授权，跳转到授权页面
                                url = "http://shenghuozhe.net/events/app_zmxy.html";
                            }
                            Bundle bundle = new Bundle();
                            bundle.putString("url", url);
                            Router.sharedRouter().open("web", bundle);
                        } else {
                            Bundle bundle = new Bundle();
                            bundle.putInt("tid", certificationBean.getTid());
                            bundle.putInt("id", certificationBean.getCertId());
                            bundle.putInt("type", authType);
                            bundle.putBoolean("realUser", realUser);
                            bundle.putString("realName", realName);
//                            bundle.putBoolean("isRealNameCert", "实名认证".equals(certificationBean.getTitle()) ? true : false);
                            Router.sharedRouter().open("certify", bundle);
                        }
                    }
                }
            }
        });

        // 初始化订单类型
        initAuthType();
    }


    @Override
    public void onResume() {
        super.onResume();
        // 初始化数据
        initData(authType);
    }

    public void initData(final int type) {
        showStatusLoading(rootView);
        noDataView.setVisibility(View.GONE);
        authRequest(type);
    }

    ///1.0/cert/list?data={"type":1}, 1=官方，2=技能 http://webdev1.shenghuozhe.net/shz/1.0/cert/list?data={%22type%22:1}&userId=10001298
    void authRequest(final int type) {
        JSONObject params = new JSONObject();
        String userId = Helper.sharedHelper().getUserId();
        params.put("userId", userId);
        params.put("type", type);
        HttpClient.get("1.0/cert/list", params, CertificationDO.class, new HttpClient.HttpCallback<CertificationDO>() {
            @Override
            public void onSuccess(CertificationDO obj) {
                hideStatusLoading();
                mSwipeRefreshLayout.setRefreshing(false);

                certificationDO = obj;

                //todo 解析authDO对象 拼装list
                mAuthList.clear();

                if ((certificationDO == null || CollectionUtil.isEmpty(certificationDO.getCertList())) && authType == Constant.TYPE_PERSONAL) {
                    mSwipeRefreshLayout.setVisibility(View.GONE);
                    noDataView.setVisibility(View.VISIBLE);
                } else {
                    mSwipeRefreshLayout.setVisibility(View.VISIBLE);
                    noDataView.setVisibility(View.GONE);

                    if (certificationDO != null) {

                        //官方认证 解析字段
                        zmAuth = certificationDO.isZmAuth();
                        zmTime = certificationDO.getZmTime();
                        realUser = certificationDO.isRealUser();
                        realName = certificationDO.getRealName();

                        //todo 存储用户的状态

                        if (type == Constant.TYPE_OFFICIAL) {
                            CertificationBean bean = new CertificationBean();
                            bean.setTitle("芝麻信用认证");

                            if (zmAuth) {
                                bean.setStatus(Constant.CERT_STATUS_PASS);
                                bean.setStatusStr("官方认证");
                            } else {
                                bean.setStatus(Constant.CERT_STATUS_UNCOMMIT);
                                bean.setStatusStr("未认证");
                            }
                            bean.setAlipayAuth(true);
                            bean.setTime(zmTime);

                            mAuthList.add(bean);
                        }

                        //解析certList字段
                        if (CollectionUtil.isNotEmpty(certificationDO.getCertList())) {
                            for (CertificationCertDO certificationCertDO : certificationDO.getCertList()) {
                                //用户进行任何认证  解析cert字段 展现认证内容
                                if (certificationCertDO != null) {
                                    CertificationBean bean = new CertificationBean();
                                    CertDO cert = certificationCertDO.getCert();

                                    //用户没有进行任何认证 解析template字段 展现模版
                                    TemplateDO template = certificationCertDO.getTemplate();
                                    if (cert != null) {
                                        bean.setPicUrlList(cert.getPicsValue());
                                        if (CollectionUtil.isEmpty(cert.getPicsValue())) {
                                            bean.setPicCount(0);
                                        } else {
                                            bean.setPicCount(cert.getPicsValue().size());
                                        }
                                        bean.setTitle(cert.getTagName());

                                        bean.setIsRealUser(realUser);

                                        int status = cert.getStatus();

                                        if (status == Constant.CERT_STATUS_AUDIT) {
                                            bean.setStatusStr("审核中");
                                        } else if (status == Constant.CERT_STATUS_PASS) {
                                            bean.setStatusStr("已通过");
                                        } else if (status == Constant.CERT_STATUS_DENY) {
                                            bean.setStatusStr("未通过");
                                        } else {
                                            bean.setStatus(Constant.CERT_STATUS_UNCOMMIT);
                                            bean.setStatusStr("未认证");
                                        }
                                        bean.setStatus(status);

                                        bean.setDesc(cert.getAuditReason());
                                        bean.setTime(cert.getUpdateTime());

                                        bean.setCertId(cert.getId());

                                    } else if (template != null) {
                                        //默认给用户展示图片
                                        List<String> picUrlList = new ArrayList<String>();
                                        picUrlList.add(template.getImage());
                                        bean.setPicUrlList(picUrlList);

                                        bean.setTitle(template.getTagName());
                                        bean.setStatus(Constant.CERT_STATUS_UNCOMMIT);
                                        bean.setStatusStr("未认证");
                                        bean.setDesc(template.getBenefit());
                                        bean.setTime("");

                                        bean.setTid(template.getId());
                                    }

                                    mAuthList.add(bean);
                                }
                            }
                        }
                    }

                }

                orderListAdapter.updateData(mAuthList);

                //如果用户点击个人认证同时已经通过实名认证 显示添加认证按钮
                if (authType == Constant.TYPE_PERSONAL) {
                    addAuthView.setVisibility(View.VISIBLE);
                } else {
                    addAuthView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFail(HttpError error) {
                mAuthList.clear();
                orderListAdapter.updateData(mAuthList);

                mSwipeRefreshLayout.setRefreshing(false);

                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData(authType);
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData(authType);
                        }
                    });
                }
            }
        });
    }

    void initAuthType() {

        View.OnClickListener orderTypeClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (authTypeMap != null && authTypeMap.keySet().size() > 0) {
                    for (Map.Entry<View, TextView> e : authTypeMap.entrySet()) {
                        View onView = e.getKey();
                        TextView label = e.getValue();
                        if (onView == v) {
                            onView.setBackgroundResource(R.drawable.order_list_type_bottom);
                            label.setTextColor(getResources().getColor(R.color.brand_b));
                            authType = (Integer) onView.getTag();
                        } else {
                            onView.setBackgroundResource(R.color.white);
                            label.setTextColor(getResources().getColor(R.color.grey_a));
                        }
                    }
                    initData(authType);
                }
            }
        };

        View officialAuthView = findViewById(R.id.auth_type_official);
        TextView allLabel = (TextView) findViewById(R.id.auth_type_official_label);
        authTypeMap.put(officialAuthView, allLabel);
        officialAuthView.setOnClickListener(orderTypeClick);
        officialAuthView.setTag(Constant.TYPE_OFFICIAL);
        officialAuthView.setBackgroundResource(R.drawable.order_list_type_bottom);
        allLabel.setTextColor(getResources().getColor(R.color.brand_b));

        View personalAuthView = findViewById(R.id.auth_type_personal);
        TextView acceptLabel = (TextView) findViewById(R.id.auth_type_personal_label);
        authTypeMap.put(personalAuthView, acceptLabel);
        personalAuthView.setOnClickListener(orderTypeClick);
        personalAuthView.setTag(Constant.TYPE_PERSONAL);
        personalAuthView.setBackgroundResource(R.color.white);
        acceptLabel.setTextColor(getResources().getColor(R.color.grey_a));

    }

    @Override
    public void onRefresh() {
        initData(authType);
    }

    @Override
    public void onDeleteClick(final int certId) {
        MessageUtils.showDialog(this, "确认删除？", "删除后该认证资料将无法恢复", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                executeDel(certId);
            }
        }, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
    }

    void executeDel(int certId) {

        JSONObject params = new JSONObject();
        String userId = Helper.sharedHelper().getUserId();
        params.put("userId", userId);
        params.put("certId", certId);

        showProgressDialog("正在删除");
        HttpClient.get("1.0/cert/del", params, JSONObject.class, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideProgressDialog();
                initData(authType);
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToast("删除失败");
            }
        });
    }
}
