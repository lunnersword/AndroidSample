package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

/**
 * Created by fufeng on 15/9/26.
 */
public class OpusShowAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private List<String> mData;
    private final int image_size;

    public OpusShowAdapter(Context context, List<String> data) {
        mContext = context;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        image_size = context.getResources().getDisplayMetrics().widthPixels -
                context.getResources().getDimensionPixelSize(R.dimen.opus_detail_padding) * 2;
    }

    public void updateOpusShow(List<String> data) {
        mData = data;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (null == convertView) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.opus_show_item, null);
            holder.image = (SimpleDraweeView) convertView.findViewById(R.id.opus_image);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        int imgWidth = image_size;
        int imgHeight = image_size;
        try {
            String imgUrl = mData.get(position);
            String[] arrays = imgUrl.split("/");
            String[] imgWh = arrays[arrays.length - 1].split("_");
            if (imgWh.length == 3) {
                float width = Integer.parseInt(imgWh[0].substring(0, imgWh[0].length() - 1));
                float height = Integer.parseInt(imgWh[1].substring(0, imgWh[1].length() - 1));
                imgHeight = (int) ((height * imgWidth) / width);
                //避免超出4096导致图片无法显示
                if (imgHeight > 4096) {
                    imgHeight = 4096;
                    imgWidth = (int) ((width / height) * 4096);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String cdnUrl = ImgUtil.getCDNUrlWithWidth(mData.get(position), image_size);

        ViewGroup.LayoutParams params = holder.image.getLayoutParams();
        params.height = imgHeight;
        params.width = imgWidth;
        holder.image.setImageURI(Uri.parse(cdnUrl));
        return convertView;
    }

    public static class ViewHolder {
        SimpleDraweeView image;
    }
}
