package com.meidalife.shz.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by shijian on 15/8/25.
 */
public class OrderRefundDetailActivity extends BaseActivity {

    private LayoutInflater inflater;
    private Context context;
    private LoadUtilV2 loadUtilV2;

    private ViewGroup rootView;
    private View contentRoot;

    private String orderNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_refund_detail);
        inflater = getLayoutInflater();
        context = getApplicationContext();
        loadUtilV2 = new LoadUtilV2(inflater);

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);

        initActionBar(R.string.title_refund_detail, true);

        Bundle extras = getIntent().getExtras();
        orderNo = extras.getString("orderNo");

        initLoadData();
    }

    public void initLoadData() {
        loadUtilV2.loadPre(rootView, contentRoot);
        JSONObject params = new JSONObject();
        params.put("orderNo", orderNo);
        HttpClient.get("1.0/refund/detail", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {

                loadUtilV2.loadSuccess(contentRoot);
                final String id = obj.getString("id");
                int role = obj.getInteger("role");

                // 主状态
                TextView status = (TextView) findViewById(R.id.status);
                status.setText(obj.getString("msg"));

                // tip提示
                JSONObject tips = obj.getJSONObject("commentMsg");
                if (tips == null) {
                    findViewById(R.id.refund_tips_group).setVisibility(View.GONE);
                } else {
                    View agreeGroup = findViewById(R.id.agree_group);
                    String agree = tips.getString("agree");
                    if (StrUtil.isEmpty(agree)) {
                        agreeGroup.setVisibility(View.GONE);
                    } else {
                        TextView agreeView = (TextView) findViewById(R.id.agree);
                        agreeView.setText(agree);
                        TextView agreeLabel = (TextView) findViewById(R.id.agree_label);
                        agreeLabel.setText(role == 0 ? "如果服务者同意：" : "如果您同意：");
                    }
                    View refuseGroup = findViewById(R.id.refuse_group);
                    String refuse = tips.getString("refuse");
                    if (StrUtil.isEmpty(agree)) {
                        refuseGroup.setVisibility(View.GONE);
                    } else {
                        TextView refuseView = (TextView) findViewById(R.id.refuse);
                        refuseView.setText(refuse);
                        TextView refuseLabel = (TextView) findViewById(R.id.refuse_label);
                        refuseLabel.setText(role == 0 ? "如果服务者拒绝：" : "如果您拒绝：");
                    }
                    View untreatedGroup = findViewById(R.id.untreated_group);
                    String untreated = tips.getString("untreated");
                    if (StrUtil.isEmpty(agree)) {
                        untreatedGroup.setVisibility(View.GONE);
                    } else {
                        TextView untreatedView = (TextView) findViewById(R.id.untreated);
                        untreatedView.setText(untreated);
                        TextView untreatedLabel = (TextView) findViewById(R.id.untreated_label);
                        untreatedLabel.setText(role == 0 ? "如果服务者未处理：" : "如果您未处理：");
                    }
                }

                // 明细
                JSONArray dataList = obj.getJSONArray("detailList");
                RefundDetailAdapter refundDetailAdapter = new RefundDetailAdapter(dataList);
                ListView detailList = (ListView) findViewById(R.id.refund_detail_list);
                detailList.setAdapter(refundDetailAdapter);

                // 操作列表
                Integer oper = obj.getInteger("oper");
                if (oper == null) {
                    findViewById(R.id.refund_opr_group).setVisibility(View.GONE);
                } else if (oper == 1) {
                    View oprAgreeView = findViewById(R.id.refund_opr_agree);
                    oprAgreeView.setVisibility(View.VISIBLE);
                    oprAgreeView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            tip("确认退款后订单金额将全部退回到买家账户。", new TipCallback() {
                                @Override
                                public void execute() {
                                    JSONObject params = new JSONObject();
                                    params.put("id", id);
                                    params.put("act", 0);
                                    HttpClient.get("1.0/refund/updateBySeller", params, null, new HttpClient.HttpCallback<JSONObject>() {
                                        @Override
                                        public void onSuccess(JSONObject obj) {
                                            Router.sharedRouter().open("orders/" + orderNo);
                                            finish();
                                        }

                                        @Override
                                        public void onFail(HttpError error) {
                                            MessageUtils.showToastCenter(error.toString());
                                        }
                                    });
                                }
                            });
                        }
                    });
                    View oprRefuseView = findViewById(R.id.refund_opr_refuse);
                    oprRefuseView.setVisibility(View.VISIBLE);
                    oprRefuseView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Router.sharedRouter().open("orderRefundRefuse/" + orderNo + "/" + id);
                            finish();
                        }
                    });
                } else if (oper == 2) {
                    View oprKefuView = findViewById(R.id.refund_opr_kefu);
                    oprKefuView.setVisibility(View.VISIBLE);
                    oprKefuView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            JSONObject params = new JSONObject();
                            params.put("id", id);
                            HttpClient.get("1.0/refund/askForKeFu", params, null, new HttpClient.HttpCallback<JSONObject>() {
                                @Override
                                public void onSuccess(JSONObject obj) {
                                    initLoadData();
                                    MessageUtils.showToastCenter("申请成功，稍后客服将致电了解具体情况");
                                }

                                @Override
                                public void onFail(HttpError error) {
                                    MessageUtils.showToastCenter("申请失败, " + error.toString());
                                }
                            });
                        }
                    });

                    View oprCancelView = findViewById(R.id.refund_opr_cancel);
                    oprCancelView.setVisibility(View.VISIBLE);
                    oprCancelView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            tip("确认取消后，退款关闭且订单金额将全部打给卖家。", new TipCallback() {
                                @Override
                                public void execute() {
                                    JSONObject params = new JSONObject();
                                    params.put("id", id);
                                    HttpClient.get("1.0/refund/confirmRefuse", params, null, new HttpClient.HttpCallback<JSONObject>() {
                                        @Override
                                        public void onSuccess(JSONObject obj) {
                                            Router.sharedRouter().open("orders/" + orderNo);
                                            finish();
                                        }

                                        @Override
                                        public void onFail(HttpError error) {
                                            MessageUtils.showToastCenter(error.toString());
                                        }
                                    });
                                }
                            });
                        }
                    });
                } else if (oper == 3) {
                    View oprLookView = findViewById(R.id.refund_opr_look);
                    oprLookView.setVisibility(View.VISIBLE);
                    oprLookView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Router.sharedRouter().open("orderPayDetail/" + orderNo);
                        }
                    });
                }
            }

            @Override
            public void onFail(HttpError error) {
                loadUtilV2.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        initLoadData();
                    }
                });
            }
        });
    }


    class RefundDetailAdapter extends BaseAdapter {

        private JSONArray datas;

        public RefundDetailAdapter(JSONArray datas) {
            this.datas = datas;
        }

        @Override
        public int getCount() {
            return datas.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            JSONObject detail = datas.getJSONObject(position);
            View root = inflater.inflate(R.layout.activity_order_refund_detail_item, null);

            TextView noView = (TextView) root.findViewById(R.id.no);
            noView.setText(String.valueOf(position + 1));

            View noLine = (TextView) root.findViewById(R.id.noLine);


            TextView topMsg = (TextView) root.findViewById(R.id.topMsg);
            TextView fundNumView = (TextView) root.findViewById(R.id.fundNum);

            topMsg.setText(detail.getString("topMsg"));
            Boolean hasDetail = detail.getBoolean("hasDetail");
            if (hasDetail) {
                topMsg.setTextColor(getResources().getColor(R.color.grey_a));
                fundNumView.setTextColor(getResources().getColor(R.color.grey_a));
                noView.setBackgroundResource(R.drawable.order_refund_detail_red_bg);
                noLine.setBackgroundResource(R.color.brand_b);
            } else {
                topMsg.setTextColor(getResources().getColor(R.color.grey_c));
                fundNumView.setTextColor(getResources().getColor(R.color.grey_c));
                noView.setBackgroundResource(R.drawable.order_refund_detail_num_bg);
                noLine.setBackgroundResource(R.color.brand_e);
            }

            String fundNum = detail.getString("fundNum");
            if (StrUtil.isEmpty(fundNum)) {
                fundNumView.setVisibility(View.GONE);
            } else {
                fundNumView.setText("金额：" + fundNum + "元");
            }

            TextView reasonView = (TextView) root.findViewById(R.id.reason);
            String reason = detail.getString("reason");
            if (StrUtil.isEmpty(reason)) {
                reasonView.setVisibility(View.GONE);
            } else {
                reasonView.setText("原因：" + reason);
            }

            TextView commentView = (TextView) root.findViewById(R.id.comment);
            String comment = detail.getString("comment");
            if (StrUtil.isEmpty(comment)) {
                commentView.setVisibility(View.GONE);
            } else {
                commentView.setText("说明：" + comment);
            }

            View deliveryGroup = root.findViewById(R.id.delivery_group);
            JSONObject deliverVO = detail.getJSONObject("deliverVO");
            if (deliverVO == null || deliverVO.size() == 0) {
                deliveryGroup.setVisibility(View.GONE);
            } else {
                TextView deliveryInfoView = (TextView) root.findViewById(R.id.delivery_info);
                final String compName = deliverVO.getString("companyName");
                final String deliveryNo = deliverVO.getString("deliveryNo");
                deliveryInfoView.setText("物流信息：" + compName + "  " + deliveryNo);
                root.findViewById(R.id.delivery_click).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // http://m.kuaidi100.com/index_all.html?type=%E5%85%A8%E5%B3%B0&postid=123456789
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "http://m.kuaidi100.com/index_all.html?type=" + compName + "&postid=" + deliveryNo);
                        Router.sharedRouter().open("web", bundle);
                    }
                });
            }

            GridView imgsView = (GridView) root.findViewById(R.id.imgs);
            JSONArray imgs = detail.getJSONArray("picList");
            if (imgs != null && imgs.size() > 0) {
                List<String> imgList = new ArrayList<>(imgs.size());
                for (int i = 0; i < imgs.size(); i++) {
                    imgList.add(imgs.getString(i));
                }
                imgsView.setAdapter(new PicsAdapter(imgList));
            } else {
                imgsView.setVisibility(View.GONE);
            }

            TextView dateView = (TextView) root.findViewById(R.id.date);
            String date = detail.getString("date");
            if (StrUtil.isEmpty(date)) {
                dateView.setVisibility(View.GONE);
            } else {
                dateView.setText(date);
            }

            convertView = root;
            return convertView;
        }
    }


    class PicsAdapter extends BaseAdapter {

        private List<String> picList;

        public PicsAdapter(List<String> picList) {
            this.picList = picList;
        }

        @Override
        public int getCount() {
            return picList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            SimpleDraweeView imageView = null;
            if (convertView != null) {
                imageView = (SimpleDraweeView) convertView;
            } else {
                imageView = new SimpleDraweeView(context);
                imageView.setLayoutParams(new AbsListView.LayoutParams((int) Helper.convertDpToPixel(60, context), (int) Helper.convertDpToPixel(60, context)));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putInt("index", position);
                        bundle.putStringArrayList("photos", (ArrayList<String>) picList);
                        Router.sharedRouter().open("imageBrowser", bundle);
                    }
                });
            }
            ImgUtil.load(context, picList.get(position), imageView.getLayoutParams(), imageView);
            return imageView;
        }
    }


    private void tip(String msg, final TipCallback callback) {
        MessageUtils.createDialog(OrderRefundDetailActivity.this, "提醒", msg, R.string.confirm, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                callback.execute();
            }
        }, R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // do nothing
            }
        }).show();
    }

    public static interface TipCallback {
        public void execute();
    }


}
