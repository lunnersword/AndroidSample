package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.event.SquareHandlerPinEvent;
import com.meidalife.shz.event.SquareRefreshEvent;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.DateUtils;

import de.greenrobot.event.EventBus;

/**
 * Created by xingchen on 2015/12/18.
 */
public class SquareBbsListAdapter extends BaseAdapter {
    private LayoutInflater mInflater;
    private JSONArray topicList;
    private Context context;
    private boolean isGezhu = false;
    private boolean isJoined = false;

    int haveVoted = 0;
    private static final int TYPE_ZAN = 10;
    private static final int TYPE_CAI = 11;

    private SquareHandlerPinEvent squareHandlerPinEvent;

    public SquareBbsListAdapter(Context context, JSONArray topicList) {
        this.context = context;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.topicList = topicList;
    }

    public void setSquareHandlerPinEvent(SquareHandlerPinEvent squareHandlerPinEvent) {
        this.squareHandlerPinEvent = squareHandlerPinEvent;
    }

    public void setIsGezhu(boolean isGezhu) {
        this.isGezhu = isGezhu;
    }

    public void setTopicList(JSONArray topicList) {
        this.topicList = topicList;
    }

    public void setIsJoined(boolean isJoined) {
        this.isJoined = isJoined;
    }

    public void clearData() {
        this.topicList.clear();
    }

    public void addData(JSONArray topicList) {
        this.topicList.addAll(topicList);
    }

    @Override
    public int getCount() {
        return topicList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_chat_hall, parent, false);
            holder = new ViewHolder();
            holder.caiCount = (TextView) convertView.findViewById(R.id.caiCount);
            holder.iconGender = (TextView) convertView.findViewById(R.id.iconGender);
            holder.textNick = (TextView) convertView.findViewById(R.id.textNick);
            holder.textTime = (TextView) convertView.findViewById(R.id.textTime);
            holder.textTitle = (TextView) convertView.findViewById(R.id.textTitle);
            holder.iconTitleView = (SimpleDraweeView) convertView.findViewById(R.id.iconTitleView);
            holder.iconTitle = (TextView) convertView.findViewById(R.id.iconTitle);
            holder.zanCount = (TextView) convertView.findViewById(R.id.zanCount);
            holder.commentCount = (TextView) convertView.findViewById(R.id.commentCount);
            holder.picView = (SimpleDraweeView) convertView.findViewById(R.id.picView);
            holder.imageAvatar = (SimpleDraweeView) convertView.findViewById(R.id.imageAvatar);
            holder.pinHandlerView = (TextView) convertView.findViewById(R.id.pinHandlerView);
            holder.pinView = convertView.findViewById(R.id.pinView);
            holder.zanIcon = (TextView) convertView.findViewById(R.id.zanIcon);
            holder.caiIcon = (TextView) convertView.findViewById(R.id.caiIcon);
            holder.zanLayout = convertView.findViewById(R.id.zanLayout);
            holder.caiLayout = convertView.findViewById(R.id.caiLayout);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final JSONObject item = topicList.getJSONObject(position);
        holder.caiCount.setText(item.getIntValue("againstCount") + "");
        holder.zanCount.setText(item.getIntValue("supportCount") + "");
        holder.commentCount.setText(String.format(context.getString(R.string.chat_hall_comment), item.getIntValue("commentCount") + ""));
        String time = DateUtils.getOffsetDays(System.currentTimeMillis(), item.getLongValue("updateTime"));
        holder.textTime.setText(time);
        if ("M".equals(item.getString("userGender"))) {
            holder.iconGender.setText(R.string.icon_gender_m);
            holder.iconGender.setTextColor(context.getResources().getColor(R.color.gender_m));
        } else {
            holder.iconGender.setText(R.string.icon_gender_f);
            holder.iconGender.setTextColor(context.getResources().getColor(R.color.pink_a));
        }

        if (item.getJSONArray("pics") == null || item.getJSONArray("pics").size() == 0
                || !item.getJSONArray("pics").getString(0).contains("http://")) {
            holder.picView.setVisibility(View.GONE);
        } else {
            holder.picView.setVisibility(View.VISIBLE);
            holder.picView.setImageURI(Uri.parse(item.getJSONArray("pics").getString(0)));
        }

        if (item.containsKey("userAvatar")) {
            holder.imageAvatar.setImageURI(Uri.parse(item.getString("userAvatar")));
        } else
            holder.imageAvatar.setImageURI(Uri.parse(""));
        holder.textNick.setText(item.getString("userNick"));
        holder.textTitle.setText(item.getString("title"));
        if (item.getString("icon").contains("http://")) {
            holder.iconTitleView.setImageURI(Uri.parse(item.getString("icon")));
            holder.iconTitle.setVisibility(View.GONE);
            holder.iconTitleView.setVisibility(View.VISIBLE);
        } else {
            holder.iconTitle.setText(item.getString("icon"));
            holder.iconTitleView.setVisibility(View.GONE);
            holder.iconTitle.setVisibility(View.VISIBLE);
        }

        holder.zanIcon.setTextColor(context.getResources().getColor(R.color.grey_c));
        holder.caiIcon.setTextColor(context.getResources().getColor(R.color.grey_c));
        holder.zanCount.setTextColor(context.getResources().getColor(R.color.grey_c));
        holder.caiCount.setTextColor(context.getResources().getColor(R.color.grey_c));
        if (item.containsKey("voteValue")) {
            if (item.getIntValue("voteValue") == 1) {
                holder.zanIcon.setTextColor(context.getResources().getColor(R.color.brand_b));
                holder.zanCount.setTextColor(context.getResources().getColor(R.color.brand_b));
            } else if (item.getIntValue("voteValue") == -1) {
                holder.caiIcon.setTextColor(context.getResources().getColor(R.color.grey_k));
                holder.caiCount.setTextColor(context.getResources().getColor(R.color.grey_k));
            }
        }


        holder.pinHandlerView.setVisibility(View.GONE);

        //格子页是否置顶
        if (item.containsKey("pin") && item.getBoolean("pin")) {
            holder.pinView.setVisibility(View.VISIBLE);
        } else {
            holder.pinView.setVisibility(View.GONE);
        }


        holder.zanLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hasVote = item.containsKey("voteValue") ? item.getInteger("voteValue") : 0;
                if (hasVote == 1) {
                    MessageUtils.showToast("你已经点过赞了哦");
                    return;
                }
                JSONObject params = new JSONObject();
                params.put("topicId", "" + item.getInteger("id"));
                params.put("value", 1);
                updateVote(params, TYPE_ZAN);
            }
        });

        holder.caiLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hasVote = item.containsKey("voteValue") ? item.getInteger("voteValue") : 0;
                if (hasVote == -1) {
                    MessageUtils.showToast("你已经踩过了唉");
                    return;
                }
                JSONObject params = new JSONObject();
                params.put("topicId", "" + item.getInteger("id"));
                params.put("value", -1);
                updateVote(params, TYPE_CAI);
            }
        });
        return convertView;
    }

    static class ViewHolder {
        SimpleDraweeView imageAvatar;
        TextView iconGender;
        TextView textNick;
        TextView textTime;
        SimpleDraweeView iconTitleView;
        TextView textTitle;
        SimpleDraweeView picView;
        TextView commentCount;
        TextView caiCount;
        TextView zanCount;
        TextView iconTitle;
        TextView pinHandlerView;
        View pinView;
        TextView zanIcon;
        TextView caiIcon;
        View zanLayout;
        View caiLayout;
    }

    private void updateVote(JSONObject params, final int type) {
        HttpClient.get("1.0/gezi/bbs/vote", params, null, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object result) {
                if (type == TYPE_ZAN) {
                    haveVoted = 1;
                } else if (type == TYPE_CAI) {
                    haveVoted = -1;
                }
                SquareRefreshEvent event = new SquareRefreshEvent();
                event.isGezhu = isGezhu;
                event.isJoined = isJoined;
                event.showLoading = false;
                EventBus.getDefault().post(event);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "投票失败，请重试");

            }
        });
    }

}
