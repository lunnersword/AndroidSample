package com.meidalife.shz.dexposed.query;

/**
 * Created by zhq on 15/12/9.
 */
public interface OnRequestCallBackListener {
    void onRequest(PatchInfo info);
}
