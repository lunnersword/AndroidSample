package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServicePropDo;
import com.meidalife.shz.util.StrUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 16/3/10.
 */
public class ServicePropAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private List<ServicePropDo> propList = new ArrayList<>();

    public ServicePropAdapter(Context context, List<ServicePropDo> list) {
        mContext = context;
        mInflater = LayoutInflater.from(context);
        setPropList(list);
    }

    public void setPropList(List<ServicePropDo> propList) {
        this.propList = propList;
    }

    @Override
    public int getCount() {
        return propList.size();
    }

    @Override
    public Object getItem(int position) {
        return propList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (null == convertView) {
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.item_service_prop, parent, false);
            viewHolder.propName = (TextView) convertView.findViewById(R.id.propName);
            viewHolder.propValue = (TextView) convertView.findViewById(R.id.propValue);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        ServicePropDo servicePropDo = propList.get(position);
        if (servicePropDo.isRequired()) {
            viewHolder.propName.setText(StrUtil.getSpanText(servicePropDo.getName() + "<b>*</b>：",
                    mContext.getResources().getColor(R.color.brand_b),
                    mContext.getResources().getDimensionPixelSize(R.dimen.font_size)));
        } else {
            viewHolder.propName.setText(servicePropDo.getName() + "：");
        }
        viewHolder.propValue.setText(servicePropDo.getText());
        return convertView;
    }

    class ViewHolder {
        TextView propName;
        TextView propValue;
    }
}
