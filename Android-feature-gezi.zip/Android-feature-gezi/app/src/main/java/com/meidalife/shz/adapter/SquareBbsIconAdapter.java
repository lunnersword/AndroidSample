package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.meidalife.shz.R;

/**
 * Created by xingchen on 2015/12/20.
 */
public class SquareBbsIconAdapter extends BaseAdapter {
    private String[] icons;
    private LayoutInflater mInflater;
    private Context mContext;

    private int selectPos = 0;

    public SquareBbsIconAdapter(Context context, String[] icons) {
        this.mContext = context;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.icons = icons;
    }

    @Override
    public int getCount() {
        return icons.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_square_bbs_icon, parent, false);
            holder = new ViewHolder();
            holder.bbsIconView = (TextView) convertView.findViewById(R.id.bbsIconView);
            holder.iconBg = (LinearLayout) convertView.findViewById(R.id.iconBg);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        if (selectPos == position) {
            holder.iconBg.setBackgroundColor(mContext.getResources().getColor(R.color.brand_b));
            holder.bbsIconView.setTextColor(mContext.getResources().getColor(R.color.white));
        } else {
            holder.iconBg.setBackgroundColor(mContext.getResources().getColor(R.color.white));
            holder.bbsIconView.setTextColor(mContext.getResources().getColor(R.color.brand_b));
        }
        holder.bbsIconView.setText(icons[position]);

        return convertView;
    }

    static class ViewHolder {
        LinearLayout iconBg;
        TextView bbsIconView;
    }

    public int getSelectPos() {
        return selectPos;
    }

    public void setSelectPos(int selectPos) {
        this.selectPos = selectPos;
    }
}
