package com.meidalife.shz.dexposed.query;


import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.meidalife.shz.Helper;
import com.meidalife.shz.dexposed.patch.PatchMain;
import com.meidalife.shz.dexposed.patch.PatchResult;
import com.meidalife.shz.util.DexposedUtils;
import com.taobao.android.dexposed.DexposedBridge;

import java.io.File;

/**
 * HotpatchManager,do the follows：
 * 1.Get Patch infomation.(md5 and downlaod url of patch apk)
 * 2.Patch apk validate(md5 check and compare the signa
 * 3.load Patch包。
 * Created by renxuan on 15/7/29.
 * <p/>
 * Email:fengcunhan@126.com
 */
public class HotPatchManager {
    private static HotPatchManager INSTANCE = new HotPatchManager();

//    public void setFileDownloader(DownLoadManager.DownloadFile fileDownloader) {
//        DownLoadManager.getInstance().setDownloadFile(fileDownloader);
//    }

    private HotPatchManager() {
    }

    public static HotPatchManager getInstance(IPatchInfoRequest request) {
        RequestManager.getInstance().setIPatchInfoRequest(request);
        return INSTANCE;
    }

    public boolean startHotPatch(final Context ctx) {
        boolean isSupport = DexposedBridge.canDexposed(ctx);
        if (isSupport) {
            check(ctx);
//            testLoadPatch(ctx);
        }
        return isSupport;
    }

    private void check(final Context ctx) {
        RequestManager manager = RequestManager.getInstance();
        manager.request(new OnRequestCallBackListener() {
            @Override
            public void onRequest(final PatchInfo info) {
                if (null != info) {
                    //如果是beta版本 用户在灰度名单之外 不需要打补丁
                    String userId = Helper.sharedHelper().getUserId();
                    if ("1".equals(info.isBeta) && info.getUsers().contains(userId)) {
                        return;
                    }

                    if (TextUtils.isEmpty(info.patchURL) || TextUtils.isEmpty(info.sign)) {
                        return;
                    }

                    String apkPath = DexposedUtils.getCacheApkFilePath(ctx, info.getPatchURL());
//                    String apkPath = "android.resource://" + ctx.getPackageName() + File.separator + "app-debug.apk";

                    File file = new File(apkPath);
                    if (file.exists()) {
                        file.delete();
                    }

                    DownLoadManager.DownloadFile downloadFile = DownLoadManager.getInstance().getDownloadFile();
                    if (null == downloadFile) {
                        downloadFile = new DefaultFileDownload();
                        DownLoadManager.getInstance().setDownloadFile(downloadFile);
                    }
                    downloadFile.download(ctx, info.getPatchURL(), new DownLoadManager.OnFileDownload() {
                        @Override
                        public void fileDownload(String apkFilePath) {
                            loadPath(info, ctx, apkFilePath);
                        }
                    });
                }
            }
        });
    }

    private void loadPath(PatchInfo info, Context ctx, String apkFilePath) {
        if (DexposedUtils.isSignEqual(ctx, apkFilePath) && TextUtils.equals(info.getSign(), DexposedUtils.getMd5ByFile(new File(apkFilePath)))) {
//        if (TextUtils.equals(info.getSign(), DexposedUtils.getMd5ByFile(new File(apkFilePath)))) {
            PatchResult result = PatchMain.load(ctx, apkFilePath, null);
            if (result.isSuccess()) {
                Log.e("Hotpatch", "patch success!");
            } else {
                Log.e("Hotpatch", "patch error is " + result.getErrorInfo());
            }
        }
    }

//    void testLoadPatch(Context ctx){
//        File cacheDir = ctx.getExternalCacheDir();
//        if(cacheDir != null){
//            String fullpath = cacheDir.getAbsolutePath() + File.separator + "patch.apk";
//            PatchResult result = PatchMain.load(ctx, fullpath, null);
//            if (result.isSuccess()) {
//                Log.e("Hotpatch", "patch success!");
//            } else {
//                Log.e("Hotpatch", "patch error is " + result.getErrorInfo());
//            }
//        }
//    }

}

