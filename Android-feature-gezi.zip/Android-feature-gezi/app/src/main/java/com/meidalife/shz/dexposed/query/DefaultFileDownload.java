package com.meidalife.shz.dexposed.query;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;

import com.meidalife.shz.util.DexposedUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

/**
 *
 */
public class DefaultFileDownload implements DownLoadManager.DownloadFile {
    @Override
    public void download(Context ctx, String fileUrl, DownLoadManager.OnFileDownload download) {
        DownloadTask task = new DownloadTask(fileUrl, ctx, download);

        if (Build.VERSION.SDK_INT > 11) {
            task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "");
        } else {
            task.execute();
        }
    }

    public final class DownloadTask extends AsyncTask<String, Integer, String> {
        private String fileUrl;
        private Context ctx;
        private DownLoadManager.OnFileDownload download;

        public DownloadTask(String fileUrl, Context context, DownLoadManager.OnFileDownload download) {
            this.fileUrl = fileUrl;
            ctx = context;
            this.download = download;
        }

        @Override
        protected String doInBackground(String... params) {
            return oldDownload(ctx, fileUrl);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (null != download) {
                download.fileDownload(s);
            }
        }
    }


    String oldDownload(Context ctx, String fileUrl) {
        InputStream inStream = null;
        FileOutputStream fs = null;
        String filePath = DexposedUtils.getCacheApkFilePath(ctx, fileUrl);
        try {
            URL url = new URL(fileUrl);
            URLConnection urlConnection = url.openConnection();
            inStream = urlConnection.getInputStream();
            File file = new File(filePath);
            if (!file.exists()) {
                file.createNewFile();
            }
            fs = new FileOutputStream(file);
            int byteread = 0;
            byte[] buffer = new byte[1024];
            while ((byteread = inStream.read(buffer)) != -1) {
                fs.write(buffer, 0, byteread);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (null != inStream) {
                try {
                    inStream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (null != fs) {
                try {
                    fs.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        return filePath;
    }

}
