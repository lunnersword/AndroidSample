package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

/**
 * Created by shijian on 15/7/20.
 */
public class ZmAuthActivity extends BaseActivity {

    public static final int ZM_AUTH_CLOSE = 1000;

    private EditText realName;
    private EditText idCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.zm_auth);
        initActionBar(R.string.title_zm_auth, true);

        realName = (EditText) findViewById(R.id.zm_real_name);
        idCard = (EditText) findViewById(R.id.zm_id_card);
        setFocus(realName);

        Button commit = (Button) findViewById(R.id.zm_commit);
        commit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String realNameV = realName.getText().toString();
                String idCardV = idCard.getText().toString();

                if (StrUtil.isEmpty(realNameV)) {
                    MessageUtils.showToastCenter("请填写姓名");
                    setFocus(realName);
                    return;
                }
                if (StrUtil.isEmpty(idCardV)) {
                    MessageUtils.showToastCenter("请填写身份证");
                    setFocus(idCard);
                    return;
                }

                JSONObject params = new JSONObject();
                params.put("realName", realNameV);
                params.put("idCard", idCardV);
                HttpClient.get("1.0/user/authAccount", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject json) {
                        setResult(ZM_AUTH_CLOSE);
                        finish();
                        boolean autorized = json.getBoolean("autorized");
                        if (autorized) {
                            MessageUtils.showToastCenter("芝麻信用授权已成功");
                        } else {
                            Bundle bundle = new Bundle();
                            bundle.putString("url", json.getString("url"));
                            Router.sharedRouter().open("web", bundle);
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter(error.toString());
                    }
                });
            }
        });
    }


    public void setFocus(EditText v) {
        v.setFocusable(true);
        v.requestFocus();
    }

}
