package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 16/3/3.
 * 我加入的格子list对应adapter
 */
public class ServicePhotoAdapter extends RecyclerView.Adapter<ServicePhotoAdapter.PhotoViewHolder> {
    LayoutInflater mInflater;
    Context mContext;
    List<String> mData;

    OnClickListener onClickListener;

    public void setOnClickListener(OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public interface OnClickListener {
        public void onClick();
    }


    static class PhotoViewHolder extends RecyclerView.ViewHolder {
        public PhotoViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.photo)
        SimpleDraweeView photo;

    }

    public ServicePhotoAdapter(Context context, List<String> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mContext = context;
        mData = data;
    }

    @Override
    public PhotoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = mInflater.inflate(R.layout.item_service_photo, parent, false);
        return new PhotoViewHolder(convertView);
    }

    @Override
    public void onBindViewHolder(PhotoViewHolder holder, int position) {
        holder.photo.setImageURI(Uri.parse(ImgUtil.getCDNUrlWithHeight(mData.get(position), holder.photo.getLayoutParams().height)));
        holder.photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onClickListener != null) {
                    onClickListener.onClick();
                }
            }
        });
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }


}
