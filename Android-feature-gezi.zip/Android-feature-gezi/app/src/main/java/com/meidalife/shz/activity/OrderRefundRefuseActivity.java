package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.laiwang.protocol.util.StringUtils;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by shijian on 15/8/24.
 */
public class OrderRefundRefuseActivity extends BaseActivity {

    private LayoutInflater inflater;
    private Context context;

    private ViewGroup rootView;
    private View contentRoot;
    private LoadUtilV2 loadUtilV2;

    private ListView reasonList;
    private GridView selectImagesGrid;
    private EditText mRefuseCommentET;
    private String orderNo;
    private String id;

    private String reason;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_refund_refuse);
        initActionBar(R.string.title_refund_refuse, true);

        inflater = getLayoutInflater();
        context = getApplicationContext();

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);
        loadUtilV2 = new LoadUtilV2(inflater);

        Bundle extras = getIntent().getExtras();
        orderNo = extras.getString("orderNo");
        id = extras.getString("id");

        reasonList = (ListView) findViewById(R.id.refund_reason_list);
        selectImagesGrid = (GridView) findViewById(R.id.selectImages);

        mRefuseCommentET = (EditText) findViewById(R.id.refund_comment);

        reasonList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView selectReason = (TextView) view.findViewById(R.id.refund_reason);
                reason = selectReason.getText().toString();
            }
        });

        View refundCommit = findViewById(R.id.refund_commit);
        refundCommit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (uploading) {
                    MessageUtils.showToastCenter("图片正在上传中，请稍等");
                    return;
                }
                if (reason == null) {
                    MessageUtils.showToastCenter("请选择退款原因");
                    return;
                }

                String otherState = mRefuseCommentET.getText() == null ? null : mRefuseCommentET.getText().toString().trim();
                if (StringUtils.isEmpty(otherState)) {
                    MessageUtils.showToastCenter("补充说明不能为空");
                    return;
                }

                JSONObject params = new JSONObject();
                params.put("id", id);
                params.put("act", 1);
                params.put("reason", reason);

                params.put("comment", otherState);
                params.put("pic", uploadedImgs.values());

                HttpClient.get("1.0/refund/updateBySeller", params, null, new HttpClient.HttpCallback<Object>() {
                    @Override
                    public void onSuccess(Object obj) {
                        Router.sharedRouter().open("orders/" + orderNo);
                        finish();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter("拒绝退款失败, " + error.toString());
                    }
                });
            }
        });

        initLoadData();
    }

    public void initLoadData() {
        loadUtilV2.loadPre(rootView, contentRoot);
        JSONObject params = new JSONObject();
        params.put("orderNo", orderNo);
        HttpClient.get("1.0/refund/initRefund", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject datas) {
                loadUtilV2.loadSuccess(contentRoot);
                Double payNum = datas.getDouble("payNum");
                TextView payNumView = (TextView) findViewById(R.id.pay_num);
                payNumView.setText(StrUtil.doubleFormat(payNum / 100) + "元");
                JSONArray reasonJson = datas.getJSONArray("reasonList");
                String[] reasonArray = new String[reasonJson.size()];
                reasonArray = reasonJson.toArray(reasonArray);
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(context, R.layout.activity_order_refund_reason_item, R.id.refund_reason, reasonArray);
                reasonList.setAdapter(adapter);
                initSelectImagesGrid();
            }

            @Override
            public void onFail(HttpError error) {
                loadUtilV2.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        initLoadData();
                    }
                });
            }
        });
    }


    /*
    =========== 处理图片 ============
     */

    private ArrayList<String> selectedImgs = new ArrayList<>();
    private int MAX_IMAGE_LENGTH = 3;
    private PublishGridAdapter adapter;
    private boolean uploading = false;
    private Map<String, String> uploadedImgs = new HashMap();

    private void initSelectImagesGrid() {
        adapter = new PublishGridAdapter(this, selectedImgs, MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_OTHER);
        selectImagesGrid.setAdapter(adapter);
        adapter.setOnClickPlusListener(new PublishGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                if (uploading) {
                    Toast.makeText(OrderRefundRefuseActivity.this, "图片正在上传中，请稍等", Toast.LENGTH_LONG).show();
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putBoolean("isCheckbox", true);
                bundle.putInt("maxLength", MAX_IMAGE_LENGTH - selectedImgs.size());
                Router.sharedRouter().openFormResult("pick/photo", bundle,
                        Constant.REQUEST_CODE_PICK_PHOTO, OrderRefundRefuseActivity.this);
            }
        });
        adapter.setOnClickRemoveListener(new PublishGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                if (position < selectedImgs.size()) {
                    selectedImgs.remove(position);
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constant.REQUEST_CODE_PICK_PHOTO && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            List<String> paths = bundle.getStringArrayList("images");
            for (int i = 0; i < paths.size(); i++) {
                String img = paths.get(i);
                if (selectedImgs.contains(img)) {
                    continue;
                } else {
                    selectedImgs.add(img);  // 如果图片列表中没有当前选中的照片，则添加到图片列表中
                }
            }
            adapter.notifyDataSetChanged();
            uploadImages();
        }
    }

    private void uploadImages() {
        final ArrayList<String> needUploadList = new ArrayList();
        for (int i = 0; i < selectedImgs.size(); i++) {
            String img = selectedImgs.get(i);
            if (!uploadedImgs.containsKey(img)) {
                needUploadList.add(img);  //如果图片列表中没有当前选中的照片，则添加到需上传图片列表中
            }
        }
        if (needUploadList.size() > 0) {
            showProgressDialog("图片上传中...");
            uploading = true;
            xhrUpdateImages(needUploadList, 0);
        }
    }

    private void xhrUpdateImages(final ArrayList needUploadList, final int index) {
        if (needUploadList.size() > 0) {
            final String path = (String) needUploadList.get(index);
            RequestSign.upload(path, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    org.json.JSONObject json = (org.json.JSONObject) result;
                    try {
                        uploadedImgs.put(path, json.getString("data"));
                        if (index == needUploadList.size() - 1) {
                            hideProgressDialog();
                            uploading = false;
                            //Toast.makeText(context, "图片上传成功...", Toast.LENGTH_SHORT).show();
                        } else {
                            xhrUpdateImages(needUploadList, index + 1);
                        }
                    } catch (JSONException e) {
                        uploading = false;
                        hideProgressDialog();
                        failTip();
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    uploading = false;
                    hideProgressDialog();
                    failTip();
                }
            });
        }
    }

    private void failTip() {
        MessageUtils.showToastCenter("图片上传过程中有错误，请重新选择");
        selectedImgs.clear();
        selectedImgs.addAll(uploadedImgs.keySet());
        adapter.notifyDataSetChanged();
    }

}
