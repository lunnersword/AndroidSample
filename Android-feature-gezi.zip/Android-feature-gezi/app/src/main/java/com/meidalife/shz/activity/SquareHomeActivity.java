package com.meidalife.shz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.SquareAskFragment;
import com.meidalife.shz.activity.fragment.SquareBbsFragment;
import com.meidalife.shz.activity.fragment.SquareMiscFragment;
import com.meidalife.shz.activity.fragment.SquareNearByFragment;
import com.meidalife.shz.activity.fragment.SquareServiceFragment;
import com.meidalife.shz.adapter.AdViewPagerAdapter;
import com.meidalife.shz.adapter.FragmentTabAdapter;
import com.meidalife.shz.adapter.SquareUserAvatarAdapter;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.SquarePortalRefreshEvent;
import com.meidalife.shz.event.SquareRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquarePublishDO;
import com.meidalife.shz.rest.model.UserItem;
import com.meidalife.shz.rest.request.RequestSquareAsk;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.widget.DragTopLayout;
import com.meidalife.shz.widget.SlidingTabLayout;
import com.meidalife.shz.widget.TutorialPopupWindow;
import com.usepropeller.routable.Router;
import com.viewpagerindicator.CirclePageIndicator;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by fufeng on 15/12/21.
 */
public class SquareHomeActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener, ViewPager.OnPageChangeListener {
    private static int PUBLISH_REQUEST_CODE = 88;

    private boolean isLoading = false;
    private String squareId;
    private String squareNameString;
    private String tab;
    private String kgStationLatitude;
    private String kgStationLongitude;
    private boolean isGezhu = false;
    public boolean isJoined = false;
    public boolean isJoinHintShowed = false;

    private List<UserItem> squareUserItemList = new ArrayList<>();

    @Bind(R.id.squareButtonLayout)
    ViewGroup squareButtonLayout;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.joinSquareButton)
    TextView joinSquareButton;
    @Bind(R.id.joinIcon)
    TextView joinIcon;
    @Bind(R.id.headerLayout)
    ViewGroup headerLayout;
    @Bind(R.id.squareHeaderBg)
    SimpleDraweeView squareHeaderBg;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.stageContentLayout)
    ViewGroup stageContentLayout;
    @Bind(R.id.dragLayout)
    DragTopLayout dragTopLayout;
    @Bind(R.id.squareIcon)
    SimpleDraweeView squareIcon;
    @Bind(R.id.squareName)
    TextView squareName;
    @Bind(R.id.squareType)
    TextView squareType;
    @Bind(R.id.userList)
    RecyclerView userList;
    @Bind(R.id.userCount)
    TextView userCount;

    @Bind(R.id.adBannerLayout)
    ViewGroup adBannerLayout;
    @Bind(R.id.adBannerViewPager)
    ViewPager adBannerViewPager;
    @Bind(R.id.adBannerIndicator)
    CirclePageIndicator circlePageIndicator;

    @Bind(R.id.circularContent)
    TextView circularContent;
    @Bind(R.id.stageContent)
    TextView stageContent;
    @Bind(R.id.locationIcon)
    TextView locationIcon;

    @Bind(R.id.publishIcon)
    TextView publishIcon;
    @Bind(R.id.publishText)
    TextView publishText;
    @Bind(R.id.publishLayout)
    View publishLayout;

    @Bind(R.id.searchSlidingTab)
    SlidingTabLayout squareSlidingTab;
    @Bind(R.id.squareTabViewPager)
    ViewPager squareTabViewPager;

    private SquareUserAvatarAdapter squareUserAvatarAdapter;
    private FragmentTabAdapter squarePagerAdapter;
    private LoadUtilV2 loadUtilV2;
    private TutorialPopupWindow tutorialPopupWindow;
    private AdViewPagerAdapter adViewPagerAdapter;
    private boolean displayAddBadge = true;

    public Map<Integer, SquarePublishDO> publishMap = new LinkedHashMap<Integer, SquarePublishDO>();
    SquarePublishDO current = new SquarePublishDO();
//    private SquarePopWindowAdapter popWindowAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_home);
        ButterKnife.bind(this);
        initActionBar("格子", true, false);
        initComponents();
    }

    @Override
    public void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
        getSquareHeader(true);
//        LogUtil.log(LogUtil.TYPE_START_PAGE, this.getClass().getName());
        try {
            LogParam param = new LogParam();
            param.setType(LogUtil.TYPE_START_PAGE);
            param.setGeziid(squareId);
            //todo 需要回传pvid
            LogUtil.log(param);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
        LogUtil.log(LogUtil.TYPE_EXIT_PAGE, this.getClass().getName());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == Constant.REQUEST_CODE_JOIN_SQUARE) {
                isJoined = true;
                showHintPopupWindow();

                //加入格子成功 请求刷新事件
                EventBus.getDefault().post(new SquarePortalRefreshEvent());
            } else if (requestCode == Constant.REQUEST_CODE_SIGNIN) {
                onRefresh();
            } else if (requestCode == PUBLISH_REQUEST_CODE) {
                EventBus.getDefault().post(new SquarePortalRefreshEvent());
                onRefresh();
            }
        }

        Fragment f = squarePagerAdapter.getItem(squareTabViewPager.getCurrentItem());
        /*在碎片中调用重写的onActivityResult方法*/
        if (f != null) {
            f.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void onEvent(BaseEvent event) {
        if (event.eventType == MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE ||
                event.eventType == MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE) {
            if (event.eventType == MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE) {
                mSwipeRefreshLayout.setEnabled(dragTopLayout.getState() == DragTopLayout.PanelState.EXPANDED);
            }
            dragTopLayout.setTouchMode(event.eventType == MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE);
        }
        if (event.eventType == MsgTypeEnum.TYPE_HIDE_SERVICE_PUBLISH) {
            displayAddBadge = false;
            if (squareTabViewPager.getCurrentItem() == 0)
                publishLayout.setVisibility(View.GONE);
        }
        if (event.eventType == MsgTypeEnum.TYPE_SHOW_SERVICE_PUBLISH) {
            displayAddBadge = true;
            if (squareTabViewPager.getCurrentItem() == 0)
                publishLayout.setVisibility(View.VISIBLE);
        }
    }


    private void initComponents() {
        loadUtilV2 = new LoadUtilV2(LayoutInflater.from(this));
        squareId = getIntent().getStringExtra("id");
        tab = getIntent().getStringExtra("tab");

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        userList.setLayoutManager(linearLayoutManager);
        squareUserAvatarAdapter = new SquareUserAvatarAdapter(this, squareUserItemList);
        userList.setAdapter(squareUserAvatarAdapter);

        squarePagerAdapter = new FragmentTabAdapter(getSupportFragmentManager());

        mSwipeRefreshLayout.setOnRefreshListener(this);

        dragTopLayout.listener(new DragTopLayout.PanelListener() {
            @Override
            public void onPanelStateChanged(DragTopLayout.PanelState panelState) {
                if (panelState == DragTopLayout.PanelState.EXPANDED) {
                    mSwipeRefreshLayout.setEnabled(true);
                } else if (panelState == DragTopLayout.PanelState.COLLAPSED) {
                    mSwipeRefreshLayout.setEnabled(false);
                }
            }

            @Override
            public void onSliding(float ratio) {

            }

            @Override
            public void onRefresh() {

            }
        });
        squareSlidingTab.setOnPageChangeListener(this);
    }

    private void getSquareHeader(boolean showLoading) {
        if (isLoading) {
            return;
        }
        if (showLoading) {
            loadUtilV2.loadPre(rootLayout, mSwipeRefreshLayout);
        }

        isLoading = true;
        JSONObject params = new JSONObject();
        params.put("geziId", squareId);
        HttpClient.get("1.0/gezi/header", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        isLoading = false;
                        loadUtilV2.loadSuccess(mSwipeRefreshLayout);
                        mSwipeRefreshLayout.setRefreshing(false);
                        if (obj.containsKey("isGezhu")) {
                            isGezhu = obj.getBoolean("isGezhu");
                        }
                        loadBanner(obj.getJSONArray("activityBanner"));

                        if (obj.getJSONObject("gezi") != null) {
                            loadHeader(obj.getJSONObject("gezi"));
                            loadUserList(obj.getJSONObject("gezi"));
                            loadTabs(obj.getJSONObject("gezi").getJSONArray("tabs"));
                        }
                        showJoinHint();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        isLoading = false;
                        mSwipeRefreshLayout.setRefreshing(false);
                        loadUtilV2.loadFail(error, rootLayout, new LoadUtilV2.RetryCallback() {
                            @Override
                            public void retry() {
                                getSquareHeader(true);
                            }
                        });
                    }
                });
    }

    private void showJoinHint() {
        if (!isJoined && !isJoinHintShowed) {
            isJoinHintShowed = true;
            MessageUtils.createDialog(this, "加入格子", String.format("加入%s，身边服务触手可得。", squareNameString),
                    R.string.join_square_now,
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            preJoin();
                        }
                    }, R.string.join_square_cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).show();
        }
    }

    private void loadBanner(JSONArray activityBanner) {
        if (activityBanner == null || activityBanner.isEmpty()) {
            adBannerLayout.setVisibility(View.GONE);
            return;
        }
        List<AdViewPagerAdapter.AdItem> adItemList = new ArrayList<>();
        for (int i = 0; i < activityBanner.size(); i++) {
            JSONObject banner = activityBanner.getJSONObject(i);
            AdViewPagerAdapter.AdItem adItem = new AdViewPagerAdapter.AdItem();
            adItem.imageUrl = banner.getString("picUrl");
            adItem.linkUrl = banner.getString("linkUrl");
            adItemList.add(adItem);
            adItemList.add(adItem);
            adItemList.add(adItem);
        }
        adViewPagerAdapter = new AdViewPagerAdapter(this, adItemList);
        adBannerViewPager.setAdapter(adViewPagerAdapter);
        circlePageIndicator.setViewPager(adBannerViewPager);
        circlePageIndicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {
                mSwipeRefreshLayout.setEnabled(state == ViewPager.SCROLL_STATE_IDLE
                        && dragTopLayout.getState() == DragTopLayout.PanelState.EXPANDED);
            }
        });
        adBannerLayout.setVisibility(View.VISIBLE);
    }

    private void loadHeader(JSONObject obj) {
        if (obj.containsKey("joined")) {
            isJoined = obj.getBoolean("joined");
        }

        if (obj.containsKey("geziTypeDesc")) {
            squareType.setText("[" + obj.getString("geziTypeDesc") + "]");
            squareType.setVisibility(View.VISIBLE);
        } else {
            squareType.setVisibility(View.GONE);
        }
        squareNameString = obj.getString("geziName");
        squareName.setText(squareNameString);

        if (!TextUtils.isEmpty(obj.getString("geziPicUrl"))) {
            String cdnUrl = ImgUtil.getCDNUrlWithHeight(obj.getString("geziPicUrl"),
                    getResources().getDimensionPixelSize(R.dimen.square_icon_size));
            squareIcon.setImageURI(Uri.parse(cdnUrl));
            squareHeaderBg.setImageURI(Uri.parse(obj.getString("geziPicUrl")));
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            squareHeaderBg.setImageAlpha(25);
        } else {
            squareHeaderBg.setAlpha(0.1f);
        }

        userCount.setText(String.format(getString(R.string.square_user_count),
                obj.getString("userCount")));
        userCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open("signin");
                    return;
                } else if (!isJoined) {
                    MessageUtils.showDialog(SquareHomeActivity.this, "提示", "加入格子后才能查看格子成员哦~", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            preJoin();
                        }
                    }, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    return;
                }
                Bundle params = new Bundle();
                params.putString("squareId", squareId);
                params.putBoolean("isOwner", isGezhu);
                Router.sharedRouter().open("squareUserList", params);
            }
        });

        if (!TextUtils.isEmpty(obj.getString("notice"))) {
            circularContent.setText("公告：" + obj.getString("notice"));
        } else {
            circularContent.setText(getString(R.string.default_square_circular));
        }

        if (obj.containsKey("kgStationAddress")) {
            stageContent.setText("空格驿站：" + obj.getString("kgStationAddress"));
            stageContentLayout.setVisibility(View.VISIBLE);
        } else {
            stageContentLayout.setVisibility(View.GONE);
        }

        kgStationLatitude = obj.getString("kgStationLatitude");
        kgStationLongitude = obj.getString("kgStationLongitude");

        if (!TextUtils.isEmpty(kgStationLongitude) && !TextUtils.isEmpty(kgStationLatitude)) {
            locationIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    try {
                        bundle.putDouble(ViewLocationActivity.LOCATION_LNG, Double.parseDouble(kgStationLongitude));
                        bundle.putDouble(ViewLocationActivity.LOCATION_LAT, Double.parseDouble(kgStationLatitude));
                        Router.sharedRouter().open("viewPosition", bundle);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
        if (isGezhu) {
            squareButtonLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("squaremanage/index/" + squareId);
                }
            });
            joinSquareButton.setText("管理中心");
            joinIcon.setVisibility(View.GONE);
            squareButtonLayout.setVisibility(View.VISIBLE);
        } else if (!isJoined) {
            squareButtonLayout.setVisibility(View.VISIBLE);
            squareButtonLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    preJoin();
                }
            });
            joinSquareButton.setText("加入");
            joinIcon.setVisibility(View.VISIBLE);
        } else {
            squareButtonLayout.setVisibility(View.GONE);
        }
    }

    private void loadUserList(JSONObject obj) {
        JSONArray userArray = obj.getJSONArray("userList");
        squareUserItemList.clear();
        if (null != userArray && !userArray.isEmpty()) {
            for (int i = 0; i < userArray.size(); i++) {
                // 只显示前8个，后面的不显示
                if (i > 7) {
                    break;
                }
                JSONObject userObj = userArray.getJSONObject(i);
                UserItem item = new UserItem();
                item.setUserId(userObj.getString("userId"));
                item.setUserName(userObj.getString("userNick"));
                item.setUserAvatar(userObj.getString("userPicUrl"));
                item.setUserDesc(userObj.getString("userInstruction"));
                item.setUserGender(userObj.getString("userGender"));

                squareUserItemList.add(item);
            }
        }

        if (!squareUserItemList.isEmpty()) {
            squareUserAvatarAdapter.setData(squareUserItemList);
            squareUserAvatarAdapter.notifyDataSetChanged();
        }
    }

    private void loadTabs(JSONArray tabs) {
        if (null == tabs || tabs.isEmpty() || tabs.size() == squarePagerAdapter.getCount()) {
            return;
        }

        for (int i = 0; i < tabs.size(); i++) {
            JSONObject tabData = tabs.getJSONObject(i);
            Bundle params = new Bundle();
            params.putString("title", tabData.getString("desc"));

            try {
                params.putInt("geziId", Integer.parseInt(squareId));
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            switch (tabData.getInteger("type")) {
                case Constant.SQUARE_TAB_MISC: {
                    params.putBoolean("isJoined", isJoined);
                    params.putBoolean("isGezhu", isGezhu);
                    squarePagerAdapter.addFragment(SquareMiscFragment.newInstance(params));

                    publishMap.put(0, new SquarePublishDO(Constant.SQUARE_TAB_MISC, R.string.icon_square_publish_service,
                            R.string.title_activity_service_publish,
                            R.string.square_service_add_warn,
                            R.string.square_service_login_warn));
                    break;
                }
                case Constant.SQUARE_TAB_SERVICE: {
                    params.putBoolean("isJoined", isJoined);
                    params.putBoolean("isGezhu", isGezhu);
                    squarePagerAdapter.addFragment(SquareServiceFragment.newInstance(params));

                    publishMap.put(0, new SquarePublishDO(Constant.SQUARE_TAB_SERVICE, R.string.icon_square_publish_service,
                            R.string.title_activity_service_publish,
                            R.string.square_service_add_warn,
                            R.string.square_service_login_warn));
                    break;
                }
                case Constant.SQUARE_TAB_ASK: {
                    params.putBoolean("isJoined", isJoined);
                    params.putBoolean("isGezhu", isGezhu);
                    squarePagerAdapter.addFragment(SquareAskFragment.newInstance(params));

                    publishMap.put(1, new SquarePublishDO(Constant.SQUARE_TAB_ASK, R.string.icon_question,
                            R.string.title_activity_publish_demand,
                            R.string.square_ask_publish_join_gezi_message,
                            R.string.square_ask_login_warn
                    ));

                    break;
                }
                case Constant.SQUARE_TAB_BBS: {
                    params.putBoolean("isJoined", isJoined);
                    params.putBoolean("isGezhu", isGezhu);
                    squarePagerAdapter.addFragment(SquareBbsFragment.newInstance(params));

                    publishMap.put(2, new SquarePublishDO(Constant.SQUARE_TAB_BBS, R.string.icon_square_publish_bbs,
                            R.string.bbs_publish,
                            R.string.square_bbs_add_warn,
                            R.string.square_bbs_login_warn
                    ));
                    break;
                }

                case Constant.SQUARE_TAB_NEARBY: {
                    params.putBoolean("isGezhu", isGezhu);
                    squarePagerAdapter.addFragment(SquareNearByFragment.newInstance(params));

                    publishMap.put(3, new SquarePublishDO(Constant.SQUARE_TAB_NEARBY, R.string.icon_gezi_address,
                            R.string.square_nearby_publish, 0, 0));
                    break;
                }
            }
        }

        squareSlidingTab.setCustomTabView(R.layout.item_category, R.id.categoryName);
        squareTabViewPager.setAdapter(squarePagerAdapter);
        squareSlidingTab.setViewPager(squareTabViewPager);
        squareSlidingTab.setDividerColors(android.R.color.transparent);

        //默认在找找看
        current = publishMap.get(0);
        updatePublishView(current);
    }

    @Override
    public void onRefresh() {
        getSquareHeader(false);
        SquareRefreshEvent squareRefreshEvent = new SquareRefreshEvent();
        squareRefreshEvent.isGezhu = isGezhu;
        squareRefreshEvent.isJoined = isJoined;
        squareRefreshEvent.squareId = squareId;
        EventBus.getDefault().post(squareRefreshEvent);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        if (position == 1) {
            showAskTutorial();
        }

        current = publishMap.get(position);

        updatePublishView(current);

        //tab点击埋点
        LogParam param = new LogParam();
        param.setType(LogUtil.TYPE_CUSTOMIZE);
        param.setEid(LogUtil.EVENT_ID_SQUARE_HOME_TAB_CLICK);
        param.setCategoryId(String.valueOf(position + 1));
        LogUtil.log(param);
    }


    @Override
    public void onPageScrollStateChanged(int state) {
        mSwipeRefreshLayout.setEnabled(state == ViewPager.SCROLL_STATE_IDLE
                && dragTopLayout.getState() == DragTopLayout.PanelState.EXPANDED);
    }

    void updatePublishView(final SquarePublishDO current) {

        if (current == null)
            return;
        if (current.getType() == Constant.SQUARE_TAB_NEARBY) {
            if (isGezhu) {
                publishLayout.setVisibility(View.VISIBLE);
            } else {
                publishLayout.setVisibility(View.GONE);
            }
        } else if (current.getType() == Constant.SQUARE_TAB_MISC) {
            publishLayout.setVisibility(displayAddBadge ? View.VISIBLE : View.GONE);
        } else {
            publishLayout.setVisibility(View.VISIBLE);
        }

        publishIcon.setText(current.getIconPath());
        publishText.setText(current.getNamePath());

        publishLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    if (isJoined) {
                        startPublish(current.getType());
                    } else {
                        showJoinDialog(current.getType(), current.getJoinTip());
                    }
                } else {
                    showLoginDialog(current.getLoginTip());
                }
            }
        });
    }

    void showJoinDialog(final int type, int resId) {
        MessageUtils.showDialog(this, this.getResources().getString(R.string.square_warn),
                this.getResources().getString(resId), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        joinCurrentGeZi(type);
                    }
                }, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
    }

    void showLoginDialog(int resId) {
        MessageUtils.showDialog(this, this.getResources().getString(R.string.square_warn),
                this.getResources().getString(resId), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Router.sharedRouter().openFormResult("signin", Constant.REQUEST_CODE_SIGNIN, SquareHomeActivity.this);
                    }
                }, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
    }

    private void joinCurrentGeZi(final int type) {
        JSONObject params = new JSONObject();
        params.put("geziId", squareId);
        RequestSquareAsk.joinGezi(params, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                MessageUtils.showToast("你已成功加入该格子");
                isJoined = true;
                startPublish(type);

                //加入格子成功 请求刷新事件 fragment底部事件处理
                EventBus.getDefault().post(new SquarePortalRefreshEvent());
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToast(error != null ? error.getMessage() : "加入格子失败，请稍后再试");
            }
        });
    }

    void startPublish(int type) {
        if (type == Constant.SQUARE_TAB_SERVICE || type == Constant.SQUARE_TAB_MISC) {
            Router.sharedRouter().openFormResult("publish/", PUBLISH_REQUEST_CODE, SquareHomeActivity.this);
        } else if (type == Constant.SQUARE_TAB_ASK) {
            Router.sharedRouter().openFormResult("squareAskPublish/" + squareId, PUBLISH_REQUEST_CODE, SquareHomeActivity.this);
        } else if (type == Constant.SQUARE_TAB_BBS) {
            Router.sharedRouter().openFormResult("squareBbsPublish/" + squareId, PUBLISH_REQUEST_CODE, SquareHomeActivity.this);
        } else {
            Router.sharedRouter().openFormResult("squareNearByPublish/" + squareId, PUBLISH_REQUEST_CODE, SquareHomeActivity.this);
        }
    }


    private void showHintPopupWindow() {
        try {
            TutorialPopupWindow hintPopupWindow = new TutorialPopupWindow(this,
                    TutorialPopupWindow.TUTORIAL_TYPE_CUSTOMIZE);
            hintPopupWindow.addTutorialItems(new TutorialPopupWindow.TutorialItem(getString(R.string.tutorial_join_square_title),
                    null, squareNameString,
                    R.mipmap.tutorial_welcome, getString(R.string.i_know)));
            hintPopupWindow.setOnFinishListener(new TutorialPopupWindow.OnFinishListener() {
                @Override
                public void onFinish() {
                }
            });
            if (!isFinishing()) {
                hintPopupWindow.showTutorial(rootLayout);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAskTutorial() {
        try {
            if (Helper.sharedHelper().getBooleanUserInfo(Constant.SQUARE_HOME_FIRST_IN, true)) {
                if (tutorialPopupWindow == null) {
                    tutorialPopupWindow = new TutorialPopupWindow(this,
                            TutorialPopupWindow.TUTORIAL_TYPE_ASSISTANCE);

                    tutorialPopupWindow.setOnFinishListener(new TutorialPopupWindow.OnFinishListener() {
                        @Override
                        public void onFinish() {
                            Helper.sharedHelper().setBooleanUserInfo(Constant.SQUARE_HOME_FIRST_IN, false);
                        }
                    });
                }
                if (!tutorialPopupWindow.isShowing() && !(isFinishing())) {
                    tutorialPopupWindow.showTutorial(rootLayout);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void preJoin() {
        JSONObject params = new JSONObject();
        params.put("geziId", squareId);
        HttpClient.get("1.0/gezi/joinPage", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        if (obj != null) {
                            JSONArray itemList = obj.getJSONArray("itemList");
                            if (itemList == null || itemList.isEmpty()) {
                                joinSquare();
                                return;
                            } else {
                                Bundle params = new Bundle();
                                params.putString("squareId", squareId);
                                Router.sharedRouter().openFormResult("serviceJoinSquare", params,
                                        Constant.REQUEST_CODE_JOIN_SQUARE, SquareHomeActivity.this);
                            }
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(error.toString());
                    }
                });
    }

    private void joinSquare() {
        JSONObject params = new JSONObject();
        JSONArray array = new JSONArray();

        params.put("geziId", squareId);
        params.put("itemIdList", array);
        HttpClient.get("1.0/gezi/join", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        isJoined = true;
                        showHintPopupWindow();

                        onRefresh();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(error.toString());
                    }
                });
    }
}
