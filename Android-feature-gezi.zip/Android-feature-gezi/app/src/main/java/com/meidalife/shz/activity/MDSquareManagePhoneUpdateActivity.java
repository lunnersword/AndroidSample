package com.meidalife.shz.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by xingchen on 2015/12/23.
 */
public class MDSquareManagePhoneUpdateActivity extends BaseActivity{

    @Bind(R.id.nameText)
    EditText nameText;
    @Bind(R.id.phoneText)
    EditText phoneText;
    private int geziId = Integer.MAX_VALUE;
    private int id = Integer.MAX_VALUE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_manage_phone_update);

        ButterKnife.bind(this);
        initActionBar(R.string.phone, true, true);
        mButtonRight.setText(R.string.save);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatePhone();
            }
        });

        if(!TextUtils.isEmpty(getIntent().getStringExtra("geziId")))
            geziId = Integer.parseInt(getIntent().getStringExtra("geziId"));


        Bundle params = getIntent().getExtras();
        if(params != null){
            id = params.getInt("id", Integer.MAX_VALUE);
            if(params.getString("name")!=null){
                nameText.setText(params.getString("name"));
                nameText.setSelection(params.getString("name").length());
            }
            phoneText.setText(Helper.formatMobileNumber(params.getString("mobile")==null?"":params.getString("mobile")));
        }

        phoneText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String contents = Helper.formatMobileNumber(s.toString().trim());
                if (contents.length() != s.toString().length()) {
                    phoneText.setText(contents);
                    phoneText.setSelection(contents.length());
                }
            }
        });
    }

    private void updatePhone(){
        String name = nameText.getText().toString();
        String phone = phoneText.getText().toString();
        if(TextUtils.isEmpty(name)){
            MessageUtils.showToastCenter("还未填写电话名称哦");
            return;
        }
        if(TextUtils.isEmpty(phone)){
            MessageUtils.showToastCenter("还未填写电话号码哦");
            return;
        }
        if((phone.replace(" ","")).length() > 11){
            MessageUtils.showToastCenter("请输入正确的手机号码");
            return;
        }
        showProgressDialog("正在保存");
        JSONObject params = new JSONObject();
        params.put("geziId",geziId);
        params.put("name",name);
        params.put("mobile",phone.replace(" ",""));
        if(id != Integer.MAX_VALUE)
            params.put("id",id);
        HttpClient.get("1.0/gezi/yp/addMobile", params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideProgressDialog();
                setResult(RESULT_OK);
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败，请稍后再试");
            }
        });
    }
}
