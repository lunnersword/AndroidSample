package com.meidalife.shz.dexposed.query;


import android.content.Context;

/**
 * Patch apk download
 * Created by renxuan on 15/7/29.
 */
class DownLoadManager {
    private static DownLoadManager INSTANCE = new DownLoadManager();
    private DownloadFile mDownloadFile;

    private DownLoadManager() {
    }

    public static DownLoadManager getInstance() {
        return INSTANCE;
    }

    public interface OnFileDownload {
        void fileDownload(String apkFilePath);
    }

    public DownloadFile getDownloadFile() {
        return mDownloadFile;
    }

    public void setDownloadFile(DownloadFile downloadFile) {
        mDownloadFile = downloadFile;
    }

    public interface DownloadFile {
        public void download(Context txt, String fileUrl, OnFileDownload download);
    }

}
