package com.meidalife.shz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.activity.fragment.PublishCategoryFragment;
import com.meidalife.shz.activity.fragment.PublishContentFragment;
import com.meidalife.shz.activity.fragment.PublishMethodFragment;
import com.meidalife.shz.adapter.ServicePropRecycleAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.ServiceCategoryDo;
import com.meidalife.shz.rest.model.ServicePropDo;
import com.meidalife.shz.rest.model.ServiceRenderDo;
import com.meidalife.shz.rest.model.ServiceSkuPropDo;
import com.meidalife.shz.rest.model.SkuListDo;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.view.OnServicePublishListener;
import com.meidalife.shz.view.StepsView;
import com.usepropeller.routable.Router;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/3/2.
 */
public class ServicePublishActivity extends BaseActivity implements OnServicePublishListener {
    private static final String LOG_TAG = "ServicePublishActivity";
    private static final String steps[] = new String[]{"", "", ""};
    private static final String bottomLabels[] = new String[]{"服务类目", "服务内容", "服务方式"};
    private static final String stepIndicatorLabels[] = new String[]{"1、请选择您的服务类别", "2、请在这里填写服务内容哦", "3、请选择你的服务方式吧"};
    private boolean isUploading = false;
    private boolean isEditMode = false;
    private boolean isPublishing = false;
    private boolean isCategoryChanged = false;
    private String itemId;
    Map<String, String> uploadedImages = new HashMap<>();

    private int mStep = 0;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.stepIndicatorLabel)
    TextView stepIndicatorLabel;
    @Bind(R.id.stepsView)
    StepsView stepsView;
    @Bind(R.id.fragmentContainer)
    ViewGroup fragmentContainer;
    @Bind(R.id.publishHelp)
    TextView publishHelp;

    private PublishContentFragment publishContentFragment;
    private PublishMethodFragment publishMethodFragment;
    private ServiceCategoryDo serviceCategoryDo;
    private ServiceCategoryDo.SecondaryCategoryDo secondaryCategoryDo;
    private ServiceRenderDo serviceRenderDo;
    private LoadUtilV2 mLoadUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_publish);
        ButterKnife.bind(this);
        initActionBar(R.string.publish, true, true);

        initComponents();
    }

    private void initComponents() {
        mLoadUtil = new LoadUtilV2(LayoutInflater.from(this));
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doNextAction();
            }
        });
        mButtonRight.setText("下一步");
        itemId = getIntent().getStringExtra("id");
        if (!TextUtils.isEmpty(itemId)) {
            isEditMode = true;
            setActionBarTitle(R.string.title_activity_service_edit);
        }
        stepsView.setLabels(steps).setShowAllBottomLabel(true).
                setBottomLabels(bottomLabels).drawView();
        stepsView.setCompletedPosition(mStep);

        if (!isEditMode) {
            showCategoryFragment();
        } else {
            getExistContent();
        }
        publishHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", Constant.KONGGE_BASE_URL + "support/publish_guide.html");
                Router.sharedRouter().open("web", bundle);
            }
        });
    }


    @Override
    public void onBackPressed() {
        mStep--;
        if (mStep >= 0) {
            stepsView.setCompletedPosition(mStep).drawView();
            stepIndicatorLabel.setText(stepIndicatorLabels[mStep]);
            mButtonRight.setText("下一步");
            if (mStep == 1) {
                showServiceContentFragment();
                return;
            } else if (mStep == 0 && !isEditMode) {
                showCategoryFragment();
                return;
            }
        }

        super.onBackPressed();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == Constant.REQUEST_CODE_PICK_PHOTO
                && publishContentFragment != null) {
            publishContentFragment.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onServiceCategorySelected(final ServiceCategoryDo categoryDo,
                                          final ServiceCategoryDo.SecondaryCategoryDo sCategoryDo) {
        if (secondaryCategoryDo != null && !secondaryCategoryDo.getCatId().equals(sCategoryDo.getCatId())) {
            MessageUtils.showDialog(this, "确认更改类目吗？", "更改类目后部分内容将需要重新填写。",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            serviceCategoryDo = categoryDo;
                            secondaryCategoryDo = sCategoryDo;
                            if (null != publishContentFragment) {
                                publishContentFragment.getServiceProps().clear();
                            }
                            doNextAction();
                        }
                    }, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
        } else if (serviceRenderDo != null && serviceRenderDo.getStdCat() != null &&
                !TextUtils.isEmpty(serviceRenderDo.getStdCat().getString("stdCatId")) &&
                !serviceRenderDo.getStdCat().getString("stdCatId").equals(sCategoryDo.getCatId())) {
            MessageUtils.showDialog(this, "确认更改类目吗？", "更改类目后部分内容将需要重新填写。",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            serviceCategoryDo = categoryDo;
                            secondaryCategoryDo = sCategoryDo;
                            isCategoryChanged = true;
                            if (null != publishContentFragment) {
                                publishContentFragment.getServiceProps().clear();
                            }
                            doNextAction();
                        }
                    }, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
        } else {
            serviceCategoryDo = categoryDo;
            secondaryCategoryDo = sCategoryDo;
            doNextAction();
        }
    }

    @Override
    public void backToCategorySetting() {
        if (isEditMode) {
            showCategoryFragment();
        } else {
            onBackPressed();
        }
    }

    @Override
    public void onServiceCategoryUpdated(ServiceCategoryDo categoryDo, ServiceCategoryDo.SecondaryCategoryDo secondaryCategoryDo) {
        serviceCategoryDo = categoryDo;
        this.secondaryCategoryDo = secondaryCategoryDo;
    }

    @Override
    public void onServiceImageSelected() {
        uploadImages();
    }

    @Override
    public void onServiceMethodSelect() {

    }

    private void doNextAction() {
        if (!checkPublishCondition()) {
            return;
        }
        switch (mStep) {
            case 0: {
                mStep++;
                getServiceContent();
                break;
            }
            case 1: {
                mStep++;
                showServiceMethodFragment();
                break;
            }
            case 2: {
                publishService();
            }
        }
    }

    private void showCategoryFragment() {
        mStep = 0;
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        Bundle param = new Bundle();

        PublishCategoryFragment publishCategoryFragment = PublishCategoryFragment.newInstance(param);
        publishCategoryFragment.setOnServicePublishListener(this);
        fragmentTransaction.replace(R.id.fragmentContainer, publishCategoryFragment);
        fragmentTransaction.commitAllowingStateLoss();
        stepIndicatorLabel.setText(stepIndicatorLabels[0]);
    }

    private void showServiceContentFragment() {
        mButtonRight.setText("下一步");
        mStep = 1;
        stepsView.setCompletedPosition(1).drawView();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        Bundle params = new Bundle();
        params.putParcelable(PublishContentFragment.EXTRA_SERVICE_CATEGORY, serviceCategoryDo);
        params.putParcelable(PublishContentFragment.EXTRA_SECONDARY_SERVICE_CATEGORY, secondaryCategoryDo);
        params.putBoolean(Constant.EXTRA_TAG_EDIT_MODE, isEditMode);
        params.putParcelable(Constant.EXTRA_TAG_SERVICE_CONTENT, serviceRenderDo);
        ArrayList<ServicePropDo> servicePropDos = new ArrayList<>();
        if (null != publishContentFragment) {
            servicePropDos = publishContentFragment.getServiceProps();
        }
        publishContentFragment = PublishContentFragment.newInstance(params);
        publishContentFragment.setOnServicePublishListener(this);
        if (servicePropDos != null && !servicePropDos.isEmpty()) {
            publishContentFragment.setServiceProps(servicePropDos);
        }
        fragmentTransaction.replace(R.id.fragmentContainer, publishContentFragment);
        //fragmentTransaction.addToBackStack(null);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        fragmentTransaction.commitAllowingStateLoss();

        stepIndicatorLabel.setText(stepIndicatorLabels[1]);
    }

    private void showServiceMethodFragment() {
        mStep = 2;
        stepsView.setCompletedPosition(2).drawView();
        mButtonRight.setText("完成");
        Bundle params = new Bundle();
        params.putParcelable(Constant.EXTRA_TAG_SERVICE_TYPE, serviceRenderDo.getServiceType());
        params.putBoolean(Constant.EXTRA_TAG_EDIT_MODE, isEditMode);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        publishMethodFragment = PublishMethodFragment.newInstance(params);
        fragmentTransaction.replace(R.id.fragmentContainer, publishMethodFragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        //fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commitAllowingStateLoss();
        stepIndicatorLabel.setText(stepIndicatorLabels[2]);
    }

    private boolean checkPublishCondition() {
        switch (mStep) {
            case 0: {
                if (!isEditMode && (serviceCategoryDo == null || secondaryCategoryDo == null)) {
                    MessageUtils.showToast("请选择服务类别");
                    return false;
                }
                break;
            }
            case 1: {
                serviceRenderDo = publishContentFragment.getServiceRenderDo();

                if (serviceRenderDo == null ||
                        TextUtils.isEmpty(serviceRenderDo.getTitle())) {
                    MessageUtils.showToastCenter("你能提供什么技能呢？");
                    return false;
                }
                if (TextUtils.isEmpty(serviceRenderDo.getDesc())) {
                    MessageUtils.showToastCenter("还没写牛逼的描述呢");
                    return false;
                }
                if (serviceRenderDo.getImages().isEmpty()) {
                    MessageUtils.showToastCenter("还没有选择照片呢");
                    return false;
                }
                //验证服务属性是否为空
                if (publishContentFragment.getServiceProps() != null && !publishContentFragment.getServiceProps().isEmpty()) {
                    for (ServicePropDo servicePropDo : publishContentFragment.getServiceProps()) {
                        if (servicePropDo.isRequired()) {
                            switch (servicePropDo.getType()) {
                                case ServicePropRecycleAdapter.PROP_TYPE_SINGLE_CHOICE: {
                                    if (servicePropDo.getVid() == null) {
                                        MessageUtils.showToast(servicePropDo.getName() + "不能为空");
                                        return false;
                                    }
                                    break;
                                }
                                case ServicePropRecycleAdapter.PROP_TYPE_MULTI_CHOICE: {
                                    if (servicePropDo.getVids() == null
                                            || servicePropDo.getVids().isEmpty()) {
                                        MessageUtils.showToast(servicePropDo.getName() + "不能为空");
                                        return false;
                                    }
                                    break;
                                }
                                case ServicePropRecycleAdapter.PROP_TYPE_TEXT: {
                                    if (TextUtils.isEmpty(servicePropDo.getText())) {
                                        MessageUtils.showToast(servicePropDo.getName() + "不能为空");
                                        return false;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                } else if (serviceRenderDo.getProps() != null && !serviceRenderDo.getProps().isEmpty()) {
                    for (ServicePropDo servicePropDo : serviceRenderDo.getProps()) {
                        if (servicePropDo.isRequired() && !isEditMode) {
                            MessageUtils.showToast(serviceRenderDo.getPropsTitle() + "还没设置呢");
                            return false;
                        }
                    }
                }

                //验证SKU 属性
                Set<String> propValueSet = new HashSet<>();
                for (SkuListDo skuListDo : serviceRenderDo.getSkus().getSkuList()) {
                    for (ServiceSkuPropDo serviceSkuPropDo : skuListDo.getProps()) {
                        if (serviceSkuPropDo.isRequired() && TextUtils.isEmpty(serviceSkuPropDo.getValue())) {
                            MessageUtils.showToastCenter(serviceSkuPropDo.getTitle() + "不能为空");
                            return false;
                        }
                        if (serviceSkuPropDo.getMaxValue() > 0) {
                            switch (serviceSkuPropDo.getType()) {
                                case Constant.SKU_INPUT_TYPE_TEXT: {
                                    if (propValueSet.contains(serviceSkuPropDo.getValue())) {
                                        MessageUtils.showToastCenter("存在相同名称的" + serviceSkuPropDo.getTitle());
                                        return false;
                                    } else {
                                        propValueSet.add(serviceSkuPropDo.getValue());
                                    }
                                    break;
                                }
                                case Constant.SKU_INPUT_TYPE_FLOAT: {
                                    if (Float.parseFloat(serviceSkuPropDo.getValue()) >
                                            serviceSkuPropDo.getMaxValue()) {
                                        MessageUtils.showToastCenter(serviceSkuPropDo.getTitle() +
                                                "不能超过" + serviceSkuPropDo.getMaxValue());
                                        return false;
                                    }
                                    break;
                                }
                                case Constant.SKU_INPUT_TYPE_INT: {
                                    try {
                                        if (Long.parseLong(serviceSkuPropDo.getValue()) >
                                                serviceSkuPropDo.getMaxValue()) {
                                            MessageUtils.showToastCenter(serviceSkuPropDo.getTitle() +
                                                    "不能超过" + serviceSkuPropDo.getMaxValue());
                                            return false;
                                        }
                                    } catch (NumberFormatException e) {
                                        e.printStackTrace();
                                        MessageUtils.showToastCenter(serviceSkuPropDo.getTitle() + "格式错误");
                                        return false;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
                break;
            }
            case 2: {
                return publishMethodFragment.checkParam();
            }
        }
        return true;
    }

    /**
     * 上传图片
     */
    private void uploadImages() {
        if (publishContentFragment.getServiceRenderDo() == null || isUploadCompleted()) {
            return;
        }
        uploadImage(0);
    }

    /**
     * 检查是否上传完成
     *
     * @return
     */
    private boolean isUploadCompleted() {
        for (String image : publishContentFragment.getServiceRenderDo().getImages()) {
            if (!TextUtils.isEmpty(image) && !uploadedImages.containsKey(image)) {
                return false;
            }
        }
        return true;
    }

    private void uploadImage(final int index) {
        if (isUploading) {
            return;
        }
        final String imagePath = publishContentFragment.getServiceRenderDo().getImages().get(index);
        if (uploadedImages.containsKey(imagePath)) {
            for (int i = 0; i < publishContentFragment.getServiceRenderDo().getImages().size(); i++) {
                if (!uploadedImages.containsKey(publishContentFragment.getServiceRenderDo().getImages().get(i))) {
                    uploadImage(i);
                    return;
                }
            }
        }
        isUploading = true;
        RequestSign.upload(imagePath, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                isUploading = false;
                try {
                    JSONObject json = (JSONObject) result;
                    uploadedImages.put(imagePath, json.getString("data"));
                    Log.d(LOG_TAG, imagePath + "上传成功");
                    for (int i = 0; i < publishContentFragment.getServiceRenderDo().getImages().size(); i++) {
                        if (!uploadedImages.containsKey(publishContentFragment.getServiceRenderDo().getImages().get(i))) {
                            uploadImage(i);
                            break;
                        }
                    }
                    if (isUploadCompleted() && isPublishing) {
                        publishService();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(HttpError error) {
                isUploading = false;
                MessageUtils.showToastCenter(error != null ? "上传图片失败失败:" + error.getMessage() : "上传图片失败失败");
                hideProgressDialog();
            }
        });
    }

    private void getServiceContent() {
        if (!isEditMode || isCategoryChanged) {
            mLoadUtil.loadPre(rootView, fragmentContainer);
            com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
            params.put("stdCatId", secondaryCategoryDo.getCatId());
            HttpClient.get("1.0/item/add/render", params, ServiceRenderDo.class,
                    new HttpClient.HttpCallback<ServiceRenderDo>() {
                        @Override
                        public void onSuccess(ServiceRenderDo obj) {
                            mLoadUtil.loadSuccess(fragmentContainer);

                            //当返回到类目选择界面的时候，保留上个界面的图片信息
                            if (serviceRenderDo != null && publishContentFragment != null) {
                                obj.merge(serviceRenderDo);
                                obj.merge(publishContentFragment.getServiceRenderDo());
                            }
                            serviceRenderDo = obj;
                            showServiceContentFragment();
                            isCategoryChanged = false;
                        }

                        @Override
                        public void onFail(HttpError error) {
                            mLoadUtil.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                                @Override
                                public void retry() {
                                    getServiceContent();
                                }
                            });
                        }
                    });
        } else {
            showServiceContentFragment();
        }
    }

    private void getExistContent() {
        mLoadUtil.loadPre(rootView, fragmentContainer);
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("itemId", itemId);
        HttpClient.get("3.0/item/update/render", params, ServiceRenderDo.class,
                new HttpClient.HttpCallback<ServiceRenderDo>() {
                    @Override
                    public void onSuccess(ServiceRenderDo obj) {
                        mLoadUtil.loadSuccess(fragmentContainer);

                        serviceRenderDo = obj;

                        for (String image : serviceRenderDo.getImages()) {
                            uploadedImages.put(image, image);
                        }
                        showServiceContentFragment();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        mLoadUtil.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                            @Override
                            public void retry() {
                                getExistContent();
                            }
                        });
                    }
                });
    }

    private void publishService() {
        showProgressDialog("正在发布");
        isPublishing = true;
        if (!isUploadCompleted()) {
            uploadImages();
            return;
        }
        com.alibaba.fastjson.JSONObject params = generateParam();
        String publisPath = "3.0/item/add";
        if (isEditMode) {
            publisPath = "3.0/item/update";
        }
        HttpClient.post(publisPath, params, null,
                new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
                    @Override
                    public void onSuccess(com.alibaba.fastjson.JSONObject data) {
                        try {
                            hideProgressDialog();
                            isPublishing = false;
                            Bundle bundle = new Bundle();
                            bundle.putBoolean(Constant.EXTRA_TAG_EDIT_MODE, isEditMode);
                            if (data.containsKey("realUser") && data.getBoolean("realUser")) {
                                bundle.putString("title", serviceRenderDo.getTitle());
                                bundle.putString("desc", serviceRenderDo.getDesc());
                                if (!isEditMode) {
                                    bundle.putString("image", uploadedImages.get(0));
                                } else if (null != publishContentFragment) {
                                    bundle.putString("image", publishContentFragment.getServiceRenderDo().getImages().get(0));
                                }
                                bundle.putString("itemId", data.getString("itemId"));
                                bundle.putBoolean("bindGezi", data.getBoolean("bindGezi"));
                                Router.sharedRouter().open("publishServiceFinish", bundle);
                            } else {
                                bundle.putBoolean("bindGezi", data.getBoolean("bindGezi"));
                                bundle.putString("itemId", data.getString("itemId"));
                                Router.sharedRouter().open("serviceNotPutOnSale", bundle);
                            }

                            setResult(RESULT_OK);
                            finish();
                        } catch (Exception e) {
                            MessageUtils.showToastCenter(e.getMessage());
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(error.toString());
                        hideProgressDialog();
                        isPublishing = false;
                    }
                });
    }

    private com.alibaba.fastjson.JSONObject generateParam() {
        com.alibaba.fastjson.JSONObject params = publishMethodFragment.getServiceTypeParam();
        JSONArray uploadImageArray = new JSONArray();
        if (isEditMode) {
            params.put("itemId", itemId);
            params.put("stdCatId", serviceRenderDo.getStdCat().getString("stdCatId"));
            for (String image : publishContentFragment.getServiceRenderDo().getImages()) {
                if (!TextUtils.isEmpty(image)) {
                    uploadImageArray.add(uploadedImages.get(image));
                }
            }
        } else {
            params.put("stdCatId", secondaryCategoryDo.getCatId());
            for (String key : uploadedImages.keySet()) {
                uploadImageArray.add(uploadedImages.get(key));
            }
        }
        params.put("images", JSON.toJSON(uploadImageArray));
        params.put("title", serviceRenderDo.getTitle());
        params.put("desc", serviceRenderDo.getDesc());

        if (!publishContentFragment.getServiceProps().isEmpty()) {
            JSONArray propsArray = new JSONArray();
            for (ServicePropDo propDo : publishContentFragment.getServiceProps()) {
                switch (propDo.getType()) {
                    case ServicePropRecycleAdapter.PROP_TYPE_SINGLE_CHOICE: {
                        com.alibaba.fastjson.JSONObject propObj = new com.alibaba.fastjson.JSONObject();
                        propObj.put("vid", propDo.getVid());
                        propObj.put("pid", propDo.getPid());
                        propsArray.add(propObj);
                        break;
                    }
                    case ServicePropRecycleAdapter.PROP_TYPE_MULTI_CHOICE: {
                        for (String vid : propDo.getVids()) {
                            com.alibaba.fastjson.JSONObject propObj = new com.alibaba.fastjson.JSONObject();
                            propObj.put("vid", vid);
                            propObj.put("pid", propDo.getPid());
                            propsArray.add(propObj);
                        }
                        break;
                    }
                    case ServicePropRecycleAdapter.PROP_TYPE_TEXT: {
                        com.alibaba.fastjson.JSONObject propObj = new com.alibaba.fastjson.JSONObject();
                        propObj.put("text", propDo.getText());
                        propObj.put("pid", propDo.getPid());
                        propsArray.add(propObj);
                        break;
                    }
                }
            }
            params.put("props", propsArray.toJSONString());
        }
        if (!serviceRenderDo.getSkus().getSkuList().isEmpty()) {
            JSONArray skuArray = new JSONArray();
            for (int i = 0; i < serviceRenderDo.getSkus().getSkuList().size(); i++) {
                SkuListDo skuListDo = serviceRenderDo.getSkus().getSkuList().get(i);
                com.alibaba.fastjson.JSONObject sku = new com.alibaba.fastjson.JSONObject();
                for (int j = 0; j < skuListDo.getProps().size(); j++) {
                    ServiceSkuPropDo skuPropDo = skuListDo.getProps().get(j);
                    sku.put(skuPropDo.getKey(), skuPropDo.getValue());
                }
                skuArray.add(sku);
            }
            params.put("skus", skuArray.toJSONString());
        }
        LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();
        if (location != null) {
            params.put("longitude", location.getLongitude());

            params.put("latitude", location.getLatitude());
        }

        return params;
    }
}
