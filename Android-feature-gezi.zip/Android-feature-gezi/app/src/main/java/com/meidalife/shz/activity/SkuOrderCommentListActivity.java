package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.ViewGroup;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.CommentListFragment;
import com.meidalife.shz.adapter.FragmentTabAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CommentTabOutDO;
import com.meidalife.shz.rest.model.SkuCommentOutDO;
import com.meidalife.shz.rest.request.RequestCommentOpr;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.widget.SlidingTabLayout;
import com.usepropeller.routable.Router;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zuozheng on 16/3/4.
 * 订单评价list tab筛选
 */
public class SkuOrderCommentListActivity extends BaseActivity implements ViewPager.OnPageChangeListener {

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.orderSlidingTab)
    SlidingTabLayout orderSlidingTab;
    @Bind(R.id.orderTabViewPager)
    ViewPager orderTabViewPager;

    FragmentTabAdapter orderPagerAdapter;

    private LoadUtil mLoadUtil;

    String itemId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_list);
        ButterKnife.bind(this);

        initActionBar("评价列表", true, false);

        if (!Helper.sharedHelper().hasToken()) {
            Bundle bundle = new Bundle();
            bundle.putString("action", "www.kongge.com");
            Router.sharedRouter().open("signin", bundle);
            finish();
        }

        mLoadUtil = new LoadUtil(getLayoutInflater());
        orderPagerAdapter = new FragmentTabAdapter(getSupportFragmentManager());

        itemId = getIntent().getStringExtra("id");
        initData();
    }

    private void initData() {
        mLoadUtil.loadPre(rootView, orderTabViewPager);
        JSONObject params = new JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", 1);
        params.put("offset", 0);
        params.put("typeList", "1");

        RequestCommentOpr.commentList(params, new HttpClient.HttpCallback<SkuCommentOutDO>() {
            @Override
            public void onSuccess(SkuCommentOutDO outDO) {
                mLoadUtil.loadSuccess(orderTabViewPager);
                loadOrderTab(outDO.getStatistic());
            }

            @Override
            public void onFail(HttpError error) {
                mLoadUtil.loadFail(error, rootView, SkuOrderCommentListActivity.this, new LoadUtil.LoadCallback() {
                    @Override
                    public void execute() {
                        initData();
                    }
                });
            }
        });
    }

    private void loadOrderTab(List<CommentTabOutDO> list) {
        if (CollectionUtil.isEmpty(list)) {
            return;
        }

        for (int i = 0; i < list.size(); i++) {
            CommentTabOutDO tabDO = list.get(i);
            CommentListFragment orderListFragment = CommentListFragment.newInstance(itemId, tabDO);
            orderPagerAdapter.addFragment(orderListFragment);
        }

        orderPagerAdapter.notifyDataSetChanged();
        orderTabViewPager.setAdapter(orderPagerAdapter);
        orderSlidingTab.setCustomTabView(R.layout.item_order_comment_tab, R.id.orderTabName, R.id.orderCount);
        orderSlidingTab.setSelectedIndicatorColors(getResources().getColor(R.color.brand_b));
        orderSlidingTab.setSelectedTabTitleColorId(R.color.brand_b);
        orderSlidingTab.setTabTitleColorId(R.color.black);
        orderSlidingTab.setViewPager(orderTabViewPager);
        orderSlidingTab.setDividerColors(android.R.color.transparent);
        orderSlidingTab.setOnPageChangeListener(this);
        orderSlidingTab.setCalculateWidthByTitle(false);

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
//        ((CommentListFragment) (orderPagerAdapter.getItem(position))).loadComments(true);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
