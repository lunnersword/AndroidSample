package com.meidalife.shz.event;

import com.alibaba.wukong.im.Conversation;
import com.meidalife.shz.event.type.MsgTypeEnum;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 15/11/25.
 */
public class ConversationEvent extends BaseEvent {
    List<Conversation> conversationList = new ArrayList<>();

    int unreadNotificationCount = 0;

    public ConversationEvent(MsgTypeEnum type) {
        super(type);
    }

    public List<Conversation> getConversationList() {
        return conversationList;
    }

    public void setConversationList(List<Conversation> conversationList) {
        this.conversationList = conversationList;
    }

    public int getUnreadNotificationCount() {
        return unreadNotificationCount;
    }

    public void setUnreadNotificationCount(int unreadNotificationCount) {
        this.unreadNotificationCount = unreadNotificationCount;
    }

}
