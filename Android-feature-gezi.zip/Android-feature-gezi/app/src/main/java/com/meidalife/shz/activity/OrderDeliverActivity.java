package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

/**
 * 发货信息 page
 * Created by shijian on 15/8/24.
 */
public class OrderDeliverActivity extends BaseActivity {

    private TextView kuaidiName;
    private String kuaidiCode;
    private EditText kuaidiNoView;
    private TextView barcodeScannerIcon;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_deliver);
        initActionBar(R.string.title_order_delivery, true);

        Bundle extras = getIntent().getExtras();
        final String orderNo = extras.getString("orderNo");

        kuaidiName = (TextView) findViewById(R.id.kuaidi_name);

        View kuaidiGroup = findViewById(R.id.kuaidi_group);
        kuaidiGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().openFormResult("pickKuaidi",
                        Constant.REQUEST_CODE_EXPRESS_COMPANY, OrderDeliverActivity.this);
            }
        });

        kuaidiNoView = (EditText) findViewById(R.id.kuaidi_no);

        View commit = findViewById(R.id.deliver_commit);
        commit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String kuaidiNo = kuaidiNoView.getText().toString();
                if (!"#".equals(kuaidiCode) && StrUtil.isEmpty(kuaidiNo)) {
                    MessageUtils.showToastCenter("请填写快递单号");
                    return;
                }
                JSONObject params = new JSONObject();
                params.put("orderNo", orderNo);
                params.put("companyCode", kuaidiCode);
                params.put("deliveryNo", kuaidiNo);
                HttpClient.get("1.0/logistics/orderDeliver", params, String.class, new HttpClient.HttpCallback<String>() {
                    @Override
                    public void onSuccess(String obj) {
                        Router.sharedRouter().open("orders/" + orderNo);
                        finish();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter("发货失败，原因：" + error.toString());
                    }
                });
            }
        });

        EditText kuaidiNo = (EditText) findViewById(R.id.kuaidi_no);
        kuaidiNo.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
                    return true;
                }
                return false;
            }
        });

        barcodeScannerIcon = (TextView) findViewById(R.id.barcode_scanner_icon);
        barcodeScannerIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(OrderDeliverActivity.this, BarcodeScannerActivity.class);
                startActivityForResult(intent, Constant.REQUEST_CODE_BARCODE_SCAN);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constant.REQUEST_CODE_EXPRESS_COMPANY) {
            if (resultCode == RESULT_OK && null != data) {
                Bundle extras = data.getExtras();
                kuaidiName.setText(extras.getString("name"));
                kuaidiCode = extras.getString("code");
                View kuaidiNoGroup = findViewById(R.id.kuaidi_no_group);
                if ("#".equals(kuaidiCode)) {
                    kuaidiNoGroup.setVisibility(View.GONE);
                } else {
                    kuaidiNoGroup.setVisibility(View.VISIBLE);
                }
            }
        } else if (requestCode == Constant.REQUEST_CODE_BARCODE_SCAN) {
            if (resultCode == RESULT_OK && null != data) {
                String result = data.getStringExtra("result");
                kuaidiNoView.setText(result);
            }
        }
    }
}
