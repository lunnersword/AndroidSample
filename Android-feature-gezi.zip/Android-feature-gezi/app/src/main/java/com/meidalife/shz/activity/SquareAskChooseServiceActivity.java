package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareAskChooseServiceAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareAskServiceItemDo;
import com.meidalife.shz.rest.request.RequestSquareAsk;
import com.meidalife.shz.view.FontEditText;

import java.util.ArrayList;

public class SquareAskChooseServiceActivity extends BaseActivity {

    public static final String KEY_RETURN_SERVICE_ITEM = "returnServiceItem";
    private ViewGroup contentRoot;
    private GridView serviceGridView;
    private ArrayList<SquareAskServiceItemDo> mServiceItemArray;
    private SquareAskChooseServiceAdapter mSquareAskChooseServiceAdapter;
    private SquareAskServiceItemDo mReturnServiceItem;
    private FontEditText textSearch;
    private Button btnSearch;
    private String mSearchString;
    private View searchContent;
    private View noDataLayout;
    private boolean isGeZhu = false;
    private int mGeZiId;
    boolean loading = false;
    boolean complete = false;
    int page = 0;
    int PAGE_SIZE = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_ask_choose_service);
        isGeZhu = getIntent().getBooleanExtra("isGeZhu", false);
        mGeZiId = getIntent().getIntExtra("geziId", -1);
        contentRoot = (ViewGroup) findViewById(R.id.contentRoot);
        serviceGridView = (GridView) findViewById(R.id.serviceGridView);
        textSearch = (FontEditText) findViewById(R.id.textSearch);
        btnSearch = (Button) findViewById(R.id.btnSearch);
        searchContent = findViewById(R.id.searchContent);
        noDataLayout = findViewById(R.id.noDataLayout);
        mButtonBack = (Button)findViewById(R.id.action_bar_button_back);
        mButtonBack.setTypeface(Helper.sharedHelper().getIconFont());
        mButtonRight = (Button)findViewById(R.id.mButtonRight);
        mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());
        mServiceItemArray = new ArrayList<>();
        mSquareAskChooseServiceAdapter = new SquareAskChooseServiceAdapter(this, mServiceItemArray);
        serviceGridView.setAdapter(mSquareAskChooseServiceAdapter);
        bindListener();

        if (!isGeZhu) {
            searchContent.setVisibility(View.INVISIBLE);
            btnSearch.setVisibility(View.INVISIBLE);
        } else {
            searchContent.setVisibility(View.VISIBLE);
            btnSearch.setVisibility(View.VISIBLE);
        }
        fetchData();
    }

    private void bindListener() {
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mSearchString = textSearch.getText().toString().trim();
                fetchData();
            }
        });

        serviceGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long row) {
                if (mSquareAskChooseServiceAdapter.selectItemId != position) {
                    mSquareAskChooseServiceAdapter.selectItemId = position;
                }
                mSquareAskChooseServiceAdapter.notifyDataSetChanged();
                mReturnServiceItem = mServiceItemArray.get(position);
            }
        });

        serviceGridView.setOnScrollListener(new AbsListView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == (view.getCount() - 1)) {
                        loadAskItem();
                    }
                }

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {

            }
        });

        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mReturnServiceItem == null) {
                    MessageUtils.showToast("还没有选择服务哦");
                } else {
                    Bundle returnBundle = new Bundle();
                    returnBundle.putSerializable(KEY_RETURN_SERVICE_ITEM, mReturnServiceItem);
                    Intent returnIntent = new Intent();
                    returnIntent.putExtras(returnBundle);
                    setResult(RESULT_OK, returnIntent);
                    finish();
                }

            }
        });
    }

    private void fetchData() {
        page = 0;
        mServiceItemArray.clear();
        serviceGridView.setVisibility(View.GONE);
        showStatusLoading(contentRoot);
        getAssociateItems();
    }

    private void getAssociateItems() {
        JSONObject params = null;
        if (!isGeZhu) {
            params = getSelfParams();
        } else {
            params = getSearchParams();
        }
        loading = true;

        RequestSquareAsk.getCommentAssociateItems(params, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                JSONObject listObject = (JSONObject) obj;
                JSONArray itemArray = (JSONArray) listObject.get("itemList");
                JSONObject itemObject;
                SquareAskServiceItemDo squareAskServiceItemDo;
                int size = itemArray.size();
                for (int i = 0; i < size; i++) {
                    squareAskServiceItemDo = new SquareAskServiceItemDo();
                    itemObject = (JSONObject) itemArray.get(i);
                    squareAskServiceItemDo.setItemId((int) itemObject.get("itemId"));
                    squareAskServiceItemDo.setItemTitle((String) (itemObject.get("itemTitle")));
                    JSONArray imagesArray = (JSONArray) itemObject.get("images");
                    ArrayList<String> imagesArrayList = new ArrayList<>();
                    for (int j = 0; j < imagesArray.size(); j++) {
                        imagesArrayList.add((String) imagesArray.get(j));
                    }
                    squareAskServiceItemDo.setImages(imagesArrayList);
                    squareAskServiceItemDo.setUserId((int) itemObject.get("userId"));
                    squareAskServiceItemDo.setUserName((String) itemObject.get("userName"));
                    squareAskServiceItemDo.setUserAvatar((String) itemObject.get("userAvatar"));
                    squareAskServiceItemDo.setUserGender((String) itemObject.get("userGender"));
                    mServiceItemArray.add(squareAskServiceItemDo);

                }
                if (mServiceItemArray.size() == 0) {
                    serviceGridView.setVisibility(View.GONE);
                    noDataLayout.setVisibility(View.VISIBLE);
                } else {
                    serviceGridView.setVisibility(View.VISIBLE);
                    noDataLayout.setVisibility(View.GONE);
                }

                mSquareAskChooseServiceAdapter.notifyDataSetChanged();
                loading = false;

                if (size < PAGE_SIZE) {
                    complete = true;
                }

            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                loading = false;
                if (page != 0) {
                    page--;
                }
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(contentRoot, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fetchData();
                        }
                    });
                } else {
                    textStatusErrorServer.setText(error.getMessage());
                    showStatusErrorServer(contentRoot, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fetchData();
                        }
                    });
                }

            }
        });
    }

    private void loadAskItem() {
        if (!complete && !loading) {
            page++;
            getAssociateItems();
        }
    }

    private JSONObject getSelfParams() {
        JSONObject params = new JSONObject();
        params.put("geziId", mGeZiId);
        params.put("offset", page * PAGE_SIZE);
        params.put("pageSize", PAGE_SIZE);
        return params;
    }

    private JSONObject getSearchParams() {
        JSONObject params = new JSONObject();
        params.put("geziId", mGeZiId);
        params.put("isSearch", true);
        params.put("keyword", TextUtils.isEmpty(mSearchString) ? "" : mSearchString);

        params.put("offset", page * PAGE_SIZE);
        params.put("pageSize", PAGE_SIZE);
        return params;
    }

}
