package com.meidalife.shz.analysis;

import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.meidalife.shz.Helper;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.rest.SyncHttpClient;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.util.SdcardUtil;
import com.meidalife.shz.util.StrUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by shijian on 15/8/21.
 */
public class LogUtil {
    public static final int TYPE_START_APP = 2;
    public static final int TYPE_EXIT_APP = 3;
    public static final int TYPE_START_PAGE = 4;
    public static final int TYPE_EXIT_PAGE = 5;
    public static final int TYPE_CUSTOMIZE = 6;
    public static final int TYPE_H5_TO_NATIVE = 8;
    /**
     * 点击首页下方list的筛选条件按钮
     */
    public static final String EVENT_ID_HOME_TAB_CLICK = "10003";
    /**
     * 点击频道页今日头牌区
     */
    public static final String EVENT_ID_TODAY_CLICK = "40001";
    /**
     * 点击频道页下方list的筛选条件按钮
     */
    public static final String EVENT_ID_CATEGORY_CLICK = "40002";
    /**
     * 点击搜索结果页list进入分享
     */
    public static final String EVENT_ID_SEARCH_SHARE_CLICK = "50001";

    /**
     * 点击分享公共组件
     */
    public static final String EVENT_ID_SHARE_CLICK = "60001";
    /**
     * 点击聊一聊公共组件
     */
    public static final String EVENT_ID_CHAT_CLICK = "60002";
    /**
     * 点击到详情页公共组件
     */
    public static final String EVENT_ID_SERVICE_ITEM_CLICK = "60003";

    /**
     * 创建订单
     */
    public static final String EVENT_ID_ORDER_CREATTE = "60004";

    /**
     * 点击格子首页进入格子HOME页
     */
    public static final String EVENT_ID_SQUARE_HOME_ITEM_CLICK = "70001";

    /**
     * 点击格子HOME页tab筛选条件按钮
     */
    public static final String EVENT_ID_SQUARE_HOME_TAB_CLICK = "70002";

    /**
     * 点击周边格子list进入格子HOME页
     */
    public static final String EVENT_ID_SURROUND_SQUARE_LIST_ITEM_CLICK = "70005";

    public static final String TAG_EVENT_ID = "eid";

    public static int SUCCESS = 0;
    public static int FAIL = -1;

    private static String packDir = "/com.kongge/";
    private static final String metaFile = "meta.txt";
    private static String logDir = null;
    private static String logFile = null;

    private static final int maxSize = 20;
    private static List<String> cache = new ArrayList<String>(maxSize);  // 仅在少数情况存在并发，忽略相互覆盖情况

    public static void init() {
        new LogInitTask().run();
    }

    /**
     * http请求记录
     *
     * @param path
     * @param s
     * @param rt
     * @param code
     * @param rid
     * @param srt
     */
    public static void log(String path, int s, long rt, int code, String rid, String srt,long rst) {
        JSONObject reportJson = new JSONObject();
        try {
            reportJson.put("ts", System.currentTimeMillis());
            reportJson.put("t", 7);
            reportJson.put("srt", srt);
            reportJson.put("i", path);
            reportJson.put("s", s);
            reportJson.put("crt", rt);
            reportJson.put("c", code);
            reportJson.put("rid", rid);
            reportJson.put("tk",Helper.sharedHelper().getToken());
            reportJson.put("rst",rst);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (!TextUtils.isEmpty(reportJson.toString())) {
            log(reportJson.toString());
        }
    }

    /**
     * 手动埋点记录
     *
     * @param eid
     * @param values
     */
    public static void log(int eid, Map<String, String> values) {
        JSONObject reportJson = new JSONObject();

        try {
            reportJson.put("ts", System.currentTimeMillis());
            reportJson.put("net", Helper.getNetWorkType());
            reportJson.put("tk", Helper.sharedHelper().getToken());
            reportJson.put("eid", eid);
            for (Map.Entry<String, String> e : values.entrySet()) {
                reportJson.put(e.getKey(), e.getValue());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (!TextUtils.isEmpty(reportJson.toString())) {
            log(reportJson.toString());
        }
    }

    /**
     * app/页面打开退出记录
     *
     * @param type
     * @param pid
     */
    public static void log(int type, String pid) {
        LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();

        JSONObject reportJson = new JSONObject();
        try {
            reportJson.put("ts", System.currentTimeMillis());
            reportJson.put("t", type);
            reportJson.put("lx", location.getLongitude());
            reportJson.put("ly", location.getLatitude());
            reportJson.put("net", Helper.getNetWorkType());
            reportJson.put("tk", Helper.sharedHelper().getToken());
            reportJson.put("pid", pid);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (!TextUtils.isEmpty(reportJson.toString())) {
            log(reportJson.toString());
        }
    }

    /**
     * 数据埋点
     */
    public static void log(LogParam param) {
        LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();

        JSONObject reportJson = new JSONObject();
        try {
            if (!TextUtils.isEmpty(param.getH5Param())) {
                reportJson = new JSONObject(param.getH5Param());
            }
            reportJson.put("ts", System.currentTimeMillis());
            reportJson.put("t", param.getType());
            reportJson.put("lx", location.getLongitude());
            reportJson.put("ly", location.getLatitude());
            reportJson.put("net", Helper.getNetWorkType());
            reportJson.put("tk", Helper.sharedHelper().getToken());

            if (!TextUtils.isEmpty(param.getEid())) {
                reportJson.put("eid", param.getEid());
            }
            if (!TextUtils.isEmpty(param.getPoid())) {
                reportJson.put("poid", param.getPoid());
            }
            if (!TextUtils.isEmpty(param.getPvid())) {
                reportJson.put("pvid", param.getPvid());
            }

            if (!TextUtils.isEmpty(param.getPid())) {
                reportJson.put("pid", param.getPid());
            }

            if (!TextUtils.isEmpty(param.getCategoryId())) {
                reportJson.put("cid", param.getCategoryId());
            }

            if (!TextUtils.isEmpty(param.getGeziid())) {
                reportJson.put("geziid", param.getGeziid());
            }

            if (!TextUtils.isEmpty(param.getItemid())) {
                reportJson.put("itemid", param.getItemid());
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (!TextUtils.isEmpty(reportJson.toString())) {
            log(reportJson.toString());
        }
    }

    public static void log(int type, String pid, int catId) {
        LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();

        JSONObject reportJson = new JSONObject();
        try {
            reportJson.put("ts", System.currentTimeMillis());
            reportJson.put("t", type);
            reportJson.put("lx", location.getLongitude());
            reportJson.put("ly", location.getLatitude());
            reportJson.put("net", Helper.getNetWorkType());
            reportJson.put("tk", Helper.sharedHelper().getToken());
            reportJson.put("pid", pid);
            reportJson.put("cid", catId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (!TextUtils.isEmpty(reportJson.toString())) {
            log(reportJson.toString());
        }
    }

    private static void log(String str) {
        if (logFile == null) {
            return;
        }
        cache.add(str);

        if (cache.size() >= maxSize) {
            synchronized (cache) {
                if (cache.size() < maxSize) return;  // 防止并发问题
                List<String> oldData = cache;
                cache = new ArrayList<>(maxSize);
                WriteFileTask writeFileTask = new WriteFileTask(oldData);
                new Thread(writeFileTask).start();
            }
        }
    }

    public static class LogInitTask implements Runnable {
        @Override
        public void run() {
            try {
                boolean isExistMeta = false;
                String oldFiles = null;
                List<String> sdPaths = SdcardUtil.getSDCardPaths();

                /*
                尝试读取meta文件
                 */
                for (String dir : sdPaths) {
                    try {
                        oldFiles = readFile(dir + packDir + metaFile);
                        isExistMeta = true;
                        logDir = dir + packDir;
                        break;
                    } catch (Exception e) {
                        Log.e(LogUtil.class.getName(), "traverse sd read meta fail", e);
                    }
                }
                /*
                不存在meta文件
                 */
                if (!isExistMeta) {
                    for (String dir : sdPaths) {
                        try {
                            String tmpDir = dir + packDir;
                            createFile(tmpDir, metaFile);
                            logDir = tmpDir;
                            break;
                        } catch (Exception e) {
                            // 说明此目录，不可写，尝试下一个
                        }
                    }
                }

                Log.e(LogUtil.class.getName(), "log file dir = " + logDir);
                if (StrUtil.isEmpty(logDir)) return;

                // 生成新文件，且写入meta
                String newLogFile = System.currentTimeMillis() + ".txt";
                createFile(logDir, newLogFile);
                appendFileToMeta(newLogFile, true);
                logFile = newLogFile;

                int netType = Helper.getNetWorkType();  // 判断网络类型，仅wifi允许上传
                if (netType == 1) {
                    // 开始上传老数据
                    if (!StrUtil.isEmpty(oldFiles)) {
                        //Log.e(LogUtil.class.getName(), "prepare upload file : " + oldFiles);
                        try {
                            uploadLog(JSONArray.parseArray(oldFiles));
                        } catch (Exception e) {

                        }
                    }
                }

            } catch (Exception e) {
                Log.e(LogUtil.class.getName(), "detect log dir fail", e);
            }
        }

        public void createFile(String dir, String file) throws Exception {
            File dirFile = new File(dir);
            if (!dirFile.exists()) {
                dirFile.mkdir();
            }
            FileOutputStream fos = new FileOutputStream(dir + file);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fos, "UTF-8"));
            writer.flush();
            writer.close();
        }

        public String readFile(String file) throws Exception {
            File fin = new File(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fin), "UTF-8"));
            String line = reader.readLine();
            reader.close();
            return line;
        }

        public void uploadLog(JSONArray fileArray) {
            for (int i = 0; i < fileArray.size(); i++) {
                try {
                    String fileName = fileArray.getString(i);
                    File file = new File(logDir + fileName);
                    if (SyncHttpClient.upload(file)) {
                        appendFileToMeta(fileName, false);
                        boolean delFlag = file.delete();
                        //if(delFlag) Log.e(thiss.class.getName(), "del meta and file, file = " + fileName);
                    }
                } catch (Exception e) {
                    Log.e(LogUtil.class.getName(), "upload file fail, files : " + fileArray.toString(), e);
                }
            }
        }

        public void appendFileToMeta(String file, boolean isAppend) throws Exception {

            String metaAbsPath = logDir + metaFile;
            String line = readFile(metaAbsPath);

            JSONArray metaData = new JSONArray();
            try {
                if (!StrUtil.isEmpty(line)) {
                    metaData = JSON.parseArray(line);
                }
            } catch (Exception e) {
            }

            if (isAppend) {
                metaData.add(file);
            } else {
                for (int i = 0; i < metaData.size(); i++) {
                    if (file.equals(metaData.getString(i))) {
                        metaData.remove(i);
                        continue;
                    }
                }
            }

            FileOutputStream fos = new FileOutputStream(metaAbsPath);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fos, "UTF-8"));
            writer.write(metaData.toJSONString());
            writer.flush();
            writer.close();
        }

    }

    public static class WriteFileTask implements Runnable {

        List<String> datas;

        public WriteFileTask(List<String> cache) {
            this.datas = cache;
        }

        @Override
        public void run() {
            try {
                //Log.e(getClass().getSimpleName(), "flush log file starting, file = " + (logDir + logFile) + ", data size = " + datas.size());

                FileOutputStream fos = new FileOutputStream(logDir + logFile, true);
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fos, "UTF-8"));
                for (String line : datas) {
                    writer.write(line);
                    writer.write("\n");
                }
                writer.flush();
                writer.close();
                //Log.e(LogUtil.class.getName(), "flush log file success, file = " + (logDir + logFile));
            } catch (Exception e) {
                Log.e(LogUtil.class.getName(), "write log to file fail", e);
            }
        }
    }
}
