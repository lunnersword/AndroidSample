package com.meidalife.shz.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.meidalife.shz.SHZApplication;

/**
 * Created by fufeng on 15/11/23.
 */
public class DatabaseManager {
    private Context mContext;
    private DaoSession mDaoSession;

    private static class SingletonHolder {
        private static DatabaseManager INSTANCE = new DatabaseManager();
    }

    private DatabaseManager() {
        mContext = SHZApplication.getInstance();
    }

    public static DatabaseManager getInstance() {
        return SingletonHolder.INSTANCE;
    }

    public DaoSession getDaoSession() {
        if (mDaoSession == null) {
            DbHelper helper = new DbHelper(mContext, "kongge.db");
            DaoMaster daoMaster = new DaoMaster(helper.getWritableDatabase());
            mDaoSession = daoMaster.newSession();
        }
        return mDaoSession;
    }

    public class DbHelper extends DaoMaster.DevOpenHelper {

        public DbHelper(Context context, String name) {
            super(context, name, null);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            super.onUpgrade(db, oldVersion, newVersion);
        }
    }
}
