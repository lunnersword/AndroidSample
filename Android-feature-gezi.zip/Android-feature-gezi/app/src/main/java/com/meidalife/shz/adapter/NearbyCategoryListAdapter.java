package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.NearbyCategoryActivity;

/**
 * Created by liujian on 16/1/30.
 */
public class NearbyCategoryListAdapter extends BaseAdapter{
    private JSONArray cats;
    private LayoutInflater mInflater;
    private int type;

    public NearbyCategoryListAdapter(Context context, JSONArray cats) {
        this.cats = cats;
        this.mInflater = LayoutInflater.from(context);
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public int getCount() {
        return cats.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.item_nearby_category,parent,false);
            holder = new ViewHolder();
            holder.categoryName = (TextView)convertView.findViewById(R.id.categoryName);
            holder.categoryTitle = (TextView)convertView.findViewById(R.id.categoryTitle);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder)convertView.getTag();
        }
        JSONObject item = cats.getJSONObject(position);
        holder.categoryName.setText(item.getString("catName"));
        if (type == NearbyCategoryActivity.SQUARE_NEARBY_CATEGORY && item.containsKey("catSubTitle")) {
            holder.categoryTitle.setVisibility(View.VISIBLE);
            holder.categoryTitle.setText(item.getString("catSubTitle"));
        } else {
            holder.categoryTitle.setVisibility(View.GONE);
        }
        return convertView;
    }

    private static class ViewHolder{
        TextView categoryName;
        TextView categoryTitle;
    }
}
