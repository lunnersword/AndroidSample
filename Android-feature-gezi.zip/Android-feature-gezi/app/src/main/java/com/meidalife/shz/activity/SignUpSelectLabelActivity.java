package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SignUpSelectLabelAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;

import org.json.JSONException;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 注册时选择用户标签
 * Created by liujian on 16/1/8.
 */
public class SignUpSelectLabelActivity extends BaseActivity{

    @Bind(R.id.labelGridView)
    GridView labelGridView;
    @Bind(R.id.btnSignUp)
    Button btnSignUp;
    @Bind(R.id.rootView)
    ViewGroup rootView;


    private JSONArray labels;
    private SignUpSelectLabelAdapter signUpSelectLabelAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_select_lable);
        ButterKnife.bind(this);

        initActionBar(R.string.title_activity_profile_label, true, true);
        mButtonRight.setText(getResources().getString(R.string.skip));

        labels = new JSONArray();
        signUpSelectLabelAdapter = new SignUpSelectLabelAdapter(this,labels);
        labelGridView.setAdapter(signUpSelectLabelAdapter);

        initListener();
        initData();

    }

    private void initListener(){
        labelGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String label = labels.getJSONObject(position).getString("label");
                if (signUpSelectLabelAdapter.containsLabel(label)) {
                    signUpSelectLabelAdapter.removeSelectPos(label);
                } else
                    signUpSelectLabelAdapter.addSelectPos(label);
                signUpSelectLabelAdapter.notifyDataSetChanged();
            }
        });
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_OK);
                finish();
            }
        });
    }

    private void initData(){
        labelGridView.setVisibility(View.GONE);
        btnSignUp.setVisibility(View.GONE);
        showStatusLoading(rootView);
        HttpClient.get("1.0/user_label/getRegister", new JSONObject(), null, new HttpClient.HttpCallback<JSONArray>() {
            @Override
            public void onSuccess(JSONArray obj) {
                hideStatusLoading();
                labelGridView.setVisibility(View.VISIBLE);
                btnSignUp.setVisibility(View.VISIBLE);

                if (obj == null || obj.size() == 0)
                    return;
                labels.clear();
                labels.addAll(obj);
                signUpSelectLabelAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                }
            }
        });

    }

    public void handleSignUp(View view){
        if(signUpSelectLabelAdapter.getSelectLabel().size() == 0){
            MessageUtils.showToastCenter("至少选择一个标签");
            return;
        }
        org.json.JSONObject params = getParams();
        showProgressDialog("正在保存");
        RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                hideProgressDialog();

                setResult(RESULT_OK);
                finish();
            }

            @Override
            public void onFailure(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败，请稍后再试");
            }
        });

    }

    private org.json.JSONObject getParams() {
        org.json.JSONObject params = new org.json.JSONObject();
        try {
            StringBuffer labelSb = new StringBuffer();
            for (String label : signUpSelectLabelAdapter.getSelectLabel()) {
                labelSb.append(label + ",");
            }
            params.put("userTag", labelSb.toString().length() == 0 ? "" : labelSb.toString().substring(0, labelSb.toString().length() - 1));
            return params;
        } catch (JSONException e) {
            e.printStackTrace();
            return params;
        }
    }
}
