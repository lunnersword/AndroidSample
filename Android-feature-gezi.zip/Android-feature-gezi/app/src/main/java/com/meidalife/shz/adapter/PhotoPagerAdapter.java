package com.meidalife.shz.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.view.PagerAdapter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.FutureTarget;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.StrUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import uk.co.senab.photoview.PhotoView;
import uk.co.senab.photoview.PhotoViewAttacher;

/**
 * Created by taber on 15/6/23.
 */
public class PhotoPagerAdapter extends PagerAdapter {
    ArrayList<String> mData;
    Context mContext;
    PhotoViewAttacher.OnPhotoTapListener mOnPhotoTapListener;
    private LayoutInflater mInflater;
    private final int screen_width;
    private final int screen_height;

    public PhotoPagerAdapter(Context mContext, ArrayList<String> mData) {
        this.mData = mData;
        this.mContext = mContext;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        screen_width = mContext.getResources().getDisplayMetrics().widthPixels;
        screen_height = mContext.getResources().getDisplayMetrics().heightPixels;
    }

    public void setOnPhotoTapListener(PhotoViewAttacher.OnPhotoTapListener mOnPhotoTapListener) {
        this.mOnPhotoTapListener = mOnPhotoTapListener;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public View instantiateItem(ViewGroup container, int position) {
        PhotoView photoView = new PhotoView(container.getContext());
        final String photoUrl = mData.get(position);

        if (!TextUtils.isEmpty(photoUrl) && photoUrl.startsWith("http://")) {
            Glide.with(mContext)
                    .load(photoUrl)
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                    .into(photoView);
        } else {
            Glide.with(mContext)  // 文件类型
                    .load(new File(photoUrl))
                    .into(photoView);
        }

        // Now just add PhotoView to ViewPager and return it
        container.addView(photoView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        photoView.setOnPhotoTapListener(new PhotoViewAttacher.OnPhotoTapListener() {
            @Override
            public void onPhotoTap(View view, float v, float v1) {
                if (mOnPhotoTapListener != null) {
                    mOnPhotoTapListener.onPhotoTap(view, v, v1);
                }
            }
        });
        photoView.setOnViewTapListener(new PhotoViewAttacher.OnViewTapListener() {
            @Override
            public void onViewTap(View view, float v, float v1) {
                if (mOnPhotoTapListener != null) {
                    mOnPhotoTapListener.onPhotoTap(view, v, v1);
                }
            }
        });

        photoView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                View contextMenu = mInflater.inflate(R.layout.message_delete_dialog, null);
                final AlertDialog dialog = new AlertDialog.Builder(mContext).create();
                dialog.setView(contextMenu, 0, 0, 0, 0);
                dialog.show();
                TextView deleteTv = (TextView) contextMenu.findViewById(R.id.singleContextMenu);
                deleteTv.setText(R.string.save_image);
                String imageDir = ImgUtil.getSavedImagePath(mContext);
                int index = photoUrl.lastIndexOf(".");
                String suffix = photoUrl.substring(index);
                final String imagePath = imageDir + File.separator + StrUtil.getRandomString(5) +
                        System.currentTimeMillis() + suffix;
                deleteTv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        if (photoUrl.startsWith("http://")) {
                            final FutureTarget<File> future = Glide.with(mContext.getApplicationContext()).
                                    load(photoUrl).downloadOnly(screen_width, screen_height);

                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        File file = future.get();
                                        ImgUtil.copyFile(file.getAbsolutePath(), imagePath);

                                        try {
                                            File imageFile = new File(imagePath);
                                            if (imageFile.exists()) {
                                                Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                                                Uri uri = Uri.fromFile(imageFile);
                                                intent.setData(uri);
                                                mContext.sendBroadcast(intent);
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    } catch (InterruptedException | ExecutionException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }).start();
                        } else {
                            ImgUtil.copyFile(photoUrl, imagePath);
                        }
                        MessageUtils.showToast(String.format(mContext.getString(R.string.image_saved_in), imagePath));
                    }
                });
                return false;
            }
        });
        return photoView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }
}
