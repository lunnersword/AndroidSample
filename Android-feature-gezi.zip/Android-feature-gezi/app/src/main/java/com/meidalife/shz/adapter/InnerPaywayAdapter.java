package com.meidalife.shz.adapter;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Switch;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by taber on 15/8/25.
 */
public class InnerPaywayAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    JSONArray mData;
    OnChange mOnChange;

    public static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.contentView)
        View contentView;
        @Bind(R.id.textTitle)
        TextView textTitle;
        @Bind(R.id.textPoint)
        TextView textPoint;
        @Bind(R.id.iconQuestion)
        View iconQuestion;
        @Bind(R.id.textDesc)
        TextView textDesc;
        @Bind(R.id.switchPoint)
        Switch switchPoint;
        @Bind(R.id.viewLine)
        View viewLine;
    }

    public InnerPaywayAdapter(Context context, JSONArray data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getCount() {
        return mData != null ? mData.size() : 0;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public String getItem(int position) {
        return null;
    }

    public void setmOnChange(OnChange onChange) {
        mOnChange = onChange;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_inner_payway, parent, false);
            ViewHolder holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        }

        final ViewHolder holder = (ViewHolder) convertView.getTag();

        try {
            final JSONObject item = mData.getJSONObject(position);
            final int type = item.getIntValue("type");
            if (item.containsKey("comment") && !TextUtils.isEmpty(item.getString("comment"))) {
                holder.iconQuestion.setVisibility(View.VISIBLE);
                holder.contentView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", item.getString("comment"));
                        Router.sharedRouter().open("web", bundle);
                    }
                });
            } else {
                holder.iconQuestion.setVisibility(View.GONE);
            }
            holder.textTitle.setText(item.getString("title"));

            holder.textPoint.setText(item.getString("payNumStr"));
            holder.textDesc.setText(item.getString("desc"));
            boolean isDisable = false;
            if (item.containsKey("disabled") && item.getBoolean("disabled")) {
                isDisable = true;
            }
            if (isDisable) { //不允许使用M豆
                holder.switchPoint.setChecked(false);
                holder.switchPoint.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        return true;
                    }
                });

            } else {
                holder.switchPoint.setChecked(item.getIntValue("selected") == 1);
                holder.switchPoint.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnChange != null) {
                            mOnChange.onChange(type, holder.switchPoint.isChecked() ? 1 : 0);
                        }
                    }
                });
            }
        } catch (JSONException e) {

        }

        if (position == mData.size() - 1) {
            holder.viewLine.setVisibility(View.GONE);
        } else {
            holder.viewLine.setVisibility(View.VISIBLE);
        }

        return convertView;
    }

    public interface OnChange {
        void onChange(int type, int selected);
    }
}
