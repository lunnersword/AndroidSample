package com.meidalife.shz.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;

import org.json.JSONException;
import org.json.JSONObject;

public class WelcomeWordsSetting extends BaseActivity {

    private final static int MAX_CONTENT_NUMS = 140;

    EditText wordsContent;
    TextView contentNum;

    int len;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_words_setting);
        initActionBar(R.string.title_activity_welcome_words_activity, true, true);
        hideIMM();

        wordsContent = (EditText) findViewById(R.id.wordsContent);
        contentNum = (TextView) findViewById(R.id.contentNum);

        mButtonRight.setText(R.string.confirm);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updataWelcome();
            }
        });
        initContentListener();
        fetchWelcome();

    }

    private void initContentListener() {

        len = wordsContent.length();
        contentNum.setText(String.valueOf(MAX_CONTENT_NUMS - len));

        wordsContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                len = wordsContent.length();
                contentNum.setText(String.valueOf(MAX_CONTENT_NUMS - len));
                if (len > MAX_CONTENT_NUMS) {
                    wordsContent.setText(wordsContent.getText().toString().substring(0, MAX_CONTENT_NUMS));
                    MessageUtils.showToast("已超出140个字符。");
                }

            }
        });
    }

    private void fetchWelcome() {

        RequestSign.getProfile(new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                JSONObject json = (JSONObject) result;
                try {
                    Log.d("myprofile", json.toString());
                    JSONObject data = json.getJSONObject("data");

                    if (data.has("welcome")) {
                        wordsContent.setText(data.getString("welcome"));
                    }
                } catch (JSONException e) {

                }
            }

            @Override
            public void onFailure(HttpError error) {

            }
        });

    }


    private void updataWelcome() {

        JSONObject params = new JSONObject();
        try {
            params.put("welcome", wordsContent.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        showProgressDialog("正在保存");
        RequestSign.updateWelcome(params, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                hideProgressDialog();
                MessageUtils.showToastCenter("保存成功");
                finish();
            }

            @Override
            public void onFailure(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败");
            }
        });

    }

}
