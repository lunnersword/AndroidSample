package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by taber on 15/7/30.
 */
public class ConstellationAdapter extends BaseAdapter {
    private LayoutInflater mInflater;
    private Context mContext;
    private ArrayList<?> mData;

    static class ViewHolder {
        public TextView icon;
        public TextView date;
        public TextView name;
    }

    public ConstellationAdapter(Context context, ArrayList<HashMap<String, String>> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.view_item_constellation, parent, false);
            TextView date = (TextView) convertView.findViewById(R.id.date);
            TextView name = (TextView) convertView.findViewById(R.id.name);
            TextView icon = (TextView) convertView.findViewById(R.id.icon);
            icon.setTypeface(Helper.sharedHelper().getIconFont());
            holder = new ViewHolder();
            holder.date = date;
            holder.name = name;
            holder.icon = icon;
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        // set data
        HashMap item = (HashMap) mData.get(position);
        holder.date.setText((String) item.get("date"));
        holder.name.setText((String) item.get("name"));
        holder.icon.setText((String) item.get("icon"));

        return convertView;
    }
}
