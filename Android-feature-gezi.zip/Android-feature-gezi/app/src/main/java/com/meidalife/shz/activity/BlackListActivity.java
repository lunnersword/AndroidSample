package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.BlackListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 拉黑的人
 * Created by xingchen on 2015/11/27.
 */
public class BlackListActivity extends BaseActivity {

    @Bind(R.id.blackList)
    ListView blackList;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.emptyView)
    View emptyView;

    private BlackListAdapter blackListAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_black_list);
        ButterKnife.bind(this);

        initActionBar(R.string.title_activity_black_list, true);
        blackListAdapter = new BlackListAdapter(this, new JSONArray());
        blackList.setAdapter(blackListAdapter);
        blackList.setOnCreateContextMenuListener(new View.OnCreateContextMenuListener() {
            @Override
            public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
                menu.add(0, 0, 0, R.string.cancel_black_list);
            }
        });
        initData();
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = (int) info.id;
        switch (item.getItemId()) {
            case 0:
                cancel(((JSONObject) blackListAdapter.getList().get(position)).getString("userId"), position);
                break;
        }
        return super.onContextItemSelected(item);
    }

    private void initData() {
        blackList.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
        showStatusLoading(rootView);
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("type", 1);
        HttpClient.get("1.0/relationship/user/getUserList", params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                JSONArray userList = obj.getJSONArray("userList");
                if (userList == null) {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                    return;
                }
                if (userList.size() == 0) {
                    emptyView.setVisibility(View.VISIBLE);
                    return;
                }
                blackList.setVisibility(View.VISIBLE);
                blackListAdapter.setList(userList);
                blackListAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initData();
                        }
                    });
                }
            }
        });
    }

    public void cancel(String anotherUserId, final int position) {
        showProgressDialog("正在取消");
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("type", 1);
        params.put("anotherUserId", anotherUserId);
        HttpClient.get("1.0/relationship/user/unbind", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                hideProgressDialog();
                blackListAdapter.removeItem(position);
                blackListAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "取消失败，请稍后再试");
            }
        });

    }
}
