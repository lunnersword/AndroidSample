package com.meidalife.shz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.JoinedServiceItem;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.widget.CheckableIconText;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by fufeng on 15/12/20.
 */
public class JoinedServiceListAdapter extends RecyclerView.Adapter<JoinedServiceListAdapter.ViewHolder> {
    private List<JoinedServiceItem> data = new ArrayList<>();
    private Context mContext;
    private Set<String> selectedSquareIds = new HashSet<>();
    private LayoutInflater inflater;

    public JoinedServiceListAdapter(Context context, List<JoinedServiceItem> data) {
        mContext = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        setData(data);
    }

    public void setData(List<JoinedServiceItem> data) {
        this.data = data;
        for (JoinedServiceItem item : data) {
            if (item.getSelected()) {
                selectedSquareIds.add(item.getItemId());
            }
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_joined_service, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final JoinedServiceItem serviceItem = data.get(position);
        holder.squareName.setText(serviceItem.getTitle());
        String descCategory = String.format(mContext.getString(R.string.joined_service_desc_category), serviceItem.getStdCategoryName());
        String descServiceType = String.format(mContext.getString(R.string.joined_service_desc_service_type), serviceItem.getServiceTypeText());
        String descFee = TextUtils.isEmpty(serviceItem.getFeeRate()) ? "" :
                String.format(mContext.getString(R.string.joined_service_desc_fee), serviceItem.getFeeRate());
        String desc = descCategory + "  " + descServiceType + "  " + descFee;
        holder.squareDesc.setText(desc);

        if (selectedSquareIds.contains(serviceItem.getItemId())) {
            holder.checkableIconText.setChecked(true);
        } else {
            holder.checkableIconText.setChecked(false);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.checkableIconText.toggle();
                if (holder.checkableIconText.isChecked()) {
                    selectedSquareIds.add(serviceItem.getItemId());
                } else {
                    selectedSquareIds.remove(serviceItem.getItemId());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public Set<String> getSelectedServiceIds() {
        return selectedSquareIds;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView squareName;
        private TextView squareDesc;
        private CheckableIconText checkableIconText;

        public ViewHolder(View itemView) {
            super(itemView);
            squareDesc = (TextView) itemView.findViewById(R.id.serviceDesc);
            squareName = (TextView) itemView.findViewById(R.id.serviceName);
            checkableIconText = (CheckableIconText) itemView.findViewById(R.id.checkbox);
        }
    }
}
