package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.activity.DelAttentionListener;
import com.meidalife.shz.rest.model.ProfileDO;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import java.util.List;

/**
 * Created by zuozheng on 15/11/10.
 * 我的收藏人的adapter
 */
public class FavoritePersonAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private List<ProfileDO> mItemList;

    DelAttentionListener delAttentionListener;

    public void setDelAttentionListener(DelAttentionListener delAttentionListener) {
        this.delAttentionListener = delAttentionListener;
    }


    public FavoritePersonAdapter(Context context, List<ProfileDO> serviceItemList) {
        this.mContext = context;
        this.mInflater = LayoutInflater.from(context);
        this.mItemList = serviceItemList;
    }

    public void setData(List<ProfileDO> discoverItemList) {
        this.mItemList = discoverItemList;
    }

    @Override
    public int getCount() {
        return mItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return mItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        final ProfileDO item = mItemList.get(position);
        if (convertView == null || convertView.getTag() == null) {
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.favorite_person_card_item, parent, false);
            viewHolder.avatar = (ImageView) convertView.findViewById(R.id.avatar);
            viewHolder.gender = (TextView) convertView.findViewById(R.id.gender);
            viewHolder.nick = (TextView) convertView.findViewById(R.id.nick);

            viewHolder.cancelView = convertView.findViewById(R.id.cancelFavorite);
            viewHolder.rootView = convertView.findViewById(R.id.favorite_person_cart);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }


        String avatarUrl = ImgUtil.getCDNUrlWithWidth(item.getAvatarUrl(),
                mContext.getResources().getDimensionPixelSize(R.dimen.discover_avatar_size));
        if (TextUtils.isEmpty(avatarUrl)) {
            //加载本地默认头像
            Uri defaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(item.getUserId()), item.getGender());
            viewHolder.avatar.setImageURI(defaultAvatarUri);
        } else {
            viewHolder.avatar.setImageURI(Uri.parse(avatarUrl));
        }


        if (mContext.getString(R.string.gender_man).equals(item.getGender())) {
            viewHolder.gender.setText(R.string.icon_gender_m);
            viewHolder.gender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
        } else if (mContext.getString(R.string.gender_women).equals(item.getGender())) {
            viewHolder.gender.setText(R.string.icon_gender_f);
            viewHolder.gender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
        } else {
            viewHolder.gender.setVisibility(View.GONE);
        }

        viewHolder.nick.setText(item.getNick());


        if (item.isLongClick()) {
            viewHolder.cancelView.setVisibility(View.VISIBLE);
        } else {
            viewHolder.cancelView.setVisibility(View.GONE);
        }

        viewHolder.rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + item.getUserId());
            }
        });

        //todo convertView 长按之后 背景变黑
        viewHolder.rootView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                item.setIsLongClick(true);
                notifyDataSetChanged();
                return false;
            }
        });

        viewHolder.cancelView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delAttentionListener.onDelClick(String.valueOf(item.getUserId()), position);
            }
        });

        return convertView;
    }

    public static class ViewHolder {
        ImageView avatar;//头像
        TextView gender;//宝贝标题
        TextView nick;//服务类型

        View cancelView;//取消收藏

        View rootView;//item root view
    }


}
