package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CoverFlowAdapter;
import com.meidalife.shz.adapter.OpusAdapter;
import com.meidalife.shz.adapter.ProfileServicesPagerAdapter;
import com.meidalife.shz.media.PlayMediaService;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.OpusDO;
import com.meidalife.shz.rest.model.PopupWindowEnum;
import com.meidalife.shz.rest.model.ProfileDO;
import com.meidalife.shz.rest.model.ProfileImageDO;
import com.meidalife.shz.rest.model.ProfileItemDO;
import com.meidalife.shz.rest.request.RequestOpus;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.task.TaskExecutor;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.view.ActionSheet;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.umeng.socialize.media.UMImage;
import com.usepropeller.routable.Router;
import com.viewpagerindicator.CirclePageIndicator;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import it.moondroid.coverflow.components.ui.containers.FeatureCoverFlow;

/**
 * @desciption 个人主页
 */

public class ProfileActivity extends BaseActivity {

    int EDIT_REQUEST_CODE = 100;
    int PAGE_SIZE = 10;

    @Bind(R.id.listView)
    ListView listView;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.iconShare)
    Button iconShare;
    @Bind(R.id.contentRoot)
    ViewGroup contentRoot;

    @Bind(R.id.bottomSpacing)
    View bottomSpacing;
    @Bind(R.id.bottomView)
    View bottomView;
    @Bind(R.id.bottomViewLine)
    View bottomViewLine;


    @Bind(R.id.icon_fav)
    TextView icon_fav;
    @Bind(R.id.icon_fav_tv)
    TextView icon_fav_tv;

    @Bind(R.id.cellPublish)
    RelativeLayout cellPublish;
    @Bind(R.id.publishView)
    View publishView;

    LinearLayout kgMemberLabel;
    LinearLayout realUserLabel;
    FontTextView tagContent;
    LinearLayout userTag;

    View listFooter;
    TextView footerMessage;
    ProgressBar footerLoading;
    Button footerReload;
    View headerView;
    SimpleDraweeView imageMain;
    FeatureCoverFlow coverflow;

    TextView textOpusCount;
    LinearLayout cellOpusEmpty;
    TextView textUserNick;
    TextView iconGender;
    TextView textInstruction;
    TextView iconLocation;
    TextView textCityName;
    TextView iconConstellation;
    TextView textConstellation;
    TextView iconSesame;
    TextView textSesame;
    ViewGroup sesameLayout;
    //微博view
    ViewGroup weiboGroup;
    TextView textWeiboAccount;
    //二维码
    ViewGroup qrCodeGroup;
    TextView qrCode;

    //认证
    ViewGroup skillAuthGroup;
    TextView skill_content;

    TextView textItemCount;
    RelativeLayout cellServicesEmptyOther;
    LinearLayout cellServices;
    CirclePageIndicator indicatorServices;
    ViewPager viewPagerServices;
    TextView iconOpusEmpty;
    //设为全局变量，用于删除时的回调
    TextView iconSkill;
    View moreServiceView;
    //头像
    SimpleDraweeView imageAvatar;

    //音频时间和播放icon
    TextView voiceTime;
    View iconVoice;
    TextView textOnlineTime;

    private SocialSharePopupWindow socialSharePopupWindow;
    private PlayVideoView mDialogView;
    private Dialog playVideoDialog;

    CoverFlowAdapter coverFlowAdapter;
    OpusAdapter adapter;

    ShareActivity shareActivity;

    String userId;

    ArrayList<OpusDO> data;
    ProfileDO profileDO;
    boolean loading = false;
    boolean complete = false;
    int page = 0;
    int cachePosition = 0;
    private String sourceImage;
    private File cropImage;
    private boolean isSelf;
    volatile boolean isPlaying = false;

    LinkedList<ProfileImageDO> profileImageList;

    int headerHeight;
    @Bind(R.id.titleBar)
    RelativeLayout titleBar;
    @Bind(R.id.action_bar_title)
    TextView action_bar_title;
    @Bind(R.id.action_bar_button_back)
    TextView action_bar_button_back;
    @Bind(R.id.action_bar_button_right)
    TextView action_bar_button_right;
    private int previous = 0;
    private int titleBarAlpha = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        ButterKnife.bind(this);

        rootView.setBackgroundColor(getResources().getColor(R.color.white));
        Bundle bundle = getIntent().getExtras();
        userId = bundle.getString("userId");

        isSelf = userId.equals(Helper.sharedHelper().getUserId()) ? true : false;


        if (isSelf) {
            initActionBar(R.string.title_activity_profile, true, true);
            mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());
            mButtonRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().openFormResult("aboutme", EDIT_REQUEST_CODE, ProfileActivity.this);
                }
            });

            RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) bottomSpacing.getLayoutParams();
            lp.height = 0;
            bottomSpacing.setLayoutParams(lp);
            publishView.setVisibility(View.VISIBLE);
        } else {
            initActionBar(R.string.title_activity_profile, true, true);
            mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());
            mButtonRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showOrHidePopMenu(v);
                }
            });
            bottomView.setVisibility(View.VISIBLE);
            bottomViewLine.setVisibility(View.VISIBLE);
            publishView.setVisibility(View.GONE);
        }

        if (headerView != null && headerView.getParent() != null) {
            listView.removeHeaderView(headerView);
        }
        headerView = getLayoutInflater().inflate(R.layout.item_profile, null);
        initTitleBarBg();

        initHeadView();
        listView.addHeaderView(headerView);
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            private boolean moveToBottom = false;
//            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (profileDO != null && profileDO.getOpusCount() > 0) {
                    boolean moveToBottom = false;
                    if (previous <= firstVisibleItem) {
                        moveToBottom = true;
                    }
                    previous = firstVisibleItem;
                    if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
                        //* 需要加载更多数据的代码 *//*
                        loadOpus();
                    }
                }
                if (firstVisibleItem == 0) {
                    changeTitleBarBg();
                }
            }
        });

        data = new ArrayList<OpusDO>();
        adapter = new OpusAdapter(this, data);
        adapter.setOnDeleteOpusListener(new OpusAdapter.RefreshProfileOpus() {
            @Override
            public void refresh() {

                int count = data.size();
                // 作品数
                textOpusCount.setText("(" + count + ")");

                // 空作品
                if (count == 0) {
                    cellOpusEmpty.setVisibility(View.VISIBLE);
                } else {
                    cellOpusEmpty.setVisibility(View.GONE);
                }

            }
        });

        listView.setAdapter(adapter);

        xhrProfile();

        iconShare.setTypeface(Helper.sharedHelper().getIconFont());

        listFooter = getLayoutInflater().inflate(R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);
        listView.addFooterView(listFooter);
        listFooter.setVisibility(View.GONE);

        shareActivity = new ShareActivity(this);

        iconShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (profileDO != null) {
                    showOrHideShareView(v);
                }
            }
        });

        // 显示引导
        showGuide();
    }

    @Override
    public boolean isInterceptTouchEvent() {
        return false;
    }

    @Override
    public void onPause() {
        super.onPause();
        //透明度还原，解决部分机型（联想等）影响其他titlebar透明度不恢复的bug
        titleBar.getBackground().setAlpha(255);
        titleBar.invalidate();
    }

    @Override
    public void onResume() {
        super.onResume();
        titleBar.getBackground().setAlpha(titleBarAlpha);
        titleBar.invalidate();
    }

    void initHeadView() {
        textOnlineTime = (TextView) headerView.findViewById(R.id.textOnlineTime);
        kgMemberLabel = (LinearLayout) headerView.findViewById(R.id.kgMemberLabel);
        realUserLabel = (LinearLayout) headerView.findViewById(R.id.realUserLabel);
        tagContent = (FontTextView) headerView.findViewById(R.id.tagContent);
        userTag = (LinearLayout) headerView.findViewById(R.id.userTag);

        textUserNick = (TextView) headerView.findViewById(R.id.textUserNick);
        iconGender = (TextView) headerView.findViewById(R.id.iconGender);
//        TextView iconWeibo = (TextView) headerView.findViewById(R.id.iconWeibo);
        textInstruction = (TextView) headerView.findViewById(R.id.textInstruction);
        iconLocation = (TextView) headerView.findViewById(R.id.iconLocation);
        textCityName = (TextView) headerView.findViewById(R.id.textCityName);
        iconConstellation = (TextView) headerView.findViewById(R.id.iconConstellation);
        textConstellation = (TextView) headerView.findViewById(R.id.textConstellation);
        iconSesame = (TextView) headerView.findViewById(R.id.iconSesame);
        textSesame = (TextView) headerView.findViewById(R.id.textSesame);
        sesameLayout = (ViewGroup) headerView.findViewById(R.id.sesameLayout);
        //微博view
        weiboGroup = (ViewGroup) headerView.findViewById(R.id.weiboGroup);
        textWeiboAccount = (TextView) headerView.findViewById(R.id.textWeiboAccount);
        //二维码
        qrCodeGroup = (ViewGroup) headerView.findViewById(R.id.qrCodeGroup);
        qrCode = (TextView) headerView.findViewById(R.id.qr_icon_tv);

        //认证
        skillAuthGroup = (ViewGroup) headerView.findViewById(R.id.skillAuthGroup);
        skill_content = (TextView) headerView.findViewById(R.id.skill_content);
        textItemCount = (TextView) headerView.findViewById(R.id.textItemCount);
        //设为全局变量，用于删除时的回调
        textOpusCount = (TextView) headerView.findViewById(R.id.textOpusCount);
        cellServicesEmptyOther = (RelativeLayout) headerView.findViewById(R.id.cellServicesEmptyOther);
        cellServices = (LinearLayout) headerView.findViewById(R.id.cellServices);
        indicatorServices = (CirclePageIndicator) headerView.findViewById(R.id.indicatorServices);
        viewPagerServices = (ViewPager) headerView.findViewById(R.id.viewPagerServices);
        iconOpusEmpty = (TextView) headerView.findViewById(R.id.iconOpusEmpty);
        //设为全局变量，用于删除时的回调
        cellOpusEmpty = (LinearLayout) headerView.findViewById(R.id.cellOpusEmpty);
        iconSkill = (TextView) headerView.findViewById(R.id.iconSkill);
        imageMain = (SimpleDraweeView) headerView.findViewById(R.id.imageMain);
        coverflow = (FeatureCoverFlow) headerView.findViewById(R.id.coverflow);
        moreServiceView = headerView.findViewById(R.id.serviceSizeMore);
        //头像
        imageAvatar = (SimpleDraweeView) headerView.findViewById(R.id.profile_avatar);
        //点击头像 跳转到设置界面
        imageAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isSelf) {
                    Router.sharedRouter().openFormResult("aboutme", EDIT_REQUEST_CODE, ProfileActivity.this);
                }
            }
        });

        //音频时间和播放icon
        voiceTime = (TextView) headerView.findViewById(R.id.voiceTime);
        iconVoice = headerView.findViewById(R.id.iconVoice);
        iconVoice.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (isSelf) {
                    Router.sharedRouter().openFormResult("aboutme", EDIT_REQUEST_CODE, ProfileActivity.this);
                } else {
                    Intent playIntent = new Intent(ProfileActivity.this, PlayMediaService.class);
                    if (profileDO != null && !TextUtils.isEmpty(profileDO.getSoundUrl())) {
                        if (!isPlaying) {
                            playIntent.putExtra(PlayMediaService.INTENT_MEDIA_PLAY, profileDO.getSoundUrl());
                            startService(playIntent);
                        } else {
                            stopService(playIntent);
                        }
                        isPlaying = !isPlaying;
                    }
                }
            }
        });

        coverflow.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                coverflow.scrollToPosition(position);
                /**
                 * coverflow 有坑
                 *
                 * position >=7的情况 这种情况下,如果用户更新图片,会导致数据position>7
                 * 再次进入个人主页,解析图片列表导致数组越界 发生crash
                 *
                 */
                if (position > profileImageList.size() || position > 6) {
                    return;
                }

                if (isSelf) {
                    final boolean isEmptyImage;
                    //防止下标越界
                    if (profileImageList.size() < position) {
                        isEmptyImage = profileImageList.get(position) == null;
                    } else
                        isEmptyImage = false;

                    final ArrayList<PopupWindowEnum> list = new ArrayList();
                    ActionSheet.Builder actionSheet = ActionSheet.createBuilder(ProfileActivity.this, getSupportFragmentManager());
                    actionSheet.setCancelButtonTitle("取消");
                    actionSheet.setCancelableOnTouchOutside(true);

                    //如果是自己 同时第一张图片
                    if (position == 3) {
                        if (TextUtils.isEmpty(profileDO.getVedioUrl())) {
                            list.add(PopupWindowEnum.TYPE_ADD_VIDEO);
                        } else {
                            list.add(PopupWindowEnum.TYPE_PLAY_VIDEO);
                            list.add(PopupWindowEnum.TYPE_REPLACE_VIDEO);
                            list.add(PopupWindowEnum.TYPE_DELETE_VIDEO);
                        }
                    }

                    if (isEmptyImage) {
                        list.add(PopupWindowEnum.TYPE_ADD_PICTURE);
                    } else {
                        list.add(PopupWindowEnum.TYPE_REPLACE_PICTURE);
                        list.add(PopupWindowEnum.TYPE_DELETE_PICTURE);
                    }

                    actionSheet.setOtherButtonTitles(list);

                    actionSheet.setListener(new ActionSheet.ActionSheetListener() {
                        @Override
                        public void onDismiss(ActionSheet actionSheet, boolean b) {
                        }

                        @Override
                        public void onOtherButtonClick(ActionSheet actionSheet, int i) {
                            cachePosition = position;
                            switch (list.get(i)) {
                                case TYPE_DELETE_VIDEO:
                                    deleteVideo();
                                    break;
                                case TYPE_REPLACE_VIDEO:
                                case TYPE_ADD_VIDEO:
                                    addVideo();
                                    break;
                                case TYPE_PLAY_VIDEO:
                                    playVideo();
                                    break;
                                case TYPE_DELETE_PICTURE:
                                    deleteImage(position);
                                    break;
                                case TYPE_ADD_PICTURE:
                                case TYPE_REPLACE_PICTURE:
                                    pickPhoto(position);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }).show();
                } else {
                    if (position == 3 && !TextUtils.isEmpty(profileDO.getVedioUrl())) {
                        playVideo();
                    }
                }
            }
        });

        coverflow.setOnScrollPositionListener(new FeatureCoverFlow.OnScrollPositionListener() {
            @Override
            public void onScrolledToPosition(int i) {
                setImageMain(profileImageList.get(i));
            }

            @Override
            public void onScrolling() {

            }
        });

        imageMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String image = (String) imageMain.getTag();
                if (image == null) {
                    return;
                }

                ArrayList<String> myImages = new ArrayList<String>();
                for (ProfileImageDO profile : profileImageList) {
                    if (profile != null) {
                        myImages.add(profile.getUri());
                    }
                }

                int index = myImages.indexOf(image);
                Bundle bundle = new Bundle();
                bundle.putStringArrayList("photos", myImages);
                bundle.putInt("index", index);
                Router.sharedRouter().open("imageBrowser", bundle);
            }
        });
    }

    //分享
    private UMImage getShareImage() {
        if (profileDO != null &&
                profileDO.getUserImgList() != null &&
                profileDO.getUserImgList().size() > 0) {

            for (int i = 0; i < profileDO.getUserImgList().size(); i++) {
                ProfileImageDO profileImageDO = profileDO.getUserImgList().get(i);
                if (profileImageDO.getPosition() == 4) {
                    return new UMImage(this, ImgUtil.getCDNUrlWithWidth(profileImageDO.getUri(), 200));
                }
            }
        }

        return new UMImage(this, R.mipmap.ic_launcher);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        if (requestCode == EDIT_REQUEST_CODE) {
            data.clear();
            adapter.notifyDataSetChanged();
            xhrProfile();
        } else if (requestCode == Constant.REQUEST_CODE_PICK_PHOTO && resultCode == RESULT_OK) {
            Bundle bundle = intent.getExtras();
            ArrayList images = bundle.getStringArrayList("images");
            int position = bundle.getInt("position");
            if (images.size() > 0) {
                sourceImage = (String) images.get(0);
                Bundle params = new Bundle();
                params.putString("image_path", sourceImage);
                params.putBoolean("return-data", false);
                params.putInt("position", position);
                cropImage = new File(ImgUtil.getEditedImagePath(this) + File.separator + "cropped_image.jpg");
                params.putParcelable(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cropImage));
                Router.sharedRouter().openFormResult("cropImage", params,
                        Constant.REQUEST_CODE_CROP_PHOTO, ProfileActivity.this);
            }
        } else if (requestCode == Constant.REQUEST_CODE_CROP_PHOTO) {
            if (resultCode == RESULT_OK) {
                Bundle bundle = intent.getExtras();
                int position = bundle.getInt("position");
                if (cropImage != null && cropImage.exists()) {
                    xhrAddImage(cropImage.getAbsolutePath(), position);
                } else {
                    xhrAddImage(sourceImage, position);
                }
            }
        } else if (requestCode == Constant.REQUEST_CODE_PUBLISH_OPUS && resultCode == RESULT_OK) {
            data.clear();
            page = 0;
            adapter.notifyDataSetChanged();
            xhrProfile();

        } else if (requestCode == Constant.REQUEST_CODE_PUBLISH_SERVICE && resultCode == RESULT_OK) {
            xhrProfile();
        }
    }

    private void xhrProfile() {
        loading = true;
        listView.setVisibility(View.GONE);
        showStatusLoading(contentRoot);
        hideStatusErrorServer();
        hideStatusErrorNetwork();

        RequestSign.getMainPageV2(userId, new HttpClient.HttpCallback<ProfileDO>() {
            @Override
            public void onSuccess(ProfileDO result) {
                loading = false;
                listView.setVisibility(View.VISIBLE);
                hideStatusLoading();
                profileDO = result;
                renderHeader();

                // 如果有作品数据直接返回不做处理了
                if (data.size() > 0) {
                    return;
                }

                if (profileDO.getOpusCount() > 0) {
                    xhrOpus();
                    previous = 0;
                    /*listView.setOnScrollListener(new AbsListView.OnScrollListener() {
                        private boolean moveToBottom = false;
                        private int previous = 0;

                        @Override
                        public void onScrollStateChanged(AbsListView view, int scrollState) {
                        }

                        @Override
                        public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                            boolean moveToBottom = false;
                            if (previous <= firstVisibleItem) {
                                moveToBottom = true;
                            }
                            previous = firstVisibleItem;
                            if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
                    *//* 需要加载更多数据的代码 *//*
                                loadOpus();
                            }
                        }
                    });*/
                }
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                loading = false;

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(contentRoot);
                    setOnClickErrorNetwork(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrProfile();
                        }
                    });
                    return;
                }

                setTextErrorServer(error.getMessage());
                showStatusErrorServer(contentRoot);
                setOnClickErrorServer(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        xhrProfile();
                    }
                });
            }
        });
    }

    public void xhrOpus() {
        loading = true;
        listFooter.setVisibility(View.VISIBLE);

        RequestOpus.listByUserId(getOpusParams(), new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                listFooter.setVisibility(View.GONE);
                loading = false;

                ArrayList<OpusDO> opusDOs = (ArrayList<OpusDO>) result;
                // empty data
                if (page == 0 && opusDOs.size() == 0) {
                }

                if (opusDOs.size() < PAGE_SIZE) {
                    complete = true;
                    listView.removeFooterView(listFooter);
                }

                data.addAll(opusDOs);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(HttpError error) {
                page--;
                loading = false;
                if (error != null) {
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        footerReload.setText("网络异常，点击重试");
                    } else {
                        footerReload.setText(error.getMessage() + "，点击重试");
                    }
                } else {
                    footerReload.setText("发生一个未知错误，点击重试");
                }
                footerReload.setVisibility(View.VISIBLE);
                footerLoading.setVisibility(View.GONE);
                footerMessage.setVisibility(View.GONE);
            }
        });
    }

    private void loadOpus() {
        if (!complete && !loading) {
            page++;
            xhrOpus();
        }
    }

    private JSONObject getOpusParams() {
        JSONObject params = new JSONObject();
        try {
            params.put("userId", userId);
            params.put("offset", PAGE_SIZE * page);
            params.put("pageSize", PAGE_SIZE);
        } catch (JSONException e) {

        }
        return params;
    }

    private void renderHeader() {

        profileImageList = new LinkedList<ProfileImageDO>();
        int max = 7;
        for (int i = 0; i < max; i++) {
            profileImageList.add(null);
        }

        for (final ProfileImageDO p : profileDO.getUserImgList()) {
            //position 小于图片列表 同时cover不包含该图
            if ((p.getPosition() - 1) < profileImageList.size() && !profileImageList.contains(p)) {
                profileImageList.remove(p.getPosition() - 1);
                profileImageList.add(p.getPosition() - 1, p);
            } else {
                //异步删除图片
                TaskExecutor.postTask(new TaskExecutor.TaggedRunnable("deleteOutIndexPic") {
                    @Override
                    public void run() {
                        aSyncDeleteImage(p.getId());
                    }
                });
            }
        }

        syncCoverFlowAdapter();

        // 设置主图
        setImageMain(profileImageList.get(0));

        //头像图片为空 显示默认图片
        ViewGroup.LayoutParams layoutParams = imageAvatar.getLayoutParams();
        String imageUrl = ImgUtil.getCDNUrlWithWidth(profileDO.getPicUrl(), layoutParams.width);
        if (TextUtils.isEmpty(imageUrl)) {
            Uri uri = ImgUtil.getDefaultAvatarUri(this, userId, profileDO.getGender());
            imageAvatar.setImageURI(uri);
        } else {
            imageAvatar.setImageURI(Uri.parse(imageUrl));
        }

        // 性别
        if (profileDO.getGender() != null) {
            if (profileDO.getGender().equals(Constant.GENDER_WOMAN_ALIAS) ||
                    profileDO.getGender().equals(Constant.GENDER_WOMAN)) {
                iconGender.setText(getResources().getString(R.string.icon_gender_f));
                iconGender.setTextColor(getResources().getColor(R.color.brand_b));
            } else {
                iconGender.setText(getResources().getString(R.string.icon_gender_m));
                iconGender.setTextColor(getResources().getColor(R.color.brand_i));
            }
        } else {
            iconGender.setVisibility(View.GONE);
        }

        textUserNick.setText(profileDO.getNick());
        textOnlineTime.setText(profileDO.getUserOnlineInfo());
//        textOrder.setText(String.valueOf(profileDO.getSellCount()));
//        orderGroup.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Router.sharedRouter().open("saleOrders/" + OrderListActivity.ROLE_TYPE_SELL);
//            }
//        });

        //音频模块
        voiceTime.setText(profileDO.getSoundLength());
        if (TextUtils.isEmpty(profileDO.getSoundUrl())) {
            voiceTime.setVisibility(View.GONE);
            if (!isSelf) {
                iconVoice.setVisibility(View.GONE);
            }
        }

        if (userId.equals(Helper.sharedHelper().getUserId())) {
            textUserNick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().openFormResult("aboutme", EDIT_REQUEST_CODE, ProfileActivity.this);
                }
            });

            textConstellation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().openFormResult("aboutme", EDIT_REQUEST_CODE, ProfileActivity.this);
                }
            });
            iconConstellation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().openFormResult("aboutme", EDIT_REQUEST_CODE, ProfileActivity.this);
                }
            });
            textInstruction.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().openFormResult("aboutme", EDIT_REQUEST_CODE, ProfileActivity.this);
                }
            });
        }


//        //禁止其他用户点击地区和出售纪录
//        if (!TextUtils.isEmpty(userId) && userId.equals(Helper.sharedHelper().getUserId())) {
//            textCityName.setEnabled(true);
//            orderGroup.setEnabled(true);
//        } else {
//            textCityName.setEnabled(false);
//            orderGroup.setEnabled(false);
//        }

        final String cityName = profileDO.getCityName() != null ? profileDO.getCityName() : "未开启";

        textCityName.setText(cityName);
        textCityName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", Constant.URL_LOCATION_INTRO + cityName);
                Router.sharedRouter().open("web", bundle);
            }
        });

        // 空作品
        if (profileDO.getOpusCount() == 0) {
            cellOpusEmpty.setVisibility(View.VISIBLE);
        } else {
            cellOpusEmpty.setVisibility(View.GONE);
        }


        // 星座
        if (profileDO.getConstellation() > 0) {
            ArrayList<HashMap<String, String>> constellationData = SignUpActivity.getConstellationData(this);
            HashMap<String, String> constellation = constellationData.get(profileDO.getConstellation() - 1);
            textConstellation.setText((String) constellation.get("name"));
            iconConstellation.setText((String) constellation.get("icon"));
        } else {
            textConstellation.setText("未设置");
            iconConstellation.setText(getResources().getString(R.string.icon_verify_code));
        }

        // 芝麻信用
        if (profileDO.getZmScore() > 0) {
            iconSesame.setTextColor(getResources().getColor(R.color.zm_credit));
            textSesame.setTextColor(getResources().getColor(R.color.zm_credit));
            textSesame.setText(profileDO.getZmLevel());
            sesameLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = "https://xy.alipay.com/auth/whatszhima.htm?view=mobile";
                    Bundle bundle = new Bundle();
                    bundle.putString("url", url);
                    Router.sharedRouter().open("web", bundle);
                }
            });
        } else {
            textSesame.setTextColor(getResources().getColor(R.color.grey_c));
            textSesame.setText("未绑定");

            if (userId.equals(Helper.sharedHelper().getUserId())) {
                sesameLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String url = "http://shenghuozhe.net/events/app_zmxy.html"; // 若未授权，跳转到授权页面
                        Bundle bundle = new Bundle();
                        bundle.putString("url", url);
                        Router.sharedRouter().open("web", bundle);
                    }
                });
            }
        }

        //空格员工
        if (profileDO.isKonggeMember()) {
            kgMemberLabel.setVisibility(View.VISIBLE);
        } else {
            kgMemberLabel.setVisibility(View.GONE);
        }

        //实名认证
        if (profileDO.isrealUser()) {
            realUserLabel.setVisibility(View.VISIBLE);
        } else {
            realUserLabel.setVisibility(View.GONE);
        }

        List<String> tagList = profileDO.getUserTag();
        if (tagList != null && tagList.size() > 0) {
            userTag.setVisibility(View.VISIBLE);
            StringBuffer sb = new StringBuffer();
            for (String tag : tagList) {
                sb.append(tag).append(" ");
            }
            tagContent.setText(sb);
        } else {
            userTag.setVisibility(View.GONE);
        }

        // 个人介绍
        String intro = profileDO.getInstruction();
        if (intro != null && !intro.equals("")) {
            //增加空格防止与右引号重叠
            intro = intro + "       ";
            textInstruction.setText(intro);
        } else {
            textInstruction.setText("这家伙很懒，什么都没有留下~      ");
        }

        // 微博账号
        if (profileDO.getWeiboAccount() != null) {
//            iconWeibo.setVisibility(View.VISIBLE);
            weiboGroup.setVisibility(View.VISIBLE);
            weiboGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", "http://m.weibo.cn/u/" + profileDO.getWeiboAccount());
                    Router.sharedRouter().open("web", bundle);
                }
            });
        } else if (userId.equals(Helper.sharedHelper().getUserId())) {
//            iconWeibo.setVisibility(View.GONE);
            textWeiboAccount.setText("未绑定微博账号");
            weiboGroup.setVisibility(View.GONE);
            weiboGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().openFormResult("aboutme", EDIT_REQUEST_CODE, ProfileActivity.this);
                }
            });
        } else {
//            iconWeibo.setVisibility(View.GONE);
            weiboGroup.setVisibility(View.GONE);
        }
        //增加二维码逻辑
        qrCodeGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (profileDO != null) {
                    showQRCode();
                }
            }
        });
        //增加认证逻辑
        List<String> certList = profileDO.getCertList();
        if (certList != null && certList.size() > 0) {
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < certList.size(); i++) {
                if (i == certList.size() - 1) {
                    str.append(certList.get(i));
                } else {
                    str.append(certList.get(i)).append("、");
                }
            }
            skill_content.setText(str.toString());
        } else {
            skillAuthGroup.setVisibility(View.GONE);
            skill_content.setText("还没有进行认证");
        }


        // 作品数
        textOpusCount.setText(String.format("(%s)", profileDO.getOpusCount()));

        // 服务数
        textItemCount.setText(String.format("(%s)", profileDO.getItemNum()));
        moreServiceView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isSelf) {
                    Router.sharedRouter().open("serviceListPublish");
                } else {
                    Router.sharedRouter().open("serviceListShow/" + profileDO.getUserId());
                }
            }
        });
        // 渲染服务列表
        if (profileDO.getItemList().size() > 0) {
            cellServices.setVisibility(View.VISIBLE);
            cellServicesEmptyOther.setVisibility(View.GONE);

            // 构造数据
            // [[ProfileItemDO, ...], ...]
            ArrayList<ArrayList<ProfileItemDO>> itemList = new ArrayList<ArrayList<ProfileItemDO>>();
            int size = profileDO.getItemList().size();
            int pages = (int) Math.ceil(size / 3.0);
            for (int j = 0; j < pages; j++) {
                ArrayList<ProfileItemDO> page = new ArrayList<ProfileItemDO>();
                int l = size - j * 3;
                l = l > 3 ? 3 : l;
                for (int i = 0; i < l; i++) {
                    page.add(profileDO.getItemList().get(i + (j * 3)));
                }
                itemList.add(page);
            }

            viewPagerServices.setAdapter(new ProfileServicesPagerAdapter(this, itemList));
            indicatorServices.setViewPager(viewPagerServices);

            // 只有一页服务时隐藏页码标识符
            if (profileDO.getItemList().size() <= 3) {
                indicatorServices.setVisibility(View.GONE);
            }
        } else {
            cellServices.setVisibility(View.GONE);
            cellServicesEmptyOther.setVisibility(View.VISIBLE);
        }


        //收藏文案修改
        if (profileDO.isUserAttention()) {
            icon_fav.setTextColor(getResources().getColor(R.color.brand_b));
            icon_fav.setText(getResources().getString(R.string.icon_star_active));
            icon_fav_tv.setText("已收藏");
        } else {
            icon_fav.setTextColor(getResources().getColor(R.color.tab_item_normal));
            icon_fav.setText(getResources().getString(R.string.icon_star_normal));
        }
    }

    private void aSyncDeleteImage(int pId) {
        RequestSign.deleteUserImage(pId, null);
    }


    private void pickPhoto(int position) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", false);
        bundle.putInt("position", position);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, ProfileActivity.this);
    }

    void showQRCode() {
        Bundle params = new Bundle();
        params.putString("iconUrl", getShareImage().toUrl());
        params.putString("content", ShareActivity.getProfileShareUrl(userId));
        params.putString("title", profileDO.getNick() != null ? profileDO.getNick() : "");

        Router.sharedRouter().open("qrCodeCreate", params);
    }

    private void setImageMain(ProfileImageDO profileImageDO) {
        if (profileImageDO != null) {
            String url = ImgUtil.getCDNUrlWithWidth(profileImageDO.getUri(),
                    getResources().getDisplayMetrics().widthPixels);
            imageMain.setImageURI(Uri.parse(url));
            imageMain.setTag(profileImageDO.getUri());
        } else {
            imageMain.setImageURI(null);
            imageMain.setTag(null);
        }
    }


    public void playVideo() {
        playVideoDialog = new AlertDialog.Builder(this, AlertDialog.THEME_HOLO_LIGHT).create();
        playVideoDialog.show();

        mDialogView = new PlayVideoView(this, profileDO.getVedioUrl());

//        mDialogView.setData(profileDO.getVedioUrl());

        mDialogView.backView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialogView.stop();
                playVideoDialog.dismiss();
            }
        });

        mDialogView.mPlayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialogView.playVideo();
            }
        });

        playVideoDialog.getWindow().setContentView(mDialogView.getView());

//        WindowManager windowManager = this.getWindowManager();
//        Display display = windowManager.getDefaultDisplay();
        WindowManager.LayoutParams lp = playVideoDialog.getWindow()
                .getAttributes();
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = 700;

        playVideoDialog.getWindow().setAttributes(lp);
        playVideoDialog.getWindow().setGravity(Gravity.CENTER);

    }

    void addVideo() {
        Router.sharedRouter().openFormResult("aboutme", EDIT_REQUEST_CODE, ProfileActivity.this);
    }

    void deleteVideo() {
        //upload

        HttpClient.get("1.0/user/delUserVideo", null, String.class, new HttpClient.HttpCallback<String>() {
            @Override
            public void onSuccess(String obj) {
                profileDO.setVedioPic("");
                profileDO.setVedioUrl("");
                syncCoverFlowAdapter();
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    private void deleteImage(final int position) {
        final ProfileImageDO profileImageDO = profileImageList.get(position);
        showProgressDialog("正在删除", false);
        if (profileImageDO == null) {
            hideProgressDialog();
            profileImageList.set(position, null);
            return;
        }
        RequestSign.deleteUserImage(profileImageDO.getId(), new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                hideProgressDialog();
                profileImageList.set(position, null);
                syncCoverFlowAdapter();
                setImageMain(null);
            }

            @Override
            public void onFailure(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "删除失败，请重试");
            }
        });
    }


    private void xhrAddImage(String path, final int position) {
        showProgressDialog("正在上传");
        RequestSign.upload(path, new MeidaRestClient.RestCallback() {

            @Override
            public void onSuccess(Object result) {
                JSONObject json = (JSONObject) result;
                try {
                    String url = json.optString("data");
                    andUpdateUserImage(url, position);
                } catch (Exception e) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(e.getMessage());
                }
            }

            @Override
            public void onFailure(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "上传失败，请重试");
            }
        });
    }

    void andUpdateUserImage(String url, final int position) {

        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();

        params.put("url", url);
        // 服务端图片position从1开始
        params.put("position", position + 1);

        if (position < profileImageList.size()) {
            ProfileImageDO cacheProfileImageDO = profileImageList.get(position);
            if (cacheProfileImageDO != null && cacheProfileImageDO.getId() > 0) {
                params.put("id", cacheProfileImageDO.getId());
            }
        }

        HttpClient.get("1.0/user/addOrUpdateUserImg", params, ProfileImageDO.class,
                new HttpClient.HttpCallback<ProfileImageDO>() {
                    @Override
                    public void onSuccess(ProfileImageDO result) {
                        hideProgressDialog();
                        profileImageList.remove(position);
                        profileImageList.add(position, result);
                        syncCoverFlowAdapter();
                        setImageMain(result);
                    }

                    @Override
                    public void onFail(HttpError error) {
                        hideProgressDialog();
                        MessageUtils.showToastCenter(error != null ? error.getMessage() : "上传失败，请重试");
                    }
                });
    }


    private void syncCoverFlowAdapter() {

        coverFlowAdapter = new CoverFlowAdapter(this, profileImageList);
        coverFlowAdapter.setVideoUrl(profileDO.getVedioUrl());
        coverFlowAdapter.setVideoPicUrl(profileDO.getVedioPic());
        coverFlowAdapter.setIsSelf(isSelf);

        coverflow.setAdapter(coverFlowAdapter);
        if (cachePosition > 0) {
            coverflow.scrollToPosition(cachePosition);
        } else {
            coverflow.scrollToPosition(3);
        }
//        cachePosition = -1;

    }


    private void showGuide() {

        final View guideGroup = findViewById(R.id.guide_group);
        String guideSelf = Helper.sharedHelper().getStringUserInfo(Constant.GUIDE_SELF);

        if (userId.equals(Helper.sharedHelper().getStringUserInfo(Constant.USER_ID)) && !Constant.GUIDE_SELF.equals(guideSelf)) {
            guideGroup.setVisibility(View.VISIBLE);
            guideGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // do nothing ...
                }
            });
            final View picsGuide = findViewById(R.id.guide_self_pics);
            final View descGuide = findViewById(R.id.guide_self_desc);
            picsGuide.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    picsGuide.setVisibility(View.GONE);
                    descGuide.setVisibility(View.VISIBLE);
                }
            });
            descGuide.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    descGuide.setVisibility(View.GONE);
                    guideGroup.setVisibility(View.GONE);
                    Helper.sharedHelper().setStringUserInfo(Constant.GUIDE_SELF, Constant.GUIDE_SELF);
                }
            });
        } else {
            guideGroup.setVisibility(View.GONE);
        }

    }

    private void showOrHideShareView(View v) {
        if (socialSharePopupWindow == null) {
            String title = null;
            String nick = profileDO.getNick() != null ? profileDO.getNick() : "";
            String content = null;
            String url = ShareActivity.getProfileShareUrl(userId);
            if (userId.equals(Helper.sharedHelper().getUserId())) {
                title = String.format(getString(R.string.my_profile_share_title), nick);
                content = getString(R.string.my_profile_share_content);
            } else {
                title = getString(R.string.profile_share_title);
                content = getString(R.string.profile_share_content);
            }

            socialSharePopupWindow = new SocialSharePopupWindow(this, shareActivity,
                    SocialSharePopupWindow.SHARE_TYPE_PROFILE);
            socialSharePopupWindow.setShareUrl(url);
            socialSharePopupWindow.setShareTitle(title);
            socialSharePopupWindow.setShareUserName(nick);
            socialSharePopupWindow.setShareDescription(content);
            socialSharePopupWindow.setShareImage(getShareImage());
        }
        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    public void handleShare(View v) {
        showOrHideShareView(v);
    }

    public void handleFavorite(View v) {
        if (null != profileDO && profileDO.isUserAttention()) {
            delAttention();
        } else {
            attention();
        }
    }

    public void handleChat(View v) {
        String action = "chat/";
        action += userId;

        if (Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().open(action);
        } else {
            Bundle bundle = new Bundle();
            bundle.putString("action", action);
            Router.sharedRouter().open("signin", bundle);
        }
    }

    private void attention() {
        try {
            com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
            params.put("attentionUserId", userId);
            HttpClient.get("1.0/attention/addUserAttention", params, null, new HttpClient.HttpCallback<Object>() {
                @Override
                public void onSuccess(Object obj) {
                    MessageUtils.showToast("收藏成功");
                    icon_fav.setTextColor(getResources().getColor(R.color.brand_b));
                    icon_fav.setText(getResources().getString(R.string.icon_star_active));
                    icon_fav_tv.setText("已收藏");
                    profileDO.setUserAttention(true);
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToast("收藏失败");
                }
            });
        } catch (Exception e) {
        }
    }

    private void delAttention() {
        try {
            com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
            params.put("attentionUserId", userId);
            HttpClient.get("1.0/attention/delUserAttention", params, null, new HttpClient.HttpCallback<Object>() {
                @Override
                public void onSuccess(Object obj) {
                    MessageUtils.showToast("取消收藏成功");
                    icon_fav.setTextColor(getResources().getColor(R.color.tab_item_normal));
                    icon_fav.setText(getResources().getString(R.string.icon_star_normal));
                    icon_fav_tv.setText("收藏");
                    profileDO.setUserAttention(false);
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToast("取消收藏失败");
                }
            });
        } catch (Exception e) {
        }
    }

    public void handleHidePublish(View view) {
        cellPublish.setVisibility(View.GONE);
    }

    public void handleShowPublish(View view) {
        cellPublish.setVisibility(View.VISIBLE);
    }

    //发布服务
    public void handlePublishService(View view) {
        if (userId.equals(Helper.sharedHelper().getUserId())) {
            Router.sharedRouter().openFormResult("publish", Constant.REQUEST_CODE_PUBLISH_SERVICE, ProfileActivity.this);
            cellPublish.setVisibility(View.GONE);
        }
    }

    //发布作品
    public void handlePublishOpus(View view) {
        if (userId.equals(Helper.sharedHelper().getUserId())) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("isFromProfile", true);
            Router.sharedRouter().openFormResult("publishOpus", bundle, Constant.REQUEST_CODE_PUBLISH_OPUS, ProfileActivity.this);
            cellPublish.setVisibility(View.GONE);
        }
    }

    @Override
    protected void doReport() {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", String.valueOf(userId));
        intent.putExtra("target", Constant.REPORT_TYPE_USER);
        startActivity(intent);
    }

    //初始化导航背景
    private void initTitleBarBg() {
        // titleBar.getBackground().setAlpha(0);
        action_bar_title.setTextColor(getResources().getColor(R.color.brand_c));
        action_bar_button_back.setTextColor(Color.argb(255, 255, 255, 255));
        iconShare.setTextColor(Color.argb(255, 255, 255, 255));
        action_bar_button_right.setTextColor(Color.argb(255, 255, 255, 255));
        // 通知标题栏刷新显示
        //  titleBar.invalidate();
    }

    //改变导航背景
    private void changeTitleBarBg() {
        // 获取头布局
        if (headerView != null) {
            // 获取头布局现在的最上部的位置的相反数
            int top = -headerView.getTop();
            // 获取头布局的高度
            headerHeight = headerView.getHeight();
            // 满足这个条件的时候，是头布局在Listview的最上面第一个控件的时候，只有这个时候，我们才调整透明度
            if (top <= headerHeight / 5 && top >= 0) {
                // 获取当前位置占头布局高度的百分比
                float f = (float) top / (float) (headerHeight / 5);
                titleBarAlpha = (int) (f * 255);
                titleBar.getBackground().setAlpha(titleBarAlpha);
                // 通知标题栏刷新显示
                titleBar.invalidate();
                action_bar_title.setTextColor(Color.argb((int) (f * 255), 26, 26, 26));
                if (255 - (int) (f * 255) * 2 > 0) {
                    action_bar_button_back.getBackground().setAlpha(255 - (int) (f * 255) * 2);
                    action_bar_button_back.setTextColor(Color.argb(255 - (int) (f * 255) * 2, 255, 255, 255));
                    iconShare.getBackground().setAlpha(255 - (int) (f * 255) * 2);
                    iconShare.setTextColor(Color.argb(255 - (int) (f * 255) * 2, 255, 255, 255));
                    action_bar_button_right.getBackground().setAlpha(255 - (int) (f * 255) * 2);
                    action_bar_button_right.setTextColor(Color.argb(255 - (int) (f * 255) * 2, 255, 255, 255));
                } else {
                    action_bar_button_back.getBackground().setAlpha(0);
                    action_bar_button_back.setTextColor(Color.argb((int) (f * 255), 26, 26, 26));
                    iconShare.getBackground().setAlpha(0);
                    iconShare.setTextColor(Color.argb((int) (f * 255), 26, 26, 26));
                    action_bar_button_right.getBackground().setAlpha(0);
                    action_bar_button_right.setTextColor(Color.argb((int) (f * 255), 26, 26, 26));
                }

            } else if (top > headerHeight / 5) {
                titleBarAlpha = 255;
                titleBar.getBackground().setAlpha(titleBarAlpha);
                // 通知标题栏刷新显示
                titleBar.invalidate();
                action_bar_title.setTextColor(Color.argb(255, 26, 26, 26));
                action_bar_button_back.setTextColor(Color.argb(255, 26, 26, 26));
                iconShare.setTextColor(Color.argb(255, 26, 26, 26));
                action_bar_button_right.setTextColor(Color.argb(255, 26, 26, 26));
                action_bar_button_back.getBackground().setAlpha(0);
                iconShare.getBackground().setAlpha(0);
                action_bar_button_right.getBackground().setAlpha(0);
            }
        }
    }
}
