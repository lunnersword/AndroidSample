package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.view.IconTextView;
import com.usepropeller.routable.Router;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 周边格子列表 item adapter
 * Created by zhq on 15/12/20.
 */
public class SurroundSquareListAdapter extends RecyclerView.Adapter<SurroundSquareListAdapter.ViewHolder> {
    LayoutInflater mInflater;
    Context mContext;
    List<SquareDO> mData;

//    private final int userAvatarMaxSize = 6;
//    private final int serviceMaxSize = 2;
//
//    private boolean isFirst = true;

    static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.rootView)
        View rootView;

        //格子名称
        @Bind(R.id.picView)
        SimpleDraweeView squarePic;
        @Bind(R.id.textName)
        TextView squareName;
        @Bind(R.id.textTypeDesc)
        TextView squareType;

        //格主信息
//        @Bind(R.id.gezuInfoView)
//        View gezuInfoView;
//        @Bind(R.id.squareManagerNick)
//        TextView squareManagerNick;
//        @Bind(R.id.squareManagerGender)
//        TextView squareManagerGender;

        //服务数
        @Bind(R.id.itemCount)
        TextView serviceCount;

//        @Bind(R.id.itemCountIncrement)
//        TextView itemCountIncrement;

        @Bind(R.id.serviceCountDynamic)
        View serviceCountDynamic;
        @Bind(R.id.squareServiceIncCount)
        TextView squareServiceIncCount;
        @Bind(R.id.squareServiceIncStatus)
        IconTextView squareServiceIncStatus;

        //人数
        @Bind(R.id.userCount)
        TextView userCount;
        @Bind(R.id.userCountDynamic)
        View userCountDynamic;
        @Bind(R.id.userIncCount)
        TextView userIncCount;
        @Bind(R.id.squareUserCountIncStatus)
        IconTextView squareUserCountIncStatus;

//        @Bind(R.id.userCountIncrement)
//        TextView userCountIncrement;

        @Bind(R.id.statusDesc)
        TextView statusDesc;

        @Bind(R.id.squareHostTagView)
        ImageView squareHostTagView;

    }

    public SurroundSquareListAdapter(Context context, List<SquareDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    public void setData(List<SquareDO> mData) {
        this.mData = mData;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = mInflater.inflate(R.layout.item_surround_square_list, parent, false);
        ViewHolder holder = new ViewHolder(convertView);

//        int spacingInPixels = mContext.getResources().getDimensionPixelSize(R.dimen.discover_item_margin);
//        holder.serviceRecyclerView.addItemDecoration(new SurroundSquareDividerItemDecoration(spacingInPixels));
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final SquareDO item = mData.get(position);

        holder.squarePic.setImageURI(Uri.parse(item.getGeziPicUrl()));
        holder.squareName.setText(item.getGeziName());
        holder.squareType.setText("[" + item.getGeziTypeDesc() + "]");

        //todo 格主 格主性别 暂时不显示

        if (item.isJoined()) {
//            UserDO gezhu = item.getGezhu();
            if (item.isGezhu()) {
                holder.squareHostTagView.setImageDrawable(mContext.getResources().getDrawable(R.mipmap.surround_square_status_gezhu));
            } else {
                holder.squareHostTagView.setImageDrawable(mContext.getResources().getDrawable(R.mipmap.surround_square_status_joined));
            }
            holder.squareHostTagView.setVisibility(View.VISIBLE);
        } else {
            holder.squareHostTagView.setImageDrawable(null);
            holder.squareHostTagView.setVisibility(View.VISIBLE);
        }

        holder.serviceCount.setText("服务数：" + item.getItemCount());
        holder.squareServiceIncCount.setText("(" + item.getItemCountIncrement());

        if (item.getItemCountIncrement() > 0) {
            holder.serviceCountDynamic.setVisibility(View.VISIBLE);
        } else {
            holder.serviceCountDynamic.setVisibility(View.GONE);
        }

        if (item.getItemCountArrow() == 1) {
            holder.squareServiceIncStatus.setText(mContext.getResources().getString(R.string.icon_increase));
        } else if (item.getItemCountArrow() == -1) {
            holder.squareServiceIncStatus.setText(mContext.getResources().getString(R.string.icon_decrease));
        } else {
            holder.squareServiceIncStatus.setText("");
        }

        holder.userCount.setText("成员数：" + item.getUserCount());
        holder.userIncCount.setText("(" + item.getUserCountIncrement());

        if (item.getUserCountArrow() == 1) {
            holder.squareUserCountIncStatus.setText(mContext.getResources().getString(R.string.icon_increase));
        } else if (item.getUserCountArrow() == -1) {
            holder.squareUserCountIncStatus.setText(mContext.getResources().getString(R.string.icon_decrease));
        } else {
            holder.squareUserCountIncStatus.setText("");
        }

        if (item.getUserCountIncrement() > 0) {
            holder.userCountDynamic.setVisibility(View.VISIBLE);
        } else {
            holder.userCountDynamic.setVisibility(View.GONE);
        }


        holder.statusDesc.setText("");

        holder.rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("squareindex/" + item.getGeziId());

                try {
                    LogParam param = new LogParam();
                    param.setType(LogUtil.TYPE_CUSTOMIZE);
                    param.setEid(LogUtil.EVENT_ID_SURROUND_SQUARE_LIST_ITEM_CLICK);
                    param.setGeziid(String.valueOf(item.getGeziId()));
                    LogUtil.log(param);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

}
