package com.meidalife.shz.activity.fragment;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.huewu.pla.lib.MultiColumnListView;
import com.huewu.pla.lib.internal.PLA_AbsListView;
import com.huewu.pla.lib.internal.PLA_AdapterView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.DiscoverAdapter;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.DiscoverItem;
import com.umeng.analytics.MobclickAgent;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class DiscoverFragment extends BaseFragment implements SwipeRefreshLayout.OnRefreshListener {
    private static final String LOG_TAG = "DiscoverFragment";
    private static final int PAGE_SIZE = 10;

    private int currentPage = 0;
    private boolean isLoading = false;

    @Bind(R.id.discover_list)
    MultiColumnListView mAdapterView;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.cellStatusDotLoading)
    LinearLayout cellStatusDotLoading;
    @Bind(R.id.cellStatusErrorNetwork)
    LinearLayout cellStatusErrorNetwork;
    @Bind(R.id.cellStatusErrorServer)
    LinearLayout cellStatusErrorServer;
    @Bind(R.id.textStatusErrorServer)
    TextView textStatusErrorServer;

    private AnimationDrawable loadingAnimation;
    private DiscoverAdapter discoverAdapter;
    private View listFooter;
    private TextView footerMessage;
    private ProgressBar footerLoading;
    private Button footerReload;

    private List<DiscoverItem> discoverItemList = Collections.synchronizedList(new ArrayList<DiscoverItem>());

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_discover, container, false);

        ButterKnife.bind(this, rootView);

        listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);

        cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadData(null, true);
            }
        });
        cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadData(null, true);
            }
        });

        mAdapterView.setOnItemClickListener(new PLA_AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(PLA_AdapterView<?> parent, View view, int position, long id) {
                SimpleDraweeView avatar = (SimpleDraweeView) view.findViewById(R.id.avatar);
                String opusId = (String) avatar.getTag();
                Router.sharedRouter().open("opusShowDetail/" + opusId);
            }
        });

        mAdapterView.setOnScrollListener(new PLA_AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(PLA_AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        listFooter.setVisibility(View.VISIBLE);
                        footerLoading.setVisibility(View.VISIBLE);
                        loadData(null, false);
                    }
                }
            }

            @Override
            public void onScroll(PLA_AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }
        });

        mAdapterView.addFooterView(listFooter);

        swipeRefreshLayout.setOnRefreshListener(this);

        initAdapter();

        loadData(null, true);

        Log.d(LOG_TAG, "onCreateView");
        mAdapterView.setSelector(getResources().getDrawable(R.drawable.discover_item_bg));
        return rootView;
    }

    @Override
    public void onResume() {
        Log.d(LOG_TAG, "onResume");
        super.onResume();
        MobclickAgent.onPageStart("discoverScreen");
    }

    @Override
    public void onDestroyView() {
        Log.d(LOG_TAG, "onDestroyView");
        super.onDestroyView();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(LOG_TAG, "onPause");
        MobclickAgent.onPageEnd("discoverScreen");
    }

    private void initAdapter() {
        discoverAdapter = new DiscoverAdapter(getActivity(), discoverItemList);
        mAdapterView.setAdapter(discoverAdapter);
    }

    private void loadData(HttpClient.HttpCallback<JSONObject> callback, boolean showLoading) {
        if (!Helper.isNetworkConnected(getActivity())) {
            showNetworkError();
            return;
        }
        if (isLoading) {
            return;
        }
        isLoading = true;
        if (showLoading) {
            showStatusLoading();
        }
        try {
            JSONObject params = new JSONObject();
            params.put("pageSize", PAGE_SIZE);
            params.put("offset", currentPage * PAGE_SIZE);
            String locateCity = SHZApplication.getInstance().getLocationManager().getLocation().getCityCode();
            String selectCity = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
            if (!TextUtils.isEmpty(selectCity)) {
                params.put("cityCode", selectCity);
            } else if (!TextUtils.isEmpty(locateCity)) {
                params.put("cityCode", locateCity);
            }

            if (callback == null) {
                HttpClient.get("2.0/explore", params, null, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject json) {
                        showDiscoverList();
                        Log.d("DiscoverFragment", "discover string:" + json.toJSONString());
                        JSONArray jsonArray = json.getJSONArray("opusList");
                        if (null == jsonArray) {
                            return;
                        }
                        for (int i = 0; i < jsonArray.size(); i++) {
                            JSONObject discoverData = jsonArray.getJSONObject(i);
                            DiscoverItem item = transferToDiscoverItem(discoverData);
                            discoverItemList.add(item);
                        }

                        if (!discoverItemList.isEmpty() && !jsonArray.isEmpty()) {
                            discoverAdapter.setData(discoverItemList);
                            discoverAdapter.notifyDataSetChanged();
                            currentPage++;
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                            showNetworkError();
                            return;
                        }

                        showServerError();
                    }
                });
            } else {
                HttpClient.get("2.0/explore", params, null, callback);
            }
        } catch (Exception e) {
            e.printStackTrace();
            showDiscoverList();
        }
    }

    private DiscoverItem transferToDiscoverItem(JSONObject data) {
        DiscoverItem item = new DiscoverItem();
        item.setNick(data.getString("nick"));
        item.setAvatar(data.getString("avatar"));
        item.setBottomColor(data.getString("bottomColor"));
        item.setImage(data.getString("image"));
        item.setOpusId(data.getString("opusId"));
        item.setUserId(data.getString("userId"));
        item.setGender(data.getString("gender"));
        item.setViewCount(data.getInteger("viewCount"));
        item.setWidth(data.getInteger("width"));
        item.setHeight(data.getInteger("height"));
        return item;
    }

    private void showServerError() {
        swipeRefreshLayout.setRefreshing(false);
        swipeRefreshLayout.setVisibility(View.GONE);
        hideStatusLoading();
        cellStatusErrorServer.setVisibility(View.VISIBLE);
        cellStatusErrorNetwork.setVisibility(View.GONE);
        isLoading = false;
    }

    private void showNetworkError() {
        swipeRefreshLayout.setRefreshing(false);
        swipeRefreshLayout.setVisibility(View.GONE);
        hideStatusLoading();
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.VISIBLE);
        isLoading = false;
    }

    private void showDiscoverList() {
        swipeRefreshLayout.setRefreshing(false);
        swipeRefreshLayout.setVisibility(View.VISIBLE);
        hideStatusLoading();
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.GONE);

        listFooter.setVisibility(View.GONE);
        footerLoading.setVisibility(View.GONE);
        footerMessage.setVisibility(View.GONE);
        footerReload.setVisibility(View.GONE);
        isLoading = false;
    }

    private void showStatusLoading() {
        footerMessage.setText(R.string.loading);
        listFooter.setVisibility(View.GONE);
        footerLoading.setVisibility(View.GONE);
        footerMessage.setVisibility(View.VISIBLE);
        footerReload.setVisibility(View.GONE);
        swipeRefreshLayout.setVisibility(View.GONE);
        try {
            cellStatusDotLoading.setVisibility(View.VISIBLE);
//            loadingAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.loading_animation);
//            ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
//            loadingImage.setBackgroundDrawable(loadingAnimation);
//            loadingAnimation.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideStatusLoading() {
        try {
            if (cellStatusDotLoading != null) {
                cellStatusDotLoading.setVisibility(View.GONE);
//                if (loadingAnimation != null) {
//                    loadingAnimation.stop();
//                    loadingAnimation = null;
//                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRefresh() {
        currentPage = 0;
        loadData(new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject json) {
                showDiscoverList();
                JSONArray jsonArray = json.getJSONArray("opusList");
                if (null == jsonArray || jsonArray.size() == 0) {
                    return;
                }
                discoverItemList.clear();

                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject discoverData = jsonArray.getJSONObject(i);
                    DiscoverItem item = transferToDiscoverItem(discoverData);
                    discoverItemList.add(item);
                }

                if (!discoverItemList.isEmpty()) {
                    discoverAdapter.setData(discoverItemList);
                    discoverAdapter.notifyDataSetChanged();
                    currentPage++;
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showNetworkError();
                } else {
                    showServerError();
                }
            }
        }, true);
    }
}

