package com.meidalife.shz.activity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServicePropDo;
import com.meidalife.shz.rest.model.ServicePropValue;
import com.meidalife.shz.widget.CheckableIconText;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by fufeng on 16/3/11.
 */
public class SinglePropValueAdapter extends BaseAdapter {
    private Context mContext;
    private List<ServicePropValue> propValueList;
    private Set<String> selectedIds = new HashSet<>();
    private OnPropSelectListener onPropSelectListener;

    public interface OnPropSelectListener {
        void onSelect(ServicePropValue value);
    }

    public SinglePropValueAdapter(Context context,
                                  List<ServicePropValue> propValueList) {
        mContext = context;
        this.propValueList = propValueList;
    }

    public void setOnPropSelectListener(OnPropSelectListener onPropSelectListener) {
        this.onPropSelectListener = onPropSelectListener;
    }

    @Override
    public int getCount() {
        return propValueList == null ? 0 : propValueList.size();
    }

    @Override
    public Object getItem(int position) {
        return propValueList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (null == convertView) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.item_single_prop_value, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.checkableIconText = (CheckableIconText) convertView.findViewById(R.id.checkbox);
            viewHolder.title = (TextView) convertView.findViewById(R.id.title);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        final ServicePropValue propValue = propValueList.get(position);
        viewHolder.title.setText(propValue.getName());
        viewHolder.checkableIconText.setChecked(selectedIds.contains(propValue.getVid()));

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedIds.clear();
                selectedIds.add(propValue.getVid());
                notifyDataSetChanged();
                if (onPropSelectListener != null) {
                    onPropSelectListener.onSelect(propValue);
                }
            }
        });
        return convertView;
    }

    public Set<String> getSelectedIds() {
        return selectedIds;
    }

    public void setSelectedIds(Set<String> selectedIds) {
        this.selectedIds = selectedIds;
    }

    class ViewHolder {
        TextView title;
        CheckableIconText checkableIconText;
    }
}
