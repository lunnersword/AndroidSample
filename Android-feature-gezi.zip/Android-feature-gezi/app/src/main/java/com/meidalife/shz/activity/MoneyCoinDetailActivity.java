package com.meidalife.shz.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TabWidget;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.MoneyCoinDetailFragment;
import com.meidalife.shz.util.MoneyDetailEnum;

/**
 * Created by shijian on 15/7/8.
 */
public class MoneyCoinDetailActivity extends FragmentActivity {

    public static final String COIN_TYPE = "m";
    public static final String MONEY_TYPE = "b";

    private FragmentTabHost mTabHost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        Context context = getApplicationContext();
        setContentView(R.layout.money_coin_detail);

        String type = MONEY_TYPE;
        Bundle extras = getIntent().getExtras();
        Object typeObj = extras.get("type");
        if (typeObj != null) {
            type = extras.getString("type");
            if (MONEY_TYPE.equals(type)) {
                initActionBar(R.string.title_money_detail, true);
            } else if (COIN_TYPE.equals(type)) {
                initActionBar(R.string.title_coin_detail, true);
            }
        } else {
            type = MONEY_TYPE;
        }

        mButtonBack = (Button) findViewById(R.id.action_bar_button_back);
        mTextTitle = (TextView) findViewById(R.id.action_bar_title);
        mButtonRight = (Button) findViewById(R.id.action_bar_button_right);

        mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(), R.id.realtabcontent);

        // 控制tab整体的布局
        TabWidget widget = mTabHost.getTabWidget();
        widget.setDividerDrawable(null);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER;
        widget.setPadding(
                (int) Helper.convertDpToPixel(50, context),
                (int) Helper.convertDpToPixel(20, context),
                (int) Helper.convertDpToPixel(50, context),
                (int) Helper.convertDpToPixel(20, context));
        widget.setBackgroundColor(getResources().getColor(R.color.grey_e));
        widget.setLayoutParams(params);


        Bundle all = new Bundle();
        all.putString("type", type);
        all.putString("data", MoneyDetailEnum.All.getCode());
        mTabHost.addTab(getTabSpecView(MoneyDetailEnum.All.getText(), R.drawable.money_detail_tab_left_selector), MoneyCoinDetailFragment.class, all);
        Bundle in = new Bundle();
        in.putString("type", type);
        in.putString("data", MoneyDetailEnum.IN.getCode());
        mTabHost.addTab(getTabSpecView(MoneyDetailEnum.IN.getText(), R.drawable.money_detail_tab_center_selector), MoneyCoinDetailFragment.class, in);
        Bundle out = new Bundle();
        out.putString("type", type);
        out.putString("data", MoneyDetailEnum.OUT.getCode());
        mTabHost.addTab(getTabSpecView(MoneyDetailEnum.OUT.getText(), R.drawable.money_detail_tab_right_selector), MoneyCoinDetailFragment.class, out);

        mTabHost.setCurrentTabByTag(MoneyDetailEnum.All.getText());
    }

    private FragmentTabHost.TabSpec getTabSpecView(String tag, int selector) {
        View view = getLayoutInflater().inflate(R.layout.money_coin_tab, null);
        TextView tabText = (TextView) view.findViewById(R.id.tabText);
        tabText.setText(tag);
        tabText.setBackgroundResource(selector);
        return mTabHost.newTabSpec(tag).setIndicator(view);
    }


    /*
    ============= 从BaseActivity拷贝，后续抽取为工具类，解决多继承问题 ===============
     */


    public Button mButtonBack;
    public TextView mTextTitle;
    public Button mButtonRight;

    public void handleBack(View view) {
        onBackPressed();
    }

    public void initActionBar(int resId) {
        initActionBar(resId, false, false);
    }

    public void initActionBar(int resId, Boolean showBackButton) {
        initActionBar(resId, showBackButton, false);
    }

    public void initActionBar(int resId, Boolean showBackButton, Boolean showRightButton) {
        getActionBarBackButton();
        getActionBarRightButton();
        setActionBarTitle(resId);
        if (showBackButton) {
            showActionBarBackButton();
        } else {
            hideActionBarBackButton();
        }
        if (showRightButton) {
            showActionBarRightButton();
        } else {
            hideActionBarRightButton();
        }
    }

    private void getActionBarBackButton() {
        if (mButtonBack == null) {
            mButtonBack = (Button) findViewById(R.id.action_bar_button_back);
        }
        if (mButtonBack != null) {
            mButtonBack.setTypeface(Helper.sharedHelper().getIconFont());
        }
    }

    private void getActionBarRightButton() {
        if (mButtonRight == null) {
            mButtonRight = (Button) findViewById(R.id.action_bar_button_right);
        }
    }

    public void setActionBarTitle(int resId) {
        setActionBarTitle(getString(resId));
    }

    public void setActionBarTitle(String title) {
        if (mTextTitle == null) {
            mTextTitle = (TextView) findViewById(R.id.action_bar_title);
        }
        if (mTextTitle != null) {
            mTextTitle.setText(title);
        }
    }

    public void showActionBarBackButton() {
        if (mButtonBack != null) {
            mButtonBack.setVisibility(View.VISIBLE);
        }
    }

    public void hideActionBarBackButton() {
        if (mButtonBack != null) {
            mButtonBack.setVisibility(View.GONE);
        }
    }

    public void showActionBarRightButton() {
        if (mButtonRight != null) {
            mButtonRight.setVisibility(View.VISIBLE);
        }
    }

    public void hideActionBarRightButton() {
        if (mButtonRight != null) {
            mButtonRight.setVisibility(View.GONE);
        }
    }


}
