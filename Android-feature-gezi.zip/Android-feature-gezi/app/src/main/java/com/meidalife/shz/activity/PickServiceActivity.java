package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ServiceListAdapter;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

public class PickServiceActivity extends BaseActivity {

    int PAGE_SIZE = 20;
    int page = 0;
    boolean loading = true;
    boolean complete = false;
    ArrayList<ServiceItem> data;
    ServiceListAdapter adapter;
    String selectItemId;

    @Bind(R.id.listView)
    ListView listView;
    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.cellEmptyData)
    RelativeLayout cellEmptyData;
    @Bind(R.id.publishListEmptyIcon)
    TextView publishListEmptyIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_service);
        initActionBar(R.string.title_activity_pick_service, true);
        ButterKnife.bind(this);

        publishListEmptyIcon.setTypeface(Helper.sharedHelper().getIconFont());

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            selectItemId = bundle.getString("itemId");
        }

        data = new ArrayList<ServiceItem>();
        adapter = new ServiceListAdapter(this, data);
        listView.setAdapter(adapter);
        listView.setVisibility(View.GONE);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ServiceItem item = data.get(position);
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putString("itemId", item.getItemId());
                bundle.putString("tag", item.getTag());
                bundle.putString("image", item.getImages().get(0));
                bundle.putString("price", item.getPrice());
                bundle.putString("pointSupport", String.valueOf(item.getPointSupport()));
                bundle.putString("serviceType", String.valueOf(item.getServiceType()));
                bundle.putString("cityName", item.getCityName());
                intent.putExtras(bundle);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            private boolean moveToBottom = false;
            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (previous < firstVisibleItem) {
                    moveToBottom = true;
                } else if (previous > firstVisibleItem) {
                    moveToBottom = false;
                }
                previous = firstVisibleItem;

                if (totalItemCount == firstVisibleItem + visibleItemCount && moveToBottom) {
                    /* 需要加载更多数据的代码 */
                    loadNext();
                }
            }
        });
        xhrServices();
    }

    private void xhrServices() {
        loading = true;
        showStatusLoading(rootView);
        hideStatusErrorNetwork();
        hideStatusErrorServer();
        RequestService.getMyPublishList(getParams(page), new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                loading = false;
                hideStatusLoading();

                ArrayList<ServiceItem> items = (ArrayList<ServiceItem>) result;
                if (items.size() < PAGE_SIZE) {
                    complete = true;
                }

                data.addAll(items);
                adapter.notifyDataSetChanged();

                // empty data
                if (data.size() == 0) {
                    listView.setVisibility(View.GONE);
                    cellEmptyData.setVisibility(View.VISIBLE);
                } else {
                    listView.setVisibility(View.VISIBLE);
                    cellEmptyData.setVisibility(View.GONE);
                }

                if (selectItemId != null) {
                    for (int i = 0; i < data.size(); i++) {
                        if (data.get(i).getItemId().equals(selectItemId)) {
                            listView.setItemChecked(i, true);
                        }
                    }
                }
            }

            @Override
            public void onFailure(HttpError error) {
                loading = false;
                hideStatusLoading();

                // refresh
                if (page == 0) {
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        showStatusErrorNetwork(rootView);
                        setOnClickErrorNetwork(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                xhrServices();
                            }
                        });
                        return;
                    }

                    showStatusErrorServer(rootView);
                    setTextErrorServer(error != null ? error.getMessage() : getResources().getString(R.string.error_server_500));
                    setOnClickErrorServer(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrServices();
                        }
                    });
                }
                // load next
                else {
                    page--;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            MessageUtils.showToastCenter("网络异常，上拉重试");
                        } else {
                            MessageUtils.showToastCenter(error.getMessage() + "，上拉重试");
                        }
                    } else {
                        MessageUtils.showToastCenter("发生一个未知错误，上拉重试");
                    }
                }
            }
        });
    }

    private JSONObject getParams(int page) {
        JSONObject params;
        try {
            params = new JSONObject();
            params.put("userId", Helper.sharedHelper().getUserId());
            params.put("pageSize", PAGE_SIZE);
            params.put("offset", page * PAGE_SIZE);
            params.put("showBlock", 0);
        } catch (JSONException e) {
            params = null;
        }

        return params;
    }

    private void loadNext() {
        if (!loading && !complete) {
            page++;
            Log.i("Taber", "load next profile");
            xhrServices();
        }
    }
}
