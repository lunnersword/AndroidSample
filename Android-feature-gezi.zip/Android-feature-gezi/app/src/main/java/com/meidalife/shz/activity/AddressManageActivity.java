package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.AddressAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.request.RequestAddress;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

/**
 * 收货地址管理（地址列表）
 */
public class AddressManageActivity extends BaseActivity {

    ListView listView;
    int selectedIndex;
    ArrayList addresses;
    AddressAdapter adapter;
    LinearLayout rootView;

    final int REQUEST_CODE_SIGNIN = 300;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address_manage);
        initActionBar(R.string.title_activity_address_manage, true);

        mButtonRight.setText("确定");
        mButtonRight.setEnabled(false);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddressItem item = (AddressItem) addresses.get(selectedIndex);
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putString("addressId", item.getAddressId());
                bundle.putString("addressName", item.getAddressName());
                bundle.putString("contactorName", item.getContactorName());
                bundle.putString("contactorPhone", item.getContactorPhone());
                intent.putExtras(bundle);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        addresses = new ArrayList();
        listView = (ListView) findViewById(R.id.addresses);
        rootView = (LinearLayout) findViewById(R.id.root_view);
        adapter = new AddressAdapter(this, addresses, Constant.ADDRESS_ADAPTER_TYPE_MANAGE);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position > 1) {

                    Bundle bundle = new Bundle();
                    AddressItem item = (AddressItem) addresses.get(position - 2);
                    bundle.putString(Constant.EXTRA_TAG_ADDRESS_ID, String.valueOf(item.getAddressId()));
                    Router.sharedRouter().openFormResult("address/change", bundle,
                            Constant.REQUEST_CODE_CHANGE_ADDRESS, AddressManageActivity.this);
                    selectedIndex = position - 2;
                } else if (position == 0) {
                    Router.sharedRouter().openFormResult("addresses/create",
                            Constant.REQUEST_CODE_CREATE_ADDRESS, AddressManageActivity.this);
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        xhrAddresses();
        setSelected();
    }

    private void xhrAddresses() {
        showStatusLoading(rootView);
        hideStatusErrorServer();
        hideStatusErrorNetwork();

        RequestAddress.getAddresses(new HttpClient.HttpCallback<List<AddressItem>>() {
            @Override
            public void onSuccess(List<AddressItem> result) {
                hideStatusLoading();
                listView.setVisibility(View.VISIBLE);
                addresses.clear();
                addresses.addAll(result);
                adapter.notifyDataSetChanged();
                if (addresses.size() > 0) {
                    mButtonRight.setEnabled(true);
                }
                setSelected();
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrAddresses();
                        }
                    });
                } else if (error.getCode() == HttpError.ERR_CODE_NOT_LOGIN) {
                    finish();
                } else {
                    showStatusErrorServer(rootView);
                    if (!TextUtils.isEmpty(error.getMessage())) {
                        setTextErrorServer(error.getMessage());
                    }
                }
            }
        });
    }

    private void xhrRemoveAddress(final int position) {
        AddressItem item = (AddressItem) addresses.get(position);
        try {
            JSONObject params = new JSONObject();
            params.put("addressId", item.getAddressId());
            showProgressDialog("正在删除");
            RequestAddress.removeAddress(params, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {
                    hideProgressDialog();
                    addresses.remove(position);
                    adapter.notifyDataSetChanged();
                    if (selectedIndex == position) {
                        selectedIndex = 0;
                    } else if (selectedIndex > position) {
                        selectedIndex--;
                    }
                    listView.setItemChecked(selectedIndex + 2, true);
                }

                @Override
                public void onFail(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "删除失败");
                }
            });
        } catch (JSONException e) {

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_CREATE_ADDRESS && resultCode == RESULT_OK) {

            xhrAddresses();
        }
        if (requestCode == Constant.REQUEST_CODE_CHANGE_ADDRESS && resultCode == RESULT_OK) {

            xhrAddresses();
        }
        if (requestCode == REQUEST_CODE_SIGNIN) {
            xhrAddresses();
        }
    }


    private void setSelected() {
        for (int i = 0; i < addresses.size(); i++) {
            AddressItem item = (AddressItem) addresses.get(i);
            if (item.getSelected() == 1) {
                selectedIndex = i;
                listView.setItemChecked(i + 2, true);
                break;
            }
        }
    }

}
