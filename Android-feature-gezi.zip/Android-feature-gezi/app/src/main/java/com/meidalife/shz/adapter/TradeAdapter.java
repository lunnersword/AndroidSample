package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.TradeItem;
import com.meidalife.shz.util.ImgUtil;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by fufeng on 15/10/21.
 */

public class TradeAdapter extends BaseAdapter {
    List<TradeItem> tradeList;
    Context mContext;
    LayoutInflater mInflater;
    final int AVATAR_SIZE;

    public TradeAdapter(Context context, List<TradeItem> data) {
        mContext = context;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        tradeList = data;
        AVATAR_SIZE = context.getResources().getDimensionPixelSize(R.dimen.trade_avatar_size);
    }

    public void setTradeList(List<TradeItem> data) {
        tradeList = data;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return tradeList.size();
    }

    @Override
    public Object getItem(int position) {
        return tradeList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (convertView == null || convertView.getTag() == null) {
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.item_trade_info, parent, false);
            viewHolder.avatar = (SimpleDraweeView) convertView.findViewById(R.id.avatar);
            viewHolder.nickname = (TextView) convertView.findViewById(R.id.nickname);
            viewHolder.price = (TextView) convertView.findViewById(R.id.tradePrice);
            viewHolder.quantity = (TextView) convertView.findViewById(R.id.tradeQuantity);
            viewHolder.date = (TextView) convertView.findViewById(R.id.tradeDate);
            viewHolder.time = (TextView) convertView.findViewById(R.id.tradeTime);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        TradeItem item = tradeList.get(position);
        ////todo set default avatar
        String avatarUrl = ImgUtil.getCDNUrlWithWidth(item.getAvatar(), AVATAR_SIZE);
        viewHolder.avatar.setImageURI(Uri.parse(avatarUrl));

        viewHolder.nickname.setText(item.getNick());
        viewHolder.price.setText(item.getPrice());
        viewHolder.quantity.setText(""+item.getQuantity());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault());
        String dateString = dateFormat.format(new Date(item.getTradeTime()));
        viewHolder.date.setText(dateString);

        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        String timeString = timeFormat.format(new Date(item.getTradeTime()));
        viewHolder.time.setText(timeString);
        return convertView;
    }

    public static class ViewHolder {
        SimpleDraweeView avatar;
        TextView nickname;
        TextView price;
        TextView quantity;
        TextView date;
        TextView time;
    }
}
