package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;

import com.amap.api.maps.AMap;
import com.amap.api.maps.MapView;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.MarkerOptions;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;


public abstract class BaseMapActivity extends BaseActivity {
    public int getLayoutResource() {
        return R.layout.activity_locating_map;
    }

    protected AMap aMap;
    private MapView mapView;
//    private View mContentView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        mContentView = this.getLayoutInflater().inflate(getLayoutResource(), null);
        setContentView(getLayoutResource());
        initMapView(savedInstanceState);
    }

    public void initMapView(Bundle savedInstanceState) {
        mapView = (MapView) findViewById(R.id.map);

        mapView.onCreate(savedInstanceState);
//        try {
//            mapView.onCreate(savedInstanceState);
//        } catch (Exception t) {
//            MessageUtils.showToast("亲，内存不足，无法打开地图，请返回重试");
//            Log.d("initMapFail",t.getMessage().toString());
//            finish();
//            return;
//        }

        if (!setUpMapIfNeeded()) {
            finish();
            return;
        }
    }

    protected void onSetUpAMap() {

    }

    protected MarkerOptions createMarker(String name, String snippet, double lat, double lng, int drawable) {
        MarkerOptions marker = new MarkerOptions();
        marker.title(name).anchor(0.5f, 1f).snippet(snippet).position(new LatLng(lat, lng)).icon(BitmapDescriptorFactory.fromResource(drawable));
        return marker;
    }

    protected MarkerOptions createMarker(String name, String snippet, double lat, double lng, View view) {
        MarkerOptions marker = new MarkerOptions();
        marker.title(name)
                .anchor(0.5f, 1f)
                .snippet(snippet)
                .position(new LatLng(lat, lng))
                .icon(BitmapDescriptorFactory.fromView(view));
        return marker;
    }

    private boolean setUpMapIfNeeded() {
        if (aMap == null) {
            aMap = mapView.getMap();
            if (aMap == null) {
                MessageUtils.showToast("地图初始化失败");
                return false;
            }
            aMap.getUiSettings().setZoomControlsEnabled(true);// 设置系统默认缩放按钮可见
            onSetUpAMap();
        }
        return true;
    }

    /**
     * 方法必须重写
     */
    @Override
    public void onResume() {
        super.onResume();
        if (mapView != null)
            mapView.onResume();
    }

    /**
     * 方法必须重写
     */
    @Override
    public void onPause() {
        super.onPause();
        if (mapView != null)
            mapView.onPause();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mapView != null)
            mapView.onSaveInstanceState(outState);
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mapView != null) {
            try {
                mapView.onDestroy();
            } catch (Throwable e) {
            }
        }
        aMap = null;
    }

//    public View getContentView() {
//        return mContentView;
//    }

}
