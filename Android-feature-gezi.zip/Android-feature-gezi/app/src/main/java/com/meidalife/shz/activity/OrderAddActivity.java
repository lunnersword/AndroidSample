package com.meidalife.shz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.AppendCostAdapter;
import com.meidalife.shz.adapter.OuterPaywayAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.request.RequestOrderOpr;
import com.meidalife.shz.view.MyListView;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 追加付款
 * Created by xiaoweilc on 15/6/19.
 */
public class OrderAddActivity extends BaseActivity {

    @Bind(R.id.listView)
    ListView listView;
    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.btnConfirm)
    Button btnConfirm;
    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.costRadio)
    TextView costRadio;
    @Bind(R.id.appendCost)
    EditText appendCost;

    @Bind(R.id.cellPayPoint)
    RelativeLayout cellPayPoint;
    @Bind(R.id.cellPayFund)
    RelativeLayout cellPayFund;
    @Bind(R.id.cellPayOther)
    RelativeLayout cellPayOther;
    @Bind(R.id.pointTitle)
    TextView pointTitle;
    @Bind(R.id.pointPayNumStr)
    TextView pointPayNumStr;
    @Bind(R.id.pointDesc)
    TextView pointDesc;
    @Bind(R.id.pointSwitch)
    Switch pointSwitch;
    @Bind(R.id.fundTitle)
    TextView fundTitle;
    @Bind(R.id.fundPayNumStr)
    TextView fundPayNumStr;
    @Bind(R.id.fundDesc)
    TextView fundDesc;
    @Bind(R.id.fundSwitch)
    Switch fundSwitch;
    @Bind(R.id.otherPayNum)
    TextView otherPayNum;
    @Bind(R.id.listViewOuterPayways)
    MyListView listViewOuterPayways;

    private OuterPaywayAdapter outerPaywayAdapter;
    private JSONArray outerPaywayList = new JSONArray();

    private int REQUEST_CODE_SIGNIN = 100;
    private String reasonText = null;
    private String amountNumber = "0";
    private String orderNo;
    private ArrayList<String> reasonData;
    Boolean loadPay;
    Boolean loadReason;
    JSONArray payInfo;

    Boolean changedSwitch = false;

    private BroadcastReceiver payResultReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int payWay = intent.getIntExtra(Pay.TAG_PAY_WAY, 0);
            if (payWay == Pay.PAY_WAY_WECHAT) {
                finish();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_add);
        initActionBar(R.string.title_order_add, true);    //统一继承BaseActivity风格
        ButterKnife.bind(this);

        costRadio.setTypeface(Helper.sharedHelper().getIconFont());

        Bundle extras = getIntent().getExtras();
        orderNo = extras.getString("orderNo");
        reasonData = new ArrayList<String>();
        loadPay = false;
        loadReason = false;

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                reasonText = reasonData.get(position);
            }
        });

        outerPaywayAdapter = new OuterPaywayAdapter(this, outerPaywayList);
        listViewOuterPayways.setAdapter(outerPaywayAdapter);

        appendCost.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                amountNumber = s.toString();
                int a = 1, b = 1;
                if (changedSwitch) {
                    a = pointSwitch.isChecked() ? 1 : 0;
                    b = fundSwitch.isChecked() ? 1 : 0;
                }
                xhrPayInfo(a, b, new XhrPayInfoCallback() {
                    @Override
                    public void exec() {
                        renderPayInfo();
                    }
                });
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        xhrReasonList();
        xhrPayInfo(1, 1, new XhrPayInfoCallback() {
            @Override
            public void exec() {
                renderReasonList();
            }
        });

        IntentFilter filter = new IntentFilter();
        filter.addAction(Pay.ACION_PAY_RESULT);

        LocalBroadcastManager.getInstance(this).registerReceiver(payResultReceiver, filter);
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(payResultReceiver);
        super.onDestroy();
    }

    private void renderReasonList() {
        if (!loadPay || !loadReason) {
            return;
        }
        hideStatusLoading();
        scrollView.setVisibility(View.VISIBLE);
        btnConfirm.setVisibility(View.VISIBLE);
        // render reason list
        AppendCostAdapter adapter = new AppendCostAdapter(OrderAddActivity.this, reasonData);
        listView.setAdapter(adapter);
        // render pay info
        renderPayInfo();
    }

    private void renderPayInfo() {
        if (payInfo == null) {
            return;
        }

        cellPayPoint.setVisibility(View.GONE);
        cellPayFund.setVisibility(View.GONE);
        cellPayOther.setVisibility(View.GONE);
        listViewOuterPayways.setVisibility(View.GONE);
        try {
            for (int i = 0; i < payInfo.size(); i++) {
                JSONObject pay = payInfo.getJSONObject(i);
                switch (pay.getIntValue(Pay.TAG_PAY_TYPE)) {
                    case Pay.PAY_WAY_ALIPAY:
                    case Pay.PAY_WAY_WECHAT:
                        if (pay.getIntValue("payNum") > 0) {
                            cellPayOther.setVisibility(View.VISIBLE);
                            listViewOuterPayways.setVisibility(View.VISIBLE);
                            otherPayNum.setText("" + (pay.getIntValue("payNum") / 100.0));
                        }
                        break;
                    // 余额
                    case 3:
                        cellPayFund.setVisibility(View.VISIBLE);
                        fundTitle.setText(pay.getString("title"));
                        fundPayNumStr.setText(pay.getString("payNumStr"));
                        fundDesc.setText(pay.getString("desc"));
                        fundSwitch.setChecked(pay.getIntValue("selected") == 1);
                        fundSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                changedSwitch = true;
                                xhrPayInfo(
                                        pointSwitch.isChecked() ? 1 : 0,
                                        isChecked ? 1 : 0,
                                        new XhrPayInfoCallback() {
                                            @Override
                                            public void exec() {
                                                renderPayInfo();
                                                scrollView.post(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        scrollView.fullScroll(ScrollView.FOCUS_DOWN);
                                                    }
                                                });
                                            }
                                        });
                            }
                        });
                        break;
                    // 生活豆
                    case 4:
                        cellPayPoint.setVisibility(View.VISIBLE);
                        pointTitle.setText(pay.getString("title"));
                        pointPayNumStr.setText(pay.getString("payNumStr"));
                        pointDesc.setText(pay.getString("desc"));
                        pointSwitch.setChecked(pay.getIntValue("selected") == 1);
                        pointSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                changedSwitch = true;
                                xhrPayInfo(isChecked ? 1 : 0, fundSwitch.isChecked() ? 1 : 0,
                                        new XhrPayInfoCallback() {
                                            @Override
                                            public void exec() {
                                                renderPayInfo();
                                                scrollView.post(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        scrollView.fullScroll(ScrollView.FOCUS_DOWN);
                                                    }
                                                });
                                            }
                                        });
                            }
                        });
                        break;
                }
            }
        } catch (JSONException e) {
            Log.e("OrderAdd", e.getMessage());
            hideProgressDialog();
        }
    }

    private void xhrReasonList() {
        showStatusLoading(rootView);
        hideStatusErrorNetwork();
        hideStatusErrorServer();
        btnConfirm.setVisibility(View.GONE);
        scrollView.setVisibility(View.GONE);
        JSONObject params = new JSONObject();
        try {
            params.put(Pay.TAG_PAY_TYPE, 3);
            params.put("orderNo", orderNo);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestOrderOpr.getReasonList(params, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                try {
                    if (result.containsKey("reasons")) {
                        reasonData.addAll(JSON.parseArray(result.getString("reasons"), String.class));
                    }

                    outerPaywayList = result.getJSONArray("payways");

                    outerPaywayAdapter.updateData(outerPaywayList);
                    outerPaywayAdapter.notifyDataSetChanged();
                    for (int i = 0; i < outerPaywayList.size(); i++) {
                        JSONObject outerPayway = outerPaywayList.getJSONObject(i);
                        if (outerPayway.getIntValue("selected") == 1) {
                            listViewOuterPayways.setItemChecked(i, true);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                loadReason = true;
                renderReasonList();
            }

            @Override
            public void onFail(HttpError error) {
                loadReason = false;
                hideStatusLoading();
                if (error != null) {
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        showStatusErrorNetwork(rootView);
                        setOnClickErrorNetwork(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                xhrReasonList();
                            }
                        });
                    } else {
                        showStatusErrorServer(rootView);
                        setTextErrorServer(error.getMessage());
                        setOnClickErrorServer(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                xhrReasonList();
                            }
                        });
                    }
                } else {
                    showStatusErrorServer(rootView);
                    setTextErrorServer("获取数据失败，请点击重试");
                    setOnClickErrorServer(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrReasonList();
                        }
                    });
                }
            }
        });
    }

    private void xhrPayInfo(int pointSelected, int fundSelected, final XhrPayInfoCallback callback) {
        if (TextUtils.isEmpty(amountNumber)) {
            return;
        }
        try {
            float amount = Float.parseFloat(amountNumber) * 100;
            JSONObject params = new JSONObject();
            params.put("payType", 2);
            params.put("orderNo", orderNo);
            params.put("totalNum", amount);
            params.put("pointSelected", pointSelected);
            params.put("fundSelected", fundSelected);
            HttpClient.get("1.0/buyerOrder/orderPayCart", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {
                    loadPay = true;
                    try {
                        payInfo = result.getJSONArray("pay");
                    } catch (JSONException e) {

                    }
                    callback.exec();
                }

                @Override
                public void onFail(HttpError error) {
                    loadPay = true;
                    callback.exec();
                }
            });
        } catch (JSONException e) {
            loadPay = true;
            callback.exec();
        }
    }

    public void xhrAppendCost() {
        try {
            JSONObject params = new JSONObject();
            params.put("orderNo", orderNo);
            params.put("addAmount", Float.parseFloat(amountNumber) * 100);
            params.put("reason", reasonText);
            if (payInfo != null) {
                for (int i = 0; i < payInfo.size(); i++) {
                    JSONObject pay = payInfo.getJSONObject(i);
                    switch (pay.getIntValue(Pay.TAG_PAY_TYPE)) {
                        case Pay.PAY_WAY_ALIPAY:
                        case Pay.PAY_WAY_WECHAT:
                            if (pay.getIntValue("payNum") > 0) {
                                params.put("otherNum", pay.getIntValue("payNum"));
                            }
                            break;
                        // 余额
                        case 3:
                            params.put("fundNum", pay.getIntValue("payNum"));
                            break;
                        // 生活豆
                        case 4:
                            params.put("pointNum", pay.getIntValue("payNum"));
                            break;
                    }
                }
            }

            int index = listViewOuterPayways.getCheckedItemPosition();

            JSONObject payWay = outerPaywayList.getJSONObject(index);
            if (payWay != null) {
                params.put("gwPayway", payWay.getIntValue(Pay.TAG_PAY_TYPE) == Pay.PAY_WAY_NONE ? Pay.PAY_WAY_ALIPAY : payWay.getIntValue(Pay.TAG_PAY_TYPE));
            }

            HttpClient.get("1.0/buyerOrder/add", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject data) {
                    try {

                        if (data.containsKey(Pay.TAG_NEED_PAY) && !data.getString(Pay.TAG_NEED_PAY).equals("0")) {
                            switch (data.getIntValue(Pay.TAG_PAY_WAY)) {
                                case Pay.PAY_WAY_ALIPAY:
//                                    String signPayStr = data.getString("signPayStr");
                                    Pay.payWithAlipay(OrderAddActivity.this, data.getString("signPayStr"), new Pay.PayCallback() {
                                        @Override
                                        public void success() {
                                            finish();
                                        }

                                        @Override
                                        public void failure(Error error) {
                                            finish();
                                            MessageUtils.showToastCenter(error.getMessage());
                                        }
                                    });
                                    break;
                                case Pay.PAY_WAY_WECHAT: {
                                    Pay.payWithWechat(OrderAddActivity.this, data.getJSONObject("wxPay"));
                                    break;
                                }
                                default:
                                    finish();
                            }
                        } else {
                            finish();
                        }

                    } catch (JSONException e) {

                    }

                    hideProgressDialog();
                    btnConfirm.setEnabled(true);
                }

                @Override
                public void onFail(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "追加付款失败");
                    btnConfirm.setEnabled(true);
                }
            });
        } catch (JSONException e) {

        }
    }

    public void handleConfirm(View view) {
        if (reasonText == null) {
            MessageUtils.showToastCenter("请选择个理由吧");
            return;
        }
        if (amountNumber == null || amountNumber.equals("") || amountNumber.equals("0")) {
            MessageUtils.showToastCenter("还没说给多少呢");
            return;
        }

        if (Float.parseFloat(amountNumber) < 0.01f) {
            MessageUtils.showToastCenter("输入的金额不应小于0.01");
            return;
        }

        showProgressDialog(getString(R.string.paying), false);

        btnConfirm.setEnabled(false);
        xhrAppendCost();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SIGNIN) {
            xhrReasonList();
        }
    }

    interface XhrPayInfoCallback {
        void exec();
    }
}
