package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.RedPaperAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.RedPaperItem;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 该笔订单可以适用红包列表
 * Created by zhq on 15/10/20.
 */
public class RedPaperListForOrderActivity extends BaseActivity {

    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.listView)
    ListView listView;
    //refresh layout
    @Bind(R.id.listViewSwipe)
    SwipeRefreshLayout mSwipeRefreshLayout;

    //红包为空 提示文案
    @Bind(R.id.redPaperListEmpty)
    View redPaperListEmpty;

    View listFooter;
    TextView footerMessage;
    ProgressBar footerLoading;
    Button footerReload;

    ArrayList<RedPaperItem> serviceItems;
    RedPaperAdapter adapter;
    Boolean loading;
    Boolean complete;
    Boolean isRefresh;

    private String orderNO;
    private String redpackIssueId;
    //当前被点击的 红包
    RedPaperItem clickedItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redpaper_list_for_order);
        ButterKnife.bind(this);

        initActionBar(R.string.choice_red_paper, true, true);

        //todo 判断跳转来源 如果是支付页面 更新头部样式 并请求数据
        Bundle intentExtras = getIntent().getExtras();
        orderNO = intentExtras != null ? intentExtras.getString("orderNO") : null;
        redpackIssueId = intentExtras != null ? intentExtras.getString("redpackIssueId") : null;


        listFooter = getLayoutInflater().inflate(R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);
        listView.addFooterView(listFooter);
        listFooter.setVisibility(View.GONE);

        serviceItems = new ArrayList<RedPaperItem>();
        loading = false;
        complete = false;
        isRefresh = false;

        initAdapter();
        initView();

        loadData();
    }


    private void loadData() {
        serviceItems.clear();
        mSwipeRefreshLayout.setVisibility(View.GONE);
        showStatusLoading(rootView);
        hideStatusErrorServer();
        hideStatusErrorNetwork();
        xhrServices();
    }

    private void initAdapter() {
        adapter = new RedPaperAdapter(this, serviceItems);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                clickedItem = serviceItems.get(position);
                //todo 红包发选操作 如果红包是选中状态 点击之后为非选中状态；如果是非选中状态,点击之后 为选中状态
                for (RedPaperItem item : serviceItems) {
                    if (item.getId().equals(clickedItem.getId())) {
                        //实现反选
                        if (item.isSelected()) {
                            item.setSelected(false);
                        } else {
                            item.setSelected(true);
                        }
                    } else {
                        item.setSelected(false);
                    }
                }
                adapter.notifyDataSetChanged();
            }
        });
    }

    private void initView() {
        mButtonRight.setText("确定");
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleConfirm();
            }
        });
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                handleRefresh();
            }
        });
        listView.setOnScrollListener(null);
//        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
//
//            private boolean moveToBottom = false;
//            private int previous = 0;
//
//            @Override
//            public void onScrollStateChanged(AbsListView view, int scrollState) {
//            }
//
//            @Override
//            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
//                if (previous < firstVisibleItem) {
//                    moveToBottom = true;
//                } else if (previous > firstVisibleItem) {
//                    moveToBottom = false;
//                }
//                previous = firstVisibleItem;
//
//                if (totalItemCount == firstVisibleItem + visibleItemCount && moveToBottom) {
//                    /* 需要加载更多数据的代码 */
//                    loadNext();
//                }
//            }
//        });
    }

    private void handleConfirm() {
        String redPaperId = "";
        if (clickedItem != null && clickedItem.isSelected()) {
            redPaperId = clickedItem.getId();
        }
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putString("redpackIssueId", redPaperId);
        intent.putExtras(bundle);
        setResult(RESULT_OK, intent);
        finish();
    }

    private JSONObject getParamsByOrderNO(String orderNo) {
        JSONObject params;
        try {
            params = new JSONObject();
            params.put("orderNo", orderNo);
        } catch (JSONException e) {
            params = null;
        }
        return params;
    }

    private void xhrServices() {
        if (loading) {
            return;
        }
        listFooter.setVisibility(View.VISIBLE);
        loading = true;

        HttpClient.get("1.0/redpack/getTradeAvailables", getParamsByOrderNO(orderNO), RedPaperItem.class, callback);
    }

    HttpClient.HttpCallback callback = new HttpClient.HttpCallback() {
        @Override
        public void onSuccess(Object result) {
            loading = false;
            complete = true;
            hideStatusLoading();
            listFooter.setVisibility(View.GONE);

            ArrayList<RedPaperItem> items = (ArrayList<RedPaperItem>) result;

            if (isRefresh) {
                isRefresh = false;
                serviceItems.clear();
                mSwipeRefreshLayout.setRefreshing(false);
            }
            //设置红包选中状态
            if (items != null && items.size() > 0) {
                for (RedPaperItem item : items) {
                    if (item.getId().equals(redpackIssueId)) {
                        item.setSelected(true);
                        clickedItem = item;
                    }
                }
            }
            serviceItems.addAll(items);
            adapter.notifyDataSetChanged();

            // 空数据
            if (serviceItems.size() == 0) {
                redPaperListEmpty.setVisibility(View.VISIBLE);
            } else {
                mSwipeRefreshLayout.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void onFail(HttpError error) {
            loading = false;
            hideStatusLoading();
            listFooter.setVisibility(View.GONE);

            // refresh
            mSwipeRefreshLayout.setRefreshing(false);

            if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                showStatusErrorNetwork(rootView);
                setOnClickErrorNetwork(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        loadData();
                    }
                });
                return;
            }

            showStatusErrorServer(rootView);
            setTextErrorServer(error.getMessage());
            setOnClickErrorServer(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    loadData();
                }
            });
        }
    };

    private void handleRefresh() {
        isRefresh = true;
        Log.i("Taber", "refresh profile");
        xhrServices();
    }
}
