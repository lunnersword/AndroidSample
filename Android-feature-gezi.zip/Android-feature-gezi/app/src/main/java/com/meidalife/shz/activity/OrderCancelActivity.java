package com.meidalife.shz.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ReasonAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.request.RequestOrderOpr;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 取消订单：已付款，卖家未接单
 * Created by xiaoweilc on 15/6/19.
 */
public class OrderCancelActivity extends BaseActivity {

    private Map<TextView, TextView> reasonCache = new HashMap<>();
    private String reasonText = null;
    private String orderNo;
    private String type;
    private String label;
    private ListView reasonList;
    private int reasonType;
    private ArrayList<String> reasonData;

    private View confirmFootView;
    private EditText otherReason;
    private TextView otherReasonNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_cancel);

        reasonType = 0;
        reasonData = new ArrayList<String>();
        label = null;
        Bundle bundle = getIntent().getExtras();
        type = bundle.getString("type");
        orderNo = bundle.getString("orderNo");
        reasonList = (ListView) findViewById(R.id.reasonList);
        if (confirmFootView == null) {
            confirmFootView = getLayoutInflater().inflate(R.layout.cancel_order_item_footer, reasonList, false);
            reasonList.addFooterView(confirmFootView);
            otherReason = (EditText) confirmFootView.findViewById(R.id.order_cancel_other_reason_et);
            otherReason.setVisibility(View.GONE);
            otherReason.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    otherReasonNum.setText(s.length()+"/15");
                }
            });
            otherReasonNum = (TextView) confirmFootView.findViewById(R.id.order_cancel_other_reason_text_num);
            otherReasonNum.setVisibility(View.GONE);
        }

        switch (type) {
            case Constant.CANCEL_ORDER_TYPE_CANCEL:
                initActionBar(R.string.title_order_cancel, true);
                label = getResources().getString(R.string.cancel_order_label);
                reasonType = 1;
                break;
            case Constant.CANCEL_ORDER_TYPE_REJECT:
                initActionBar(R.string.title_order_reject, true);
                label = getResources().getString(R.string.reject_order_label);
                reasonType = 2;
                break;
            default:
        }

        reasonList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0 && position < reasonData.size()) {
                    view.setSelected(true);
                    reasonText = (String) reasonData.get(position - 1);
                    otherReason.setVisibility(View.GONE);
                    otherReason.setText(null);
                    otherReasonNum.setVisibility(View.GONE);
                } else if (position == reasonData.size()) {
                    view.setSelected(true);
                    otherReason.setVisibility(View.VISIBLE);
                    otherReasonNum.setVisibility(View.VISIBLE);
                }
            }
        });

        JSONObject params = new JSONObject();
        try {
            params.put(Pay.TAG_PAY_TYPE, reasonType);
            params.put("orderNo", orderNo);
        } catch (JSONException e) {
            Log.e("OrderCancel", e.getMessage());
        }
        RequestOrderOpr.getReasonList(params, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                try {
                    if (result.containsKey("reasons")) {
                        reasonData.addAll(JSON.parseArray(result.getString("reasons"), String.class));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                reasonData.add("其他");

                Button confirm = (Button) confirmFootView.findViewById(R.id.order_cancel_confirm_bt);

                ReasonAdapter adapter = new ReasonAdapter(OrderCancelActivity.this, reasonData, label);
                reasonList.setAdapter(adapter);
                confirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (otherReason.getVisibility() == View.VISIBLE) {
                            reasonText = otherReason.getText().toString();
                        }
                        if (TextUtils.isEmpty(reasonText)) {
                            MessageUtils.showToastCenter("请选择个理由吧");
                            return;
                        }

                        xhrConfirm();
                    }
                });
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "获取取消理由失败，请重试");
            }
        });
    }

    private void xhrConfirm() {
        showProgressDialog("正在处理");

        if (reasonType == 1) { // 退款
            RequestOrderOpr.refund(orderNo, reasonText, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {
                    hideProgressDialog();
                    finish();
                }

                @Override
                public void onFail(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "取消订单失败");
                }
            });
        } else { // 拒单
            RequestOrderOpr.sellRefuse(orderNo, reasonText, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {
                    hideProgressDialog();
                    finish();
                }

                @Override
                public void onFail(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "确认拒单失败，请重试");
                }
            });
        }
    }
}
