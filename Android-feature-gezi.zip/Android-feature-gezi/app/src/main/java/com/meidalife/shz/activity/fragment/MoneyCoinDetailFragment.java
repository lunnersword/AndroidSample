package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.MoneyCoinDetailActivity;
import com.meidalife.shz.adapter.MoneyDetailAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.MoneyDetailDO;
import com.meidalife.shz.rest.request.RequestMoneyDetail;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.LoadUtil;
import com.meidalife.shz.util.MoneyDetailEnum;

import java.util.List;

/**
 * Created by shijian on 15/7/8.
 * @description m豆明细
 */
public class MoneyCoinDetailFragment extends BaseFragment {

    private LayoutInflater inflater;
//    private Context context;

    private View rootLayout;

    private ViewGroup rootView;
    private View contentRootView;

    private SwipeRefreshLayout detailListSwipe;
    private ListView detailList;
    private LinearLayout moneyNoData;
    private TextView moneyNoDataTip;
    private LinearLayout mcoinNoData;
    private TextView mcoinNoDataTip;

    private View listFoot;
    private MoneyDetailAdapter detailAdapter;

    private LoadUtil helper;

    private int page = 0;
    private int pageSize = 20;
    private boolean isMore = true;
    private boolean isLoading = false;
    private int previous;

    private String type;
    private String data;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        this.inflater = inflater;
//        this.context = inflater.getContext();

        if (rootLayout == null) {

            rootLayout = inflater.inflate(R.layout.money_coin_detail_list, container, false);
            Bundle args = getArguments();
            type = args.getString("type");
            data = args.getString("data");

            detailListSwipe = (SwipeRefreshLayout) rootLayout.findViewById(R.id.money_detail_list_swipe);
            detailList = (ListView) rootLayout.findViewById(R.id.money_detail_list);
            moneyNoData = (LinearLayout) rootLayout.findViewById(R.id.money_no_data);
            TextView moneyNoIcon = (TextView) rootLayout.findViewById(R.id.money_no_data_icon);
            moneyNoIcon.setTypeface(Helper.sharedHelper().getIconFont());
            moneyNoDataTip = (TextView) rootLayout.findViewById(R.id.money_no_data_tip);
            mcoinNoData = (LinearLayout) rootLayout.findViewById(R.id.mcoin_no_data);
            mcoinNoDataTip = (TextView) rootLayout.findViewById(R.id.mcoin_no_data_tip);
            TextView mcoinNoData = (TextView) rootLayout.findViewById(R.id.mcoin_no_data_icon);
            mcoinNoData.setTypeface(Helper.sharedHelper().getIconFont());

            // 添加底部loading样式
            listFoot = inflater.inflate(R.layout.view_list_footer, null);
            detailList.addFooterView(listFoot);
            listFoot.setVisibility(View.GONE);

            // 处理第一次加载或异常情况
            helper = new LoadUtil(inflater);
            rootView = (ViewGroup) rootLayout.findViewById(R.id.root_view);
            contentRootView = rootLayout.findViewById(R.id.content_root_view);
        }

        ViewGroup parent = (ViewGroup) rootLayout.getParent();
        if (parent != null) {
            parent.removeView(rootLayout);
        }

        return rootLayout;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initData();
    }


    public void initData() {

        helper.loadPre(rootView, contentRootView);
        page = 0;
        final int detailType = mapType(type, data);

        // 第一次请求
        RequestMoneyDetail.get(detailType, page, pageSize, new HttpClient.HttpCallback<List<MoneyDetailDO>>() {
            @Override
            public void onSuccess(List<MoneyDetailDO> dataList) {
                helper.loadSuccess(contentRootView);
//                List<MoneyDetailDO> dataList = (List<MoneyDetailDO>) result;
                if (CollectionUtil.isEmpty(dataList)) {
                    noDataTip(type, data);
                } else {
                    detailAdapter = new MoneyDetailAdapter(inflater, dataList, type);
                    detailList.setAdapter(detailAdapter);
                    hideNoDataTip();
                }
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(MoneyCoinDetailFragment.class.getName(), "req money detail fail, detailType=" + detailType + ", page=" + page + ", " + error.toString());
                helper.loadFail(error, rootView, null, new LoadUtil.LoadCallback() {
                    @Override
                    public void execute() {
                        initData();
                    }
                });
            }
        });

        // 下拉更新
        detailListSwipe.setProgressViewOffset(false, 150, 250);
        detailListSwipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                page = 0;
                RequestMoneyDetail.get(detailType, page, pageSize, new HttpClient.HttpCallback<List<MoneyDetailDO>>() {
                    @Override
                    public void onSuccess(List<MoneyDetailDO> detailList) {
//                        List<MoneyDetailDO> detailList = (List<MoneyDetailDO>) result;
                        detailListSwipe.setRefreshing(false);
                        if (CollectionUtil.isEmpty(detailList)) {
                            noDataTip(type, data);
                        } else {
                            detailAdapter.setDataList(detailList);
                            detailAdapter.notifyDataSetChanged();
                            hideNoDataTip();
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        Log.e(MoneyCoinDetailFragment.class.getName(), "req money detail fail, detailType=" + detailType + ", page=" + page + ", " + error.toString());
                        detailListSwipe.setRefreshing(false);
                        MessageUtils.showToastCenter(error.toString());
                    }
                });
                isMore = true;
            }
        });

        // 加载更多
        detailList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (!isMore) {
                    return;     // 是否有更多数据，则忽略
                }
                if (isLoading) {
                    return;     // 若已经在加载中，则忽略
                }
                boolean moveToBottom = false;
                if (previous < firstVisibleItem) {
                    moveToBottom = true;
                }
                previous = firstVisibleItem;
                if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
                    isLoading = true;
                    listFoot.setVisibility(View.VISIBLE);
                    page++;
                    RequestMoneyDetail.get(detailType, page, pageSize, new HttpClient.HttpCallback<List<MoneyDetailDO>>() {
                        @Override
                        public void onSuccess(List<MoneyDetailDO> dataList) {
                            isLoading = false;
//                            List<MoneyDetailDO> resData = (List<MoneyDetailDO>) result;
                            if (CollectionUtil.isEmpty(dataList)) {
                                isMore = false;
                                listFoot.setVisibility(View.GONE);
                            } else {
                                detailAdapter.add(dataList);
                                detailAdapter.notifyDataSetChanged();
                                listFoot.setVisibility(View.GONE);
                            }
                        }

                        @Override
                        public void onFail(HttpError error) {
                            isLoading = false;
                            MessageUtils.showToastCenter(error.toString());
                            page--;
                            listFoot.setVisibility(View.GONE);
                        }
                    });
                }
            }
        });

    }

    private void hideNoDataTip() {
        moneyNoData.setVisibility(View.GONE);
        mcoinNoData.setVisibility(View.GONE);
        contentRootView.setVisibility(View.VISIBLE);
    }

    private void noDataTip(String type, String data) {
        if (MoneyCoinDetailActivity.MONEY_TYPE.equals(type)) {
            moneyNoData.setVisibility(View.VISIBLE);
            if (MoneyDetailEnum.IN.code.equals(data)) {
                moneyNoDataTip.setText("一笔收入都没有哦！");
            } else if (MoneyDetailEnum.OUT.code.equals(data)) {
                moneyNoDataTip.setText("一笔支出都没有哦！");
            } else {
                moneyNoDataTip.setText("不劳动，怎么能有钱？赶快发个服务赚钱去吧！");
            }
        } else if (MoneyCoinDetailActivity.COIN_TYPE.equals(type)) {
            mcoinNoData.setVisibility(View.VISIBLE);
            if (MoneyDetailEnum.IN.code.equals(data)) {
                mcoinNoDataTip.setText("一笔收入都没有哦！");
            } else if (MoneyDetailEnum.OUT.code.equals(data)) {
                mcoinNoDataTip.setText("一笔支出都没有哦！");
            } else {
                mcoinNoDataTip.setText("你还没有豆哎，赶紧去赚豆吧！");
            }
        }
        contentRootView.setVisibility(View.GONE);
    }

    private int mapType(String type, String data) {

        if (MoneyCoinDetailActivity.MONEY_TYPE.equals(type)) {
            if (MoneyDetailEnum.All.code.equals(data))
                return 1;
            else if (MoneyDetailEnum.IN.code.equals(data))
                return 2;
            else if (MoneyDetailEnum.OUT.code.equals(data))
                return 3;
        } else if (MoneyCoinDetailActivity.COIN_TYPE.equals(type)) {
            if (MoneyDetailEnum.All.code.equals(data))
                return 4;
            else if (MoneyDetailEnum.IN.code.equals(data))
                return 5;
            else if (MoneyDetailEnum.OUT.code.equals(data))
                return 6;
        }
        return 0;
    }

}
