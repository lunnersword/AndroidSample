package com.meidalife.shz.activity;

import android.graphics.Point;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.SearchServiceResultFragment;
import com.meidalife.shz.activity.fragment.SearchUserFragment;
import com.meidalife.shz.adapter.SearchRecyclerViewAdapter;
import com.meidalife.shz.adapter.SearchTopListViewAdapter;
import com.meidalife.shz.event.SearchParamsChanceEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SearchFilterDO;
import com.meidalife.shz.rest.model.SearchTopListPromotionDO;
import com.meidalife.shz.rest.model.SearchTopListUserDO;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.rest.model.TabItem;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.widget.DragTopLayout;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

public class SearchResActivity extends BaseActivity {
    private final String SEARCH_HISTORY_KW_SPLIT = ",";
    private static final int SEARCH_TYPE_SERVICE = 0;
    private static final int SEARCH_TYPE_USER = 1;

    private int startLeft;
    private int startTop;
    private int height;
    private int spaceWidth;
    private int spaceHeight;
    private int screenWidth;
    private boolean isIgnoreChange = false;
    private int searchType = 0;//0服务， 1 用户
    private String hintKeyword;
    private List<TabItem> tabItemList = new ArrayList<>();
    String searchParamType = null;
    String defaultParamType = null;
    private String lastSearchWord = "";
    private boolean isFirstSearch = false;


    @Bind(R.id.root_view)
    ViewGroup rootView;
    @Bind(R.id.head_search_back)
    TextView backButton;
    @Bind(R.id.head_search_input)
    EditText searchInput;
    @Bind(R.id.search_input_group)
    View searchInputGroup;
    @Bind(R.id.searchKeywordClear)
    TextView searchKeywordClear;
    @Bind(R.id.head_search_commit)
    TextView searchCommit;

    @Bind(R.id.searchTabLayout)
    ViewGroup searchTabLayout;
    @Bind(R.id.serviceTabLayout)
    ViewGroup serviceTabLayout;
    @Bind(R.id.serviceTabTitle)
    TextView serviceTabTitle;
    @Bind(R.id.userTabLayout)
    ViewGroup userTabLayout;
    @Bind(R.id.userTabTitle)
    TextView userTabTitle;

    @Bind(R.id.search_recommend_group)
    View recommendGroup;
    @Bind(R.id.search_history_group)
    View historyGroup;
    @Bind(R.id.search_history_keywords)
    LinearLayout historyKeywords;
    @Bind(R.id.search_suggest_kws_group)
    LinearLayout suggestGroup;

    @Bind(R.id.search_recommend_tags)
    RelativeLayout recommendTags;
    @Bind(R.id.searchResultLayout)
    ViewGroup searchResultLayout;

    @Bind(R.id.searchUserContentFrame)
    FrameLayout searchUserContentFrame;

    @Bind(R.id.dragLayout)
    DragTopLayout dragTopLayout;
    @Bind(R.id.squareResult)
    ViewGroup squareResult;
    @Bind(R.id.searchTopList)
    ListView searchTopList;

    @Bind(R.id.searchRecyclerView)
    RecyclerView searchRecyclerView;

    @Bind(R.id.searchContentTagContainer)
    View searchContentTagContainer;
    @Bind(R.id.searchContentTagText)
    TextView searchContentTagText;

    @Bind(R.id.titleTopListView)
    TextView titleTopListView;

    private LoadUtilV2 helperV2;
    private SearchTopListViewAdapter searchTopListViewAdapter;
    private SearchRecyclerViewAdapter searchRecyclerViewAdapter;
    private String extraParams;
    private SearchServiceResultFragment serviceResultFragment;
    IFilterChangeListener iFilterChangeListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_res);
        ButterKnife.bind(this);
        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

    public interface IFilterChangeListener {

        public void changeStatus(boolean isChecked, int popupIndex);

    }

    public void setIFilterChangeListener(IFilterChangeListener iFilterChangeListener) {
        this.iFilterChangeListener = iFilterChangeListener;
    }


    //接收搜过数据参数的改变
    public void onEventMainThread(SearchParamsChanceEvent event) {

        if (event.eventType == MsgTypeEnum.TYPE_SEARCH_PARAMS_CHANGE) {
            if (null != event.getType()) {
                searchParamType = event.getType();
                startSearch();
            } else if (null != event.getExtraParams()) {
                extraParams = event.getExtraParams().toString();

                //不计算{} 占2位的长度
                if (!TextUtils.isEmpty(extraParams) && extraParams.toString().length() > 2) {
                    iFilterChangeListener.changeStatus(true, event.getPopupIndex());
                } else {
                    iFilterChangeListener.changeStatus(false, event.getPopupIndex());

                }

                startSearch();
            }

        }
    }

    private void initData() {
        helperV2 = new LoadUtilV2(getLayoutInflater());
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        screenWidth = size.x;
        spaceWidth = (int) Helper.convertDpToPixel(10, this);
        spaceHeight = (int) Helper.convertDpToPixel(15, this);
        height = (int) Helper.convertDpToPixel(30, this);
        startLeft = 0;
        startTop = spaceHeight;
        screenWidth -= Helper.convertDpToPixel(15, this) * 2;

        initServiceResultFragment();
        View cleanHistory = findViewById(R.id.search_clean_history);
        cleanHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                historyGroup.setVisibility(View.GONE);
                cleanSearchHistory();
            }
        });

        hintKeyword = getIntent().getStringExtra("keyword");
        if (!TextUtils.isEmpty(hintKeyword)) {
            searchInput.setHint(hintKeyword);
        }
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (isIgnoreChange) {
                    isIgnoreChange = false;
                    return;
                }
                if (StrUtil.isEmpty(s.toString())) {
                    showRecommendAndHistoryData();
                } else {
                    searchInputGroup.setVisibility(View.VISIBLE);
                    loadSuggestKws(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        searchInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH
                        || (event != null && KeyEvent.KEYCODE_ENTER == event.getKeyCode() && KeyEvent.ACTION_DOWN == event.getAction())) {
                    startSearch();
                    return true;
                }
                return false;
            }
        });

        searchInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchInputGroup.setVisibility(View.VISIBLE);
                searchTabLayout.setVisibility(View.VISIBLE);
                searchUserContentFrame.setVisibility(View.GONE);
                searchContentTagContainer.setVisibility(View.GONE);
                extraParams = null;
                searchParamType = defaultParamType;
                if (searchType == SEARCH_TYPE_SERVICE) {
                    recommendGroup.setVisibility(View.VISIBLE);
                    showRecommendAndHistoryData();
                } else if (searchType == SEARCH_TYPE_USER) {
                    recommendGroup.setVisibility(View.GONE);
                }
            }
        });

        searchContentTagText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchInputGroup.setVisibility(View.VISIBLE);
                searchTabLayout.setVisibility(View.VISIBLE);
                searchUserContentFrame.setVisibility(View.GONE);
                searchContentTagContainer.setVisibility(View.GONE);
                if (searchType == SEARCH_TYPE_SERVICE) {
                    recommendGroup.setVisibility(View.VISIBLE);
                    showRecommendAndHistoryData();
                } else if (searchType == SEARCH_TYPE_USER) {
                    recommendGroup.setVisibility(View.GONE);
                }
            }
        });

        searchKeywordClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchInputGroup.setVisibility(View.VISIBLE);
                searchTabLayout.setVisibility(View.VISIBLE);
                searchContentTagContainer.setVisibility(View.GONE);
                searchUserContentFrame.setVisibility(View.GONE);
                searchInput.setText("");
                extraParams = null;
                searchParamType = defaultParamType;
                if (searchType == SEARCH_TYPE_SERVICE) {
                    recommendGroup.setVisibility(View.VISIBLE);
                } else if (searchType == SEARCH_TYPE_USER) {
                    recommendGroup.setVisibility(View.GONE);
                }
            }
        });

        searchCommit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startSearch();
            }
        });

        serviceTabLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceTabTitle.setTextColor(getResources().getColor(R.color.brand_b));
                userTabTitle.setTextColor(getResources().getColor(R.color.brand_m));

                serviceTabLayout.setBackgroundResource(R.drawable.order_list_type_bottom);
                userTabLayout.setBackgroundResource(R.color.white);

                recommendGroup.setVisibility(View.VISIBLE);
                searchInputGroup.setVisibility(View.VISIBLE);
                searchUserContentFrame.setVisibility(View.GONE);
                searchType = 0;
            }
        });

        userTabLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceTabTitle.setTextColor(getResources().getColor(R.color.brand_m));
                userTabTitle.setTextColor(getResources().getColor(R.color.brand_b));
                userTabLayout.setBackgroundResource(R.drawable.order_list_type_bottom);
                serviceTabLayout.setBackgroundResource(R.color.white);
                searchType = 1;

                String searchWord = searchInput.getText().toString();
                if (StrUtil.isEmpty(searchWord)) {
                    showRecommendAndHistoryData();
                    recommendGroup.setVisibility(View.GONE);
                    return; // do nothing
                }
                searchUserContentFrame.setVisibility(View.VISIBLE);
                searchInputGroup.setVisibility(View.GONE);
                commitSearch(searchWord);
            }
        });

        searchTopListViewAdapter = new SearchTopListViewAdapter(this);
        searchTopList.setAdapter(searchTopListViewAdapter);
        // 初始显示推荐标签和历史记录
        loadRecommendAndHistoryData();
    }

    private void initServiceResultFragment() {


        serviceResultFragment = SearchServiceResultFragment.newInstance();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.searchServiceContentFrame,
                serviceResultFragment).commitAllowingStateLoss();
        serviceResultFragment.setSearchActionListener(new SearchServiceResultFragment.SearchCompleteListener() {
            @Override
            public void onUpdateSquareList(Object object, int type) {

                switch (type) {

                    case Constant.SEARCH_TOP_LIST_TYPE_GEZI:
                        List<SquareDO> squareDOs = (List<SquareDO>) object;
                        if (null != squareDOs && !squareDOs.isEmpty()) {
                            searchTopListViewAdapter.setData(squareDOs, type);
                            searchTopListViewAdapter.notifyDataSetChanged();
                            squareResult.setVisibility(View.VISIBLE);
                            titleTopListView.setText("相关格子");
                            titleTopListView.setVisibility(View.VISIBLE);
                            dragTopLayout.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    dragTopLayout.openTopView(true);
                                }
                            }, 100);
                            dragTopLayout.setTouchMode(true);
                        } else {
                            dragTopLayout.setTouchMode(false);
                            dragTopLayout.closeTopView(true);
                            squareResult.setVisibility(View.GONE);
                        }
                        break;

                    case Constant.SEARCH_TOP_LIST_TYPE_USER:
                        SearchTopListUserDO searchTopListUserDO = (SearchTopListUserDO) object;
                        searchTopListViewAdapter.setData(searchTopListUserDO, type);
                        searchTopListViewAdapter.notifyDataSetChanged();
                        titleTopListView.setVisibility(View.GONE);
                        squareResult.setVisibility(View.VISIBLE);
                        dragTopLayout.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                dragTopLayout.openTopView(true);
                            }
                        }, 100);
                        dragTopLayout.setTouchMode(true);
                        break;

                    case Constant.SEARCH_TOP_LIST_TYPE_PROMOTION:
                        SearchTopListPromotionDO searchTopListPromotionDO = (SearchTopListPromotionDO) object;
                        searchTopListViewAdapter.setData(searchTopListPromotionDO, type);
                        searchTopListViewAdapter.notifyDataSetChanged();
                        titleTopListView.setVisibility(View.GONE);
                        squareResult.setVisibility(View.VISIBLE);
                        dragTopLayout.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                dragTopLayout.openTopView(true);
                            }
                        }, 100);
                        dragTopLayout.setTouchMode(true);
                        break;

                    default:
                        dragTopLayout.setTouchMode(false);
                        dragTopLayout.closeTopView(true);
                        squareResult.setVisibility(View.GONE);
                }

            }

            @Override
            public void onScrollToTop(boolean top) {
                if (!searchTopListViewAdapter.isEmpty()) {
                    dragTopLayout.setTouchMode(top);
                }
            }

            @Override
            public void onUpdateTabFilter(SearchFilterDO searchFilterDO) {
                searchRecyclerViewAdapter.setSearchFilterDO(searchFilterDO);
            }
        });


    }

    private void startSearch() {
        String searchWord = searchInput.getText().toString().trim();
        if (TextUtils.isEmpty(searchWord) && !TextUtils.isEmpty(hintKeyword)) {
            commitSearch(hintKeyword);
            return;
        }
        commitSearch(searchWord);
    }

    private void commitSearch(String word) {
        searchInputGroup.setVisibility(View.GONE);
        searchContentTagText.setText(word);
        searchContentTagContainer.setVisibility(View.VISIBLE);
        addSearchHistory(word);
        isIgnoreChange = true;
        searchInput.setText(word);
        searchInput.setSelection(word.length());
        if (searchRecyclerViewAdapter != null) {
            searchRecyclerViewAdapter.setSelectedIndex(0);
            searchRecyclerViewAdapter.notifyDataSetChanged();
        }

        if (!TextUtils.isEmpty(word) && !word.equals(lastSearchWord)) {
            lastSearchWord = word;
            isFirstSearch = true;

            searchParamType = defaultParamType;

        } else {
            isFirstSearch = false;
        }

        dragTopLayout.closeTopView(false);
        dragTopLayout.setTouchMode(false);

        squareResult.setVisibility(View.GONE);

        loadSearchRes();
    }

    private void loadSearchRes() {
        if (searchType == SEARCH_TYPE_SERVICE) {
            searchTabLayout.setVisibility(View.GONE);
            searchResultLayout.setVisibility(View.VISIBLE);

            Bundle args = new Bundle();
            args.putString(SearchServiceResultFragment.SEARCH_ARG_TYPE, searchParamType);
            args.putString(SearchServiceResultFragment.SEARCH_ARG_KEYWORD, searchInput.getText().toString());
            args.putString(SearchServiceResultFragment.SEARCH_ARG_EXTRA, extraParams);
            args.putBoolean(SearchServiceResultFragment.SEARCH_ARG_FIRST_SEARCH, isFirstSearch);

            serviceResultFragment.setSearchParams(args);

        } else if (searchType == SEARCH_TYPE_USER) {
            searchResultLayout.setVisibility(View.GONE);
            searchUserContentFrame.setVisibility(View.VISIBLE);
            FragmentManager fragmentManager = getSupportFragmentManager();
            Bundle args = new Bundle();
            args.putString(SearchUserFragment.SEARCH_ARG_NICK, searchInput.getText().toString());
            fragmentManager.beginTransaction().replace(R.id.searchUserContentFrame,
                    SearchUserFragment.newInstance(args)).commitAllowingStateLoss();
        }
    }

    public void loadRecommendAndHistoryData() {
        recommendGroup.setVisibility(View.VISIBLE);
        historyGroup.setVisibility(View.VISIBLE);
        suggestGroup.setVisibility(View.GONE);
        searchResultLayout.setVisibility(View.GONE);
        startLeft = 0;
        startTop = spaceHeight;

        // 加载推荐标签
        recommendTags.removeAllViews();
        loadHotKeyword();
        // 加载搜索历史
        historyKeywords.removeAllViews();
        loadSearchHistory();
    }

    public void showRecommendAndHistoryData() {
        recommendGroup.setVisibility(View.VISIBLE);
        historyGroup.setVisibility(View.VISIBLE);
        suggestGroup.setVisibility(View.GONE);
        searchResultLayout.setVisibility(View.GONE);
    }

    public void loadHotKeyword() {
        helperV2.loadPre(rootView, searchInputGroup);
        HttpClient.get("2.0/search/init", null, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject data) {
                helperV2.loadSuccess(searchInputGroup);
                if (data == null || data.isEmpty()) {
                    return;
                }
                JSONArray hotKeywords = data.getJSONArray("hotKeywords");
                //移除第一个关键词
                loadHotKeywords(hotKeywords);
                String tabArray = data.getString("tagVOList");

                tabItemList = JSON.parseArray(tabArray, TabItem.class);

                for (TabItem tabItem : tabItemList) {
                    if (tabItem.getSelected() != null && tabItem.getSelected().equals(1)) {
                        defaultParamType = tabItem.getType();
                    }
                }

                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(SearchResActivity.this);
                linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
                searchRecyclerView.setLayoutManager(linearLayoutManager);
                searchRecyclerViewAdapter = new SearchRecyclerViewAdapter(SearchResActivity.this, tabItemList);
                searchRecyclerView.setAdapter(searchRecyclerViewAdapter);

            }

            @Override
            public void onFail(HttpError error) {
                helperV2.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        loadRecommendAndHistoryData();
                    }
                });
            }
        });
    }

    private void loadHotKeywords(JSONArray hotKeywords) {
        for (int i = 0; i < hotKeywords.size(); i++) {
            String kw = hotKeywords.getString(i);
            // 展开分类
            Button expandButton = (Button) LayoutInflater.from(SearchResActivity.this).
                    inflate(R.layout.activity_search_recommend_item, recommendTags, false);
            expandButton.setText("#" + kw);
            expandButton.setTag(kw);
            appendMargin(expandButton);
            // 计算位置
            expandButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MessageUtils.showToastCenter("click on keyword : " + ((TextView) v).getText().toString());
                }
            });
            recommendTags.addView(expandButton);
            // 点击事件
            expandButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String word = (String) v.getTag();
                    commitSearch(word);
                }
            });
        }
    }

    private void appendMargin(Button button) {
        button.measure(0, 0);
        int width = button.getMeasuredWidth();

        if (startLeft + width > screenWidth) {
            startLeft = 0;
            startTop += height + spaceHeight;
        }

        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) button.getLayoutParams();
        layoutParams.setMargins(startLeft, startTop, 0, 0);
        button.setLayoutParams(layoutParams);
        startLeft += width + spaceWidth;
    }

    public void loadSearchHistory() {
        String[] searchHistory = parseSearchHistory();
        if (searchHistory == null || searchHistory.length == 0) {
            historyGroup.setVisibility(View.GONE);
            return;
        }
        for (String str : searchHistory) {
            TextView hisKw = (TextView) LayoutInflater.from(this).inflate(R.layout.activity_search_history_item, historyKeywords, false);
            hisKw.setText(str);
            hisKw.setTag(str);
            historyKeywords.addView(hisKw);
            hisKw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String word = (String) v.getTag();
                    commitSearch(word);
                }
            });
        }
    }

    public void loadSuggestKws(String searchKw) {
        suggestGroup.removeAllViews();
        suggestGroup.setVisibility(View.VISIBLE);
        recommendGroup.setVisibility(View.GONE);
        historyGroup.setVisibility(View.GONE);
        searchResultLayout.setVisibility(View.GONE);

        JSONObject params = new JSONObject();
        params.put("keyword", searchKw);
        helperV2.loadPre(rootView, searchInputGroup);
        HttpClient.get("1.0/search/suggest", params, String.class, new HttpClient.HttpCallback<List<String>>() {
            @Override
            public void onSuccess(List<String> datalist) {
                helperV2.loadSuccess(searchInputGroup);
                for (String str : datalist) {
                    TextView suggestKw = (TextView) LayoutInflater.from(SearchResActivity.this).
                            inflate(R.layout.activity_search_history_item, suggestGroup, false);
                    suggestKw.setText(str);
                    suggestKw.setTag(str);
                    suggestGroup.addView(suggestKw);
                    suggestKw.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String word = (String) v.getTag();
                            commitSearch(word);
                        }
                    });
                }
            }

            @Override
            public void onFail(HttpError error) {
                helperV2.loadSuccess(searchInputGroup);
            }
        });
    }

    public String[] parseSearchHistory() {
        String str = Helper.sharedHelper().getStringUserInfo(Constant.SEARCH_HISTORY_KW);
        if (StrUtil.isEmpty(str)) {
            return null;
        } else {
            return str.split(SEARCH_HISTORY_KW_SPLIT);
        }
    }

    public void addSearchHistory(String newKw) {
        String[] oldKwList = parseSearchHistory();
        StringBuilder builder = new StringBuilder(newKw);
        int maxSize = 10;

        if (oldKwList != null) {
            int start = 0;
            if (oldKwList.length >= maxSize) {
                start = 1;
            }
            for (int i = start; i < oldKwList.length; i++) {
                String oldKw = oldKwList[i];
                if (!newKw.equalsIgnoreCase(oldKw)) {
                    builder.append(SEARCH_HISTORY_KW_SPLIT).append(oldKwList[i]);
                }
            }
        }
        Helper.sharedHelper().setStringUserInfo(Constant.SEARCH_HISTORY_KW, builder.toString());
    }

    public void cleanSearchHistory() {
        historyKeywords.removeAllViews();
        Helper.sharedHelper().setStringUserInfo(Constant.SEARCH_HISTORY_KW, "");
    }
}
