package com.meidalife.shz.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.OrderJudgeActivity;
import com.meidalife.shz.activity.OrderRefundActivity;
import com.meidalife.shz.activity.OrderRemarkActivity;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ItemDO;
import com.meidalife.shz.rest.model.OrderDO;
import com.meidalife.shz.rest.request.RequestOrderOpr;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.OrderUtil;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.MyWarnDialog;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

public class OrderListAdapter extends BaseAdapter {
    Context context;
    List<OrderDO> mOrderList;
    LayoutInflater mInflater;
    OnOrderChangeLister onOrderChangeLister;
//    private int serviceType;

    ItemDO mFirstItem;

    public OrderListAdapter(Context context, List<OrderDO> data) {
        this.context = context;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mOrderList = data;
    }

    public void updateData(List<OrderDO> data) {
        mOrderList = data;
        notifyDataSetChanged();
    }

    public void setOnOrderChangeLister(OnOrderChangeLister onOrderChangeLister) {
        this.onOrderChangeLister = onOrderChangeLister;
    }

    @Override
    public int getCount() {
        return mOrderList.size();
    }

    @Override
    public Object getItem(int position) {
        return mOrderList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        OrderItemHolder holder = new OrderItemHolder();

        if (convertView != null) {
            holder = (OrderItemHolder) convertView.getTag();
        } else {
            View itemView = mInflater.inflate(R.layout.activity_orders_item, null);
            holder.userPic = (SimpleDraweeView) itemView.findViewById(R.id.order_user_pic);
            holder.userNick = (TextView) itemView.findViewById(R.id.order_user_nick);
            holder.iconUserRight = (TextView) itemView.findViewById(R.id.iconUserRight);
            holder.remarkFlag = (TextView) itemView.findViewById(R.id.sellerRemarkFlag);
            holder.status = (TextView) itemView.findViewById(R.id.order_status);
            holder.priceExtra = (TextView) itemView.findViewById(R.id.order_price_extra);
            holder.priceTotal = (TextView) itemView.findViewById(R.id.order_price_total);
            holder.oprBtList = (LinearLayout) itemView.findViewById(R.id.order_opr_bt_list);
            holder.oprBtPlacer = (LinearLayout) itemView.findViewById(R.id.order_opr_bt_list_placer);
            //  holder.squareOrder = (TextView) itemView.findViewById(R.id.squareOrder);

            holder.serviceItemGroup = (LinearLayout) itemView.findViewById(R.id.serviceItemGroup);
            holder.contactName = (TextView) itemView.findViewById(R.id.contactName);
            holder.contactPhone = (TextView) itemView.findViewById(R.id.contactPhone);
            holder.serviceAddress = (TextView) itemView.findViewById(R.id.serviceAddress);
            holder.serviceTime = (TextView) itemView.findViewById(R.id.serviceTime);
            holder.createTime = (TextView) itemView.findViewById(R.id.createTime);
            convertView = itemView;
            convertView.setTag(holder);
        }

        final OrderDO order = mOrderList.get(position);

        //多服务订单
        holder.serviceItemGroup.removeAllViews();
        if (order.getItemList() != null && order.getItemList().size() > 0) {
            for (ItemDO item : order.getItemList()) {
//                serviceType = item.getServiceType();
                View itemView = mInflater.inflate(R.layout.view_order_service_item, holder.serviceItemGroup, false);
                SimpleDraweeView imageItem = (SimpleDraweeView) itemView.findViewById(R.id.imageItem);
                if (!TextUtils.isEmpty(item.getItemImage())) {
                    String url = ImgUtil.getCDNUrlWithWidth(item.getItemImage(), imageItem.getLayoutParams().width);
                    if (!TextUtils.isEmpty(url)) {
                        imageItem.setImageURI(Uri.parse(url));
                    }
                }
                ((TextView) itemView.findViewById(R.id.textItemTag)).setText("我能·" + item.getTitle());
                if (item.getSku() != null) {
                    ((TextView) itemView.findViewById(R.id.skuName)).setText("服务规格：" + item.getSku().getName());
                    TextView oriPriceItemPrice = (TextView) itemView.findViewById(R.id.oriPriceItemPrice);
                    if (item.getSku().getPromotionPrice() != null) {
                        oriPriceItemPrice.setVisibility(View.VISIBLE);
                        oriPriceItemPrice.setText(item.getSku().getPrice() + "元");
                        ((TextView) itemView.findViewById(R.id.textItemPrice)).setText(item.getSku().getPromotionPrice() + "元");
                        oriPriceItemPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
                    } else {
                        oriPriceItemPrice.setVisibility(View.GONE);
                        ((TextView) itemView.findViewById(R.id.textItemPrice)).setText(item.getSku().getPrice() + "元");
                    }
                }
                TextView count = (TextView) itemView.findViewById(R.id.count);
                count.setText("x" + item.getCount());
                if (null != item.getServiceTypeText()) {
                    TextView itemServiceType = (TextView) itemView.findViewById(R.id.itemServiceType);
                    itemServiceType.setVisibility(View.VISIBLE);
                    itemServiceType.setText(item.getServiceTypeText());
                }
                //活动标
                ViewGroup promotionLayout = (ViewGroup) itemView.findViewById(R.id.promotionLayout);
                promotionLayout.removeAllViews();
                if (null != item.getPromotionTips() && item.getPromotionTips().size() > 0) {
                    for (String str : item.getPromotionTips()) {
                        View promotionView = mInflater.inflate(R.layout.view_promotion, promotionLayout, false);
                        ((TextView) (promotionView.findViewById(R.id.promotion))).setText(str);
                        promotionLayout.addView(promotionView);
                    }
                }
                holder.serviceItemGroup.addView(itemView);
            }
        }
        if (order.getBuyer() != null) {
            holder.contactName.setVisibility(View.VISIBLE);
            holder.contactPhone.setVisibility(View.VISIBLE);
            holder.contactName.setText("联系人：" + order.getBuyer().getContactorName());
            holder.contactPhone.setText("联系电话：" + order.getBuyer().getContactorPhone());
        } else {
            holder.contactName.setVisibility(View.GONE);
            holder.contactPhone.setVisibility(View.GONE);
        }

        if (order.getUser() != null && order.getBuyer() != null && order.getBuyer().getAddressName() != null) {
            holder.serviceAddress.setVisibility(View.VISIBLE);
            holder.serviceAddress.setText(("服务地址：") + order.getBuyer().getAddressName());
        } else {
            holder.serviceAddress.setVisibility(View.GONE);
        }

        if (TextUtils.isEmpty(order.getBookTime())) {
            holder.serviceTime.setVisibility(View.GONE);
        } else {
            holder.serviceTime.setVisibility(View.VISIBLE);
            holder.serviceTime.setText("服务时间：" + order.getBookTime());
        }


        if (order.getUser() != null) {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(order.getUser().getAvatar(), holder.userPic.getLayoutParams().width));
            holder.userPic.setImageURI(uri);
            holder.userNick.setText(order.getUser().getUserNick());
            holder.userPic.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("profile/" + order.getUser().getUserId());
                }
            });
            holder.userNick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("profile/" + order.getUser().getUserId());
                }
            });
            holder.iconUserRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("profile/" + order.getUser().getUserId());
                }
            });
            holder.userPic.setVisibility(View.VISIBLE);
            holder.userNick.setVisibility(View.VISIBLE);
        } else {
            holder.userPic.setVisibility(View.GONE);
            holder.userNick.setVisibility(View.GONE);
        }
        holder.status.setText(order.getStatusText());
        holder.createTime.setText("订单生成时间：" + order.getCreateTime());
        holder.priceTotal.setText(order.getAmountStr().toString() + "元");

        if (order.getRoleType() == OrderUtil.ROLE_TYPE_SELL && order.getSellerInnerFlag() != null) {
            holder.remarkFlag.setTextColor(context.getResources().getColor(OrderUtil.
                    getRemarkFlagColor(order.getSellerInnerFlag() - 1)));
            holder.remarkFlag.setVisibility(View.VISIBLE);
        } else {
            holder.remarkFlag.setVisibility(View.GONE);
        }
        addOprBt(holder, order, position);

        final int index = position;
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                Router.sharedRouter().open("orders/" + order.getOrderNo());
                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(index, order.getOrderNo());
                }
            }
        });

        //  holder.squareOrder.setVisibility(TextUtils.isEmpty(order.getGeziId()) ? View.GONE : View.VISIBLE);
        return convertView;
    }

    /**
     * 增加可操作列表
     *
     * @param holder
     * @param order
     */
    private void addOprBt(OrderListAdapter.OrderItemHolder holder, OrderDO order, int position) {
        holder.oprBtList.removeAllViews();
        List<Object[]> oprList = OrderUtil.getAllOperateList(order.getOperate(), order);
        if (order.getRoleType() == OrderUtil.ROLE_TYPE_SELL) {
            TextView bt = new FontTextView(context);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) Helper.convertDpToPixel(70, context),
                    (int) Helper.convertDpToPixel(30, context));
            params.setMargins(0, 0, (int) Helper.convertDpToPixel(10, context), 0);
            bt.setLayoutParams(params);
            bt.setGravity(Gravity.CENTER);
            bt.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);

            bt.setTextColor(context.getResources().getColor(R.color.grey_a));
            bt.setBackgroundResource(R.drawable.order_list_edit_bg_white);
            bt.setText("备注");
            bt.setTag(R.id.order_list_order, order);
            bt.setTag(R.id.order_list_opr, OrderUtil.OPEN_REMARK);
            bt.setTag(R.id.order_list_holder, holder);
            OrderOprClickListener oprListener = new OrderOprClickListener(position);
            bt.setOnClickListener(oprListener);
            holder.oprBtList.addView(bt);
            holder.oprBtPlacer.setVisibility(View.VISIBLE);
        } else {
            if (oprList.size() == 0) {
                holder.oprBtPlacer.setVisibility(View.GONE);
                return;
            }
        }

        //卖家回复评论查看评论不共存（为解决卖家能修改买家评论BUG）
        oprList = OrderUtil.removeCommentOpr(oprList);

        for (int i = oprList.size() - 1; i >= 0; i--) {
            TextView bt = new FontTextView(context);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) Helper.convertDpToPixel(70, context),
                    (int) Helper.convertDpToPixel(30, context));
            params.setMargins(0, 0, (int) Helper.convertDpToPixel(10, context), 0);
            bt.setLayoutParams(params);
            bt.setGravity(Gravity.CENTER);
            bt.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
            Object[] data = oprList.get(i);
            if ((int) data[2] == 0) {
                bt.setTextColor(context.getResources().getColor(R.color.grey_a));
                bt.setBackgroundResource(R.drawable.order_list_edit_bg_white);
            } else {
                bt.setTextColor(context.getResources().getColor(R.color.brand_b));
                bt.setBackgroundResource(R.drawable.order_list_edit_bg_red);
            }
            bt.setText((String) data[1]);
            bt.setTag(R.id.order_list_order, order);
            bt.setTag(R.id.order_list_opr, (Long) data[0]);
            bt.setTag(R.id.order_list_holder, holder);
            OrderOprClickListener oprListener = new OrderOprClickListener(position);
            bt.setOnClickListener(oprListener);
            holder.oprBtList.addView(bt);
            holder.oprBtPlacer.setVisibility(View.VISIBLE);
        }

    }

    private void loadImg(String url, ViewGroup.LayoutParams layoutParams, SimpleDraweeView img) {
        int height = layoutParams.height;
        int width = layoutParams.width;
        if (url != null) {
            String reqUrl = url;
            if (width > 0) {
                reqUrl = ImgUtil.getCDNUrlWithWidth(url, width);
            } else if (height > 0) {
                reqUrl = ImgUtil.getCDNUrlWithHeight(url, height);
            }
            img.setImageURI(Uri.parse(reqUrl));
        }
    }

    class OrderItemHolder {
        public SimpleDraweeView userPic;
        public TextView userNick;
        public TextView iconUserRight;
        public TextView remarkFlag;
        public TextView status;
        public TextView priceExtra;
        public TextView priceTotal;
        public LinearLayout oprBtList;
        public LinearLayout oprBtPlacer;

        public LinearLayout serviceItemGroup;
        public TextView contactName;
        public TextView contactPhone;
        public TextView serviceAddress;
        public TextView serviceTime;
        public TextView createTime;
    }

    class OrderOprClickListener implements View.OnClickListener {

        private int position;

        public OrderOprClickListener(int position) {
            this.position = position;
        }

        @Override
        public void onClick(final View v) {

            OrderDO order = (OrderDO) v.getTag(R.id.order_list_order);
            final String orderNo = order.getOrderNo();
            if (CollectionUtil.isNotEmpty(order.getItemList())) {
                mFirstItem = order.getItemList().get(0);
            }
            final Long operate = (Long) v.getTag(R.id.order_list_opr);
            final OrderListAdapter.OrderItemHolder holder = (OrderListAdapter.OrderItemHolder) v.getTag(R.id.order_list_holder);

            if (operate == OrderUtil.OPEN_REMARK) {
                Intent intent = new Intent();
                intent.putExtra(Constant.EXTRA_TAG_ORDER_NO, order.getOrderNo());
                intent.putExtra(Constant.EXTRA_TAG_REMARK_CONTENT, order.getSellerInnerRemark());
                intent.putExtra(Constant.EXTRA_TAG_REMARK_FLAG, order.getSellerInnerFlag());
                intent.setClass(context, OrderRemarkActivity.class);
                context.startActivity(intent);

                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
                return;
            }

            /*
            支付
             */
            if ((OrderUtil.OPERATE_BUYER_CAN_PAY & operate) == OrderUtil.OPERATE_BUYER_CAN_PAY) {
                Bundle bundle = new Bundle();
                bundle.putString("orderNo", orderNo);
                bundle.putString("title", mFirstItem.getTitle());
                Router.sharedRouter().open("pay", bundle);

                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
            }
            /*
            取消
             */
            else if ((OrderUtil.OPERATE_BUYER_CAN_CANCEL & operate) == OrderUtil.OPERATE_BUYER_CAN_CANCEL) {
                tip("确认取消订单？取消后需重新下单", new TipCallback() {
                    @Override
                    public void execute() {
                        RequestOrderOpr.cancel(orderNo, new HttpClient.HttpCallback<JSONObject>() {
                            @Override
                            public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                                // 取消订单成功, 刷新列表
                                if (onOrderChangeLister != null) {
                                    onOrderChangeLister.onOrderRefresh();
                                }
                            }

                            @Override
                            public void onFail(HttpError error) {
                                MessageUtils.showToastCenter(error.getMessage());
                            }
                        });
                    }
                });
            }
            /*
            取消：已付款，卖家未接单
             */
            else if ((OrderUtil.OPERATE_BUYER_CAN_REFUND & operate) == OrderUtil.OPERATE_BUYER_CAN_REFUND) {
                Router.sharedRouter().open("orderCancel/" + orderNo + "/cancel");
                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
            }
            /*
            追加付款
             */
            else if ((OrderUtil.OPERATE_BUYER_CAN_ADD & operate) == OrderUtil.OPERATE_BUYER_CAN_ADD) {
                Router.sharedRouter().open("orderAdd/" + orderNo);
                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
            }
            /*
            延長時間
             */
            else if (((OrderUtil.OPERATE_BUYER_CAN_EXTEND & operate) == OrderUtil.OPERATE_BUYER_CAN_EXTEND) ||
                    ((OrderUtil.OPERATE_SELLER_CAN_EXTEND & operate) == OrderUtil.OPERATE_SELLER_CAN_EXTEND)) {
                String msg = "";
                final boolean isSeller = (OrderUtil.OPERATE_SELLER_CAN_EXTEND & operate) != 0;
                if (!isSeller) {
                    msg = "点击确定，自动确认收货时间将再延长3天。";
                } else {
                    msg = "点击确定，自动确认服务时间将再延长3天。";
                }
                tip(msg, new TipCallback() {
                    @Override
                    public void execute() {
                        RequestOrderOpr.extendTime(orderNo, new HttpClient.HttpCallback<JSONObject>() {
                            @Override
                            public void onSuccess(JSONObject result) {
                                if (onOrderChangeLister != null) {
                                    onOrderChangeLister.onOrderRefresh();
                                }
                            }

                            @Override
                            public void onFail(HttpError error) {
                                MessageUtils.showToastCenter("操作失败, " + error.toString());
                            }
                        });
                    }
                });
            }
            /*
            确认服务
             */
            else if (((OrderUtil.OPERATE_BUYER_CAN_CONFIRM & operate) == OrderUtil.OPERATE_BUYER_CAN_CONFIRM) ||             // 確認服務
                    ((OrderUtil.OPERATE_BUYER_CAN_CONFIRM_MAIL & operate) == OrderUtil.OPERATE_BUYER_CAN_CONFIRM_MAIL)) {   // 確認收貨
                String msg = "";
                final boolean needDeliver = (OrderUtil.OPERATE_BUYER_CAN_CONFIRM_MAIL & operate) != 0;
                if (!needDeliver) {
                    msg = "确认服务后，" + order.getAmountStr() + "元将立即到卖家账户，请务必在服务完成后确认";
                } else {
                    msg = "确认收货后，" + order.getAmountStr() + "元将立即到卖家账户，请务必在收到货后再确认";
                }
                tip(msg, new TipCallback() {
                    @Override
                    public void execute() {
                        RequestOrderOpr.confirm(orderNo, new HttpClient.HttpCallback<JSONObject>() {
                            @Override
                            public void onSuccess(JSONObject result) {
                                if (onOrderChangeLister != null) {
                                    onOrderChangeLister.onOrderRefresh();
                                }
                                Router.sharedRouter().open("orderJudge/" + OrderJudgeActivity.ADD + "/" + mFirstItem.getItemId() + "/" + orderNo);
                                if (onOrderChangeLister != null) {
                                    onOrderChangeLister.onOrderChange(position, orderNo);
                                }
                            }

                            @Override
                            public void onFail(HttpError error) {
                                MessageUtils.showToastCenter(error.toString());
                            }
                        });
                    }
                });
            }
            /*
            评价服务
             */
            else if ((OrderUtil.OPERATE_BUYER_CAN_COMMENT & operate) == OrderUtil.OPERATE_BUYER_CAN_COMMENT) {
                Router.sharedRouter().open("orderJudge/" + OrderJudgeActivity.ADD + "/" + mFirstItem.getItemId() + "/" + orderNo);
                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
            }
            /*
            卖家：接单
             */
            else if ((OrderUtil.OPERATE_SELLER_CAN_CONFIRM & operate) == OrderUtil.OPERATE_SELLER_CAN_CONFIRM) {
                if (checkAttention(OrderUtil.OPERATE_SELLER_CAN_CONFIRM, position)) {
                    getAttentionInfo(OrderUtil.OPERATE_SELLER_CAN_CONFIRM, holder, position);
                } else
                    acceptOrder(orderNo, holder, position);
            }
            /*
            卖家：拒单
             */
            else if ((OrderUtil.OPERATE_SELLER_CAN_REFUSE & operate) == OrderUtil.OPERATE_SELLER_CAN_REFUSE) {
                Router.sharedRouter().open("orderCancel/" + orderNo + "/reject");
                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
            }
            /*
            卖家评价
             */
            else if ((OrderUtil.OPERATE_SELLER_CAN_COMMENT & operate) == OrderUtil.OPERATE_SELLER_CAN_COMMENT) {
                String commentId = null;
                try {
                    JSONObject json = JSON.parseObject(order.getComment());
                    commentId = json.getString("commentId");
                    Router.sharedRouter().open("orderReply/" + OrderJudgeActivity.REPLY + "/" + commentId + "/" + orderNo);
                } catch (Exception e) {
                    Toast.makeText(context, "reply comment exception, commentId=" + commentId, Toast.LENGTH_LONG).show();
                }
            }
            /*
            卖家：发货
             */
            else if ((OrderUtil.OPERATE_SELLER_CAN_DELIVER & operate) == OrderUtil.OPERATE_SELLER_CAN_DELIVER) {
                if (checkAttention(OrderUtil.OPERATE_SELLER_CAN_DELIVER, position)) {
                    getAttentionInfo(OrderUtil.OPERATE_SELLER_CAN_DELIVER, holder, position);
                } else {
                    if (onOrderChangeLister != null) {
                        onOrderChangeLister.onOrderChange(position, orderNo);
                    }
                    Router.sharedRouter().open("orderDelivery/" + orderNo);
                }
            }
            /*
            买家：申请退款
             */
            else if ((OrderUtil.OPERATE_BUYER_CAN_APPLY_REFUND & operate) == OrderUtil.OPERATE_BUYER_CAN_APPLY_REFUND) {
                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
                if (mFirstItem.getServiceType() != null && OrderRefundActivity.TYPE_DELIVERY == mFirstItem.getServiceType()) {
                    Router.sharedRouter().open("orderRefund/" + OrderRefundActivity.TYPE_DELIVERY + "/" + orderNo);
                } else {
                    Router.sharedRouter().open("orderRefund/" + OrderRefundActivity.TYPE_SERVICE + "/" + orderNo);
                }
            }
            /*
            退款详情
             */
            else if ((OrderUtil.OPERATE_CAN_VIEW_APPLY_REFUND & operate) == OrderUtil.OPERATE_CAN_VIEW_APPLY_REFUND) {
                Router.sharedRouter().open("orderRefundDetail/" + orderNo);
                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
            }
            /*
            买家：删除
             */
            else if ((OrderUtil.OPERATE_BUYER_CAN_DELETE & operate) == OrderUtil.OPERATE_BUYER_CAN_DELETE) {
                tip("确认删除订单？删除之后无法恢复", new TipCallback() {
                    @Override
                    public void execute() {
                        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
                        params.put("orderNo", orderNo);
                        HttpClient.get("1.0/buyerOrder/delete", params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
                            @Override
                            public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                                List<OrderDO> dataList = mOrderList;
                                dataList.remove(position);
                                notifyDataSetChanged();
                            }

                            @Override
                            public void onFail(HttpError error) {
                                MessageUtils.showToastCenter(error.toString());
                            }
                        });
                    }
                });
            }
            /*
            查看评价.
             */
            else if (OrderUtil.OPERATE_OPEN_COMMENT == operate) {
                Router.sharedRouter().open("orderCommentByOrderId/" + orderNo, context);
                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
                //修改价格
            } else if ((OrderUtil.OPERATE_SELLER_CAN_BARGAIN & operate) == OrderUtil.OPERATE_SELLER_CAN_BARGAIN) {
                Router.sharedRouter().open("orderUpdatePrice/" + orderNo);
                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
            } else if ((OrderUtil.OPERATE_FINAL_PAY & operate) == OrderUtil.OPERATE_FINAL_PAY) {
                Bundle bundle = new Bundle();
                bundle.putString("orderNo", orderNo);
                bundle.putString("title", mFirstItem.getTitle());
                Router.sharedRouter().open("pay", bundle);

                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
            } else if ((OrderUtil.OPERATE_EARNEST & operate) == OrderUtil.OPERATE_EARNEST) {
                Bundle bundle = new Bundle();
                bundle.putString("orderNo", orderNo);
                bundle.putString("title", mFirstItem.getTitle());
                Router.sharedRouter().open("pay", bundle);

                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderChange(position, orderNo);
                }
            }

        }
    }

    private void tip(String msg, final TipCallback callback) {
        MessageUtils.createDialog(context, "提醒", msg, R.string.confirm, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                callback.execute();
            }
        }, R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // do nothing
            }
        }).show();
    }

    private void acceptOrder(String orderNo, final OrderListAdapter.OrderItemHolder holder, final int position) {
        RequestOrderOpr.sellConfirm(orderNo, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                if (onOrderChangeLister != null) {
                    onOrderChangeLister.onOrderRefresh();
                }
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error.toString());
            }
        });
    }

    /**
     * 检测操作是否在提醒范围中
     *
     * @return true 需要提醒
     */
    private boolean checkAttention(Long operate, int position) {
        try {
            if (CollectionUtil.isNotEmpty(mOrderList) && mOrderList.get(position) != null) {
                JSONArray oprAttention = mOrderList.get(position).getOprAttention();
                for (int i = 0; i < oprAttention.size(); i++) {
                    if (operate == Long.parseLong(oprAttention.get(i).toString())) {
                        return true;
                    }
                }
            }
        } catch (JSONException e) {
            Log.e(OrderListAdapter.this.getClass().toString(), e.getMessage());
        }
        return false;
    }

    /**
     * 获取提醒内容
     *
     * @param operate
     */
    private void getAttentionInfo(final Long operate, final OrderListAdapter.OrderItemHolder holder, final int position) {

        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("orderNo", mOrderList.get(position).getOrderNo());
        params.put("operate", operate.toString());
        HttpClient.get("1.0/sellerOrder/getOprAttention", params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject result) {
                if (result.getBoolean("isAttention")) {
                    com.alibaba.fastjson.JSONObject attention = result.getJSONObject("attention");
                    showAcceptWarnDialog(attention, holder, position, operate);
                } else {
                    if (OrderUtil.OPERATE_SELLER_CAN_CONFIRM == operate) {//接单
                        acceptOrder(mOrderList.get(position).getOrderNo(), holder, position);
                    } else if (OrderUtil.OPERATE_SELLER_CAN_DELIVER == operate) {  //发货
                        Router.sharedRouter().open("orderDelivery/" + mOrderList.get(position).getOrderNo());
                    }
                }
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter("获取提醒信息失败, " + error.toString());
            }
        });
    }

    private void showAcceptWarnDialog(com.alibaba.fastjson.JSONObject result, final OrderListAdapter.OrderItemHolder holder, final int position, final Long typeOperate) {
        // com.alibaba.fastjson.JSONObject attention = result.getJSONObject("attention");
        MyWarnDialog.Builder builder = new MyWarnDialog.Builder(context);
        builder.setTitle(result.getString("title"));
        View messageLayout = View.inflate(context, R.layout.dialog_sure_buyer, null);
        OrderAttentionListAdapter orderAttentionListAdapter = new OrderAttentionListAdapter(context,
                result.getJSONArray("tipList"), result.getJSONArray("warnList"));
        ListView listView = (ListView) messageLayout.findViewById(R.id.dialog_message_listView);
        listView.setAdapter(orderAttentionListAdapter);
        builder.setContentView(messageLayout);
        Long operate = Long.parseLong(result.get("operate").toString());
        final List<Object[]> operates = getAttentionOperate(operate);
        if (operates.size() > 0) {
            builder.setPositiveButton(operates.get(0)[1].toString(), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    attentionBtnClick((Long) operates.get(0)[0], typeOperate, dialog, holder, position);
                }
            });

            if (operates.size() > 1) {
                builder.setNegativeButton(operates.get(1)[1].toString(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        attentionBtnClick((Long) operates.get(1)[0], typeOperate, dialog, holder, position);
                    }
                });
            }
        }
        builder.create().show();
    }

    private void attentionBtnClick(Long operate, Long typeOperate, DialogInterface dialog, OrderListAdapter.OrderItemHolder holder, int position) {
        dialog.dismiss();
        if (OrderUtil.OPERATE_ATTENTION_ACCEPT == operate) { //继续接单
            if (OrderUtil.OPERATE_SELLER_CAN_CONFIRM == typeOperate) {//接单
                acceptOrder(mOrderList.get(position).getOrderNo(), holder, position);
            } else if (OrderUtil.OPERATE_SELLER_CAN_DELIVER == typeOperate) {  //发货
                Router.sharedRouter().open("orderDelivery/" + mOrderList.get(position).getOrderNo());
            }
        } else if (OrderUtil.OPERATE_ATTENTION_CANCEL == operate) { //取消

        } else if (OrderUtil.OPERATE_ATTENTION_CHECK_PROFILE == operate) { //去看主页
            if (mOrderList.get(position) != null && mOrderList.get(position).getUser() != null)
                Router.sharedRouter().open("profile/" + mOrderList.get(position).getUser().getUserId());
        } else if (OrderUtil.OPERATE_ATTENTION_GO_CONFIRM == operate) { //去认证
            Router.sharedRouter().open("certificationlist");
        }
    }

    private List<Object[]> getAttentionOperate(Long operate) {
        List<Object[]> operates = new ArrayList<Object[]>();
        if ((OrderUtil.OPERATE_ATTENTION_ACCEPT & operate) == OrderUtil.OPERATE_ATTENTION_ACCEPT) {
            operates.add(new Object[]{OrderUtil.OPERATE_ATTENTION_ACCEPT, "继续接单"});
        }
        if ((OrderUtil.OPERATE_ATTENTION_CHECK_PROFILE & operate) == OrderUtil.OPERATE_ATTENTION_CHECK_PROFILE) {
            operates.add(new Object[]{OrderUtil.OPERATE_ATTENTION_CHECK_PROFILE, "去看主页"});
        }
        if ((OrderUtil.OPERATE_ATTENTION_GO_CONFIRM & operate) == OrderUtil.OPERATE_ATTENTION_GO_CONFIRM) {
            operates.add(new Object[]{OrderUtil.OPERATE_ATTENTION_GO_CONFIRM, "去认证"});
        }
        if ((OrderUtil.OPERATE_ATTENTION_CANCEL & operate) == OrderUtil.OPERATE_ATTENTION_CANCEL) {
            operates.add(new Object[]{OrderUtil.OPERATE_ATTENTION_CANCEL, "取消"});
        }
        return operates;
    }

    public interface OnOrderChangeLister {
        void onOrderChange(int position, String orderNo);

        void onOrderRefresh();
    }

    public static interface TipCallback {
        public void execute();
    }
}
