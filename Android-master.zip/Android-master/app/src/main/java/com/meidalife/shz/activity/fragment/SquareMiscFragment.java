package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareMiscCategoryAdapter;
import com.meidalife.shz.adapter.SquareServiceBannerAdapter;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.SquareRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 找找看-格子(优化版本后服务社)
 * Created by liujian on 16/1/10.
 */
public class SquareMiscFragment extends BaseFragment {
    private View rootView;
    private Context context;
    private int geziId = Integer.MAX_VALUE;
    private boolean isLoading = false;
    private boolean isJoined;
    private boolean isGezhu;

    @Bind(R.id.serviceList)
    ListView serviceListView;
    @Bind(R.id.cellStatusErrorNetwork)
    LinearLayout cellStatusErrorNetwork;
    @Bind(R.id.cellStatusErrorServer)
    LinearLayout cellStatusErrorServer;
    @Bind(R.id.cellStatusLoading)
    LinearLayout cellStatusLoading;
    @Bind(R.id.noDataLayout)
    LinearLayout noDataLayout;
    @Bind(R.id.textStatusErrorServer)
    TextView textStatusErrorServer;
    @Bind(R.id.nearByHintLayout)
    LinearLayout nearByHintLayout;
    @Bind(R.id.categoryList)
    RecyclerView categoryListView;
    @Bind(R.id.line)
    View line;
    @Bind(R.id.nearbyHintLabel)
    TextView nearbyHintLabel;
    private AnimationDrawable loadingAnimation;
    private JSONArray categoryList;
    private GridView categoryGridView;
    private SquareMiscCategoryAdapter squareMiscCategoryAdapter;
    private View footerView;
    private JSONArray bannerList;
    private SquareServiceBannerAdapter squareServiceBannerAdapter;


    public static SquareMiscFragment newInstance(Bundle params) {
        SquareMiscFragment squareMiscFragment = new SquareMiscFragment();
        squareMiscFragment.setArguments(params);
        return squareMiscFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        EventBus.getDefault().register(this);
        if (rootView == null) {
            Bundle params = getArguments();
            if (params != null) {
                geziId = params.getInt("geziId", Integer.MAX_VALUE);
                isJoined = params.getBoolean("isJoined", false);
                isGezhu = params.getBoolean("isGezhu", false);
            }
            rootView = inflater.inflate(R.layout.fragment_square_list, container, false);

            context = getActivity();
            ButterKnife.bind(this, rootView);

            categoryListView.setVisibility(View.GONE);
            //line.setVisibility(View.GONE);
            serviceListView.setDivider(null);

            footerView = getLayoutInflater(savedInstanceState).inflate(R.layout.view_square_service_footer, null);
            categoryGridView = (GridView) footerView.findViewById(R.id.categoryGridView);
            serviceListView.addFooterView(footerView);

            categoryList = new JSONArray();
            squareMiscCategoryAdapter = new SquareMiscCategoryAdapter(context, categoryList);
            categoryGridView.setAdapter(squareMiscCategoryAdapter);
            footerView.setVisibility(View.GONE);

            bannerList = new JSONArray();
            squareServiceBannerAdapter = new SquareServiceBannerAdapter(context,bannerList);
            serviceListView.setAdapter(squareServiceBannerAdapter);

            initListener();

        }
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getData(true);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null)
                parent.removeView(rootView);
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    public void onEvent(SquareRefreshEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isLoading) {
            isJoined = event.isJoined;
            isGezhu = event.isGezhu;
            // servicesAdapter.setIsGezhu(isGezhu);
            getData(true);
        }
    }

    private void initListener() {
        cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData(true);
            }
        });
        cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData(true);
            }
        });
        serviceListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                openDatail(bannerList.getJSONObject(position));

            }
        });
        categoryGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                openDatail(categoryList.getJSONObject(position));
            }
        });
        serviceListView.setOnScrollListener(new AbsListView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                BaseEvent message = new BaseEvent();
                final View topChildView = serviceListView.getChildAt(0);
                if (scrollState == SCROLL_STATE_IDLE && serviceListView.getFirstVisiblePosition() == 0
                        && topChildView.getTop() == 0) {
                    message.eventType = MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                } else {
                    message.eventType = MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                }

//                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
//                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
//                        getData(false);
//                    }
//                }

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }
        });

    }

    private void openDatail(JSONObject item) {
        if (!item.containsKey("linkUrl") || TextUtils.isEmpty(item.getString("linkUrl")))
            return;
        String linkUrl = item.getString("linkUrl");
        if (linkUrl.contains("http://")) {  //H5页面
            Bundle bundle = new Bundle();
            bundle.putString("url", linkUrl);
            Router.sharedRouter().open("web", bundle);
        } else {
            try {
                Router.sharedRouter().open(linkUrl);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void getData(final boolean isShowLoading){
        if(isShowLoading)
            showStatusLoading();
        isLoading = true;
        cellStatusErrorNetwork.setVisibility(View.GONE);
        cellStatusErrorServer.setVisibility(View.GONE);
        noDataLayout.setVisibility(View.GONE);
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        HttpClient.get("1.1/gezi/service/home", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                if (isShowLoading)
                    hideStatusLoading();
                isLoading = false;
                serviceListView.setVisibility(View.VISIBLE);
                if (obj.containsKey("banners"))
                    initBannerData(obj.getJSONArray("banners"));
                if (obj.containsKey("icons"))
                    initCategoryData(obj.getJSONArray("icons"));
                BaseEvent message = new BaseEvent();
                if (obj.containsKey("displayAddBadge") && obj.getBoolean("displayAddBadge")) {
                    message.eventType = MsgTypeEnum.TYPE_SHOW_SERVICE_PUBLISH;
                } else
                    message.eventType = MsgTypeEnum.TYPE_HIDE_SERVICE_PUBLISH;
                EventBus.getDefault().post(message);
                if (bannerList.size() == 0 && categoryList.size() == 0) {
                    serviceListView.setVisibility(View.GONE);
                    noDataLayout.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                serviceListView.setVisibility(View.GONE);
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    cellStatusErrorNetwork.setVisibility(View.VISIBLE);
                    return;
                }
                if (!TextUtils.isEmpty(error.getMessage())) {
                    textStatusErrorServer.setText(error.getMessage());
                }
                cellStatusErrorServer.setVisibility(View.VISIBLE);
            }
        });
    }

    private void initBannerData(JSONArray banners){
        bannerList.clear();
        bannerList.addAll(banners);
        squareServiceBannerAdapter.notifyDataSetChanged();
    }

    private void initCategoryData(JSONArray cats){
        categoryList.clear();
        categoryList.addAll(cats);
        if(categoryList.size() == 0){
            footerView.setVisibility(View.GONE);
        }else
            footerView.setVisibility(View.VISIBLE);
        squareMiscCategoryAdapter.notifyDataSetChanged();
    }


    private void showStatusLoading() {
        serviceListView.setVisibility(View.GONE);
        try {
            cellStatusLoading.setVisibility(View.VISIBLE);
            loadingAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.loading_animation);
            ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
            loadingImage.setBackgroundDrawable(loadingAnimation);
            loadingAnimation.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideStatusLoading() {
        try {
            if (cellStatusLoading != null) {
                cellStatusLoading.setVisibility(View.GONE);
                if (loadingAnimation != null) {
                    loadingAnimation.stop();
                    loadingAnimation = null;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

