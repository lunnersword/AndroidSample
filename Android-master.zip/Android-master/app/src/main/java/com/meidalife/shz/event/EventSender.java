package com.meidalife.shz.event;

import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.event.type.ModifyUnReadMsdCountEventModel;
import com.meidalife.shz.event.type.NetworkConnectEventModel;
import com.meidalife.shz.event.type.NetworkConnectTypeEnum;
import com.meidalife.shz.event.type.NewMsgEventModel;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.event.type.ResizeFragmentHeightEventModel;
import com.meidalife.shz.event.type.SquareAddressEventModel;
import com.meidalife.shz.event.type.TabMaskDisplayEventModel;
import com.meidalife.shz.event.type.TabMaskDisplayTypeEnum;
import com.meidalife.shz.rest.model.SquareAddressOutDO;

import de.greenrobot.event.EventBus;

/**
 * EventBus发送消息类
 * Created by zhq on 15/10/14.
 */
public class EventSender {


    private static void send(Object eventModel) {
        EventBus.getDefault().post(eventModel);
    }


    public static void displayTabMask(TabMaskDisplayTypeEnum type) {
        TabMaskDisplayEventModel displayModel = new TabMaskDisplayEventModel();
        displayModel.type = type;
        send(displayModel);
    }

    // 当有新消息到达 更新消息tab（或者通知tab)小红点
    public static void notifyHadNewMsg(MsgTypeEnum type, int unReadMsgCount) {
        NewMsgEventModel msgModel = new NewMsgEventModel();
        msgModel.type = type;
        msgModel.unReadMsgCount = unReadMsgCount;
        send(msgModel);
    }

    //   点击消息tab会话list(或者通知tab会话list) 进入会话详情  对消息tab未读数进行减操作
    public static void modifyUnReadMsgCount(MsgTypeEnum type, int msgCount) {
        ModifyUnReadMsdCountEventModel model = new ModifyUnReadMsdCountEventModel();
        model.type = type;
        model.msgCount = msgCount;
        send(model);
    }

    public static void notifyNetworkChanged(NetworkConnectTypeEnum type) {
        NetworkConnectEventModel msgModel = new NetworkConnectEventModel();
        msgModel.type = type;
        send(msgModel);
    }

    public static void reMeasureFragmentHeight(int msgCount, int totalHeight) {
        ResizeFragmentHeightEventModel model = new ResizeFragmentHeightEventModel();
        model.position = msgCount;
        model.totalHeight = totalHeight;
        send(model);
    }

    public static void notifyItemClicked(SquareAddressOutDO type) {
        SquareAddressEventModel msgModel = new SquareAddressEventModel();
        msgModel.address = type;
        send(msgModel);
    }
}
