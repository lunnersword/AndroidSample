package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;

import java.util.ArrayList;
import java.util.List;

public class ProfileAdapter extends BaseAdapter {
    private final int ICON_SIZE;
    private List<ProfileItem> data = new ArrayList<>();
    private Context context;

    public ProfileAdapter(Context context, List<ProfileItem> data) {
        this.context = context;
        setData(data);
        ICON_SIZE = context.getResources().getDimensionPixelSize(R.dimen.profile_item_icon_size);
    }

    public void setData(List<ProfileItem> data) {
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        ProfileItem item = data.get(position);
        if (convertView == null || convertView.getTag() == null) {
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.item_profile_icon, parent, false);
            viewHolder.icon = (SimpleDraweeView) convertView.findViewById(R.id.profileIcon);
            viewHolder.title = (TextView) convertView.findViewById(R.id.profileItemName);
            viewHolder.badge = (TextView) convertView.findViewById(R.id.badge);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.icon.setTag(item);

        if (!TextUtils.isEmpty(item.iconUrl)) {
            viewHolder.icon.setImageURI(Uri.parse(item.iconUrl));
        }
        if (!TextUtils.isEmpty(item.badge)) {
            viewHolder.badge.setText(item.badge);
            viewHolder.badge.setVisibility(View.VISIBLE);
        } else {
            viewHolder.badge.setVisibility(View.GONE);
        }
        viewHolder.title.setText(item.title);
        return convertView;
    }

    public static class ViewHolder {
        SimpleDraweeView icon;
        TextView title;
        TextView badge;
    }

    public static class ProfileItem {
        String iconUrl;
        String title;
        String badge;
        String action;

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getBadge() {
            return badge;
        }

        public void setBadge(String badge) {
            this.badge = badge;
        }

        public String getAction() {
            return action;
        }

        public void setAction(String action) {
            this.action = action;
        }
    }
}