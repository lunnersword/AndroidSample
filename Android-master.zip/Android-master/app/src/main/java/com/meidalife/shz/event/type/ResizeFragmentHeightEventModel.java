
package com.meidalife.shz.event.type;

/**
 * Created by zuozheng on 14-10-31.
 */
public class ResizeFragmentHeightEventModel {

    public int type = 1000;
    public int position;
    public int totalHeight;
}
