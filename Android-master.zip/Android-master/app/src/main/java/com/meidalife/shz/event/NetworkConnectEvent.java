package com.meidalife.shz.event;

import com.meidalife.shz.event.type.NetworkConnectEventModel;

/**
 * Created by zuozheng on 14-10-31.
 */
public interface NetworkConnectEvent {

    public void onEvent(NetworkConnectEventModel model);
}
