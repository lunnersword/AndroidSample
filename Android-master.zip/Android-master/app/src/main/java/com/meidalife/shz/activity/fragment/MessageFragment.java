package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.event.type.NewMsgEventModel;

import de.greenrobot.event.EventBus;

public class MessageFragment extends BaseFragment {
    private FragmentActivity context;
    private LayoutInflater inflater;

    private FragmentTabHost mTabHost;
    public View chatUnread;
    public View notifyUnread;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootLayout = inflater.inflate(R.layout.fragment_message, null);
        this.inflater = inflater;
        this.context = getActivity();

        mTabHost = (FragmentTabHost) rootLayout.findViewById(android.R.id.tabhost);
        mTabHost.setup(context, getChildFragmentManager(), R.id.realtabcontent);

        // 增加tab
        mTabHost.addTab(getTabSpecView(MsgTypeEnum.TYPE_CHAT, R.drawable.msg_type_bg_selector),
                MessageChatFragment.class, null);
        mTabHost.addTab(getTabSpecView(MsgTypeEnum.TYPE_NOTIFICATION, R.drawable.msg_type_bg_selector),
                MessageNotifyFragment.class, null);
        mTabHost.setCurrentTab(0);


        return rootLayout;
    }

    @Override
    public void onResume() {
        EventBus.getDefault().registerSticky(this);
        super.onResume();
    }

    @Override
    public void onPause() {
        EventBus.getDefault().unregister(this);
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    /**
     * 接收未读消息通知决定标签页小红点是否显示
     *
     * @param model
     */
    public void onEvent(NewMsgEventModel model) {
        int unread = model.unReadMsgCount;
        switch (model.type) {
            case TYPE_CHAT: {
                //存在未读聊天消息
                chatUnread.setVisibility(unread > 0 ? View.VISIBLE : View.GONE);
                break;
            }
            case TYPE_NOTIFICATION: {
                //存在未读通知消息
                notifyUnread.setVisibility(unread > 0 ? View.VISIBLE : View.GONE);
                break;
            }
            default: {
                chatUnread.setVisibility(View.GONE);
                notifyUnread.setVisibility(View.GONE);
            }
        }
    }

    private FragmentTabHost.TabSpec getTabSpecView(MsgTypeEnum type, int bg) {
        View view = inflater.inflate(R.layout.fragment_message_tab, null);
        TextView tabText = (TextView) view.findViewById(R.id.tabText);
        if (type == MsgTypeEnum.TYPE_CHAT) {
            chatUnread = view.findViewById(R.id.badge);
            tabText.setText(R.string.tab_item_chat_text);
        } else {
            notifyUnread = view.findViewById(R.id.badge);
            tabText.setText(R.string.tab_item_notification_text);
        }

        tabText.setBackgroundResource(bg);
        return mTabHost.newTabSpec(String.valueOf(type)).setIndicator(view);
    }
}
