package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ProfileImageDO;
import com.meidalife.shz.util.ImgUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class CoverFlowAdapter extends BaseAdapter {

    private List<ProfileImageDO> mData;
    private Context mContext;

    private String videoUrl;
    private String videoPicUrl;

    private boolean isSelf;
    private final int COVERFLOW_ICON_SIZE;

    public void setData(ArrayList<ProfileImageDO> data) {
        mData = data;
    }

    public CoverFlowAdapter(Context context, List<ProfileImageDO> data) {
        mContext = context;
        mData = data;
        COVERFLOW_ICON_SIZE = mContext.getResources().getDimensionPixelSize(R.dimen.cover_height);
    }

    public void setVideoPicUrl(String videoPicUrl) {
        this.videoPicUrl = videoPicUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public void setIsSelf(boolean isSelf) {
        this.isSelf = isSelf;
    }

    public List<ProfileImageDO> getData() {
        return mData;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int pos) {
        return mData.get(pos);
    }

    @Override
    public long getItemId(int pos) {
        return pos;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View rowView = convertView;

        if (rowView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowView = inflater.inflate(R.layout.item_coverflow, null);
            ViewHolder viewHolder = new ViewHolder(rowView);
//            viewHolder.iconEmpty.setTypeface(Helper.sharedHelper().getIconFont());
            rowView.setTag(viewHolder);
        }

        ProfileImageDO profileImageDO = mData.get(position);
        ViewHolder holder = (ViewHolder) rowView.getTag();

        //有视频 第一个显示播放按钮
        if (position == 3) {
            if (TextUtils.isEmpty(videoUrl)) {
                //隐藏
                holder.videoPlay.setVisibility(View.GONE);
                //todo 如果是用户自己
                if (isSelf && profileImageDO == null) {
                    //显示添加视频按钮
                    holder.addVideoTip.setVisibility(View.VISIBLE);
                } else {
                    holder.addVideoTip.setVisibility(View.GONE);
                }

                holder.imageCoverflow.setVisibility(View.GONE);

                if (profileImageDO != null) {
                    //此处缓存大图，加快coverflow背景图加载
                    Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(profileImageDO.getUri(), COVERFLOW_ICON_SIZE));
                    holder.imageCoverflow.setImageURI(uri);
                    holder.imageCoverflow.setVisibility(View.VISIBLE);
                } else {
                    holder.imageCoverflow.setVisibility(View.GONE);
                }
            } else {
                //显示播放按钮 隐藏提示添加view
                holder.addVideoTip.setVisibility(View.GONE);
                holder.videoPlay.setVisibility(View.VISIBLE);
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(videoPicUrl, holder.imageCoverflow.getLayoutParams().width));
                holder.imageCoverflow.setImageURI(uri);
                holder.imageCoverflow.setVisibility(View.VISIBLE);
            }
        } else {
            holder.videoPlay.setVisibility(View.GONE);
            holder.addVideoTip.setVisibility(View.GONE);

            if (profileImageDO != null) {
                //此处缓存大图，加快coverflow背景图加载
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(profileImageDO.getUri(), COVERFLOW_ICON_SIZE));
                holder.imageCoverflow.setImageURI(uri);
                holder.imageCoverflow.setVisibility(View.VISIBLE);
            } else {
                holder.imageCoverflow.setVisibility(View.GONE);
            }
        }
        return rowView;
    }


    static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.imageCoverflow)
        SimpleDraweeView imageCoverflow;

        @Bind(R.id.addVideoTip)
        View addVideoTip;
        @Bind(R.id.videoPlay)
        View videoPlay;
    }
}
