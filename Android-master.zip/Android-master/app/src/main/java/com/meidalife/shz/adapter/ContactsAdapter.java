package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ContactDO;
import com.meidalife.shz.rest.request.RequestContacts;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.StrUtil;

import java.util.List;

/**
 * Created by shijian on 15/7/12.
 */
public class ContactsAdapter extends BaseAdapter {

    public List<Object> dataList;
    private LayoutInflater inflater;
    private Context context;

    private View.OnClickListener inviteListener = new InviteOnClickListener();

    public ContactsAdapter(LayoutInflater inflater, Context context, List<Object> dataList) {
        this.inflater = inflater;
        this.context = context;
        this.dataList = dataList;
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    /**
     * 添加item时判断，如果读取到的数据可以在arrayList中找到（即大写的单独字母），则添加为标题，否则是内容
     */
    public View getView(int position, View convertView, ViewGroup parent) {

        Object obj = dataList.get(position);

        if (obj instanceof ContactDO) {
            ContactDO c = (ContactDO) obj;
            View view = inflater.inflate(R.layout.earn_mcoin_contacts_item, null);
            SimpleDraweeView avatar = (SimpleDraweeView) view.findViewById(R.id.contacts_item_avatar);
            if (!StrUtil.isEmpty(c.getAvatar())) {
                ImgUtil.load(context, c.getAvatar(), avatar.getLayoutParams(), avatar);
            }
            TextView nick = (TextView) view.findViewById(R.id.contacts_item_nick);
            nick.setText(c.getName());
            TextView phone = (TextView) view.findViewById(R.id.contacts_item_phone);
            phone.setText(c.getNumber());
            TextView invite = (TextView) view.findViewById(R.id.contacts_item_invite);
            invite.setText(c.getStatusHint());
            int status = c.getStatus();
            if (status == 1) {
                invite.setTag(position);
                invite.setOnClickListener(inviteListener);
            } else {
                invite.setBackgroundColor(context.getResources().getColor(R.color.white));
                invite.setTextColor(context.getResources().getColor(R.color.grey_c));
            }
            convertView = view;
        } else {
            String c = (String) obj;
            View view = inflater.inflate(R.layout.earn_mcoin_contacts_tag, null);
            TextView tag = (TextView) view.findViewById(R.id.contacts_item_tag);
            tag.setText(c);
            convertView = view;
        }

        return convertView;
    }


    class InviteOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            final TextView invite = (TextView) v;
            final Integer index = (Integer) v.getTag();
            String phoneNum = ((ContactDO) dataList.get(index)).getNumber();
            RequestContacts.invite(phoneNum, new HttpClient.HttpCallback<ContactDO>() {
                @Override
                public void onSuccess(ContactDO contact) {
//                    ContactDO contact = (ContactDO) result;
                    invite.setBackgroundColor(context.getResources().getColor(R.color.white));
                    invite.setTextColor(context.getResources().getColor(R.color.grey_c));
                    invite.setText(contact.getStatusHint());
                    invite.setOnClickListener(null);
                    dataList.set(index, contact);
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToastCenter("服务开点小差，邀请失败请重试");
                }
            });
        }
    }


}
