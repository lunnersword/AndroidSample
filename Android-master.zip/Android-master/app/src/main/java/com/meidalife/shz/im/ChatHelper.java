package com.meidalife.shz.im;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.text.style.TypefaceSpan;
import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.wukong.Callback;
import com.alibaba.wukong.auth.ALoginParam;
import com.alibaba.wukong.auth.AuthInfo;
import com.alibaba.wukong.auth.AuthService;
import com.alibaba.wukong.im.IMEngine;
import com.alibaba.wukong.im.MessageContent;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.MessageDO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by fufeng on 15/10/19.
 */
public class ChatHelper {
    private static final String LOG_TAG = "ChatHelper";
    public static Map<String, String> faceExpressionMap = new HashMap<>();
    private Context context;
    private static ChatHelper chatHelper;
    private boolean logining = false;

    private ChatHelper(Context context) {
        this.context = context;
        initExpressionMap();
    }

    public static ChatHelper getInstance(Context context) {
        if (chatHelper == null) {
            chatHelper = new ChatHelper(context.getApplicationContext());
        }
        return chatHelper;
    }

    private void initExpressionMap() {
        try {
            InputStream in = context.getAssets().open("faces/official/meta.json");
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line = null;
            StringBuilder content = new StringBuilder();
            while ((line = br.readLine()) != null) {
                content.append(line);
            }
            JSONArray metaList = JSONArray.parseArray(content.toString());
            for (int i = 0; i < metaList.size(); i++) {
                JSONObject obj = metaList.getJSONObject(i);
                faceExpressionMap.put(obj.getString("name"), obj.getString("file"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public Spannable getExpressionSpanText(String sourceText, int spanSize) {
        Spannable spanText = new SpannableString(sourceText);
        try {
            Pattern p = Pattern.compile("\\[\\w+\\]");
            Matcher matcher = p.matcher(sourceText);
            int start = 0;
            int end = 0;
            while (matcher.find()) {
                start = matcher.start();
                end = matcher.end();
                String expression = sourceText.substring(start, end);
                ImageSpan expressionPan = getImageSpan(expression, spanSize);
                if (start < end && expressionPan != null) {
                    spanText.setSpan(expressionPan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }

            Pattern emojiPattern = Pattern.compile("[\\ud83c\\udc00-\\ud83c\\udfff]|[\\ud83d\\udc00-\\ud83d\\udfff]|[\\u2600-\\u27ff]",
                    Pattern.UNICODE_CASE | Pattern.CASE_INSENSITIVE);
            Matcher emojiPatternMatcher = emojiPattern.matcher(spanText);
            int emojiStart = 0;
            int emojiEnd = 0;
            while (emojiPatternMatcher.find()) {
                emojiStart = emojiPatternMatcher.start();
                emojiEnd = emojiPatternMatcher.end();
                TypefaceSpan typefaceSpan = new TypefaceSpan("monospace");

                if (emojiStart < emojiEnd) {
                    spanText.setSpan(typefaceSpan, emojiStart, emojiEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return spanText;
    }

    public ImageSpan getImageSpan(String name, int size) {
        String file = faceExpressionMap.get(name);
        if (file == null) {
            return null;
        }
        InputStream in = null;
        try {
            in = context.getAssets().open("faces/official/" + file);
            Bitmap expressionBitmap = BitmapFactory.decodeStream(in);

            Bitmap scaledBitmap = Bitmap.createScaledBitmap(expressionBitmap,
                    (int) Helper.convertDpToPixel(size, context),
                    (int) Helper.convertDpToPixel(size, context), true);
            if (!expressionBitmap.equals(scaledBitmap)) {
                expressionBitmap.recycle();
            }

            return new ImageSpan(context, scaledBitmap);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != in) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public void authWuKong(final String userId) {
        if (!logining) {
            logining = true;
            final AuthService authService = IMEngine.getIMService(AuthService.class);
            com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
            params.put("devType", "android");
            HttpClient.get("1.0/conversation/loginWuKongIM", params, com.alibaba.fastjson.JSONObject.class,
                    new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
                        @Override
                        public void onSuccess(com.alibaba.fastjson.JSONObject obj) {

                            ALoginParam loginParam = new ALoginParam();
                            loginParam.openId = Long.parseLong(userId);
                            loginParam.domain = obj.getString("domain");
                            loginParam.nonce = obj.getString("nonce");
                            loginParam.timestamp = obj.getLong("timestamp");
                            loginParam.signature = obj.getString("signature");

                            authService.login(loginParam, new Callback<AuthInfo>() {
                                @Override
                                public void onSuccess(AuthInfo authInfo) {
                                    Log.e(LOG_TAG, "auth wukong succes, " + userId);
                                    logining = false;
                                }

                                @Override
                                public void onException(String s, String s1) {
                                    MessageUtils.showToastCenter(SHZApplication.getInstance().
                                            getString(R.string.error_wukong_login_failed) + ":" + s + ": " + s1);
                                    Log.d(LOG_TAG, s + "; " + s1);
                                    logining = false;
                                }

                                @Override
                                public void onProgress(AuthInfo authInfo, int i) {
                                }
                            });
                        }

                        @Override
                        public void onFail(HttpError error) {
                            MessageUtils.showToastCenter(SHZApplication.getInstance().
                                    getString(R.string.error_wukong_login_failed));
                            logining = false;
                        }
                    });
        }
    }

    public static String getMessageSubTitle(MessageContent content) {
        if (content instanceof MessageContent.TextContent) {
            return ((MessageContent.TextContent) content).text();
        } else if (content instanceof MessageContent.ImageContent) {
            return "[图片]";
        } else if (content instanceof MessageContent.AudioContent) {
            return "[语音]";
        } else if (content.type() == MessageDO.MESSAGE_TYPE_SERVICE) {
            return "[服务]";
        } else if (content.type() == MessageDO.MESSAGE_TYPE_ADDRESS) {
            return "[地图]";
        } else if (content.type() == MessageDO.MESSAGE_TYPE_BONUS) {
            return "[打赏]";
        } else if (content.type() == MessageDO.MESSAGE_TYPE_REMINDER) {
            return "[提醒]";
        } else {
            return "[未知]";
        }
    }
}
