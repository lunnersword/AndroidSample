package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.common.util.UriUtil;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareBbsDetailDO;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by mzzcy on 2015/12/20.
 */
public class SquareBbsDetailAdapter extends BaseAdapter implements View.OnClickListener {

    private static final String TAG_HOLDER = "topicHolder";
    private static final String TAG_TYPE = "type";
    private Context mContext;
    private LayoutInflater mInflater;
    private JSONObject mSquareBbsTopicItem;
    private ArrayList<SquareBbsDetailDO> mData;
    private int topicId;
    private ChatHelper mChatHelper;
    private boolean haveSupported = false;
    private boolean haveAgainsted = false;
    private boolean hasUpdateVote = false;

    private static final int TYPE_ZAN = 10;
    private static final int TYPE_CAI = 11;

    private static final int TYPE_COUNT = 3;
    public static final int VIEW_TYPE_TOPIC = 0;
    private static final int VIEW_TYPE_REPLY_COUNT = 1;
    public static final int VIEW_TYPE_REPLY = 2;
    private int caiCountNumber;
    private int zanCountNumber;

    ReplyHolder replyHolder = null;
    TopicHolder topicHolder = null;

    private View.OnClickListener onClickListener;


    class TopicHolder {
        private View view;

        SimpleDraweeView imageAvatar;
        TextView iconGender;
        TextView textNick;
        TextView textTime;
        SimpleDraweeView iconTitleView;
        TextView textTitle;
        SimpleDraweeView picView;
        View zanContainer;
        IconTextView zanIcon;
        TextView zanCount;

        View caiContainer;
        IconTextView caiIcon;
        TextView caiCount;
        TextView iconTitle;
        TextView pinHandlerView;

        public TopicHolder(View view) {
            this.view = view;
            Log.d("mzLog TopicHolder", "start find ");

            caiContainer = this.view.findViewById(R.id.caiContainer);
            caiIcon = (IconTextView) this.view.findViewById(R.id.caiIcon);
            zanContainer = this.view.findViewById(R.id.zanContainer);
            caiIcon = (IconTextView) this.view.findViewById(R.id.caiIcon);
            caiCount = (TextView) this.view.findViewById(R.id.caiCount);
            iconGender = (TextView) this.view.findViewById(R.id.iconGender);
            textNick = (TextView) this.view.findViewById(R.id.textNick);
            textTime = (TextView) this.view.findViewById(R.id.textTime);
            textTitle = (TextView) this.view.findViewById(R.id.textTitle);
            iconTitleView = (SimpleDraweeView) this.view.findViewById(R.id.iconTitleView);
            iconTitle = (TextView) this.view.findViewById(R.id.iconTitle);
            zanCount = (TextView) this.view.findViewById(R.id.zanCount);
            zanIcon = (IconTextView) this.view.findViewById(R.id.zanIcon);
            picView = (SimpleDraweeView) this.view.findViewById(R.id.picView);
            imageAvatar = (SimpleDraweeView) this.view.findViewById(R.id.imageAvatar);
            pinHandlerView = (TextView) this.view.findViewById(R.id.pinHandlerView);
        }
    }

    class ReplyHolder {
        private View view;

        SimpleDraweeView userAvatar;
        IconTextView iconGender;
        FontTextView textNick;
        FontTextView floor;
        FontTextView beforeTime;
        FontTextView reply;
        SimpleDraweeView picView;
        TextView pinHandlerView;
        View replyContainer;
        FontTextView replyNick;
        IconTextView replyIconGender;

        public ReplyHolder(View view) {
            this.view = view;

            Log.d("mzLog ReplyHolder", "start find ");
            userAvatar = (SimpleDraweeView) this.view.findViewById(R.id.imageAvatar);
            iconGender = (IconTextView) this.view.findViewById(R.id.iconGender);
            textNick = (FontTextView) this.view.findViewById(R.id.textNick);
            floor = (FontTextView) this.view.findViewById(R.id.floor);
            beforeTime = (FontTextView) this.view.findViewById(R.id.beforeTime);
            reply = (FontTextView) this.view.findViewById(R.id.reply);
            picView = (SimpleDraweeView) this.view.findViewById(R.id.picView);
            pinHandlerView = (TextView) this.view.findViewById(R.id.pinHandlerView);
            replyContainer = this.view.findViewById(R.id.replyContainer);
            replyNick = (FontTextView) this.view.findViewById(R.id.replyNick);
            replyIconGender = (IconTextView) this.view.findViewById(R.id.replyIconGender);
        }
    }

    public SquareBbsDetailAdapter(Context context, JSONObject squareBbsItem, ArrayList<SquareBbsDetailDO> data) {
        try {
            mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            mSquareBbsTopicItem = squareBbsItem;
            mData = data;
            mContext = context;
            mChatHelper = ChatHelper.getInstance(context);
            zanCountNumber = mSquareBbsTopicItem.getInteger("supportCount");
            caiCountNumber = mSquareBbsTopicItem.getInteger("againstCount");
            if (mSquareBbsTopicItem.containsKey("voteValue")) {
                if (mSquareBbsTopicItem.getIntValue("voteValue") == 1) {
                    haveSupported = true;
                } else if (mSquareBbsTopicItem.getIntValue("voteValue") == -1) {
                    haveAgainsted = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean getHasUpdateVote() {
        return hasUpdateVote;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    @Override
    public int getCount() {
        Log.d("mzLog", "mData size " + mData.size());
        return mData.size() + 2;
    }

    @Override
    public SquareBbsDetailDO getItem(int position) {
        return mData.get(position - 2);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View converView, ViewGroup parent) {

        View view = null;
        View viewTopic = null;
        View viewReplyCount;
        View viewReply = null;

        if (position == 0) {

            if (converView != null) {
                HashMap tag = (HashMap) converView.getTag();
                int type = (int) tag.get(TAG_TYPE);
                if (type == VIEW_TYPE_TOPIC) {
                    viewTopic = converView;
                    topicHolder = (TopicHolder) tag.get(TAG_HOLDER);
                }
            }
            if (viewTopic == null) {

                Log.d("mzLog helpAdapter", "position: " + position);
                viewTopic = mInflater.inflate(R.layout.item_square_bbs_topic_detail, parent, false);
                topicHolder = new TopicHolder(viewTopic);
                HashMap tag = new HashMap();
                tag.put(TAG_HOLDER, topicHolder);
                tag.put(TAG_TYPE, VIEW_TYPE_TOPIC);
                viewTopic.setTag(tag);
            }
            topicId = (Integer) mSquareBbsTopicItem.get("id");
            topicHolder.caiCount.setText(String.valueOf(caiCountNumber));
            topicHolder.zanCount.setText(String.valueOf(zanCountNumber));
            String time = DateUtils.getOffsetDays(System.currentTimeMillis(), (Long) mSquareBbsTopicItem.get("createTime"));
            topicHolder.textTime.setText(time);
            if ("M".equals(mSquareBbsTopicItem.get("userGender"))) {
                topicHolder.iconGender.setText(R.string.icon_gender_m);
                topicHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.gender_m));
            } else {
                topicHolder.iconGender.setText(R.string.icon_gender_f);
                topicHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.pink_a));
            }

            if (onClickListener != null) {
                HashMap params = new HashMap();
                params.put("id", mSquareBbsTopicItem.getIntValue("id"));
                params.put("type", VIEW_TYPE_TOPIC);
                params.put("isOwn", Helper.sharedHelper().getUserId().equals(mSquareBbsTopicItem.getIntValue("userId") + ""));
                topicHolder.pinHandlerView.setTag(params);
                topicHolder.pinHandlerView.setOnClickListener(onClickListener);
            }

            topicHolder.zanIcon.setTextColor(mContext.getResources().getColor(R.color.grey_c));
            topicHolder.caiIcon.setTextColor(mContext.getResources().getColor(R.color.grey_c));
            topicHolder.zanCount.setTextColor(mContext.getResources().getColor(R.color.grey_c));
            topicHolder.caiCount.setTextColor(mContext.getResources().getColor(R.color.grey_c));

            if (haveSupported) {
                topicHolder.zanIcon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                topicHolder.zanCount.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            } else if (haveAgainsted) {
                topicHolder.caiIcon.setTextColor(mContext.getResources().getColor(R.color.grey_k));
                topicHolder.caiCount.setTextColor(mContext.getResources().getColor(R.color.grey_k));
            }

            JSONArray picArr = (JSONArray) mSquareBbsTopicItem.get("pics");
            if (picArr == null || picArr.size() == 0 || ((String) (picArr.get(0))).isEmpty()) {
                topicHolder.picView.setVisibility(View.GONE);

            } else {
                topicHolder.picView.setVisibility(View.VISIBLE);
                String picurl = (String) picArr.get(0);
                topicHolder.picView.setImageURI(Uri.parse(picurl));
                topicHolder.picView.setTag(picurl);
                topicHolder.picView.setOnClickListener(this);
            }
//            if (mSquareBbsTopicItem.containsKey("voteValue")) {
//                haveVoted = mSquareBbsTopicItem.getInteger("voteValue");
//            }

            if (mSquareBbsTopicItem.containsKey("userAvatar")) {
                topicHolder.imageAvatar.setImageURI(Uri.parse((String) mSquareBbsTopicItem.get("userAvatar")));
            } else
                topicHolder.imageAvatar.setImageURI(Uri.parse(""));
            topicHolder.textNick.setText((String) mSquareBbsTopicItem.get("userNick"));
            topicHolder.textTitle.setText((String) mSquareBbsTopicItem.get("title"));
            if (((String) mSquareBbsTopicItem.get("icon")).contains("http://")) {
                topicHolder.iconTitleView.setImageURI(Uri.parse((String) mSquareBbsTopicItem.get("icon")));
                topicHolder.iconTitle.setVisibility(View.GONE);
                topicHolder.iconTitleView.setVisibility(View.VISIBLE);
            } else {
                topicHolder.iconTitle.setText((String) mSquareBbsTopicItem.get("icon"));
                topicHolder.iconTitleView.setVisibility(View.GONE);
                topicHolder.iconTitle.setVisibility(View.VISIBLE);
            }

            topicHolder.zanContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (haveSupported) {
                        MessageUtils.showToast("你已经点过赞了哦");
                        return;
                    }
                    JSONObject params = new JSONObject();
                    params.put("topicId", topicId);
                    params.put("value", 1);
                    updateVote(params, TYPE_ZAN);

                }
            });

            topicHolder.caiContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (haveAgainsted) {
                        MessageUtils.showToast("你已经踩过了唉");
                        return;
                    }
                    JSONObject params = new JSONObject();
                    params.put("topicId", topicId);
                    params.put("value", -1);
                    updateVote(params, TYPE_CAI);
                }
            });


            view = viewTopic;

        } else if (position == 1) {

            //不作优化
            viewReplyCount = mInflater.inflate(R.layout.item_square_bbs_reply_count, parent, false);
            TextView replyCount = (TextView) viewReplyCount.findViewById(R.id.replyCount);
            replyCount.setText("已有" + mSquareBbsTopicItem.get("commentCount") + "条讨论");
            HashMap tag = new HashMap();
            tag.put(TAG_TYPE, VIEW_TYPE_REPLY_COUNT);
            viewReplyCount.setTag(tag);

            view = viewReplyCount;

        } else if (position > 1) {

            if (converView != null) {
                HashMap tag = (HashMap) converView.getTag();
                int type = (int) tag.get(TAG_TYPE);
                if (type == VIEW_TYPE_REPLY) {
                    viewReply = converView;
                    replyHolder = (ReplyHolder) tag.get(TAG_HOLDER);
                }
            }

            if (viewReply == null) {

                viewReply = mInflater.inflate(R.layout.item_square_bbs_reply, parent, false);
                replyHolder = new ReplyHolder(viewReply);
                HashMap tag = new HashMap();
                tag.put(TAG_HOLDER, replyHolder);
                tag.put(TAG_TYPE, VIEW_TYPE_REPLY);
                viewReply.setTag(tag);
            }
            SquareBbsDetailDO squareBbsDetailDO = getItem(position);
            if (squareBbsDetailDO == null) {
            }
            String gender = squareBbsDetailDO.getUserGender();
            // 设置服务者性别
            if (gender != null) {
                replyHolder.iconGender.setVisibility(View.VISIBLE);
                if (gender.equals("woman") || gender.equals("F")) {
                    replyHolder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_f));
                    replyHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                } else {
                    replyHolder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_m));
                    replyHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
                }
            } else {
                replyHolder.iconGender.setVisibility(View.GONE);
            }

            if (onClickListener != null) {
                HashMap params = new HashMap();
                params.put("id", squareBbsDetailDO.getId());
                params.put("type", VIEW_TYPE_REPLY);
                params.put("isOwn", Helper.sharedHelper().getUserId().equals(squareBbsDetailDO.getUserId() + ""));
                replyHolder.pinHandlerView.setTag(params);
                replyHolder.pinHandlerView.setOnClickListener(onClickListener);
            }

            // 加载发布者头像
            ViewGroup.LayoutParams avatarParams = replyHolder.userAvatar.getLayoutParams();
            if (TextUtils.isEmpty(squareBbsDetailDO.getUserAvatar())) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(squareBbsDetailDO.getUserId()), gender);
                replyHolder.userAvatar.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(squareBbsDetailDO.getUserAvatar(), avatarParams.width));
                replyHolder.userAvatar.setImageURI(uri);
            }
            replyHolder.textNick.setText(squareBbsDetailDO.getUserNick());

            //是否为回复
            if (squareBbsDetailDO.getReplyUserId() > 0) {
                replyHolder.replyContainer.setVisibility(View.VISIBLE);
                replyHolder.replyNick.setText(squareBbsDetailDO.getReplyUserNick());
                String replyGender = squareBbsDetailDO.getReplyUserGender();
                if (gender != null) {
                    replyHolder.iconGender.setVisibility(View.VISIBLE);
                    if (replyGender.equals("woman") || replyGender.equals("F")) {
                        replyHolder.replyIconGender.setText(mContext.getResources().getString(R.string.icon_gender_f));
                        replyHolder.replyIconGender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                    } else {
                        replyHolder.replyIconGender.setText(mContext.getResources().getString(R.string.icon_gender_m));
                        replyHolder.replyIconGender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
                    }
                } else {
                    replyHolder.replyIconGender.setVisibility(View.GONE);
                }
            } else {
                replyHolder.replyContainer.setVisibility(View.GONE);
            }

            int floor = position - 1;
            replyHolder.floor.setText(floor + "楼");
            String remainTime = DateUtils.getOffsetDays(System.currentTimeMillis(), squareBbsDetailDO.getCreateTime());
            replyHolder.beforeTime.setText(remainTime);
            replyHolder.reply.setText(mChatHelper.getExpressionSpanText(squareBbsDetailDO.getContent(), 20));
            ArrayList<String> picArr = squareBbsDetailDO.getPics();
            Log.d("mzLog", "picArr size: " + picArr.size() + "||" + position);
            if (picArr.size() > 0 && !picArr.get(0).isEmpty()) {
                replyHolder.picView.setVisibility(View.VISIBLE);
                replyHolder.picView.setImageURI(Uri.parse(picArr.get(0)));
                replyHolder.picView.setTag(picArr.get(0));
                replyHolder.picView.setOnClickListener(this);
            } else {
                replyHolder.picView.setVisibility(View.GONE);
            }

            view = viewReply;
        }

        return view;
    }

    private void updateVote(JSONObject params, final int type) {
        HttpClient.get("1.0/gezi/bbs/vote", params, null, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object result) {
                hasUpdateVote = true;
                if (type == TYPE_ZAN) {
                    //zanCountNumber = (int) mSquareBbsTopicItem.get("supportCount");
                    //mSquareBbsTopicItem.put("supportCount", zanCountNumber + 1);
                    //mSquareBbsTopicItem.put("voteValue", 1);
                    haveSupported = true;
                    haveAgainsted = false;
                    zanCountNumber++;
                    if (caiCountNumber > 0) {
                        caiCountNumber--;
                    }
                    notifyDataSetChanged();
                } else if (type == TYPE_CAI) {
                    //caiCountNumber = (int) mSquareBbsTopicItem.get("againstCount");
                    //mSquareBbsTopicItem.put("againstCount", caiCountNumber + 1);
                    //mSquareBbsTopicItem.put("voteValue", -1);
                    haveAgainsted = true;
                    haveSupported = false;
                    caiCountNumber++;
                    if (zanCountNumber > 0) {
                        zanCountNumber--;
                    }
                    notifyDataSetChanged();
                }
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "投票失败，请重试");
            }
        });
    }

    @Override
    public void onClick(View v) {
        String image = (String) v.getTag();
        if (image == null) {
            return;
        }
        ArrayList<String> myImages = new ArrayList<String>();
        myImages.add(image);
        int index = myImages.indexOf(image);
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("photos", myImages);
        bundle.putInt("index", index);
        Router.sharedRouter().open("imageBrowser", bundle);
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public static Uri getDefaultAvatarUri(Context context) {

        int drawableIndex = context.getResources().getIdentifier("avatar_anony", "drawable",
                SHZApplication.getInstance().getPackageName());
        return new Uri.Builder()
                .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(drawableIndex)).build();
    }
}
