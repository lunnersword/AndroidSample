package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.BasePageAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.usepropeller.routable.Router;
import com.viewpagerindicator.CirclePageIndicator;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/2/16.
 */
public class SplashScreenActivity extends BaseActivity {
    @Bind(R.id.tutorialLayout)
    ViewGroup tutorialLayout;
    @Bind(R.id.tutorialViewpager)
    ViewPager tutorialViewpager;
    @Bind(R.id.indicator)
    CirclePageIndicator indicator;

    @Bind(R.id.logoLayout)
    ViewGroup logoLayout;
    @Bind(R.id.ad_image)
    ImageView adImage;
    @Bind(R.id.skipStartPage)
    Button skipStartPage;
    @Bind(R.id.start)
    Button start;

    TutorialPageAdapter tutorialPageAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        ButterKnife.bind(this);
        initComponents();
        loadAdView();
    }

    private void initComponents() {
        tutorialPageAdapter = new TutorialPageAdapter();
        tutorialViewpager.setAdapter(tutorialPageAdapter);
        indicator.setViewPager(tutorialViewpager);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMainScreen();
            }
        });

        skipStartPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMainScreen();
            }
        });

        indicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageScrolled(int i, float v, int i2) {
            }

            @Override
            public void onPageSelected(int i) {
                if (i == tutorialPageAdapter.getCount() - 1) {
                    start.setVisibility(View.VISIBLE);
                    skipStartPage.setVisibility(View.GONE);
                    Helper.sharedHelper().setBooleanUserInfo(Constant.SP_FIRST_START, false);
                } else {
                    skipStartPage.setVisibility(View.VISIBLE);
                    start.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
    }

    private void loadAdView() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("cityCode", Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE));
            HttpClient.get("1.0/home/openADList", jsonObject, null,
                    new HttpClient.HttpCallback<JSONObject>() {
                        @Override
                        public void onSuccess(JSONObject json) {
                            JSONArray array = json.getJSONArray("adList");
                            if (array.size() == 0) {
                                doNextAction();
                                Helper.sharedHelper().setStringUserInfo(Constant.AD_PICTURE_URL, "");
                                Helper.sharedHelper().setStringUserInfo(Constant.AD_PICTURE_LINK, "");
                                return;
                            }
                            JSONObject jsonObj = array.getJSONObject(0);
                            String picUrl = jsonObj.getString("pic");
                            String link = jsonObj.getString("url");
                            loadAdPicture(picUrl, link);
                        }

                        @Override
                        public void onFail(HttpError error) {
                            String picUrl = Helper.sharedHelper().getStringUserInfo(Constant.AD_PICTURE_URL);
                            String link = Helper.sharedHelper().getStringUserInfo(Constant.AD_PICTURE_LINK);
                            if (TextUtils.isEmpty(picUrl)) {
                                doNextAction();
                            } else {
                                loadAdPicture(picUrl, link);
                            }
                        }
                    });
        } catch (Exception e) {
            doNextAction();
            e.printStackTrace();
        }
    }

    private void loadAdPicture(final String picUrl, final String link) {
        if (isFinishing()) {
            return;
        }
        Glide.with(getApplicationContext()).load(picUrl).fitCenter().diskCacheStrategy(DiskCacheStrategy.SOURCE).into(adImage);
        if (TextUtils.isEmpty(link)) {
            adImage.postDelayed(new Runnable() {
                @Override
                public void run() {
                    doNextAction();
                }
            }, 2000);
        } else {
            adImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle params = new Bundle();
                    params.putString("url", link);
                    Router.sharedRouter().open("web", params);
                }
            });
            adImage.postDelayed(new Runnable() {
                @Override
                public void run() {
                    doNextAction();
                }
            }, 5000);
        }

    }

    private void doNextAction() {
        if (Helper.sharedHelper().getBooleanUserInfo(Constant.SP_FIRST_START, true)) {
            tutorialLayout.setVisibility(View.VISIBLE);
            skipStartPage.setVisibility(View.VISIBLE);
            logoLayout.setVisibility(View.GONE);
        } else {
            showMainScreen();
        }
    }

    private void showMainScreen() {
        try {
            Helper.sharedHelper().setBooleanUserInfo(Constant.SP_FIRST_START, false);
            String selectCityName = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_NAME);
            String locationCityName = SHZApplication.getInstance().getLocationManager().getLocation().getCityName();

            if (TextUtils.isEmpty(selectCityName) && TextUtils.isEmpty(locationCityName)) {
                Bundle bundle = new Bundle();
                bundle.putString("from", "splash");
                Router.sharedRouter().open("pick/city", bundle);
                finish();
            } else {
                Router.sharedRouter().open("main");
                finish();
            }
        } catch (Exception e) {
            Log.e("SplashScreenJumpError", e.getMessage());
            Router.sharedRouter().open("main");
            finish();
        }
    }

    public class TutorialPageAdapter extends BasePageAdapter {
        private int[] images = new int[]{
                R.mipmap.start_page_1,
                R.mipmap.start_page_2,
                R.mipmap.start_page_3,
                R.mipmap.start_page_4
        };

        public TutorialPageAdapter() {
        }

        @Override
        public int getCount() {
            return images.length;
        }

        @Override
        public View newView(int position) {
            ImageView view = new ImageView(SplashScreenActivity.this);
            view.setScaleType(ImageView.ScaleType.CENTER_CROP);
            view.setImageResource(images[position]);
            return view;
        }
    }
}
