
package com.meidalife.shz.event.type;

import com.meidalife.shz.rest.model.SquareAddressOutDO;

/**
 * Created by zuozheng on 14-10-31.
 */
public class SquareAddressEventModel {

    public SquareAddressOutDO address;
}
