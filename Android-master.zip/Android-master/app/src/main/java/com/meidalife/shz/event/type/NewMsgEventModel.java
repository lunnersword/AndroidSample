
package com.meidalife.shz.event.type;

/**
 * Created by zuozheng on 14-10-31.
 */
public class NewMsgEventModel {

    public MsgTypeEnum type;

    public int unReadMsgCount;
}
