package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.Logger;
import com.meidalife.shz.util.NetworkUtils;
import com.meidalife.shz.view.ProgressView;
import com.yixia.camera.FFMpegUtils;
import com.yixia.camera.MediaRecorder;
import com.yixia.camera.MediaRecorder.OnErrorListener;
import com.yixia.camera.MediaRecorder.OnPreparedListener;
import com.yixia.camera.MediaRecorderFilter;
import com.yixia.camera.VCamera;
import com.yixia.camera.model.MediaObject;
import com.yixia.camera.model.MediaObject.MediaPart;
import com.yixia.camera.util.DeviceUtils;
import com.yixia.camera.util.FileUtils;
import com.yixia.camera.view.CameraNdkView;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 视频录制
 *
 * @author tangjun@yixia.com
 */
public class VCMediaRecorderActivity extends BaseActivity implements OnErrorListener, OnClickListener, OnPreparedListener {

    /**
     * 录制最长时间
     */
    public final static int RECORD_TIME_MAX = 10 * 1000;
    /**
     * 录制最小时间
     */
    public final static int RECORD_TIME_MIN = 4 * 1000;

    @Bind(R.id.record_close)
    View closeRecord;
    @Bind(R.id.record_revert_camera)
    View revertCamera;
    @Bind(R.id.record_preview)
    CameraNdkView mSurfaceView;
    @Bind(R.id.record_progress)
    ProgressView mProgressView;


    @Bind(R.id.record_click_tips)
    View tips;

    @Bind(R.id.videoRecordView)
    View videoRecordView;
    //删除
    @Bind(R.id.record_delete)
    TextView mDeleteRecord;
    //ok
    @Bind(R.id.record_ok)
    View mOKRecord;

    private MediaRecorderFilter mMediaRecorder;
    private MediaObject mMediaObject;
    private int mWindowWidth;
    /**
     * 是否是点击状态
     */
    private volatile boolean mPressedStatus, mReleased, mStartEncoding, mStartCapture;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);// 防止锁屏
        mWindowWidth = DeviceUtils.getScreenWidth(this);
        setContentView(R.layout.activity_media_recorder);

        // ~~~ 绑定控件
        ButterKnife.bind(this);

        // ~~~ 绑定事件
        closeRecord.setOnClickListener(this);
        revertCamera.setOnClickListener(this);
        videoRecordView.setOnTouchListener(mOnSurfaceViewTouchListener);
        mOKRecord.setOnClickListener(this);
        mDeleteRecord.setOnClickListener(this);

        // ~~~ 初始数据
        mSurfaceView.getLayoutParams().height = mWindowWidth;//(int) (mWindowWidth * 3F / 2);//视频为640x480，后期裁剪成1：1的视频
//        findViewById(R.id.record_layout).getLayoutParams().height = mWindowWidth;//设置1：1预览范围
        mProgressView.invalidate();

    }

    @Override
    protected void onStart() {
        super.onStart();

        if (mMediaRecorder == null)
            initMediaRecorder();
        else {
            try {
                mMediaRecorder.setSurfaceHolder(mSurfaceView.getHolder());
                mMediaRecorder.prepare();
            } catch (Exception e) {
                Logger.e("mMediaRecorder prepare error: " + e.toString());
            }
        }
        checkStatus();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mMediaRecorder != null && !mReleased) {
            mMediaRecorder.release();
        }
    }

    @Override
    public void onBackPressed() {
        if (cancelDelete()) {
            return;
        }

        if (mMediaObject != null && mMediaObject.getDuration() > 1) {
            //未转码
            new AlertDialog.Builder(this).setTitle(R.string.hint).setMessage(R.string.record_camera_exit_dialog_message).setNegativeButton(R.string.dialog_yes, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    mMediaObject.delete();
                    finish();
                }

            }).setPositiveButton(R.string.dialog_no, null).setCancelable(false).show();
            return;
        }
        super.onBackPressed();
    }

    private void initMediaRecorder() {
        mMediaRecorder = new MediaRecorderFilter();
        mMediaRecorder.setOnErrorListener(this);
        mMediaRecorder.setOnPreparedListener(this);
        //WIFI下800k码率，其他情况（4G/3G/2G）600K码率
        mMediaRecorder.setVideoBitRate(NetworkUtils.isWifiAvailable(this) ? MediaRecorder.VIDEO_BITRATE_MEDIUM : MediaRecorder.VIDEO_BITRATE_NORMAL);
        //		mMediaRecorder.setSurfaceHolder(mSurfaceView.getHolder());
        mMediaRecorder.setSurfaceView(mSurfaceView);
        String mediaObjKey = String.valueOf(System.currentTimeMillis());
        String mediaObjPath = VCamera.getVideoCachePath() + mediaObjKey;
        mMediaObject = mMediaRecorder.setOutputDirectory(mediaObjKey, mediaObjPath);
        try {
            if (mMediaObject != null) {
                mMediaRecorder.prepare();
                mMediaRecorder.setCameraFilter(MediaRecorderFilter.CAMERA_FILTER_NO);
                mProgressView.setData(mMediaObject);
            } else {
                Toast.makeText(this, R.string.record_camera_init_faild, Toast.LENGTH_SHORT).show();
                finish();
            }
        } catch (Exception e) {
            Log.e("RecorderVideo", e.getMessage());
            finish();
        }
    }

    private View.OnTouchListener mOnSurfaceViewTouchListener = new View.OnTouchListener() {

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (mMediaRecorder == null || mMediaObject == null) {
                return false;
            }

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:

                    //检测是否手动对焦
                    //				if (checkCameraFocus(event))
                    //					return true;

                    //取消回删
                    if (cancelDelete())
                        return true;

                    //取消延时拍摄
                    //				if (mRecordDelay.isChecked()) {
                    //					stopRecord();
                    //					return true;
                    //				}

                    //判断是否已经超时
                    if (mMediaObject.getDuration() >= RECORD_TIME_MAX) {
                        return true;
                    }

                    //显示当前时间
//                    mTitleText.setText(String.format("%.1f", mMediaObject.getDuration() / 1000F));

                    startRecord();

                    break;
                case MotionEvent.ACTION_MOVE:
                    break;
                case MotionEvent.ACTION_UP:
                    // 暂停
                    if (mPressedStatus) {
                        stopRecord();

                        //检测是否已经完成
                        if (mMediaObject.getDuration() >= RECORD_TIME_MAX) {
//                            mTitleNext.performClick();
                        }
                    }

//                    mTitleText.setText(R.string.record_camera_title);
                    break;
            }
            return true;
        }

    };

    /**
     * 开始拍摄
     */
    private void startRecord() {

        tips.setVisibility(View.GONE);
        mPressedStatus = true;

        if (mMediaRecorder != null) {
            mMediaRecorder.startRecord();
        }

        if (mHandler != null) {
            mHandler.sendEmptyMessage(HANDLE_INVALIDATE_PROGRESS);
            mHandler.sendEmptyMessageDelayed(HANDLE_STOP_RECORD, RECORD_TIME_MAX - mMediaObject.getDuration());
        }

        mHandler.removeMessages(HANDLE_SHOW_TIPS);
        mHandler.sendEmptyMessage(HANDLE_SHOW_TIPS);
        mDeleteRecord.setVisibility(View.VISIBLE);
        mOKRecord.setVisibility(View.VISIBLE);

    }

    private void stopRecord() {
        mPressedStatus = false;
        //提示完成
//        mPressText.setImageResource(R.drawable.record_tips_press);

        if (mMediaRecorder != null)
            mMediaRecorder.stopRecord();

        //取消倒计时
        mHandler.removeMessages(HANDLE_STOP_RECORD);
    }

    /**
     * 是否可回删
     */
    private boolean cancelDelete() {
        if (mMediaObject != null) {
            MediaPart part = mMediaObject.getCurrentPart();
            if (part != null && part.remove) {
                part.remove = false;
//                mRecordDelete.setChecked(false);

                if (mProgressView != null)
                    mProgressView.invalidate();

                return true;
            }
        }
        return false;
    }

    /**
     * 刷新进度条
     */
    private static final int HANDLE_INVALIDATE_PROGRESS = 0;
    /**
     * 延迟拍摄停止
     */
    private static final int HANDLE_STOP_RECORD = 1;
    /**
     * 显示下一步
     */
    private static final int HANDLE_SHOW_TIPS = 2;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case HANDLE_INVALIDATE_PROGRESS:
                    if (mMediaObject != null && !isFinishing()) {
                        if (mProgressView != null)
                            mProgressView.invalidate();
                        if (mPressedStatus)
//                            mTitleText.setText(String.format("%.1f", mMediaObject.getDuration() / 1000F));
                            if (mPressedStatus)
                                sendEmptyMessageDelayed(0, 30);
                    }
                    break;
                case HANDLE_SHOW_TIPS:
                    if (mMediaRecorder != null && !isFinishing()) {
                        int duration = checkStatus();

                        if (mPressedStatus) {
                            if (duration < RECORD_TIME_MAX) {
                                sendEmptyMessageDelayed(HANDLE_SHOW_TIPS, 200);
                            } else {
                                sendEmptyMessageDelayed(HANDLE_SHOW_TIPS, 500);
                            }
                        }
                    }
                    break;
                case HANDLE_STOP_RECORD:
                    stopRecord();
                    startEncoding();
                    break;
            }
        }
    };


    private void startEncoding() {
        //检测磁盘空间
        if (FileUtils.showFileAvailable() < 200) {
            Toast.makeText(this, R.string.record_camera_check_available_faild, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isFinishing() && mMediaRecorder != null && mMediaObject != null && !mStartEncoding) {
            mStartEncoding = true;

            new AsyncTask<Void, Void, Boolean>() {

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    showProgress("", getString(R.string.record_camera_progress_message));
                }

                @Override
                protected Boolean doInBackground(Void... params) {
                    boolean result = FFMpegUtils.videoTranscoding(mMediaObject, mMediaObject.getOutputTempVideoPath(), mWindowWidth, false);
                    if (result && mMediaRecorder != null) {
                        mMediaRecorder.release();
                        mReleased = true;
                    }
                    return result;
                }

                @Override
                protected void onCancelled() {
                    super.onCancelled();
                    mStartEncoding = false;
                }

                @Override
                protected void onPostExecute(Boolean result) {
                    super.onPostExecute(result);
                    hideProgress();
                    if (result) {
                        try {
                            //todo Async todo capture the picture by FFMpegUtils.captureThumbnails method.
                            captureThumbnails(mMediaObject.getOutputTempVideoPath());
                        } catch (Exception e) {
                            Log.e("VCMediaRecorderActivity", "截屏失败" + e.getMessage());
                        }
                    } else {
                        Toast.makeText(VCMediaRecorderActivity.this, R.string.record_video_transcoding_faild, Toast.LENGTH_SHORT).show();
                    }
                    mStartEncoding = false;
                }
            }.execute();
        }
    }

    private void captureThumbnails(String filePath) {
        //todo

        if (filePath != null && !mStartCapture) {

            mStartEncoding = true;

            new AsyncTask<String, Void, ArrayList<String>>() {
                @Override
                protected ArrayList<String> doInBackground(String... params) {
                    //视频存储路径
                    String videoFilePath = params[0];
                    ArrayList<String> picList = new ArrayList<String>();

                    //todo 设置图片输出路径
                    try {
                        int time = 0;
                        int interval = (int) Math.floor((double) mMediaObject.getDuration() / 1000 / 4);
                        for (int i = 0; i < 4; i++) {
                            String capturedImagePath = ImgUtil.getSavedImagePath(VCMediaRecorderActivity.this) + File.separator
                                    + "recorder_" + System.currentTimeMillis() + ".jpg";

                            boolean result = FFMpegUtils.captureThumbnails(videoFilePath, capturedImagePath, "120x120", String.valueOf(time));
                            if (result) {
                                time += interval;
                                picList.add(capturedImagePath);
                            }
                        }
                    } catch (Exception e) {
                        Log.e("VCMediaRecorderActivity", "截屏失败");
                    }
                    return picList;
                }

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    showProgress("", getString(R.string.record_video_progress_capture));
                }

                @Override
                protected void onCancelled() {
                    super.onCancelled();
                    hideProgress();
                    mStartCapture = false;
                }

                @Override
                protected void onPostExecute(ArrayList<String> urlList) {
                    super.onPostExecute(urlList);
                    hideProgress();
                    if (urlList != null && urlList.size() > 0) {
                        try {
                            if (saveMediaObject(mMediaObject)) {
                                Intent intent = new Intent(VCMediaRecorderActivity.this, VCMediaPreviewActivity.class);
                                intent.putExtra("obj", mMediaObject.getObjectFilePath());
                                intent.putStringArrayListExtra("picList", urlList);
                                startActivity(intent);
                                MessageUtils.showToast("截取封面成功");

                                finish();
                            } else {
                                Toast.makeText(VCMediaRecorderActivity.this, "截取封面失败", Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            Log.e("VCMediaRecorderActivity", "截取封面失败");
                        }
                    } else {
                        Toast.makeText(VCMediaRecorderActivity.this, "截取封面失败", Toast.LENGTH_SHORT).show();
                    }
                    mStartCapture = false;
                }
            }.execute(filePath);
        }

    }

    /**
     * 检测是否超过三秒
     */

    private int checkStatus() {
        int duration = 0;
        if (!isFinishing() && mMediaObject != null) {
            duration = mMediaObject.getDuration();
            if (duration < RECORD_TIME_MIN) {
                //视频必须大于3秒
                if (mDeleteRecord.getVisibility() != View.INVISIBLE)
                    mDeleteRecord.setVisibility(View.INVISIBLE);

                if (mOKRecord.getVisibility() != View.INVISIBLE)
                    mOKRecord.setVisibility(View.INVISIBLE);
            } else {
                //下一步
                if (mDeleteRecord.getVisibility() != View.VISIBLE)
                    mDeleteRecord.setVisibility(View.VISIBLE);

                if (mOKRecord.getVisibility() != View.VISIBLE)
                    mOKRecord.setVisibility(View.VISIBLE);
            }
        }
        return duration;
    }

    @Override
    public void onVideoError(int what, int extra) {
        Logger.e("[MediaRecorderActvity]onVideoError: what" + what + " extra:" + extra);
    }

    @Override
    public void onAudioError(int what, String message) {
        Logger.e("[MediaRecorderActvity]onAudioError: what" + what + " message:" + message);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(VCMediaRecorderActivity.this, R.string.record_camera_open_audio_faild, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.record_close:
                onBackPressed();
                break;
            case R.id.record_revert_camera:
                mMediaRecorder.switchCamera();
                break;
            case R.id.record_ok:
                startEncoding();
                break;
            case R.id.record_delete:
                if (mMediaObject != null) {
                    LinkedList<MediaPart> mMediaList = mMediaObject.getMedaParts();
                    if (mMediaList != null && mMediaList.size() > 0) {
                        for (int i = mMediaList.size() - 1; i >= 0; i--) {
                            MediaPart part = mMediaList.get(i);
                            if (part != null) {
                                if (part.remove) {
                                    //确认删除分块
                                    part.remove = false;
                                    mMediaObject.removePart(part, true);
                                } else {
                                    part.remove = true;
                                }
                            }
                        }
                    }

                    if (mProgressView != null)
                        mProgressView.invalidate();

                    //检测按钮状态
                    checkStatus();
                }
                break;
        }
    }


    @Override
    public void onPrepared() {
        if (mMediaRecorder != null) {
            //自动对焦
            mMediaRecorder.autoFocus(new AutoFocusCallback() {

                @Override
                public void onAutoFocus(boolean success, Camera camera) {
                    if (success) {

                    }
                }
            });
        }
    }
}
