package com.meidalife.shz.im.task;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.meidalife.shz.Helper;
import com.meidalife.shz.db.ImServer;
import com.meidalife.shz.im.ImConfig;
import com.meidalife.shz.im.ImMessageType;
import com.meidalife.shz.im.SocketManger;
import com.meidalife.shz.im.protos.NotificationProtos.C2SMessage;
import com.meidalife.shz.im.protos.NotificationProtos.CltMethodType;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * Created by fufeng on 15/12/7.
 */
public class ImHeartbeatTask extends ImSendTask {
    private static final String LOG_TAG = "ImHeartbeatTask";
    private boolean isRunning = true;

    public ImHeartbeatTask(ImConfig config, Handler handler) {
        super(config, handler);
    }

    public void stop() {
        isRunning = false;
    }

    public boolean isRunning() {
        return isRunning;
    }

    @Override
    public void run() {
        while (isRunning) {
            Log.d(LOG_TAG, "Heartbeat task running.");
            C2SMessage message = Helper.sharedHelper().hasToken() ?
                    buildC2SMessage(CltMethodType.CLIENT_HEART_BEAT) :
                    buildC2SMessage(CltMethodType.CLIENT_NOLOGIN_HB);
            Message heartbeatMessage = new Message();

            try {
                if (SocketManger.getInstance().isClosed() || !SocketManger.getInstance().isConnected()) {
                    if (!connect()) {
                        heartbeatMessage.what = ImMessageType.TYPE_RECONNECT.value;
                        mHandler.sendMessage(heartbeatMessage);
                        break;
                    }
                }

                for (int retryTimes = 0; retryTimes < config.getMaxRetryTimes(); retryTimes++) {
                    if (sendMessage(message)) {
                        heartbeatMessage.what = ImMessageType.TYPE_HEARTBEAT_SUCCESS.value;
                        mHandler.sendMessage(heartbeatMessage);
                        Log.d(LOG_TAG, "Heartbeat task success.");
                        try {
                            if (!Helper.sharedHelper().hasToken()) {
                                Thread.sleep(15 * 1000);
                                SocketManger.getInstance().close();
                                Log.d(LOG_TAG, "Heartbeat socket close.");
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                    try {
                        Thread.sleep(config.getRetryInterval() * 1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                try {
                    if (Helper.sharedHelper().hasToken()) {
                        Thread.sleep(config.getHeartbeatInterval() * 1000);
                    } else {
                        Thread.sleep(config.getHeartbeatIntervalNotLogin() * 1000);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } catch (Exception e) {
                Log.d(LOG_TAG, "Heartbeat task failed.");
                e.printStackTrace();

                heartbeatMessage.what = ImMessageType.TYPE_HEARTBEAT_FAILED.value;
                mHandler.sendMessage(heartbeatMessage);
            }
        }
    }

    private boolean connect() {
        Log.d(LOG_TAG, "Heartbeat task connecting.");
        for (ImServer server : config.getServerList()) {
            InetSocketAddress address;
            address = new InetSocketAddress(server.getAddress(), server.getPort());
            Log.d(LOG_TAG, "Heartbeat task connect " + address.toString());
            try {
                SocketManger.getInstance().connect(address, config.getSocketTimeout());
                break;
            } catch (IOException e) {
                e.printStackTrace();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e1) {
                    e1.printStackTrace();
                }
            }
        }

        return SocketManger.getInstance().isConnected();
    }
}
