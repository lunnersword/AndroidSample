package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 16/1/14.
 */
public class AdViewPagerAdapter extends BasePageAdapter {
    private Context mContext;
    private List<AdItem> adItemList = new ArrayList<>();
    private int imgHeight;

    public AdViewPagerAdapter(Context context, List<AdItem> data) {
        mContext = context;
        setData(data);
        imgHeight = mContext.getResources().getDimensionPixelSize(R.dimen.ad_banner_heignt);
    }

    public void setData(List<AdItem> data) {
        adItemList = data;
    }

    public void setImgHeight(int imgHeight) {
        this.imgHeight = imgHeight;
    }

    @Override
    public View newView(int position) {
        SimpleDraweeView imageView = new SimpleDraweeView(mContext);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ViewPager.LayoutParams params = new ViewPager.LayoutParams();
        params.height = imgHeight;
        imageView.setLayoutParams(params);

        final AdItem item = adItemList.get(position);
        if (!TextUtils.isEmpty(item.imageUrl)) {
            imageView.setImageURI(Uri.parse(item.imageUrl));
        }
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", item.linkUrl);
                Router.sharedRouter().open("web", bundle);
            }
        });
        return imageView;
    }

    @Override
    public int getCount() {
        return adItemList.size();
    }

    public static class AdItem {
        public String imageUrl;
        public String linkUrl;
    }
}
