package com.meidalife.shz.im;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.BuildConfig;
import com.meidalife.shz.db.DaoSession;
import com.meidalife.shz.db.DatabaseManager;
import com.meidalife.shz.db.ImServer;
import com.meidalife.shz.im.protos.NotificationProtos;
import com.meidalife.shz.im.task.ImHeartbeatTask;
import com.meidalife.shz.im.task.ImReceiveTask;
import com.meidalife.shz.im.task.ImSendTask;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by fufeng on 15/12/6.
 */
public class ImPushManager {
    private static final String LOG_TAG = "ImPushManager";

    private int connectRetryTime;
    private boolean running = false;
    private DatabaseManager databaseManager;
    private DaoSession daoSession;
    private ImConfig imConfig;

    private Handler mainHanler = new MessageHandler();
    private ExecutorService executorService;
    private NotifyMessageListener notifyMessageListener;
    private ImReceiveTask imReceiveTask;
    private ImHeartbeatTask imHeartbeatTask;

    private static class SingletonHolder {
        private static ImPushManager INSTANCE = new ImPushManager();
    }

    private ImPushManager() {
        databaseManager = DatabaseManager.getInstance();
        daoSession = databaseManager.getDaoSession();
        executorService = Executors.newFixedThreadPool(8);
    }

    public static ImPushManager getInstance() {
        return SingletonHolder.INSTANCE;
    }

    public void setNotifyMessageListener(NotifyMessageListener notifyMessageListener) {
        this.notifyMessageListener = notifyMessageListener;
    }

    public void start() {
        connectRetryTime = 0;
        if (!isRunning()) {
            running = true;
            connect(false);
        }
    }

    public void stop() {
        try {
            running = false;
            executorService.shutdown();
            connectRetryTime = 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isRunning() {
        return running && SocketManger.getInstance().getSocket().isConnected();
    }

    private void connect(boolean refreshConfig) {
        Log.d(LOG_TAG, "connect connectRetryTime=" + connectRetryTime);

        try {
            imConfig = new ImConfig();
            if (!refreshConfig && !imConfig.isExpired()) {
                List<ImServer> serverList = daoSession.getImServerDao().loadAll();
                if (null != serverList && !serverList.isEmpty()) {
                    imConfig.setServerList(serverList);

                    if (imConfig.isPushEnabled()) {
                        startHeartbeatTask();
                    }
                    return;
                }
            }

            if (connectRetryTime > 3) {
                return;
            }
            connectRetryTime++;

            Log.d(LOG_TAG, "getImConfig connectRetryTime=" + connectRetryTime);
            mainHanler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    HttpClient.get("1.0/im/getImConfig", null, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                        @Override
                        public void onSuccess(JSONObject obj) {
                            if (null == obj) {
                                Log.e(LOG_TAG, "IM config can't be empty!");
                                return;
                            }
                            imConfig = ImConfig.parse(obj);

                            JSONArray serverInfoArray = obj.getJSONArray(ImConfig.TAG_SERVER_INFO);
                            List<ImServer> serverList = new ArrayList<>();
                            if (serverInfoArray != null) {
                                for (int i = 0; i < serverInfoArray.size(); i++) {
                                    ImServer serverInfo = new ImServer();
                                    serverInfo.setAddress(serverInfoArray.getJSONObject(i).getString(ImConfig.TAG_SERVER_ADDRESS));
                                    serverInfo.setPort(serverInfoArray.getJSONObject(i).getIntValue(ImConfig.TAG_SERVER_PORT));
                                    serverList.add(serverInfo);
                                    saveServerList(serverList);
                                }

                                imConfig.setServerList(serverList);
                                if (imConfig.isPushEnabled()) {
                                    startHeartbeatTask();
                                }
                            }
                        }

                        @Override
                        public void onFail(HttpError error) {
                            Log.e(LOG_TAG, "Failed to get IM config:" + error);
                        }
                    });
                }
            }, connectRetryTime * 2000 + 1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveServerList(List<ImServer> list) {
        if (list.isEmpty()) {
            return;
        }
        try {
            daoSession.getImServerDao().deleteAll();
            for (ImServer serverInfo : list) {
                daoSession.getImServerDao().insert(serverInfo);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleNewMessage(NotificationProtos.C2SMessage c2SMessage) {
        if (null == c2SMessage) {
            Log.e(LOG_TAG, "Can't handle empty c2SMessage.");
            return;
        }
        try {
            Log.e(LOG_TAG, "Handle c2SMessage:" + c2SMessage);
            if (c2SMessage.hasNotifyList()) {
                for (NotificationProtos.NotifyMsg notifyMsg : c2SMessage.getNotifyList().getNotifyMsgList()) {
                    if (notifyMessageListener != null) {
                        Log.e(LOG_TAG, "notifyMessageListener:" + notifyMsg);
                        notifyMessageListener.onNewMessage(notifyMsg);
                    }
                }
            }
            switch (c2SMessage.getMethodType()) {
                case SERVER_ACK_PONG:
                case NOTIFY_MSG_RSP:
                case BROAD_CAST_RSP: {
                    break;
                }
                case HAVA_NOTICE: {
                    ImPushManager.getInstance().startSendTask();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startReceiveTask() {
        try {
            if (imReceiveTask == null || !imReceiveTask.isRunning()) {
                imReceiveTask = new ImReceiveTask(imConfig, mainHanler);
                executorService.execute(imReceiveTask);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startSendTask() {
        try {
            executorService.execute(new ImSendTask(imConfig, mainHanler));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startHeartbeatTask() {
        try {
            if (imHeartbeatTask != null) {
                imHeartbeatTask.stop();
            }

            imHeartbeatTask = new ImHeartbeatTask(imConfig, mainHanler);
            executorService.execute(imHeartbeatTask);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface NotifyMessageListener {
        void onNewMessage(NotificationProtos.NotifyMsg message);
    }

    private static class MessageHandler extends Handler {
        private MessageHandler() {
            super(Looper.getMainLooper());
        }

        @Override
        public void handleMessage(Message msg) {
            Log.d(LOG_TAG, "handleMessage:" + msg.what);
            switch (ImMessageType.valueOf(msg.what)) {
                case TYPE_RECONNECT: {
                    ImPushManager.getInstance().connect(true);
                    break;
                }
                case TYPE_SOCKET_CLOSE: {
                    break;
                }
                case TYPE_HEARTBEAT_SUCCESS: {
                    ImPushManager.getInstance().startReceiveTask();
                    break;
                }
                case TYPE_HEARTBEAT_FAILED: {
                    break;
                }
                case TYPE_RECEIVE_MESSAGE_SUCCESS: {
                    ImPushManager.getInstance().handleNewMessage((NotificationProtos.C2SMessage) msg.obj);
                    break;
                }
            }
        }
    }
}
