package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SquarePublishDO;

/**
 * Created by zhq on 15/12/30.
 */
public class SquarePopWindowAdapter extends BaseAdapter {
    private Context mContext;
    //    private ArrayList mDate;
    private LayoutInflater mInflater;
    private int itemType;

    private SquarePublishDO publishDO;

    private View view;

    static class ItemHolder {
        public TextView content;
        public TextView icon;
        public View parent;
    }

    public SquarePopWindowAdapter(Context c, View view, SquarePublishDO bean) {
        mContext = c;
        publishDO = bean;
        this.view = view;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return 1;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {


        return view;
    }
}
