package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.adapter.OpusAdapter;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.OpusDO;
import com.meidalife.shz.rest.request.RequestOpus;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

public class OpusListActivity extends BaseActivity {

    int EDIT_REQUEST_CODE = 100;
    int PAGE_SIZE = 10;

    OpusAdapter adapter;
    ArrayList<OpusDO> data;
    boolean loading = false;
    boolean complete = false;
    int page = 0;
    String itemId;

    @Bind(R.id.listView)
    ListView listView;
    @Bind(R.id.rootView)
    LinearLayout rootView;

    View listFooter;
    TextView footerMessage;
    ProgressBar footerLoading;
    Button footerReload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opus_list);
        initActionBar(R.string.title_activity_opus_list, true);

        ButterKnife.bind(this);

        Bundle bundle = getIntent().getExtras();
        itemId = bundle.getString("itemId");

        listFooter = getLayoutInflater().inflate(R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);
        listView.addFooterView(listFooter);
        data = new ArrayList<OpusDO>();
        adapter = new OpusAdapter(this, data);
        listView.setAdapter(adapter);
        listFooter.setVisibility(View.GONE);
        listView.setVisibility(View.GONE);
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            private boolean moveToBottom = false;
            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                boolean moveToBottom = false;
                if (previous <= firstVisibleItem) {
                    moveToBottom = true;
                }
                previous = firstVisibleItem;
                if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
                    /* 需要加载更多数据的代码 */
                    loadOpus();
                }
            }
        });

        xhrOpusList();
    }

    private void xhrOpusList() {
        if (loading) {
            return;
        }
        loading = true;
        showStatusLoading(rootView);

        RequestOpus.listByItemId(getOpusParams(), new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                listView.setVisibility(View.VISIBLE);
                listFooter.setVisibility(View.GONE);
                hideStatusLoading();
                loading = false;

                ArrayList<OpusDO> opusDOs = (ArrayList<OpusDO>) result;

                if (opusDOs.size() < PAGE_SIZE) {
                    complete = true;
                    listView.removeFooterView(listFooter);
                }

                data.addAll(opusDOs);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(HttpError error) {
                loading = false;
                hideStatusLoading();
                listFooter.setVisibility(View.GONE);

                // refresh
                if (page == 0) {
                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        showStatusErrorNetwork(rootView);
                        setOnClickErrorNetwork(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                xhrOpusList();
                            }
                        });
                        return;
                    }

                    showStatusErrorServer(rootView);
                    setTextErrorServer(error.getMessage());
                    setOnClickErrorServer(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrOpusList();
                        }
                    });
                }
                // load next
                else {
                    page--;
                    if (error != null) {
                        if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);
                    footerReload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            footerLoading.setVisibility(View.VISIBLE);
                            footerReload.setVisibility(View.GONE);
                            loadOpus();
                        }
                    });
                }
            }
        });
    }

    private void loadOpus() {
        if (!complete && !loading) {
            page++;
            xhrOpusList();
        }
    }

    private JSONObject getOpusParams() {
        JSONObject params = new JSONObject();
        try {
            params.put("itemId", itemId);
            params.put("offset", PAGE_SIZE * page);
            params.put("pageSize", PAGE_SIZE);
        } catch (JSONException e) {

        }
        return params;
    }
}
