package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SquareDynamicDO;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 15/12/20.
 */
public class SquareDynamicAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    List<SquareDynamicDO> mData;

    static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }


//        @Bind(R.id.userAvatar)
//        SimpleDraweeView userAvatar;

        @Bind(R.id.dynamicCreateTime)
        TextView squareCreateTime;

        @Bind(R.id.textNick)
        TextView textNick;

        @Bind(R.id.dynamicTitle)
        TextView dynamicTitle;

    }

    public SquareDynamicAdapter(Context context, List<SquareDynamicDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public String getItem(int position) {
        return null;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_square_dynamic, parent, false);
            ViewHolder holder = new ViewHolder(convertView);

            convertView.setTag(holder);
        }

        SquareDynamicDO item = mData.get(position);
        ViewHolder holder = (ViewHolder) convertView.getTag();

//        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getUserPicUrl(), holder.userAvatar.getLayoutParams().width));
//        if (uri != null) {
//            holder.userAvatar.setImageURI(uri);
//        } else {
//            holder.userAvatar.setImageURI(null);
//        }

        holder.squareCreateTime.setText(item.getCreateTimeByMonth());

        if (TextUtils.isEmpty(item.getUserNick())) {
            holder.textNick.setText("");
        } else {
            holder.textNick.setText(item.getUserNick() + ": ");
        }


        if (item.getType() == 1) {
            //我能
            holder.dynamicTitle.setText(mContext.getResources().getString(R.string.label_i_can) + item.getItemTitle());
            holder.dynamicTitle.setTextColor(mContext.getResources().getColor(R.color.brand_b));
        } else if (item.getType() == 2) {
            //我要
            holder.dynamicTitle.setText(mContext.getResources().getString(R.string.label_i_want) + item.getDemandTitle());
            holder.dynamicTitle.setTextColor(mContext.getResources().getColor(R.color.square_i_want_title));
        } else {
            //闲话
            holder.dynamicTitle.setText(item.getTopicTitle());
            holder.dynamicTitle.setTextColor(mContext.getResources().getColor(R.color.grey_l));
        }

        return convertView;
    }
}
