package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.util.DataCleanUtils;
import com.meidalife.shz.util.UpdateUtil;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

public class SettingActivity extends BaseActivity {

    @Bind(R.id.signout)
    Button buttonSignout;
    @Bind(R.id.packageVersion)
    TextView packageVersion;

    @Bind(R.id.profileArrow)
    TextView profileArrow;
    @Bind(R.id.messageArrow)
    TextView messageArrow;
    @Bind(R.id.addressManageArrow)
    TextView addressManageArrow;
    @Bind(R.id.cleanCacheArrow)
    TextView cleanCacheArrow;
    @Bind(R.id.aboutMeArrow)
    TextView aboutMeArrow;
    @Bind(R.id.cacheSize)
    TextView cacheSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        initActionBar(R.string.title_activity_setting, true);

        ButterKnife.bind(this);

        if (Helper.sharedHelper().hasToken()) {
            buttonSignout.setVisibility(View.VISIBLE);
        } else {
            buttonSignout.setVisibility(View.GONE);
        }

        try {
            packageVersion.setText(getVersion());
        } catch (Exception e) {

        }
        profileArrow.setTypeface(Helper.sharedHelper().getIconFont());
        messageArrow.setTypeface(Helper.sharedHelper().getIconFont());
        addressManageArrow.setTypeface(Helper.sharedHelper().getIconFont());
        cleanCacheArrow.setTypeface(Helper.sharedHelper().getIconFont());
        aboutMeArrow.setTypeface(Helper.sharedHelper().getIconFont());

        try {
            cacheSize.setText(DataCleanUtils.getTotalCacheSize(this));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void handleOpenProfile(View view) {
        Router.sharedRouter().open("aboutme");
    }

    public void handleOpenMessage(View view) {
        Router.sharedRouter().open("messageSetting");
    }

    public void handleOpenAddressManage(View view) {
        Router.sharedRouter().open("addressManage");

    }

    public void handleOpenCleanCache(View view) {
        try {
            DataCleanUtils.clearAllCache(this);
            Fresco.getImagePipeline().clearCaches();
            cacheSize.setText("0.0MB");
            MessageUtils.showToast("已清除");
        } catch (Exception e) {
            MessageUtils.showToast("清除失败");
            e.printStackTrace();
        }
    }

    public void handleCheckUpdate(View view) {
        UpdateUtil.getInstance(this).checkUpdate(true);
    }

    public void handleSignout(View view) {
        Helper.sharedHelper().signOut();
        MessageUtils.showToastCenter("已退出");
        finish();
    }

    public void handleComment(View view) {
        try {
            Uri uri = Uri.parse("market://details?id=" + getPackageName());
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void handleOpenAboutUs(View v) {
        Bundle bundle = new Bundle();
        bundle.putString("url", "http://kongge.com/support/about.html");
        Router.sharedRouter().open("web", bundle);
    }

    private String getVersion() throws Exception {
        if (HttpClient.BASE_URL_RELEASE.equals(HttpClient.genAbsoluteUrl(""))) {
            return Helper.sharedHelper().getVersionName();
        } else if (HttpClient.BASE_URL_PRE.equals(HttpClient.genAbsoluteUrl(""))) {
            return Helper.sharedHelper().getVersionName() + "_pre";
        } else if (HttpClient.BASE_URL_DEV.equals(HttpClient.genAbsoluteUrl(""))) {
            return Helper.sharedHelper().getVersionName() + "_dev";
        }
        return Helper.sharedHelper().getVersionName();
    }
}
