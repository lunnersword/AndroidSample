package com.meidalife.shz.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.StrUtil;

import butterknife.Bind;
import butterknife.ButterKnife;

public class RewardDialogActivity extends Activity {
    private boolean isLoading = false;
    private String receiverId;
    private String avatarUrl;
    private int rewardAmount;
    private String rewardDescString;

    @Bind(R.id.rewardLayout)
    ViewGroup rewardLayout;
    @Bind(R.id.iconClose)
    TextView iconClose;
    @Bind(R.id.avatar)
    SimpleDraweeView avatar;
    @Bind(R.id.rewardDesc)
    TextView rewardDesc;
    @Bind(R.id.changeReward)
    TextView changeReward;
    @Bind(R.id.rewardValue)
    TextView rewardValue;
    @Bind(R.id.rewardButton)
    Button rewardButton;

    @Bind(R.id.resultIconClose)
    TextView resultIconClose;
    @Bind(R.id.rewardResultLayout)
    ViewGroup rewardResultLayout;
    @Bind(R.id.rewardResultTitle)
    TextView rewardResultTitle;
    @Bind(R.id.rewardResultDesc)
    TextView rewardResultDesc;
    @Bind(R.id.rewardResultAmount)
    TextView rewardResultAmount;
    @Bind(R.id.rewardResultAvatar)
    SimpleDraweeView rewardResultAvatar;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reward_dialog);
        ButterKnife.bind(this);
        boolean showResult = getIntent().getBooleanExtra("showResult", false);
        if (!showResult) {
            initComponents();
        } else {
            rewardDescString = getIntent().getStringExtra("rewardsDesc");
            try {
                rewardAmount = Integer.parseInt(getIntent().getStringExtra("amount"));
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            initResultComponents(getIntent().getStringExtra("owner"));
        }
        setFinishOnTouchOutside(false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case Constant.REQUEST_CODE_REWARD_PAY: {
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getBooleanExtra(Pay.TAG_PAY_RESULT, false)) {
                        setResult(RESULT_OK, data);
                        finish();
                        //initResultComponents(Helper.sharedHelper().getStringUserInfo("nick"));
                    } else {
                        //支付失败
                        finish();
                    }
                }
            }
        }
    }

    private void initComponents() {
        receiverId = getIntent().getStringExtra("receiverId");
        avatarUrl = getIntent().getStringExtra("avatar");

        if (!TextUtils.isEmpty(avatarUrl)) {
            String cdnUrl = ImgUtil.getCDNUrlWithHeight(avatarUrl,
                    getResources().getDimensionPixelSize(R.dimen.reward_avatar_icon_size));
            avatar.setImageURI(Uri.parse(cdnUrl));
        }

        iconClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        changeReward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getRewards();
            }
        });

        rewardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(RewardDialogActivity.this, RewardPayDialogActivity.class);
                intent.putExtra("receiverId", receiverId);
                intent.putExtra("amount", rewardAmount);
                intent.putExtra("rewardsDesc", rewardDescString);

                startActivityForResult(intent, Constant.REQUEST_CODE_REWARD_PAY);
            }
        });

        rewardLayout.setVisibility(View.VISIBLE);
        rewardResultLayout.setVisibility(View.GONE);
        getRewards();
    }

    private void initResultComponents(String owner) {
        rewardLayout.setVisibility(View.GONE);
        rewardResultLayout.setVisibility(View.VISIBLE);
        rewardResultDesc.setText(rewardDescString);
        rewardResultAmount.setText(StrUtil.doubleFormat((double) rewardAmount / 100));

        avatarUrl = getIntent().getStringExtra("avatar");

        rewardResultTitle.setText(TextUtils.isEmpty(owner) ? getString(R.string.chat_item_reward) :
                String.format(getString(R.string.reward_owner), owner));
        if (!TextUtils.isEmpty(avatarUrl)) {
            String cdnUrl = ImgUtil.getCDNUrlWithHeight(avatarUrl,
                    getResources().getDimensionPixelSize(R.dimen.reward_avatar_icon_size));
            rewardResultAvatar.setImageURI(Uri.parse(cdnUrl));
        }

        resultIconClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void getRewards() {
        if (isLoading) {
            return;
        }
        showProgressDialog();
        HttpClient.get("1.0/rewards/getRewards", new JSONObject(), JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        hideProgressDialog();
                        JSONObject rewards = obj.getJSONObject("rewards");
                        rewardAmount = rewards.getIntValue("amount");
                        rewardDescString = rewards.getString("desc");
                        rewardValue.setText(String.format(getString(R.string.money_unit),
                                StrUtil.doubleFormat((double) rewardAmount / 100)));
                        rewardDesc.setText(rewardDescString);
                        isLoading = false;
                    }

                    @Override
                    public void onFail(HttpError error) {
                        isLoading = false;
                        hideProgressDialog();
                        MessageUtils.showToast(getString(R.string.reward_failed) + error.toString());
                        finish();
                    }
                });
    }

    private void showProgressDialog() {
        if (progressDialog == null) {
            progressDialog = new ProgressDialog(this);
        }
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    private void hideProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
}
