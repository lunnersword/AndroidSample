package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.model.PositionOutDO;
import com.meidalife.shz.rest.request.RequestAddress;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

public class AddressCreateActivity extends BaseActivity {

    private boolean isDefaultAddress = false;

    EditText textNickname;
    EditText textPhone;
    EditText textDetailAddress;
    TextView textPickAddress;
//    TextView iconNickname;
//    TextView iconPhone;
//    TextView iconCity;
//    TextView iconAddress;
//    TextView iconRight;

    @Bind(R.id.defaultLabel)
    TextView iconCheckFull;
    @Bind(R.id.textDefaultAddress)
    TextView textDefaultAddress;
    @Bind(R.id.btnSetDefault)
    View btnSetDefault;

    int cityCode;
    PositionOutDO poiDO = null;
    String matchedAddress = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address_create);
        initActionBar(R.string.title_activity_address_create, true, false);

        ButterKnife.bind(this);

        textNickname = (EditText) findViewById(R.id.nickname);
        textPhone = (EditText) findViewById(R.id.phone);
        textPickAddress = (TextView) findViewById(R.id.pickAddress);
        textDetailAddress = (EditText) findViewById(R.id.address);

        if (Helper.sharedHelper().getStringUserInfo("mobile") != null) {
            textPhone.setText(Helper.sharedHelper().getStringUserInfo("mobile"));
        }
        if (Helper.sharedHelper().getStringUserInfo("nick") != null) {
            textNickname.setText(Helper.sharedHelper().getStringUserInfo("nick"));
        }

        initPhoneListener();
    }

    public void handlePickLocation(View view) {
        Router.sharedRouter().openFormResult("pick/addresslocation", Constant.REQUEST_CODE_PICK_ADDRESS, this);
    }

    public void handleSetDefault(View view) {

        if (!isDefaultAddress) {
            iconCheckFull.setTextColor(getResources().getColor(R.color.red_a));
            textDefaultAddress.setTextColor(getResources().getColor(R.color.red_a));
            isDefaultAddress = true;
        } else {
            iconCheckFull.setTextColor(getResources().getColor(R.color.grey_c));
            textDefaultAddress.setTextColor(getResources().getColor(R.color.grey_c));
            isDefaultAddress = false;
        }
    }

    public void handleSaveAddress(View view) {

        if (textNickname.getText().length() == 0) {
            MessageUtils.showToastCenter("请输入昵称");
            return;
        }
        if (textPhone.getText().length() == 0) {
            MessageUtils.showToastCenter("请输入手机号");
            return;
        } else if (textPhone.getText().length() != 13) {
            MessageUtils.showToastCenter("请输入正确的手机号");
            return;
        }
        if (textPickAddress.getText().length() == 0) {
            MessageUtils.showToastCenter("请选择地址");
            return;
        }
        if (textDetailAddress.getText().length() == 0) {
            MessageUtils.showToastCenter("请填写详细地址");
            return;
        }

        btnSetDefault.setEnabled(false);

        addAddress();
    }

    void addAddress() {

        try {
            //addressName 只做展示 不做修改
//            params.put("isEdited", 1);
            JSONObject params = new JSONObject();
            params.put("contactorName", textNickname.getText().toString());
            params.put("contactorPhone", textPhone.getText().toString().replace(" ", ""));

            if (poiDO != null) {
                params.put("name", poiDO.getName());
                params.put("address", poiDO.getAddress());
                params.put("poiLongitude", "" + poiDO.getPoiLongitude());
                params.put("poiLatitude", "" + poiDO.getPoiLatitude());
            }

            params.put("detailedAddress", textDetailAddress.getText().toString());

            //新增字段
            params.put("matchedName", matchedAddress);

            params.put("selected", isDefaultAddress ? 1 : 0);

            RequestAddress.addAddress(params, new HttpClient.HttpCallback<AddressItem>() {
                @Override
                public void onSuccess(AddressItem result) {
                    /**
                     * 该段代码返回地址数据 给下单页OrderActivity.java选择地址使用
                     */
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(Constant.EXTRA_TAG_ADDRESS, result);
                    intent.putExtras(bundle);
                    setResult(RESULT_OK, intent);
//                    setDefaultAddress(result);
                    finish();
                }

                @Override
                public void onFail(HttpError error) {
                    btnSetDefault.setEnabled(true);
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "创建地址失败，请重试");
                }
            });
        } catch (JSONException e) {

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //todo 选择地址 返回地址信息和poi信息
        if (Constant.REQUEST_CODE_PICK_ADDRESS == requestCode && resultCode == RESULT_OK) {
            poiDO = (PositionOutDO) data.getSerializableExtra("positionDO");
            if (poiDO != null) {
                xhrMatchedAddress(poiDO);
            }
        }
    }

    void xhrMatchedAddress(PositionOutDO poiDO) {
        JSONObject params = new JSONObject();

        try {
            if (poiDO != null) {
                params.put("name", poiDO.getName());
                params.put("address", poiDO.getAddress());
                params.put("poiLongitude", "" + poiDO.getPoiLongitude());
                params.put("poiLatitude", "" + poiDO.getPoiLatitude());
            }

            RequestAddress.matchAddress(params, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {
                    if (result.containsKey("matchedName")) {
                        matchedAddress = result.getString("matchedName");
                    }
                    textPickAddress.setText(matchedAddress);
                }

                @Override
                public void onFail(HttpError error) {
                    btnSetDefault.setEnabled(true);
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "获取匹配地址失败，请重试");
                }
            });
        } catch (JSONException e) {

        }
    }

    private void initPhoneListener() {
        textPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String contents = Helper.formatMobileNumber(s.toString());
                if (contents.length() != s.toString().length()) {
                    textPhone.setText(contents);
                    textPhone.setSelection(contents.length());
                }
            }
        });
    }
}
