package com.meidalife.shz.analysis;

/**
 * Created by fufeng on 15/11/12.
 */
public class LogParam {
    //type 事件类型
    private int type;
    //eid  事件ID
    private String eid;
    //
    private String pvid;
    // 标签页序号从左到右从1开始
    private String poid;

    //页面ID
    private String pid;

    private String categoryId;

    private String h5Param;
    //格子id
    private String geziid;
    //宝贝id
    private String itemid;

    public String getPoid() {
        return poid;
    }

    public void setPoid(String poid) {
        this.poid = poid;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getEid() {
        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid;
    }

    public String getPvid() {
        return pvid;
    }

    public void setPvid(String pvid) {
        this.pvid = pvid;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getH5Param() {
        return h5Param;
    }

    public void setH5Param(String h5Param) {
        this.h5Param = h5Param;
    }


    //格子埋点字段
    public String getGeziid() {
        return geziid;
    }

    public void setGeziid(String geziid) {
        this.geziid = geziid;
    }

    public String getItemid() {
        return itemid;
    }

    public void setItemid(String itemid) {
        this.itemid = itemid;
    }
}
