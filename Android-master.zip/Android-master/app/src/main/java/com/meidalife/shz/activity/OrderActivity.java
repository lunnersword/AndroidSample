package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.BookTimeDayAdapter;
import com.meidalife.shz.adapter.BookTimeHourAdapter;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpClient.HttpCallback;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.model.ItemVO;
import com.meidalife.shz.rest.model.OrderVO;
import com.meidalife.shz.rest.model.SellerVO;
import com.meidalife.shz.rest.model.TimeVO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.MyGridView;
import com.usepropeller.routable.Router;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import it.sephiroth.android.library.widget.AdapterView;
import it.sephiroth.android.library.widget.HListView;

/**
 * 下单页
 */

public class OrderActivity extends BaseActivity {

    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.cellServiceTime)
    RelativeLayout cellServiceTime;

    @Bind(R.id.textAddressAndUserInfo)
    RelativeLayout textAddressAndUserInfo;

    @Bind(R.id.cellToolBar)
    RelativeLayout cellToolBar;

    @Bind(R.id.redPaperTips)
    TextView redPaperTips;
    @Bind(R.id.textServiceType)
    TextView textServiceType;
    @Bind(R.id.textTime)
    TextView textTime;
    @Bind(R.id.textAddressLabel)
    TextView textAddressLabel;
    @Bind(R.id.cellServiceAddress)
    LinearLayout cellServiceAddress;
    @Bind(R.id.textContactInfo)
    TextView textContactInfo;
    @Bind(R.id.textAddress)
    TextView textAddress;
    @Bind(R.id.textAddressEmpty)
    TextView textAddressEmpty;
    @Bind(R.id.textMessage)
    TextView textMessage;

    @Bind(R.id.imageAvatar)
    SimpleDraweeView imageAvatar;
    @Bind(R.id.textSellerName)
    TextView textSellerName;
    @Bind(R.id.imageItem)
    SimpleDraweeView imageItem;
    @Bind(R.id.textItemTag)
    TextView textItemTag;
    //商品服务类型
    @Bind(R.id.itemServiceType)
    TextView mItemServiceType;
    @Bind(R.id.textItemPrice)
    TextView textItemPrice;
    @Bind(R.id.is_mcoin)
    TextView isMcoin;
    //活动促销标
    @Bind(R.id.promotion)
    TextView promotion;

    @Bind(R.id.textSellerAddress)
    TextView textSellerAddress;
    @Bind(R.id.cellSellerAddress)
    RelativeLayout cellSellerAddress;

    @Bind(R.id.cellProtectionInfo)
    LinearLayout cellProtectionInfo;

    @Bind(R.id.textProtectionInfo)
    TextView textProtectionInfo;

    @Bind(R.id.textOrderPrice)
    TextView textOrderPrice;
    @Bind(R.id.btnBuy)
    Button btnBuy;

    //增加商品数量
    @Bind(R.id.addItemCount)
    TextView addItemCount;
    //减少商品数量
    @Bind(R.id.decItemCount)
    View decItemCount;
    //原价
    @Bind(R.id.oriPriceItemPrice)
    TextView oriPriceItemPrice;
    //stock
    @Bind(R.id.itemStockTV)
    TextView itemStockTV;

    @Bind(R.id.itemCount)
    TextView itemCount;

    //活动促销标
    @Bind(R.id.itmCountDesc)
    TextView itmCountDesc;

    //todo 针对格子服务 需要修改标题
    @Bind(R.id.itemCountTitle)
    TextView itemCountTitle;


    @Bind(R.id.itemInfoView)
    View itemInfoView;
    @Bind(R.id.sellerInfoView)
    View sellerInfoView;

    //todo 格子宝贝 修改销保文案

    String itemId;
    long snapshotItemId;

    int serviceType;
    Boolean loadComplete;
    Boolean loadOrder;
    Boolean loadPay;
    List<TimeVO> timeList;
    String bookDate;
    String bookHour;
    String geziId;
    private boolean isPaidan = false;
    int bookDateIndex;
    int bookHourIndex;
    int bookHourIndexRelativeDateIndex;

    private int lastSelectIndex = -1;

    //商品最多可以购买数量
    private int buyLimit;
    //商品最少可以购买数量
    private int buyDownLimit = 1;

    //库存
    private int itemStock;//库存

    private static final int SERVICE_TYPE_VISIT = 1;
    private static final int SERVICE_TYPE_STORE = 2;
    private static final int SERVICE_TYPE_ONLINE = 3;
    private static final int SERVICE_TYPE_DELIVER = 4;

    private int currentItemCount = 1;

    private long priceCent;//价格
    private long promotionPriceCent;//促销价格
    private Long promotionId;//促销id

    NumberFormat formatter = new DecimalFormat("#0.00");
    OrderVO orderVO;
    AddressItem addressItem = new AddressItem();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        initActionBar(R.string.title_activity_order, true);
        ButterKnife.bind(this);

        itemId = null;

        loadComplete = false;
        loadOrder = false;
        loadPay = false;
        bookDateIndex = 0;
        bookHourIndex = -1;
        bookHourIndexRelativeDateIndex = -1;

        Bundle intentExtras = getIntent().getExtras();
        itemId = intentExtras != null ? intentExtras.getString("id") : null;
        geziId = getIntent().getStringExtra(Constant.EXTRA_TAG_SQUARE_ID);

        hideIMM();

        initClickEvent();

        orderVO = new OrderVO();

        xhrOrderForm();
        //todo 需要一个字段来判断宝贝类型 格子洗衣或者家政 普通宝贝
    }

    void initClickEvent() {
        textMessage.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
                    return true;
                }
                return false;
            }
        });
        addItemCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (buyLimit > 0 && currentItemCount >= buyLimit) {
                    MessageUtils.showToast("每人限购" + buyLimit + "件");
                    return;
                }

                if (itemStock > 0 && currentItemCount >= itemStock) {
                    MessageUtils.showToast("库存不足");
                    return;
                }
                currentItemCount++;
                //重新计算总价
//                xhrOrderForm();
                updateTotalPrice();
            }
        });

        decItemCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (buyDownLimit > 0 && currentItemCount <= buyDownLimit) {
                    MessageUtils.showToast(String.format("最少购买%s件", buyDownLimit));
                    return;
                }
                currentItemCount--;
                //重新计算总价
                updateTotalPrice();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if ((requestCode == Constant.REQUEST_CODE_PICK_ADDRESS && resultCode == RESULT_OK)
                || (requestCode == Constant.REQUEST_CODE_CHANGE_ADDRESS && resultCode == RESULT_OK)) {
            if (data != null && data.getExtras() != null) {
                Bundle bundle = data.getExtras();
                addressItem = (AddressItem) bundle.getSerializable(Constant.EXTRA_TAG_ADDRESS);
                if (null != addressItem) {
                    renderAddressInfo(addressItem.getAddressName(), addressItem.getContactorPhone(),
                            addressItem.getContactorName());
                }
                lastSelectIndex = bundle.getInt("lastSelectIndex");
            }
        } else if (requestCode == Constant.REQUEST_CODE_PICK_ADDRESS && resultCode == RESULT_CANCELED) {
            Bundle bundle = data.getExtras();
            if (bundle != null) {
                lastSelectIndex = bundle.getInt("lastSelectIndex");
            }
        }
    }

    private void renderAddressInfo(String addressName, String phone, String name) {
        textAddressLabel.setVisibility(View.GONE);
        textAddressEmpty.setVisibility(View.GONE);
        cellServiceAddress.setVisibility(View.VISIBLE);
        String contactString = "联系人：" + name;
        contactString += "，";
        contactString += phone;
        textContactInfo.setText(contactString);

        if (serviceType == SERVICE_TYPE_VISIT || serviceType == SERVICE_TYPE_DELIVER) {
            textAddress.setText(addressName);
        }
    }

    private void xhrOrderForm() {
        cellToolBar.setVisibility(View.GONE);
        scrollView.setVisibility(View.GONE);
        hideStatusErrorNetwork();
        hideStatusErrorServer();
        showStatusLoading(rootView);

        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("itemId", itemId);
        if (!TextUtils.isEmpty(geziId)) {
            params.put("geziId", geziId);
        }
        HttpClient.get("1.0/buyerOrder/orderForm", params, OrderVO.class, new HttpCallback<OrderVO>() {
            @Override
            public void onSuccess(OrderVO result) {
                cellToolBar.setVisibility(View.VISIBLE);
                scrollView.setVisibility(View.VISIBLE);
                hideStatusLoading();

                orderVO = result;
                isPaidan = result.getPaidan();
                updateView(result);
            }

            @Override
            public void onFail(HttpError error) {
                xhrFailure(error);
            }
        });
    }

    void updateView(OrderVO result) {
        //服务时间是否可见
        serviceType = result.getServiceType();
        cellServiceTime.setVisibility(serviceType == SERVICE_TYPE_DELIVER ? View.GONE : View.VISIBLE);
        textAddressAndUserInfo.setVisibility(serviceType == SERVICE_TYPE_ONLINE ? View.GONE : View.VISIBLE);

//        cellUserName.setVisibility(serviceType == SERVICE_TYPE_STORE ? View.VISIBLE : View.GONE);
//        cellUserPhoneNumber.setVisibility(serviceType == SERVICE_TYPE_STORE ? View.VISIBLE : View.GONE);

        // 服务类型
        //todo 针对格子宝贝 需要展现
        textServiceType.setText(result.getServiceTypeText());
        //订单价格 todo update price
        textOrderPrice.setText(result.getAmount());

        // 消保文案
        if (CollectionUtil.isNotEmpty(result.getGurantees())) {
            StringBuffer tips = null;
            for (String tee : result.getGurantees()) {
                if (tips == null) {
                    tips = new StringBuffer(tee).append("\n");
                } else {
                    tips = tips.append(tee).append("\n");
                }
            }

            textProtectionInfo.setText(tips.toString());
            cellProtectionInfo.setVisibility(View.VISIBLE);
        }

        // 地址
        if (result.getBuyer() != null) {
            textAddressLabel.setVisibility(View.GONE);
            textAddressEmpty.setVisibility(View.GONE);
            cellServiceAddress.setVisibility(View.VISIBLE);
            String contactString = "联系人：" + result.getBuyer().getContactorName();
            contactString += "，";
            contactString += result.getBuyer().getContactorPhone();
            textContactInfo.setText(contactString);
            textAddress.setText(result.getBuyer().getAddressName());
            addressItem.setAddressName(result.getBuyer().getAddressName());
            addressItem.setContactorName(result.getBuyer().getContactorName());
            addressItem.setContactorPhone(result.getBuyer().getContactorPhone());
            addressItem.setAddressId(result.getBuyer().getAddressId());
        } else {
            textAddressLabel.setVisibility(View.VISIBLE);
            textAddressEmpty.setVisibility(View.VISIBLE);
            cellServiceAddress.setVisibility(View.GONE);
        }

        // 可服务时间
        timeList = result.getTime();

        if (!TextUtils.isEmpty(result.getRedpackTip())) {
            redPaperTips.setText(result.getRedpackTip());
            redPaperTips.setVisibility(View.VISIBLE);
        }


        ItemVO itemVO = result.getItem();
        if (itemVO != null) {
            buyDownLimit = currentItemCount = itemVO.getBuyDownLimit() > 0 ? itemVO.getBuyDownLimit() : 1;
//            currentItemCount = currentItemCount > itemVO.getBuyDownLimit() ? currentItemCount : itemVO.getBuyDownLimit();

            promotionId = itemVO.getPromotionId();
            priceCent = itemVO.getPriceCent();
            promotionPriceCent = itemVO.getPromotionPriceCent();
            buyLimit = itemVO.getBuyLimit();
            itemStock = itemVO.getInventory();
            snapshotItemId = itemVO.getSnapshotItemId();


            if (isPaidan) {
                itemCountTitle.setText(itemVO.getQuantityPrefix());
            }

            //增加限购数量解析逻辑
            if (buyLimit > 0) {
                itmCountDesc.setText(String.format("(每人限购%s件)", buyLimit));
                itmCountDesc.setVisibility(View.VISIBLE);
            }

            //设置数量
            itemCount.setText(String.valueOf(currentItemCount));
        }

        if (isPaidan) {
            return;
        } else {
            sellerInfoView.setVisibility(View.VISIBLE);
            itemInfoView.setVisibility(View.VISIBLE);
        }

        // 卖家信息 //todo set default avatar
        SellerVO sellerVO = result.getSeller();
        if (sellerVO != null) {
            if (!TextUtils.isEmpty(sellerVO.getPicUrl())) {
                String picUrl = ImgUtil.getCDNUrlWithWidth(result.getSeller().getPicUrl(), imageAvatar.getLayoutParams().width);
                imageAvatar.setImageURI(Uri.parse(picUrl));
            } else {
                String userId = sellerVO.getUserId();
                String gender = sellerVO.getGender();
                if (userId != null && gender != null) {
                    Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(OrderActivity.this, userId, gender);
                    imageAvatar.setImageURI(getDefaultAvatarUri);
                }
            }
            textSellerName.setText(sellerVO.getNick());

            // 到店服务有卖家地址显示
            if (!TextUtils.isEmpty(sellerVO.getAddressName())) {
                textSellerAddress.setText(sellerVO.getAddressName());
                cellSellerAddress.setVisibility(View.VISIBLE);
            }
        }

        // 商品信息
        if (itemVO != null) {
            if (!TextUtils.isEmpty(itemVO.getItemImage())) {
                String url = ImgUtil.getCDNUrlWithWidth(itemVO.getItemImage(), imageItem.getLayoutParams().width);
                if (!TextUtils.isEmpty(url)) {
                    imageItem.setImageURI(Uri.parse(url));
                }
            }
            textItemTag.setText(itemVO.getTitle());

            //判断商品服务类型 展示字段
            if (result.getServiceType() == SERVICE_TYPE_DELIVER) {
                if (itemVO.getIsSpot() == 1) {
                    mItemServiceType.setText("邮寄(现货)");
                } else {
                    mItemServiceType.setText("邮寄(定制)");
                }
            } else {
                mItemServiceType.setText(result.getServiceTypeText());
            }

            if ("1".equals(itemVO.getSupportPoint())) {
                isMcoin.setVisibility(View.VISIBLE);
            }

            if (itemStock > 0) {
                itemStockTV.setText(String.format("(剩余%s件)", itemStock));
                itemStockTV.setVisibility(View.VISIBLE);
            }

            if (TextUtils.isEmpty(itemVO.getPromotionPrice())) {
                textItemPrice.setText(itemVO.getPrice());
            } else {
                textItemPrice.setText(itemVO.getPromotionPrice());
                oriPriceItemPrice.setText(itemVO.getPrice());
                oriPriceItemPrice.setVisibility(View.VISIBLE);
                oriPriceItemPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
            }

            List<String> tipsList = itemVO.getPromotionTips();
            if (CollectionUtil.isNotEmpty(tipsList)) {
                if (!TextUtils.isEmpty(tipsList.get(0))) {
                    promotion.setText(tipsList.get(0));
                    promotion.setVisibility(View.VISIBLE);
                }
            }
        }

    }

    private void updateTotalPrice() {
        long totalPrice = 0;
        if (!TextUtils.isEmpty(orderVO.getEarnestPrice())) {
            try {
                int earneastPrice = Integer.valueOf(orderVO.getEarnestPrice());
                totalPrice = earneastPrice * currentItemCount;
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        if (totalPrice == 0) {
            if (promotionPriceCent > 0) {
                totalPrice = promotionPriceCent * currentItemCount;
            } else {
                totalPrice = priceCent * currentItemCount;
            }
        }
        textOrderPrice.setText(formatter.format(totalPrice / 100.00) + "元");

        itemCount.setText("" + currentItemCount);
    }

    private void xhrFailure(HttpError error) {
        scrollView.setVisibility(View.GONE);
        cellToolBar.setVisibility(View.GONE);
        hideStatusLoading();
        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
            showStatusErrorNetwork(rootView, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    xhrOrderForm();
                }
            });
        } else {
            showStatusErrorServer(rootView, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    xhrOrderForm();
                }
            });
        }
    }


    public void handleBuy(View view) {
        //上门和邮寄需要地址
        if (serviceType != SERVICE_TYPE_DELIVER && serviceType != SERVICE_TYPE_VISIT && addressItem.getAddressId() == 0) {
            MessageUtils.showToastCenter("请选择联系方式");
            return;
        }

        if (serviceType != SERVICE_TYPE_DELIVER && textTime.getText().length() == 0) {
            MessageUtils.showToastCenter("请选择预约时间");
            return;
        }

        if (addressItem.getAddressId() < 0) {
            MessageUtils.showToastCenter("请选择联系人");
            return;
        }

        btnBuy.setEnabled(false);

        try {
            JSONObject params = new JSONObject();
            params.put("itemId", itemId);
            params.put("title", textItemTag.getText().toString());
            params.put("addressId", addressItem.getAddressId());
            params.put("buyerRemark", textMessage.getText().toString());
            params.put("snapshotItemId", snapshotItemId);
            params.put("promotionId", promotionId);
            if (!TextUtils.isEmpty(geziId)) {
                params.put("geziId", geziId);
            }

            params.put("quantity", currentItemCount);
            if (serviceType != SERVICE_TYPE_DELIVER) {
                params.put("bookTime", textTime.getText().toString());
            }
            //todo 增加购买数量
            HttpClient.get("1.2/buyerOrder/order", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                @Override
                public void onSuccess(JSONObject result) {
                    try {
                        if (result.containsKey("orderNo")) {
                            String orderNo = result.getString("orderNo");
                            Bundle bundle = new Bundle();
                            bundle.putString("orderNo", orderNo);
                            if (result.containsKey("title")) {
                                bundle.putString("title", result.getString("title"));
                            }
                            Router.sharedRouter().open("pay", bundle);
                        }

                        if (result.containsKey("pvid")) {
                            LogParam param = new LogParam();
                            param.setType(LogUtil.TYPE_CUSTOMIZE);
                            param.setEid(LogUtil.EVENT_ID_ORDER_CREATTE);
                            param.setPvid(result.getString("pvid"));
                            LogUtil.log(param);
                        }

                        finish();
                    } catch (JSONException e) {
                        btnBuy.setEnabled(true);
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    btnBuy.setEnabled(true);
                    if (null == error) {
                        MessageUtils.showToast("预约失败，请重试");
                        return;
                    }
                    switch (error.getCode()) {
                        case HttpError.ERR_CODE_UPDATE_ADRESS: {
                            MessageUtils.createDialog(OrderActivity.this, error.getTitle(), error.getMessage(),
                                    R.string.update, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Bundle bundle = new Bundle();
                                            bundle.putString(Constant.EXTRA_TAG_ADDRESS_ID, String.valueOf(addressItem.getAddressId()));
                                            bundle.putInt(Constant.EXTRA_TAG_ADDRESS_STATUS, 1);
                                            Router.sharedRouter().openFormResult("address/change", bundle,
                                                    Constant.REQUEST_CODE_CHANGE_ADDRESS, OrderActivity.this);
                                        }
                                    }, R.string.cancel, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    }).show();
                            return;
                        }
                        case HttpError.ERR_CODE_SERVICE_OUT_OF_RANGE: {
                            showNotInSquareServiceTip(error);
                            return;
                        }
                        case HttpError.ERR_CODE_SQUARE_OUT_OF_RANGE: {
                            showMaxJoinedSquareTip(error);
                            return;
                        }
                        case HttpError.ERR_CODE_NEED_JOIN_SQUARE: {
                            showJoinSquareTip(error);
                            return;
                        }
                    }
                    MessageUtils.showToastCenter(error.getMessage());
                }
            });
        } catch (JSONException e) {
            btnBuy.setEnabled(true);
        }
    }

    public void handleSelectTime(View view) {
        openSelectTimeDialog();
    }

    public void handleSelectAddress(View view) {

        Bundle bundle = new Bundle();
        bundle.putInt("lastSelectIndex", lastSelectIndex);
        Router.sharedRouter().openFormResult("addresses", bundle, Constant.REQUEST_CODE_PICK_ADDRESS, this);
    }

    private void joinSquare(String squareId) {
        JSONObject params = new JSONObject();
        JSONArray array = new JSONArray();

        params.put("geziId", squareId);
        params.put("itemIdList", array);
        HttpClient.get("1.0/gezi/join", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        MessageUtils.showToast("加入成功");
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(error.toString());
                    }
                });
    }

    private void openSelectTimeDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.show();
        int deviceWidth = this.getResources().getDisplayMetrics().widthPixels;
        deviceWidth = deviceWidth - deviceWidth / 10;
        dialog.getWindow().setLayout(deviceWidth, ViewGroup.LayoutParams.WRAP_CONTENT);
        View view = getLayoutInflater().inflate(R.layout.view_select_time, null);
        dialog.getWindow().setContentView(view);
        HListView selectDateListView = (HListView) view.findViewById(R.id.optionDate);
        MyGridView selectHourGridView = (MyGridView) view.findViewById(R.id.optionHour);
        initSelectDateListView(dialog, selectDateListView, selectHourGridView);
    }

    private void initSelectDateListView(final AlertDialog dialog, HListView listView, final MyGridView selectHourGridView) {
        BookTimeDayAdapter adapter = new BookTimeDayAdapter(this, timeList);
        listView.setAdapter(adapter);
        listView.setFooterDividersEnabled(false);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                bookDateIndex = i;
                view.setSelected(true);
                selectedDate(dialog, selectHourGridView, bookDateIndex);
            }
        });

        listView.setItemChecked(bookDateIndex, true);
        selectedDate(dialog, selectHourGridView, bookDateIndex);
    }

    private void selectedDate(AlertDialog dialog, MyGridView selectHourGridView, int index) {
        if (CollectionUtil.isNotEmpty(timeList) && index < timeList.size()) {
            TimeVO timeVO = timeList.get(index);
            bookDate = timeVO.getDateString();
            initSelectHourGridView(dialog, selectHourGridView, (ArrayList) timeVO.getSubList());
        }
    }

    private void initSelectHourGridView(final AlertDialog dialog, MyGridView gridView, final ArrayList hours) {
        BookTimeHourAdapter adapter = new BookTimeHourAdapter(this, hours);
        gridView.setAdapter(adapter);
        gridView.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (view.isEnabled()) {
                    view.setSelected(true);
                    TimeVO.HourVO hourVO = (TimeVO.HourVO) hours.get(position);
                    bookHourIndex = position;
                    bookHourIndexRelativeDateIndex = bookDateIndex;
                    bookHour = hourVO.getHour();
                    textTime.setText(bookDate + " " + bookHour);
                    dialog.dismiss();
                } else {
                    view.setSelected(false);
                }
            }
        });

        if (bookHourIndex > -1 &&
                bookHourIndexRelativeDateIndex > -1 &&
                bookHourIndexRelativeDateIndex == bookDateIndex) {
            gridView.setItemChecked(bookHourIndex, true);
        }
    }

    private void showJoinSquareTip(final HttpError error) {
        try {
            MessageUtils.createDialog(this, error.getTitle(), error.getMessage(), null, R.mipmap.order_square_join_tip,
                    R.string.join_now, new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (!TextUtils.isEmpty(geziId)) {
                                joinSquare(geziId);
                            } else {
                                joinSquare(error.getInfo().getString("geziId"));
                            }
                            dialog.dismiss();
                        }
                    }, R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showMaxJoinedSquareTip(HttpError error) {
        MessageUtils.createDialog(this, error.getTitle(), error.getMessage(), null,
                R.mipmap.order_square_max_tip, R.string.confirm, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }, 0, null).show();
    }

    private void showNotInSquareServiceTip(HttpError error) {
        MessageUtils.createDialog(this, error.getTitle(), error.getMessage(), null,
                R.mipmap.order_square_out_service_tip, R.string.confirm, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }, 0, null).show();
    }
}

