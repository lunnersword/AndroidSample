package com.meidalife.shz.activity.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.wukong.Callback;
import com.alibaba.wukong.auth.AuthService;
import com.alibaba.wukong.im.Conversation;
import com.alibaba.wukong.im.ConversationService;
import com.alibaba.wukong.im.IMEngine;
import com.alibaba.wukong.im.Message;
import com.alibaba.wukong.im.MessageContent;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.MessageAdapter;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.event.ConversationEvent;
import com.meidalife.shz.event.EventSender;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.event.type.NetworkConnectEventModel;
import com.meidalife.shz.event.type.NetworkConnectTypeEnum;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ConversationDO;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.StrUtil;
import com.umeng.analytics.MobclickAgent;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.event.EventBus;

public class MessageChatFragment extends BaseFragment implements AbsListView.OnScrollListener {
    private boolean isMoreData = true;
    private boolean isLoading = false;
    private int previous;
    private int page = 1;
    private int pageSize = 25;
    private int maxSize = 500;
    private int preCount = 0;
    private int retry = 0;

    private Context context;

    private View rootLayout;
    private ViewGroup rootView;
    private View contentRoot;
    private LoadUtilV2 loadUtilV2;

    private ListView listView;
    private RelativeLayout cellEmptyData;
    private MessageAdapter adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        if (rootLayout == null) {
            context = inflater.getContext();
            rootLayout = inflater.inflate(R.layout.fragment_message_chat, null);

            rootView = (ViewGroup) rootLayout.findViewById(R.id.root_view);
            contentRoot = rootLayout.findViewById(R.id.content_root_view);
            loadUtilV2 = new LoadUtilV2(inflater);

            listView = (ListView) rootLayout.findViewById(R.id.message_list);
            cellEmptyData = (RelativeLayout) rootLayout.findViewById(R.id.message_no_data);

            /*
            点击进入聊天
             */
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    ConversationDO conversation = (ConversationDO) view.getTag();
                    String action = "chat/";
                    action += conversation.getUserId();
                    Bundle bundle = new Bundle();
                    bundle.putString("receiveAvatar", conversation.getAvatar());
                    bundle.putString("receiveName", conversation.getUserName());
                    Router.sharedRouter().open(action, bundle);
                    if (null != view.findViewById(R.id.badge_with_number)) {
                        view.findViewById(R.id.badge_with_number).setVisibility(View.GONE);
                    }
                }
            });

        /*
        长按删除聊天
         */
            listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                    View contextMenu = inflater.inflate(R.layout.message_delete_dialog, null);
                    final AlertDialog dialog = new AlertDialog.Builder(context).create();
                    dialog.setView(contextMenu, 0, 0, 0, 0);
                    dialog.show();
                    TextView deleteTv = (TextView) contextMenu.findViewById(R.id.singleContextMenu);
                    deleteTv.setText(R.string.delete_message);
                    deleteTv.setTag(position);
                    deleteTv.setOnClickListener(new DeleteMsgClickListener(dialog));
                    return true;
                }
            });

        /*
        滚动加载更多
         */
            listView.setOnScrollListener(this);
        }
        EventBus.getDefault().register(this);
        return rootLayout;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        loadMsgData(pageSize);
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart(this.getClass().getName());
        LogUtil.log(LogUtil.TYPE_START_PAGE, this.getClass().getName());
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void onEventMainThread(ConversationEvent event) {
        if (!event.getConversationList().isEmpty()) {
            loadMsgData(pageSize);
        }
    }

    public void onEventMainThread(NetworkConnectTypeEnum eventType) {
        if (NetworkConnectTypeEnum.TYPE_CONNECTED.equals(eventType)) {
            loadMsgData(pageSize);
        }
    }

    public void onEventMainThread(NetworkConnectEventModel model) {
        if (NetworkConnectTypeEnum.TYPE_CONNECTED.equals(model.type)) {
            loadMsgData(pageSize);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd(this.getClass().getName());
        LogUtil.log(LogUtil.TYPE_EXIT_PAGE, this.getClass().getName());
        /*
        更新小红点
         */
        ConversationService conversationService = IMEngine.getIMService(ConversationService.class);
        conversationService.getTotalUnreadCount(new Callback<Integer>() {
            @Override
            public void onSuccess(Integer size) {
                //使用event bus 实现
                EventSender.notifyHadNewMsg(MsgTypeEnum.TYPE_CHAT, size);
            }

            @Override
            public void onException(String s, String s1) {
            }

            @Override
            public void onProgress(Integer integer, int i) {
            }
        }, false);
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);

        try {
            ViewGroup parent = (ViewGroup) rootLayout.getParent();
            if (parent != null) {
                parent.removeView(rootLayout);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (!isMoreData) {
            return;         // 若已无数据，则忽略
        }
        if (isLoading) {
            return;         // 若已加载中，则忽略
        }
        boolean moveToBottom = false;
        if (previous < firstVisibleItem) {
            moveToBottom = true;
        }
        previous = firstVisibleItem;
        if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
            isLoading = true;
            page = page + 1;
            int count = page * pageSize;
            if (count > maxSize) {
                isMoreData = false;
                return;
            } else {
                loadMsgData(count);
            }
        }
    }

    /**
     * 加载聊天数据，一次取50条
     */
    public void loadMsgData(final int count) {
        loadUtilV2.loadPre(rootView, contentRoot);
        isLoading = true;

        if (count == pageSize) {  // 说明是第一次请求，初始化标示数据
            isMoreData = true;
            isLoading = false;
            preCount = 0;
        }
        if (!AuthService.getInstance().isLogin() && retry <= 5) {
            try {
                Long userId = Long.parseLong(Helper.sharedHelper().getUserId());
                if (IMEngine.getIMService(AuthService.class).latestAuthInfo().getOpenId() == userId) {
                    IMEngine.getIMService(AuthService.class).autoLogin(userId);
                    rootView.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            loadMsgData(pageSize);
                        }
                    }, 500 + retry * 100);
                } else {
                    ChatHelper.getInstance(getActivity()).authWuKong(Helper.sharedHelper().getUserId());
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            return;
        }

        /*
         获取会话列表
          */
        ConversationService conversationService = IMEngine.getIMService(ConversationService.class);
        conversationService.listConversations(new Callback<List<Conversation>>() {
            @Override
            public void onSuccess(List<Conversation> conversations) {
                isLoading = false;
                loadUtilV2.loadSuccess(contentRoot);
                if (conversations.size() == 0) {
                    listView.setVisibility(View.GONE);
                    cellEmptyData.setVisibility(View.VISIBLE);
                    isMoreData = false;
                } else {
                    if (conversations.size() < count) {
                        isMoreData = false;
                    }
                    List<ConversationDO> cdList = new ArrayList<>();
                    for (Conversation c : conversations) {
                        ConversationDO cd = convert(c);
                        if (cd == null) continue;
                        cdList.add(cd);
                    }
                    adapter = new MessageAdapter(context, cdList);
                    listView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                    listView.setVisibility(View.VISIBLE);
                    listView.setSelection(preCount);
                    preCount = count;
                }
            }

            @Override
            public void onException(String s, String s1) {
                isLoading = false;
                HttpError error = new HttpError(HttpError.ERR_CODE_SERVER_ERROR, s + ", " + s1);
                loadUtilV2.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        loadMsgData(count);
                    }
                });
            }

            @Override
            public void onProgress(List<Conversation> conversations, int i) {
            }
        }, count, Conversation.ConversationType.CHAT);
    }

    private ConversationDO convert(Conversation c) {

        final ConversationDO cd = new ConversationDO();
        cd.setConversation(c);
        Message msg = c.latestMessage();

        if (msg == null) {  // 脏数据，忽略此消息
            Log.e(MessageChatFragment.class.getName(), "wukong last message is null, conversation id = " + c.conversationId());
            return null;
        }

        try {
            MessageContent content = msg.messageContent();

            cd.setType(ConversationDO.TYPE_IM);
            cd.setSubTitle(ChatHelper.getMessageSubTitle(content));
            cd.setTime(msg.createdAt() / 1000);  // 转换为秒
            cd.setUnread(c.unreadMessageCount());

            cd.setDraftMessage(c.draftMessage());

        /*
        获取用户信息
         */
            String fromStr = msg.extension("from");
            String toStr = msg.extension("to");
            String toUserId = String.valueOf(c.getPeerId());

        /*
        若from或to是空，则忽略跳过
         */
            if (StrUtil.isEmpty(fromStr) || StrUtil.isEmpty(toStr)) {
                Log.e(MessageChatFragment.class.getName(), "wukong message, cid = " + c.conversationId() + ", msgid = " + msg.messageId() + ", formStr = " + fromStr + ", toStr = " + toStr);
                return null;
            }

        /*
        从message中获取
         */
            JSONObject from = JSONObject.parseObject(fromStr);
            JSONObject to = JSONObject.parseObject(toStr);
            if (null != to && toUserId.equals(to.getString("id"))) {
                cd.setUserId(to.getString("id"));
                cd.setAvatar(to.getString("avatar"));
                cd.setUserName(to.getString("nick"));
            } else if (null != from) {
                cd.setUserId(from.getString("id"));
                cd.setAvatar(from.getString("avatar"));
                cd.setUserName(from.getString("nick"));
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return cd;
    }

    public class DeleteMsgClickListener implements View.OnClickListener {

        private Dialog dialog;

        public DeleteMsgClickListener(Dialog dialog) {
            this.dialog = dialog;
        }

        @Override
        public void onClick(View v) {
            final Integer position = (Integer) v.getTag();
            ConversationDO cd = (ConversationDO) adapter.getItem(position);
            Conversation wkc = cd.getConversation();
            wkc.remove();
            adapter.remove(position);
            adapter.notifyDataSetChanged();
            dialog.dismiss();
        }
    }
}
