package com.meidalife.shz.event;

import de.greenrobot.event.EventBus;

/**
 * 重写方法、判断订阅状态以后在执行注册操作
 * Created by zhq on 15/10/14.
 */
public class SHZEventBus extends EventBus {

//    private static final SHZEventBus instance = new SHZEventBus();

//    private SHZEventBus(){}
//
//    public static SHZEventBus getInstance(){
//        EventBus.clearCaches();
//        return instance;
//    }

    @Override
    public void register(Object subscriber) {
        if (!isRegistered(subscriber)) {
            super.register(subscriber);
        }
    }

    @Override
    public void register(Object subscriber, int priority) {
        if (!isRegistered(subscriber)) {
            super.register(subscriber, priority);
        }
    }

    @Override
    public synchronized void unregister(Object subscriber) {
        if (subscriber != null && isRegistered(subscriber)) {
            super.unregister(subscriber);
        }
    }

    @Override
    public void registerSticky(Object subscriber) {
        if (!isRegistered(subscriber)) {
            super.registerSticky(subscriber);
        }
    }

    @Override
    public void registerSticky(Object subscriber, int priority) {
        if (!isRegistered(subscriber)) {
            super.registerSticky(subscriber, priority);
        }
    }
}
