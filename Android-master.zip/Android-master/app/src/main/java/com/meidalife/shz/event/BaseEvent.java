package com.meidalife.shz.event;

import com.meidalife.shz.event.type.MsgTypeEnum;

/**
 * Created by fufeng on 15/11/8.
 */
public class BaseEvent {
    public BaseEvent() {

    }

    public BaseEvent(MsgTypeEnum type) {
        eventType = type;
    }

    public MsgTypeEnum eventType;
}
