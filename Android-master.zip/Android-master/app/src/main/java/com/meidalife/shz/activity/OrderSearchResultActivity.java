package com.meidalife.shz.activity;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.OrderListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.OrderDO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/9/27.
 * 订单搜索
 */
public class OrderSearchResultActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener {
    public static final int ROLE_TYPE_BUY = 1;
    public static final int ROLE_TYPE_SELL = 2;

    private static final String TAG_SEARCH_KEYWORD = "query";
    private static final String TAG_SEARCH_SORT = "sort";
    private static final String TAG_SEARCH_OFFSET = "offset";
    private static final String TAG_SEARCH_PAGESIZE = "pageSize";
    private static final String TAG_SEARCH_TYPE = "searchType";
    private static final String TAG_SEARCH_FILTER = "filter";
    private static final String TAG_TYPE = "type";

    private static final String keywordFormat = "default:\'%s\'";
    private List<OrderDO> orderDataList = Collections.synchronizedList(new ArrayList<OrderDO>());

    @Bind(R.id.action_back)
    TextView backKey;
    @Bind(R.id.head_search_input)
    EditText searchKeyword;
    @Bind(R.id.action_search)
    TextView searchButton;
    @Bind(R.id.cellStatusLoading)
    ViewGroup cellStatusLoading;
    @Bind(R.id.order_list)
    ListView searchResultList;
    @Bind(R.id.hint_layout)
    LinearLayout hintLayout;

    @Bind(R.id.hint_message)
    TextView hintMessage;
    @Bind(R.id.swipe_refresh_layout)
    SwipeRefreshLayout swipeRefreshLayout;

    private OrderListAdapter orderListAdapter;
    private View listFooter;


    private int roleType = 1;
    private String filter = "";
    private int currentPage = 0;
    private int PAGE_SIZE = 10;
    private boolean isLoading = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_order_search_result);
        ButterKnife.bind(this);

        String roleTypeString = getIntent().getStringExtra("type");
        roleType = Integer.parseInt(roleTypeString);

        if (roleType == ROLE_TYPE_BUY) {
            filter = "buyer_id=" + Helper.sharedHelper().getUserId();
        } else if (roleType == ROLE_TYPE_SELL) {
            filter = "seller_id=" + Helper.sharedHelper().getUserId();
        }

        initComponent();
    }

    private void initComponent() {
        backKey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doOrderSearch(true);
            }
        });

        cellStatusLoading.setVisibility(View.GONE);
        orderListAdapter = new OrderListAdapter(this, orderDataList);
        searchResultList.setAdapter(orderListAdapter);

        searchResultList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {

                        doOrderSearch(false);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

        swipeRefreshLayout.setOnRefreshListener(this);
        listFooter = getLayoutInflater().inflate(R.layout.view_list_footer, null);
        listFooter.setVisibility(View.GONE);
        searchResultList.addFooterView(listFooter);
    }

    void doOrderSearch(boolean freshLoad) {
        if (isLoading) {
            return;
        }
        if (TextUtils.isEmpty(searchKeyword.getText())) {
            MessageUtils.showToast(R.string.no_such_orders);
            return;
        }
        if (!Helper.isNetworkConnected(this)) {
            showStatusErrorNetwork(swipeRefreshLayout);
            return;
        }
        if (freshLoad) {
            orderDataList.clear();
            currentPage = 0;
            cellStatusLoading.setVisibility(View.VISIBLE);
        } else {
            listFooter.setVisibility(View.VISIBLE);
        }

        JSONObject params = new JSONObject();

        params.put(TAG_SEARCH_KEYWORD, String.format(keywordFormat, searchKeyword.getText()));
        params.put(TAG_SEARCH_SORT, "create_time");
        params.put(TAG_SEARCH_OFFSET, currentPage * PAGE_SIZE);
        params.put(TAG_SEARCH_PAGESIZE, PAGE_SIZE);
        params.put(TAG_SEARCH_TYPE, "5");
        params.put(TAG_SEARCH_FILTER, filter);
        params.put(TAG_TYPE, roleType);

        isLoading = true;
        HttpClient.get("1.0/search/order", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                isLoading = false;
                try {
                    if (result.containsKey("orders")) {
                        orderDataList.addAll(JSON.parseArray(result.getString("orders"),OrderDO.class));
                        currentPage++;
                    } else if (orderDataList.isEmpty()) {
                        showHint(R.string.no_such_orders);
                        return;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                showSearchResult();
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                showStatusErrorServer(swipeRefreshLayout);
            }
        });
    }

    private void showSearchResult() {
        swipeRefreshLayout.setRefreshing(false);
        swipeRefreshLayout.setVisibility(View.VISIBLE);
        hintLayout.setVisibility(View.GONE);
        cellStatusLoading.setVisibility(View.GONE);
        listFooter.setVisibility(View.GONE);
        orderListAdapter.updateData(orderDataList);
    }

    private void showHint(int textResId) {
        swipeRefreshLayout.setRefreshing(false);
        swipeRefreshLayout.setVisibility(View.GONE);
        cellStatusLoading.setVisibility(View.GONE);
        listFooter.setVisibility(View.GONE);
        hintLayout.setVisibility(View.VISIBLE);
        hintMessage.setText(textResId);
    }

    @Override
    public void onRefresh() {
        doOrderSearch(true);
    }
}
