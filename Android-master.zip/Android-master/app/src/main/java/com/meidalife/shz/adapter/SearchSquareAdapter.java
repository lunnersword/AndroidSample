package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 16/1/31.
 */
public class SearchSquareAdapter extends BaseAdapter {
    List<SquareDO> squareDOList = new ArrayList<>();
    LayoutInflater mInflater;

    public SearchSquareAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
    }

    public void setSquareDOList(List<SquareDO> squareDOList) {
        this.squareDOList = squareDOList;
    }

    @Override
    public int getCount() {
        return squareDOList.size();
    }

    @Override
    public Object getItem(int position) {
        return squareDOList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_search_result_square, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.icon = (SimpleDraweeView) convertView.findViewById(R.id.squareIcon);
            viewHolder.name = (TextView) convertView.findViewById(R.id.squareName);
            viewHolder.serviceCount = (TextView) convertView.findViewById(R.id.serviceCount);
            viewHolder.distance = (TextView) convertView.findViewById(R.id.distance);
            viewHolder.squareType = (TextView) convertView.findViewById(R.id.squareType);
            viewHolder.joinStatus = (ImageView) convertView.findViewById(R.id.joinStatus);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        final SquareDO squareDO = squareDOList.get(position);

        viewHolder.name.setText(squareDO.getGeziName());
        if (!TextUtils.isEmpty(squareDO.getGeziPicUrl())) {
            viewHolder.icon.setImageURI(Uri.parse(squareDO.getGeziPicUrl()));
        }
        if (!TextUtils.isEmpty(squareDO.getGeziTypeDesc())) {
            viewHolder.squareType.setVisibility(View.VISIBLE);
            viewHolder.squareType.setText(String.format("[%s]", squareDO.getGeziTypeDesc()));
        } else {
            viewHolder.squareType.setVisibility(View.GONE);
        }
        viewHolder.serviceCount.setText("服务数：" + squareDO.getItemCount());
        viewHolder.distance.setText("距离：" + StrUtil.getDistanceString(squareDO.getGeziDistance()));
        viewHolder.joinStatus.setVisibility(squareDO.isJoined() ? View.VISIBLE : View.GONE);
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("squareindex/" + squareDO.getGeziId());
            }
        });
        return convertView;
    }

    private static class ViewHolder {
        SimpleDraweeView icon;
        TextView name;
        TextView squareType;
        TextView serviceCount;
        TextView distance;
        ImageView joinStatus;
    }
}
