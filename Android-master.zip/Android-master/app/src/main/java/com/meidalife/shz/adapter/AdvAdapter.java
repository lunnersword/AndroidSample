package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.common.util.UriUtil;
import com.meidalife.shz.R;
import com.usepropeller.routable.Router;

/**
 * Created by zuozheng on 15/12/07.
 * 广告adapter
 */
public class AdvAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private JSONArray itemList = new JSONArray();


    public AdvAdapter(Context context) {
        this.mContext = context;
        this.mInflater = LayoutInflater.from(context);
    }

    public void setData(JSONArray itemList) {
        this.itemList = itemList;
    }

    @Override
    public int getCount() {
        return itemList.size();
    }

    @Override
    public Object getItem(int position) {
        return itemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;

        if (convertView == null || convertView.getTag() == null) {
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.adv_card_item, parent, false);
            viewHolder.adTitle = (TextView) convertView.findViewById(R.id.adv_title);
            viewHolder.adSubTitle = (TextView) convertView.findViewById(R.id.adv_sub_title);
            viewHolder.image = (ImageView) convertView.findViewById(R.id.adv_image);
            viewHolder.belt = (TextView) convertView.findViewById(R.id.adv_belt);
            viewHolder.rootView = convertView.findViewById(R.id.adv_root_view);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        if (position < itemList.size()) {
            final JSONObject item = itemList.getJSONObject(position);

            if (position == 0) {
                viewHolder.adTitle.setTextColor(mContext.getResources().getColor(R.color.red_f));
                viewHolder.belt.setBackgroundColor(mContext.getResources().getColor(R.color.red_f));
            } else if (position == 1) {
                viewHolder.adTitle.setTextColor(mContext.getResources().getColor(R.color.yellow_a));
                viewHolder.belt.setBackgroundColor(mContext.getResources().getColor(R.color.yellow_a));
            } else {
                viewHolder.adTitle.setTextColor(mContext.getResources().getColor(R.color.blue_a));
                viewHolder.belt.setBackgroundColor(mContext.getResources().getColor(R.color.blue_a));
            }
            JSONObject json = item.getJSONObject("custom");
            if (json != null) {
                viewHolder.adTitle.setText(json.getString("title"));
                viewHolder.adSubTitle.setText(json.getString("subTitle"));

                if (TextUtils.isEmpty(json.getString("icon"))) {
                    Uri img = new Uri.Builder()
                            .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.avatar)).build();
                    viewHolder.image.setImageURI(img);
                } else {
                    viewHolder.image.setImageURI(Uri.parse(json.getString("icon")));
                }

                viewHolder.belt.setText(json.getString("belt"));
            }

            final String url = item.getString("url");
            viewHolder.rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", url);
                    Router.sharedRouter().open("web", bundle);
                }
            });

            TextPaint tp = viewHolder.adTitle.getPaint();
            tp.setFakeBoldText(true);
        }
        return convertView;
    }

    public static class ViewHolder {
        TextView adTitle;//标题
        TextView adSubTitle;//子标题
        ImageView image;//图片
        TextView belt;
        View rootView;
    }

    ;
}
