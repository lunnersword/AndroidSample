package com.meidalife.shz.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by taber on 15/8/23.
 */
public class ServiceManageAdapter extends BaseAdapter {

    private static final int TYPE_COUNT = 1;

    LayoutInflater mInflater;
    Context mContext;
    ArrayList<ServiceItem> mData;

    private IServiceStatusListener serviceStatusListener;

    public void setServiceStatusListener(IServiceStatusListener serviceStatusListener) {
        this.serviceStatusListener = serviceStatusListener;
    }

    static class ViewHolder {
        @Bind(R.id.textTime)
        TextView textTime;
        @Bind(R.id.textTag)
        TextView textTag;
        @Bind(R.id.textType)
        TextView textType;
        @Bind(R.id.promotionPrice)
        TextView textPrice;
        @Bind(R.id.textViewCount)
        TextView textViewCount;
        @Bind(R.id.textCommentCount)
        TextView textCommentCount;
        @Bind(R.id.textLikeCount)
        TextView textLikeCount;
        @Bind(R.id.textGetOn)
        TextView textGetOn;
        @Bind(R.id.textEdit)
        TextView textEdit;
        @Bind(R.id.textDelete)
        TextView textDelete;
        @Bind(R.id.imageItem)
        SimpleDraweeView imageItem;

        @Bind(R.id.textBeginSell)
        TextView mTextBeginSell;
        @Bind(R.id.textStopSell)
        TextView mTextStopSell;
        @Bind(R.id.splitLine)
        View mSplitLine;

        @Bind(R.id.oriPrice)
        TextView oriPrice;

        @Bind(R.id.promotionNum)
        TextView promotionNum;

        @Bind(R.id.sellCount)
        TextView sellCount;
        @Bind(R.id.catName)
        TextView catName;


        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }

    public ServiceManageAdapter(Context context, ArrayList<ServiceItem> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    public void addAll(ArrayList<ServiceItem> items) {
        mData.addAll(items);
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public ServiceItem getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ServiceItem item = mData.get(position);
        final String itemId = item.getItemId();
        final String geziFeeRateUrl = item.getGeziFeeRateUrl();
        convertView = genViewHolder(convertView, parent);
        ViewHolder holder = (ViewHolder) convertView.getTag();

        Date date = new Date(item.getUpdateTime());
        SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        holder.textTime.setText(sdformat.format(date));

        //显示所属类目
        if(TextUtils.isEmpty(item.getStdCatName())){
            holder.catName.setVisibility(View.GONE);
        }else{
            holder.catName.setVisibility(View.VISIBLE);
            holder.catName.setText(String.format(mContext.getResources().getString(R.string.text_service_publish_category), item.getStdCatName()));
            holder.catName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(TextUtils.isEmpty(geziFeeRateUrl) || !geziFeeRateUrl.startsWith("http://"))
                        return;
                    Bundle bundle = new Bundle();
                    bundle.putString("url", geziFeeRateUrl);
                    Router.sharedRouter().open("web", bundle);
                }
            });
        }

        //显示促销价格
        if (TextUtils.isEmpty(item.getPromotionPrice())) {
            holder.textPrice.setText(item.getPrice());
            holder.oriPrice.setVisibility(View.GONE);
            holder.oriPrice.setText("");
        } else {
            holder.textPrice.setText(item.getPromotionPrice());
            holder.oriPrice.setVisibility(View.VISIBLE);
            holder.oriPrice.setText(item.getPrice());
            holder.oriPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
        }
        //显示剩余数量
        if (item.getPromotionNum() > 0) {
            holder.promotionNum.setText("剩余（" + item.getPromotionNum() + "单）");
            holder.promotionNum.setVisibility(View.VISIBLE);
        } else {
            holder.promotionNum.setText("");
            holder.promotionNum.setVisibility(View.GONE);
        }

        holder.sellCount.setText("销量：" + item.getSellCount());

        holder.textTag.setText(mContext.getResources().getString(R.string.label_i_can) + " " + item.getTag());

        Uri imageUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getImages().get(0), holder.imageItem.getLayoutParams().width));
        holder.imageItem.setImageURI(imageUri);

        boolean verifyFail = item.getStatus() == 2 && Helper.sharedHelper().hasToken() &&
                Helper.sharedHelper().getUserId().equals(item.getUserId().toString()) ? true : false;
        if (verifyFail) {
            holder.textType.setText("审核未通过");
        } else if (item.getStatus() == 3) {
            holder.textType.setText("已下架");
        } else {
            switch (item.getServiceType()) {
                case 1:
                    holder.textType.setText("上门");
                    break;
                case 2:
                    holder.textType.setText("到店");
                    break;
                case 3:
                    holder.textType.setText("线上");
                    break;
                case 4:
                    holder.textType.setText("邮寄");
                    break;
            }
        }

        if (item.getStatus() == 1) {
            //服务处于上架状态
            holder.textGetOn.setVisibility(View.VISIBLE);
            holder.mSplitLine.setVisibility(View.VISIBLE);

            holder.mTextStopSell.setVisibility(View.VISIBLE);
            holder.mTextBeginSell.setVisibility(View.GONE);
        } else if (item.getStatus() == 3) {
            //服务处于下架状态
            holder.textGetOn.setVisibility(View.GONE);
            holder.mSplitLine.setVisibility(View.GONE);

            holder.mTextStopSell.setVisibility(View.GONE);
            holder.mTextBeginSell.setVisibility(View.VISIBLE);
        } else if (item.getStatus() == 2) {
            //status=2 审核未通过情况下 隐藏上头条和下架
            holder.textGetOn.setVisibility(View.GONE);
            holder.mSplitLine.setVisibility(View.GONE);

            holder.mTextStopSell.setVisibility(View.GONE);
            holder.mTextBeginSell.setVisibility(View.GONE);
        } else {
            //status=0 为审核状态 todo 方便测试 需要产品定规则
            holder.textGetOn.setVisibility(View.VISIBLE);
            holder.mSplitLine.setVisibility(View.VISIBLE);

            holder.mTextStopSell.setVisibility(View.VISIBLE);
            holder.mTextBeginSell.setVisibility(View.GONE);
        }


        holder.textLikeCount.setText(item.getLikeCount() + " 收藏");
        holder.textCommentCount.setText(item.getCommentCount() + " 评论");
        holder.textViewCount.setText(item.getViewCount() + " 人看过");

        holder.textEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("publish/" + itemId);
            }
        });

        holder.textGetOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceStatusListener.touch(itemId);
            }
        });

        holder.textDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceStatusListener.remove(itemId);
            }
        });

        //点击下架 调用下架接口
        holder.mTextStopSell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceStatusListener.downShelf(itemId);
            }
        });

        //点击上架 调用上架接口
        holder.mTextBeginSell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceStatusListener.upShelf(itemId);
            }
        });


        return convertView;
    }

    private View genViewHolder(View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_service_manage, parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            if (holder == null) {
                return genViewHolder(null, parent);
            }
        }

        return convertView;
    }


    public interface IServiceStatusListener {

        //上头条
        public void touch(String itemId);

        //删除
        public void remove(String itemId);

        //下架
        public void downShelf(String itemId);

        //上架
        public void upShelf(String itemId);

    }
}
