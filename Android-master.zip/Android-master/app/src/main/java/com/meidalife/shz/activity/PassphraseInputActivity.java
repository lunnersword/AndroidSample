package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.view.FontButton;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by shijian on 15/7/15.
 */
public class PassphraseInputActivity extends BaseActivity {

    @Bind(R.id.action_bar_button_right)
    FontButton rightButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.passphrase_input);
        ButterKnife.bind(this);
        initActionBar(R.string.title_mcoin_passphrase, true);

        if (!Helper.sharedHelper().hasToken()) {
            Helper.sharedHelper().jumpToLogin("passphrase_input", PassphraseInputActivity.this);
        }

        String code = "";
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.get("code") != null) {
            code = extras.getString("code");
        }

        final EditText passphraseInput = (EditText) findViewById(R.id.passphrase_input_text);
        TextView passphraseCommit = (TextView) findViewById(R.id.passphrase_input_commit);
        passphraseCommit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = passphraseInput.getText().toString();
                if (StrUtil.isEmpty(code)) {
                    MessageUtils.showToastCenter("请输入口令");
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putString("code", code);
                Router.sharedRouter().openFormResult("passphrase_res", bundle, PassphraseInputActivity.this);
            }
        });
        passphraseInput.setText(code);


        /*
        三个分享渠道
         */

        View shareArea = findViewById(R.id.share_invite);
        shareArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("share_invite");
            }
        });

        View shareWx = findViewById(R.id.share_wx);
        shareWx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", "http://www.shenghuozhe.net/support/find_m_coin_password_wechat.html");
                Router.sharedRouter().open("web", bundle);
            }
        });

        View findArea = findViewById(R.id.find_invite);
        findArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", Constant.URL_OFFICIAL_WEIBO);
                Router.sharedRouter().open("web", bundle);
            }
        });


        /*
        排行榜和挖豆攻略
         */

        View mcoinIntro = findViewById(R.id.mcoin_intro);
        mcoinIntro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", Constant.URL_MBILL_RULE);
                Router.sharedRouter().open("web", bundle);

            }
        });

        final TextView mcoinTop = (TextView) findViewById(R.id.mcoin_top);
        mcoinTop.setVisibility(View.INVISIBLE);
        HttpClient.get("1.0/point/pointH5", null, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(final JSONObject obj) {
                mcoinTop.setText(obj.getString("message") + " >");
                final String url = obj.getString("url");
                mcoinTop.setVisibility(View.VISIBLE);
                mcoinTop.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", url);
                        Router.sharedRouter().open("web", bundle);
                    }
                });
            }

            @Override
            public void onFail(HttpError error) {
            }
        });
        rightButton.setVisibility(View.VISIBLE);
        rightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("money_coin_detail/" + MoneyCoinDetailActivity.COIN_TYPE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Helper.ACTIVITY_RESULT_CODE_BACK) {
            setResult(Helper.ACTIVITY_RESULT_CODE_BACK);
            finish();
        }
    }

}
