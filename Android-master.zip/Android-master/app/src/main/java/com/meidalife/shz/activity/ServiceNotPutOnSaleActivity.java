package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;

import com.meidalife.shz.R;
import com.usepropeller.routable.Router;

public class ServiceNotPutOnSaleActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_not_put_on_sale);
        Bundle bundle = getIntent().getExtras();
        String serviceItemId = bundle.getString("itemId");
        boolean bindGezi = bundle.getBoolean("bindGezi", false);
        if (bindGezi) {
            Bundle params = new Bundle();
            params.putString("serviceId", serviceItemId);
            params.putInt("type", ServiceJoinSquareActivity.SERVICE_JOIN_SQUARES);
            Router.sharedRouter().open("serviceJoinSquare", params);
        }
    }


    public void handleComplete(View view) {
        finish();
    }

    public void handleCertificate(View view) {
        Router.sharedRouter().open("certificationlist");
        finish();
    }

    public void handleContinuePublish(View view) {
        Router.sharedRouter().open("publish");
        finish();
    }

}
