package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CityItem;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by taber on 15/6/9.
 */
public class CityAdapter extends BaseAdapter {

    private static final int TYPE_COUNT = 3;
    private CityAdapter.OnClickListener mOnClickCellListener;
    private LayoutInflater mInflater;
    private Context mContext;
    private ArrayList<?> mData;

    static class HeaderViewHolder {
        public TextView textView;
    }

    static class ButtonViewHolder {
        public Button button;
    }

    static class ButtonListViewHolder {
        public GridView gridView;
    }

    public CityAdapter(Context context, ArrayList<?> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    public void setOnClickCellListener(CityAdapter.OnClickListener listener) {
        mOnClickCellListener = listener;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (mData.get(position) instanceof CityItem) {
            CityItem item = (CityItem) mData.get(position);
            switch (item.getType()) {
                case CityItem.CITY_VIEW_TYPE_HEADER:
                    convertView = initHeaderView(convertView, parent, item, position);
                    break;

                case CityItem.CITY_VIEW_TYPE_BUTTON:
                    convertView = initButtonView(convertView, parent, item, position);
                    break;

                case CityItem.CITY_VIEW_TYPE_CELL:
                    convertView = initCellView(convertView, parent, item, position);
                    break;
                default:
            }
        } else {
            ArrayList item = (ArrayList) mData.get(position);
            convertView = initButtonListView(convertView, parent, item, position);
        }

        return convertView;
    }

    private View initHeaderView(View convertView, ViewGroup parent, CityItem data, final int position) {
        convertView = genHeaderView(convertView, parent);
        HashMap tag = (HashMap) convertView.getTag();
        HeaderViewHolder holder = (HeaderViewHolder) tag.get("holder");
        holder.textView.setText(data.getName());
        return convertView;
    }

    private View initButtonView(View convertView, ViewGroup parent, CityItem data, final int position) {
        convertView = genButtonView(convertView, parent);
        HashMap tag = (HashMap) convertView.getTag();
        ButtonViewHolder holder = (ButtonViewHolder) tag.get("holder");
        holder.button.setText(data.getName());
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnClickCellListener != null) {
                    mOnClickCellListener.onClick(v, (CityItem) mData.get(position));
                }
            }
        });
        return convertView;
    }

    private View initCellView(View convertView, ViewGroup parent, CityItem data, final int position) {
        convertView = genCellView(convertView, parent);
        HashMap tag = (HashMap) convertView.getTag();
        ButtonViewHolder holder = (ButtonViewHolder) tag.get("holder");
        holder.button.setText(data.getName());
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnClickCellListener != null) {
                    mOnClickCellListener.onClick(v, (CityItem) mData.get(position));
                }
            }
        });
        return convertView;
    }

    private View initButtonListView(View convertView, ViewGroup parent, ArrayList data, final int position) {
        convertView = genButtonListView(convertView, parent);
        HashMap tag = (HashMap) convertView.getTag();
        ButtonListViewHolder holder = (ButtonListViewHolder) tag.get("holder");
        CityButtonGridAdapter adapter = new CityButtonGridAdapter(mContext, data);
        holder.gridView.setAdapter(adapter);
        adapter.setOnClickCellListener(new CityAdapter.OnClickListener() {
            public void onClick(View v, CityItem item) {
                if (mOnClickCellListener != null) {
                    mOnClickCellListener.onClick(v, item);
                }
            }
        });
        return convertView;
    }

    private View genHeaderView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.city_header, parent, false);
            HeaderViewHolder holder = new HeaderViewHolder();
            holder.textView = (TextView) convertView.findViewById(R.id.cityItemHeader);
            HashMap tag = new HashMap();
            tag.put("type", CityItem.CITY_VIEW_TYPE_HEADER);
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != CityItem.CITY_VIEW_TYPE_HEADER) {
                return genHeaderView(null, parent);
            }
        }
        return convertView;
    }

    private View genButtonView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.city_button, parent, false);
            ButtonViewHolder holder = new ButtonViewHolder();
            holder.button = (Button) convertView.findViewById(R.id.cityButton);
            HashMap tag = new HashMap();
            tag.put("type", CityItem.CITY_VIEW_TYPE_BUTTON);
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != CityItem.CITY_VIEW_TYPE_BUTTON) {
                return genButtonView(null, parent);
            }
        }
        return convertView;
    }

    private View genCellView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.city_cell, parent, false);
            ButtonViewHolder holder = new ButtonViewHolder();
            holder.button = (Button) convertView.findViewById(R.id.cityButton);
            HashMap tag = new HashMap();
            tag.put("type", CityItem.CITY_VIEW_TYPE_CELL);
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != CityItem.CITY_VIEW_TYPE_CELL) {
                return genCellView(null, parent);
            }
        }
        return convertView;
    }

    private View genButtonListView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.city_button_list, parent, false);
            ButtonListViewHolder holder = new ButtonListViewHolder();
            holder.gridView = (GridView) convertView.findViewById(R.id.buttonList);
            HashMap tag = new HashMap();
            tag.put("type", CityItem.CITY_VIEW_TYPE_LIST_BUTTON);
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != CityItem.CITY_VIEW_TYPE_LIST_BUTTON) {
                return genButtonListView(null, parent);
            }
        }
        return convertView;
    }

    public interface OnClickListener {
        void onClick(View v, CityItem item);
    }
}
