package com.meidalife.shz.im.task;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.BuildConfig;
import com.meidalife.shz.Helper;
import com.meidalife.shz.db.DaoSession;
import com.meidalife.shz.db.DatabaseManager;
import com.meidalife.shz.db.ImNotifyMsg;
import com.meidalife.shz.db.ImNotifyMsgDao;
import com.meidalife.shz.db.ImServer;
import com.meidalife.shz.im.ImConfig;
import com.meidalife.shz.im.ImMessageType;
import com.meidalife.shz.im.SocketManger;
import com.meidalife.shz.im.protos.NotificationProtos;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 15/12/7.
 */
public class ImReceiveTask implements Runnable {
    private static final String LOG_TAG = "ImReceiveTask";
    private Handler mHandler;
    private boolean isRunning = true;
    private ImConfig config;
    private DaoSession daoSession;

    public ImReceiveTask(ImConfig config, Handler handler) {
        mHandler = handler;
        this.config = config;
    }

    public void stop() {
        isRunning = false;
    }

    public boolean isRunning() {
        return isRunning;
    }

    @Override
    public void run() {
        Log.d(LOG_TAG, "Receive task start.");
        daoSession = DatabaseManager.getInstance().getDaoSession();
        while (isRunning) {
            Message message = new Message();
            try {
                NotificationProtos.C2SMessage c2SMessage = readC2SMessage();
                if (BuildConfig.DEBUG) {
                    Log.d(LOG_TAG, "Receive task get new message:" + c2SMessage);
                }
                message.what = ImMessageType.TYPE_RECEIVE_MESSAGE_SUCCESS.value;
                if (c2SMessage.hasNotifyList()) {
                    message.obj = removeDuplicateMessage(c2SMessage);
                    if (BuildConfig.DEBUG) {
                        Log.d(LOG_TAG, "Removed dup new message:" + message.obj);
                    }
                    removeDuplicateMessage(c2SMessage);
                    Helper.sharedHelper().setLongUserInfo(ImConfig.TAG_BROADCAST_MAX_ID, c2SMessage.getBroadcastMaxId());
                    Helper.sharedHelper().setLongUserInfo(ImConfig.TAG_UNICAST_MAX_ID, c2SMessage.getUnicastMaxId());
                } else {
                    message.obj = c2SMessage;
                }

            } catch (IOException e) {
                Log.d(LOG_TAG, "Receive task error." + SocketManger.getInstance().isClosed(), e);
                if (SocketManger.getInstance().isClosed()) {
                    isRunning = false;
                    message.what = ImMessageType.TYPE_SOCKET_CLOSE.value;
                    break;
                } else {
                    connect();
                }
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            } catch (Throwable e) {
                Log.d(LOG_TAG, "Receive task error.", e);
                if (SocketManger.getInstance().isClosed()) {
                    isRunning = false;
                    message.what = ImMessageType.TYPE_SOCKET_CLOSE.value;
                    break;
                }
            } finally {
                mHandler.sendMessage(message);
            }
        }
    }

    private NotificationProtos.C2SMessage removeDuplicateMessage(NotificationProtos.C2SMessage c2SMessage) {
        if (BuildConfig.DEBUG) {
            Log.d(LOG_TAG, "Receive task removeDuplicateMessage.1" + c2SMessage);
        }
        if (!c2SMessage.hasNotifyList()) {
            return c2SMessage;
        }
        List<NotificationProtos.NotifyMsg> list = c2SMessage.getNotifyList().getNotifyMsgList();

        NotificationProtos.NotifyList.Builder notifyListBuilder = NotificationProtos.NotifyList.newBuilder();
        if (BuildConfig.DEBUG) {
            Log.d(LOG_TAG, "Receive task removeDuplicateMessage.2:" + list.isEmpty());
        }
        for (NotificationProtos.NotifyMsg msg : list) {
            JSONObject jsonContext = JSONObject.parseObject(msg.getNotifyContext());
            Log.d(LOG_TAG, "Receive task jsonContext=" + jsonContext);
            if (null != jsonContext && jsonContext.containsKey("body")) {
                //JSONObject bodyJson = jsonContext.getJSONObject("body");
                JSONObject extraJson = jsonContext.getJSONObject("extra");
                if (BuildConfig.DEBUG) {
                    Log.d(LOG_TAG, "Receive task bodyJson=" + extraJson);
                }
                long messageId = extraJson.getLongValue("message_id");
                List<ImNotifyMsg> imNotifyList = daoSession.getImNotifyMsgDao().queryBuilder().
                        where(ImNotifyMsgDao.Properties.MessageId.eq(messageId)).build().list();

                if (null == imNotifyList || imNotifyList.isEmpty()) {
                    ImNotifyMsg notifyMsg = new ImNotifyMsg();
                    notifyMsg.setMessageId(messageId);
                    Log.d(LOG_TAG, "Receive task not exist messageId=" + String.valueOf(messageId));
                    notifyListBuilder.addNotifyMsg(msg);
                } else {
                    for (ImNotifyMsg imNotifyMsg : imNotifyList) {
                        Log.d(LOG_TAG, "Receive task exist removed messageId=" + messageId);
                    }
                }
            }
        }
        return NotificationProtos.C2SMessage.newBuilder().setMethodType(c2SMessage.getMethodType())
                .setUnicastMaxId(c2SMessage.getUnicastMaxId()).setNotifyList(notifyListBuilder.build())
                .setBroadcastMaxId(c2SMessage.getBroadcastMaxId()).build();
    }

    private NotificationProtos.C2SMessage readC2SMessage() throws IOException {
        Log.d(LOG_TAG, "readC2SMessage");
        int length = 0;
        DataInputStream dataInputStream = new DataInputStream(SocketManger.getInstance().getSocket().getInputStream());
        length = dataInputStream.readInt() - 4;

        Log.d(LOG_TAG, "Receive task data:length = " + length);
        if (length > 0) {
            byte[] bytes = new byte[length];
            dataInputStream.read(bytes);
            return NotificationProtos.C2SMessage.parseFrom(bytes);
        } else {
            return NotificationProtos.C2SMessage.
                    parseFrom(SocketManger.getInstance().getSocket().getInputStream());
        }
    }

    private void connect() {
        Log.d(LOG_TAG, "Receive task connecting.");
        for (ImServer server : config.getServerList()) {
            InetSocketAddress address;
            address = new InetSocketAddress(server.getAddress(), server.getPort());
            Log.d(LOG_TAG, "Receive task connect " + address.toString());
            try {
                SocketManger.getInstance().connect(address, config.getSocketTimeout());
                break;
            } catch (IOException e) {
                e.printStackTrace();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }
}
