package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.BaseActivity;
import com.meidalife.shz.adapter.CommentAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CommentDO;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.StrUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 已合并到TradeAndCommentListActivity.java  后期确认无用可删除此类
 * Created by fufeng on 15/10/23.
 */
@Deprecated
public class CommentListFragment extends BaseFragment implements SwipeRefreshLayout.OnRefreshListener {
    private static final int PAGE_SIZE = 10;
    private boolean isLoading = false;
    private int currentPage = 0;
    private long itemId;

    @Bind(android.R.id.list)
    ListView mListView;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.emptyView)
    ViewGroup emptyView;
    @Bind(R.id.description)
    TextView description;
    @Bind(R.id.cellStatusErrorServer)
    ViewGroup cellStatusErrorServer;
    @Bind(R.id.cellStatusErrorNetwork)
    ViewGroup cellStatusErrorNetwork;

    private CommentAdapter commentAdapter;
    private List<CommentDO> commentList = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list, container, false);
        ButterKnife.bind(this, view);
        commentAdapter = new CommentAdapter(getActivity(), inflater, commentList);
        itemId = getArguments().getLong("itemId");
        commentAdapter = new CommentAdapter(getActivity(), commentList);

        mListView.setAdapter(commentAdapter);
        description.setText(R.string.comment_count_none);

        mSwipeRefreshLayout.setOnRefreshListener(this);
        mListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        loadComments();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });
        loadComments();
        return view;
    }

    public void loadComments() {
        if (!Helper.isNetworkConnected(getActivity())) {
            showNetWorkError();
            return;
        }
        isLoading = true;
        JSONObject params = new JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", PAGE_SIZE);
        params.put("offset", currentPage * PAGE_SIZE);
        params.put("typeList", "1,3");
        HttpClient.get("1.0/comment/getComment", params, CommentDO.class, new HttpClient.HttpCallback<List<CommentDO>>() {
            @Override
            public void onSuccess(List<CommentDO> dataList) {
                isLoading = false;
                mSwipeRefreshLayout.setRefreshing(false);
                commentList.addAll(dataList);

                if (!commentList.isEmpty()) {
                    commentAdapter.set(commentList);
                    commentAdapter.notifyDataSetChanged();
                    currentPage++;
                } else {
                    showEmptyView();
                }
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                mSwipeRefreshLayout.setRefreshing(false);
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showNetWorkError();
                } else {
                    showServerError();
                }
            }
        });
    }

    @Override
    public void onRefresh() {
        currentPage = 0;
        commentList.clear();
        loadComments();
    }

    private void showNetWorkError() {
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.VISIBLE);
        mSwipeRefreshLayout.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
    }

    private void showServerError() {
        cellStatusErrorServer.setVisibility(View.VISIBLE);
        cellStatusErrorNetwork.setVisibility(View.GONE);
        mSwipeRefreshLayout.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
    }

    private void showEmptyView() {
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.GONE);
        mSwipeRefreshLayout.setVisibility(View.GONE);
        emptyView.setVisibility(View.VISIBLE);
    }
}
