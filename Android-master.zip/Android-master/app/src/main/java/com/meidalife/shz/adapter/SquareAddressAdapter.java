package com.meidalife.shz.adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.rest.model.SquareAddressOutDO;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class SquareAddressAdapter extends BaseAdapter {

    private List<SquareAddressOutDO> mData;
    //    private ItemClick mItemClickListener;
    private boolean mIsShowSelected = false;
    private int currentPosition = 0;
    private Context mContext;

    static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }


        @Bind(R.id.squareName)
        TextView squareName;
        @Bind(R.id.squareType)
        TextView squareType;
        @Bind(R.id.addressName)
        TextView addressName;
        @Bind(R.id.distance)
        TextView distance;

        @Bind(R.id.address_used)
        TextView address_used;


        @Bind(R.id.rootView)
        View rootView;
    }

    public SquareAddressAdapter(Context context, List<SquareAddressOutDO> data) {
        this.mContext = context;
        mData = data;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(SHZApplication.getInstance());
            convertView = inflater.inflate(R.layout.item_square_address, null);

//            ViewHolder holder = new ViewHolder(convertView);

            convertView.setTag(new ViewHolder(convertView));
        }

        ViewHolder holder = (ViewHolder) convertView.getTag();

        SquareAddressOutDO mAddress = mData.get(position);

        holder.squareName.setText(mAddress.getName());
        holder.squareType.setText(mAddress.getGeziTypeDesc());
        holder.addressName.setText(mAddress.getAddress());
        holder.distance.setText(mAddress.getDistance());


        if (mAddress.isCreated()) {
            holder.rootView.setEnabled(false);
            holder.address_used.setVisibility(View.VISIBLE);
            holder.rootView.setBackgroundColor(mContext.getResources().getColor(R.color.grey_m));
        } else {
            holder.rootView.setEnabled(true);
            holder.address_used.setVisibility(View.INVISIBLE);
            holder.rootView.setBackgroundColor(mContext.getResources().getColor(R.color.gezi_title_white));
        }

        if (mAddress.isSelected()) {
            holder.rootView.setBackgroundColor(mContext.getResources().getColor(R.color.square_i_want_title));
        } else {
            holder.rootView.setBackgroundColor(mContext.getResources().getColor(R.color.gezi_title_white));
        }

        return convertView;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public SquareAddressOutDO getItem(int position) {
        return mData.get(position);
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    public void clear() {
        mData.clear();
        notifyDataSetChanged();
    }

    public void setCurrentPosition(int position) {
        currentPosition = position;
    }

}

