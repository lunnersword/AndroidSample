package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.MDMyLotteryListAdapter;
import com.meidalife.shz.event.LotteryListRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.request.RequestLotteryList;
import com.meidalife.shz.util.CountDownTimerUtils;
import com.meidalife.shz.util.LoadUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by liujian on 16/1/20.
 */
public class MDMyLotteryListFragment extends Fragment{
    private View rootView;
    private int type;
    private LoadUtil mLoadUtil;
    private boolean isLoading;
    private final int pageSize = 20;
    private int page;
    private boolean isComplete;
    private List<RequestLotteryList.LotteryOrder> orders;
    private MDMyLotteryListAdapter mdMyLotteryListAdapter;
    private boolean dataChange = false;

    @Bind(R.id.emptyView)
    View emptyView;
    @Bind(R.id.lotteryList)
    ListView lotteryList;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.emptyViewText)
    TextView emptyViewText;
    public static MDMyLotteryListFragment newInstance(Bundle bundle){
        MDMyLotteryListFragment mdMyLotteryListFragment = new MDMyLotteryListFragment();
        mdMyLotteryListFragment.setArguments(bundle);
        return mdMyLotteryListFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if(rootView == null){
            rootView = inflater.inflate(R.layout.fragment_my_lottery_list,container,false);
            ButterKnife.bind(this, rootView);
            Bundle bundle = getArguments();
            if(bundle != null){
                type = bundle.getInt("type",1);
                if(type == 2){
                    emptyViewText.setText(getResources().getString(R.string.text_empty_win));
                }else if(type == 3){
                    emptyViewText.setText(getResources().getString(R.string.text_empty_nowin));
                }
            }
            mLoadUtil = new LoadUtil(inflater);
            orders = new ArrayList<RequestLotteryList.LotteryOrder>();
            mdMyLotteryListAdapter = new MDMyLotteryListAdapter(getActivity(),orders);
            initListener();
            lotteryList.setAdapter(mdMyLotteryListAdapter);

        }
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initData(true);
    }

    @Override
    public void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
        if(dataChange){
            dataChange = false;
            initData(true);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null)
                parent.removeView(rootView);
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    public void onEvent(LotteryListRefreshEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isLoading) {
            initData(true);
        }
    }

    private void initListener(){
        lotteryList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        initData(false);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
            }
        });
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                initData(true);
            }
        });
        mdMyLotteryListAdapter.setOnDataChangeListener(new MDMyLotteryListAdapter.onDataChangeListener() {
            @Override
            public void onDataChange(boolean isDataChange) {
                dataChange = isDataChange;
            }
        });
    }

    private void initData(final boolean refresh){
        if(isLoading)
            return;
        isLoading = true;
        if(refresh){
            page = 0;
            isComplete = false;
            mLoadUtil.loadPre((ViewGroup) rootView, swipeRefreshLayout);
        }else{
            if(isComplete){
                isLoading = false;
                return;
            }
            page++;
        }
        JSONObject params = new JSONObject();
        params.put("type",type);
        params.put("offset", pageSize * page);
        params.put("pageSize", pageSize);
        RequestLotteryList.getLotteryList(params, new RequestLotteryList.RequestLotteryCallBack() {
            @Override
            public void onSuccess(Object obj) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                mLoadUtil.hideStatusLoading();
                List<RequestLotteryList.LotteryOrder> lottertOrders = (List<RequestLotteryList.LotteryOrder>) obj;
                initCountDownTimer(lottertOrders);
                if (refresh)
                    orders.clear();
                orders.addAll(lottertOrders);
                if (orders.size() == 0) {
                    swipeRefreshLayout.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                    mdMyLotteryListAdapter.notifyDataSetChanged();
                }
                if (lottertOrders.size() < pageSize)
                    isComplete = true;
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                if (!refresh)
                    page--;
                mLoadUtil.loadFail(error, (ViewGroup) rootView, getActivity(), new LoadUtil.LoadCallback() {
                    @Override
                    public void execute() {
                        initData(true);
                    }
                });
            }
        });
    }

    private void initCountDownTimer(List<RequestLotteryList.LotteryOrder> lotteryOrders){
        CountDownTimerUtils.newInstance().clearAllTimer();
        for(RequestLotteryList.LotteryOrder lotteryOrder : lotteryOrders){
            if(lotteryOrder.getStatus() == RequestLotteryList.ORDER_STATUS_ANNOUNCEING){
                CountDownTimerUtils.newInstance().startCountDownTimer(lotteryOrder);
            }
        }
    }
}
