package com.meidalife.shz.event;

import com.meidalife.shz.event.type.MsgTypeEnum;

/**
 *
 */
public class SquarePortalRefreshEvent extends BaseEvent {
    public SquarePortalRefreshEvent() {
        super(MsgTypeEnum.TYPE_REFRESH);
    }
}
