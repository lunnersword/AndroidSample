package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.usepropeller.routable.Router;

/**
 * Created by shijian on 15/7/7.
 */
public class MoneyWholeActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.money_whole_info);
        initActionBar(R.string.title_money_whole, true);

        if (!Helper.sharedHelper().hasToken()) {
            Bundle bundle = new Bundle();
            bundle.putString("action", "profile_money");
            Router.sharedRouter().open("signin", bundle);
            finish();
        }

        Bundle extras = getIntent().getExtras();
        String sumValue = extras.getString("sum");
        TextView moneyTotalNum = (TextView) findViewById(R.id.money_total_num);
        moneyTotalNum.setText(sumValue + " 元");

        TextView moneyDetailIcon = (TextView) findViewById(R.id.money_detail_icon);
        moneyDetailIcon.setTypeface(Helper.sharedHelper().getIconFont());
        TextView withdrawIcon = (TextView) findViewById(R.id.money_withdraw_entry);
        withdrawIcon.setTypeface(Helper.sharedHelper().getIconFont());
        TextView withdrawLogIcon = (TextView) findViewById(R.id.money_withdraw_log_entry);
        withdrawLogIcon.setTypeface(Helper.sharedHelper().getIconFont());

        View moneyDetail = findViewById(R.id.money_detail);
        moneyDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("money_coin_detail/" + MoneyCoinDetailActivity.MONEY_TYPE);
            }
        });

        View withdraw = findViewById(R.id.money_withdraw);
        withdraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("money_withdraw");
            }
        });

        View withdrawLog = findViewById(R.id.money_withdraw_log);
        withdrawLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("withdraw_log");
            }
        });
    }
}
