package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.CategoryFilterEvent;
import com.meidalife.shz.event.EventSender;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.CategoryDO;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestService;
import com.meidalife.shz.util.StrUtil;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

public class CategoryFragment extends BaseFragment {


    private String title;

    private Context context;
    private boolean isLoad;
    private boolean isComplete;
    private int page = 0;
    private int catId = Integer.MAX_VALUE;
    private int tabId = Integer.MAX_VALUE;
    private int stdCatId = Integer.MAX_VALUE;
    private boolean needPOI = false;
    private boolean isRefresh = false;

    private ArrayList<ServiceItem> listData;
    private ServicesAdapter adapter;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    private View listFooter;
    @Bind(R.id.listView)
    ListView listView;
    private TextView footerMessage;
    private View rootView;
    private ProgressBar footerLoading;
    private Button footerReload;
    @Bind(R.id.textStatusErrorServer)
    TextView textStatusErrorServer;
    @Bind(R.id.cellStatusLoading)
    LinearLayout cellStatusLoading;
    @Bind(R.id.cellStatusErrorNetwork)
    LinearLayout cellStatusErrorNetwork;
    @Bind(R.id.cellStatusErrorServer)
    LinearLayout cellStatusErrorServer;
    @Bind(R.id.noDataLayout)
    ViewGroup noDataLayout;
    private AnimationDrawable loadingAnimation;

    @Bind(R.id.nearByHintLayout)
    LinearLayout nearByHintLayout;
    @Bind(R.id.nearbyHintLabel)
    TextView nearbyHintLabel;
    Boolean hasInitData = false;

    public static CategoryFragment newInstance(CategoryDO categoryDO) {
        CategoryFragment categoryFragment = new CategoryFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("catId", categoryDO.getCatId());
        bundle.putString("title", categoryDO.getCatName());
        bundle.putInt("tabId", categoryDO.getTabId());
        bundle.putBoolean("needPOI", categoryDO.isNeedPoi());
        categoryFragment.setArguments(bundle);
        categoryFragment.title = categoryDO.getCatName();
        return categoryFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            Bundle args = getArguments();
            if (args != null) catId = args.getInt("catId", Integer.MAX_VALUE);
            if (args != null) tabId = args.getInt("tabId", Integer.MAX_VALUE);
            if (args != null) stdCatId = args.getInt("stdCatId", Integer.MAX_VALUE);
            if (args != null) needPOI = args.getBoolean("needPOI", false);
            rootView = inflater.inflate(R.layout.item_home, container, false);
            context = getActivity();

            ButterKnife.bind(this, rootView);

            listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
            footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
            footerMessage = (TextView) listFooter.findViewById(R.id.message);
            footerReload = (Button) listFooter.findViewById(R.id.footerReload);

            listView.addFooterView(listFooter);
            listFooter.setVisibility(View.GONE);
            mSwipeRefreshLayout.setVisibility(View.GONE);
            showStatusLoading();

            page = 0;
            listData = new ArrayList<ServiceItem>();
            isComplete = false;
            isLoad = false;
            adapter = new ServicesAdapter(getActivity(), listData);

            initListener();
            mSwipeRefreshLayout.setEnabled(false);
        }
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (!hasInitData) {
            refreshList();
            hasInitData = true;
        }
    }

    public void onEvent(BaseEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isRefresh) {
            showStatusLoading();
            if (event instanceof CategoryFilterEvent)
                stdCatId = ((CategoryFilterEvent) event).getStdCatId();
            refreshList();
        }
    }

    @Override
    public void onDestroyView() {
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("HomeScreen");

        LogUtil.log(LogUtil.TYPE_START_PAGE, this.getClass().getName(), catId);
        EventBus.getDefault().register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("HomeScreen");
        LogUtil.log(LogUtil.TYPE_EXIT_PAGE, this.getClass().getName());
        EventBus.getDefault().unregister(this);
    }

    private void initListener() {
        cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStatusLoading();
                refreshList();
            }
        });
        cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStatusLoading();
                refreshList();
            }
        });
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            private boolean moveToBottom = false;
            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                BaseEvent message = new BaseEvent();
                final View topChildView = listView.getChildAt(0);
                if (scrollState == SCROLL_STATE_IDLE && listView.getFirstVisiblePosition() == 0
                        && topChildView.getTop() == 0) {
                    message.eventType = MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                } else {
                    message.eventType = MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE;
                    EventBus.getDefault().post(message);
                }

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        loadList();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                //EventBus.getDefault().post(AttachUtil.isAdapterViewAttach(view));
            }
        });

        listView.setAdapter(adapter);
    }

    private void refreshList() {
        cellStatusErrorNetwork.setVisibility(View.GONE);
        cellStatusErrorServer.setVisibility(View.GONE);

        Log.d("myThisLog: ", title + " | " + tabId + " | " + needPOI);
        if (needPOI && !checkLocationSetting() && !isRefresh) {
            hideStatusLoading();
            return;
        }
        isRefresh = true;
        page = 0;
        isComplete = false;

        RequestService.list(getParams(page), new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                isRefresh = false;
                hideStatusLoading();

                ArrayList<ServiceItem> resData = (ArrayList<ServiceItem>) result;
                if (resData.size() == 0) {
                    mSwipeRefreshLayout.setVisibility(View.GONE);
                    noDataLayout.setVisibility(View.VISIBLE);
                } else {
                    listData.clear();
                    listData.addAll(resData);
                    mSwipeRefreshLayout.setVisibility(View.VISIBLE);
                    adapter.notifyDataSetChanged();
                    noDataLayout.setVisibility(View.GONE);
                }

                if (listData.size() < 20) {
                    isComplete = true;
                    listView.removeFooterView(listFooter);
                }

            }

            @Override
            public void onFailure(HttpError error) {
                isRefresh = false;
                mSwipeRefreshLayout.setVisibility(View.GONE);
                hideStatusLoading();

                if (listData.size() > 0) {
                    listData.clear();
                }
                adapter.notifyDataSetChanged();

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    cellStatusErrorNetwork.setVisibility(View.VISIBLE);
                    return;
                }
                if (!TextUtils.isEmpty(error.getMessage())) {
                    textStatusErrorServer.setText(error.getMessage());
                }
                cellStatusErrorServer.setVisibility(View.VISIBLE);
            }
        });
    }

    private boolean checkLocationSetting() {
        try {
            String locateCode = SHZApplication.getInstance().getLocationManager().getLocation().getCityCode();
            String selectCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
            if (Helper.isLocationEnabled(getActivity())) {
                if (!TextUtils.isEmpty(locateCode) && (locateCode.equals(selectCode) || TextUtils.isEmpty(selectCode))) {
                    nearByHintLayout.setVisibility(View.GONE);
                    return true;
                } else {
                    nearByHintLayout.setVisibility(View.VISIBLE);
                    nearbyHintLabel.setText("选择城市和定位所在城市不一致，无法显示哦");
                    return false;
                }
            } else {
                nearByHintLayout.setVisibility(View.VISIBLE);
                nearbyHintLabel.setText("未开启定位，点击设置");
                nearByHintLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (Helper.isLocationEnabled(getActivity())) {
                            refreshList();
                        } else {
                            Helper.openLocationSetting(getActivity());
                        }
                    }
                });
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    private void loadList() {
        if (!isLoad && !isComplete) {
            footerMessage.setText("正在加载");
            listFooter.setVisibility(View.VISIBLE);
            footerLoading.setVisibility(View.VISIBLE);
            footerMessage.setVisibility(View.VISIBLE);
            footerReload.setVisibility(View.GONE);
            isLoad = true;
            page++;
            RequestService.list(getParams(page), new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    ArrayList<ServiceItem> resData = (ArrayList<ServiceItem>) result;

                    listData.addAll(resData);
                    adapter.notifyDataSetChanged();
                    // 其它处理
                    isLoad = false;
                    isComplete = resData.size() < 20;
                    listFooter.setVisibility(View.GONE);
                    if (isComplete) {
                        listView.removeFooterView(listFooter);
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    page--;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);

                    listFooter.setVisibility(View.GONE);
                }
            });
        }
    }

    private JSONObject getParams(int page) {
        JSONObject params;
        try {
            params = new JSONObject();
            LocationDO location = SHZApplication.getInstance().getLocationManager().getLocation();
            params.put("longitude", String.valueOf(location.getLongitude()));
            params.put("latitude", String.valueOf(location.getLatitude()));
            String locateCode = location.getCityCode();
            String selectCode = Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE);
            params.put("cityCode", StrUtil.isEmpty(selectCode) ? locateCode : selectCode);  // 优先用户选择，其次自动定位
            params.put("pageSize", 20);
            params.put("offset", page * 20);
            if (Integer.MAX_VALUE != catId) {
                params.put("catId", catId);
            }
            if (Integer.MAX_VALUE != tabId) {
                params.put("tabId", tabId);
            }
            if (Integer.MAX_VALUE != stdCatId) {
                params.put("stdCatId", stdCatId);
            }
        } catch (JSONException e) {
            params = null;
        }

        return params;
    }

    private void showStatusLoading() {
        try {
            cellStatusLoading.setVisibility(View.VISIBLE);
            loadingAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.loading_animation);
            ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
            loadingImage.setBackgroundDrawable(loadingAnimation);
            loadingAnimation.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideStatusLoading() {
        try {
            if (cellStatusLoading != null) {
                cellStatusLoading.setVisibility(View.GONE);
                if (loadingAnimation != null) {
                    loadingAnimation.stop();
                    loadingAnimation = null;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}