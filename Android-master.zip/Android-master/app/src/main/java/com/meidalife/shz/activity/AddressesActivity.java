package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.AddressAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.request.RequestAddress;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

/**
 * 此AddressesActivity 为下单选择地址界面
 */
public class AddressesActivity extends BaseActivity {

    ListView listView;
    //需保证改变显示选择项 和 实际选择的同步 selectedIndex保存的为实际选择项
    int selectedIndex;
    ArrayList addresses;
    AddressAdapter adapter;
    LinearLayout rootView;

    //保存退出再进入的选择项
    private int lastSelectIndex = -1;
    //是否是新创建后进入选择页
    boolean isFromCreateAddress = false;
    int createCount = 0;

    final int REQUEST_CODE_SIGNIN = 300;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addresses);
        initActionBar(R.string.title_activity_addresses, true, true);

        if (null != getIntent().getExtras()) {
            lastSelectIndex = getIntent().getExtras().getInt("lastSelectIndex");
        }

        mButtonRight.setText("确定");
        mButtonRight.setEnabled(false);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddressItem item = (AddressItem) addresses.get(selectedIndex);
                Intent intent = new Intent();
                Bundle bundle = new Bundle();

                bundle.putInt("lastSelectIndex", selectedIndex);
                bundle.putSerializable(Constant.EXTRA_TAG_ADDRESS, item);
                intent.putExtras(bundle);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        mButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backEvent();
            }
        });

        addresses = new ArrayList();
        listView = (ListView) findViewById(R.id.addresses);
        rootView = (LinearLayout) findViewById(R.id.root_view);
        adapter = new AddressAdapter(this, addresses);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position > 1) {
                    view.setSelected(true);
                    selectedIndex = position - 2;
                } else if (position == 0) {
                    Router.sharedRouter().openFormResult("addresses/create",
                            Constant.REQUEST_CODE_CREATE_ADDRESS, AddressesActivity.this);
                }
            }
        });

        xhrAddresses();
    }

    private void backEvent() {
        Intent intent = new Intent();
        Bundle bundle = new Bundle();

        //上次选择可能随着增加地址后位置会偏移
        if (lastSelectIndex != -1) {

            if (isFromCreateAddress) {
                bundle.putInt("lastSelectIndex", createCount + lastSelectIndex);
            } else {
                bundle.putInt("lastSelectIndex", lastSelectIndex);
            }

        } else {
            bundle.putInt("lastSelectIndex", -1);
        }
        intent.putExtras(bundle);
        setResult(RESULT_CANCELED, intent);
        finish();
    }

    @Override
    public void onResume() {
        super.onResume();
        setSelected();
    }

    private void xhrAddresses() {
        showStatusLoading(rootView);
        hideStatusErrorServer();
        hideStatusErrorNetwork();

        RequestAddress.getAddresses(new HttpClient.HttpCallback<List<AddressItem>>() {
            @Override
            public void onSuccess(List<AddressItem> result) {
                hideStatusLoading();
                listView.setVisibility(View.VISIBLE);
                addresses.clear();
                addresses.addAll(result);
                adapter.notifyDataSetChanged();
                if (addresses.size() > 0) {
                    mButtonRight.setEnabled(true);
                }
                setSelected();
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrAddresses();
                        }
                    });
                } else {
                    showStatusErrorServer(rootView);
                    if (!TextUtils.isEmpty(error.getMessage())) {
                        setTextErrorServer(error.getMessage());
                    }
                }
            }
        });
    }

    private void setSelected() {

        if (isFromCreateAddress) {
            selectedIndex = 0;
            listView.setItemChecked(selectedIndex + 2, true);
        } else {
            if (lastSelectIndex != -1) {
                listView.setItemChecked(lastSelectIndex + 2, true);
                selectedIndex = lastSelectIndex;
            } else {
                for (int i = 0; i < addresses.size(); i++) {
                    AddressItem item = (AddressItem) addresses.get(i);
                    if (item.getSelected() == 1) {
                        selectedIndex = i;
                        listView.setItemChecked(i + 2, true);
                        break;
                    }
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_CREATE_ADDRESS && resultCode == RESULT_OK) {
            isFromCreateAddress = true;
            createCount++;
            xhrAddresses();
        }
        if (requestCode == REQUEST_CODE_SIGNIN) {
            xhrAddresses();
        }
    }

    @Override
    public void onBackPressed() {
        backEvent();
    }
}
