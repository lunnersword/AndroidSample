package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Toast;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SelectGridAdapter;
import com.meidalife.shz.view.MyGridView;
import com.meidalife.shz.widget.VideoView;
import com.usepropeller.routable.Router;
import com.yixia.camera.FFMpegUtils;
import com.yixia.camera.model.MediaObject;
import com.yixia.camera.util.DeviceUtils;
import com.yixia.camera.util.FileUtils;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 视频预览
 *
 * @author tangjun@yixia.com
 */
public class VCMediaPreviewActivity extends BaseActivity implements OnClickListener, VideoView.OnPlayStateListener, OnPreparedListener {

    /**
     * 窗体宽度
     */
    private int mWindowWidth;
    /**
     * 视频信息
     */
    private MediaObject mMediaObject;

    /**
     * 是否需要恢复视频播放
     */
    private boolean mNeedResume;

    @Bind(R.id.record_close)
    View backView;

    @Bind(R.id.record_finish)
    View finishView;

    @Bind(R.id.record_preview)
    VideoView mVideoView;

    @Bind(R.id.record_play)
    View mRecordPlay;

    @Bind(R.id.videoSelectImages)
    MyGridView selectImagesGrid;

    private SelectGridAdapter videoIndexAdapter;

    String selectedFilePath;

    ArrayList<String> picList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);// 防止锁屏
        mWindowWidth = DeviceUtils.getScreenWidth(this);
        setContentView(R.layout.activity_media_preview);

        // ~~~ 绑定控件
        ButterKnife.bind(this);

        //播放器默认不循环
        mVideoView.setLooping(false);

        // ~~~ 绑定事件
        mVideoView.setOnClickListener(this);
        mVideoView.setOnPreparedListener(this);
        mVideoView.setOnPlayStateListener(this);
        backView.setOnClickListener(this);
        finishView.setOnClickListener(this);

        // ~~~ 初始数据
        findViewById(R.id.record_layout).getLayoutParams().height = mWindowWidth;//设置1：1预览范围


        String obj = getIntent().getStringExtra("obj");
        picList = getIntent().getStringArrayListExtra("picList");
        mMediaObject = restoneMediaObject(obj);
        if (mMediaObject == null) {
            Toast.makeText(this, R.string.record_read_object_faild, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        if (picList != null && picList.size() > 0) {
            selectedFilePath = picList.get(0);
        }

        mVideoView.setVideoPath(mMediaObject.getOutputTempVideoPath());

        videoIndexAdapter = new SelectGridAdapter(this, picList);
        videoIndexAdapter.setListener(new OnClickListener());

        selectImagesGrid.setAdapter(videoIndexAdapter);
    }

    class OnClickListener implements SelectGridAdapter.OnClickListener {

        @Override
        public void onImgClick(int position) {
            // 设置适配器的选中项
            videoIndexAdapter.setSelectedPosition(position);
            // 更新列表框
            videoIndexAdapter.notifyDataSetInvalidated();
            if (position < picList.size()) {
                selectedFilePath = picList.get(position);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mVideoView != null) {
            if (mNeedResume) {
                mVideoView.start();
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mVideoView != null) {
            if (mVideoView.isPlaying()) {
                mVideoView.pause();
                mNeedResume = true;
            }
        }
    }

    @Override
    public void onPrepared(android.media.MediaPlayer mp) {
//        if (!isFinishing()) {
//            mVideoView.start();
//            mVideoView.setLooping(true);
//        }
    }

    @Override
    public void onBackPressed() {

        if (mMediaObject != null && mMediaObject.getDuration() > 1) {
            //未转码
            new AlertDialog.Builder(this).setTitle(R.string.hint).setMessage(R.string.record_camera_exit_dialog_message).setNegativeButton(R.string.dialog_yes, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    mMediaObject.delete();
                    finish();
                }

            }).setPositiveButton(R.string.dialog_no, null).setCancelable(false).show();
            return;
        }

        super.onBackPressed();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.record_close:
                onBackPressed();
                break;
            case R.id.record_finish:
                startEncoding();
                break;
            case R.id.record_preview:
                if (mVideoView.isPlaying()) {
                    mVideoView.pause();
                } else {
                    mVideoView.start();
                }
                break;
        }
    }

    private void startEncoding() {
        //检测磁盘空间
        if (FileUtils.showFileAvailable() < 200) {
            Toast.makeText(this, R.string.record_camera_check_available_faild, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isFinishing() && mMediaObject != null) {
            new AsyncTask<Void, Void, Boolean>() {

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    showProgress("", "视频处理中");
                }

                @Override
                protected Boolean doInBackground(Void... params) {
                    return FFMpegUtils.videoTranscoding(mMediaObject, mMediaObject.getOutputVideoPath(), mWindowWidth, true);
                }

                @Override
                protected void onPostExecute(Boolean result) {
                    super.onPostExecute(result);
                    hideProgress();
                    if (result) {
                        if (TextUtils.isEmpty(selectedFilePath)) {
                            MessageUtils.showToast("封面图片不能为空");
                            return;
                        }
                        Bundle bundle = new Bundle();
                        bundle.putString("videoPath", mMediaObject.getOutputVideoPath());
                        bundle.putString("videoPicPath", selectedFilePath);
                        Router.sharedRouter().open("uploadVideo", bundle);
                        finish();
                    } else {
                        Toast.makeText(VCMediaPreviewActivity.this, R.string.record_video_transcoding_faild, Toast.LENGTH_SHORT).show();
                    }
                }
            }.execute();
        }
    }

    @Override
    public void onStateChanged(boolean isPlaying) {
        if (isPlaying)
            mRecordPlay.setVisibility(View.GONE);
        else
            mRecordPlay.setVisibility(View.VISIBLE);
    }

    public static boolean isExternalStorageRemovable() {
        if (DeviceUtils.hasGingerbread())
            return Environment.isExternalStorageRemovable();
        else
            return Environment.MEDIA_REMOVED.equals(Environment.getExternalStorageState());
    }
}
