package com.meidalife.shz.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.WebActivity;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.model.TodayRecommendItem;
import com.meidalife.shz.util.ImgUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 15/11/10.
 */
public class TodayRecommendationAdapter extends RecyclerView.Adapter<TodayRecommendationAdapter.ViewHolder> {
    private List<TodayRecommendItem> todayRecommendItemList = new ArrayList<>();
    private static int ICON_SIZE;
    private Context mContext;
    private LayoutInflater inflater;
    private String categoryId;

    public TodayRecommendationAdapter(Context context, String cid) {
        mContext = context;
        ICON_SIZE = context.getResources().getDimensionPixelSize(R.dimen.today_recommend_icon_size);
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        categoryId = cid;
    }

    public void setData(List<TodayRecommendItem> data) {
        todayRecommendItemList = data;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = inflater.inflate(R.layout.item_today_recommendation, parent, false);
        ViewHolder viewHolder = new ViewHolder(convertView);
        viewHolder.icon = (SimpleDraweeView) convertView.findViewById(R.id.icon);
        viewHolder.title = (TextView) convertView.findViewById(R.id.title);
        viewHolder.price = (TextView) convertView.findViewById(R.id.price);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final TodayRecommendItem item = todayRecommendItemList.get(position);
        String cdnUrl = ImgUtil.getCDNUrlWithWidth(item.getIconUrl(), ICON_SIZE);
        holder.icon.setImageURI(Uri.parse(cdnUrl));
        holder.title.setText(item.getTitle());
        holder.price.setText(item.getPrice());
        holder.icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = item.getLink();
                if (!TextUtils.isEmpty(url)) {
                    Intent intent = new Intent();
                    intent.setClass(mContext, WebActivity.class);
                    intent.putExtra("url", url);
                    mContext.startActivity(intent);

                    LogParam param = new LogParam();
                    param.setType(LogUtil.TYPE_CUSTOMIZE);
                    param.setEid(LogUtil.EVENT_ID_TODAY_CLICK);
                    param.setPvid(item.getPvid());
                    param.setCategoryId(categoryId);
                    LogUtil.log(param);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return todayRecommendItemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        SimpleDraweeView icon;
        TextView title;
        TextView price;

        public ViewHolder(View itemView) {
            super(itemView);
        }
    }
}
