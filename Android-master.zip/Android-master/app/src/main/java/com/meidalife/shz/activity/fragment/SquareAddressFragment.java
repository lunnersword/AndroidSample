package com.meidalife.shz.activity.fragment;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareAddressAdapter;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.EventSender;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareAddressCateOutDO;
import com.meidalife.shz.rest.model.SquareAddressOutDO;
import com.umeng.analytics.MobclickAgent;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

public class SquareAddressFragment extends BaseFragment {


    @Bind(R.id.listView)
    ListView listView;
    private View rootView;

    @Bind(R.id.textStatusErrorServer)
    TextView textStatusErrorServer;
    @Bind(R.id.cellStatusLoading)
    LinearLayout cellStatusLoading;
    @Bind(R.id.cellStatusErrorNetwork)
    LinearLayout cellStatusErrorNetwork;
    @Bind(R.id.cellStatusErrorServer)
    LinearLayout cellStatusErrorServer;
    @Bind(R.id.noDataLayout)
    ViewGroup noDataLayout;
    private AnimationDrawable loadingAnimation;

    private String title;

    private boolean isRefresh;
    private String typeId;
    private String cityCode;
    private String lng;
    private String lat;
    private ArrayList<SquareAddressOutDO> listData;
    private SquareAddressAdapter mAdapter;

    SquareAddressOutDO clickedItem;

    public static SquareAddressFragment newInstance(SquareAddressCateOutDO categoryDO, String cityCode, String lng, String lat) {
        SquareAddressFragment categoryFragment = new SquareAddressFragment();
        Bundle bundle = new Bundle();
        bundle.putString("typeId", categoryDO.getType());
        bundle.putString("cityCode", cityCode);
        bundle.putString("lng", lng);
        bundle.putString("lat", lat);
        bundle.putString("title", categoryDO.getDesc());
        categoryFragment.setArguments(bundle);
//        categoryFragment.title = ;
        return categoryFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            Bundle args = getArguments();
            typeId = args.getString("typeId");
            cityCode = args.getString("cityCode");
            lng = args.getString("lng");
            lat = args.getString("lat");

            rootView = inflater.inflate(R.layout.fragment_square_address, container, false);

            ButterKnife.bind(this, rootView);

            initListener();
        }
        return rootView;
    }

    private void initListener() {
        isRefresh = false;
        listData = new ArrayList<SquareAddressOutDO>();
        mAdapter = new SquareAddressAdapter(getActivity(), listData);
        listView.setAdapter(mAdapter);

        cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStatusLoading();
                refreshList();
            }
        });

        cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStatusLoading();
                refreshList();
            }
        });

        //通知selectSquareLocation the current position address
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                clickedItem = listData.get(position);
                for (SquareAddressOutDO item : listData) {
                    if (item.getName().equals(clickedItem.getName())) {
                        //实现反选
                        if (item.isSelected()) {
                            item.setSelected(false);
                        } else {
                            item.setSelected(true);
                        }
                    } else {
                        item.setSelected(false);
                    }
                }
                mAdapter.notifyDataSetChanged();

                //Send Event
                EventSender.notifyItemClicked(clickedItem);
            }
        });
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        showStatusLoading();
        refreshList();
    }

    public void onEvent(BaseEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType && !isRefresh) {
            showStatusLoading();
            refreshList();
        }
    }

    @Override
    public void onDestroyView() {
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("HomeScreen");
        LogUtil.log(LogUtil.TYPE_START_PAGE, this.getClass().getName());
        EventBus.getDefault().register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("HomeScreen");
        LogUtil.log(LogUtil.TYPE_EXIT_PAGE, this.getClass().getName());
        EventBus.getDefault().unregister(this);
    }


    private void refreshList() {
        if (!isRefresh) {
            cellStatusErrorNetwork.setVisibility(View.GONE);
            cellStatusErrorServer.setVisibility(View.GONE);
            isRefresh = true;

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("cityCode", cityCode);
                jsonObject.put("longitude", lng);
                jsonObject.put("latitude", lat);
                jsonObject.put("tabId", typeId);

                HttpClient.get("1.0/gezi/apply/position", jsonObject, JSONObject.class, callback);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    HttpClient.HttpCallback<JSONObject> callback = new HttpClient.HttpCallback<JSONObject>() {
        @Override
        public void onSuccess(JSONObject jsonObj) {
            isRefresh = false;
            hideStatusLoading();
            List<SquareAddressOutDO> mData = JSON.parseArray(jsonObj.getString("addressList"), SquareAddressOutDO.class);

            if (mData == null || mData.size() == 0) {
                noDataLayout.setVisibility(View.VISIBLE);
            } else {
                listData.clear();
                listData.addAll(mData);
//                mAdapter.setCurrentPosition(0);
                mAdapter.notifyDataSetChanged();

                noDataLayout.setVisibility(View.GONE);
            }

        }

        @Override
        public void onFail(HttpError error) {
            isRefresh = false;
            hideStatusLoading();

            if (listData.size() > 0) {
                listData.clear();
            }
            mAdapter.notifyDataSetChanged();

            if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                cellStatusErrorNetwork.setVisibility(View.VISIBLE);
                return;
            }
            if (!TextUtils.isEmpty(error.getMessage())) {
                textStatusErrorServer.setText(error.getMessage());
            }
            cellStatusErrorServer.setVisibility(View.VISIBLE);
        }
    };


    private void showStatusLoading() {
        try {
            cellStatusLoading.setVisibility(View.VISIBLE);
            loadingAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.loading_animation);
            ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
            loadingImage.setBackgroundDrawable(loadingAnimation);
            loadingAnimation.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideStatusLoading() {
        try {
            if (cellStatusLoading != null) {
                cellStatusLoading.setVisibility(View.GONE);
                if (loadingAnimation != null) {
                    loadingAnimation.stop();
                    loadingAnimation = null;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}