
package com.meidalife.shz.event.type;

/**
 * Created by zuozheng on 14-11-14.
 */
public enum TabMaskDisplayTypeEnum {
    VISIBLE,
    INVISIBLE,
    GONE;
}
