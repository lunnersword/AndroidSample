package com.meidalife.shz.event;

import com.meidalife.shz.event.type.NewMsgEventModel;

/**
 * Created by zuozheng on 14-10-31.
 */
public interface NewMsgEvent {

    public void onEvent(NewMsgEventModel model);
}
