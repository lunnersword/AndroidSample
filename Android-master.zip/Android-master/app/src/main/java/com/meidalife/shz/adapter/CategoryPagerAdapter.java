package com.meidalife.shz.adapter;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.meidalife.shz.activity.fragment.CategoryFragment;
import com.meidalife.shz.rest.model.CategoryDO;

import java.util.ArrayList;

/**
 * Created by taber on 15/7/22.
 */
public class CategoryPagerAdapter extends FragmentStatePagerAdapter {

    ArrayList<CategoryDO> mData;
    Context mContext;

    public CategoryPagerAdapter(FragmentManager fm, ArrayList<CategoryDO> mData) {
        super(fm);
        this.mData = mData;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Fragment getItem(int position) {
        CategoryFragment categoryFragment = new CategoryFragment();
        Bundle bundle = new Bundle();
        CategoryDO categoryDO = mData.get(position);
        bundle.putInt("catId", categoryDO.getCatId());
        categoryFragment.setArguments(bundle);

        return categoryFragment;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        CategoryDO categoryDO = mData.get(position);
        if (null != categoryDO) {
            return categoryDO.getCatName();
        }
        return null;
    }
}
