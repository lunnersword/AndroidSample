package com.meidalife.shz.activity;


import android.content.Intent;
import android.os.Bundle;

import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.view.IconTextView;

/**
 * 暂时没用
 * @deprecated
 */
public class LocationPositionActivity extends BaseMapActivity
        implements AMap.OnMarkerClickListener {

    private final static String TAG = "LocationPosition";
    private Double mCurLatitude;
    private Double mCurLongitude;
    private IconTextView mImageArrow;

    @Override
    public int getLayoutResource() {
        return R.layout.activity_locating_map;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initActionBar(R.string.title_select_nav, true, true);
    }


    void initData() {
        Intent intent = getIntent();
        if (null != intent) {
            mCurLongitude = intent.getDoubleExtra(Constant.GPS_LONG, 0.0);
            mCurLatitude = intent.getDoubleExtra(Constant.GPS_LAT, 0.0);
        }
    }


    @Override
    protected void onSetUpAMap() {
        super.onSetUpAMap();
        initData();
        aMap.getUiSettings().setZoomControlsEnabled(false);
        addMark(mCurLongitude, mCurLatitude, "", "", true);
    }

    private void addMark(Double Longitude, Double Latitude, String descripe, String snippet, boolean isZoom) {

        try {
            LatLng llA = new LatLng(Latitude, Longitude);
            MarkerOptions markerOption = new MarkerOptions();
            markerOption.position(llA);
            markerOption.title(descripe);
            markerOption.snippet(snippet);
            markerOption.anchor(0.5f, 1f);
            markerOption.draggable(true);
            if ("".equals(snippet))
                markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
            else
                markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
            aMap.addMarker(markerOption);
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(llA));
            if (isZoom)
                aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
            aMap.setOnMarkerClickListener(this);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        if (marker.getPosition().latitude >= 0 && marker.getPosition().longitude >= 0) {
            LatLng currentLln = new LatLng(marker.getPosition().latitude, marker.getPosition().longitude);
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
            aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        }
        return true;
    }
}