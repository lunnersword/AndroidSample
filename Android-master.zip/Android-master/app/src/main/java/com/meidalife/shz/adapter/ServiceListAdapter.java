package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServiceItem;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by taber on 15/8/10.
 */
public class ServiceListAdapter extends BaseAdapter {

    LayoutInflater mInflater;
    Context mContext;
    ArrayList<ServiceItem> mData;

    static class ViewHolder {
        TextView radio;
        TextView content;
    }

    public ServiceListAdapter(Context context, ArrayList<ServiceItem> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public ServiceItem getItem(int position) {
        return mData.get(position);
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        convertView = genView(convertView, parent);
        HashMap tag = (HashMap) convertView.getTag();
        ViewHolder holder = (ViewHolder) tag.get("holder");
        ServiceItem item = mData.get(position);
        holder.content.setText(mContext.getResources().getString(R.string.label_i_can) + " " + item.getTag());
        return convertView;
    }

    private View genView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.cancel_order_item, parent, false);
            ViewHolder holder = new ViewHolder();
            holder.radio = (TextView) convertView.findViewById(R.id.reasonRadio);
            holder.content = (TextView) convertView.findViewById(R.id.reasonContent);
            // set iconfont
            holder.radio.setTypeface(Helper.sharedHelper().getIconFont());
            HashMap tag = new HashMap();
            tag.put("type", "reason");
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((String) tag.get("type") != "reason") {
                return genView(null, parent);
            }
        }
        return convertView;
    }
}
