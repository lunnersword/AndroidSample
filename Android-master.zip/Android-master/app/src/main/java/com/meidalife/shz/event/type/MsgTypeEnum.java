
package com.meidalife.shz.event.type;

/**
 * Created by zuozheng on 14-11-14.
 */
public enum MsgTypeEnum {
    TYPE_CHAT(1),
    TYPE_NOTIFICATION(2),
    TYPE_ENABLE_TOUCH_MODE(100),
    TYPE_DISABLE_TOUCH_MODE(101),
    TYPE_REFRESH(102),
    TYPE_CHAT_EXPRESSION(103),
    TYPE_HIDE_SERVICE_PUBLISH(104),
    TYPE_SHOW_SERVICE_PUBLISH(105);

    public int value;

    private MsgTypeEnum(int value) {
        this.value = value;
    }

    public static MsgTypeEnum to(int value) {
        for (MsgTypeEnum element : values()) {
            if (element.value == value) {
                return element;
            }
        }
        return null;
    }
}
