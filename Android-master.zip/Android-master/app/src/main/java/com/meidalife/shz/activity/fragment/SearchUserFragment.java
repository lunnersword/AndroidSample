package com.meidalife.shz.activity.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.UserItem;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtilV2;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/1/7.
 */
public class SearchUserFragment extends BaseFragment {
    public static final String SEARCH_ARG_NICK = "nick";
    private String nick;
    private int page = 0;
    private static final int PAGE_SIZE = 10;
    private boolean isLoading = false;
    List<UserItem> itemList = new ArrayList<>();

    private View rootView;
    private View footView;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.searchResultList)
    ListView searchResultList;
    @Bind(R.id.searchEmptyLayout)
    ViewGroup searchEmptyLayout;

    SearchUserAdapter searchUserAdapter;

    private LoadUtilV2 helperV2;

    public static SearchUserFragment newInstance(Bundle args) {
        SearchUserFragment fragment = new SearchUserFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_search_result, container, false);
            ButterKnife.bind(this, rootView);
            nick = getArguments().getString(SEARCH_ARG_NICK);
            helperV2 = new LoadUtilV2(inflater);
            footView = inflater.inflate(R.layout.fragment_comment_foot, searchResultList, false);
            searchUserAdapter = new SearchUserAdapter(getActivity(), new ArrayList<UserItem>());
            searchResultList.setAdapter(searchUserAdapter);
            searchResultList.setDividerHeight(getResources().getDimensionPixelSize(R.dimen.default_list_divider_height));
            searchResultList.setEmptyView(searchEmptyLayout);

            searchResultList.setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                        if (view.getLastVisiblePosition() == view.getCount() - 1) {
                            footView.setVisibility(View.VISIBLE);
                            searchUser(false);
                        }
                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                }
            });
        }

        searchUser(true);
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    private void searchUser(boolean forceLoad) {
        if (isLoading) {
            return;
        }

        if (forceLoad) {
            page = 0;
            itemList.clear();
            helperV2.loadPre(rootLayout, searchResultList);
        }
        isLoading = true;
        JSONObject params = new JSONObject();
        params.put("nick", nick);
        params.put("offset", page * PAGE_SIZE);
        params.put("pageSize", PAGE_SIZE);

        HttpClient.get("1.0/search/user", params, null, new HttpClient.HttpCallback<JSONArray>() {
            @Override
            public void onSuccess(JSONArray data) {
                isLoading = false;
                helperV2.loadSuccess(searchResultList);
                footView.setVisibility(View.GONE);
                if (null == getActivity() || data == null) {
                    return;
                }

                for (int i = 0; i < data.size(); i++) {
                    JSONObject userJson = data.getJSONObject(i);
                    UserItem item = new UserItem();
                    item.setUserAvatar(userJson.getString("picUrl"));
                    item.setUserGender(userJson.getString("gender"));
                    item.setUserId(userJson.getString("userId"));
                    item.setUserName(userJson.getString("nick"));
                    itemList.add(item);
                }

                searchUserAdapter.setData(itemList);
                searchUserAdapter.notifyDataSetChanged();
                page++;
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                footView.setVisibility(View.GONE);
                helperV2.loadFail(error, rootLayout, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        searchUser(true);
                    }
                });
            }
        });
    }

    public static class SearchUserAdapter extends BaseAdapter {
        private Context mContext;
        private LayoutInflater layoutInflater;
        private final int AVATAR_SIZE;
        List<UserItem> userList = new ArrayList<>();

        public SearchUserAdapter(Context context, List<UserItem> list) {
            this.mContext = context;
            layoutInflater = LayoutInflater.from(context);
            setData(list);
            AVATAR_SIZE = context.getResources().getDimensionPixelSize(R.dimen.search_result_user_avatar_size);
        }

        public void setData(List<UserItem> list) {
            userList = list;
        }

        @Override
        public int getCount() {
            return userList.size();
        }

        @Override
        public Object getItem(int position) {
            return userList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (convertView == null || convertView.getTag() == null) {
                viewHolder = new ViewHolder();
                convertView = layoutInflater.inflate(R.layout.item_search_result_user, parent, false);
                viewHolder.avatar = (SimpleDraweeView) convertView.findViewById(R.id.avatar);
                viewHolder.gender = (TextView) convertView.findViewById(R.id.gender);
                viewHolder.nick = (TextView) convertView.findViewById(R.id.nick);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            final UserItem item = userList.get(position);
            String cdnAvatarUrl = ImgUtil.getCDNUrlWithWidth(item.getUserAvatar(), AVATAR_SIZE);
            if (!TextUtils.isEmpty(cdnAvatarUrl)) {
                viewHolder.avatar.setImageURI(Uri.parse(cdnAvatarUrl));
            } else {
                viewHolder.avatar.setImageURI(ImgUtil.getDefaultAvatarUri(mContext, item.getUserId(), item.getUserGender()));
            }
            viewHolder.nick.setText(item.getUserName());
            if (Constant.GENDER_MAN.equals(item.getUserGender())) {
                viewHolder.gender.setText(R.string.icon_gender_m);
                viewHolder.gender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
            } else if (Constant.GENDER_WOMAN.equals(item.getUserGender())) {
                viewHolder.gender.setText(R.string.icon_gender_f);
                viewHolder.gender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            } else {
                viewHolder.gender.setVisibility(View.GONE);
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("profile/" + item.getUserId());
                }
            });
            return convertView;
        }
    }

    public static class ViewHolder {
        SimpleDraweeView avatar;
        TextView gender;
        TextView nick;
    }
}
