package com.meidalife.shz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zhq on 15/12/20.
 */
public class SquareApplyQualificationAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    JSONArray mData;

    static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.num)
        TextView num;
        @Bind(R.id.content)
        TextView content;
        @Bind(R.id.tip)
        TextView tip;

        @Bind(R.id.desc)
        TextView desc;
    }

    public SquareApplyQualificationAdapter(Context context, JSONArray data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_square_create_square_qualification, parent, false);
            ViewHolder holder = new ViewHolder(convertView);

            convertView.setTag(holder);
        }

        JSONObject obj = mData.getJSONObject(position);

        ViewHolder holder = (ViewHolder) convertView.getTag();

        holder.num.setText((position + 1) + "");
        holder.content.setText(obj.getString("desc"));
        String tips = obj.getString("tips");
        if (TextUtils.isEmpty(tips)) {
            holder.tip.setText("");
        } else {
            holder.tip.setText(tips);
        }
        boolean passed = obj.getBoolean("passed");
        if (passed) {
            holder.desc.setText("满足");
            holder.desc.setTextColor(mContext.getResources().getColor(R.color.grey_j));
        } else {
            holder.desc.setText("不满足");
            holder.desc.setTextColor(mContext.getResources().getColor(R.color.brand_b));
        }
        return convertView;
    }
}
