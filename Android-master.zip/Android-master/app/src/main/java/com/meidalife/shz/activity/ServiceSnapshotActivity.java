package com.meidalife.shz.activity;

import android.content.Context;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ServiceDO;
import com.meidalife.shz.rest.request.RequestItem;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

/**
 * Created by shijian on 15/8/2.
 * <p/>
 * update by zuozheng on 15/11/09 增加活动和促销信息
 */
public class ServiceSnapshotActivity extends BaseActivity {

    private LayoutInflater inflater;
    private Context context;

    private ViewGroup rootView;
    private View contentRoot;

    private String itemId;
    private String snapshotId;

    ViewGroup sellCountGroup;
    ViewGroup evaluationCountGroup;
    TextView sellCountText;
    TextView evaluationCountText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_snapshot);


        //初始化action bar
        initActionBar("商品快照", true, false);

        context = getApplicationContext();
        inflater = getLayoutInflater();

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);

        View infoView = findViewById(R.id.detail_info_type_group);
        infoView.setVisibility(View.GONE);
        View addressView = findViewById(R.id.detail_address_group);
        addressView.setVisibility(View.GONE);
        View judgeView = findViewById(R.id.detail_judge_group);
        judgeView.setVisibility(View.GONE);
        View likeView = findViewById(R.id.detail_like_group);
        likeView.setVisibility(View.GONE);
        View commentView = findViewById(R.id.detail_comment_group);
        commentView.setVisibility(View.GONE);
        View opusView = findViewById(R.id.detail_opus_group);
        opusView.setVisibility(View.GONE);

        sellCountText = (TextView) findViewById(R.id.sellCountText);
        evaluationCountText = (TextView) findViewById(R.id.evaluationCountText);

        Bundle extra = getIntent().getExtras();
        itemId = extra.getString("itemId");
        snapshotId = extra.getString("snapshotId");

        View backView = findViewById(R.id.action_bar_button_back);
        backView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        initLoadData();
    }


    public void initLoadData() {

        loadPre(rootView, contentRoot);

        RequestItem.get(itemId, snapshotId, new HttpClient.HttpCallback<ServiceDO>() {
            @Override
            public void onSuccess(ServiceDO result) {
                loadSuccess(contentRoot);
//                ServiceDO item = (ServiceDO) result;
                renderItem(result);
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(ServiceDetailActivity.class.getName(), "req item data fail, itemId=" + itemId + ", " + error.toString());
                loadFail(error, rootView, ServiceSnapshotActivity.this, new LoadCallback() {
                    @Override
                    public void execute() {
                        initLoadData();
                    }
                });
            }
        });

    }

    public void renderItem(final ServiceDO item) {

        //设置action bar 为卖家名字
        setActionBarTitle(item.getUserName());

        /*
        头部区域，如：用户昵称
         */
//        View headGroup = findViewById(R.id.detail_head_group);
//        headGroup.setVisibility(View.VISIBLE);

//        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getUserAvatar(), userPic.getLayoutParams().width));
//        userPic.setImageURI(uri);
        ImageView userPic = (ImageView) findViewById(R.id.detail_user_pic);
        if (TextUtils.isEmpty(item.getUserAvatar())) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(item.getUserId()), item.getUserGender());
            userPic.setImageURI(getDefaultAvatarUri);
        } else {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getUserAvatar(), userPic.getLayoutParams().width));
            userPic.setImageURI(uri);
        }

        userPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + item.getUserId());
            }
        });

        TextView sexIcon = (TextView) findViewById(R.id.detail_sex_icon);
        if (item.getUserGender() == null) {
            sexIcon.setVisibility(View.GONE);
        } else {
            if (item.getUserGender().equals("woman") || item.getUserGender().equals("F")) {
                sexIcon.setText(context.getResources().getString(R.string.icon_gender_f));
                sexIcon.setTextColor(getResources().getColor(R.color.brand_b));
            } else {
                sexIcon.setText(context.getResources().getString(R.string.icon_gender_m));
                sexIcon.setTextColor(getResources().getColor(R.color.brand_i));
            }
        }

        //实名认证状态
        TextView realNameAuthStatus = (TextView) findViewById(R.id.detail_real_name_auth_status);
        if (item.getRealNameCert() == 1) {
            realNameAuthStatus.setText("已实名认证");
        } else {
            realNameAuthStatus.setText("未实名认证");
        }

        //芝麻信用分数
        TextView zmLevel = (TextView) findViewById(R.id.detail_zm_level);
        //todo 设置用户实名认证状态和技能认证状态
        if (TextUtils.isEmpty(item.getZmLevel())) {
            zmLevel.setText("芝麻信用未绑定");
        } else {
            zmLevel.setText(item.getZmLevel());
        }

        //个人认证
        TextView skillAuth = (TextView) findViewById(R.id.detail_skill_tv);
        if (item.getCertList() != null && item.getCertList().size() > 0) {
            StringBuilder str = new StringBuilder();
            for (String cert : item.getCertList()) {
                str.append(cert).append(" ");
            }
            skillAuth.setText(str.toString());
        } else {
            skillAuth.setText("未申请个人认证");
        }

        /*
        中间区域，如：title等
         */

        TextView latestSell = (TextView) findViewById(R.id.detail_latest_sell);
        latestSell.setVisibility(View.GONE);

        TextView userTag = (TextView) findViewById(R.id.detail_user_tag);
        userTag.setText(getString(R.string.label_i_can) + item.getTag());

        //todo 解析活动字段 原价；剩余单数和促销字段tag  字段待确认
        TextView promotionTag = (TextView) findViewById(R.id.detail_promotion_tag);
        TextView price = (TextView) findViewById(R.id.detail_price);
        TextView oriPrice = (TextView) findViewById(R.id.detail_origin_price);
        if (TextUtils.isEmpty(item.getPromotionPrice())) {
            price.setText(item.getPrice());
        } else {
            promotionTag.setVisibility(View.VISIBLE);
            price.setText(item.getPromotionPrice());
            oriPrice.setVisibility(View.VISIBLE);
            oriPrice.setText(item.getPrice());
            oriPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
        }

        TextView itemStock = (TextView) findViewById(R.id.itemStock);
        if (item.getPromotionNum() > 0) {
            itemStock.setText("剩余" + item.getPromotionNum() + "单");
        } else {
            itemStock.setVisibility(View.GONE);
        }


        TextView content = (TextView) findViewById(R.id.detail_content);
        content.setText(item.getContent());

        int tenDp = (int) Helper.convertDpToPixel(10, context);
        int deviceWidth = content.getResources().getDisplayMetrics().widthPixels;
        LinearLayout picsGroup = (LinearLayout) findViewById(R.id.detail_pics_group);
        picsGroup.removeAllViews();

        for (String imgUrl : item.getImages()) {
            int imgWidth = deviceWidth - (2 * tenDp);
            int imgHeight = imgWidth;
            // 计算图片高度
            String[] arrays = imgUrl.split("/");
            String[] imgWh = arrays[arrays.length - 1].split("_");
            if (imgWh.length == 3) {
                float width = Integer.parseInt(imgWh[0].substring(0, imgWh[0].length() - 1));
                float height = Integer.parseInt(imgWh[1].substring(0, imgWh[1].length() - 1));
                imgHeight = (int) ((height * imgWidth) / width);
                if (imgHeight > 4096) {
                    imgHeight = 4096;
                    imgWidth = (int) ((width / height) * 4096);
                }
            }
            // 显示图片
            SimpleDraweeView imgView = (SimpleDraweeView) inflater.inflate(R.layout.activity_service_detail_pics_item, null);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(imgWidth, imgHeight);
            layoutParams.setMargins(0, tenDp, 0, 0);
            imgView.setLayoutParams(layoutParams);
            imgUrl = ImgUtil.getCDNUrlWithWidth(imgUrl, imgWidth);
            imgView.setImageURI(Uri.parse(imgUrl));
            picsGroup.addView(imgView);
        }

        /*售出数目&评论数量*/
        sellCountText.setText(item.getSellCount() > 0 ?
                String.format(getString(R.string.sell_count), item.getSellCount()) : getString(R.string.sell_count_none));
        evaluationCountText.setText(item.getEvaluationCount() > 0 ?
                String.format(getString(R.string.comment_count), item.getEvaluationCount()) : getString(R.string.comment_count_none));
        /*
        已更新的提示
         */

//        TextView editTime = (TextView) findViewById(R.id.snapshot_edit_time);
//        editTime.setText(item.getUpdateDateStr() + " 已更新");

        TextView snapshotLatest = (TextView) findViewById(R.id.snapshot_latest);
        snapshotLatest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Router.sharedRouter().open("services/" + itemId);
            }
        });
    }
}
