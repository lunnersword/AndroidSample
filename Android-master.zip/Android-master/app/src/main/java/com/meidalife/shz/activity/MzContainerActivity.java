package com.meidalife.shz.activity;

import android.os.Bundle;
import android.app.Activity;

import com.meidalife.shz.R;

public class MzContainerActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mz_container);
    }


}
