package com.meidalife.shz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.adapter.ServiceGridAdapter;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.request.RequestService;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.MyGridView;
import com.usepropeller.routable.Router;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.Bind;
import butterknife.ButterKnife;
//import us.pinguo.edit.sdk.PGEditActivity;
//import us.pinguo.edit.sdk.base.PGEditResult;
//import us.pinguo.edit.sdk.base.PGEditSDK;

public class ServicePublishActivity extends BaseActivity {

//    public static int MAX_IMAGE_LENGTH = 9;

    final int SERVICE_TYPE_VISIT = 1;
    final int SERVICE_TYPE_COME = 2;
    final int SERVICE_TYPE_ONLINE = 3;
    final int SERVICE_TYPE_POST = 4;

    //    int REQUEST_CODE_PICK_TIME = 111;
//    int REQUEST_CODE_PICK_ADDRESS = 222;
    int TEXT_LENGTH_LIMIT_TITLE = 7;
    int TEXT_LENGTH_LIMIT_DESC = 250;

    @Bind(R.id.imageAvatar)
    SimpleDraweeView imageAvatar;
    @Bind(R.id.iconRightTime)
    TextView iconRightTime;
    @Bind(R.id.iconServiceType)
    TextView iconServiceType;
    @Bind(R.id.cellServiceType1)
    LinearLayout cellServiceType1;
    @Bind(R.id.cellServiceType2)
    LinearLayout cellServiceType2;
    @Bind(R.id.cellServiceType3)
    LinearLayout cellServiceType3;
    @Bind(R.id.cellServiceType4)
    LinearLayout cellServiceType4;
    @Bind(R.id.imageArrowServiceType1)
    ImageView imageArrowServiceType1;
    @Bind(R.id.imageArrowServiceType2)
    ImageView imageArrowServiceType2;
    @Bind(R.id.imageArrowServiceType3)
    ImageView imageArrowServiceType3;
    @Bind(R.id.imageArrowServiceType4)
    ImageView imageArrowServiceType4;
    @Bind(R.id.btnPublish)
    Button btnPublish;

    @Bind(R.id.iconRight)
    TextView iconRight;
    @Bind(R.id.iconRightCity)
    TextView iconRightCity;
    //item picture List
    @Bind(R.id.selectImages)
    MyGridView selectImagesGrid;

    @Bind(R.id.textServiceTitle)
    EditText textServiceTitle;
    @Bind(R.id.textServicePrice)
    EditText textServicePrice;
    @Bind(R.id.textServiceUnit)
    EditText textServiceUnit;
    @Bind(R.id.textServiceDesc)
    EditText textServiceDesc;
    @Bind(R.id.cellAddress)
    RelativeLayout cellAddress;
    @Bind(R.id.cellTime)
    RelativeLayout cellTime;
    @Bind(R.id.cellCity)
    RelativeLayout cellCity;
    @Bind(R.id.textTimeContent)
    TextView textTimeContent;
    @Bind(R.id.textCityContent)
    TextView textCityContent;
    @Bind(R.id.textAddressContent)
    TextView textAddressContent;
    @Bind(R.id.textTitleLimit)
    TextView textTitleLimit;
    @Bind(R.id.textDescLimit)
    TextView textDescLimit;

    //服务方式为邮寄 库存类型view
    @Bind(R.id.stockType)
    RelativeLayout mStockType;
    //库存类型  有现货
    @Bind(R.id.stockTypeInStock)
    TextView mStockTypeInStock;
    //库存类型 需现做
    @Bind(R.id.stockTypeUnStock)
    TextView mStockTypeUnStock;
    //货物类型描述
    @Bind(R.id.textStockTypeDesc)
    TextView mTextStockTypeDesc;

    @Bind(R.id.scrollViewContent)
    View scrollViewContent;

    Boolean submit;
    Boolean uploadComplete;
    Boolean uploading;
    int count;
    HashMap uploadImages = new HashMap();
    ArrayList<String> selectedImages;
    String cityCode;
    String itemId;
    ServiceGridAdapter adapter;
    int serviceType = 0;
    String scheduleTime;
    int addressId;


    // 邮寄类型增加 isSpot 字段表示是否现货，1表示现货，0表示现做
    //具体看接口文档 https://github.com/meida/Docs/wiki/%E5%95%86%E5%93%81%E7%9B%B8%E5%85%B3%E6%8E%A5%E5%8F%A3 服务发布接口
    int isSpot = 1;

    private String currentSourceImage = null;

    private int currentPosition = 0;

    private String EDITED_IMAGE_DIRECTORY;
    private static final String EDITED_IMAGE_PREFIX = "editedImage";

    int canPickPicCount;
    private int lastSelectIndex = -1;
    private boolean isFromEdit = false; //来自编辑服务
    private boolean isBanEdit = false;   //不可编辑

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_publish);
        initActionBar(R.string.title_activity_service_publish, true);


        ButterKnife.bind(this);

        hideIMM();

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            isFromEdit = true;
            itemId = bundle.getString("id");
            setActionBarTitle(R.string.title_activity_service_edit);
            btnPublish.setText("保存");
        }

        cityCode = null;
        submit = false;
        uploading = false;
        uploadComplete = false;
        count = 0;

        iconRight.setTypeface(Helper.sharedHelper().getIconFont());
        iconRightTime.setTypeface(Helper.sharedHelper().getIconFont());
        iconRightCity.setTypeface(Helper.sharedHelper().getIconFont());
        iconServiceType.setTypeface(Helper.sharedHelper().getIconFont());

        // set avatar //todo set default avatar
        String avatarUrl = Helper.sharedHelper().getStringUserInfo(Constant.USER_AVATAR);
        if (TextUtils.isEmpty(avatarUrl)) {
            String userId = Helper.sharedHelper().getStringUserInfo(Constant.USER_ID);
            String gender = Helper.sharedHelper().getStringUserInfo(Constant.USER_GENDER);
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, userId, gender);
            imageAvatar.setImageURI(getDefaultAvatarUri);
        } else {
            Uri avatarUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, imageAvatar.getLayoutParams().width));
            imageAvatar.setImageURI(avatarUri);
        }

        // 服务类型宽度
        float deviceWidth = this.getResources().getDisplayMetrics().widthPixels;
        float spaceWidth = Helper.convertDpToPixel(30 + 8 * 3, this);
        float sumWidth = deviceWidth - spaceWidth;
        int itemWidth = (int) (sumWidth / 4);
        ViewGroup.LayoutParams layoutParams = cellServiceType1.getLayoutParams();
        layoutParams.width = itemWidth;
        cellServiceType1.setLayoutParams(layoutParams);
        layoutParams = cellServiceType2.getLayoutParams();
        layoutParams.width = itemWidth;
        cellServiceType2.setLayoutParams(layoutParams);
        layoutParams = cellServiceType3.getLayoutParams();
        layoutParams.width = itemWidth;
        cellServiceType3.setLayoutParams(layoutParams);
        layoutParams = cellServiceType4.getLayoutParams();
        layoutParams.width = itemWidth;
        cellServiceType4.setLayoutParams(layoutParams);

        textServiceTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textTitleLimit.setText("" + s.toString().length());
                if (s.toString().length() > TEXT_LENGTH_LIMIT_TITLE) {
                    textTitleLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textTitleLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        textServiceDesc.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textDescLimit.setText("" + s.toString().length());
                if (s.toString().length() > TEXT_LENGTH_LIMIT_DESC) {
                    textDescLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textDescLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        //邮寄类商品 库存类型为“有现货” 设置点击事件
        mStockTypeInStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                modifyStockType(1);
            }
        });
        //邮寄类商品 库存类型为“需现做” 设置点击事件
        mStockTypeUnStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                modifyStockType(0);
            }
        });

        initSelectImagesGrid();

        if (itemId != null) {
            xhrServiceDetail();
        }

        EDITED_IMAGE_DIRECTORY = ImgUtil.getEditedImagePath(this);
    }

    private void modifyStockType(int isSpot) {
        //库存是 “有现货” 默认3天发货;库存是 “需现做” 默认7天发货
        this.isSpot = isSpot;
        if (isSpot == 0) {
            mStockTypeInStock.setTextColor(getResources().getColor(R.color.grey_f));
            mStockTypeUnStock.setTextColor(getResources().getColor(R.color.grey_a));
//            mTextStockTypeDesc.setText(getString(R.string.service_stock_type_desc_seven_days));

            mStockTypeInStock.setBackgroundResource(R.drawable.bg_corner_stocktype_unselected);
            mStockTypeUnStock.setBackgroundResource(R.drawable.bg_corner_stocktype_selected);
        } else {
            mStockTypeInStock.setTextColor(getResources().getColor(R.color.grey_a));
            mStockTypeUnStock.setTextColor(getResources().getColor(R.color.grey_f));
//            mTextStockTypeDesc.setText(getString(R.string.service_stock_type_desc_default));

            mStockTypeInStock.setBackgroundResource(R.drawable.bg_corner_stocktype_selected);
            mStockTypeUnStock.setBackgroundResource(R.drawable.bg_corner_stocktype_unselected);

        }
    }

    private void initSelectImagesGrid() {
        selectedImages = new ArrayList<String>(9);
        canPickPicCount = Constant.MAX_IMAGE_LENGTH - selectedImages.size();
        adapter = new ServiceGridAdapter(this, selectedImages, Constant.MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_SERVICE);
        selectImagesGrid.setAdapter(adapter);
        adapter.setOnClickListener(new ServiceGridAdapter.OnClickListener() {
            @Override
            public void onAddClick(View v, int position) {
                addImg(position);
            }

            @Override
            public void onEditClick(View v, int position) {
                currentSourceImage = selectedImages.get(position);
                currentPosition = position;
                addImg(position);
            }

            @Override
            public void onRemoveClick(View v, int position) {
                if (position < selectedImages.size()) {
                    selectedImages.set(position, "");
                    canPickPicCount++;
                    adapter.notifyDataSetChanged();
                }
            }
        });

//        selectImagesGrid.setOnItemClickListener(adapter);
    }

    void addImg(int position) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", canPickPicCount);
        bundle.putInt("position", position);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, this);
    }

//    void editImg(int position) {
//        if (TextUtils.isEmpty(EDITED_IMAGE_DIRECTORY)) {
//            return;
//        }
//
//        String url = selectedImages.get(position);
//        String outputPath = EDITED_IMAGE_DIRECTORY + File.separator + EDITED_IMAGE_PREFIX + "_" + position;
//        File outputFile = new File(outputPath);
//        if (outputFile.exists()) {
//            boolean result = outputFile.delete();
//            Log.d("ServicePublish", "Delete previous edited images:" + result);
//        }
//        if (!TextUtils.isEmpty(url)) {
//            PGEditSDK.instance().startEdit(this, PGEditActivity.class, url, outputPath);
//        }
//    }

    public void handleOpenSpecification(View view) {
        Bundle bundle = new Bundle();
        bundle.putString("url", Constant.URL_SPECIFICATION);
        Router.sharedRouter().open("web", bundle);
    }

    public void handlePickCity(View view) {
        Router.sharedRouter().openFormResult("pick/city",
                Constant.REQUEST_CODE_PICK_CITY, this);
    }

    public void handlePickTime(View view) {
        if (scheduleTime != null) {
            Bundle bundle = new Bundle();
            bundle.putString("scheduleTime", scheduleTime);
            Router.sharedRouter().openFormResult("timemanage", bundle,
                    Constant.REQUEST_CODE_TIME_MANAGE, this);
        } else {
            Router.sharedRouter().openFormResult("timemanage",
                    Constant.REQUEST_CODE_TIME_MANAGE, this);
        }
    }

    public void handlePickAddress(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("lastSelectIndex", lastSelectIndex);
        Router.sharedRouter().openFormResult("addresses", bundle, Constant.REQUEST_CODE_PICK_ADDRESS, this);
    }

    public void handleSelectType1(View view) {
        cellServiceType1.setSelected(true);
        cellServiceType2.setSelected(false);
        cellServiceType3.setSelected(false);
        cellServiceType4.setSelected(false);
        imageArrowServiceType1.setVisibility(View.VISIBLE);
        imageArrowServiceType2.setVisibility(View.INVISIBLE);
        imageArrowServiceType3.setVisibility(View.INVISIBLE);
        imageArrowServiceType4.setVisibility(View.INVISIBLE);
        serviceType = SERVICE_TYPE_VISIT;
        cellTime.setVisibility(View.VISIBLE);
        cellCity.setVisibility(View.VISIBLE);
        cellAddress.setVisibility(View.GONE);

        mStockType.setVisibility(View.GONE);
        mTextStockTypeDesc.setVisibility(View.GONE);
    }

    public void handleSelectType2(View view) {
        cellServiceType1.setSelected(false);
        cellServiceType2.setSelected(true);
        cellServiceType3.setSelected(false);
        cellServiceType4.setSelected(false);
        imageArrowServiceType1.setVisibility(View.INVISIBLE);
        imageArrowServiceType2.setVisibility(View.VISIBLE);
        imageArrowServiceType3.setVisibility(View.INVISIBLE);
        imageArrowServiceType4.setVisibility(View.INVISIBLE);
        serviceType = SERVICE_TYPE_COME;
        cellTime.setVisibility(View.VISIBLE);
        cellCity.setVisibility(View.GONE);
        cellAddress.setVisibility(View.VISIBLE);

        mStockType.setVisibility(View.GONE);
        mTextStockTypeDesc.setVisibility(View.GONE);
    }

    public void handleSelectType3(View view) {
        cellServiceType1.setSelected(false);
        cellServiceType2.setSelected(false);
        cellServiceType3.setSelected(true);
        cellServiceType4.setSelected(false);
        imageArrowServiceType1.setVisibility(View.INVISIBLE);
        imageArrowServiceType2.setVisibility(View.INVISIBLE);
        imageArrowServiceType3.setVisibility(View.VISIBLE);
        imageArrowServiceType4.setVisibility(View.INVISIBLE);
        serviceType = SERVICE_TYPE_ONLINE;
        cellTime.setVisibility(View.VISIBLE);
        cellCity.setVisibility(View.GONE);
        cellAddress.setVisibility(View.GONE);

        mStockType.setVisibility(View.GONE);
        mTextStockTypeDesc.setVisibility(View.GONE);
    }

    public void handleSelectType4(View view) {
        cellServiceType1.setSelected(false);
        cellServiceType2.setSelected(false);
        cellServiceType3.setSelected(false);
        cellServiceType4.setSelected(true);
        imageArrowServiceType1.setVisibility(View.INVISIBLE);
        imageArrowServiceType2.setVisibility(View.INVISIBLE);
        imageArrowServiceType3.setVisibility(View.INVISIBLE);
        imageArrowServiceType4.setVisibility(View.VISIBLE);
        serviceType = SERVICE_TYPE_POST;
        cellTime.setVisibility(View.GONE);
        cellCity.setVisibility(View.GONE);
        cellAddress.setVisibility(View.GONE);

        mStockType.setVisibility(View.VISIBLE);
        mTextStockTypeDesc.setVisibility(View.VISIBLE);
    }

    public void handlePublish(View view) {
        if (textServiceTitle.getText().toString().length() == 0) {
            MessageUtils.showToastCenter("你能提供什么技能呢？");
            return;
        }
        if (textServiceDesc.getText().toString().length() == 0) {
            MessageUtils.showToastCenter("还没写牛逼的描述呢");
            return;
        }
        if (selectedImages.size() == 0) {
            MessageUtils.showToastCenter("还没有选择照片呢");
            return;
        }
        if (textServicePrice.getText().toString().length() == 0) {
            MessageUtils.showToastCenter("不要钱了吗");
            return;
        }
        if (textServiceUnit.getText().toString().length() == 0) {
            MessageUtils.showToastCenter("认真填写个单位吧");
            return;
        }
        if (serviceType == 0) {
            MessageUtils.showToastCenter("请选择您的服务类型");
            return;
        }
        if (serviceType == SERVICE_TYPE_VISIT) {
            if (TextUtils.isEmpty(scheduleTime) || !scheduleTime.contains("1")) {
                MessageUtils.showToastCenter("请选择您可提供服务的时间");
                return;
            }
            if (cityCode == null) {
                MessageUtils.showToastCenter("还没选择服务城市呢");
                return;
            }
        }
        if (serviceType == SERVICE_TYPE_COME) {
            if (TextUtils.isEmpty(scheduleTime) || !scheduleTime.contains("1")) {
                MessageUtils.showToastCenter("请选择您可提供服务的时间");
                return;
            }
            if (addressId == 0) {
                MessageUtils.showToastCenter("还没设置服务地址");
                return;
            }
        }
        if (serviceType == SERVICE_TYPE_ONLINE) {
            if (TextUtils.isEmpty(scheduleTime) || !scheduleTime.contains("1")) {
                MessageUtils.showToastCenter("请选择您可提供服务的时间");
                return;
            }
        }
        if (!submit) {
            submit = true;
            showProgressDialog("正在发布", false);

            if (uploadComplete) {
                xhrPublishService();
            } else {
                uploadImages();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Bundle bundle;
        switch (requestCode) {
            case Constant.REQUEST_CODE_PICK_CITY:
                //设置服务城市
                if (resultCode == RESULT_OK) {
                    bundle = data.getExtras();
                    cityCode = "" + bundle.getInt("code");
                    textCityContent.setText(bundle.getString("name"));
                }
                break;
            case Constant.REQUEST_CODE_PICK_PHOTO:
                //todo: 设置选择图片，并后台上传
                if (resultCode == RESULT_OK) {
                    bundle = data.getExtras();
                    ArrayList<String> paths = bundle.getStringArrayList("images");
                    if (paths != null && paths.size() > 0) {
                        for (int i = 0; i < paths.size(); i++) {
                            if (currentPosition < selectedImages.size() && TextUtils.isEmpty(selectedImages.get(currentPosition))) {
                                selectedImages.set(currentPosition++, paths.get(i));
                                canPickPicCount--;
                            } else {
                                if (selectedImages.size() < Constant.MAX_IMAGE_LENGTH) {
                                    selectedImages.add(paths.get(i));
                                    canPickPicCount--;
                                }
                            }
                        }
                    }

                    adapter.notifyDataSetChanged();
                    uploading = false;
                    uploadComplete = false;
                    uploadImages();
                }
                break;
            case Constant.REQUEST_CODE_TIME_MANAGE:
                if (resultCode == RESULT_OK) {
                    bundle = data.getExtras();
                    scheduleTime = bundle.getString("scheduleTime");
                    textTimeContent.setText("设置完成");
                }
                break;
            case Constant.REQUEST_CODE_PICK_ADDRESS:
                if (resultCode == RESULT_OK) {
                    bundle = data.getExtras();
                    AddressItem addressItem = (AddressItem) bundle.getSerializable(Constant.EXTRA_TAG_ADDRESS);
                    addressId = addressItem.getAddressId();
                    textAddressContent.setText(addressItem.getAddressName());
                    lastSelectIndex = bundle.getInt("lastSelectIndex");
                }
                if (resultCode == RESULT_CANCELED) {
                    bundle = data.getExtras();
                    if (bundle != null) {
                        lastSelectIndex = bundle.getInt("lastSelectIndex");
                    }
                }

                break;
//            case PGEditSDK.PG_EDIT_SDK_REQUEST_CODE: {
//                if (resultCode == RESULT_OK) {
//                    handleEditImageResult(data);
//                    for (int i = 0; i < adapter.getImageList().size(); i++) {
//                        // 如果图片列表中没有当前选中的照片，则添加到图片列表中
//                        if (selectedImages.indexOf(adapter.getImageList().get(i)) == -1) {
//                            selectedImages.add(adapter.getImageList().get(i));
//                        }
//                    }
//                    uploading = false;
//                    uploadComplete = false;
//                    uploadImages();
//                }
//                break;
//            }
            default:
        }
    }

//    public void handleEditImageResult(Intent data) {
//        PGEditResult editResult = PGEditSDK.instance().handleEditResult(data);
//        String resultPhotoPath = editResult.getReturnPhotoPath();
//        if (!TextUtils.isEmpty(currentSourceImage) && !TextUtils.isEmpty(resultPhotoPath)) {
//            for (int i = 0; i < selectedImages.size(); i++) {
//                if (currentSourceImage.equals(selectedImages.get(i))) {
//                    selectedImages.set(i, resultPhotoPath);
//                }
//            }
//        }
//        adapter.notifyDataSetChanged();
//    }

    private void uploadImages() {
        if (!uploading) {
            uploading = true;

            ArrayList uploadQueue = new ArrayList();
            for (int i = 0; i < selectedImages.size(); i++) {
                // 如果图片列表中没有当前选中的照片，则添加到图片列表中
                if (!TextUtils.isEmpty(selectedImages.get(i)) && !uploadImages.containsKey(selectedImages.get(i))) {
                    uploadQueue.add(selectedImages.get(i));
                }
            }

            xhrUpdateImages(uploadQueue, 0);
        }
    }

    private void xhrUpdateImages(final ArrayList paths, final int index) {
        if (paths.size() > 0) {
            final String path = (String) paths.get(index);
            RequestSign.upload(path, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    JSONObject json = (JSONObject) result;
                    try {
                        uploadImages.put(path, json.getString("data"));
                        if (index == paths.size() - 1) {
                            uploadComplete = true;
                            if (submit) {
                                xhrPublishService();
                            }
                        } else {
                            uploadComplete = false;
                            xhrUpdateImages(paths, index + 1);
                        }
                    } catch (JSONException e) {
                        uploading = false;
                        uploadComplete = false;
                        hideProgressDialog();
                        selectedImages.clear();
                        selectedImages.addAll(uploadImages.keySet());
                        adapter.notifyDataSetChanged();
                        Toast.makeText(ServicePublishActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    uploading = false;
                    uploadComplete = false;
                    submit = false;
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败");
                }
            });
        } else {
            uploadComplete = true;
            if (submit) {
                xhrPublishService();
            }
        }
    }

    private void xhrPublishService() {
        btnPublish.setEnabled(false);
        initLBSInfo();
    }

    void initLBSInfo() {
        LocationDO mNewLocation = SHZApplication.getInstance().getLocationManager().getLocation();
        buildParams(null, mNewLocation);
    }

    void buildParams(LocationDO mOldLocation, LocationDO mNewLocation) {
        try {
            final JSONObject params = new JSONObject();
            params.put("title", textServiceTitle.getText().toString());
            params.put("desc", textServiceDesc.getText().toString());
            params.put("price", textServicePrice.getText().toString());
            params.put("unit", textServiceUnit.getText().toString());
            // 设置poi数据
            if (mOldLocation != null) {
                params.put("poiLongitude", "" + mOldLocation.getLongitude());
                params.put("poiLatitude", "" + mOldLocation.getLatitude());
            }

            if (mNewLocation != null) {
                params.put("poiLongitude", "" + mNewLocation.getLongitude());
                params.put("poiLatitude", "" + mNewLocation.getLatitude());
            }

            params.put("images", getUploadImagesUrl());
            params.put("serviceType", serviceType);
            switch (serviceType) {
                case SERVICE_TYPE_VISIT:
                    params.put("scheduleTime", scheduleTime);
                    params.put("cityCode", cityCode);
                    break;
                case SERVICE_TYPE_COME:
                    params.put("scheduleTime", scheduleTime);
                    params.put("addressId", addressId);
                    break;
                case SERVICE_TYPE_ONLINE:
                    params.put("scheduleTime", scheduleTime);
                    break;
                case SERVICE_TYPE_POST:
                    params.put("isSpot", isSpot);
                    break;
            }

            if (itemId != null) {
                params.put("id", itemId);
                RequestService.update(params, callback);
            } else {
                RequestService.create(params, callback);
            }

        } catch (JSONException e) {
        }
    }


    MeidaRestClient.RestCallback callback = new MeidaRestClient.RestCallback() {
        @Override
        public void onSuccess(Object result) {
            hideProgressDialog();
            submit = false;
            JSONObject json = (JSONObject) result;
            try {
                JSONObject data = json.getJSONObject("data");
                Bundle bundle = new Bundle();
                Log.d("mzLog", "publish data:" + data.toString());
                if (isFromEdit || data.has("realUser") && data.getBoolean("realUser")) {
                    bundle.putString("title", textServiceTitle.getText().toString());
                    bundle.putString("desc", textServiceDesc.getText().toString());
                    bundle.putString("image", getUploadImagesUrl().getString(0));
                    bundle.putString("itemId", data.getString("itemId"));
                    bundle.putBoolean("bindGezi", data.getBoolean("bindGezi"));
                    Router.sharedRouter().open("publishServiceFinish", bundle);
                } else {
                    bundle.putBoolean("bindGezi", data.getBoolean("bindGezi"));
                    bundle.putString("itemId", data.getString("itemId"));
                    Router.sharedRouter().open("serviceNotPutOnSale", bundle);
                }

                setResult(RESULT_OK);
                finish();
            } catch (JSONException e) {
                MessageUtils.showToastCenter(e.getMessage());
                btnPublish.setEnabled(true);
            }
        }

        @Override
        public void onFailure(HttpError error) {
            btnPublish.setEnabled(true);
            hideProgressDialog(); // http://blog.csdn.net/yihongyuelan/article/details/9829313
            submit = false;
            MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败，请重试");
        }
    };

    private void xhrServiceDetail() {
        showProgressDialog("正在获取数据", false);
        try {
            JSONObject params = new JSONObject();
            params.put("id", itemId);
            RequestService.getUpdateRender(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    hideProgressDialog();
                    HashMap item = (HashMap) result;
                    textServiceTitle.setText((String) item.get("title"));
                    textTitleLimit.setText("" + textServiceTitle.getText().toString().length());
                    textServicePrice.setText((String) item.get("price"));
                    textDescLimit.setText("" + textServicePrice.getText().toString().length());
                    textServiceUnit.setText((String) item.get("unit"));
                    textServiceDesc.setText((String) item.get("desc"));
                    ArrayList<String> urls = (ArrayList) item.get("images");
                    if (urls != null && urls.size() > 0) {
//                        for (int i = 0; i < urls.size(); i++) {
//                            uploadImages.put(urls.get(i), urls.get(i));
//                            selectedImages.add(i, urls.get(i));
//                        }
                        for (String url : urls) {
                            uploadImages.put(url, url);
                            selectedImages.add(url);
                        }
                    }
                    adapter.notifyDataSetChanged();

                    //服务类型
                    serviceType = (int) item.get("serviceType");

                    //邮寄服务 支持几天发货 1:现货 0:需要现做
                    isSpot = (int) item.get("isSpot");

                    switch (serviceType) {
                        case SERVICE_TYPE_VISIT:
                            scheduleTime = (String) item.get("scheduleTime");
                            cityCode = (String) item.get("cityCode");
                            handleSelectType1(null);
                            textTimeContent.setText("设置完成");
                            textCityContent.setText((String) item.get("cityName"));
                            break;
                        case SERVICE_TYPE_COME:
                            scheduleTime = (String) item.get("scheduleTime");
                            addressId = (int) item.get("addressId");
                            handleSelectType2(null);
                            textTimeContent.setText("设置完成");
                            textAddressContent.setText((String) item.get("addressName"));
                            break;
                        case SERVICE_TYPE_ONLINE:
                            scheduleTime = (String) item.get("scheduleTime");
                            handleSelectType3(null);
                            textTimeContent.setText("设置完成");
                            break;
                        case SERVICE_TYPE_POST:
                            handleSelectType4(null);
                            modifyStockType(isSpot);
                            break;
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "获取服务数据失败");
                    if(error != null && error.getMessage().contains("不能编辑")){
                        scrollViewContent.setVisibility(View.GONE);
                        isBanEdit = true;
                    }
                }
            });
        } catch (JSONException e) {

        }
    }

    private JSONArray getUploadImagesUrl() {
        JSONArray data = new JSONArray();
        for (int i = 0; i < selectedImages.size(); i++) {
            if (uploadImages.containsKey(selectedImages.get(i))) {
                data.put(uploadImages.get(selectedImages.get(i)));
            }
        }
        return data;
    }

    @Override
    public void onBackPressed() {
        if (!hasChange() || isBanEdit) {
            super.onBackPressed();
            return;
        }

        MessageUtils.createDialog(ServicePublishActivity.this, "提醒", "真的要放弃编辑吗", R.string.confirm_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }, R.string.cancel_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        }).show();
    }

    private boolean hasChange() {
        if (itemId == null) {
            if (textServiceTitle.getText().toString().equals("") &&
                    textServiceDesc.getText().toString().equals("") &&
                    textServicePrice.getText().toString().equals("") &&
                    textServiceUnit.getText().toString().equals("") &&
                    serviceType == 0 &&
                    selectedImages.size() == 0) {
                return false;
            }
        }
        return true;
    }

}
