package com.meidalife.shz.activity.fragment;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.github.lzyzsd.jsbridge.Message;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.OrderListActivity;
import com.meidalife.shz.adapter.ProfileAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.LoadUtilV2;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/12/23.
 */
public class ProfileFragment extends BaseFragment {
    private View rootView;
    final String ZERO = "0";
    String kefuPhone;
    String kefuId;
    private List<ProfileAdapter.ProfileItem> buyerProfileItems = new ArrayList<>();
    private List<ProfileAdapter.ProfileItem> sellerProfileItems = new ArrayList<>();
    private List<ProfileAdapter.ProfileItem> settingProfileItems = new ArrayList<>();
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;

    @Bind(R.id.scrollView)
    ScrollView scrollView;
    @Bind(R.id.profileBannerLayout)
    ViewGroup profileBannerLayout;
    @Bind(R.id.profileBanner)
    TextView profileBanner;
    @Bind(R.id.profileBannerImage)
    SimpleDraweeView profileBannerImage;

    @Bind(R.id.profileGroup)
    ViewGroup profileGroup;
    @Bind(R.id.profileAvatar)
    SimpleDraweeView profileAvatar;
    @Bind(R.id.userName)
    TextView userName;
    @Bind(R.id.notSignInLabel)
    TextView notSignInLabel;
    @Bind(R.id.zmCredit)
    ViewGroup zmCreditLayout;
    @Bind(R.id.zmIcon)
    TextView zmIcon;
    @Bind(R.id.zmScore)
    TextView zmScore;
    @Bind(R.id.genderIcon)
    TextView genderIcon;

    @Bind(R.id.profileCompleteLayout)
    ViewGroup profileCompleteLayout;
    @Bind(R.id.completeRate)
    TextView completeRate;
    @Bind(R.id.moneyAmountLayout)
    ViewGroup moneyAmountLayout;
    @Bind(R.id.moneyValue)
    TextView moneyValue;
    @Bind(R.id.redpaperAmountLayout)
    ViewGroup redpaperAmountLayout;
    @Bind(R.id.redpaperValue)
    TextView redpaperValue;
    @Bind(R.id.mcoinAmountLayout)
    ViewGroup mcoinAmountLayout;
    @Bind(R.id.mcoinValue)
    TextView mcoinValue;

    @Bind(R.id.banner1)
    TextView bmoneyValueanner1;
    @Bind(R.id.grideView1)
    GridView gridView1;

    @Bind(R.id.banner2)
    TextView banner2;
    @Bind(R.id.grideView2)
    GridView gridView2;
    @Bind(R.id.grideView3)
    GridView gridView3;

    ProfileAdapter profileAdapter1;
    ProfileAdapter profileAdapter2;
    ProfileAdapter profileAdapter3;
    private LoadUtilV2 loadHelper;

    AdapterView.OnItemClickListener profileItemListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            View iconView = view.findViewById(R.id.profileIcon);
            ProfileAdapter.ProfileItem profileItem = (ProfileAdapter.ProfileItem) iconView.getTag();
            if (!TextUtils.isEmpty(profileItem.getAction()) && profileItem.getAction().startsWith("http://")) {
                Bundle bundle = new Bundle();
                bundle.putString("url", profileItem.getAction());
                Router.sharedRouter().open("web", bundle);
            } else if ("doBuyService".equals(profileItem.getAction())) {
                openActivity("buyOrders/" + OrderListActivity.ROLE_TYPE_BUY);
            } else if ("doGezi".equals(profileItem.getAction())) {
                openActivity("mysquares");
            } else if ("doSellService".equals(profileItem.getAction())) {
                openActivity("saleOrders/" + OrderListActivity.ROLE_TYPE_SELL);
            } else if ("doCertificate".equals(profileItem.getAction())) {
                openActivity("certificationlist");
            } else if ("deployedItem".equals(profileItem.getAction())) {
                openActivity("serviceListPublish");
            } else if ("doPhone".equals(profileItem.getAction())) {
                Helper.makeCall(getActivity(), kefuPhone);
            } else if ("doSetting".equals(profileItem.getAction())) {
                Router.sharedRouter().open("setting");
            } else if ("doFavorites".equals(profileItem.getAction())) {
                openActivity("favorites");
            } else if ("doPosts".equals(profileItem.getAction())) {
                openActivity("serviceListPublish");
            } else if ("doChat".equals(profileItem.getAction())) {
                String action = "chat/" + kefuId;
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open(action);
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString("action", action);
                    Router.sharedRouter().open("signin", bundle);
                }
            } else if (!TextUtils.isEmpty(profileItem.getAction()) && profileItem.getAction().startsWith("imlifer://")) {
                Router.sharedRouter().open(profileItem.getAction());
            } else if ("doDuoBao".equals(profileItem.getAction())) {
                openActivity("mylottery/all");
            }
        }
    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_profile, container, false);
            ButterKnife.bind(this, rootView);
            loadHelper = new LoadUtilV2(inflater);
            profileAdapter1 = new ProfileAdapter(getActivity(), buyerProfileItems);
            gridView1.setAdapter(profileAdapter1);

            profileAdapter2 = new ProfileAdapter(getActivity(), sellerProfileItems);
            gridView2.setAdapter(profileAdapter2);

            profileAdapter3 = new ProfileAdapter(getActivity(), settingProfileItems);
            gridView3.setAdapter(profileAdapter3);
        }
        return rootView;
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void onResume() {
        super.onResume();
        getMyProfile();
    }

    private void getMyProfile() {
        loadHelper.loadPre(rootLayout, scrollView);
        HttpClient.get("1.0/user/getUserMyPage", null, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        if (null == getActivity() || isDetached()) {
                            return;
                        }
                        loadHelper.loadSuccess(scrollView);
                        if (obj != null) {
                            loadHeader(obj.getJSONObject("base"));
                            loadAssetLayout(obj.getJSONObject("base"));
                            loadContent(obj.getJSONArray("sections"));
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        if (null == getActivity() || isDetached()) {
                            return;
                        }
                        loadHelper.loadFail(error, rootLayout, new LoadUtilV2.RetryCallback() {
                            @Override
                            public void retry() {
                                getMyProfile();
                            }
                        });
                    }
                });
    }

    private void loadHeader(JSONObject obj) {
        if (obj == null) {
            return;
        }
        final boolean isAuth = obj.containsKey("zmScore");

        kefuId = obj.getString("kefuId");
        //设置头像
        String userId = obj.getString("userId");
        String gender = obj.getString("gender");
        String cdnUrl = ImgUtil.getCDNUrlWithWidth(obj.getString("userAvatar"),
                getResources().getDimensionPixelSize(R.dimen.profile_normal_avatar_size));
        if (TextUtils.isEmpty(cdnUrl)) {
            Uri uri = ImgUtil.getDefaultAvatarUri(getActivity(), userId, gender);
            profileAvatar.setImageURI(uri);
        } else {
            profileAvatar.setImageURI(Uri.parse(cdnUrl));
        }
        //是指昵称和芝麻信用
        if (Helper.sharedHelper().hasToken()) {
            userName.setText(obj.getString("userNick"));
            notSignInLabel.setVisibility(View.GONE);
            zmCreditLayout.setVisibility(View.VISIBLE);
            if (isAuth) {
                zmIcon.setTextColor(getResources().getColor(R.color.zm_credit));
                zmScore.setTextColor(getResources().getColor(R.color.zm_credit));
                zmScore.setText("芝麻信用: " + obj.getString("zmScore"));
            } else {
                zmIcon.setTextColor(getResources().getColor(R.color.grey_c));
                zmScore.setTextColor(getResources().getColor(R.color.grey_c));
                zmScore.setText("绑定芝麻信用");
            }
            //设置性别
            if (Constant.GENDER_MAN.equals(gender)) {
                genderIcon.setText(R.string.icon_gender_m);
                genderIcon.setTextColor(getResources().getColor(R.color.brand_i));
            } else if (Constant.GENDER_WOMAN.equals(gender)) {
                genderIcon.setText(R.string.icon_gender_f);
                genderIcon.setTextColor(getResources().getColor(R.color.brand_b));
            } else {
                genderIcon.setVisibility(View.GONE);
            }
        } else {
            userName.setText(R.string.not_signin);
            notSignInLabel.setText(R.string.click_to_signin);
            notSignInLabel.setVisibility(View.VISIBLE);
            zmCreditLayout.setVisibility(View.GONE);
            genderIcon.setVisibility(View.GONE);
        }

        zmCreditLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://shenghuozhe.net/events/app_zmxy.html"; // 若未授权，跳转到授权页面
                if (isAuth) {
                    url = "https://xy.alipay.com/auth/whatszhima.htm?view=mobile";
                }
                Bundle bundle = new Bundle();
                bundle.putString("url", url);
                Router.sharedRouter().open("web", bundle);
            }
        });

        kefuPhone = obj.getString("kefuPhone");
        Helper.sharedHelper().setStringUserInfo(Constant.CUSTOMER_SERVICE_TEL, kefuPhone);

        profileGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open("profile/" + Helper.sharedHelper().getUserId());
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });

        if (obj.containsKey("infoCount")) {
            int infoCount = obj.getInteger("infoCount");
            completeRate.setText("完善度" + infoCount + "%");
            profileCompleteLayout.setVisibility(View.VISIBLE);
        } else {
            profileCompleteLayout.setVisibility(View.GONE);
        }

        loadBanner(obj.getJSONObject("banner"));
    }

    private void loadBanner(JSONObject obj) {
        if (obj == null) {
            return;
        }
        profileBanner.setText(obj.getString("text"));
        String cdnUrl = ImgUtil.getCDNUrlWithHeight(obj.getString("imageUrl"),
                getResources().getDimensionPixelSize(R.dimen.action_bar_height));
        profileBannerImage.setImageURI(Uri.parse(cdnUrl));
        final String linkUrl = obj.getString("url");
        if (!TextUtils.isEmpty(obj.getString("url"))) {
            profileBannerLayout.setVisibility(View.VISIBLE);
            profileBannerLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", linkUrl);
                    Router.sharedRouter().open("web", bundle);
                }
            });
        } else {
            profileBannerLayout.setVisibility(View.GONE);
        }
    }

    private void loadAssetLayout(JSONObject obj) {
        if (obj == null) {
            return;
        }
        final String moneySum = obj.containsKey("fundSum") ? obj.getString("fundSum") : ZERO;
        moneyValue.setText(moneySum);
        moneyAmountLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open("profile_money/" + moneySum);
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });
        String bonusNum = obj.containsKey("bonusNum") ? obj.getString("bonusNum") : ZERO;
        redpaperValue.setText(bonusNum);
        redpaperAmountLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open("redpaper");
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });
        mcoinValue.setText(obj.containsKey("pointSum") ? obj.getString("pointSum") : ZERO);
        mcoinAmountLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    //Router.sharedRouter().open("money_coin_detail/" + MoneyCoinDetailActivity.COIN_TYPE);
                    Router.sharedRouter().open("passphrase_input");
                } else {
                    Router.sharedRouter().open("signin");
                }
            }
        });
    }

    public void openActivity(String action) {
        if (Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().open(action);
        } else {
            Bundle bundle = new Bundle();
            bundle.putString("action", action);
            Router.sharedRouter().open("signin", bundle);
        }
    }


    private void loadContent(JSONArray sections) {
        if (null == sections || sections.isEmpty()) {
            return;
        }
        gridView1.setOnItemClickListener(profileItemListener);
        gridView2.setOnItemClickListener(profileItemListener);
        gridView3.setOnItemClickListener(profileItemListener);
        buyerProfileItems.clear();
        sellerProfileItems.clear();
        settingProfileItems.clear();

        for (int i = 0; i < sections.getJSONArray(0).size(); i++) {
            JSONObject item = sections.getJSONArray(0).getJSONObject(i);
            ProfileAdapter.ProfileItem profileItem = new ProfileAdapter.ProfileItem();
            profileItem.setTitle(item.getString("text"));
            profileItem.setBadge(item.getString("badge"));
            profileItem.setIconUrl(item.getString("iconURL"));
            profileItem.setAction(item.getString("action"));
            buyerProfileItems.add(profileItem);
        }

        if (!buyerProfileItems.isEmpty()) {
            profileAdapter1.setData(buyerProfileItems);
        }

        if (sections.size() > 1) {
            for (int i = 0; i < sections.getJSONArray(1).size(); i++) {
                JSONObject item = sections.getJSONArray(1).getJSONObject(i);
                ProfileAdapter.ProfileItem profileItem = new ProfileAdapter.ProfileItem();
                profileItem.setTitle(item.getString("text"));
                profileItem.setBadge(item.getString("badge"));
                profileItem.setIconUrl(item.getString("iconURL"));
                profileItem.setAction(item.getString("action"));
                sellerProfileItems.add(profileItem);
            }
        }

        if (!sellerProfileItems.isEmpty()) {
            profileAdapter2.setData(sellerProfileItems);
        }

        if (sections.size() > 2) {
            for (int i = 0; i < sections.getJSONArray(2).size(); i++) {
                JSONObject item = sections.getJSONArray(2).getJSONObject(i);
                ProfileAdapter.ProfileItem profileItem = new ProfileAdapter.ProfileItem();
                profileItem.setTitle(item.getString("text"));
                profileItem.setBadge(item.getString("badge"));
                profileItem.setIconUrl(item.getString("iconURL"));
                profileItem.setAction(item.getString("action"));
                settingProfileItems.add(profileItem);
            }
        }
        if (!settingProfileItems.isEmpty()) {
            profileAdapter3.setData(settingProfileItems);
        }
        profileAdapter1.notifyDataSetChanged();
        profileAdapter2.notifyDataSetChanged();
        profileAdapter3.notifyDataSetChanged();
    }
}

