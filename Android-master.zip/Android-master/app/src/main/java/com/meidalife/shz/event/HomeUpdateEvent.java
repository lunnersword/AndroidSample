package com.meidalife.shz.event;

import com.meidalife.shz.event.type.MsgTypeEnum;

/**
 * 首页推荐宝贝刷新
 */
public class HomeUpdateEvent extends BaseEvent {

    public HomeUpdateEvent() {
        super(MsgTypeEnum.TYPE_REFRESH);
    }

    public int position;

}
