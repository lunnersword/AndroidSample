package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.RedPaperAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.RedPaperItem;
import com.meidalife.shz.util.CollectionUtil;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 该笔订单可以适用红包列表
 * Created by zhq on 15/10/20.
 */
public class RedPaperListActivity extends BaseActivity {

    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.listView)
    ListView listView;
    //refresh layout
    @Bind(R.id.listViewSwipe)
    SwipeRefreshLayout mSwipeRefreshLayout;

    @Bind(R.id.action_bar_button_back)
    View action_bar_button_back;
    //tab未使用
    @Bind(R.id.index_coupon_unuse)
    TextView unUseTextView;
    //tab已使用
    @Bind(R.id.index_coupon_used)
    TextView usedTextView;

    //红包规则
    @Bind(R.id.iconRule)
    View iconRule;

    //红包为空 提示文案
    @Bind(R.id.redPaperListEmpty)
    View redPaperListEmpty;

    View listFooter;
    TextView footerMessage;
    ProgressBar footerLoading;
    Button footerReload;

    ArrayList<RedPaperItem> serviceItems = new ArrayList<RedPaperItem>();

    RedPaperAdapter adapter;
    int page = 1;//历史红包开始页数为1
    Boolean loading;
    Boolean complete;
    Boolean isRefresh;
    //    int type = 0;//type＝0未使用红包；type＝1已使用红包:type=2 适用订单的红包列表
    String type = "";//unuse:未使用 used:已经使用
    private static final int PAGE_SIZE = 5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coupon_list);
        ButterKnife.bind(this);

        //从我的tab页跳转过来
        action_bar_button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleBack(v);
            }
        });

        iconRule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://kongge.com/support/bonus_rule.html";
                Intent intent = new Intent();
                intent.setClass(RedPaperListActivity.this, WebActivity.class);
                intent.putExtra("url", url);
                startActivity(intent);
            }
        });

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            type = bundle.getString("type");
        }

        listFooter = getLayoutInflater().inflate(R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);
        listView.addFooterView(listFooter);
        listFooter.setVisibility(View.GONE);


        initAdapter();
        initListView();
        loadData();
    }


    private void loadData() {
        loading = false;
        complete = false;
        isRefresh = false;
        page = 1;

        serviceItems.clear();
        showStatusLoading(rootView);
        hideStatusErrorServer();
        hideStatusErrorNetwork();
        xhrServices();
    }

    private void initAdapter() {
        adapter = new RedPaperAdapter(this, serviceItems);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                LocationDO lbs = SHZApplication.getInstance().getLocationManager().getLocation();

                if (position < serviceItems.size()) {
                    RedPaperItem item = serviceItems.get(position);
                    if (item != null) {
                        item.setSelected(true);
                        //跳转到h5
                        if (item.getStatus() == 1) {
                            String url = "http://www.shenghuozhe.net/support/bonus.html?cityCode=" + lbs.getCityCode()
                                    + "&latitude=" + lbs.getLatitude() + "&longitude="
                                    + lbs.getLongitude() + "&promotionId=" + item.getPromotionId() +
                                    "&bonusId=" + item.getId();
                            Intent intent = new Intent();
                            intent.setClass(RedPaperListActivity.this, WebActivity.class);
                            intent.putExtra("url", url);
                            startActivity(intent);
                        }
                    }
                }
            }
        });
    }

    private void initListView() {
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                handleRefresh();
            }
        });
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {

            private boolean moveToBottom = false;
            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (previous < firstVisibleItem) {
                    moveToBottom = true;
                } else if (previous > firstVisibleItem) {
                    moveToBottom = false;
                }
                previous = firstVisibleItem;
                if (type.equals("used") && totalItemCount == firstVisibleItem + visibleItemCount && moveToBottom) {
                    /* 需要加载更多数据的代码 */
                    loadNext();
                }
            }
        });

        unUseTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                type = "unuse";
                setTitleStyle(true);
                loadData();
            }
        });

        usedTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                type = "used";
                setTitleStyle(false);
                loadData();
            }
        });
    }


    private void setTitleStyle(boolean canUse) {
        if (canUse) {
            //设置未使用红包不可点击
            unUseTextView.setClickable(false);
            unUseTextView.setTextColor(getResources().getColor(R.color.white));
            unUseTextView.setBackgroundResource(R.drawable.index_head_type_coupon_select_bg);

            //设置历史红包可点击
            usedTextView.setClickable(true);
            usedTextView.setTextColor(getResources().getColor(R.color.brand_c));
            usedTextView.setBackgroundResource(android.R.color.transparent);
        } else {
            //设置未使用红包可点击
            unUseTextView.setClickable(true);
            unUseTextView.setTextColor(getResources().getColor(R.color.brand_c));
            unUseTextView.setBackgroundResource(android.R.color.transparent);

            //设置历史红包不可点击
            usedTextView.setClickable(false);
            usedTextView.setTextColor(getResources().getColor(R.color.white));
            usedTextView.setBackgroundResource(R.drawable.index_head_type_coupon_select_bg);
        }
    }

    private JSONObject getParamsByPage(int page) {
        JSONObject params;
        try {
            params = new JSONObject();
            params.put("size", PAGE_SIZE);
            params.put("page", page);
        } catch (JSONException e) {
            params = null;
        }
        return params;
    }


    private void loadNext() {
        if (!loading && !complete) {
            page++;
            Log.i("Taber", "load next profile");
            xhrServices();
        }
    }

    private void xhrServices() {
        if (loading) {
            return;
        }
        listFooter.setVisibility(View.VISIBLE);
        loading = true;

        if (type.equals("used")) {
            HttpClient.get("1.0/redpack/getHistoricals", getParamsByPage(page), RedPaperItem.class, callback);
        } else {
            HttpClient.get("1.0/redpack/getAvailables", null, RedPaperItem.class, callback);
        }
    }

    HttpClient.HttpCallback callback = new HttpClient.HttpCallback() {
        @Override
        public void onSuccess(Object result) {
            loading = false;
            hideStatusLoading();
            listFooter.setVisibility(View.GONE);

            ArrayList<RedPaperItem> items = (ArrayList<RedPaperItem>) result;
            if (CollectionUtil.isEmpty(items) || items.size() < PAGE_SIZE) {
                complete = true;
            }
            if (isRefresh) {
                isRefresh = false;
                serviceItems.clear();
                mSwipeRefreshLayout.setRefreshing(false);
            }
            serviceItems.addAll(items);
            adapter.notifyDataSetChanged();

            // 空数据
            if (CollectionUtil.isEmpty(serviceItems)) {
                redPaperListEmpty.setVisibility(View.VISIBLE);
                mSwipeRefreshLayout.setVisibility(View.GONE);
            } else {
                redPaperListEmpty.setVisibility(View.GONE);
                mSwipeRefreshLayout.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void onFail(HttpError error) {
            loading = false;
            hideStatusLoading();
            listFooter.setVisibility(View.GONE);

            if (page == 1) {
                // refresh
                mSwipeRefreshLayout.setRefreshing(false);

                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView);
                    setOnClickErrorNetwork(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            loadData();
                        }
                    });
                    return;
                }

                showStatusErrorServer(rootView);
                setTextErrorServer(error != null ? error.getMessage() : getResources().getString(R.string.error_server_500));
                setOnClickErrorServer(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        loadData();
                    }
                });
            } else {
                // load next
                page--;
                if (error != null) {
                    if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                        footerReload.setText("网络异常，点击重试");
                    } else {
                        footerReload.setText(error.getMessage() + "，点击重试");
                    }
                } else {
                    footerReload.setText("发生一个未知错误，点击重试");
                }
                footerReload.setVisibility(View.VISIBLE);
                footerLoading.setVisibility(View.GONE);
                footerMessage.setVisibility(View.GONE);
                footerReload.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        footerLoading.setVisibility(View.VISIBLE);
                        footerReload.setVisibility(View.GONE);
                        loadNext();
                    }
                });
            }
        }
    };

    private void handleRefresh() {
        isRefresh = true;
        page = 1;
        Log.i("Taber", "refresh profile");
        xhrServices();
    }

}
