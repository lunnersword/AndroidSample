package com.meidalife.shz.activity;

import android.location.Location;
import android.os.Bundle;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationListener;
import com.amap.api.location.LocationManagerProxy;
import com.amap.api.location.LocationProviderProxy;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.LocationSource;
import com.amap.api.maps.MapView;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;

/**
 * Created by fufeng on 15/12/27.
 */
public class ViewLocationActivity extends BaseActivity {
    public final static String LOCATION_LAT = "location_lat";
    public final static String LOCATION_LNG = "location_lng";
    private AMap aMap;
    private MapView mapView;
    private Marker mLocationMarker;
    private LocationManagerProxy mAMapLocationManager;
    private LatLng mLocationLatLng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_view_location);
        initActionBar("位置", true, false);

        // 如果传进来的是有地址的，就先定位到这里， 如果没有，那么定位到当前的位置
        Double lat = getIntent().getDoubleExtra(LOCATION_LAT, 0);
        Double lng = getIntent().getDoubleExtra(LOCATION_LNG, 0);
        if (0 != lat && 0 != lng) {
            mLocationLatLng = new LatLng(lat, lng);
        } else {
            mLocationLatLng = null;
        }

        initView(null);
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mapView != null) {
            try {
                mapView.onDestroy();
            } catch (Throwable e) {
            }
        }
        if (null != aMap) {
            aMap.clear();
            aMap = null;
        }
        if (null != mAMapLocationManager) {
            mAMapLocationManager.destroy();
            mAMapLocationManager = null;
        }
        mLocationLatLng = null;
    }

    /**
     * 方法必须重写
     */
    @Override
    public void onResume() {
        super.onResume();
        if (mapView != null)
            mapView.onResume();
    }

    /**
     * 方法必须重写
     */
    @Override
    public void onPause() {
        super.onPause();
        if (mapView != null)
            mapView.onPause();
        if (null != locationSource)
            locationSource.deactivate();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mapView != null)
            mapView.onSaveInstanceState(outState);
    }


    private void initView(Bundle savedInstanceState) {
        mapView = (MapView) findViewById(R.id.map);

        try {
            mapView.onCreate(savedInstanceState);
        } catch (Throwable t) {
            MessageUtils.showToast("亲，内存不足，无法打开地图，请返回重试");
            finish();
            return;
        }

        if (!setUpMapIfNeeded()) {
            finish();
        }
    }

    private boolean setUpMapIfNeeded() {
        if (aMap == null) {
            aMap = mapView.getMap();
            if (aMap == null) {
                MessageUtils.showToast("地图初始化失败");
                return false;
            }
        }

        aMap.getUiSettings().setZoomControlsEnabled(false);// 设置系统默认缩放按钮可见
        //aMap.setOnCameraChangeListener(cameraChangeListener);
        mAMapLocationManager = LocationManagerProxy.getInstance(this);
        //aMap.setLocationSource(locationSource);
        aMap.setMyLocationEnabled(true);// 设置为true表示系统定位按钮显示并响应点击，false表示隐藏，默认是false
        aMap.getUiSettings().setMyLocationButtonEnabled(false);
        aMap.getUiSettings().setTiltGesturesEnabled(false);

        if (mLocationLatLng != null) {
            addMarker(mLocationLatLng, "");
            aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(
                    mLocationLatLng, 15));
        }

        return true;
    }

    LocationSource locationSource = new LocationSource() {

        @Override
        public void deactivate() {
            if (mAMapLocationManager != null) {
                mAMapLocationManager.removeUpdates(aMapLocationListener);
                mAMapLocationManager.destroy();
            }
            mAMapLocationManager = null;
        }

        @Override
        public void activate(OnLocationChangedListener listener) {
            if (mAMapLocationManager == null) {
                mAMapLocationManager = LocationManagerProxy
                        .getInstance(ViewLocationActivity.this);
            }
            /*
             * mAMapLocManager.setGpsEnable(false);//
			 * 1.0.2版本新增方法，设置true表示混合定位中包含gps定位，false表示纯网络定位，默认是true
			 */
            // Location API定位采用GPS和网络混合定位方式，时间最短是5000毫秒
            // PendingIntent
            mAMapLocationManager.requestLocationUpdates(
                    LocationProviderProxy.AMapNetwork, 5000, 10,
                    aMapLocationListener);
        }
    };

    AMapLocationListener aMapLocationListener = new AMapLocationListener() {

        @Override
        public void onLocationChanged(AMapLocation aLocation) {
            if (aLocation != null) {
                String desc = "";
                Double geoLat = aLocation.getLatitude();
                Double geoLng = aLocation.getLongitude();
                if (null == mLocationLatLng) {
                    mLocationLatLng = new LatLng(geoLat, geoLng);

                    Bundle locBundle = aLocation.getExtras();
                    if (locBundle != null) {
                        desc = locBundle.getString("desc");
                    }
                }
                addMarker(mLocationLatLng, desc);
                aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(
                        mLocationLatLng, 15));
                locationSource.deactivate();
            }
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onLocationChanged(Location location) {
        }

    };

    AMap.OnCameraChangeListener cameraChangeListener = new AMap.OnCameraChangeListener() {

        @Override
        public void onCameraChangeFinish(CameraPosition position) {
            if (null != mLocationMarker) {

            }
        }

        @Override
        public void onCameraChange(CameraPosition position) {
            if (mLocationMarker != null) {
                mLocationLatLng = position.target;
                mLocationMarker.setPosition(position.target);
            }
        }
    };

    /**
     * 往地图上添加marker
     *
     * @param latLng
     */
    private void addMarker(LatLng latLng, String desc) {
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("[位置]");
        markerOptions.snippet(desc);
        markerOptions.anchor(0.5f, 1f);
        markerOptions.draggable(true);
        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
        mLocationMarker = aMap.addMarker(markerOptions);
    }
}
