package com.meidalife.shz.adapter;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SquareCateDO;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.rest.model.UserDO;
import com.meidalife.shz.widget.SurroundSquareDividerItemDecoration;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 周边格子列表 item adapter
 * Created by zhq on 15/12/20.
 */
public class SurroundSquareAdapter extends RecyclerView.Adapter<SurroundSquareAdapter.ViewHolder> {
    LayoutInflater mInflater;
    Context mContext;
    List<SquareDO> mData;

    private final int userAvatarMaxSize = 6;
    private final int serviceMaxSize = 2;

    private boolean isFirst = true;

    static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.rootView)
        View rootView;

        //格子名称
        @Bind(R.id.squareNme)
        TextView squareNme;
        @Bind(R.id.squareType)
        TextView squareType;

        //格主信息
        @Bind(R.id.gezuInfoView)
        View gezuInfoView;
        @Bind(R.id.squareManagerNick)
        TextView squareManagerNick;
        @Bind(R.id.squareManagerGender)
        TextView squareManagerGender;

        //服务数
        @Bind(R.id.serviceCount)
        TextView serviceCount;

        //人气
        @Bind(R.id.squarePopular)
        TextView squarePopular;

        //人数
        @Bind(R.id.userCount)
        TextView userCount;

        //成员头像列表
        @Bind(R.id.avatar_recycler_view)
        RecyclerView avatarRecyclerView;

        @Bind(R.id.service_recycler_view)
        RecyclerView serviceRecyclerView;

        @Bind(R.id.join_status)
        TextView join_status;

    }

    public SurroundSquareAdapter(Context context, List<SquareDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    public void setData(List<SquareDO> mData) {
        this.mData = mData;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = mInflater.inflate(R.layout.item_surround_square, parent, false);
        ViewHolder holder = new ViewHolder(convertView);

        int spacingInPixels = mContext.getResources().getDimensionPixelSize(R.dimen.discover_item_margin);
        holder.serviceRecyclerView.addItemDecoration(new SurroundSquareDividerItemDecoration(spacingInPixels));
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final SquareDO item = mData.get(position);

        holder.squareNme.setText(item.getGeziName());
        holder.squareType.setText("[" + item.getGeziTypeDesc() + "]");

        //todo 格主 格主性别 暂时不显示
        UserDO gezhu = item.getGezhu();
        if (gezhu != null) {
            holder.gezuInfoView.setVisibility(View.VISIBLE);
            holder.squareManagerNick.setText(String.format(mContext.getResources().getString(R.string.str_square_manager), gezhu.getUserNick()));
            if (gezhu.getUserGender() != null) {
                holder.squareManagerNick.setVisibility(View.VISIBLE);
                if (gezhu.getUserGender().equals("woman") || gezhu.getUserGender().equals("F")) {
                    holder.squareManagerGender.setText(mContext.getResources().getString(R.string.icon_gender_f));
                    holder.squareManagerGender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                } else {
                    holder.squareManagerGender.setText(mContext.getResources().getString(R.string.icon_gender_m));
                    holder.squareManagerGender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
                }
            } else {
                holder.squareManagerGender.setVisibility(View.GONE);
                holder.squareManagerGender.setText("");
            }
        } else {
            holder.gezuInfoView.setVisibility(View.GONE);
            holder.squareManagerNick.setText("");
            holder.squareManagerGender.setText("");
        }
        //服务数,人气,成员
        holder.serviceCount.setText(String.format(mContext.getResources().getString(R.string.str_square_service_count), item.getItemCount()));
        holder.squarePopular.setText(String.format(mContext.getResources().getString(R.string.str_square_popular), item.getPopularity()));
        holder.userCount.setText(String.format(mContext.getResources().getString(R.string.str_square_member), item.getUserCount()));

        //设置头像
        showUserAvatar(holder.avatarRecyclerView, item.getUserList());

        //服务
        if (item.getCategoryList() == null || item.getCategoryList().size() <= 0) {
            List cateList = new ArrayList<>();
            cateList.add(new SquareCateDO());
            cateList.add(new SquareCateDO());
            item.setCategoryList(cateList);
        }
        showService(holder.serviceRecyclerView, item.getCategoryList());

        //
        int sdk = android.os.Build.VERSION.SDK_INT;
        if (item.isJoined()) {
            holder.join_status.setText("已加入");
            if (sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
                holder.join_status.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.bg_surround_square_joined));
            } else {
                holder.join_status.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.bg_surround_square_joined));
            }
        } else {
            holder.join_status.setText("未加入");
            if (sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
                holder.join_status.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.bg_surround_square_unjoin));
            } else {
                holder.join_status.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.bg_surround_square_unjoin));
            }

        }

        holder.rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("squareindex/" + item.getGeziId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void showUserAvatar(RecyclerView recyclerView, List<UserDO> datalist) {

        recyclerView.removeAllViews();
        if (datalist == null || datalist.size() <= 0) {
            recyclerView.setVisibility(View.GONE);
            return;
        }

        int end = Math.min(userAvatarMaxSize, datalist.size());
        datalist = datalist.subList(0, end);


        recyclerView.setVisibility(View.VISIBLE);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(new UserAvatarAdapter(mContext, datalist));
    }

    void showService(RecyclerView recyclerView, List<SquareCateDO> dataList) {

        recyclerView.removeAllViews();
        if (dataList == null || dataList.size() <= 0) {
            recyclerView.setVisibility(View.GONE);
            return;
        }
        recyclerView.setVisibility(View.VISIBLE);

        recyclerView.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

//        int spacingInPixels = mContext.getResources().getDimensionPixelSize(R.dimen.discover_item_margin);
//        recyclerView.addItemDecoration(new SurroundSquareDividerItemDecoration(spacingInPixels));

        int end = Math.min(serviceMaxSize, dataList.size());
        dataList = dataList.subList(0, end);
        recyclerView.setAdapter(new SquareServiceAdapter(mContext, dataList));
    }
}
