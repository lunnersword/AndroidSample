package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;

/**
 * Created by xingchen on 2015/12/22.
 */
public class SquareManageCategoryOrderAdapter extends BaseAdapter{
    private Context context;
    private LayoutInflater mInflater;
    private JSONArray categoryList;
    private View.OnClickListener onClickListener;
    private int selectPos = -1;

    public SquareManageCategoryOrderAdapter(Context context,JSONArray categoryList,View.OnClickListener onClickListener){
        this.context = context;
        this.onClickListener = onClickListener;
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.categoryList = categoryList;
    }

    public void setSelectPos(int selectPos){
        this.selectPos = selectPos;
    }

    public int getSelectPos(){
        return selectPos;
    }

    @Override
    public int getCount() {
        return categoryList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.item_square_manage_category_order,parent,false);
            holder = new ViewHolder();
            holder.categoryName = (TextView)convertView.findViewById(R.id.categoryName);
            holder.downView = (TextView)convertView.findViewById(R.id.downView);
            holder.upView = (TextView)convertView.findViewById(R.id.upView);
            holder.picView = (SimpleDraweeView)convertView.findViewById(R.id.picView);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder)convertView.getTag();
        }
        JSONObject item = categoryList.getJSONObject(position);
        StringBuilder sb = new StringBuilder();
        if(item.containsKey("categoryName"))
            sb.append(item.getString("categoryName"));
        if(item.containsKey("itemCount"))
            sb.append("（"+item.getString("itemCount")+"）");
        holder.categoryName.setText(sb.toString());
        if(item.containsKey("picUrl"))
            holder.picView.setImageURI(Uri.parse(item.getString("picUrl")));
        if(onClickListener != null){
            holder.upView.setOnClickListener(onClickListener);
            holder.downView.setOnClickListener(onClickListener);
        }
        holder.downView.setVisibility(View.GONE);
        holder.upView.setVisibility(View.GONE);
        if(selectPos == position && categoryList.size()>1){
            holder.downView.setVisibility(View.VISIBLE);
            holder.upView.setVisibility(View.VISIBLE);
            holder.upView.setEnabled(true);
            holder.downView.setEnabled(true);
            if(position == 0){
                holder.upView.setTextColor(context.getResources().getColor(R.color.grey_c));
                holder.upView.setEnabled(false);
                holder.downView.setTextColor(convertView.getResources().getColor(R.color.grey_a));
            }
            else if(position == categoryList.size()-1){
                holder.upView.setTextColor(context.getResources().getColor(R.color.grey_a));
                holder.downView.setEnabled(false);
                holder.downView.setTextColor(convertView.getResources().getColor(R.color.grey_c));
            }else{
                holder.upView.setTextColor(context.getResources().getColor(R.color.grey_a));
                holder.downView.setTextColor(convertView.getResources().getColor(R.color.grey_a));
            }

        }

        return convertView;
    }

    static class ViewHolder{

        SimpleDraweeView picView;
        TextView categoryName;
        TextView downView;
        TextView upView;
    }
}
