package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SquareItem;
import com.meidalife.shz.widget.CheckableIconText;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by fufeng on 15/12/18.
 */
public class JoinedSquareListAdapter extends RecyclerView.Adapter<JoinedSquareListAdapter.ViewHolder> {
    private List<SquareItem> data = new ArrayList<>();
    private Context mContext;
    private Set<String> selectedSquareIds = new HashSet<>();
    private LayoutInflater inflater;

    public JoinedSquareListAdapter(Context context, List<SquareItem> data) {
        mContext = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        setData(data);
    }

    public void setData(List<SquareItem> data) {
        this.data = data;
        for (SquareItem item : data) {
            if (item.getSelected()) {
                selectedSquareIds.add(item.getId());
            }
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_joined_square, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final SquareItem squareItem = data.get(position);
        holder.squareName.setText(squareItem.getName());
        holder.squareDesc.setText(String.format("服务数：%1$s   成员数：%2$s", squareItem.getItemCount(),
                squareItem.getUserCount()));
        if (!TextUtils.isEmpty(squareItem.getPicUrl())) {
            holder.squareIcon.setImageURI(Uri.parse(squareItem.getPicUrl()));
        }
        holder.checkableIconText.setChecked(selectedSquareIds.contains(squareItem.getId()));
        holder.squareType.setText(String.format("[%s]", squareItem.getDescription()));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.checkableIconText.toggle();
                if (holder.checkableIconText.isChecked()) {
                    selectedSquareIds.add(squareItem.getId());
                } else {
                    selectedSquareIds.remove(squareItem.getId());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public Set<String> getSelectedItems() {
        return selectedSquareIds;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private SimpleDraweeView squareIcon;
        private TextView squareName;
        private TextView squareType;
        private TextView squareDesc;
        private CheckableIconText checkableIconText;

        public ViewHolder(View itemView) {
            super(itemView);
            squareDesc = (TextView) itemView.findViewById(R.id.squareDesc);
            squareIcon = (SimpleDraweeView) itemView.findViewById(R.id.squareIcon);
            squareType = (TextView) itemView.findViewById(R.id.squareType);
            squareName = (TextView) itemView.findViewById(R.id.squareName);
            checkableIconText = (CheckableIconText) itemView.findViewById(R.id.checkbox);
        }
    }
}
