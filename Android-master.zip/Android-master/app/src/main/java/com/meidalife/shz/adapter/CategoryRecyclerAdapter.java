package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;


/**
 * 服务社-一级类目
 * Created by xingchen on 2015/12/15.
 */
public class CategoryRecyclerAdapter extends RecyclerView.Adapter<CategoryRecyclerAdapter.ViewHolder> {
    private Context context;
    private JSONArray categoryList;
    private LayoutInflater mInflater;

    public CategoryRecyclerAdapter(Context context, JSONArray categoryList) {
        this.context = context;
        this.categoryList = categoryList;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = mInflater.inflate(R.layout.item_category_recycler, parent, false);
        ViewHolder holder = new ViewHolder(convertView);
        holder.categoryName = (TextView) convertView.findViewById(R.id.categoryName);
        holder.itemCount = (TextView) convertView.findViewById(R.id.itemCount);
        holder.icon = (SimpleDraweeView) convertView.findViewById(R.id.icon);
        return holder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

        final JSONObject item = categoryList.getJSONObject(position);
        if(item.containsKey("picUrl")){
            String cdnUrl = ImgUtil.getCDNUrlWithWidth(item.getString("picUrl"), context.getResources().getDimensionPixelSize(R.dimen.emotion_icon_size));
            holder.icon.setImageURI(Uri.parse(cdnUrl));
        }
        if(item.containsKey("categoryName"))
            holder.categoryName.setText(item.getString("categoryName"));
        if(item.containsKey("itemCount"))
            holder.itemCount.setText(item.getIntValue("itemCount") + "人");
        holder.icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(item.containsKey("geziId") && item.containsKey("categoryId"))
                    Router.sharedRouter().open("categorySquareService/" + item.getIntValue("geziId") +"/"+item.getIntValue("categoryId"));
            }
        });

    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        SimpleDraweeView icon;
        TextView categoryName;
        TextView itemCount;

        public ViewHolder(View itemView) {
            super(itemView);
        }
    }

    public void setCategoryList(JSONArray categoryList) {
        this.categoryList = categoryList;
    }
}
