package com.meidalife.shz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.CategoryDO;

import java.util.ArrayList;


/**
 */
public class HomeTabAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private ArrayList<CategoryDO> tabList;

    public HomeTabAdapter(Context mContext, ArrayList<CategoryDO> tabList) {
        this.mInflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
        this.tabList = tabList;
    }

    @Override
    public int getCount() {
        return tabList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        CategoryDO cate = tabList.get(position);
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_home_tab_category, parent, false);
            holder = new ViewHolder();
            holder.filterTab = (TextView) convertView.findViewById(R.id.filterTab);
            holder.isSelect = convertView.findViewById(R.id.isSelect);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.filterTab.setText(cate.getCatName());
        if (cate.isClicked()) {
            holder.isSelect.setVisibility(View.VISIBLE);
        } else {
            holder.isSelect.setVisibility(View.INVISIBLE);
        }

        return convertView;
    }

    static class ViewHolder {
        TextView filterTab;
        View isSelect;
    }

}
