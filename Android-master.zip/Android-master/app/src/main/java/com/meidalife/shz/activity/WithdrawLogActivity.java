package com.meidalife.shz.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.WithdrawLogAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.WithdrawLogDO;
import com.meidalife.shz.rest.request.RequestWithdraw;
import com.meidalife.shz.util.CollectionUtil;

import java.util.List;

/**
 * Created by shijian on 15/7/20.
 */
public class WithdrawLogActivity extends BaseActivity {

    private LayoutInflater inflater;
    private Context context;

    private ViewGroup rootView;
    private View contentRoot;

    private int page = 0;

    private ListView listView;
    private SwipeRefreshLayout swipeList;
    private WithdrawLogAdapter adapter;
    private View noDataView;
    private View listFooter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.money_withdraw_log);
        initActionBar(R.string.title_withdraw_log, true);

        inflater = getLayoutInflater();
        context = getApplicationContext();

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);

        listView = (ListView) findViewById(R.id.withdraw_log_listview);
        swipeList = (SwipeRefreshLayout) findViewById(R.id.withdraw_log_list_swipe);
        swipeList.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refresh();
            }
        });

        View footView = inflater.inflate(R.layout.view_list_footer, null);
        listView.addFooterView(footView);
        listFooter = footView.findViewById(R.id.loadingView);
        listFooter.setVisibility(View.GONE);

        noDataView = findViewById(R.id.no_data_group);
        TextView nodataIcon = (TextView) findViewById(R.id.no_data_icon);
        nodataIcon.setTypeface(Helper.sharedHelper().getIconFont());

        WithdrawLogScrollListener scrollListener = new WithdrawLogScrollListener();
        listView.setOnScrollListener(scrollListener);

        initLoadData();
    }

    public void initLoadData() {

        loadPre(rootView, contentRoot);
        page = 0;
        RequestWithdraw.getWithdrawList(page, new HttpClient.HttpCallback<List<WithdrawLogDO>>() {
            @Override
            public void onSuccess(List<WithdrawLogDO> dataList) {
                loadSuccess(contentRoot);
//                List<WithdrawLogDO> dataList = (List<WithdrawLogDO>) result;
                if (CollectionUtil.isEmpty(dataList)) {
                    noDataView.setVisibility(View.VISIBLE);
                    swipeList.setVisibility(View.GONE);
                } else {
                    swipeList.setVisibility(View.VISIBLE);
                    noDataView.setVisibility(View.GONE);
                    adapter = new WithdrawLogAdapter(inflater, context, dataList);
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFail(HttpError error) {
                loadFail(error, rootView, WithdrawLogActivity.this, new LoadCallback() {
                    @Override
                    public void execute() {
                        initLoadData();
                    }
                });
            }
        });
    }

    public void refresh() {
        page = 0;
        RequestWithdraw.getWithdrawList(page, new HttpClient.HttpCallback<List<WithdrawLogDO>>() {
            @Override
            public void onSuccess(List<WithdrawLogDO> dataList) {
                swipeList.setRefreshing(false);
//                List<WithdrawLogDO> dataList = (List<WithdrawLogDO>) result;
                if (CollectionUtil.isEmpty(dataList)) {
                    noDataView.setVisibility(View.VISIBLE);
                    swipeList.setVisibility(View.GONE);
                } else {
                    noDataView.setVisibility(View.GONE);
                    swipeList.setVisibility(View.VISIBLE);
                    adapter.setDataList(dataList);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFail(HttpError error) {
                swipeList.setRefreshing(false);
                MessageUtils.showToastCenter(error.getMessage());
            }
        });
    }


    class WithdrawLogScrollListener implements AbsListView.OnScrollListener {

        private boolean isMoreData = true;
        private boolean isLoading = false;
        private int previous;

        @Override
        public void onScrollStateChanged(AbsListView view, int scrollState) {
        }

        @Override
        public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            if (!isMoreData) {
                return;
            }
            if (isLoading) { // 若已经在加载中，则忽略
                return;
            }
            boolean moveToBottom = false;
            if (previous < firstVisibleItem) {
                moveToBottom = true;
            }
            previous = firstVisibleItem;
            if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
                isLoading = true;
                listFooter.setVisibility(View.VISIBLE);
                page++;
                RequestWithdraw.getWithdrawList(page, new HttpClient.HttpCallback<List<WithdrawLogDO>>() {
                    @Override
                    public void onSuccess(List<WithdrawLogDO> dataList) {
                        listFooter.setVisibility(View.GONE);
//                        List<WithdrawLogDO> dataList = (List<WithdrawLogDO>) result;
                        isLoading = false;
                        if (CollectionUtil.isEmpty(dataList)) {
                            isMoreData = false;
                        } else {
                            adapter.addDataList(dataList);
                            adapter.notifyDataSetChanged();
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        page--;
                        isLoading = false;
                        MessageUtils.showToastCenter(error.getMessage());
                    }
                });
            }
        }

    }


}
