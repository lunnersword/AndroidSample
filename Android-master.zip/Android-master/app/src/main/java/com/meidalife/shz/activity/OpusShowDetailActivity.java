package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ViewAnimator;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.OpusShowAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.MyListView;
import com.meidalife.shz.widget.PopupListMenu;
import com.usepropeller.routable.Router;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/9/25.
 */
public class OpusShowDetailActivity extends BaseActivity {
    private static final String TAG_OPUS_ID = "opusId";

    private static final int CHILD_ID_LOADING = 0;
    private static final int CHILD_ID_OPUS_SHOW = 1;
    private static final int CHILD_ID_NETWORK_ERROR = 2;
    private static final int CHILD_ID_SERVER_ERROR = 3;

    private static final int MENU_ITEM_CANCEL = 1;
    private static final int MENU_ITEM_REPORT = 0;
    @Bind(R.id.opus_show_container)
    ViewAnimator opusViewAnimator;
    @Bind(R.id.avatar)
    SimpleDraweeView avatar;
    @Bind(R.id.opus_show_list)
    MyListView opusShowList;
    @Bind(R.id.gender)
    TextView gender;
    @Bind(R.id.user_name)
    TextView userName;
    @Bind(R.id.chat_button)
    Button chatButton;
    @Bind(R.id.opus_show_description)
    TextView opusDescription;
    @Bind(R.id.opus_show_view_count)
    TextView viewCount;

    @Bind(R.id.opus_show_publish_time)
    TextView opusPublishTime;

    @Bind(R.id.service_link_layout)
    RelativeLayout serviceLinkLayout;
    @Bind(R.id.service_image)
    SimpleDraweeView serviceImage;
    @Bind(R.id.service_title)
    TextView serviceTitle;
    @Bind(R.id.service_price)
    TextView servicePrice;
    @Bind(R.id.service_type)
    TextView serviceType;

    @Bind(R.id.textStatusErrorServer)
    TextView serverErrorMessage;

    @Bind(R.id.fromService)
    TextView fromService;

    private String opusId;
    private OpusShowAdapter opusShowAdapter;
    private PopupListMenu mPopupListMenu;
    private List<String> opusData = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opus_show_detail);
        initActionBar(R.string.opus_detail_title, true, true);
        ButterKnife.bind(this);

        opusId = getIntent().getStringExtra(TAG_OPUS_ID);

        initComponents();

        loadOpusShowDetail();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void initComponents() {
        opusShowAdapter = new OpusShowAdapter(this, opusData);
        opusShowList.setAdapter(opusShowAdapter);

        mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHidePopMenu(v);
            }
        });
    }

    private void loadOpusShowDetail() {
        if (!Helper.isNetworkConnected(this)) {
            opusViewAnimator.setDisplayedChild(CHILD_ID_NETWORK_ERROR);
            return;
        }
        opusViewAnimator.setDisplayedChild(CHILD_ID_LOADING);
        JSONObject params = new JSONObject();
        params.put(TAG_OPUS_ID, opusId);

        HttpClient.get("1.0/opus/get", params, JSONObject.class, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                JSONObject result = (JSONObject) obj;
                loadHeader(result);
                loadOpusImageList(result);
                loadFooter(result);

                opusViewAnimator.setDisplayedChild(CHILD_ID_OPUS_SHOW);
            }

            @Override
            public void onFail(HttpError error) {
                opusViewAnimator.setDisplayedChild(CHILD_ID_SERVER_ERROR);
                serverErrorMessage.setText(TextUtils.isEmpty(error.getMessage()) ?
                        getString(R.string.opus_show_not_exist) : error.getMessage());
            }
        });
    }

    private void loadHeader(JSONObject data) {
        JSONObject userInfo = data.getJSONObject("user");
        final String userId = userInfo.getString("userId");
        String cdnUrl = ImgUtil.getCDNUrlWithHeight(userInfo.getString("userAvatar"),
                getResources().getDimensionPixelSize(R.dimen.opus_avatar_size));

        userName.setText(userInfo.getString("userName"));
        avatar.setImageURI(Uri.parse(cdnUrl));
        avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("profile/" + userId);
            }
        });

        String userGender = userInfo.getString("gender");
        if (getString(R.string.gender_man).equals(userGender)) {
            gender.setText(R.string.icon_gender_m);
            gender.setTextColor(getResources().getColor(R.color.brand_i));
        } else {
            gender.setText(R.string.icon_gender_f);
            gender.setTextColor(getResources().getColor(R.color.brand_b));
        }

        opusDescription.setText(data.getString("description"));

        chatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("chat/" + userId);
            }
        });
    }

    private void loadOpusImageList(JSONObject data) {
        JSONArray imageArray = data.getJSONArray("images");
        for (int index = 0; index < imageArray.size(); index++) {
            opusData.add(imageArray.getString(index));
        }
        if (!opusData.isEmpty()) {
            opusShowAdapter.updateOpusShow(opusData);
            opusShowAdapter.notifyDataSetChanged();
        }
    }

    private void loadFooter(JSONObject data) {
        long publishTime = data.getLong("createTime") * 1000;
        SimpleDateFormat format = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault());
        Date date = new Date(publishTime);
        String readableTime = format.format(date);
        opusPublishTime.setText(String.format(getString(R.string.opus_show_publish_at), readableTime));

        int count = data.getInteger("viewCount");
        if (count >= 0) {
            viewCount.setText(String.format(getString(R.string.view_count), count));
        }

        JSONObject serviceInfo = data.getJSONObject("item");
        if (serviceInfo == null) {
            serviceLinkLayout.setVisibility(View.GONE);
            fromService.setVisibility(View.GONE);
            return;
        }
        servicePrice.setText(serviceInfo.getString("price"));
        serviceTitle.setText(String.format(getString(R.string.service_i_can), serviceInfo.getString("tag")));

        JSONArray imageArray = serviceInfo.getJSONArray("images");
        if (imageArray.size() > 0) {
            String cdnUrl = ImgUtil.getCDNUrlWithHeight(imageArray.getString(0),
                    getResources().getDimensionPixelSize(R.dimen.opus_service_image_size));

            serviceImage.setImageURI(Uri.parse(cdnUrl));
        }

        final String itemId = serviceInfo.getString("itemId");
        serviceLinkLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("detail/" + itemId);
            }
        });

        final String cityName = serviceInfo.getString("cityName");
        int serviceType = serviceInfo.getInteger("serviceType");
        String serviceTypeString = "";
        String[] serviceTypes = getResources().getStringArray(R.array.serviceType);
        switch (serviceType) {
            case 1:
            case 2:
                serviceTypeString = cityName + serviceTypes[serviceType - 1];
                break;
            case 3:
            case 4:
                serviceTypeString = serviceTypes[serviceType - 1];
                break;
        }
        this.serviceType.setText(serviceTypeString);
    }

    private void showOrHidePopMenu(View v) {
        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(this);
        }

        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_CANCEL: {
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_REPORT:{
                        doReport();
                        mPopupListMenu.dismiss();
                        break;
                    }
                }
            }
        });

        List<String> menuList = new ArrayList<>();

        menuList.add(MENU_ITEM_REPORT, getString(R.string.report));
        menuList.add(MENU_ITEM_CANCEL, getString(R.string.cancel));

        mPopupListMenu.setMenuData(menuList);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private void doReport() {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", String.valueOf(opusId));
        intent.putExtra("target", Constant.REPORT_TYPE_OPUS);
        startActivity(intent);
    }
}
