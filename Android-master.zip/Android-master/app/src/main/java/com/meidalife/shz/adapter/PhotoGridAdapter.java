package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by taber on 15/6/11.
 */
public class PhotoGridAdapter extends BaseAdapter {

    private static final int TYPE_COUNT = 2;

    private static int VIEW_TYPE_BUTTON = 1;
    private static int VIEW_TYPE_IMAGE = 2;

    private int itemWidth;
    private int itemHeight;
    private Context mContext;
    private ArrayList<String> mImages;
    private LayoutInflater mInflater;
    private PhotoGridAdapter.OnClickListener mOnClickListener;

    private ArrayList<String> selectImages;

    static class ImageHolder {
        public ImageView image;
        public TextView checkbox;
    }

    static class ButtonHolder {
        public Button button;
    }

    public PhotoGridAdapter(Context c, ArrayList<String> images) {
        mContext = c;
        mImages = images;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        float deviceWidth = mContext.getResources().getDisplayMetrics().widthPixels;
        float sumWidth = deviceWidth - Helper.convertDpToPixel((float) 6, mContext) * 4;
        itemWidth = Math.round(sumWidth / 3);
        itemHeight = itemWidth;
    }

    public void setOnClickListener(PhotoGridAdapter.OnClickListener listener) {
        mOnClickListener = listener;
    }

    public void setSelectImages(ArrayList<String> selectImages) {
        this.selectImages = selectImages;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    public int getCount() {
//        Log.i("Taber", "size: " + mImages.size());
        return mImages.size() + 1;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(final int position, View convertView, ViewGroup parent) {
//        Log.i("Taber: ", "position: " + position);
        if (position == 0) {
            convertView = genOpenCameraView(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            ButtonHolder holder = (ButtonHolder) tag.get("holder");
            ViewGroup.LayoutParams layoutParams = holder.button.getLayoutParams();
            layoutParams.width = itemWidth;
            layoutParams.height = itemHeight;
            holder.button.setLayoutParams(layoutParams);
            holder.button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mOnClickListener != null) {
                        mOnClickListener.onTakePhoto(v, position);
                    }
                }
            });
        } else {
            convertView = genImageView(convertView, parent);
            HashMap tag = (HashMap) convertView.getTag();
            ImageHolder holder = (ImageHolder) tag.get("holder");
            ViewGroup.LayoutParams layoutParams = holder.image.getLayoutParams();
            layoutParams.width = itemWidth;
            layoutParams.height = itemHeight;
            holder.image.setLayoutParams(layoutParams);
            int index = position - 1;
            index = mImages.size() - 1 - index;

            Uri uri = Uri.fromFile(new File(mImages.get(index)));
            Glide.with(mContext.getApplicationContext())
                    .load(uri)
                    .centerCrop()
                    .into(holder.image);
            if(selectImages != null && selectImages.size() >0){
                holder.checkbox.setText(selectImages.contains(mImages.get(index)) ?
                        R.string.icon_checkbox_active :
                        R.string.icon_checkbox_normal);
                holder.checkbox.setTextColor(mContext.getResources().getColor(selectImages.contains(mImages.get(index)) ?
                        R.color.brand :
                        R.color.grey_d));
            }
        }

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnClickListener != null) {
                    int index = position - 1;
                    index = mImages.size() - 1 - index;
                    mOnClickListener.onTogglePhoto(v, position, mImages.get(index));
                }
            }
        });
        return convertView;
    }

    private View genOpenCameraView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.photo_grid_item_camera, parent, false);
            ButtonHolder holder = new ButtonHolder();
            holder.button = (Button) convertView.findViewById(R.id.btnOpenCamera);
            holder.button.setTypeface(Helper.sharedHelper().getIconFont());
            HashMap tag = new HashMap();
            tag.put("type", VIEW_TYPE_BUTTON);
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != VIEW_TYPE_BUTTON) {
                return genOpenCameraView(null, parent);
            }
        }
        return convertView;
    }

    private View genImageView(View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.photo_grid_item, parent, false);
            ImageHolder holder = new ImageHolder();
            holder.image = (ImageView) convertView.findViewById(R.id.image);
            holder.checkbox = (TextView) convertView.findViewById(R.id.checkbox);
            holder.checkbox.setTypeface(Helper.sharedHelper().getIconFont());
            HashMap tag = new HashMap();
            tag.put("type", VIEW_TYPE_IMAGE);
            tag.put("holder", holder);
            convertView.setTag(tag);
        } else {
            HashMap tag = (HashMap) convertView.getTag();
            if ((int) tag.get("type") != VIEW_TYPE_IMAGE) {
                return genImageView(null, parent);
            }
        }
        return convertView;
    }

    public interface OnClickListener {
        void onTakePhoto(View v, int position);

        void onTogglePhoto(View v, int position, String path);
    }
}
