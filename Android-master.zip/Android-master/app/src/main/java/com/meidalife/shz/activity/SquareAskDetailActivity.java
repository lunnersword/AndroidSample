package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.SquareAskDetailAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareAskDO;
import com.meidalife.shz.rest.model.SquareAskDetailDO;
import com.meidalife.shz.rest.request.RequestSquareAsk;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.widget.PopupListMenu;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SquareAskDetailActivity extends BaseActivity implements SquareAskDetailAdapter.PresentNoReplyMessage {

    private static final int REQUEST_SIGN_IN = 1201;
    private static final int REQUEST_I_CAN_HELP = 12;
    private String demandId;
    private SquareAskDetailAdapter squareAskDetailAdapter;
    private ListView mListView;
    private ArrayList<SquareAskDetailDO> mReplyList;
    private View listFooter;

    private Button footerReload;
    private View iCanHelp;
    private FontTextView noReplyMessage;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ViewGroup rootView;
    private ViewGroup listViewContent;

    private int userId;
    private boolean isJoined = false;
    private boolean isGeZhu = false;
    private int mGeZiId;
    private int previous = 0;
    boolean loading = false;
    boolean complete = false;
    int PAGE_SIZE = 20;
    int page = 0;
    boolean isFirstEnter = true;
    private SquareAskDO squareAskDO;
    private boolean otherContentLoadDone = false;

    private boolean pin = false;
    private int geziId = Integer.MAX_VALUE;

    //刚登录返回
    private boolean isFromSignIn = false;
    private static final int MENU_ITEM_ACTION_PIN = 0;
    private static final int MENU_ITEM_ACTION_DEL = 1;
    private static final int MENU_ITEM_CANCEL = 2;
    private PopupListMenu mPopupListMenu;
    private boolean hasDataUpate = false;
    private int status;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_I_CAN_HELP:
                if (resultCode == RESULT_OK) {
                    hasDataUpate = true;
                    getData(true);
                }
                break;

            case REQUEST_SIGN_IN:
                if (resultCode == RESULT_OK) {
                    isFromSignIn = true;
                    getData(true);
                }
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_ask_detail);

        initActionBar(R.string.title_activity_help_platform_detail, true);
        findView();

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            demandId = bundle.getString("demandId");
            pin = bundle.getBoolean("pin", false);
            geziId = bundle.getInt("geziId", Integer.MAX_VALUE);
        }

        if (demandId != null) {
            mReplyList = new ArrayList<>();
            listFooter = getLayoutInflater().inflate(R.layout.view_list_footer, null);
            footerReload = (Button) listFooter.findViewById(R.id.footerReload);
            mListView.addFooterView(listFooter);
            listFooter.setVisibility(View.GONE);
            squareAskDetailAdapter = new SquareAskDetailAdapter(SquareAskDetailActivity.this, squareAskDO, mReplyList);
            squareAskDetailAdapter.setNoReplyMessageListener(SquareAskDetailActivity.this);
            mListView.setAdapter(squareAskDetailAdapter);
            bindListener();
            getData(true);

        }
    }

    @Override
    public void onBackPressed() {
        //通知列表页面刷新
        if (hasDataUpate)
            setResult(RESULT_OK);
        super.onBackPressed();
    }

    private void getData(boolean showLoading) {
        otherContentLoadDone = false;
        isFirstEnter = false;

        if (showLoading) {
            hideStatusErrorNetwork();
            hideStatusErrorServer();
            showStatusLoading(rootView);
            listViewContent.setVisibility(View.GONE);
            iCanHelp.setVisibility(View.GONE);
        }

        page = 0;
        complete = false;
        fetchAskData();
        // fetchDetailItem(true);

    }

    private void findView() {
        rootView = (ViewGroup) findViewById(R.id.rootView);
        listViewContent = (ViewGroup) findViewById(R.id.listViewContent);
        noReplyMessage = (FontTextView) findViewById(R.id.noReplyMessage);
        iCanHelp = findViewById(R.id.iCanHelp);
        mListView = (ListView) findViewById(R.id.listView);
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
    }

    private void bindListener() {
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getData(false);
            }
        });

        mListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView absListView, int scrollState) {
                if (scrollState == SCROLL_STATE_IDLE && mListView.getFirstVisiblePosition() == 0
                        && mListView.getChildAt(0).getTop() == 0) {
                    swipeRefreshLayout.setEnabled(true);
                } else {
                    swipeRefreshLayout.setEnabled(false);
                }

                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    if (absListView.getLastVisiblePosition() == absListView.getCount() - 1) {
                        loadDetailItem();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }
        });

        squareAskDetailAdapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHidePopMenu(v);
            }
        });

        iCanHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkHelpStatus();
            }
        });

        footerReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadDetailItem();
            }
        });
    }

    private void checkHelpStatus() {

        if (Helper.sharedHelper().getUserId().equals(String.valueOf(userId))) {
            MessageUtils.showToast("不能回复自己的求助哦");
            return;
        }
        if (isJoined) {
            startReplyActivity();
        } else {
            if (Helper.sharedHelper().hasToken()) {
                Dialog dialog = getJoinGeZiDialog();
                dialog.show();
            } else {
                Router.sharedRouter().openFormResult("signin", REQUEST_SIGN_IN, SquareAskDetailActivity.this);
            }

        }
    }

    @Override
    public void presentMessage(boolean isOwn) {
        noReplyMessage.setVisibility(View.VISIBLE);
        if (status == Constant.SQUARE_ASK_ITEM_TYPE_GOING) {
            if (isOwn) {
                noReplyMessage.setText(getResources().getString(R.string.square_ask_no_reply_message_going));
            } else
                noReplyMessage.setText(getResources().getString(R.string.square_ask_no_reply_message));
        } else if (status == Constant.SQUARE_ASK_ITEM_TYPE_STALE) {
            noReplyMessage.setText(getResources().getString(R.string.square_ask_no_reply_message_stale));
        }

    }

    @Override
    public void hideMessage() {
        noReplyMessage.setVisibility(View.GONE);
    }

    private void loadDetailItem() {
        if (!complete && !loading) {
            page++;
            fetchDetailItem(false);
        }
    }

    private void fetchAskData() {
        JSONObject params = new JSONObject();
        params.put("demandId", demandId);
        RequestSquareAsk.getDemandDetail(params, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                JSONObject demandDetail = (JSONObject) obj;
                Log.d("mzLog", "demandDetail:" + demandDetail.toString());
                try {
                    if (demandDetail.containsKey("joined")) {
                        isJoined = demandDetail.getBoolean("joined");
                    }
                    if (demandDetail.containsKey("isGezhu")) {
                        isGeZhu = demandDetail.getBoolean("isGezhu");
//                        squareAskDO.setIsGezhu(isGeZhu);
                    }
                    squareAskDO = new SquareAskDO();
                    if (demandDetail.containsKey("demand")) {
                        JSONObject demandJB = (JSONObject) demandDetail.get("demand");
                        if (demandJB.containsKey("id"))
                            squareAskDO.setId(demandJB.getInteger("id"));
                        if (demandJB.containsKey("geziId")) {
                            mGeZiId = demandJB.getInteger("geziId");
                            squareAskDO.setGeziId(mGeZiId);
                        }
                        if (demandJB.containsKey("title"))
                            squareAskDO.setTitle(demandJB.getString("title"));
                        if (demandJB.containsKey("description"))
                            squareAskDO.setDescription(demandJB.getString("description"));
                        if (demandJB.containsKey("closeTime"))
                            squareAskDO.setCloseTime(demandJB.getInteger("closeTime"));
                        if (demandJB.containsKey("remainTime"))
                            squareAskDO.setRemainTime(demandJB.getInteger("remainTime"));
                        if (demandJB.containsKey("user")) {
                            JSONObject user = demandJB.getJSONObject("user");
                            if (user.containsKey("userInstruction"))
                                squareAskDO.setUserInstruction(user.getString("userInstruction"));
                            if (user.containsKey("userId")) {
                                userId = user.getInteger("userId");
                                squareAskDO.setUserId(userId);
                            }
                            if (user.containsKey("userNick"))
                                squareAskDO.setUserNick(user.getString("userNick"));
                            if (user.containsKey("userPicUrl"))
                                squareAskDO.setUserPicUrl(user.getString("userPicUrl"));
                            if (user.containsKey("userGender"))
                                squareAskDO.setUserGender(user.getString("userGender"));
                        }
                        if (demandJB.containsKey("commentCount"))
                            squareAskDO.setCommentCount(demandJB.getInteger("commentCount"));
                        if (demandJB.containsKey("status"))
                            squareAskDO.setStatus(demandJB.getIntValue("status"));
                        status = squareAskDO.getStatus();
                        squareAskDetailAdapter.setStatus(status);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                squareAskDetailAdapter.setIsGeZhu(isGeZhu);
                squareAskDetailAdapter.setSquareAskData(squareAskDO);
                if (isFromSignIn) {
                    //刚从登录返回则直接进入帮助页面
                    checkHelpStatus();
                    isFromSignIn = false;
                }

                if (otherContentLoadDone) {
                    listViewContent.setVisibility(View.VISIBLE);
                    squareAskDetailAdapter.notifyDataSetChanged();
                    hideStatusLoading();
                    hideStatusErrorNetwork();
                    hideStatusErrorServer();
                    swipeRefreshLayout.setRefreshing(false);
                    swipeRefreshLayout.setVisibility(View.VISIBLE);

                } else {
                    otherContentLoadDone = true;
                }

                if (status == Constant.SQUARE_ASK_ITEM_TYPE_STALE
                        || Helper.sharedHelper().getUserId().equals(String.valueOf(userId))) {
                    iCanHelp.setVisibility(View.GONE);
                } else {
                    iCanHelp.setVisibility(View.VISIBLE);
                }

                fetchDetailItem(true);
            }

            @Override
            public void onFail(HttpError error) {
                swipeRefreshLayout.setRefreshing(false);
                listViewContent.setVisibility(View.GONE);
                iCanHelp.setVisibility(View.GONE);
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getData(true);
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getData(true);
                        }
                    });
                    setTextErrorServer(error.getMessage());
                }
            }
        });

    }

    public void fetchDetailItem(final boolean isRefresh) {
        loading = true;
        listFooter.setVisibility(View.VISIBLE);

        RequestSquareAsk.getCommnetList(getDetailItemParams(), new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object result) {
                listFooter.setVisibility(View.GONE);
                loading = false;
                JSONArray detailArr = (JSONArray) result;
                Log.d("mzLog", "detailArr: " + detailArr.toString());
                int size = detailArr.size();
                if (isRefresh)
                    mReplyList.clear();
                for (int i = 0; i < size; i++) {
                    SquareAskDetailDO squareAskDetailDO = new SquareAskDetailDO();

                    //太挫,后面再优化
                    try {
                        JSONObject detailItem = (JSONObject) detailArr.get(i);
                        if (detailItem.containsKey("id")) {
                            squareAskDetailDO.setId(detailItem.getInteger("id"));
                        }
                        if (detailItem.containsKey("accepted")) {
                            squareAskDetailDO.setAccepted(detailItem.getBoolean("accepted"));
                        } else {
                            squareAskDetailDO.setAccepted(false);
                        }

                        if (detailItem.containsKey("canAccept"))
                            squareAskDetailDO.setCanAccept(detailItem.getBoolean("canAccept"));
                        if (detailItem.containsKey("reply"))
                            squareAskDetailDO.setReply(detailItem.getString("reply"));
                        if (detailItem.containsKey("createTime"))
                            squareAskDetailDO.setCreateTime(detailItem.getLong("createTime"));
                        if (detailItem.containsKey("commentUserId"))
                            squareAskDetailDO.setCommentUserId(detailItem.getInteger("commentUserId"));
                        if (detailItem.containsKey("user")) {
                            JSONObject user = detailItem.getJSONObject("user");
                            squareAskDetailDO.setUserId(user.getInteger("userId"));
                            squareAskDetailDO.setUserNick(user.getString("userNick"));
                            squareAskDetailDO.setUserInstruction(user.getString("userInstruction"));
                            squareAskDetailDO.setUserPicUrl(user.getString("userPicUrl"));
                            squareAskDetailDO.setUserGender(user.getString("userGender"));
                            if (user.containsKey("isGeZhu")) {
                                squareAskDetailDO.setIsGeZhu(user.getBoolean("isGeZhu"));
                            }
                        }

                        if (detailItem.containsKey("associatedItemId")) {
                            squareAskDetailDO.setAssociatedItemId(detailItem.getInteger("associatedItemId"));
                            JSONObject item = detailItem.getJSONObject("item");
                            squareAskDetailDO.setServiceItemId(item.getInteger("itemId"));
                            squareAskDetailDO.setServiceTitle(item.getString("title"));
                            squareAskDetailDO.setServicePrice(item.getString("price"));
                            JSONArray images = item.getJSONArray("images");
                            ArrayList<String> imageArr = new ArrayList<>();
                            for (int j = 0; j < images.size(); j++) {
                                imageArr.add((String) images.get(j));
                            }
                            squareAskDetailDO.setServiceImages(imageArr);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    mReplyList.add(squareAskDetailDO);
                }

                if (otherContentLoadDone) {
                    listViewContent.setVisibility(View.VISIBLE);
                    //iCanHelp.setVisibility(View.VISIBLE);
                    squareAskDetailAdapter.notifyDataSetChanged();
                    hideStatusLoading();
                    hideStatusErrorNetwork();
                    hideStatusErrorServer();
                    swipeRefreshLayout.setRefreshing(false);
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                } else {
                    otherContentLoadDone = true;
                }

                if (size < PAGE_SIZE) {
                    complete = true;
                    mListView.removeFooterView(listFooter);
                }
            }

            @Override
            public void onFail(HttpError error) {
                if (page > 0) {
                    page--;
                }
                loading = false;
                swipeRefreshLayout.setRefreshing(false);
                listViewContent.setVisibility(View.GONE);
                iCanHelp.setVisibility(View.GONE);
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getData(true);
                        }
                    });
                } else {
                    showStatusErrorServer(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getData(true);
                        }
                    });
                    setTextErrorServer(error.toString());
                }
            }
        });
    }

    private void showOrHidePopMenu(View v) {
        if (v.getTag() == null)
            return;
        HashMap params = (HashMap) v.getTag();
        final int type = (int) params.get("type");
        final int delId = (int) params.get("id");
        final boolean isOwn = (boolean) params.get("isOwn");
        List<String> options = new ArrayList<String>();
        if (type == SquareAskDetailAdapter.VIEW_TYPE_DEMAND) {
            if (isGeZhu) {
                options.add(MENU_ITEM_ACTION_PIN, getString(pin ? R.string.square_cancel_pin : R.string.square_pin));
                options.add(MENU_ITEM_ACTION_DEL, isOwn ? getString(R.string.delete) : getString(R.string.report));
                options.add(MENU_ITEM_CANCEL, getString(R.string.cancel));
            } else {
                options.add(MENU_ITEM_ACTION_PIN, isOwn ? getString(R.string.delete) : getString(R.string.report));
                options.add(MENU_ITEM_ACTION_DEL, getString(R.string.cancel));
            }
        } else {
            options.add(MENU_ITEM_ACTION_PIN, isOwn ? getString(R.string.delete) : getString(R.string.report));
            options.add(MENU_ITEM_ACTION_DEL, getString(R.string.cancel));
        }
        final int size = options.size();
        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(this);
        }

        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_ACTION_PIN:
                        if (size == 3) {
                            handlerPin(delId);
                        } else {
                            if (isOwn) {
                                deleteItem(type, delId);
                            } else
                                report(type, delId);
                        }
                        mPopupListMenu.dismiss();
                        break;
                    case MENU_ITEM_ACTION_DEL:
                        if (size == 3) {
                            if (isOwn) {
                                deleteItem(type, delId);
                            } else
                                report(type, delId);
                        }
                        mPopupListMenu.dismiss();
                        break;
                    case MENU_ITEM_CANCEL:
                        mPopupListMenu.dismiss();
                        break;
                }
            }
        });


        mPopupListMenu.setMenuData(options);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private void handlerPin(int itemId) {
        if (!isGeZhu) {
            MessageUtils.showToastCenter("非格主不能操作");
            return;
        }
        String path = pin ? "1.0/gezi/pin/del" : "1.0/gezi/pin/add";
        JSONObject params = new JSONObject();
        params.put("bizType", Constant.SQUARE_LIST_PIN_TYPE_ASK);
        params.put("geziId", geziId);
        params.put("bizId", itemId);
        HttpClient.get(path, params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                // fetchAskCategory();
                pin = !pin;
                hasDataUpate = true;
                MessageUtils.showToastCenter("操作成功");
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "操作失败");
            }
        });
    }

    private void deleteItem(final int type, int delId) {

        showProgressDialog(getString(R.string.text_deleting));
        JSONObject params = new JSONObject();
        String urlPath = "";
        if (type == SquareAskDetailAdapter.VIEW_TYPE_DEMAND) {
            urlPath = "1.0/demand/delete";
            params.put("demandId", delId);
        } else if (type == SquareAskDetailAdapter.VIEW_TYPE_REPLY) {
            urlPath = "1.0/demand/deleteComment";
            params.put("commentId", delId);
        }

        HttpClient.get(urlPath, params, null, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object obj) {
                hideProgressDialog();
                if (type == SquareAskDetailAdapter.VIEW_TYPE_DEMAND) {
                    //需要通知列表页更新
                    onBackPressed();
                } else {
                    //更新当前页面
                    getData(true);
                }
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "操作失败");
            }
        });
    }

    //举报
    private void report(final int type, int id) {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", String.valueOf(id));
        intent.putExtra("target", type == SquareAskDetailAdapter.VIEW_TYPE_DEMAND ?
                Constant.REPORT_TYPE_SQUARE_ASK : Constant.REPORT_TYPE_SQUARE_ASK_REPLY);
        startActivity(intent);
    }

    private AlertDialog getJoinGeZiDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.square_ask_detail_join_gezi_message)
                .setPositiveButton(R.string.comfirm_join_gezi, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        joinCurrentGeZi();

                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
        return builder.create();
    }

    private JSONObject getDetailItemParams() {
        JSONObject params = new JSONObject();
        params.put("demandId", demandId);
        params.put("offset", PAGE_SIZE * page);
        params.put("pageSize", PAGE_SIZE);
        return params;
    }

    private void joinCurrentGeZi() {
        JSONObject params = new JSONObject();
        params.put("geziId", mGeZiId);
        RequestSquareAsk.joinGezi(params, new HttpClient.HttpCallback() {
            @Override
            public void onSuccess(Object obj) {
                MessageUtils.showToast("你已成功加入该格子");
                startReplyActivity();
                getData(true);
            }

            @Override
            public void onFail(HttpError error) {
                MessageUtils.showToast(error != null ? error.getMessage() : "加入格子失败，请稍后再试");
            }
        });
    }

    private void startReplyActivity() {
        Router.sharedRouter().openFormResult("squareaskreply/" + demandId, REQUEST_I_CAN_HELP, SquareAskDetailActivity.this);
    }
}
