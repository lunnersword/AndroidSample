package com.meidalife.shz.im;

import android.support.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.db.ImServer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 15/12/6.
 */
public class ImConfig {
    public static final String TAG_SERVER_INFO = "im_svr";
    public static final String TAG_SERVER_ADDRESS = "imsvr_ip";
    public static final String TAG_UNICAST_MAX_ID = "unicast_max_id";
    public static final String TAG_BROADCAST_MAX_ID = "broadcast_max_id";
    public static final String TAG_SERVER_PORT = "imsvr_port";

    private static final String TAG_HEARTBEAT_INTERVAL = "heartbeat_interval";
    private static final String TAG_HEARTBEAT_INTERVAL_NOTLOGIN = "nologin_hb_interval";
    private static final String TAG_MAX_RETRY_TIMES = "max_retry_times";
    private static final String TAG_RETRY_INTERVAL = "retry_interval";
    private static final String TAG_PUSH_ENABLED = "push_open_flag";

    private static final String TAG_CONFIG_TIMESTAMP = "push_config_timestamp";

    private static final int DEFAULT_HB_INTERVAL = 10 * 60;//10分钟，单位秒
    private static final int DEFAULT_INTERVAL = 10 * 60;//5分钟，单位秒
    private static final int DEFAULT_RETRY_TIMES = 5;
    private static final int DEFAULT_RETRY_INTERVAL = 2;
    private static final int SOCKET_TIME_OUT = 10000;//单位毫秒
    private static final long PUSH_CONFIG_EXPIRE_TIME = 24 * 60 * 60 * 1000;//1天，单位毫秒

    private int heartbeatInterval;
    private int heartbeatIntervalNotLogin;
    private int maxRetryTimes;
    private int retryInterval;
    private int socketTimeout = SOCKET_TIME_OUT;
    private boolean pushEnabled = true;
    private List<ImServer> serverList = new ArrayList<>();
    private String deviceId;
    private String userId;
    private long timestamp;

    public ImConfig() {
        heartbeatInterval = Helper.sharedHelper().getIntUserInfo(TAG_HEARTBEAT_INTERVAL, DEFAULT_INTERVAL);
        heartbeatIntervalNotLogin = Helper.sharedHelper().
                getIntUserInfo(TAG_HEARTBEAT_INTERVAL_NOTLOGIN, DEFAULT_INTERVAL);
        maxRetryTimes = Helper.sharedHelper().getIntUserInfo(TAG_MAX_RETRY_TIMES, DEFAULT_RETRY_TIMES);
        retryInterval = Helper.sharedHelper().getIntUserInfo(TAG_RETRY_INTERVAL, DEFAULT_RETRY_INTERVAL);
        deviceId = Helper.sharedHelper().getStringUserInfo(Constant.TAG_DEVICE_ID);
        userId = Helper.sharedHelper().getUserId();
        pushEnabled = Helper.sharedHelper().getBooleanUserInfo(TAG_PUSH_ENABLED, true);
        timestamp = Helper.sharedHelper().getLongUserInfo(TAG_CONFIG_TIMESTAMP, 0);
    }

    /**
     * {"heartbeat_interval":600,"im_svr":[{"imsvr_ip":"1.2.3.4","imsvr_port":1234},
     * {"imsvr_ip":"5.6.7.8","imsvr_port":1234}],"max_retry_times":3,
     * "nologin_hb_interval":600,"push_open_flag":true,"retry_interval":5}
     *
     * @param obj
     * @return
     */
    @NonNull
    public static ImConfig parse(JSONObject obj) {
        ImConfig config = new ImConfig();

        try {
            config.heartbeatInterval = obj.getIntValue(TAG_HEARTBEAT_INTERVAL);
            Helper.sharedHelper().setIntUserInfo(TAG_HEARTBEAT_INTERVAL,
                    config.heartbeatInterval);

            config.heartbeatIntervalNotLogin = obj.getIntValue(TAG_HEARTBEAT_INTERVAL_NOTLOGIN);
            Helper.sharedHelper().setIntUserInfo(TAG_HEARTBEAT_INTERVAL_NOTLOGIN,
                    config.heartbeatIntervalNotLogin);

            config.maxRetryTimes = obj.getIntValue(TAG_MAX_RETRY_TIMES);
            Helper.sharedHelper().setIntUserInfo(TAG_MAX_RETRY_TIMES,
                    config.maxRetryTimes);

            config.retryInterval = obj.getIntValue(TAG_RETRY_INTERVAL);
            Helper.sharedHelper().setIntUserInfo(TAG_RETRY_INTERVAL,
                    config.retryInterval);

            config.pushEnabled = obj.getBoolean(TAG_PUSH_ENABLED);
            Helper.sharedHelper().setBooleanUserInfo(TAG_PUSH_ENABLED, config.pushEnabled);

            config.timestamp = System.currentTimeMillis();
            Helper.sharedHelper().setLongUserInfo(TAG_CONFIG_TIMESTAMP, config.timestamp);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return config;
    }

    public int getHeartbeatInterval() {
        if (heartbeatInterval <= 0) {
            return DEFAULT_HB_INTERVAL;
        }
        return heartbeatInterval;
    }

    public int getHeartbeatIntervalNotLogin() {
        if (heartbeatIntervalNotLogin <= 0) {
            return DEFAULT_HB_INTERVAL;
        }
        return heartbeatIntervalNotLogin;
    }

    public int getMaxRetryTimes() {
        if (maxRetryTimes <= 0) {
            return DEFAULT_RETRY_TIMES;
        }
        return maxRetryTimes;
    }

    public int getRetryInterval() {
        if (retryInterval <= 0) {
            return DEFAULT_RETRY_INTERVAL;
        }
        return retryInterval;
    }

    public int getSocketTimeout() {
        return socketTimeout;
    }

    public void setSocketTimeout(int socketTimeout) {
        this.socketTimeout = socketTimeout;
    }

    public List<ImServer> getServerList() {
        return serverList;
    }

    public void setServerList(List<ImServer> serverList) {
        this.serverList = serverList;
    }

    public boolean isPushEnabled() {
        return pushEnabled;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getUserId() {
        return userId;
    }

    public boolean isExpired() {
        return (System.currentTimeMillis() - timestamp) > PUSH_CONFIG_EXPIRE_TIME;
    }
}
