package com.meidalife.shz.im;

import java.io.IOException;
import java.net.Socket;
import java.net.SocketAddress;

/**
 * Created by fufeng on 15/12/11.
 */
public class SocketManger {

    private Socket socket;

    private static class SingletonHolder {
        private static SocketManger INSTANCE = new SocketManger();
    }

    public static SocketManger getInstance() {
        return SingletonHolder.INSTANCE;
    }

    private SocketManger() {
        socket = new Socket();
    }

    public boolean isClosed() {
        return socket.isClosed();
    }

    public Socket getSocket() {
        return socket;
    }

    public boolean isConnected() {
        return socket.isConnected();
    }

    public void connect(SocketAddress remoteAddr, int timeout) throws IOException {
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        socket = new Socket();
        //no timeout
        socket.setSoTimeout(0);
        socket.connect(remoteAddr, timeout);
    }

    public void close() throws IOException {
        socket.close();
    }
}
