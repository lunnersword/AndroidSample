package com.meidalife.shz.adapter;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 16/1/22.
 */
public class FragmentTabStateAdapter extends FragmentStatePagerAdapter {
    private static final String ARG_TITLE = "title";
    private List<Fragment> fragmentsList = new ArrayList<Fragment>();
    FragmentManager mFragmentManager;

    public FragmentTabStateAdapter(FragmentManager fm) {
        super(fm);
        mFragmentManager = fm;
    }

    @Override
    public Fragment getItem(int position) {
        return fragmentsList.get(position);
    }

    @Override
    public int getCount() {
        return fragmentsList.size();
    }

    public void addFragment(Fragment fragment) {
        fragmentsList.add(fragment);
    }

    public void replaceFragment(int position, Fragment fragment) {
        fragmentsList.set(position, fragment);
    }

    public CharSequence getPageTitle(int position) {
        Bundle args = fragmentsList.get(position).getArguments();
        if (null != args) {
            return args.getString(ARG_TITLE);
        } else {
            return String.valueOf(position);
        }
    }

    public void clear() {
        try {
            FragmentTransaction transaction = mFragmentManager.beginTransaction();
            for (Fragment fragment : fragmentsList) {
                transaction.detach(fragment);
            }
            fragmentsList.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
