
package com.meidalife.shz.event.type;

/**
 * Created by zuozheng on 14-10-31.
 */
public class TabMaskDisplayEventModel {
    /**
     * 刷新对应frag类型
     */
    public TabMaskDisplayTypeEnum type;
}
