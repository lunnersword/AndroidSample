package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;

/**
 * Created by xingchen on 2015/11/29.
 */
public class BlackListAdapter extends BaseAdapter {

    private Context mContext;
    private LayoutInflater mInflater;
    private JSONArray list;

    public BlackListAdapter(Context context, JSONArray list) {
        this.mContext = context;
        this.list = list;
        this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_black_list, parent, false);
            holder = new ViewHolder();
            holder.headPic = (SimpleDraweeView) convertView.findViewById(R.id.headPic);
            holder.iconGender = (TextView) convertView.findViewById(R.id.iconGender);
            holder.nickName = (TextView) convertView.findViewById(R.id.nickName);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        try {
            JSONObject item = (JSONObject) list.get(position);
            if ("M".equals(item.getString("gender"))) {
                holder.iconGender.setText(R.string.icon_gender_m);
                holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.gender_m));
            } else {
                holder.iconGender.setText(R.string.icon_gender_f);
                holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.pink_a));
            }

            holder.iconGender.setTypeface(Helper.sharedHelper().getIconFont());
            if (!TextUtils.isEmpty(item.getString("picUrl"))) {
                holder.headPic.setImageURI(Uri.parse(item.getString("picUrl")));
            } else {
                Uri uri = ImgUtil.getDefaultAvatarUri(mContext, item.getString("userId"), item.getString("gender"));
                if (null != uri) {
                    holder.headPic.setImageURI(uri);
                }
            }
            holder.nickName.setText(item.getString("nick"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return convertView;
    }

    public void setList(JSONArray list) {
        this.list = list;
    }

    public JSONArray getList() {
        return list;
    }

    public void removeItem(int position) {
        if (position < list.size()) {
            list.remove(position);
        }
    }


    class ViewHolder {

        SimpleDraweeView headPic;
        TextView iconGender;
        TextView nickName;
    }
}
