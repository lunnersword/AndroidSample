package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by taber on 15/8/11.
 */
public class RecommendSquareAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    List<SquareDO> mData;

    static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.title)
        TextView title;
        @Bind(R.id.imageItem)
        SimpleDraweeView imageItem;
    }

    public RecommendSquareAdapter(Context context, List<SquareDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public String getItem(int position) {
        return null;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_square_portal_recommend, parent, false);
            ViewHolder holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        }

        SquareDO item = mData.get(position);
        ViewHolder holder = (ViewHolder) convertView.getTag();

        Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getGeziPicUrl(), holder.imageItem.getLayoutParams().width));
        holder.imageItem.setImageURI(uri);
        holder.title.setText(item.getGeziName());

        return convertView;
    }
}
