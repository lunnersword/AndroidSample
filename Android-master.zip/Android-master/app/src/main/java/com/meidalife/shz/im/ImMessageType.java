
package com.meidalife.shz.im;

public enum ImMessageType {
    TYPE_UNKNOWN(-1),
    TYPE_DISCONNECTED(11),
    TYPE_RECONNECT(12),
    TYPE_SOCKET_CLOSE(13),
    TYPE_RECEIVE_MESSAGE_SUCCESS(20),
    TYPE_RECEIVE_MESSAGE_FAILED(21),
    TYPE_SEND_MESSAGE_SUCCESS(30),
    TYPE_SEND_MESSAGE_FAILED(31),
    TYPE_HEARTBEAT_SUCCESS(40),
    TYPE_HEARTBEAT_FAILED(41);

    public int value;

    ImMessageType(int value) {
        this.value = value;
    }

    public static ImMessageType valueOf(int value) {
        for (ImMessageType element : values()) {
            if (element.value == value) {
                return element;
            }
        }
        return TYPE_UNKNOWN;
    }

}
