package com.meidalife.shz.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.DiscoverItem;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

/**
 * Created by fufeng on 15/9/20.
 */
public class DiscoverAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private List<DiscoverItem> discoverItemList;
    private final int DISCOVER_ITEM_WIDTH;

    public DiscoverAdapter(Context context, List<DiscoverItem> discoverItemList) {
        this.mContext = context;
        this.mInflater = LayoutInflater.from(context);
        this.discoverItemList = discoverItemList;
        DISCOVER_ITEM_WIDTH = (int) (mContext.getResources().getDisplayMetrics().widthPixels / 2 -
                mContext.getResources().getDimensionPixelSize(R.dimen.discover_item_margin) * 3);
    }

    public void setData(List<DiscoverItem> discoverItemList) {
        this.discoverItemList = discoverItemList;
    }

    @Override
    public int getCount() {
        return discoverItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return discoverItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        DiscoverItem item = discoverItemList.get(position);
        if (convertView == null || convertView.getTag() == null) {
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.discover_card_item, parent, false);
            viewHolder.avatar = (ImageView) convertView.findViewById(R.id.avatar);
            viewHolder.image = (ImageView) convertView.findViewById(R.id.discover_image);
            viewHolder.title = (TextView) convertView.findViewById(R.id.discover_title);
            viewHolder.viewCount = (TextView) convertView.findViewById(R.id.view_count);
            viewHolder.gender = (TextView) convertView.findViewById(R.id.gender);
            viewHolder.bottomLayout = (LinearLayout) convertView.findViewById(R.id.bottom_layout);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        int imageHeight = caculateImageHeight(item.getWidth(), item.getHeight());

        ViewGroup.LayoutParams params = viewHolder.image.getLayoutParams();
        params.height = imageHeight;
        params.width = DISCOVER_ITEM_WIDTH;
        viewHolder.image.setLayoutParams(params);
        String cdnUrl = ImgUtil.getCDNUrlWithWidth(item.getImage(), imageHeight);
        viewHolder.image.setImageURI(Uri.parse(cdnUrl));
        viewHolder.title.setText(item.getNick());
        viewHolder.viewCount.setText(String.valueOf((item.getViewCount())));
        viewHolder.avatar.setTag(item.getOpusId());

        if (mContext.getString(R.string.gender_man).equals(item.getGender())) {
            viewHolder.gender.setText(R.string.icon_gender_m);
            viewHolder.gender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
        } else if (mContext.getString(R.string.gender_women).equals(item.getGender())) {
            viewHolder.gender.setText(R.string.icon_gender_f);
            viewHolder.gender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
        } else {
            viewHolder.gender.setVisibility(View.GONE);
        }


        String avatarUrl = ImgUtil.getCDNUrlWithWidth(item.getAvatar(),
                mContext.getResources().getDimensionPixelSize(R.dimen.discover_avatar_size));
        if (TextUtils.isEmpty(avatarUrl)) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(item.getUserId()), item.getGender());
            viewHolder.avatar.setImageURI(getDefaultAvatarUri);
        } else {
            viewHolder.avatar.setImageURI(Uri.parse(avatarUrl));
        }

        GradientDrawable drawable = (GradientDrawable) viewHolder.bottomLayout.getBackground();

        drawable.setColor(Color.parseColor(item.getBottomColor()));
        return convertView;
    }

    private int caculateImageHeight(int w, int h) {
        float radio = w / (float) DISCOVER_ITEM_WIDTH;
        int height = (int) (h / radio);
        return height > h ? h : height;
    }

    public static class ViewHolder {
        ImageView image;
        ImageView avatar;
        LinearLayout bottomLayout;
        TextView gender;
        TextView title;
        TextView viewCount;
    }
}
