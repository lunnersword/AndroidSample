package com.meidalife.shz.activity.fragment;

import android.content.DialogInterface;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.DelAttentionListener;
import com.meidalife.shz.adapter.FavoriteServiceAdapter;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.ServiceItem;
import com.umeng.analytics.MobclickAgent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * add by zuozheng
 */

public class FavoriteServiceFragment extends BaseFragment implements SwipeRefreshLayout.OnRefreshListener, DelAttentionListener {
    private static final String LOG_TAG = "FavoriteServiceFragment";
    private static final int PAGE_SIZE = 10;

    private int currentPage = -1;
    private boolean isLoading = false;
    private boolean isComplete = false;

    @Bind(R.id.favorite_service_list)
    GridView mListView;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.cellStatusLoading)
    LinearLayout cellStatusLoading;
    @Bind(R.id.cellStatusErrorNetwork)
    LinearLayout cellStatusErrorNetwork;
    @Bind(R.id.cellStatusErrorServer)
    LinearLayout cellStatusErrorServer;
    @Bind(R.id.textStatusErrorServer)
    TextView textStatusErrorServer;
    View rootView;

    private AnimationDrawable loadingAnimation;
    private FavoriteServiceAdapter mServiceAdapter;
//    private View listFooter;
//    private TextView footerMessage;
//    private ProgressBar footerLoading;
//    private Button footerReload;

    private List<ServiceItem> serviceItemList = Collections.synchronizedList(new ArrayList<ServiceItem>());

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        Log.d(LOG_TAG, "onCreateView");

        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_favorite_service, container, false);

            ButterKnife.bind(this, rootView);

//            listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
//            footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
//            footerMessage = (TextView) listFooter.findViewById(R.id.message);
//            footerReload = (Button) listFooter.findViewById(R.id.footerReload);

            cellStatusErrorNetwork.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    loadData(true);
                }
            });

            cellStatusErrorServer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    loadData(true);
                }
            });

            swipeRefreshLayout.setOnRefreshListener(this);

            initAdapter();
        }

        loadData(true);

        return rootView;
    }


    @Override
    public void onResume() {
        Log.d(LOG_TAG, "onResume");
        super.onResume();
        MobclickAgent.onPageStart(LOG_TAG);
        LogUtil.log(LogUtil.TYPE_START_PAGE, this.getClass().getName());
    }

    @Override
    public void onDestroyView() {
        Log.d(LOG_TAG, "onDestroyView");
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(LOG_TAG, "onPause");
        MobclickAgent.onPageEnd("LOG_TAG");
        LogUtil.log(LogUtil.TYPE_EXIT_PAGE, this.getClass().getName());
    }

    private void initAdapter() {
        mServiceAdapter = new FavoriteServiceAdapter(getActivity(), serviceItemList);
        mServiceAdapter.setDelAttentionListener(this);
        mListView.setAdapter(mServiceAdapter);
//        mAdapterView.setSelector(getResources().getDrawable(R.drawable.discover_item_bg));

//        mListView.add(listFooter);
        mListView.setOnScrollListener(new AbsListView.OnScrollListener() {

            private boolean moveToBottom = false;
            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
//                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
//                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
//                        listFooter.setVisibility(View.VISIBLE);
//                        footerLoading.setVisibility(View.VISIBLE);
//                        loadData(false);
//                    }
//                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (previous < firstVisibleItem) {
                    moveToBottom = true;
                } else if (previous > firstVisibleItem) {
                    moveToBottom = false;
                }
                previous = firstVisibleItem;

                if (totalItemCount == firstVisibleItem + visibleItemCount && moveToBottom) {
                    /* 需要加载更多数据的代码 */
//                    listFooter.setVisibility(View.VISIBLE);
//                    footerLoading.setVisibility(View.VISIBLE);
                    loadData(false);
                }
            }
        });

    }

    private void loadData(boolean showLoading) {
        if (!Helper.isNetworkConnected(getActivity())) {
            showNetworkError();
            return;
        }

        if (isLoading || isComplete) {
            return;
        }

        isLoading = true;
        if (showLoading) {
            showStatusLoading();
        }
        Log.i("Taber", "xhr getAttentionList");
        currentPage++;
        HttpClient.get("1.0/attention/getAttentionList", getParams(currentPage), null, callback);
    }

    HttpClient.HttpCallback<JSONArray> callback = new HttpClient.HttpCallback<JSONArray>() {
        @Override
        public void onSuccess(JSONArray jsonArray) {
            if (jsonArray == null || jsonArray.size() < PAGE_SIZE) {
                isComplete = true;
            }

            if (jsonArray != null && jsonArray.size() > 0) {
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject discoverData = jsonArray.getJSONObject(i);
                    ServiceItem item = transferToDiscoverItem(discoverData);
                    serviceItemList.add(item);
                }
            }

            if (serviceItemList.isEmpty()) {
                showServerError();
                textStatusErrorServer.setText("没有相关服务收藏");
            } else {
                showDiscoverList();

                mServiceAdapter.setData(serviceItemList);
                mServiceAdapter.notifyDataSetChanged();
            }

        }

        @Override
        public void onFail(HttpError error) {
            currentPage--;
            if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                showNetworkError();
                return;
            }

            showServerError();
        }

    };

    private JSONObject getParams(int page) {
        JSONObject params;
        try {
            params = new JSONObject();
            params.put("userId", Helper.sharedHelper().getUserId());
            params.put("pageSize", PAGE_SIZE);
            params.put("offset", page * PAGE_SIZE);
        } catch (com.alibaba.fastjson.JSONException e) {
            params = null;
        }

        return params;
    }


    private ServiceItem transferToDiscoverItem(JSONObject data) {
        ServiceItem item = new ServiceItem();
        item.setItemId(data.getString("itemId"));
        item.setUserId(data.getLong("userId"));
        item.setUserAvatar(data.getString("userAvatar"));
        item.setTag(data.getString("tag"));
        item.setServiceType(data.getIntValue("serviceType"));
        item.setImages((ArrayList<String>) JSONArray.parseArray(data.getString("images"), String.class));
        item.setPrice(data.getString("price"));
        item.setCityName(data.getString("cityName"));

        return item;
    }

    private void xhrDelFavService(String itemId) {
        //todo 需要实现解耦合
        try {
            JSONObject params = new JSONObject();
            params.put("itemId", itemId);
            HttpClient.get("1.0/attention/delAttention", params, null, new HttpClient.HttpCallback<Object>() {
                @Override
                public void onSuccess(Object obj) {
                    MessageUtils.showToast("取消收藏成功");
                    onRefresh();
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToast("取消收藏失败");
                    onRefresh();
                }
            });
        } catch (Exception e) {
        }
    }

    private void showServerError() {
        swipeRefreshLayout.setRefreshing(false);
        swipeRefreshLayout.setVisibility(View.GONE);
        hideStatusLoading();
        cellStatusErrorServer.setVisibility(View.VISIBLE);
        cellStatusErrorNetwork.setVisibility(View.GONE);
        isLoading = false;
    }

    private void showNetworkError() {
        swipeRefreshLayout.setRefreshing(false);
        swipeRefreshLayout.setVisibility(View.GONE);
        hideStatusLoading();
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.VISIBLE);
        isLoading = false;
    }

    private void showDiscoverList() {
        swipeRefreshLayout.setRefreshing(false);
        swipeRefreshLayout.setVisibility(View.VISIBLE);
        hideStatusLoading();
        cellStatusErrorServer.setVisibility(View.GONE);
        cellStatusErrorNetwork.setVisibility(View.GONE);

//        listFooter.setVisibility(View.GONE);
//        footerLoading.setVisibility(View.GONE);
//        footerMessage.setVisibility(View.GONE);
//        footerReload.setVisibility(View.GONE);
        isLoading = false;
    }

    private void showStatusLoading() {
//        footerMessage.setText(R.string.loading);
//        listFooter.setVisibility(View.GONE);
//        footerLoading.setVisibility(View.GONE);
//        footerMessage.setVisibility(View.VISIBLE);
//        footerReload.setVisibility(View.GONE);
        swipeRefreshLayout.setVisibility(View.GONE);
        try {
            cellStatusLoading.setVisibility(View.VISIBLE);
            loadingAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.loading_animation);
            ImageView loadingImage = (ImageView) cellStatusLoading.findViewById(R.id.loadingImageAnimation);
            loadingImage.setBackgroundDrawable(loadingAnimation);
            loadingAnimation.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideStatusLoading() {
        try {
            if (cellStatusLoading != null) {
                cellStatusLoading.setVisibility(View.GONE);
                if (loadingAnimation != null) {
                    loadingAnimation.stop();
                    loadingAnimation = null;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRefresh() {
        currentPage = -1;
        serviceItemList.clear();
        isLoading = false;
        isComplete = false;
        loadData(true);
    }

    @Override
    public void onDelClick(final String id, final int position) {
        MessageUtils.showDialog(getActivity(), "取消收藏", "确认吗，删了就没咯！", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                xhrDelFavService(id);
            }
        }, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if (position < serviceItemList.size()) {
                    ServiceItem item = serviceItemList.get(position);
                    if (item != null) {
                        item.setIsLongClick(false);
                    }
                    mServiceAdapter.notifyDataSetChanged();
                }
            }
        });

    }
}

