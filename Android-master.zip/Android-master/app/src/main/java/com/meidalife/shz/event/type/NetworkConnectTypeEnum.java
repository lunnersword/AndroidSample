
package com.meidalife.shz.event.type;

/**
 * Created by zuozheng on 14-11-14.
 */
public enum NetworkConnectTypeEnum {
    TYPE_DISCONNECTED(-1),
    TYPE_CONNECTED(0);

    public int value;

    private NetworkConnectTypeEnum(int value) {
        this.value = value;
    }

    public static NetworkConnectTypeEnum to(int value) {
        for (NetworkConnectTypeEnum element : values()) {
            if (element.value == value) {
                return element;
            }
        }
        return null;
    }
}
