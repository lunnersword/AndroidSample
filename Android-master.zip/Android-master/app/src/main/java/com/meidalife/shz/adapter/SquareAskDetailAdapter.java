package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.SquareAskDO;
import com.meidalife.shz.rest.model.SquareAskDetailDO;
import com.meidalife.shz.rest.request.RequestSquareAsk;
import com.meidalife.shz.util.DateUtils;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.RemainTimeUtils;
import com.meidalife.shz.view.FontTextView;
import com.meidalife.shz.view.IconTextView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by mzzcy on 2015/12/16.
 */
public class SquareAskDetailAdapter extends BaseAdapter {

    private static final String TAG_HOLDER = "holder";
    private static final String TAG_TYPE = "type";
    private Context mContext;
    private LayoutInflater mInflater;
    private SquareAskDO mSquareAskDO;
    private ArrayList<SquareAskDetailDO> mData;
    private PresentNoReplyMessage mNoReplyMessageCallback;
    private boolean haveAccepted = false;
    private ReplyHolder replyHolder = null;
    private AskHolder demandHolder = null;
    SquareAskDetailDO squareAskDetailDO;
    private int mUsefulPosition = -1;

    private static final int TYPE_COUNT = 3;
    public static final int VIEW_TYPE_DEMAND = 0;
    private static final int VIEW_TYPE_REPLY_COUNT = 1;
    public static final int VIEW_TYPE_REPLY = 2;

    private boolean isGeZhu = false;
    private int status;

    private View.OnClickListener onClickListener;

    //没有回复时 用于更新Activity界面提示
    public interface PresentNoReplyMessage {
        void presentMessage(boolean isOwn);

        void hideMessage();
    }

    public void setNoReplyMessageListener(PresentNoReplyMessage callback) {
        mNoReplyMessageCallback = callback;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    class AskHolder {
        private View view;

        SimpleDraweeView userAvatar;
        FontTextView demandTitle;
        FontTextView remainDays;
        IconTextView iconGender;
        FontTextView textNick;
        FontTextView commentCount;
        FontTextView description;
        TextView pinHandlerView;
        FontTextView gezhuLogo;
        ImageView askFallLogo;
        ImageView askOverLogo;

        public AskHolder(View view) {
            this.view = view;
            userAvatar = (SimpleDraweeView) this.view.findViewById(R.id.imageAvatar);
            demandTitle = (FontTextView) this.view.findViewById(R.id.demandTitle);
            remainDays = (FontTextView) this.view.findViewById(R.id.remainDays);
            iconGender = (IconTextView) this.view.findViewById(R.id.iconGender);
            textNick = (FontTextView) this.view.findViewById(R.id.textNick);
            commentCount = (FontTextView) this.view.findViewById(R.id.commentCount);
            description = (FontTextView) this.view.findViewById(R.id.description);
            pinHandlerView = (TextView) this.view.findViewById(R.id.pinHandlerView);
            gezhuLogo = (FontTextView) this.view.findViewById(R.id.gezhuLogo);
            askFallLogo = (ImageView) this.view.findViewById(R.id.askFallLogo);
            askOverLogo = (ImageView) this.view.findViewById(R.id.askOverLogo);
        }
    }

    class ReplyHolder {
        private View view;

        ImageView imageUseful;
        SimpleDraweeView userAvatar;
        IconTextView iconGender;
        FontTextView textNick;
        FontTextView floor;
        FontTextView beforeTime;
        FontTextView reply;
        FontTextView serviceTitle;
        FontTextView servicePrice;
        View associatedServiceContent;
        SimpleDraweeView servicePic0;
        SimpleDraweeView servicePic1;
        SimpleDraweeView servicePic2;
        View acceptContent;
        TextView pinHandlerView;
        FontTextView gezhuLogo;

        public ReplyHolder(View view) {
            this.view = view;
            imageUseful = (ImageView) this.view.findViewById(R.id.imageUseful);
            userAvatar = (SimpleDraweeView) this.view.findViewById(R.id.imageAvatar);
            iconGender = (IconTextView) this.view.findViewById(R.id.iconGender);
            textNick = (FontTextView) this.view.findViewById(R.id.textNick);
            floor = (FontTextView) this.view.findViewById(R.id.floor);
            beforeTime = (FontTextView) this.view.findViewById(R.id.beforeTime);
            reply = (FontTextView) this.view.findViewById(R.id.reply);
            serviceTitle = (FontTextView) this.view.findViewById(R.id.serviceTitle);
            servicePrice = (FontTextView) this.view.findViewById(R.id.servicePrice);
            associatedServiceContent = this.view.findViewById(R.id.associatedServiceContent);
            servicePic0 = (SimpleDraweeView) this.view.findViewById(R.id.servicePic0);
            servicePic1 = (SimpleDraweeView) this.view.findViewById(R.id.servicePic1);
            servicePic2 = (SimpleDraweeView) this.view.findViewById(R.id.servicePic2);
            acceptContent = this.view.findViewById(R.id.acceptContent);
            pinHandlerView = (TextView) this.view.findViewById(R.id.pinHandlerView);
            gezhuLogo = (FontTextView) this.view.findViewById(R.id.gezhuLogo);
        }
    }

    public SquareAskDetailAdapter(Context context, SquareAskDO squareAskDO, ArrayList<SquareAskDetailDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mSquareAskDO = squareAskDO;
        mData = data;
        mContext = context;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size() + 2;
    }

    @Override
    public SquareAskDetailDO getItem(int position) {
        return mData.get(position - 2);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View converView, ViewGroup parent) {

        View view = null;
        View viewAsk = null;
        View viewReplyCount;
        View viewReply = null;

        if (getCount() < 3) {
            mNoReplyMessageCallback.presentMessage(Helper.sharedHelper().getUserId().equals(mSquareAskDO.getUserId() + ""));
        } else {
            mNoReplyMessageCallback.hideMessage();
        }

        if (position == 0) {
            if (converView != null) {
                HashMap tag = (HashMap) converView.getTag();
                int type = (int) tag.get(TAG_TYPE);
                if (type == VIEW_TYPE_DEMAND) {
                    viewAsk = converView;
                    demandHolder = (AskHolder) tag.get(TAG_HOLDER);
                }
            }

            if (viewAsk == null) {
                Log.d("mzLog helpAdapter", "position: " + position);
                viewAsk = mInflater.inflate(R.layout.item_square_ask, parent, false);
                demandHolder = new AskHolder(viewAsk);
                HashMap tag = new HashMap();
                tag.put(TAG_HOLDER, demandHolder);
                tag.put(TAG_TYPE, VIEW_TYPE_DEMAND);
                viewAsk.setTag(tag);
            }

            if (mSquareAskDO != null) {
                Log.d("mzLog", "mSquareAskDO is not null");
                String gender = mSquareAskDO.getUserGender();
                // 设置服务者性别
                if (mSquareAskDO.getUserGender() != null) {
                    demandHolder.iconGender.setVisibility(View.VISIBLE);
                    if (mSquareAskDO.getUserGender().equals("woman") || mSquareAskDO.getUserGender().equals("F")) {
                        demandHolder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_f));
                        demandHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                    } else {
                        demandHolder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_m));
                        demandHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
                    }
                } else {
                    demandHolder.iconGender.setVisibility(View.GONE);
                }

                if (isGeZhu) {
                    demandHolder.gezhuLogo.setVisibility(View.VISIBLE);
                } else {
                    demandHolder.gezhuLogo.setVisibility(View.GONE);
                }

                // 加载发布者头像
                ViewGroup.LayoutParams avatarParams = demandHolder.userAvatar.getLayoutParams();
                if (TextUtils.isEmpty(mSquareAskDO.getUserPicUrl())) {
                    Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(mSquareAskDO.getUserId()), gender);
                    demandHolder.userAvatar.setImageURI(getDefaultAvatarUri);
                } else {
                    Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(mSquareAskDO.getUserPicUrl(), avatarParams.width));
                    demandHolder.userAvatar.setImageURI(uri);
                }

                demandHolder.demandTitle.setText("我要·" + mSquareAskDO.getTitle());
                switch (mSquareAskDO.getStatus()) {
                    case Constant.SQUARE_ASK_ITEM_TYPE_STALE:
                        demandHolder.remainDays.setText("已过期");
                        break;
                    case Constant.SQUARE_ASK_ITEM_TYPE_COMPLETE:
                        demandHolder.remainDays.setText("已解决");
                        break;
                    default:
                        demandHolder.remainDays.setText("剩余时间：" + RemainTimeUtils.transTime(mSquareAskDO.getRemainTime()));
                        break;
                }
                demandHolder.textNick.setText(mSquareAskDO.getUserNick() == null ? "" : mSquareAskDO.getUserNick());
                demandHolder.commentCount.setText("回答数：" + mSquareAskDO.getCommentCount());
                demandHolder.description.setText(mSquareAskDO.getDescription());
                //设置操作
                if (onClickListener != null) {
                    HashMap params = new HashMap();
                    params.put("id", mSquareAskDO.getId());
                    params.put("type", VIEW_TYPE_DEMAND);
                    params.put("isOwn", Helper.sharedHelper().getUserId().equals(mSquareAskDO.getUserId() + ""));
                    demandHolder.pinHandlerView.setTag(params);
                    demandHolder.pinHandlerView.setOnClickListener(onClickListener);
                }
            } else {
                Log.d("mzLog", "mSquareAskDO is null");
            }

            view = viewAsk;

        } else if (position == 1) {

            //不作优化
            viewReplyCount = mInflater.inflate(R.layout.item_square_ask_reply_count, parent, false);
            TextView replyCount = (TextView) viewReplyCount.findViewById(R.id.replyCount);
            if (mSquareAskDO != null) {
                replyCount.setText("共" + mSquareAskDO.getCommentCount() + "条回答");
            }
            HashMap tag = new HashMap();
            tag.put(TAG_TYPE, VIEW_TYPE_REPLY_COUNT);
            viewReplyCount.setTag(tag);
            view = viewReplyCount;

        } else if (position > 1) {

            if (converView != null) {
                HashMap tag = (HashMap) converView.getTag();
                int type = (int) tag.get(TAG_TYPE);
                if (type == VIEW_TYPE_REPLY) {
                    viewReply = converView;
                    replyHolder = (ReplyHolder) tag.get(TAG_HOLDER);
                }
            }

            if (viewReply == null) {
                viewReply = mInflater.inflate(R.layout.item_square_ask_detail, parent, false);
                replyHolder = new ReplyHolder(viewReply);
                HashMap tag = new HashMap();
                tag.put(TAG_HOLDER, replyHolder);
                tag.put(TAG_TYPE, VIEW_TYPE_REPLY);
                viewReply.setTag(tag);
            }
            squareAskDetailDO = getItem(position);
            String gender = squareAskDetailDO.getUserGender();
            // 设置服务者性别
            if (gender != null) {
                replyHolder.iconGender.setVisibility(View.VISIBLE);
                if (gender.equals("woman") || gender.equals("F")) {
                    replyHolder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_f));
                    replyHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                } else {
                    replyHolder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_m));
                    replyHolder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
                }
            } else {
                replyHolder.iconGender.setVisibility(View.GONE);
            }

            //设置操作
            if (onClickListener != null) {
                HashMap params = new HashMap();
                params.put("id", squareAskDetailDO.getId());
                params.put("type", VIEW_TYPE_REPLY);
                params.put("isOwn", Helper.sharedHelper().getUserId().equals(squareAskDetailDO.getUserId() + ""));
                replyHolder.pinHandlerView.setTag(params);
                replyHolder.pinHandlerView.setOnClickListener(onClickListener);
            }

            if (squareAskDetailDO.getIsGeZhu()) {
                replyHolder.gezhuLogo.setVisibility(View.VISIBLE);
            } else {
                replyHolder.gezhuLogo.setVisibility(View.GONE);
            }

            // 加载发布者头像
            ViewGroup.LayoutParams avatarParams = replyHolder.userAvatar.getLayoutParams();
            if (TextUtils.isEmpty(squareAskDetailDO.getUserPicUrl())) {
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(squareAskDetailDO.getUserId()), gender);
                replyHolder.userAvatar.setImageURI(getDefaultAvatarUri);
            } else {
                Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(squareAskDetailDO.getUserPicUrl(), avatarParams.width));
                replyHolder.userAvatar.setImageURI(uri);
            }

            replyHolder.textNick.setText(squareAskDetailDO.getUserNick());
            int floor = position - 1;
            replyHolder.floor.setText(floor + "楼");
            Long createTime = squareAskDetailDO.getCreateTime();
            String remainTime = DateUtils.getOffsetDays(System.currentTimeMillis(), createTime * 1000);
            replyHolder.beforeTime.setText(remainTime);
            replyHolder.reply.setText(squareAskDetailDO.getReply());
            if (squareAskDetailDO.getAssociatedItemId() == 0) {
                replyHolder.associatedServiceContent.setVisibility(View.GONE);
            } else {

                replyHolder.associatedServiceContent.setVisibility(View.VISIBLE);

                replyHolder.associatedServiceContent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            Router.sharedRouter().open("services/" + squareAskDetailDO.getServiceItemId());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

                replyHolder.servicePic0.setVisibility(View.GONE);
                replyHolder.servicePic1.setVisibility(View.GONE);
                replyHolder.servicePic2.setVisibility(View.GONE);
                replyHolder.serviceTitle.setText("我能·" + squareAskDetailDO.getServiceTitle());
                replyHolder.servicePrice.setText(squareAskDetailDO.getServicePrice());
                ArrayList<String> images = squareAskDetailDO.getServiceImages();
                int endIndex = Math.min(ServiceImagesAdapter.MAX_IMG, images.size());
                Uri uri;

                if (endIndex >= 1) {
                    uri = Uri.parse(images.get(0));
                    replyHolder.servicePic0.setImageURI(uri);
                    replyHolder.servicePic0.setVisibility(View.VISIBLE);
                    if (endIndex >= 2) {
                        uri = Uri.parse(images.get(1));
                        replyHolder.servicePic1.setImageURI(uri);
                        replyHolder.servicePic1.setVisibility(View.VISIBLE);
                        if (endIndex >= 3) {
                            uri = Uri.parse(images.get(2));
                            replyHolder.servicePic2.setImageURI(uri);
                            replyHolder.servicePic2.setVisibility(View.VISIBLE);
                        }
                    }
                }
            }
            if (squareAskDetailDO.isAccepted()) {
                haveAccepted = true;
                replyHolder.imageUseful.setVisibility(View.VISIBLE);
                if (Helper.sharedHelper().getUserId().equals(squareAskDetailDO.getUserId() + ""))
                    replyHolder.pinHandlerView.setVisibility(View.GONE);
            } else {
                replyHolder.imageUseful.setVisibility(View.GONE);
            }

            if (mUsefulPosition != -1 && position == mUsefulPosition) {
                replyHolder.imageUseful.setVisibility(View.VISIBLE);
            }

            if (!haveAccepted && squareAskDetailDO.isCanAccept()
                    && Helper.sharedHelper().getUserId().equals(String.valueOf(mSquareAskDO.getUserId()))
                    && !Helper.sharedHelper().getUserId().equals(String.valueOf(squareAskDetailDO.getUserId()))) {
                replyHolder.acceptContent.setVisibility(View.VISIBLE);
                replyHolder.acceptContent.setTag(position);
                replyHolder.acceptContent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View view) {
                        replyHolder.acceptContent.setEnabled(false);
                        JSONObject params = new JSONObject();
                        params.put("commentId", squareAskDetailDO.getId());
                        RequestSquareAsk.acceptComment(params, new HttpClient.HttpCallback() {
                            @Override
                            public void onSuccess(Object obj) {
                                replyHolder.acceptContent.setEnabled(true);
                                MessageUtils.showToast("认可成功");
                                haveAccepted = true;
                                mUsefulPosition = (int) (view.getTag());
                                notifyDataSetChanged();
                            }

                            @Override
                            public void onFail(HttpError error) {
                                replyHolder.acceptContent.setEnabled(true);
                                MessageUtils.showToast(error != null ? error.getMessage() : "认可失败，请稍后再试");
                            }
                        });
                    }
                });
            } else {
                replyHolder.acceptContent.setVisibility(View.GONE);
            }
            view = viewReply;
        }
        return view;
    }

    public void setSquareAskData(SquareAskDO squareAskDO) {
        mSquareAskDO = squareAskDO;
    }


    public void setIsGeZhu(boolean isGeZhu) {
        this.isGeZhu = isGeZhu;
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }


}
