package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.MessageAdapter;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ConversationDO;
import com.meidalife.shz.rest.model.NotifyDO;
import com.meidalife.shz.rest.request.RequestMessage;
import com.umeng.analytics.MobclickAgent;
import com.usepropeller.routable.Router;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class NotificationActivity extends BaseActivity implements AbsListView.OnScrollListener {

    private MessageAdapter adapter;

    private int page = 0;
    private int pageSize = 20;
    private boolean isMoreData = true;
    private boolean isLoading = true;
    private int previous = 0;

    private String subType;

    @Bind(R.id.message_list)
    ListView listView;
    @Bind(R.id.notification_root)
    LinearLayout rootView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        initActionBar(R.string.title_activity_notification, true, true);
        ButterKnife.bind(this);
        initListener();

        Bundle extras = getIntent().getExtras();
        subType = extras.getString("subType");
    }

    private void initListener() {
        listView.setOnScrollListener(this);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MessageAdapter.MessageHolder holder = (MessageAdapter.MessageHolder) view.getTag();
                NotifyDO notify = (NotifyDO) holder.item;
                if (notify.getSubType() == NotifyDO.SUB_TYPE_SHZ) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", notify.getTargetUrl());
                    Router.sharedRouter().open("web", bundle);
                } else {
                    if (notify.getTargetUrl().startsWith("http://")) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", notify.getTargetUrl());
                        Router.sharedRouter().open("web", bundle);
                    } else {
                        String jumpTarget = notify.getTargetUrl().split("//")[1];
                        Router.sharedRouter().open(jumpTarget);
                    }
                }
//                 系统消息；点击单条信息 更新消息啊状态为已读 同时更新消息tab 未读消息数
                RequestMessage.updateUnread(notify.getId(), new MeidaRestClient.RestCallback() {

                    @Override
                    public void onSuccess(Object result) {
                    }

                    @Override
                    public void onFailure(HttpError error) {

                    }
                });
//                RequestMessage.updateUnread(notify.getId(),null);
            }
        });

        setOnClickErrorServer(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadData();
            }
        });
        setOnClickErrorNetwork(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadData();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("MessageScreen");
        page = 0;
        isLoading = false;
        isMoreData = true;
        loadData();
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("MessageScreen");
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (!isMoreData) {
            return;
        }
        if (isLoading) { // 若已经在加载中，则忽略
            return;
        }
        boolean moveToBottom = false;
        if (previous <= firstVisibleItem) {
            moveToBottom = true;
        }
        previous = firstVisibleItem;
        if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
            isLoading = true;
            page++;
            RequestMessage.getNotificationList(page, pageSize, subType, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    List<NotifyDO> resData = (List<NotifyDO>) result;
                    adapter.add(resData);
                    adapter.notifyDataSetChanged();
                    isLoading = false;

                    if (resData.size() < pageSize) {
                        isMoreData = false;
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "主人，出错了，请再上拉一次...");
                    isLoading = false;
                    page--;
                }
            });
        }
    }

    private void loadData() {
        showStatusLoading(rootView);
        hideStatusErrorServer();
        hideStatusErrorNetwork();
        isLoading = true;
        RequestMessage.getNotificationList(page, pageSize, subType, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                listView.setVisibility(View.VISIBLE);
                hideStatusLoading();
                List<ConversationDO> notifyList = (List<ConversationDO>) result;
                if (notifyList.size() > 0) {
                    adapter = new MessageAdapter(NotificationActivity.this, notifyList);
                    listView.setAdapter(adapter);
                    listView.setVisibility(View.VISIBLE);
                }

                if (notifyList.size() < pageSize) {
                    isMoreData = false;
                }
                isLoading = false;
            }

            @Override
            public void onFailure(HttpError error) {
                isLoading = false;
                listView.setVisibility(View.GONE);
                hideStatusLoading();
                if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                    showStatusErrorNetwork(rootView);
                } else {
                    showStatusErrorServer(rootView);
                }
            }
        });
    }
}
