package com.meidalife.shz.event;

import com.meidalife.shz.event.type.MsgTypeEnum;

/**
 * Created by xingchen on 2015/12/8.
 */
public class CategoryFilterEvent extends BaseEvent {

    private int stdCatId = Integer.MAX_VALUE;

    public CategoryFilterEvent(MsgTypeEnum type, int stdCatId) {
        super(type);
        this.stdCatId = stdCatId;
    }

    public int getStdCatId() {
        return stdCatId;
    }
}
