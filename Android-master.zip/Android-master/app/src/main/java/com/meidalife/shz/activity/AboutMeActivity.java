package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ConstellationAdapter;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.StrUtil;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.usepropeller.routable.Router;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import butterknife.Bind;
import butterknife.ButterKnife;

public class AboutMeActivity extends BaseActivity {

    @Bind(R.id.avatar)
    SimpleDraweeView imageAvatar;
    @Bind(R.id.avatariRight)
    TextView avatarRight;

    @Bind(R.id.nicknameArrow)
    TextView nicknameArrow;
    @Bind(R.id.nickname)
    TextView textNick;

    @Bind(R.id.sex)
    TextView sex;
    @Bind(R.id.genderArrow)
    TextView genderArrow;

    @Bind(R.id.city)
    TextView city;
    @Bind(R.id.cityArrow)
    TextView cityArrow;

    @Bind(R.id.phone)
    TextView textPhone;

    @Bind(R.id.constellationIcon)
    TextView constellationIcon;
    @Bind(R.id.constellation)
    TextView constellation;
    @Bind(R.id.constellationRight)
    TextView constellationRight;

    @Bind(R.id.signature)
    TextView textDescription;
    @Bind(R.id.resumeArrow)
    TextView resumeArrow;

    @Bind(R.id.personalLabelIcon)
    TextView personalLabelIcon;
    @Bind(R.id.labelContent)
    TextView labelContent;
    @Bind(R.id.personalLabelArrow)
    TextView personalLabelArrow;

    @Bind(R.id.voiceIntroArrow)
    TextView voiceIntroArrow;


    @Bind(R.id.videoRecordArrow)
    TextView videoRecordArrow;

    @Bind(R.id.workNumber)
    TextView workNumber;
    @Bind(R.id.workNumberArrow)
    TextView workNumberArrow;


    @Bind(R.id.wxStatus)
    TextView wxStatus;
    @Bind(R.id.weiboStatus)
    TextView weiboStatus;
    @Bind(R.id.qqStatus)
    TextView qqStatus;

    @Bind(R.id.haveVoiceIcon)
    View haveoiceIcon;
    @Bind(R.id.voiceTimeText)
    TextView voiceTimeText;

    @Bind(R.id.haveVideoIcon)
    View haveVideoIcon;

    String avatarUrl;
    String avatarPath;
    int cityCode;

    //是否实名实证用户
    Boolean isRealUser;

    //String[] labels;
    ArrayList<String> labels;

    String videoUrl;
    String voiceUrl;
    long voiceTimeLength;

    private ArrayList<HashMap<String, String>> constellationData;
    private int constellationIndex;

    private UMShareAPI mController;

    private ViewGroup rootView;
    private View contentRoot;

    private VoiceRecorderView mDialogView;
    private Dialog recordVoiceDialog;
    private File cropImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_me);
        ButterKnife.bind(this);
        initActionBar(R.string.title_activity_about_me, true);
        hideIMM();

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);

        constellationData = SignUpActivity.getConstellationData(this);

        avatarRight.setTypeface(Helper.sharedHelper().getIconFont());
        nicknameArrow.setTypeface(Helper.sharedHelper().getIconFont());
        genderArrow.setTypeface(Helper.sharedHelper().getIconFont());
        cityArrow.setTypeface(Helper.sharedHelper().getIconFont());
        constellationRight.setTypeface(Helper.sharedHelper().getIconFont());
        constellationIcon.setTypeface(Helper.sharedHelper().getIconFont());
        resumeArrow.setTypeface(Helper.sharedHelper().getIconFont());
        personalLabelArrow.setTypeface(Helper.sharedHelper().getIconFont());
        personalLabelIcon.setTypeface(Helper.sharedHelper().getIconFont());
        voiceIntroArrow.setTypeface(Helper.sharedHelper().getIconFont());
        videoRecordArrow.setTypeface(Helper.sharedHelper().getIconFont());
        workNumberArrow.setTypeface(Helper.sharedHelper().getIconFont());

        mController = UMShareAPI.get(this);

//        放到onStart()中刷新
//        xhrProfile();

    }

    @Override
    protected void onStart() {
        super.onStart();
        xhrProfile();
    }

    public void handlePickAvatar(View view) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", false);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, AboutMeActivity.this);
    }

    public void handleNickname(View view) {
        String gender = textNick.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putString("nickname", gender);
        Router.sharedRouter().openFormResult("changeNickname", bundle,
                Constant.REQUEST_CODE_CHANGE_NICKNAME, AboutMeActivity.this);
    }

    public void handleGender(View view) {
        String gender = sex.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putString(Constant.DATA_GENDER, gender);
        bundle.putBoolean("isRealUser", isRealUser);
        Router.sharedRouter().openFormResult("chooseGender", bundle,
                Constant.REQUEST_CODE_CHANGE_GENDER, AboutMeActivity.this);
    }

    public void handleCity(View view) {
        Router.sharedRouter().openFormResult("pick/city", Constant.REQUEST_CODE_PICK_CITY, this);
    }

    public void handleSelectConstellation(final View view) {
        final AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.show();
        view.setEnabled(false);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                view.setEnabled(true);
            }
        });
        int deviceWidth = this.getResources().getDisplayMetrics().widthPixels;
        int deviceHeight = this.getResources().getDisplayMetrics().heightPixels;
        deviceWidth -= deviceWidth / 10;
        deviceHeight /= 2;
        dialog.getWindow().setLayout(deviceWidth, deviceHeight);
        View rootView = getLayoutInflater().inflate(R.layout.view_select_constellation, null);
        dialog.getWindow().setContentView(rootView);
        // init view
        ListView listView = (ListView) rootView.findViewById(R.id.optionConstellation);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                dialog.dismiss();
                constellationIndex = position + 1;
                HashMap<String, String> item = constellationData.get(position);
                constellation.setText(item.get("name"));
                constellationIcon.setText(item.get("icon"));
                constellation.setVisibility(View.VISIBLE);
                constellationIcon.setVisibility(View.VISIBLE);
                xhrUpdateProfile();
            }
        });
        ConstellationAdapter adapter = new ConstellationAdapter(this, constellationData);
        listView.setAdapter(adapter);
        if (constellationIndex > 0) {
            listView.setItemChecked(constellationIndex - 1, true);
        }
    }

    public void handlePersonalIntroduce(View view) {
        String data = textDescription.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putString("personalIntroduce", data);
        Router.sharedRouter().openFormResult("personalIntroduce", bundle,
                Constant.REQUEST_CODE_CHANGE_PERSONAL_INTRODUCE, AboutMeActivity.this);
    }

    public void handlePersonalLabel(View view) {

        Bundle bundle = new Bundle();
        bundle.putStringArrayList("userTag", labels);
        Router.sharedRouter().openFormResult("profileLabel", bundle,
                Constant.REQUEST_CODE_CHANGE_PROFILE_LABEL, AboutMeActivity.this);

    }

    /**
     * 录制音频
     *
     * @param view
     */
    public void handleVoiceIntro(View view) {
//        Router.sharedRouter().open("voice", AboutMeActivity.this);
        //通过dialog 实现
        showVoiceDialog();
    }

    public void showVoiceDialog() {
        recordVoiceDialog = new AlertDialog.Builder(this, AlertDialog.THEME_HOLO_LIGHT).create();
        recordVoiceDialog.show();

        mDialogView = new VoiceRecorderView(AboutMeActivity.this, voiceUrl, voiceTimeLength);
        mDialogView.setListener(new MyOnClickListener());
        recordVoiceDialog.getWindow().setContentView(mDialogView.getView());

//        WindowManager windowManager = this.getWindowManager();
//        Display display = windowManager.getDefaultDisplay();
        WindowManager.LayoutParams lp = recordVoiceDialog.getWindow()
                .getAttributes();
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = Dp2Px(250);

        recordVoiceDialog.getWindow().setAttributes(lp);
        recordVoiceDialog.getWindow().setGravity(Gravity.BOTTOM);

//        bindDialogEvent();
    }

    public int Dp2Px(float dp) {
        final float scale = this.getResources().getDisplayMetrics().density;
        return (int) (dp * scale + 0.5f);
    }

    class MyOnClickListener implements VoiceRecorderView.OnClickListener {

        @Override
        public void voiceUploadSuccess() {
            recordVoiceDialog.dismiss();
            xhrProfile();
        }

        @Override
        public void voiceDeleteSuccess() {
            recordVoiceDialog.dismiss();
            xhrProfile();
        }
    }

    /**
     * 录制视频
     *
     * @param view
     */

    public void handleVideoIntro(View view) {
        //NETWORK_TYPE_WIFI = 1 wifi情况下放行
        if (!TextUtils.isEmpty(videoUrl)) {
            Router.sharedRouter().open("playVideo/" + Uri.encode(videoUrl), this);
            return;
        }

        if (Helper.sharedHelper().getNetWorkType() == 1) {
            Router.sharedRouter().openFormResult("video", AboutMeActivity.this);
            return;
        }
        MessageUtils.showDialog(this, "流量使用提醒", "继续录制，运营商将收取流量费用", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Router.sharedRouter().openFormResult("video", AboutMeActivity.this);

            }
        }, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
    }

    public void handleWorkNumber(View view) {
        String data = workNumber.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putString("workCellphone", data);
        Router.sharedRouter().openFormResult("workCellphone", bundle,
                Constant.REQUEST_CODE_CHANGE_WORK_NUMBER, AboutMeActivity.this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_PICK_PHOTO && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            ArrayList images = bundle.getStringArrayList("images");
            if (images.size() > 0) {
                avatarUrl = (String) images.get(0);
                Bundle params = new Bundle();
                params.putString("image_path", avatarUrl);
                params.putBoolean("return-data", false);

                cropImage = new File(ImgUtil.getEditedImagePath(this) +
                        File.separator + "cropped_avatar_" + System.currentTimeMillis() + ".jpg");
                params.putParcelable(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cropImage));
                Router.sharedRouter().openFormResult("cropImage", params,
                        Constant.REQUEST_CODE_CROP_PHOTO, AboutMeActivity.this);
            }
        } else if (requestCode == Constant.REQUEST_CODE_CROP_PHOTO && resultCode == RESULT_OK) {
            if (cropImage != null && cropImage.exists()) {
                syncAvatar(cropImage.getAbsolutePath());
                xhrUploadAvatar(cropImage.getAbsolutePath());
            } else {
                syncAvatar(avatarUrl);
                xhrUploadAvatar(avatarUrl);
            }

        } else if (requestCode == Constant.REQUEST_CODE_CHANGE_GENDER && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            String gender = bundle.getString(Constant.DATA_GENDER);
            if (gender != null)
                sex.setText(gender);

        } else if (Constant.REQUEST_CODE_PICK_CITY == requestCode && resultCode == RESULT_OK) {
            Bundle bundle;
            bundle = data.getExtras();
            cityCode = bundle.getInt("code");
            city.setText(bundle.getString("name"));
            xhrUpdateProfile();
        } else if (Constant.REQUEST_CODE_CHANGE_NICKNAME == requestCode && resultCode == RESULT_OK) {
            Bundle bundle;
            bundle = data.getExtras();
            textNick.setText(bundle.getString("nickname"));
            xhrUpdateProfile();
        } else if (Constant.REQUEST_CODE_CHANGE_PERSONAL_INTRODUCE == requestCode && resultCode == RESULT_OK) {
            Bundle bundle;
            bundle = data.getExtras();
            textDescription.setText(bundle.getString("personalIntroduce"));
            //xhrUpdateProfile();
        } else if (Constant.REQUEST_CODE_CHANGE_WORK_NUMBER == requestCode && resultCode == RESULT_OK) {
            Bundle bundle;
            bundle = data.getExtras();
            workNumber.setText(bundle.getString("workCellphone"));
        } else if (Constant.REQUEST_CODE_CHANGE_PROFILE_LABEL == requestCode && resultCode == RESULT_OK) {
            Bundle bundle;
            bundle = data.getExtras();
            labels = bundle.getStringArrayList("userTag");
            initUserTag();
        }

        try {
            mController.onActivityResult(requestCode, resultCode, data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void syncAvatar(String path) {
        Uri uri = Uri.fromFile(new File(path));
        imageAvatar.setImageURI(uri);
    }

    private void xhrUploadAvatar(String path) {
        RequestSign.upload(path, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                JSONObject json = (JSONObject) result;
                try {
                    avatarUrl = json.getString("data");
                    xhrUpdateProfile();
                } catch (JSONException e) {
                }
                hideProgressDialog();
                if (cropImage != null && cropImage.exists()) {
                    syncAvatar(cropImage.getAbsolutePath());
                } else {
                    syncAvatar(avatarUrl);
                }

            }

            @Override
            public void onFailure(HttpError error) {
                avatarUrl = null;
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "头像上传失败，请重试");
            }
        });
    }

    private void xhrProfile() {

        loadPre(rootView, contentRoot);

        RequestSign.getProfile(new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                loadSuccess(contentRoot);
                JSONObject json = (JSONObject) result;
                try {
//                    Log.d("myprofile", json.toString());
                    JSONObject data = json.getJSONObject("data");
                    ViewGroup.LayoutParams layoutParams = imageAvatar.getLayoutParams();
                    avatarUrl = data.getString("picUrl");
                    String imageUrl = ImgUtil.getCDNUrlWithWidth(avatarUrl, layoutParams.width);
                    //add default avatar
                    if (TextUtils.isEmpty(imageUrl)) {
                        String gender = data.has("gender") ? data.getString("gender") : "";
                        String userId = data.getString("userId");
                        Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(AboutMeActivity.this, userId, gender);
                        imageAvatar.setImageURI(getDefaultAvatarUri);
                    } else {
                        imageAvatar.setImageURI(Uri.parse(imageUrl));
                    }

                    String nick = data.getString("nick");
                    textNick.setText(nick);
                    if (data.has("gender")) {
                        String gender = data.getString("gender");
                        if (Constant.GENDER_MAN.equals(gender)) {
                            sex.setText("男");
                        } else if (Constant.GENDER_WOMAN.equals(gender)) {
                            sex.setText("女");
                        }
                    }

                    if (data.has("instruction")) {
                        String instruction = data.getString("instruction");
                        textDescription.setText(instruction);
                    }

                    if (data.has("constellation")) {
                        constellationIndex = data.getInt("constellation");
                        Map<String, String> value = constellationData.get(constellationIndex - 1);
                        constellation.setText(value.get("name"));
                        constellationIcon.setText(value.get("icon"));
                        constellationIcon.setTypeface(Helper.sharedHelper().getIconFont());
                        constellationIcon.setVisibility(View.VISIBLE);
                    } else {
                        constellationIcon.setVisibility(View.INVISIBLE);
                    }

                    JSONArray userTag = data.getJSONArray("userTag");
                    Log.d("AboutMeActivity", "userTag: " + userTag.length() + userTag.toString());
                    labels = new ArrayList<String>(userTag.length());
                    if (userTag.length() > 0) {
                        for (int i = 0; i < userTag.length(); i++) {
                            labels.add(i,userTag.get(i).toString());
                            Log.d("AboutMeActivity", "labelsitem" + i + labels.get(i));
                        }
                    }
                    initUserTag();

                    String phone = data.optString("mobile");

                    textPhone.setText(phone);

                    if (data.has("workMobile")) {
                        workNumber.setText(data.getString("workMobile"));
                    } else {
                        workNumber.setText(phone);
                    }

                    if (data.has("isRealUser")) {
                        isRealUser = data.getBoolean("isRealUser");
                    } else {
                        isRealUser = false;
                    }

                    if (data.has("vedioUrl")) {
                        videoUrl = data.getString("vedioUrl");
                        if (!TextUtils.isEmpty(videoUrl)) {
                            haveVideoIcon.setVisibility(View.VISIBLE);
                        }
                    } else {
                        videoUrl = null;
                        haveVideoIcon.setVisibility(View.GONE);
                    }

                    if (data.has("soundUrl")) {
                        voiceUrl = data.getString("soundUrl");
                        if (!TextUtils.isEmpty(voiceUrl)) {
                            haveoiceIcon.setVisibility(View.VISIBLE);
                        }
                    } else {
                        voiceUrl = null;
                        haveoiceIcon.setVisibility(View.GONE);
                    }

                    if (data.has("soundLength")) {
                        voiceTimeLength = data.getLong("soundLength");
                        voiceTimeText.setVisibility(View.VISIBLE);
                        voiceTimeText.setText(voiceTimeLength + " ''");
                    } else {
                        voiceTimeLength = 0;
                        voiceTimeText.setVisibility(View.GONE);
                    }

                    bindStatusToString(wxStatus, "weixinAccount", data, SHARE_MEDIA.WEIXIN);
                    bindStatusToString(weiboStatus, "weiboAccount", data, SHARE_MEDIA.SINA);
                    bindStatusToString(qqStatus, "qqAccount", data, SHARE_MEDIA.QQ);


                } catch (JSONException e) {
                    Log.e(AboutMeActivity.class.getName(), "init mine profile data fail", e);
                    MessageUtils.showToastCenter(getString(R.string.error_server_500));
                }
            }

            @Override
            public void onFailure(HttpError error) {
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            xhrProfile();
                        }
                    });
                }
            }
        });
    }

    public void bindStatusToString(TextView view, String fieldName, JSONObject data, final SHARE_MEDIA shareMedia) throws JSONException {

        if (data.has(fieldName) && !StrUtil.isEmpty(data.getString(fieldName))) {
            view.setBackgroundColor(getResources().getColor(R.color.white));
            view.setTextColor(getResources().getColor(R.color.grey_c));
            view.setText("已绑定");
        } else {
            view.setBackgroundResource(R.drawable.about_me_button);
            view.setTextColor(getResources().getColor(R.color.white));
            view.setText("绑定");
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    bind(shareMedia, v);
                }
            });
        }
    }

    private void xhrUpdateProfile() {
        try {
            JSONObject params = new JSONObject();
            if (avatarUrl != null) {
                params.put("picUrl", avatarUrl);
                params.put("backgroundUrl", avatarUrl);
            }

            params.put("instruction", textDescription.getText().toString());
            if (constellationIndex > 0) {
                params.put("constellation", constellationIndex);
            }

            showProgressDialog("正在保存");
            RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter("保存成功");
//                    finish();
                    Helper.sharedHelper().setStringUserInfo("nick", textNick.getText().toString());
                    if (avatarUrl != null) {
                        Helper.sharedHelper().setStringUserInfo("picUrl", avatarUrl);
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败");
                }
            });
        } catch (JSONException e) {
        }
    }

    public void bind(SHARE_MEDIA shareMedia, View view) {
        oAuth(shareMedia, (TextView) view);
    }

    public void oAuth(final SHARE_MEDIA shareMedia, final TextView view) {

        showProgressDialog("正在请求授权", false);
        mController.doOauthVerify(AboutMeActivity.this, shareMedia, new UMAuthListener() {
            @Override
            public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
                showProgressDialog("授权成功，绑定中...");
                StringBuffer logBuffer = new StringBuffer();

                JSONObject params = new JSONObject();
                try {
                    if (shareMedia == SHARE_MEDIA.WEIXIN) {
                        params.put("weixinAccount", data.get("openid"));
                    } else if (shareMedia == SHARE_MEDIA.SINA) {
                        params.put("weiboAccount", data.get("uid"));
                    } else if (shareMedia == SHARE_MEDIA.QQ) {
                        params.put("qqAccount", data.get("openid"));
                    }
                    RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
                        @Override
                        public void onSuccess(Object result) {
                            hideProgressDialog();
                            view.setBackgroundColor(getResources().getColor(R.color.white));
                            view.setTextColor(getResources().getColor(R.color.grey_c));
                            view.setText("已绑定");
                        }

                        @Override
                        public void onFailure(HttpError error) {
                            hideProgressDialog();
                            MessageUtils.showToastCenter(error != null ? error.getMessage() : "绑定失败");
                        }
                    });
                } catch (Exception e) {
                    Log.e(AboutMeActivity.class.getName(), "bind third account fail", e);
                    MessageUtils.showToastCenter(getString(R.string.error_server_500));
                }
            }

            @Override
            public void onError(SHARE_MEDIA platform, int action, Throwable t) {
                hideProgressDialog();
                MessageUtils.showToastCenter("授权失败");
            }

            @Override
            public void onCancel(SHARE_MEDIA platform, int action) {
                MessageUtils.showToastCenter("授权取消");
            }
        });
    }

    private void initUserTag() {
        StringBuilder stringBuilder = new StringBuilder();

        if (labels.size() > 0) {
            personalLabelIcon.setVisibility(View.VISIBLE);
            labelContent.setVisibility(View.VISIBLE);
            for (String s : labels) {
                stringBuilder.append(s + "  ");
            }
            labelContent.setText(stringBuilder.toString());
        } else {
            personalLabelIcon.setVisibility(View.INVISIBLE);
            labelContent.setVisibility(View.INVISIBLE);
        }

        Log.d("AboutMeActivity", stringBuilder.toString());
    }

}
