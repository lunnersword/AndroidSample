package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;

import com.meidalife.shz.R;
import com.meidalife.shz.adapter.OrderListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.OrderDO;
import com.meidalife.shz.rest.model.OrderListOutDO;
import com.meidalife.shz.rest.model.OrderTabTypeOutDO;
import com.meidalife.shz.rest.request.RequestOrder;
import com.meidalife.shz.rest.request.RequestOrderList;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.LoadUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/12/1.
 */
public class OrderListFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener, OrderListAdapter.OnOrderChangeLister {
    private static final String TAG_ROLE_TYPE = "role_type";
    private static final String TAG_TYPE = "type";
    private static final String TAG_COUNT = "count";
    private static final String TAG_TITLE = "title";
    private Boolean isLoading = false;
    private int roleType = 1;
    private int page = 1;
    private int pageSize = 10;
    private List<OrderDO> mOrderList = new ArrayList<>();
    private View rootView;

    //private View listFooter;
    private OrderListAdapter orderListAdapter;
    private OnDataChangeListener onDataChangeListener;
    private LoadUtil mLoadUtil;

    @Bind(R.id.emptyView)
    View emptyView;
    @Bind(R.id.orderList)
    ListView orderListView;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    private String currentChangedOrderNo;
    private int changedOrderIndex = -1;

    public static OrderListFragment newInstance(OrderTabTypeOutDO orderTabTypeDO, int roleType) {
        OrderListFragment orderListFragment = new OrderListFragment();

        Bundle params = new Bundle();
        params.putInt(TAG_ROLE_TYPE, roleType);
        params.putInt(TAG_TYPE, orderTabTypeDO.getType());
        params.putInt(TAG_COUNT, orderTabTypeDO.getCount() == null ? 0 : orderTabTypeDO.getCount());
        params.putString(TAG_TITLE, orderTabTypeDO.getText());
        orderListFragment.setArguments(params);

        return orderListFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_order_list, null);
            ButterKnife.bind(this, rootView);

            //listFooter = getLayoutInflater(savedInstanceState).inflate(R.layout.view_list_footer, null);
            mLoadUtil = new LoadUtil(inflater);

            orderListView.setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                        if (view.getLastVisiblePosition() == view.getCount() - 1) {
                            loadData(false);
                        }
                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem,
                                     int visibleItemCount, int totalItemCount) {
                }
            });

            swipeRefreshLayout.setOnRefreshListener(this);
            orderListAdapter = new OrderListAdapter(getActivity(), mOrderList);
            orderListAdapter.setOnOrderChangeLister(this);
            //orderListView.addFooterView(listFooter);
            orderListView.setAdapter(orderListAdapter);
        }
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        loadData(true);
    }

    @Override
    public void onResume() {
        updateOrder();
        super.onResume();
    }

    @Override
    public void onDestroyView() {
        try {
            try {
                ViewGroup parent = (ViewGroup) rootView.getParent();
                if (parent != null) {
                    parent.removeView(rootView);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    private void loadData(boolean reload) {
        if (isLoading) {
            return;
        }
        isLoading = true;
        int type = getArguments().getInt(TAG_TYPE);
        roleType = getArguments().getInt(TAG_ROLE_TYPE);
        if (reload) {
            page = 1;
            mOrderList.clear();

            mLoadUtil.loadPre((ViewGroup) rootView, swipeRefreshLayout);
        }
        RequestOrderList.get(roleType, type, page, pageSize, new HttpClient.HttpCallback<OrderListOutDO>() {
            @Override
            public void onSuccess(OrderListOutDO orderListVO) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                if (getActivity() == null) {
                    return;
                }
                //listFooter.setVisibility(View.GONE);
                mLoadUtil.hideStatusLoading();

                if (onDataChangeListener != null) {
                    onDataChangeListener.onDataChange(orderListVO.getOrderCounts());
                }

                mOrderList.addAll(orderListVO.getOrders());
                if (mOrderList.size() == 0) {
                    swipeRefreshLayout.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                    orderListAdapter.updateData(mOrderList);
                    page++;
                }
            }

            @Override
            public void onFail(HttpError error) {
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
                //listFooter.setVisibility(View.GONE);
                mLoadUtil.loadFail(error, (ViewGroup) rootView, getActivity(), new LoadUtil.LoadCallback() {
                    @Override
                    public void execute() {
                        loadData(true);
                    }
                });
            }
        });
    }

    public void setOnDataChangeListener(OnDataChangeListener onDataChangeListener) {
        this.onDataChangeListener = onDataChangeListener;
    }

    @Override
    public void onRefresh() {
        loadData(true);
    }

    @Override
    public void onOrderChange(int position, String orderNo) {
        if (CollectionUtil.isNotEmpty(mOrderList) && position < mOrderList.size()) {
            OrderDO orderDO = mOrderList.get(position);
            currentChangedOrderNo = orderDO.getOrderNo();
            changedOrderIndex = position;
        }
    }

    private void updateOrder() {
        if (TextUtils.isEmpty(currentChangedOrderNo) || changedOrderIndex < 0) {
            return;
        }
        RequestOrder.getOrder(currentChangedOrderNo, new HttpClient.HttpCallback<OrderDO>() {
            @Override
            public void onSuccess(OrderDO result) {
                try {
                    currentChangedOrderNo = null;
//                    OrderDO mOrder = (OrderDO) result;
                    mOrderList.remove(changedOrderIndex);
                    mOrderList.add(changedOrderIndex, result);
                    orderListAdapter.updateData(mOrderList);
                    changedOrderIndex = -1;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFail(HttpError error) {
                changedOrderIndex = -1;
                currentChangedOrderNo = null;
            }
        });
    }

    public interface OnDataChangeListener {
        void onDataChange(List<OrderTabTypeOutDO> orderTabTypeDOList);
    }
}
