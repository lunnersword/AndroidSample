package com.meidalife.shz.adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.github.curioustechizen.ago.RelativeTimeTextView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.BaseActivity;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.OpusDO;
import com.meidalife.shz.rest.request.RequestOpus;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.MyGridView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by taber on 15/8/9.
 */
public class OpusAdapter extends BaseAdapter {
    LayoutInflater mInflater;
    Context mContext;
    ArrayList<OpusDO> mData;
    RefreshProfileOpus profileCallback;

    static class ViewHolder {
        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

        @Bind(R.id.textCalendarDay)
        TextView textCalendarDay;
        @Bind(R.id.textCalendarMonth)
        TextView textCalendarMonth;
        @Bind(R.id.textDescription)
        TextView textDescription;
        @Bind(R.id.fromService)
        TextView textSource;
        @Bind(R.id.textCreateTime)
        RelativeTimeTextView textCreateTime;
        @Bind(R.id.gridViewThumbs)
        MyGridView gridViewThumbs;
        @Bind(R.id.imageThumb)
        SimpleDraweeView imageThumb;
        @Bind(R.id.textDelete)
        TextView textDelete;
    }

    public OpusAdapter(Context context, ArrayList<OpusDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    //删除作品刷新个人主页的 回调接口
    public interface RefreshProfileOpus {
        void refresh();
    }

    public void setOnDeleteOpusListener(RefreshProfileOpus callback) {
        profileCallback = callback;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public String getItem(int position) {
        return null;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_opus, parent, false);
            ViewHolder holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        }

        final OpusDO item = mData.get(position);
        ViewHolder holder = (ViewHolder) convertView.getTag();
        holder.textCreateTime.setReferenceTime(item.getCreateTime());
        if (item.getDescription() != null) {
            holder.textDescription.setText(item.getDescription());
            holder.textDescription.setVisibility(View.VISIBLE);
        } else {
            holder.textDescription.setVisibility(View.GONE);
        }
        if (item.getItemTitle() != null) {
            holder.textSource.setText("来自" + item.getItemTitle());
            holder.textSource.setVisibility(View.VISIBLE);
        } else {
            holder.textSource.setVisibility(View.GONE);
        }

        Activity activity = (Activity) mContext;
        Display display = activity.getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int screenWidth = size.x - (int) Helper.convertDpToPixel(90, mContext) - 3;

        if (item.getImages().size() == 1) {
            ViewGroup.LayoutParams layoutParmas = holder.imageThumb.getLayoutParams();
            layoutParmas.width = screenWidth;
            layoutParmas.height = (int) Math.ceil(screenWidth * 0.64);
            Uri itemUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getImages().get(0), layoutParmas.width));
            holder.imageThumb.setLayoutParams(layoutParmas);
            holder.imageThumb.setImageURI(itemUri);
            holder.imageThumb.setVisibility(View.VISIBLE);
            holder.gridViewThumbs.setVisibility(View.GONE);
            holder.imageThumb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openBrowser(mData.get(position), 0);
                }
            });
        } else {
            // 计算多图每栏宽度
            float spacing = Helper.convertDpToPixel(10, mContext);
            int width = screenWidth;
            width -= spacing * 2;
            holder.gridViewThumbs.setColumnWidth(width / 3);
            int thumbWidth = width / 3;
            holder.imageThumb.setVisibility(View.GONE);
            holder.gridViewThumbs.setAdapter(new ServiceImagesAdapter(mContext, item.getImages(), thumbWidth));
            holder.gridViewThumbs.setVisibility(View.VISIBLE);
            holder.gridViewThumbs.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int index, long id) {
                    openBrowser(mData.get(position), index);
                }
            });
        }

        // 设置日期
        OpusDO preItem = position > 0 ? mData.get(position - 1) : null;

        if (position == 0 ||
                (preItem != null &&
                        preItem.getMonth() != null &&
                        preItem.getDay() != null &&
                        item.getMonth() != null &&
                        item.getDay() != null &&
                        (!preItem.getMonth().equals(item.getMonth()) || !preItem.getDay().equals(item.getDay())))) {
            holder.textCalendarDay.setText(item.getDay());
            holder.textCalendarMonth.setText(item.getMonth() + "月");
        } else {
            holder.textCalendarDay.setText("");
            holder.textCalendarMonth.setText("");
        }

        if (item.isCanDelete()) {
            holder.textDelete.setVisibility(View.VISIBLE);
            holder.textDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    confirmDeleteDialog(item.getId(), position);
                }
            });
        } else {
            holder.textDelete.setVisibility(View.GONE);
        }

        return convertView;
    }

    private void confirmDeleteDialog(final int opusId, final int position) {
        AlertDialog dialog = new AlertDialog.Builder(mContext).
                setTitle(R.string.title_dialog_delete_confirm).
                setMessage(R.string.delete_opus_confirm).
                setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteOpus(opusId, position);
            }
        }).create();

        dialog.show();
    }

    private void deleteOpus(int opusId, final int position) {
        final BaseActivity activity = (BaseActivity) mContext;
        activity.showProgressDialog("正在删除", false);
        RequestOpus.deleteOpus(opusId, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                mData.remove(position);
                notifyDataSetChanged();
                if (null != profileCallback) {
                    profileCallback.refresh();
                }

                activity.hideProgressDialog();
            }

            @Override
            public void onFailure(HttpError error) {
                activity.hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "删除失败，请重试");
            }
        });
    }

    private void openBrowser(OpusDO item, int index) {
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("photos", item.getImages());
        bundle.putInt("index", index);
        bundle.putLong("time", item.getCreateTime());
        bundle.putLong("itemId", item.getItemId());
        bundle.putString("title", item.getItemTitle());
        bundle.putString("description", item.getDescription());
        Router.sharedRouter().open("imageBrowser", bundle);
    }
}
