package com.meidalife.shz.event;

import com.meidalife.shz.event.type.ModifyUnReadMsdCountEventModel;

/**
 * Created by zuozheng on 14-10-31.
 */
public interface ModifyUnReadMsgCountEvent {

    public void onEvent(ModifyUnReadMsdCountEventModel model);
}
