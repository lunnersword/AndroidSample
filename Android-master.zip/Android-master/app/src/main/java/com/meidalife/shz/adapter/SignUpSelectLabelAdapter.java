package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liujian on 16/1/8.
 */
public class SignUpSelectLabelAdapter extends BaseAdapter {
    private JSONArray labels;
    private Context context;
    private LayoutInflater mInflater;
    private List<String> selectLabel = new ArrayList<String>();

    public SignUpSelectLabelAdapter(Context context, JSONArray labels) {
        this.labels = labels;
        this.context = context;
        this.mInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return labels.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.item_sign_up_label,parent,false);
            holder = new ViewHolder();
            holder.icon = (SimpleDraweeView)convertView.findViewById(R.id.icon);
            holder.label = (TextView)convertView.findViewById(R.id.label);
            holder.selectIcon = convertView.findViewById(R.id.selectIcon);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder)convertView.getTag();
        }
        JSONObject item = labels.getJSONObject(position);
        if(item.containsKey("imageURL"))
            holder.icon.setImageURI(Uri.parse(item.getString("imageURL")));
        if(item.containsKey("label"))
            holder.label.setText(item.getString("label"));
        if(selectLabel.contains(item.getString("label"))){
            holder.selectIcon.setVisibility(View.VISIBLE);
        }else
            holder.selectIcon.setVisibility(View.GONE);
        return convertView;
    }

    static class ViewHolder{
        SimpleDraweeView icon;
        TextView label;
        View selectIcon;
    }

    public List<String> getSelectLabel(){
        return selectLabel;
    }

    public void addSelectPos(String label){
        selectLabel.add(label);
    }

    public void removeSelectPos(String label){
        selectLabel.remove(label);
    }

    public boolean containsLabel(String label){
        return selectLabel.contains(label);
    }
}
