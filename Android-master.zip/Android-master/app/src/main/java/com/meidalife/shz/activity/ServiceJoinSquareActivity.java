package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.JoinedServiceListAdapter;
import com.meidalife.shz.adapter.JoinedSquareListAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.JoinedServiceItem;
import com.meidalife.shz.rest.model.SquareItem;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.widget.DividerItemDecoration;
import com.meidalife.shz.widget.RecyclerViewEmptySupport;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 15/12/18.
 */
public class ServiceJoinSquareActivity extends BaseActivity {
    private static final int PAGE_SIZE = 100;

    //发布服务后，将服务加入某几个格子
    public static final int SERVICE_JOIN_SQUARES = 0;
    //选择服务，将多个服务加入格子
    public static final int JOIN_SQUARE = 1;

    private int offset = 0;
    private int type = 0;
    private String serviceItemId;
    private String squareId;
    private Integer scope = 0;
    List<SquareItem> squareItemList = new ArrayList<>();
    List<JoinedServiceItem> serviceItemList = new ArrayList<>();

    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    ViewGroup contentView;
    @Bind(R.id.action_bar_title)
    TextView title;
    @Bind(R.id.closeButton)
    TextView closeButton;
    @Bind(R.id.tipsLayout1)
    ViewGroup tipsLayout1;
    @Bind(R.id.joinTips1)
    TextView joinTips1;
    @Bind(R.id.tipsLayout2)
    ViewGroup tipsLayout2;
    @Bind(R.id.joinTips2)
    TextView joinTips2;
    @Bind(R.id.serviceFeeButton)
    TextView serviceFeeButton;
    @Bind(R.id.jumpButton)
    TextView jumpButton;

    @Bind(R.id.serviceRestrictLayout)
    ViewGroup serviceRestrictLayout;
    @Bind(R.id.serviceRestrictSwitch)
    Switch serviceRestrictSwitch;

    @Bind(R.id.emptyView)
    ViewGroup emptyView;
    @Bind(R.id.squareListHint)
    TextView listHint;
    @Bind(R.id.squareList)
    RecyclerViewEmptySupport squareList;
    @Bind(R.id.btnComplete)
    TextView btnComplete;
    @Bind(R.id.emptyViewHint)
    TextView emptyViewHint;

    JoinedSquareListAdapter joinedSquareListAdapter;
    JoinedServiceListAdapter joinedServiceListAdapter;
    LinearLayoutManager linearLayoutManager;
    LoadUtilV2 loadUtilV2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_join_square);
        ButterKnife.bind(this);

        type = getIntent().getIntExtra("type", 1);
        squareList.setEmptyView(emptyView);

        //设置布局管理器
        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        squareList.setLayoutManager(linearLayoutManager);
        squareList.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL_LIST));

        if (type == SERVICE_JOIN_SQUARES) {
            serviceItemId = getIntent().getStringExtra("serviceId");
            joinedSquareListAdapter = new JoinedSquareListAdapter(this, squareItemList);
            squareList.setAdapter(joinedSquareListAdapter);
            btnComplete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    bindServiceToSquares();
                }
            });
            title.setText("关联格子");
            jumpButton.setVisibility(View.GONE);
        } else {
            squareId = getIntent().getStringExtra("squareId");
            joinedServiceListAdapter = new JoinedServiceListAdapter(this, serviceItemList);
            squareList.setAdapter(joinedServiceListAdapter);
            emptyViewHint.setText(R.string.joined_service_empty);
            btnComplete.setText("确认加入");

            btnComplete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    joinSquare(false);
                }
            });

            jumpButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    joinSquare(true);
                }
            });
            title.setText("加入格子");
        }

        squareList.addOnScrollListener(
                new OnScrollListener() {
                    @Override
                    public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                        super.onScrollStateChanged(recyclerView, newState);
                    }

                    @Override
                    public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                        super.onScrolled(recyclerView, dx, dy);

//                        if (type == JOIN_SQUARE) {
//                            if (linearLayoutManager.findLastCompletelyVisibleItemPosition() ==
//                                    (joinedServiceListAdapter.getItemCount() - 1)) {
//                                getServiceList(false);
//                            }
//                        }
                    }
                }

        );

        closeButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        loadUtilV2 = new LoadUtilV2(LayoutInflater.from(this));
    }

    @Override
    public void onResume() {
        super.onResume();
        if (Helper.sharedHelper().hasToken()) {
            if (type == SERVICE_JOIN_SQUARES) {
                getSquareList(true);
            } else {
                getServiceList(true);
            }
        } else {
            Router.sharedRouter().openFormResult("signin",
                    Constant.REQUEST_CODE_SIGNIN, this);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.REQUEST_CODE_SIGNIN) {
            if (RESULT_OK == resultCode) {
                if (type == SERVICE_JOIN_SQUARES) {
                    getSquareList(true);
                } else {
                    getServiceList(true);
                }
            } else {
                finish();
            }
        }
    }

    private void getSquareList(final boolean isReload) {
        JSONObject params = new JSONObject();
        params.put(Constant.REQUEST_PARAM_OFFSET, offset * PAGE_SIZE);
        params.put(Constant.REQUEST_PARAM_PAGE_SIZE, PAGE_SIZE);
        params.put("itemId", serviceItemId);
        loadUtilV2.loadPre(rootView, contentView);
        HttpClient.get("1.0/gezi/item/joinedList", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        loadUtilV2.loadSuccess(contentView);
                        btnComplete.setVisibility(View.VISIBLE);
                        if (obj != null) {
                            loadTips(obj);
                            loadSquareList(obj, isReload);
                            offset++;
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        loadUtilV2.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                            @Override
                            public void retry() {
                                getSquareList(true);
                            }
                        });
                    }
                });
    }

    private void getServiceList(final boolean isReload) {
        JSONObject params = new JSONObject();
        params.put("geziId", squareId);
        params.put(Constant.REQUEST_PARAM_OFFSET, offset * PAGE_SIZE);
        params.put(Constant.REQUEST_PARAM_PAGE_SIZE, PAGE_SIZE);
        loadUtilV2.loadPre(rootView, contentView);
        HttpClient.get("1.0/gezi/joinPage", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        loadUtilV2.loadSuccess(contentView);
                        btnComplete.setVisibility(View.VISIBLE);
                        if (obj != null) {
                            loadTips(obj);
                            loadServiceList(obj, isReload);
                            offset++;
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        loadUtilV2.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                            @Override
                            public void retry() {
                                getServiceList(true);
                            }
                        });
                    }
                });
    }

    private void loadTips(JSONObject data) {
        joinTips1.setText(data.getString("tips1"));
        tipsLayout1.setVisibility(TextUtils.isEmpty(data.getString("tips1")) ? View.GONE : View.VISIBLE);
        String tips2 = data.getString("tips2");
        String feePercent = data.getString("tips2Pos1");
        if (data.containsKey("scope")) {
            scope = data.getInteger("scope");
        }

        final String descriptionUrl = data.getString("url");

        if (!TextUtils.isEmpty(tips2) && !TextUtils.isEmpty(feePercent) &&
                !TextUtils.isEmpty(descriptionUrl)) {
            tipsLayout2.setVisibility(View.VISIBLE);
            String sourceText = tips2.replace("%@", feePercent);
            joinTips2.setText(StrUtil.getDigitSpanText(sourceText, feePercent,
                    getResources().getColor(R.color.brand_b),
                    getResources().getDimensionPixelSize(R.dimen.font_size_large)));
            serviceFeeButton.setVisibility(View.VISIBLE);
            serviceFeeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", descriptionUrl);
                    Router.sharedRouter().open("web", bundle);
                }
            });
        } else {
            tipsLayout2.setVisibility(View.GONE);
            serviceFeeButton.setVisibility(View.GONE);
        }

        if (type == SERVICE_JOIN_SQUARES) {
            serviceRestrictLayout.setVisibility(View.VISIBLE);
            serviceRestrictSwitch.setChecked(scope == 1);
            serviceRestrictSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    scope = isChecked ? 1 : 0;
                }
            });
        } else {
            serviceRestrictLayout.setVisibility(View.GONE);
        }
    }

    private void loadSquareList(JSONObject obj, boolean isReload) {
        JSONArray data = obj.getJSONArray("geziList");
        if (data == null) {
            return;
        }
        if (isReload) {
            squareItemList.clear();
        }
        for (int i = 0; i < data.size(); i++) {
            JSONObject squareObject = data.getJSONObject(i);
            if (null != squareObject) {
                SquareItem item = new SquareItem();
                item.setId(squareObject.getString("geziId"));
                item.setName(squareObject.getString("geziName"));
                item.setPicUrl(squareObject.getString("geziPicUrl"));
                item.setItemCount(squareObject.getInteger("itemCount"));
                item.setUserCount(squareObject.getInteger("userCount"));
                item.setDescription(squareObject.getString("geziTypeDesc"));
                item.setSelected(squareObject.getBoolean("selected"));
                squareItemList.add(item);
            }
        }
        String tips3 = obj.getString("tips3");
        if (!squareItemList.isEmpty()) {
            joinedSquareListAdapter.setData(squareItemList);
            joinedSquareListAdapter.notifyDataSetChanged();
            listHint.setText(tips3);
            listHint.setVisibility(View.VISIBLE);
        } else {
            listHint.setVisibility(View.GONE);
        }
    }

    private void loadServiceList(JSONObject obj, boolean isReload) {
        JSONArray itemList = obj.getJSONArray("itemList");
        if (itemList == null || itemList.isEmpty()) {
            joinSquare(false);
            return;
        }
        if (isReload) {
            serviceItemList.clear();
        }
        for (int i = 0; i < itemList.size(); i++) {
            JSONObject serviceObj = itemList.getJSONObject(i);
            JoinedServiceItem item = new JoinedServiceItem();
            item.setTitle(serviceObj.getString("title"));
            item.setFeeRate(serviceObj.getString("feeRate"));
            item.setItemId(serviceObj.getString("itemId"));
            item.setServiceTypeText(serviceObj.getString("serviceTypeText"));
            item.setStdCategoryName(serviceObj.getString("stdCategoryName"));
            item.setSelected(serviceObj.containsKey("selected") ? serviceObj.getBoolean("selected") : false);
            serviceItemList.add(item);
        }
        String tips3 = obj.getString("tips3");

        if (!serviceItemList.isEmpty()) {
            joinedServiceListAdapter.setData(serviceItemList);
            joinedServiceListAdapter.notifyDataSetChanged();
            listHint.setText(tips3);
            listHint.setVisibility(View.VISIBLE);
        } else {
            listHint.setVisibility(View.GONE);
        }
    }

    public void bindServiceToSquares() {
        JSONObject params = new JSONObject();
        JSONArray array = new JSONArray();

        for (String id : joinedSquareListAdapter.getSelectedItems()) {
            array.add(id);
        }

        params.put("itemId", serviceItemId);
        params.put("scope", scope);
        btnComplete.setEnabled(false);
        params.put("geziIdList", array);
        HttpClient.get("1.0/gezi/item/bindGezi", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        finish();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(error.toString());
                        btnComplete.setEnabled(true);
                        finish();
                    }
                });
    }

    private void joinSquare(boolean isBind) {
        JSONObject params = new JSONObject();
        JSONArray array = new JSONArray();

        if (isBind) {
            for (String id : joinedServiceListAdapter.getSelectedServiceIds()) {
                array.add(id);
            }
        }

        params.put("geziId", squareId);
        btnComplete.setEnabled(false);
        params.put("itemIdList", array);
        HttpClient.get("1.0/gezi/join", params, JSONObject.class,
                new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        setResult(RESULT_OK);
                        finish();
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(error.toString());
                        finish();
                    }
                });
    }
}
