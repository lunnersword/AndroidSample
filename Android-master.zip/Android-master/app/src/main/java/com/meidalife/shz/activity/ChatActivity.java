package com.meidalife.shz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentTabHost;
import android.support.v4.content.LocalBroadcastManager;
import android.text.Editable;
import android.text.Spannable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.wukong.AuthConstants;
import com.alibaba.wukong.Callback;
import com.alibaba.wukong.auth.AuthService;
import com.alibaba.wukong.im.Conversation;
import com.alibaba.wukong.im.ConversationService;
import com.alibaba.wukong.im.IMEngine;
import com.alibaba.wukong.im.Message;
import com.alibaba.wukong.im.MessageContent;
import com.alibaba.wukong.im.MessageListener;
import com.alibaba.wukong.im.MessageService;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.Pay;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.activity.fragment.ChatExpressionFragment;
import com.meidalife.shz.adapter.ChatAdapter;
import com.meidalife.shz.db.ChatTimer;
import com.meidalife.shz.db.ChatTimerDao;
import com.meidalife.shz.db.DaoSession;
import com.meidalife.shz.db.DatabaseManager;
import com.meidalife.shz.event.type.NetworkConnectTypeEnum;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.manager.WukongSender;
import com.meidalife.shz.media.AudioRecorder;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.AddressItem;
import com.meidalife.shz.rest.model.ChatDO;
import com.meidalife.shz.rest.model.MessageDO;
import com.meidalife.shz.rest.model.PositionOutDO;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.view.RecordButton;
import com.meidalife.shz.widget.PopupListMenu;
import com.usepropeller.routable.Router;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

public class ChatActivity extends BaseActivity implements ChatAdapter.MsgClickListener {
    private static final String LOG_TAG = "ChatActivity";

    private static final int PAGE_SIZE = 10;
    private static final int STATUS_TIMER_STOP = 0;
    private static final int STATUS_TIMER_PAUSE = 1;
    private static final int STATUS_TIMER_PLAY = 2;

    private static final int MENU_ITEM_BLACK_LIST = 1;
    private static final int MENU_ITEM_CANCEL = 2;
    private static final int MENU_ITEM_REPORT = 0;

    private long timeInterval = 0;
    private long HALF_HOUR = 1000 * 60 * 30; // 单位：微妙
    private int retry;
    private int minVersion = 195;
    private boolean isLoading = false;
    private boolean isMoreData = true;
    private boolean isTimerOn = false;

    private String receiverId;
    private String itemId;
    private String orderNo;

    private List<String> trueWordsList = new ArrayList<>();
    private ChatAdapter adapter;
    private Conversation conversation;
    private Message lastMessage = null;

    private ChatDO chatDO;

    private MessageService messageService;
    private MessageListener messageListener;
    private WukongSender wukongSender;
    private Handler handler;
    private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    private ChatHelper chatHelper;
    private Timer chatTimer = null;
    private DatabaseManager databaseManager;
    private DaoSession daoSession;

    @Bind(R.id.rootView)
    LinearLayout rootView;

    @Bind(R.id.menuButton)
    TextView menuButton;
    @Bind(R.id.itemInfoGroup)
    RelativeLayout itemInfoGroup;
    @Bind(R.id.itemImage)
    ImageView itemImage;
    @Bind(R.id.itemPrice)
    TextView itemPrice;
    @Bind(R.id.itemTitle)
    TextView itemTitle;
    @Bind(R.id.itemBuy)
    Button itemBuy;

    @Bind(R.id.listView)
    ListView listView;
    @Bind(R.id.timerLayout)
    ViewGroup timerLayout;
    @Bind(R.id.timer)
    TextView timer;
    @Bind(R.id.timerIndicator)
    TextView timerIndicator;
    @Bind(R.id.timerStatus)
    TextView timerStatus;

    @Bind(R.id.cellInputGroup)
    View cellInputGroup;
    @Bind(R.id.inputEdit)
    EditText inputEdit;
    @Bind(R.id.voiceRecord)
    RecordButton voiceRecord;
    @Bind(R.id.chatSend)
    View chatSend;
    @Bind(R.id.openAttach)
    View openAttach;

    @Bind(R.id.trueWords)
    ViewGroup trueWords;

    @Bind(R.id.rewardLayout)
    ViewGroup rewardLayout;

    @Bind(R.id.chatVoiceIcon)
    TextView chatVoiceIcon;

    @Bind(R.id.chatFaceIcon)
    TextView chatFaceIcon;
    @Bind(R.id.attachPanel)
    ViewGroup attachPanel;

    @Bind(R.id.chatFaceGroup)
    View chatFaceGroup;

    //发送图片
    @Bind(R.id.attachImg)
    View attachImg;
    //发送服务
    @Bind(R.id.attachService)
    View attachService;
    //发送位置
    @Bind(R.id.attachLBS)
    View attachLBS;
    @Bind(android.R.id.tabcontent)
    ViewGroup tabcontent;
    @Bind(android.R.id.tabhost)
    FragmentTabHost mTabHost;

    PopupListMenu mPopupListMenu;
    private long lastRemindOrderTime = 0;

    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (AuthConstants.Event.EVENT_AUTH_LOGIN.equals(action)) {
                initIM();
            } else if (AuthConstants.Event.EVENT_AUTH_LOGOUT.equals(action)) {
                //退出登录
            } else if (AuthConstants.Event.EVENT_AUTH_KICKOUT.equals(action)) {
                //被踢断线
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        initActionBar(R.string.im_state_start, true);
        ButterKnife.bind(this);
        handler = new Handler();

        Bundle bundle = getIntent().getExtras();
        receiverId = bundle.getString("receiverId");
        if (bundle.get("itemId") != null) {
            itemId = bundle.getString("itemId");
        }
        if (bundle.get("orderNo") != null) {
            orderNo = bundle.getString("orderNo");
        }

        adapter = new ChatAdapter(this, new ArrayList());
        adapter.setMsgClickListener(this);

        listView.setAdapter(adapter);

        AudioRecorder audioRecorder = new AudioRecorder();
        voiceRecord.setAudioRecord(audioRecorder);
        voiceRecord.setRecordListener(new VoiceRecordListener());

        initListener();

        chatHelper = ChatHelper.getInstance(this);

        IntentFilter intentFilter = new IntentFilter();

        intentFilter.addAction(AuthConstants.Event.EVENT_AUTH_LOGIN);
        intentFilter.addAction(AuthConstants.Event.EVENT_AUTH_LOGOUT);
        intentFilter.addAction(AuthConstants.Event.EVENT_AUTH_KICKOUT);

        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, intentFilter);

        databaseManager = DatabaseManager.getInstance();
        daoSession = databaseManager.getDaoSession();

        EventBus.getDefault().register(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        retry = 0;
        initIM();
        SHZApplication.getInstance().setCurrentChatUserId(receiverId);
    }

    @Override
    protected void onStop() {
        SHZApplication.getInstance().setCurrentChatUserId("");
        super.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        if (messageService != null) {
            messageService.removeMessageListener(messageListener);
        }
        if (conversation != null) {
            conversation.resetUnreadCount();
        }

        if (conversation != null) {
            if (!TextUtils.isEmpty(inputEdit.getText())) {
                conversation.updateDraftMessage(inputEdit.getText().toString());
            } else {
                conversation.updateDraftMessage("");
            }
        }
        if (null != adapter) {
            adapter.release();
        }
        stopTimer(isTimerOn ? STATUS_TIMER_PLAY : STATUS_TIMER_PAUSE);
    }

    public void onEventMainThread(NetworkConnectTypeEnum eventType) {
        if (NetworkConnectTypeEnum.TYPE_CONNECTED.equals(eventType)) {
            if (chatDO != null) {
                setActionBarTitle(chatDO.getReceiveUserName());
            }
        } else {
            setActionBarTitle("网络连接中...");
        }
    }

    public void onEventMainThread(ChatExpressionFragment.ChatExpressionEvent event) {
        Editable edit = inputEdit.getEditableText();//获取EditText的文字
        int index = inputEdit.getSelectionStart();
        if (index < 0 || index >= edit.length()) {
            edit.append(event.expressionName);
        } else {
            edit.insert(index, event.expressionName);//光标所在位置插入文字
        }
        ImageSpan expressionPan = chatHelper.getImageSpan(event.expressionName, 20);
        if (null != expressionPan) {
            edit.setSpan(expressionPan, index, index + event.expressionName.length(),
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    @Override
    public void avatarOnClickListener(String sendUserId) {
        Router.sharedRouter().open("profile/" + sendUserId);
    }

    @Override
    public void itemOnClickListener(String itemId) {
        Router.sharedRouter().open("services/" + itemId);
    }


    @Override
    public void convertViewOnClickListener(MessageDO msg) {
        Map<String, String> dataMap = msg.getExt();
        String lon = dataMap.get(Constant.GPS_LONG);
        String lat = dataMap.get(Constant.GPS_LAT);
        Bundle bundle = new Bundle();
//        bundle.putString(Constant.GPS_LONG, lon);
//        bundle.putString(Constant.GPS_LAT, lat);
//        Router.sharedRouter().open("location", bundle);
        try {
            bundle.putDouble(ViewLocationActivity.LOCATION_LNG, Double.parseDouble(lon));
            bundle.putDouble(ViewLocationActivity.LOCATION_LAT, Double.parseDouble(lat));
            Router.sharedRouter().open("viewPosition", bundle);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    /**
     * 选择其它内容后回调
     */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {

            case Constant.REQUEST_CODE_PICK_PHOTO: {
                // 选择图片
                if (resultCode == RESULT_OK && null != data) {
                    Bundle bundle = data.getExtras();
                    ArrayList<String> paths = bundle.getStringArrayList("images");
                    if (null != paths && !paths.isEmpty()) {
                        for (String path : paths) {
                            if (wukongSender != null) {
                                wukongSender.sendImageMessage(path);
                            }
                        }

                        finishSend();
                        attachPanel.setVisibility(View.GONE);
                    }
                }
                break;
            }
            case Constant.REQUEST_CODE_PICK_ADDRESS: {
                if (resultCode == RESULT_OK) {
                    Bundle extras = data.getExtras();
                    AddressItem addressItem = (AddressItem) extras.getSerializable(Constant.EXTRA_TAG_ADDRESS);
                    if (wukongSender != null) {
                        wukongSender.sendTextMessage(addressItem.getContactorName() + ", " +
                                addressItem.getContactorPhone() + ", " + addressItem.getAddressName());
                    }
                    finishSend();
                }
                break;
            }
            case Constant.REQUEST_CODE_PICK_LOCATION: {
                if (resultCode == RESULT_OK) {
                    Bundle extras = data.getExtras();
                    PositionOutDO positionOut = (PositionOutDO) extras.getSerializable("INTENT_SELECTED_ADDRESS");
                    if (wukongSender != null) {
                        wukongSender.sendPositionMessage(positionOut);
                    }
                    finishSend();
                }
                break;
            }

            case Constant.REQUEST_CODE_PICK_SERVICE: {
                if (resultCode == RESULT_OK) {
                    if (wukongSender != null) {
                        wukongSender.sendServiceMessage(data.getExtras());
                    }
                    finishSend();
                }
                break;
            }
            case Constant.REQUEST_CODE_REWARD: {
                if (resultCode == RESULT_OK && data != null) {
                    int rewardAmount = data.getIntExtra("amount", 0);
                    String desc = data.getStringExtra("rewardsDesc");
                    boolean result = data.getBooleanExtra(Pay.TAG_PAY_RESULT, false);
                    if (result && rewardAmount > 0) {
                        wukongSender.sendRewardMessage(rewardAmount, desc);
                        finishSend();
                        return;
                    } else {
                        MessageUtils.showToast(R.string.reward_failed);
                    }
                }

            }
        }
    }

    private void initListener() {
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHidePopMenu(v);
            }
        });
        inputEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chatFaceGroup.setVisibility(View.GONE);
                attachPanel.setVisibility(View.GONE);
                chatFaceIcon.setText(getString(R.string.icon_chat_face));
            }
        });
        inputEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    chatFaceGroup.setVisibility(View.GONE);
                    attachPanel.setVisibility(View.GONE);
                    chatFaceIcon.setText(getString(R.string.icon_chat_face));
                }
            }
        });
        inputEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().length() > 0) {
                    chatSend.setVisibility(View.VISIBLE);
                    openAttach.setVisibility(View.GONE);
                } else {
                    chatSend.setVisibility(View.GONE);
                    openAttach.setVisibility(View.VISIBLE);
                }
                if (inputEdit.getTag() != null && (Boolean) inputEdit.getTag()) {
                    inputEdit.setTag(false);
                    return; // 是表情输入，忽略此次内容变化
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == SCROLL_STATE_IDLE) {
                    if (view.getChildCount() > 0) {
                        View first = view.getChildAt(0);
                        if (first != null && view.getFirstVisiblePosition() == 0 && first.getTop() == 0) {
                            loadOldMessages();
                        }
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });
        listView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideKeyboard();
                attachPanel.setVisibility(View.GONE);
                return false;
            }
        });

        timerLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isTimerOn) {
                    stopTimer(STATUS_TIMER_PAUSE);
                } else {
                    startTimer();
                }
            }
        });

        timerStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isTimerOn) {
                    stopTimer(STATUS_TIMER_STOP);
                } else {
                    startTimer();
                }
            }
        });

        rewardLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle params = new Bundle();
                params.putString("receiverId", receiverId);
                params.putString("avatar", chatDO.getReceiveAvatar());
                Router.sharedRouter().openFormResult("rewards", params,
                        Constant.REQUEST_CODE_REWARD, ChatActivity.this);
            }
        });

        chatSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = inputEdit.getText().toString();
                if (!StrUtil.isEmpty(text)) {
                    wukongSender.sendTextMessage(text);
                    finishSend();
                }
            }
        });

        chatVoiceIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (chatDO.getReceiveVersion() < minVersion
                        && chatDO.getReceiveVersion() > 0) {
                    MessageUtils.showToastCenter("对方版本过低，将收不到你的语音");
                    return;
                }
                attachPanel.setVisibility(View.GONE);
                chatFaceGroup.setVisibility(View.GONE);
                hideKeyboard();
                if (inputEdit.getVisibility() == View.VISIBLE) {
                    chatFaceIcon.setVisibility(View.GONE);
                    inputEdit.setVisibility(View.GONE);
                    voiceRecord.setVisibility(View.VISIBLE);
                    chatVoiceIcon.setText(getString(R.string.icon_chat_keyboard));
                } else {
                    chatFaceIcon.setVisibility(View.VISIBLE);
                    inputEdit.setVisibility(View.VISIBLE);
                    voiceRecord.setVisibility(View.GONE);
                    chatVoiceIcon.setText(getString(R.string.icon_chat_voice));
                    inputEdit.setFocusable(true);
                    inputEdit.requestFocus();
                    openAttach.setVisibility(View.VISIBLE);
                    chatSend.setVisibility(View.GONE);
                    chatFaceIcon.setText(getString(R.string.icon_chat_face));
                }
            }
        });
        openAttach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard();
                chatFaceGroup.setVisibility(View.GONE);
                attachPanel.setVisibility(View.VISIBLE);
            }
        });

        chatFaceIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 再次点击显示输入键盘
                if (chatFaceGroup.getVisibility() == View.VISIBLE) {
                    chatFaceGroup.setVisibility(View.GONE);
                    attachPanel.setVisibility(View.GONE);
                    chatFaceIcon.setText(getString(R.string.icon_chat_face));
                    inputEdit.requestFocus();
                    return;
                }

                chatFaceIcon.setText(getString(R.string.icon_chat_keyboard));
                hideKeyboard();
                chatFaceGroup.setVisibility(View.VISIBLE);
                attachPanel.setVisibility(View.GONE);
            }
        });

        attachImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putBoolean("isCheckbox", true);
                bundle.putInt("maxLength", 9);
                Router.sharedRouter().openFormResult("pick/photo", bundle,
                        Constant.REQUEST_CODE_PICK_PHOTO, ChatActivity.this);
            }
        });

        attachService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (chatDO.getReceiveVersion() < minVersion
                        && chatDO.getReceiveVersion() > 0) {
                    MessageUtils.showToastCenter("对方版本过低，将收不到你的服务");
                    return;
                }
                Router.sharedRouter().openFormResult("pick/service",
                        Constant.REQUEST_CODE_PICK_SERVICE, ChatActivity.this);
            }
        });

        attachLBS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MessageUtils.singleChoiceDialog(ChatActivity.this, "", getResources()
                                .getStringArray(R.array.sendPosition), 0,
                        new MessageUtils.SingleChoiceDialogInterface() {

                            @Override
                            public void onNegative(DialogInterface dialog) {
                                dialog.dismiss();
                            }

                            @Override
                            public void onPositive(DialogInterface dialog, int checkedItem) {
                                processChecked(checkedItem);
                                dialog.dismiss();
                            }
                        });
            }
        });

        trueWords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendRandomTrueWord();
            }
        });

        mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);

        mTabHost.addTab(getTabSpecView("home", R.layout.item_single_image), ChatExpressionFragment.class, null);
    }

    private FragmentTabHost.TabSpec getTabSpecView(String tag, int layoutId) {
        return mTabHost.newTabSpec(tag).setIndicator(getLayoutInflater().inflate(layoutId, null));
    }

    private void showOrHidePopMenu(View v) {
        if (chatDO == null) {
            return;
        }
        if (null == mPopupListMenu) {
            mPopupListMenu = new PopupListMenu(this);
        }

        mPopupListMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case MENU_ITEM_BLACK_LIST: {
                        if (chatDO.isBlock()) {
                            unblockUser(chatDO.getReceiveUserId());
                        } else {
                            blockUser(chatDO.getReceiveUserId());
                        }
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_CANCEL: {
                        mPopupListMenu.dismiss();
                        break;
                    }
                    case MENU_ITEM_REPORT: {
                        doReport();
                        mPopupListMenu.dismiss();
                        break;
                    }
                }
            }
        });

        List<String> menuList = new ArrayList<>();

        menuList.add(MENU_ITEM_REPORT, getString(R.string.report));

        if (!chatDO.isBlock()) {
            menuList.add(MENU_ITEM_BLACK_LIST, getString(R.string.menu_item_blacklist));
        } else {
            menuList.add(MENU_ITEM_BLACK_LIST, getString(R.string.menu_item_remove_blacklist));
        }

        menuList.add(MENU_ITEM_CANCEL, getString(R.string.cancel));

        mPopupListMenu.setMenuData(menuList);

        if (mPopupListMenu.isShowing()) {
            mPopupListMenu.dismiss();
        } else {
            mPopupListMenu.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private void doReport() {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", String.valueOf(receiverId));
        intent.putExtra("target", Constant.REPORT_TYPE_IM);
        startActivity(intent);
    }

    private void startTimer() {
        if (isTimerOn) {
            return;
        }
        if (chatTimer == null) {
            chatTimer = new Timer();
        }

        chatTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                timeInterval += 1000;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setTimerValue();
                    }
                });
            }
        }, 0, 1000);

        isTimerOn = true;
        timerLayout.setVisibility(View.VISIBLE);
        timerIndicator.setText(R.string.icon_pause);
        timerStatus.setText(getString(R.string.icon_timer_used));
        setTimerValue();
    }

    private void stopTimer(int status) {
        if (chatDO == null || TextUtils.isEmpty(chatDO.getReceiveUserId())
                || !isTimerOn) {
            return;
        }

        //停止计时器重新计时
        if (status == STATUS_TIMER_STOP) {
            timeInterval = 0;
            timerLayout.setVisibility(View.GONE);
            timerStatus.setText(getString(R.string.icon_timer_normal));
        }
        ChatTimer currentChatTimer = new ChatTimer();
        currentChatTimer.setUserId(chatDO.getReceiveUserId());
        currentChatTimer.setInterval(timeInterval);
        currentChatTimer.setStatus(status);
        daoSession.getChatTimerDao().insertOrReplace(currentChatTimer);
        if (chatTimer != null) {
            chatTimer.cancel();
            chatTimer = null;
        }
        timerIndicator.setText(R.string.icon_play);
        setTimerValue();
        isTimerOn = false;
    }

    private void checkChatTimer() {
        ChatTimer savedChatTimer = daoSession.getChatTimerDao().queryBuilder().
                where(ChatTimerDao.Properties.UserId.eq(chatDO.getReceiveUserId())).
                build().unique();
        if (null != savedChatTimer && savedChatTimer.getStatus() == STATUS_TIMER_PLAY) {
            //继续上次播放
            timeInterval = savedChatTimer.getInterval();
            timerStatus.setText(getString(R.string.icon_timer_used));
            startTimer();
            timerLayout.setVisibility(View.VISIBLE);
        } else if (null != savedChatTimer && savedChatTimer.getStatus() == STATUS_TIMER_PAUSE) {
            timeInterval = savedChatTimer.getInterval();
            timerStatus.setText(getString(R.string.icon_timer_used));
            timerLayout.setVisibility(View.VISIBLE);
        } else {
            timerStatus.setText(getString(R.string.icon_timer_normal));
        }

        setTimerValue();
        timerStatus.setVisibility(View.VISIBLE);
    }

    private void setTimerValue() {
        SimpleDateFormat format = new SimpleDateFormat("mm:ss");
        Date date = new Date(timeInterval);
        String timerString = format.format(date);
        long hours = (timeInterval / 1000) / 3600;
        if (!TextUtils.isEmpty(timerString)) {
            if (hours > 0) {
                String hoursString = String.valueOf(hours).length() == 1 ?
                        ("0" + String.valueOf(hours)) : String.valueOf(hours);

                timer.setText(hoursString + ":" + timerString);
            } else {
                timer.setText(timerString);
            }
        }
    }

    private void sendRandomTrueWord() {
        Random random = new Random();
        int index = random.nextInt(trueWordsList.size());
        String trueWordString = trueWordsList.get(index);
        wukongSender.sendTextMessage(trueWordString);
        scrollToLast();
    }

    private void initTrueWordsList() {
        HttpClient.get("1.0/conversation/getTrueWordsList", new JSONObject(), null, new HttpClient.HttpCallback<JSONArray>() {
            @Override
            public void onSuccess(JSONArray obj) {
                if (obj != null && obj.size() > 0) {
                    for (int index = 0; index < obj.size(); index++) {
                        if (!trueWordsList.contains(obj.getString(index))) {
                            trueWordsList.add(obj.getString(index));
                        }
                    }
                }
                if (!trueWordsList.isEmpty()) {
                    trueWords.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(LOG_TAG, "Failed to init true word list" + error);
            }
        });
    }

    private void blockUser(String userId) {
        JSONObject params = new JSONObject();
        params.put("type", "1");
        params.put("anotherUserId", userId);

        HttpClient.get("1.0/relationship/user/bind", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                chatDO.setBlock(true);
                wukongSender.sendReminderMessage(MessageDO.REMIND_MESSAGE_TYPE_BLOCK, Helper.sharedHelper().getUserId());
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(LOG_TAG, "Failed to init true word list" + error);
            }
        });
    }

    private void unblockUser(String userId) {
        JSONObject params = new JSONObject();
        params.put("type", "1");
        params.put("anotherUserId", userId);
        HttpClient.get("1.0/relationship/user/unbind", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                chatDO.setBlock(false);
                wukongSender.sendReminderMessage(MessageDO.REMIND_MESSAGE_TYPE_UNBLOCK, Helper.sharedHelper().getUserId());
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(LOG_TAG, "Failed to init true word list" + error);
            }
        });
    }

    void processChecked(int position) {
        //发送当前位置 选择地图位置
        if (position == 0) {
            Router.sharedRouter().openFormResult("location",
                    Constant.REQUEST_CODE_PICK_LOCATION, ChatActivity.this);
        } else {
            Router.sharedRouter().openFormResult("addresses",
                    Constant.REQUEST_CODE_PICK_ADDRESS, ChatActivity.this);
        }
    }

    private void initIM() {
        if (!Helper.sharedHelper().hasToken()) {
            Router.sharedRouter().open("signin");
            finish();
            return;
        }

        if (!AuthService.getInstance().isLogin() && retry <= 5) {  // 此时用户已登录，等待鉴权成功，重试5次
            retry++;
            showStatusLoading(rootView);
            Long userId = Long.parseLong(Helper.sharedHelper().getUserId());

            if (IMEngine.getIMService(AuthService.class).latestAuthInfo().getOpenId() == userId) {
                IMEngine.getIMService(AuthService.class).autoLogin(userId);

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initIM();
                    }
                }, 500 + retry * 100);
            } else {
                ChatHelper.getInstance(this).authWuKong(Helper.sharedHelper().getUserId());
            }

        } else {
            hideStatusLoading();
            // 初始化会话
            initConversation();
        }
    }

    private void initConversation() {
        JSONObject params = new JSONObject();
        params.put("receiveUserId", receiverId);
        if (orderNo != null) {
            params.put("orderNo", orderNo);
        } else {
            params.put("itemId", itemId);
        }

        HttpClient.get("1.0/conversation/initWukongChat", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                /*
                渲染头部
                 */
                // 标题栏头部
                setActionBarTitle(obj.getString("receiveUserName"));
                // 用户信息
                chatDO = new ChatDO();
                String versionStr = obj.getString("receiveAppVersion");
                if (versionStr != null) {
                    chatDO.setReceiveVersion(Integer.parseInt(versionStr.replace(".", "")));
                }

                chatDO.setPushUserId(obj.getString("pushUserId"));
                chatDO.setPushUserName(obj.getString("pushUserName"));
                chatDO.setPushAvatar(obj.getString("pushAvatar"));
                chatDO.setReceiveUserId(obj.getString("receiveUserId"));
                chatDO.setReceiveUserName(obj.getString("receiveUserName"));
                chatDO.setReceiveAvatar(obj.getString("receiveAvatar"));
                // 商品信息
                if (obj.get("itemId") != null) {
                    chatDO.setItemId(obj.getString("itemId"));
                    chatDO.setItemOwnerId(obj.getString("itemOwnerId"));
                    chatDO.setItemPic(obj.getString("itemPic"));
                    chatDO.setItemPrice(obj.getString("itemPrice"));
                    chatDO.setItemTitle(obj.getString("itemTitle"));
                    chatDO.setOrderStatus(obj.getString("orderStatus")); // 订单相关
                    chatDO.setOrderNo(obj.getString("orderNo"));

                    chatDO.setIsRemindOrder(obj.getBoolean("isRemindOrder") == null ?
                            false : obj.getBoolean("isRemindOrder"));
                    chatDO.setImStatus(obj.getString("imStatus"));
                }
                // 渲染头部
                renderItemInfo(chatDO);

                chatDO.setIsChatCategory(obj.getBoolean("isChatCategory") == null ?
                        false : obj.getBoolean("isChatCategory"));

                chatDO.setBlock(obj.getBoolean("block") == null ?
                        false : obj.getBoolean("block"));

                chatDO.setBlocked(obj.getBoolean("blocked") == null ?
                        false : obj.getBoolean("blocked"));

                chatDO.setWelcome(obj.getString("welcome"));

                //只有在卖家界面，而且是陪聊类目时才显示计时器
                if (chatDO.isChatCategory() && !TextUtils.isEmpty(chatDO.getItemOwnerId())
                        && chatDO.getItemOwnerId().equals(Helper.sharedHelper().getUserId())) {
                    checkChatTimer();
                }

                if (chatDO.isChatCategory()) {
                    initTrueWordsList();
                }

                createConversation(Long.parseLong(receiverId));
            }

            @Override
            public void onFail(HttpError error) {
                setActionBarTitle("系统异常");
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootView);
                } else {
                    showStatusErrorServer(rootView);
                    if (!TextUtils.isEmpty(error.getMessage())) {
                        setTextErrorServer(error.getMessage());
                    }
                }
            }
        });
    }

    private void createConversation(long receiveId) {
        ConversationService conversationService = IMEngine.getIMService(ConversationService.class);
        listView.setVisibility(View.VISIBLE);

        conversationService.createConversation(new Callback<Conversation>() {

            @Override
            public void onSuccess(final Conversation conversation) {

                ChatActivity.this.conversation = conversation;

                // 发送IM消息
                wukongSender = new WukongSender(getApplicationContext(), chatDO, conversation, adapter);
                // 显示输入框
                cellInputGroup.setVisibility(View.VISIBLE);
                // 清零未读消息数
                conversation.resetUnreadCount();
                /*
                加载历史消息
                 */
                isLoading = true;
                conversation.listPreviousMessages(null, PAGE_SIZE, new Callback<List<Message>>() {
                    @Override
                    public void onSuccess(List<Message> messages) {
                        isLoading = false;
                        List<MessageDO> messageDOList = toMessageDO(messages, null, null);
                        if (messageDOList.isEmpty() && !TextUtils.isEmpty(chatDO.getWelcome())) {
                            MessageDO messageDO = new MessageDO();
                            messageDO.setType(MessageDO.MESSAGE_TYPE_TEXT);
                            messageDO.setText(chatDO.getWelcome());
                            messageDO.setSendUserId(chatDO.getReceiveUserId());
                            messageDO.setSendUserAvatar(chatDO.getReceiveAvatar());
                            messageDOList.add(messageDO);
                        }
                        adapter.setMessageList(messageDOList);
                        scrollToLast();
                        if (messages.size() > 0) {
                            lastMessage = messages.get(0);
                        }
                        if (messages.size() < PAGE_SIZE) {
                            isMoreData = false;
                        }
                    }

                    @Override
                    public void onException(String s, String s1) {
                        isLoading = false;
                        MessageUtils.showToast(getString(R.string.error_wukong_login_failed) + ":" + s + "; " + s1);
                        Log.d(LOG_TAG, s + "; " + s1);
                    }

                    @Override
                    public void onProgress(List<Message> messages, int i) {
                    }
                });
                /*
                建立消息监听器
                 */
                messageListener = new MessageListener() {
                    @Override
                    public void onAdded(List<Message> list, DataType dataType) {
                        //Log.e(ChatActivity.class.getName(), "MessageListener onAdded, size = " + list.size());
                        List<Message> filteredMsgList = new ArrayList<Message>();
                        for (Message m : list) {
                            String pushUserId = chatDO.getPushUserId();
                            if (m.conversation().conversationId() != conversation.conversationId())  // 不属于此会话
                                continue;
                            if (pushUserId.equals(String.valueOf(m.senderId())))     // 发送者自己发送
                                continue;
                            filteredMsgList.add(m);
                        }
                        if (filteredMsgList.size() > 0) {
                            List<MessageDO> messageDOList = toMessageDO(filteredMsgList, null, lastMessage);
                            adapter.addMessageList(messageDOList);
                            scrollToLast();
                        }
                    }

                    @Override
                    public void onRemoved(List<Message> list) {
                    }

                    @Override
                    public void onChanged(List<Message> list) {
                        //Log.e(ChatActivity.class.getName(), "message change callback ...");
                        String pushUserId = chatDO.getPushUserId();
                        Map<Long, Message> readedMap = new HashMap<Long, Message>();
                        for (Message m : list) {
                            if (pushUserId.equals(String.valueOf(m.senderId())) && m.unReadCount() <= 0) { // 发送者自己发送，且状态变为已读
                                readedMap.put(m.messageId(), m);
                            }
                        }
                        if (readedMap.size() == 0) {
                            return;
                        } else {
                            List<MessageDO> msgList = adapter.getMessageList();
                            for (MessageDO localMsg : msgList) {
                                if (localMsg.getMessage() == null) continue;
                                Message wkMsg = readedMap.get(localMsg.getMessage().messageId());
                                if (wkMsg != null)
                                    localMsg.setMessage(wkMsg);
                            }
                            adapter.notifyDataSetChanged();
                        }
                    }
                };
                messageService = IMEngine.getIMService(MessageService.class);
                messageService.addMessageListener(messageListener);

                if (!TextUtils.isEmpty(conversation.draftMessage())) {
                    inputEdit.setText(chatHelper.getExpressionSpanText(conversation.draftMessage(), 20));
                }
            }

            @Override
            public void onException(String s, String s1) {
                MessageUtils.showToastCenter(s + "; " + s1);
            }

            @Override
            public void onProgress(com.alibaba.wukong.im.Conversation conversation, int i) {
            }
        }, null, null, null, com.alibaba.wukong.im.Conversation.ConversationType.CHAT, receiveId);

    }

    private void loadOldMessages() {
        if (isLoading || !isMoreData) {
            return;
        } else {
            isLoading = true;
            conversation.listPreviousMessages(lastMessage, PAGE_SIZE, new Callback<List<Message>>() {
                @Override
                public void onSuccess(List<Message> messages) {
                    isLoading = false;
                    List<MessageDO> messageDOList = toMessageDO(messages, lastMessage, null);
                    adapter.headMessageList(messageDOList);
                    listView.setSelection(messageDOList.size());
                    if (messages.size() > 0) {
                        lastMessage = messages.get(0);
                    }
                    if (messages.size() < PAGE_SIZE) {
                        isMoreData = false;
                    }
                }

                @Override
                public void onException(String s, String s1) {
                    isLoading = false;
                    MessageUtils.showToastCenter(s + "; " + s1);
                }

                @Override
                public void onProgress(List<Message> messages, int i) {
                }
            });
        }
    }

    private List<MessageDO> toMessageDO(List<Message> messages, Message lastMsg, Message latestMsg) {

        List<MessageDO> messageDOList = new ArrayList<MessageDO>();

        for (Message m : messages) {

            MessageDO timeMessageDO = new MessageDO();
            /*
             计算是否显示时间
              */
            if (lastMsg == null && latestMsg == null) {  // 初始加载数据
                timeMessageDO.setType(MessageDO.MESSAGE_TYPE_TIME);
                timeMessageDO.setText(format.format(new Date(m.createdAt())));
                messageDOList.add(timeMessageDO);
            } else if (lastMsg == null && latestMsg != null) { // 新增聊天
                if (m.createdAt() - latestMsg.createdAt() > HALF_HOUR) {
                    timeMessageDO.setType(MessageDO.MESSAGE_TYPE_TIME);
                    timeMessageDO.setText(format.format(new Date(m.createdAt())));
                    messageDOList.add(timeMessageDO);
                }
            } else if (lastMsg != null && latestMsg == null) { // 加载历史，第一条数据
                timeMessageDO.setType(MessageDO.MESSAGE_TYPE_TIME);
                timeMessageDO.setText(format.format(new Date(m.createdAt())));
                messageDOList.add(timeMessageDO);
            } else if (lastMsg != null && latestMsg != null) { // 加载历史，后续数据
                if (m.createdAt() - latestMsg.createdAt() > HALF_HOUR) {
                    timeMessageDO.setType(MessageDO.MESSAGE_TYPE_TIME);
                    timeMessageDO.setText(format.format(new Date(m.createdAt())));
                    messageDOList.add(timeMessageDO);
                }
            }
            latestMsg = m;
            /*
             实际的消息
              */
            MessageDO messageDO = new MessageDO();
            MessageContent content = m.messageContent();
            if (content instanceof MessageContent.TextContent) {
                messageDO.setType(MessageDO.MESSAGE_TYPE_TEXT);
                messageDO.setText(((MessageContent.TextContent) content).text());
            } else if (content instanceof MessageContent.ImageContent) {
                messageDO.setType(MessageDO.MESSAGE_TYPE_IMG);
                messageDO.setImage(((MessageContent.ImageContent) content).url());
                content.type();
            } else if (content.type() == MessageDO.MESSAGE_TYPE_ADDRESS) {
                messageDO.setType(MessageDO.MESSAGE_TYPE_ADDRESS);
                MessageContent.MultiMessageContent multiMessageContent = (MessageContent.MultiMessageContent) content;
                MessageContent.CustomMessageContent customContent = (MessageContent.CustomMessageContent) multiMessageContent.contents().get(0);
                messageDO.setExt(customContent.extension());
            } else if (content instanceof MessageContent.AudioContent) {
                MessageContent.AudioContent audio = (MessageContent.AudioContent) content;
                messageDO.setType(MessageDO.MESSAGE_TYPE_VOICE);
                messageDO.setVoiceTime(audio.duration());
                messageDO.setVoiceUrl(audio.url());
            } else if (content.type() == MessageDO.MESSAGE_TYPE_SERVICE) {
                messageDO.setType(MessageDO.MESSAGE_TYPE_SERVICE);
                MessageContent.MultiMessageContent multiMessageContent = (MessageContent.MultiMessageContent) content;
                MessageContent.CustomMessageContent customContent = (MessageContent.CustomMessageContent) multiMessageContent.contents().get(0);
                messageDO.setExt(customContent.extension());
            } else if (content.type() == MessageDO.MESSAGE_TYPE_REMINDER) {
                MessageContent.MultiMessageContent multiMessageContent = (MessageContent.MultiMessageContent) content;
                MessageContent.CustomMessageContent customContent = (MessageContent.CustomMessageContent) multiMessageContent.contents().get(0);
                messageDO.setType(MessageDO.MESSAGE_TYPE_REMINDER);
                messageDO.setCustomType(customContent.customType());
                messageDO.setExt(customContent.extension());
            } else if (content.type() == MessageDO.MESSAGE_TYPE_BONUS) {
                messageDO.setType(MessageDO.MESSAGE_TYPE_BONUS);
                MessageContent.MultiMessageContent multiMessageContent = (MessageContent.MultiMessageContent) content;
                MessageContent.CustomMessageContent customContent = (MessageContent.CustomMessageContent) multiMessageContent.contents().get(0);
                messageDO.setExt(customContent.extension());
            } else {
                Log.e(ChatActivity.class.getName(), "unknwon msg type = " + content.type());
                continue;
            }
            String senderId = String.valueOf(m.senderId());

            if (receiverId.equals(senderId)) {
                messageDO.setSenderName(chatDO.getReceiveUserName());
                messageDO.setSendUserId(chatDO.getReceiveUserId());
                messageDO.setSendUserAvatar(chatDO.getReceiveAvatar());
            } else {
                messageDO.setSenderName(chatDO.getPushUserName());
                messageDO.setSendUserId(chatDO.getPushUserId());
                messageDO.setSendUserAvatar(chatDO.getPushAvatar());
            }
            messageDO.setMessage(m);
            messageDOList.add(messageDO);
        }
        return messageDOList;
    }

    private void renderItemInfo(final ChatDO chatDO) {
        /*
        说明是宝贝或订单
         */
        if (chatDO.getItemId() != null) {
            itemPrice.setText(chatDO.getItemPrice());
            itemTitle.setText(getString(R.string.label_i_can) + " " + chatDO.getItemTitle());
            ViewGroup.LayoutParams layoutParams = itemImage.getLayoutParams();
            itemImage.setImageURI(Uri.parse(ImgUtil.getCDNUrlWithWidth(chatDO.getItemPic(), layoutParams.width)));
            if (chatDO.getOrderNo() != null) {
                itemBuy.setBackgroundResource(R.drawable.chat_order_status_bg);
                itemBuy.setTextColor(getResources().getColor(R.color.brand_c));
                itemBuy.setText(chatDO.getOrderStatus());

                itemBuy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (chatDO.getOrderNo() != null) {
                            Router.sharedRouter().open("orderdetail/" + chatDO.getOrderNo());
                        } else {
                            Router.sharedRouter().open("order/" + chatDO.getItemId());
                        }
                    }
                });
            } else {
                itemBuy.setBackgroundResource(R.drawable.chat_buy_bg);
                itemBuy.setTextColor(getResources().getColor(R.color.white));

                if (chatDO.getItemOwnerId().equals(Helper.sharedHelper().getUserId())) {
                    if (chatDO.getIsRemindOrder()) {
                        itemBuy.setText(chatDO.getImStatus());
                        itemBuy.setVisibility(View.VISIBLE);
                        itemBuy.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (System.currentTimeMillis() - lastRemindOrderTime > 60000) {
                                    lastRemindOrderTime = System.currentTimeMillis();
                                    wukongSender.sendReminderMessage(MessageDO.REMIND_MESSAGE_TYPE_REMINDER,
                                            chatDO.getItemOwnerId());
                                } else {
                                    MessageUtils.showToast(R.string.reminder_message_remind_order_too_many);
                                }
                            }
                        });
                    } else {
                        itemBuy.setVisibility(View.GONE);
                    }
                } else {
                    itemBuy.setText("立即预约");
                    itemBuy.setVisibility(View.VISIBLE);
                    itemBuy.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (chatDO.getOrderNo() != null) {
                                Router.sharedRouter().open("orderdetail/" + chatDO.getOrderNo());
                            } else {
                                Router.sharedRouter().open("order/" + chatDO.getItemId());
                            }
                        }
                    });
                }
            }
            itemImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("services/" + chatDO.getItemId());
                }
            });

            itemInfoGroup.setVisibility(View.VISIBLE);
        }
        /*
        否则隐藏头部
         */
        else {
            itemInfoGroup.setVisibility(View.GONE);
        }
    }

    /*
    ----------- 一些通用用法 -----------
     */

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(inputEdit.getWindowToken(), 0);
    }

    public void finishSend() {
        inputEdit.setText(null);
        scrollToLast();
    }

    private void scrollToLast() {
        listView.post(new Runnable() {
            @Override
            public void run() {
                listView.setSelection(adapter.getCount() - 1);
            }
        });
    }

    class VoiceRecordListener implements RecordButton.RecordListener {
        @Override
        public void recordEnd(String filePath, long recordTime) {
            Log.e(ChatActivity.class.getName(), "record voice end, file = " + filePath + ", record time = " + recordTime);
            wukongSender.sendVoiceMessage(filePath, recordTime);
            finishSend();
        }
    }

    @Override
    public boolean isInterceptTouchEvent() {
        return false;
    }
}
