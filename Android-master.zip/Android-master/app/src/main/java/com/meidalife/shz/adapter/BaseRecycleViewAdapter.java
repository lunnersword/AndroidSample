package com.meidalife.shz.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;

import com.meidalife.shz.R;

import java.util.ArrayList;

/**
 * Created by fufeng on 15/12/23.
 */
public abstract class BaseRecycleViewAdapter extends RecyclerView.Adapter {
    private static final int HEADER_TYPE = R.integer.header_type;
    private static final int FOOTER_TYPE = R.integer.footer_type;

    private View mHeaderViews = null; //头视图
    private View mFooterViews = null;   //尾视图


    public void setHeaderView(View headerView) {
        mHeaderViews = headerView;
    }

    public void setFooterView(View footerView) {
        mFooterViews = footerView;
    }

    @Override
    final public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case HEADER_TYPE: {
                return new HeaderViewHolder(mHeaderViews);
            }
            case FOOTER_TYPE: {
                return new FooterViewHolder(mFooterViews);
            }
        }
        return onCreateContentViewHolder(parent, viewType);
    }

    @Override
    final public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        switch (holder.getItemViewType()) {
            case HEADER_TYPE: {
                return;
            }
            case FOOTER_TYPE: {
                return;
            }
        }
        onBindContentViewHolder(holder, position);
    }

    @Override
    final public int getItemCount() {
        return getContentItemCount() + (mFooterViews == null ? 0 : 1) + (mHeaderViews == null ? 0 : 1);
    }

    abstract public RecyclerView.ViewHolder onCreateContentViewHolder(ViewGroup parent, int viewType);

    abstract public void onBindContentViewHolder(RecyclerView.ViewHolder holder, int position);

    abstract public int getContentItemCount();

    @Override
    public int getItemViewType(int position) {
        if (position == 0 && mFooterViews != null) {
            return HEADER_TYPE;
        } else if (mFooterViews != null && (position == getItemCount() - 1)) {
            return FOOTER_TYPE;
        }
        return super.getItemViewType(position);
    }

    class HeaderViewHolder extends RecyclerView.ViewHolder {

        public HeaderViewHolder(View itemView) {
            super(itemView);
        }
    }

    class FooterViewHolder extends RecyclerView.ViewHolder {

        public FooterViewHolder(View itemView) {
            super(itemView);
        }
    }
}
