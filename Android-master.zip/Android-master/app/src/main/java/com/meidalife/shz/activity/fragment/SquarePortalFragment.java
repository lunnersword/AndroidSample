package com.meidalife.shz.activity.fragment;

import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.learnNcode.android.Clock;
import com.learnNcode.android.ExtendedListView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.GallerySquareAdapter;
import com.meidalife.shz.adapter.RecommendSquareAdapter;
import com.meidalife.shz.adapter.SquareSurroundAdapter;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.SquarePortalRefreshEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.PortalSquareDO;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.rest.model.SquareDynamicDO;
import com.meidalife.shz.rest.model.SquareDynamicOutDO;
import com.meidalife.shz.util.CollectionUtil;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.widget.SquareDividerItemDecoration;
import com.meidalife.shz.widget.TutorialPopupWindow;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by zuozheng on 15/12/16.
 * 格子首页
 */
public class SquarePortalFragment extends BaseFragment {
    private static final String LOG_TAG = "SquarePortalFragment";
    private static final int SQUARE_MAX_COUNT = 6;

//    Handler handler = new Handler();

    private View rootView;

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;

    /**
     * actionBar locationView
     */
//    @Bind(R.id.locationLayout)
//    ViewGroup locationLayout;
    @Bind(R.id.locationNameView)
    TextView locationNameView;

    /**
     * actionBar right navView
     */
    @Bind(R.id.squareNav)
    View squareNav;
    @Bind(R.id.squareNavDesc)
    TextView squareNavDesc;

    /**
     * sourrounding listview
     */
    @Bind(R.id.surroundingListView)
    ExtendedListView surroundingListView;

    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;


    @Bind(R.id.surroundingTitleTop)
    View surroundingTitleTop;

    //腰峰广告
//    @Bind(R.id.squarePortalAdViewLayout)
    View squarePortalAdViewLayout;
    //    @Bind(R.id.homeBeltAdv)
    SimpleDraweeView homeBeltAdv;


    View notJoinNavView;
    TextView squareCountTipView;
    GridView navGridView;
    View joinedNavView;

    View bottomIndexView;

    TextView currentPositionView;
    TextView totalCountView;


    //没有数据提示view
    View noDataHeadTipView;
    //    ViewPager viewPager;
    RecyclerView mRecyclerView;
    TutorialPopupWindow tutorialPopupWindow;

    List<SquareDO> recommendSquareList;
    private RecommendSquareAdapter mRecSquareAdapter;

    private SquareSurroundAdapter surroundingAdapter;

    private GallerySquareAdapter mGallerySquareAdapter;

    private LoadUtilV2 loadUtil;
    PortalSquareDO squareDO = new PortalSquareDO();

    private AMapLocationManager mLocationManager;
    private boolean needLocation = false;
    LocationDO mLocation;
    List<SquareDynamicDO> dynamicList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_square_portal, null);

            ButterKnife.bind(this, rootView);

            View listHeader = getLayoutInflater(savedInstanceState).inflate(R.layout.fragment_square_portal_header, null);
            initHeadView(listHeader);
            surroundingListView.addHeaderView(listHeader);

            loadUtil = new LoadUtilV2(inflater);
            initListener();
        }

        return rootView;
    }

    void initHeadView(View view) {

        squarePortalAdViewLayout = view.findViewById(R.id.squarePortalAdViewLayout);

        homeBeltAdv = (SimpleDraweeView) view.findViewById(R.id.homeBeltAdv);
        /**
         * navBodyView
         */
        notJoinNavView = view.findViewById(R.id.notJoinNavView);

        noDataHeadTipView = view.findViewById(R.id.noDataTipView);

        /**
         * nav square count tips
         */
        squareCountTipView = (TextView) view.findViewById(R.id.squareCountTipView);
        /**
         * square listView
         */
        navGridView = (GridView) view.findViewById(R.id.navGridView);


        joinedNavView = view.findViewById(R.id.joinedNavView);

        bottomIndexView = view.findViewById(R.id.bottomIndexView);
        currentPositionView = (TextView) view.findViewById(R.id.currentIndex);
        totalCountView = (TextView) view.findViewById(R.id.totalCount);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.id_recyclerview_horizontal);

        //设置布局管理器
        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);

        int spacingInPixels = getResources().getDimensionPixelSize(R.dimen.square_item_space);
        mRecyclerView.addItemDecoration(new SquareDividerItemDecoration(spacingInPixels));
        //设置适配器

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                //解决横向滑动和SwipeRefreshLayout下拉事件冲突
                mSwipeRefreshLayout.setEnabled(newState == RecyclerView.SCROLL_STATE_IDLE);
                recyclerView.getX();
                View view = recyclerView.findChildViewUnder(recyclerView.getX(), recyclerView.getY()); //获取点击项的view
                int idx = recyclerView.getChildAdapterPosition(view) + 2;//获取点击项view在adapter的索引位置

                int maxPosition = Math.min(5, idx);
                currentPositionView.setText("" + maxPosition);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }
        });
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mLocationManager = SHZApplication.getInstance().getLocationManager();
        mLocation = mLocationManager.getLocation();

        if (mLocation != null && mLocation.getLongitude() > 0) {
            requestSquareData(mLocation);
            updateLBSInfo(mLocation);
        } else {
            needLocation = true;
            getCurrentLbsLocation();
        }
    }

    void getCurrentLbsLocation() {
        mLocationManager.updateLocation(mLocationChangedListener);
    }

    private AMapLocationManager.LocationChangedListener mLocationChangedListener = new AMapLocationManager.LocationChangedListener() {

        @Override
        public void onLocationUpdateFailed() {
            needLocation = true;

            //定位失败 使用选择城市id请求数据
            mLocation = new LocationDO();
            mLocation.setCityCode(Helper.sharedHelper().getStringUserInfo(Constant.SELECT_CITY_CODE));
            requestSquareData(mLocation);
        }

        @Override
        public void onLocationChanged(LocationDO location) {
            mLocation = location;
            updateLBSInfo(location);

            //定位成功 重新请求数据
            requestSquareData(location);

            if (needLocation) {
                needLocation = false;
            }

        }
    };

    @Override
    public void onResume() {
        super.onResume();
        showTutorial();
        EventBus.getDefault().register(this);

    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
//        LocalBroadcastManager.getInstance(SHZApplication.getInstance()).unregisterReceiver(mLocationReceiver);
    }

    public void onEvent(SquarePortalRefreshEvent event) {
        if (MsgTypeEnum.TYPE_REFRESH == event.eventType) {
            requestSquareData(mLocation);
        }
    }

    @Override
    public void onDestroyView() {
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    void initListener() {
//        mSwipeRefreshLayout.setVisibility(View.GONE);
//        mSwipeRefreshLayout.setEnabled(false);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(false);
                requestSquareData(mLocation);
            }
        });

        navGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //todo
                // 使用 initIm 接口调用 方式
                if (CollectionUtil.isNotEmpty(recommendSquareList) && position < recommendSquareList.size()) {
                    SquareDO square = recommendSquareList.get(position);
                    if (square != null) {
                        String action = "squareindex/";
                        action += square.getGeziId();
                        //用户未登陆 进入格子详情
                        Router.sharedRouter().open(action);

                        try {
                            LogParam param = new LogParam();
                            param.setType(LogUtil.TYPE_CUSTOMIZE);
                            param.setEid(LogUtil.EVENT_ID_SQUARE_HOME_ITEM_CLICK);
                            param.setGeziid(String.valueOf(square.getGeziId()));
                            LogUtil.log(param);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

        squareNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("ssswithmap", getActivity());
            }
        });

        surroundingListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (surroundingListView.getFirstVisiblePosition() >= 1) {
                    surroundingTitleTop.setVisibility(View.VISIBLE);
                } else {
                    surroundingTitleTop.setVisibility(View.GONE);
                }
            }
        });
        surroundingListView.setCacheColorHint(Color.TRANSPARENT);

        surroundingListView.setOnPositionChangedListener(new ExtendedListView.OnPositionChangedListener() {
            @Override
            public void onPositionChanged(ExtendedListView listView, int position, View scrollBarPanel) {

                ViewGroup viewGroup = (ViewGroup) scrollBarPanel.findViewById(R.id.scrollbar_panel_layout);
                if (CollectionUtil.isNotEmpty(dynamicList) && position > 0 && (position - 1) < dynamicList.size()) {
                    SquareDynamicDO dynamicDO = dynamicList.get(position - 1);
                    TextView tv = (TextView) scrollBarPanel.findViewById(R.id.timeTextView);

                    try {
                        if (dynamicDO != null) {
                            String timeStr = dynamicDO.getCreateTimeByHour();
                            tv.setText(timeStr);

                            Clock analogClockObj = (Clock) scrollBarPanel.findViewById(R.id.analogClockScroller);
                            String[] timeArray = timeStr != null ? timeStr.split(":") : new String[]{"0", "0"};
                            Time timeObj = new Time();
                            analogClockObj.setSecondHandVisibility(false);
                            viewGroup.setVisibility(View.VISIBLE);
                            if (timeArray != null && timeArray.length > 1) {
                                timeObj.set(0, Integer.parseInt(timeArray[1]), Integer.parseInt(timeArray[0]), 0, 0, 0);
                            } else {
                                timeObj.set(0, 0, 0, 0, 0, 0);
                            }
                            analogClockObj.onTimeChanged(timeObj);
                        }
                    } catch (Exception e) {
                    }
                } else {
                    viewGroup.setVisibility(View.GONE);
                }
            }
        });

    }

    void updateLBSInfo(LocationDO location) {
        if (location != null) {
            locationNameView.setText(location.getAddress());
        } else {
            locationNameView.setText("定位失败");
        }
    }

    JSONObject getParam(LocationDO location) {
        JSONObject params = new JSONObject();
        if (location != null) {
            params.put("cityCode", location.getCityCode());
            params.put("longitude", location.getLongitude());
            params.put("latitude", location.getLatitude());
        }
        return params;
    }

    private void requestSquareData(final LocationDO location) {
        loadUtil.loadPre(rootLayout, mSwipeRefreshLayout);

        HttpClient.get("1.0/gezi/home", getParam(location), PortalSquareDO.class, new HttpClient.HttpCallback<PortalSquareDO>() {
            @Override
            public void onSuccess(PortalSquareDO result) {
                mSwipeRefreshLayout.setRefreshing(false);
                loadUtil.loadSuccess(mSwipeRefreshLayout);

                squareDO = result;
                requestDynamicData(location);
            }

            @Override
            public void onFail(HttpError error) {
                mSwipeRefreshLayout.setRefreshing(false);

                loadUtil.loadFail(error, rootLayout, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        requestSquareData(location);
                    }
                });

                squareDO = new PortalSquareDO();
            }
        });
    }

    private void requestDynamicData(LocationDO location) {
        HttpClient.get("1.1/gezi/surroundings", getParam(location), Object.class, new HttpClient.HttpCallback<Object>() {
            @Override
            public void onSuccess(Object result) {
                if (getActivity() == null || getActivity().isFinishing()) {
                    return;
                }
//                mSwipeRefreshLayout.setEnabled(true);
                mSwipeRefreshLayout.setVisibility(View.VISIBLE);

                updateSquareView();
                try {
                    //结果有时候回返回数组 增加异常处理
                    if (result instanceof JSONArray) {
                        return;
                    }

                    if (result instanceof JSONObject) {
                        JSONObject dataObj = (JSONObject) result;
                        SquareDynamicOutDO obj = JSON.parseObject(dataObj.toString(), SquareDynamicOutDO.class);
                        //加载腰峰广告
                        JSONArray homeBeltAdArray = obj.getAdList();
                        loadHomeBelt(homeBeltAdArray);

                        loadDynamic(obj.getSurroundingsList());
                    }
                } catch (JSONException e) {

                }
            }

            @Override
            public void onFail(HttpError error) {
//                mSwipeRefreshLayout.setEnabled(true);
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    private void loadHomeBelt(JSONArray data) {
        if (CollectionUtil.isEmpty(data)) {
            squarePortalAdViewLayout.setVisibility(View.GONE);
            return;
        }

        squarePortalAdViewLayout.setVisibility(View.VISIBLE);
        com.alibaba.fastjson.JSONObject homBeltData = data.getJSONObject(0);
        final String linkUrl = homBeltData.getString("url");
        homeBeltAdv.setImageURI(Uri.parse(homBeltData.getString("pic")));
        homeBeltAdv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", linkUrl);
                Router.sharedRouter().open("web", bundle);
            }
        });
    }

    void loadDynamic(List<SquareDynamicDO> result) {
        if (CollectionUtil.isNotEmpty(result)) {
            dynamicList = result;
        } else {
            if (result == null) {
                result = new ArrayList<SquareDynamicDO>();
            }

            if (Helper.isLocationEnabled(getActivity())) {
                if (needLocation) {
                    //开启定位  定位失败
                    SquareDynamicDO error = new SquareDynamicDO();
                    error.setErrorDesc("定位失败，请检查定位设置");
                    error.setErrorType(1);
                    result.add(error);
                } else {
                    if (result == null || result.size() <= 0) {
                        SquareDynamicDO noDataError = new SquareDynamicDO();
                        noDataError.setErrorDesc("努力搜集中");
                        noDataError.setErrorType(2);
                        result.add(noDataError);
                    }
                }
            } else {
                //用户没有开启定位
                SquareDynamicDO error = new SquareDynamicDO();
                error.setErrorDesc("未开启定位，点击设置");
                error.setErrorType(1);
                result.add(error);
            }
        }

        updateDynamicView(result);
    }

    void updateSquareView() {
        if (squareDO != null) {
            int surroundSquareCount = squareDO != null ? squareDO.getSurroundingGeziCount() : 0;
            List<SquareDO> squareList = squareDO.getGeziList();
            if (squareDO.isJoined()) {
                //如果已经加入 显示滚动列表
                notJoinNavView.setVisibility(View.GONE);
                joinedNavView.setVisibility(View.VISIBLE);
                bottomIndexView.setVisibility(View.VISIBLE);
                noDataHeadTipView.setVisibility(View.GONE);

                //格子数量大于0
                if (CollectionUtil.isNotEmpty(squareList)) {
                    //最多显示5个格子
                    if (squareList.size() > 5) {
                        squareList = squareList.subList(0, 5);
                    }

                    bottomIndexView.setVisibility(View.VISIBLE);
                    currentPositionView.setText("1");
                    int maxTotalCount = Math.min(SQUARE_MAX_COUNT - 1, squareList.size());
                    totalCountView.setText("" + maxTotalCount);
                }

                if (squareDO.getJoinedCount() > 5) {
                    squareList.add(new SquareDO());
                }

                mGallerySquareAdapter = new GallerySquareAdapter(getActivity(), squareList, squareDO.getJoinedCount());
                mRecyclerView.setAdapter(mGallerySquareAdapter);


            } else {
                joinedNavView.setVisibility(View.GONE);
                bottomIndexView.setVisibility(View.GONE);

                if (surroundSquareCount > 0) {
                    notJoinNavView.setVisibility(View.VISIBLE);
                    noDataHeadTipView.setVisibility(View.GONE);

                    squareCountTipView.setText(String.format(getActivity().getResources().getString(R.string.str_square_count_tip), surroundSquareCount));
                    recommendSquareList = squareDO != null ? squareDO.getGeziList() : null;
                    mRecSquareAdapter = new RecommendSquareAdapter(getActivity(), recommendSquareList);
                    navGridView.setAdapter(mRecSquareAdapter);

                } else {
                    notJoinNavView.setVisibility(View.GONE);
                    noDataHeadTipView.setVisibility(View.VISIBLE);
                    noDataHeadTipView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Router.sharedRouter().open("createSquare", getActivity());
                        }
                    });
                }
            }

            squareNavDesc.setText(String.format(getActivity().getResources().getString(R.string.str_square_count), surroundSquareCount));
        }
    }


    void updateDynamicView(List<SquareDynamicDO> result) {
        surroundingAdapter = new SquareSurroundAdapter(getActivity(), result, squareDO);
        surroundingListView.setAdapter(surroundingAdapter);
    }

    private void showTutorial() {
        try {
            if (Helper.sharedHelper().getBooleanUserInfo(Constant.SQUARE_FIRST_IN, true) && null != getActivity()) {
                if (tutorialPopupWindow == null) {
                    tutorialPopupWindow = new TutorialPopupWindow(getActivity(),
                            TutorialPopupWindow.TUTORIAL_TYPE_ENTER_SQUARE);

                    tutorialPopupWindow.setOnFinishListener(new TutorialPopupWindow.OnFinishListener() {
                        @Override
                        public void onFinish() {
                            Helper.sharedHelper().setBooleanUserInfo(Constant.SQUARE_FIRST_IN, false);
                        }
                    });
                }
                if (!tutorialPopupWindow.isShowing() && !getActivity().isFinishing()) {
                    tutorialPopupWindow.showTutorial(rootView);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
