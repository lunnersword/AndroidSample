package com.meidalife.shz.activity;

import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.R;
import com.meidalife.shz.activity.fragment.CategoryFragment;
import com.meidalife.shz.adapter.CategoryFilterTabAdapter;
import com.meidalife.shz.adapter.FragmentTabAdapter;
import com.meidalife.shz.adapter.TodayRecommendationAdapter;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.BaseEvent;
import com.meidalife.shz.event.CategoryFilterEvent;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CategoryDO;
import com.meidalife.shz.rest.model.TodayRecommendItem;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.widget.DragTopLayout;
import com.meidalife.shz.widget.SlidingTabLayout;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.umeng.socialize.media.UMImage;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * 二级类目
 * Created by fufeng on 15/11/9.
 */
public class CategoryActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener, ViewPager.OnPageChangeListener {
    private int categoryId = Integer.MAX_VALUE;
    private String contentBannerBgUrl;
    private String categoryTitleString;
    private String categoryContentString;

    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.bannerBackgroud)
    SimpleDraweeView bannerBackgroud;
    @Bind(R.id.titleBar)
    ViewGroup titleBar;
    //标题栏目
    @Bind(R.id.backButton)
    TextView backButton;
    @Bind(R.id.title)
    TextView title;
    @Bind(R.id.searchIcon)
    TextView searchIcon;
    @Bind(R.id.shareIcon)
    TextView shareIcon;

    //类目标题
    @Bind(R.id.categoryBannerLayout)
    ViewGroup categoryBannerLayout;
    @Bind(R.id.categoryTitle)
    TextView categoryTitle;
    @Bind(R.id.categorySubTitle)
    TextView categorySubTitle;
    @Bind(R.id.browseCount)
    TextView browseCount;
    @Bind(R.id.favCount)
    TextView favCount;

    //今日推荐
    @Bind(R.id.todayRecommendLayout)
    ViewGroup todayRecommendLayout;
    @Bind(R.id.divider1)
    View divider1;
    @Bind(R.id.todayRecommendLabel)
    TextView todayRecommendLabel;
    @Bind(R.id.recommendCount)
    TextView recommendCount;
    @Bind(R.id.todayRecommendations)
    RecyclerView todayRecommendations;
    TodayRecommendationAdapter todayRecommendationAdapter;

    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @Bind(R.id.categorySlidingTab)
    SlidingTabLayout categorySlidingTab;
    @Bind(R.id.categoryTabViewPager)
    ViewPager categoryTabViewPager;
    @Bind(R.id.dragLayout)
    DragTopLayout dragTopLayout;
    @Bind(R.id.tagGridView)
    GridView tagGridView;
    @Bind(R.id.tagLine)
    View tagLine;

    private FragmentTabAdapter categoryPagerAdapter;
    private SocialSharePopupWindow socialSharePopupWindow;
    private ShareActivity shareActivity;
    private CategoryFilterTabAdapter categoryFilterTabAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        ButterKnife.bind(this);

        initComponent();
        loadData(true);
    }

    @Override
    public void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void reportPause() {
        LogParam param = new LogParam();
        param.setType(LogUtil.TYPE_EXIT_PAGE);
        param.setPid(this.getClass().getName());
        param.setCategoryId(String.valueOf(categoryId));
        LogUtil.log(param);
    }

    @Override
    public void reportResume() {
        LogParam param = new LogParam();
        param.setType(LogUtil.TYPE_START_PAGE);
        param.setPid(this.getClass().getName());
        param.setCategoryId(String.valueOf(categoryId));
        LogUtil.log(param);
    }

    public void onEvent(BaseEvent event) {
        if (event.eventType == MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE ||
                event.eventType == MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE) {
            if (event.eventType == MsgTypeEnum.TYPE_DISABLE_TOUCH_MODE) {
                swipeRefreshLayout.setEnabled(dragTopLayout.getState() == DragTopLayout.PanelState.EXPANDED);
            }
            dragTopLayout.setTouchMode(event.eventType == MsgTypeEnum.TYPE_ENABLE_TOUCH_MODE);
        }
    }

    private void initComponent() {
        try {
            categoryId = Integer.valueOf(getIntent().getStringExtra("catId"));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        todayRecommendationAdapter = new TodayRecommendationAdapter(this, String.valueOf(categoryId));
        todayRecommendations.setAdapter(todayRecommendationAdapter);

        //设置布局管理器
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        todayRecommendations.setLayoutManager(linearLayoutManager);


        categoryFilterTabAdapter = new CategoryFilterTabAdapter(this, new JSONArray());
        categoryFilterTabAdapter.setTagNameKey("tag");
        tagGridView.setAdapter(categoryFilterTabAdapter);
        categoryPagerAdapter = new FragmentTabAdapter(getSupportFragmentManager());

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        todayRecommendations.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                swipeRefreshLayout.setEnabled(newState == RecyclerView.SCROLL_STATE_IDLE
                        && dragTopLayout.getState() == DragTopLayout.PanelState.EXPANDED);
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }
        });

        shareIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHideShareList(v);
            }
        });

        searchIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("search_res");
            }
        });
        swipeRefreshLayout.setOnRefreshListener(this);
        categorySlidingTab.setOnTabClickListener(new SlidingTabLayout.OnTabClickListener() {
            @Override
            public void onClick(View v, int position, int oldPosition) {
                if (position != oldPosition) {
                    EventBus.getDefault().post(new CategoryFilterEvent(MsgTypeEnum.TYPE_REFRESH, categoryFilterTabAdapter.getStdCatId()));
                    dragTopLayout.closeTopView(true);
                }
                LogParam param = new LogParam();
                param.setType(LogUtil.TYPE_CUSTOMIZE);
                param.setEid(LogUtil.EVENT_ID_CATEGORY_CLICK);
                param.setPoid(String.valueOf(position + 1));
                LogUtil.log(param);
            }
        });

        dragTopLayout.listener(new DragTopLayout.PanelListener() {
            @Override
            public void onPanelStateChanged(DragTopLayout.PanelState panelState) {
                if (panelState == DragTopLayout.PanelState.COLLAPSED) {
                    title.setText(categoryTitleString);
                } else {
                    title.setText("");
                }

                if (panelState == DragTopLayout.PanelState.EXPANDED) {
                    swipeRefreshLayout.setEnabled(true);
                } else if (panelState == DragTopLayout.PanelState.COLLAPSED) {
                    swipeRefreshLayout.setEnabled(false);
                }
            }

            @Override
            public void onSliding(float ratio) {

            }

            @Override
            public void onRefresh() {

            }
        });

        dragTopLayout.setSmoothDrag(false);
    }

    private void loadData(boolean showLoading) {
        if (showLoading) {
            showStatusLoading(rootLayout);
        }
        JSONObject params = new JSONObject();
        params.put("catId", categoryId);
        HttpClient.get("1.0/category/info", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                setBanner(result);
                setTodayRecommendation(result);
                loadCategoryTabs(result.getJSONArray("tabs"));
                loadFilterTabs(result.getJSONArray("tagList"));
                titleBar.setVisibility(View.VISIBLE);
                swipeRefreshLayout.setVisibility(View.VISIBLE);
                categoryBannerLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                titleBar.setVisibility(View.GONE);
                swipeRefreshLayout.setVisibility(View.GONE);
                categoryBannerLayout.setVisibility(View.GONE);
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(rootLayout, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            loadData(true);
                        }
                    });
                } else {
                    showStatusErrorServer(rootLayout, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            loadData(true);
                        }
                    });
                }
            }
        });
    }

    private void setBanner(JSONObject result) {
        contentBannerBgUrl = result.getString("bannerUrl");
        String cdnUrl = ImgUtil.getCDNUrlWithWidth(result.getString("bannerUrl"),
                getResources().getDimensionPixelSize(R.dimen.category_banner_height));

        categoryTitleString = result.getString("title");
        categoryContentString = result.getString("subTitle");
        bannerBackgroud.setImageURI(Uri.parse(cdnUrl));
        categoryTitle.setText(categoryTitleString);
        categorySubTitle.setText(categoryContentString);

        browseCount.setText(result.getString("browseCount"));
        favCount.setText(result.getString("favCount"));
    }

    private void setTodayRecommendation(JSONObject result) {
        List<TodayRecommendItem> recommendItemList = new ArrayList<>();
        todayRecommendLabel.setText(result.getString("choiceTitle"));
        recommendCount.setText(result.getString(""));
        JSONArray todayRecommendationArray = result.getJSONArray("today");
        if (todayRecommendationArray == null || todayRecommendationArray.isEmpty()) {
            todayRecommendLayout.setVisibility(View.GONE);
            divider1.setVisibility(View.GONE);
            return;
        }

        for (int i = 0; i < todayRecommendationArray.size(); i++) {
            JSONObject today = (JSONObject) todayRecommendationArray.get(i);
            TodayRecommendItem item = new TodayRecommendItem();
            item.setIconUrl(today.getString("image"));
            item.setTitle(today.getString("title"));
            item.setPrice(today.getString("price"));
            item.setLink(today.getString("url"));
            item.setPvid(today.getString("pvid"));
            recommendItemList.add(item);
        }
        if (!recommendItemList.isEmpty()) {
            todayRecommendationAdapter.setData(recommendItemList);
            todayRecommendationAdapter.notifyDataSetChanged();
            todayRecommendLayout.setVisibility(View.VISIBLE);
            divider1.setVisibility(View.VISIBLE);
        }
    }

    private void loadCategoryTabs(JSONArray data) {
        if (data == null || data.isEmpty()) {
            return;
        }
        categoryPagerAdapter.clear();

        for (int i = 0; i < data.size(); i++) {
            JSONObject catJson = data.getJSONObject(i);
            CategoryDO category = new CategoryDO();
            category.setCatName(catJson.getString("title"));
            category.setTabId(catJson.getInteger("tabId"));
            category.setNeedPoi(catJson.getBoolean("needPOI"));
            category.setCatId(categoryId);
            if (categoryFilterTabAdapter != null) {
                category.setStdCatId(categoryFilterTabAdapter.getStdCatId());
            }

            categoryPagerAdapter.addFragment(CategoryFragment.newInstance(category));
        }
        categoryTabViewPager.setAdapter(categoryPagerAdapter);
        categoryPagerAdapter.notifyDataSetChanged();
        categorySlidingTab.setCustomTabView(R.layout.item_category, R.id.categoryName);
        categorySlidingTab.setSelectedIndicatorColors(getResources().getColor(R.color.brand));
        categorySlidingTab.setViewPager(categoryTabViewPager);
        categorySlidingTab.setDividerColors(android.R.color.transparent);

        categorySlidingTab.setOnPageChangeListener(this);
    }

    private void loadFilterTabs(JSONArray tagList) {
        if (tagList == null || tagList.isEmpty()) {
            tagLine.setVisibility(View.GONE);
            return;
        }
        tagLine.setVisibility(View.VISIBLE);
        categoryFilterTabAdapter.setTabList(tagList);
        tagGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == categoryFilterTabAdapter.getSelectPos()) {
                    if (position == 0)
                        return;
                    categoryFilterTabAdapter.setSelectPos(0);
                } else
                    categoryFilterTabAdapter.setSelectPos(position);
                categoryFilterTabAdapter.notifyDataSetChanged();
                EventBus.getDefault().post(new CategoryFilterEvent(MsgTypeEnum.TYPE_REFRESH, categoryFilterTabAdapter.getStdCatId()));
            }
        });
        categoryFilterTabAdapter.notifyDataSetChanged();
    }

    @Override
    public void onRefresh() {
        swipeRefreshLayout.setRefreshing(false);
        EventBus.getDefault().post(new CategoryFilterEvent(MsgTypeEnum.TYPE_REFRESH, categoryFilterTabAdapter.getStdCatId()));
    }

    private void showOrHideShareList(View v) {
        if (socialSharePopupWindow == null) {
            if (shareActivity == null) {
                shareActivity = new ShareActivity(this);
            }
            socialSharePopupWindow = new SocialSharePopupWindow(this, shareActivity, 0);
            socialSharePopupWindow.setShareUrl(Constant.URL_CATEGORY + categoryId);
            socialSharePopupWindow.setShareTitle(categoryTitleString);
            socialSharePopupWindow.setShareDescription(categoryContentString);
            socialSharePopupWindow.setShareImage(new UMImage(this, contentBannerBgUrl));
        }
        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {
        //解决viewpager和swiperefreshlayout的触摸事件冲突
        swipeRefreshLayout.setEnabled(state == ViewPager.SCROLL_STATE_IDLE
                && dragTopLayout.getState() == DragTopLayout.PanelState.EXPANDED);
    }
}
