package com.meidalife.shz.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.SquareHandlerPinEvent;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestService;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.view.IconTextView;
import com.meidalife.shz.widget.ItemDislikePopupWindow;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.usepropeller.routable.Router;
import com.viewpagerindicator.CirclePageIndicator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by taber on 15/6/1.
 */
public class ServicesAdapter extends BaseAdapter {
    private static final String LOG_TAG = "ServicesAdapter";
    private static final int TYPE_COUNT = 2;

    public static final int SCENE_HOME = 1;
    public static final int SCENE_MINE = 2;


    int KEY_TYPE = 1 << 26;
    int KEY_HOLDER = 1 << 27;

    String ITEM_TYPE_NORMAL = "normal";
    String ITEM_TYPE_ERROR = "error";

    int imgWidth;

    LayoutInflater mInflater;
    Context mContext;
    ArrayList<ServiceItem> mData;

    private SocialSharePopupWindow socialSharePopupWindow;
    ViewUsersAdapter viewUsersAdapter;

    private boolean isSquare = false;
    private int geziId = Integer.MAX_VALUE;
    private boolean isGezhu = false;

    private SquareHandlerPinEvent squareHandlerPinEvent;

    private ItemDislikePopupWindow dislikePopupWindow;

    static class ViewHolder {

        @Bind(R.id.imageAvatar)
        SimpleDraweeView userAvatar;
        @Bind(R.id.textNick)
        TextView userName;
        @Bind(R.id.timeLine)
        TextView timeLine;

        @Bind(R.id.textTitle)
        TextView tag;
        @Bind(R.id.textStatus)
        TextView textStatus;
        @Bind(R.id.textDesc)
        TextView content;
        //促销标示
        @Bind(R.id.promotionTag)
        TextView promotionTag;

        @Bind(R.id.textPrice)
        TextView price;
        @Bind(R.id.textViewCount)
        TextView textViewCount;

        @Bind(R.id.btnFavLabel)
        TextView btnFavLabel;

        @Bind(R.id.btnReplyLabel)
        TextView btnReplyLabel;

        @Bind(R.id.iconGender)
        IconTextView iconGender;

        @Bind(R.id.imageList)
        GridView imageList;
        @Bind(R.id.imageSingle)
        SimpleDraweeView imageSingle;

        /*@Bind(R.id.btnReplyCell)
        LinearLayout cellReply;*/
        /*@Bind(R.id.btnShareCell)
        LinearLayout cellShare;*/
        /*@Bind(R.id.gridViewUsers)
        RecyclerView gridViewUsers;*/
        /*@Bind(R.id.cellViewUsers)
        ViewGroup cellViewUsers;*/
        /*@Bind(R.id.buttonSeeAD)
        Button buttonSeeAD;*/
        @Bind(R.id.cellServiceInfo)
        RelativeLayout cellServiceInfo;
        @Bind(R.id.cellServiceUser)
        LinearLayout cellServiceUser;
        @Bind(R.id.imageAD)
        SimpleDraweeView imageAD;
        /*@Bind(R.id.zm_group)
        View zmGroup;*/
        /*@Bind(R.id.zm_value)
        TextView zmValue;*/
        //可用M豆
        /*@Bind(R.id.pointSupport)
        TextView pointSupport;*/
        @Bind(R.id.promotionPrice)
        TextView promotionPrice;
        @Bind(R.id.pointSupport)
        IconTextView pointSupport;
        @Bind(R.id.redPackSupport)
        IconTextView redPackSupport;
        @Bind(R.id.bigPromotionIcon)
        SimpleDraweeView bigPromotionIcon;
        @Bind(R.id.textStatus1)
        TextView textStatus1;
        @Bind(R.id.pinView)
        TextView pinView;
        @Bind(R.id.pinHandlerView)
        TextView pinHandlerView;


        @Bind(R.id.dislikeView)
        View inVisibleView;

        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }


    static class ErrorViewHolder {
        TextView errorTip;
        View locationTip;
        View no_data_icon;

        View rootView;
    }

    public ServicesAdapter(Context context, ArrayList<ServiceItem> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    public void addAll(ArrayList<ServiceItem> items) {
        mData.addAll(items);
    }

    public void setData(ArrayList<ServiceItem> items) {
        mData = items;
    }

    public void setIsSquare(boolean isSquare, boolean isGezhu, int geziId) {
        this.isSquare = isSquare;
        this.geziId = geziId;
        this.isGezhu = isGezhu;
    }

    public void setIsGezhu(boolean isGezhu) {
        this.isGezhu = isGezhu;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public ServiceItem getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ServiceItem item = mData.get(position);

        if (item.getType() > 0) {
            convertView = getErrorItemView(convertView);
            ErrorViewHolder holder = (ErrorViewHolder) convertView.getTag(KEY_HOLDER);

            holder.errorTip.setText(item.getDesc());

            if (item.getType() == 1) {
                holder.locationTip.setVisibility(View.VISIBLE);
            } else {
                holder.locationTip.setVisibility(View.GONE);
            }

            if (item.getType() == 2) {
                holder.no_data_icon.setVisibility(View.VISIBLE);
            } else {
                holder.no_data_icon.setVisibility(View.GONE);
            }

            if (item.isNeedSetLocation()) {
                holder.rootView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (Helper.isLocationEnabled(mContext)) {
                            notifyDataSetChanged();
                        } else {
                            Helper.openLocationSetting(mContext);
                        }
                    }
                });
            } else {
                holder.rootView.setOnClickListener(null);
            }

        } else {

            if (item.getAdList() != null && item.getAdList().size() > 0) {
                AdPicViewer adPicViewer = new AdPicViewer(item.getAdList(), mInflater, mContext);
                convertView = adPicViewer.render();
                convertView.setTag(null);
                return convertView;
            }

            ArrayList<String> images = new ArrayList<>();
            if (item.getImages() != null) {
                images = item.getImages();
            }
            boolean isSingle = (images.size() == 1);

            Activity activity = (Activity) mContext;
            Display display = activity.getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);
            int screenWidth = size.x;

            convertView = genViewHolder(convertView, parent);
            ViewHolder holder = (ViewHolder) convertView.getTag();

            //格子页是否置顶
            if (item.getPin()) {
                holder.pinView.setVisibility(View.VISIBLE);
            } else
                holder.pinView.setVisibility(View.GONE);

            if (isSquare && isGezhu) {
                holder.pinHandlerView.setVisibility(View.VISIBLE);
            } else {
                holder.pinHandlerView.setVisibility(View.GONE);
            }

            if (item.getDislikeLables() != null && item.getDislikeLables().size() > 0) {
                holder.inVisibleView.setVisibility(View.VISIBLE);
            } else {
                holder.inVisibleView.setVisibility(View.GONE);
            }

            //专享价
            if (TextUtils.isEmpty(item.getPromotionPrice())) {
                // holder.promotionTag.setVisibility(View.GONE);
                holder.promotionPrice.setVisibility(View.GONE);
                holder.price.setText(item.getPrice());
            } else {
                // holder.promotionTag.setVisibility(View.VISIBLE);
                holder.promotionPrice.setVisibility(View.VISIBLE);
                holder.promotionPrice.setText(item.getPrice());
                holder.promotionPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);
                holder.price.setText(item.getPromotionPrice());
            }

            //至2.1版本后广告商品情况将不会出现
            // 广告商品隐藏购买入口
            if (item.getLink() != null) {
                //  holder.buttonSeeAD.setVisibility(View.VISIBLE);
                holder.cellServiceInfo.setVisibility(View.GONE);
                holder.cellServiceUser.setVisibility(View.GONE);
                holder.imageAD.setVisibility(View.VISIBLE);
                holder.imageSingle.setVisibility(View.GONE);
                holder.imageList.setVisibility(View.GONE);

                ViewGroup.LayoutParams layoutParams = holder.imageAD.getLayoutParams();
                layoutParams.width = screenWidth;
                layoutParams.height = (int) Math.ceil(screenWidth * 0.5);
                if (images.size() > 0) {
                    Uri adUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(images.get(0), screenWidth));
                    holder.imageAD.setImageURI(adUri);
                } else {
                    holder.imageAD.setImageURI(null);
                }
            } else {
                holder.cellServiceInfo.setVisibility(View.VISIBLE);
                holder.cellServiceUser.setVisibility(View.VISIBLE);
                holder.imageAD.setVisibility(View.GONE);
                holder.imageSingle.setVisibility(View.VISIBLE);
                holder.imageList.setVisibility(View.VISIBLE);
                //  holder.buttonSeeAD.setVisibility(View.GONE);

                //是否支持M豆
            /*if (item.getPointSupport() != null && item.getPointSupport() == 1) {
                holder.pointSupport.setVisibility(View.VISIBLE);
            } else {
                holder.pointSupport.setVisibility(View.GONE);
            }*/
                if (item.getPointSupport() != null && item.getPointSupport() == 1) {
                    holder.pointSupport.setVisibility(View.VISIBLE);
                } else
                    holder.pointSupport.setVisibility(View.GONE);

                //是否支持红包
                if (item.getRedpackSupport()) {
                    holder.redPackSupport.setVisibility(View.VISIBLE);
                } else
                    holder.redPackSupport.setVisibility(View.GONE);

                //特惠活动标识
                if (!TextUtils.isEmpty(item.getBigPromotionIcon())) {
                    holder.bigPromotionIcon.setVisibility(View.VISIBLE);
                    holder.bigPromotionIcon.setImageURI(Uri.parse(item.getBigPromotionIcon()));
                } else
                    holder.bigPromotionIcon.setVisibility(View.GONE);

                // 设置标题
                holder.tag.setText(mContext.getResources().getString(R.string.label_i_can) + item.getTag());
                // 审核未通过并登录用户是自己的时候时间字段显示 审核未通过
                if (item.getStatus() == 2) {
                    holder.textStatus.setText("审核未通过");
                    holder.textStatus1.setVisibility(View.GONE);
                } else {
                    if (item.getDistance() != null) {
                        holder.textStatus1.setVisibility(View.VISIBLE);
                        holder.textStatus1.setText(item.getDistance());
                    } else
                        holder.textStatus1.setVisibility(View.GONE);
                    String typeLabel = typeToLabel(item.getServiceType(), item.getCityName());
                    if (typeLabel == null) {
                        holder.textStatus.setVisibility(View.GONE);
                    } else {
                        holder.textStatus.setVisibility(View.VISIBLE);
                        holder.textStatus.setText(typeLabel);
                    }
                }


                holder.userName.setText(item.getUserName());

                holder.timeLine.setText(item.getUserOnlineInfo());

                holder.content.setText(item.getContent());
                String gender = "";
                // 设置服务者性别
                if (item.getUserGender() != null) {
                    holder.iconGender.setVisibility(View.VISIBLE);
                    if (item.getUserGender().equals("woman") || item.getUserGender().equals("F")) {
                        holder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_f));
                        holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_b));
                    } else {
                        holder.iconGender.setText(mContext.getResources().getString(R.string.icon_gender_m));
                        holder.iconGender.setTextColor(mContext.getResources().getColor(R.color.brand_i));
                    }
                } else {
                    holder.iconGender.setVisibility(View.GONE);
                }

                // 加载发布者头像
                ViewGroup.LayoutParams avatarParams = holder.userAvatar.getLayoutParams();
                if (TextUtils.isEmpty(item.getUserAvatar())) {
                    Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(mContext, String.valueOf(item.getUserId()), gender);
                    holder.userAvatar.setImageURI(getDefaultAvatarUri);
                } else {
                    Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getUserAvatar(), avatarParams.width));
                    holder.userAvatar.setImageURI(uri);
                }

                if (isSingle) {
                    ViewGroup.LayoutParams layoutParmas = holder.imageSingle.getLayoutParams();
                    if (images.size() > 0) {
                        Uri itemUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(images.get(0), layoutParmas.width));
                        holder.imageSingle.setImageURI(itemUri);
                    } else {
                        holder.imageSingle.setImageURI(null);
                    }
                    holder.imageList.setVisibility(View.GONE);
                    holder.imageSingle.setVisibility(View.VISIBLE);
                } else {
                    ArrayList<String> showImgList = new ArrayList<>();
                    if (images.size() > 0) {
                        int endIndex = Math.min(ServiceImagesAdapter.MAX_IMG, images.size());
                        for (int i = 0; i < endIndex; i++) {
                            showImgList.add(images.get(i));
                        }
                    }
                    holder.imageList.setAdapter(new ServiceImagesAdapter(mContext, showImgList, imgWidth, images.size()));

                    holder.imageSingle.setVisibility(View.GONE);
                    holder.imageList.setVisibility(View.VISIBLE);
                }
            }

            // 操作栏
        /*if (item.getIsLike() == 1) {
            holder.btnFavIcon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            holder.btnFavIcon.setText(mContext.getResources().getString(R.string.icon_star_active));
        } else {
            holder.btnFavIcon.setTextColor(mContext.getResources().getColor(R.color.brand_e));
            holder.btnFavIcon.setText(mContext.getResources().getString(R.string.icon_star_normal));
        }*/
            if (item.getLikeCount() > 0) {
                holder.btnFavLabel.setVisibility(View.VISIBLE);
                holder.btnFavLabel.setText(String.valueOf(item.getLikeCount()));
            } else {
                holder.btnFavLabel.setVisibility(View.GONE);
            }
            if (item.getCommentCount() > 0) {
                holder.btnReplyLabel.setText(String.valueOf(item.getCommentCount()));
            } else {
                holder.btnReplyLabel.setText("0");
            }
        /*if (item.isEditable()) {
            holder.buttonChat.setVisibility(View.GONE);
        } else {
            holder.buttonChat.setVisibility(View.VISIBLE);
        }
*/
            // 看过用户
            holder.textViewCount.setText(item.getViewCount() + "");
        /*if (item.getViewUsers() == null || item.getViewUsers().size() == 0) {
            holder.cellViewUsers.setVisibility(View.GONE);
        } else {
            holder.cellViewUsers.setVisibility(View.VISIBLE);
            viewUsersAdapter = new ViewUsersAdapter(mContext, item.getViewUsers());
            holder.gridViewUsers.setAdapter(viewUsersAdapter);

            //设置布局管理器
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
            linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
            holder.gridViewUsers.setLayoutManager(linearLayoutManager);
        }*/

            // 芝麻信用分
        /*if (item.getZmLevel() == null) {
            holder.zmGroup.setVisibility(View.GONE);
        } else {
            holder.zmGroup.setVisibility(View.VISIBLE);
            holder.zmValue.setText("芝麻信用:" + item.getZmLevel());
        }
*/
            initListener(convertView, position, item.getItemId(), holder);
        }


        return convertView;
    }

    private View getErrorItemView(View convertView) {
        if (convertView != null && convertView.getTag() != null && convertView.getTag(KEY_TYPE) != null) {
            String type = (String) convertView.getTag(KEY_TYPE);
            if (ITEM_TYPE_ERROR.equals(type)) {
                return convertView;
            }
        }

        convertView = mInflater.inflate(R.layout.location_error_view, null);
        convertView.setTag(KEY_TYPE, ITEM_TYPE_ERROR);

        ErrorViewHolder holder = new ErrorViewHolder();
        holder.rootView = convertView.findViewById(R.id.root_view);
        holder.errorTip = (TextView) convertView.findViewById(R.id.nearbyHintLabel);
        holder.locationTip = convertView.findViewById(R.id.locationTip);
        holder.no_data_icon = convertView.findViewById(R.id.no_data_icon);

        convertView.setTag(KEY_HOLDER, holder);
        return convertView;
    }

    private void initListener(View convertView, final int positionIndex, final String itemId, ViewHolder holder) {

        holder.pinHandlerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (squareHandlerPinEvent != null && isSquare)
                    squareHandlerPinEvent.handlerPin(v, positionIndex);
            }
        });


        holder.inVisibleView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ServiceItem item = mData.get(positionIndex);
                handlerInvisible(v, item.getDislikeLables(), item.getItemId(), positionIndex);
            }
        });

        /*holder.buttonChat.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // 使用 initIm 接口调用 方式
                ServiceItem item = mData.get(positionIndex);
                String action = "chatFormService/";
                action += item.getUserId();
                action += "/";
                action += itemId;

                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open(action);
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString("action", action);
                    Router.sharedRouter().open("signin", bundle);
                }

                LogParam param = new LogParam();
                param.setType(LogUtil.TYPE_CUSTOMIZE);
                param.setEid(LogUtil.EVENT_ID_CHAT_CLICK);
                param.setPvid(mData.get(positionIndex).getPvid());
                LogUtil.log(param);
            }
        });*/

        /*holder.cellFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    ServiceItem item = mData.get(positionIndex);
                    toggleIsLike(item, v);
                    xhrFav(itemId, item.getIsLike() == 1);
                } else {
                    Router.sharedRouter().open("signin");
                }

            }
        });*/

        /*holder.cellReply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    Router.sharedRouter().open("commentList/" + itemId);
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString("action", "commentList/" + itemId);
                    Router.sharedRouter().open("signin", bundle);
                }

            }
        });*/

        /*holder.cellShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOrHideShareList(v, mData.get(positionIndex));
                LogParam param = new LogParam();
                param.setType(LogUtil.TYPE_CUSTOMIZE);
                param.setEid(LogUtil.EVENT_ID_SHARE_CLICK);
                param.setPvid(mData.get(positionIndex).getPvid());
                LogUtil.log(param);
            }
        });*/

        View.OnClickListener itemClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ServiceItem item = mData.get(positionIndex);
                if (item.getLink() != null) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", item.getLink());
                    Router.sharedRouter().open("web", bundle);
                } else {
                    Router.sharedRouter().open("services/" + itemId);
                    LogParam param = new LogParam();
                    param.setType(LogUtil.TYPE_CUSTOMIZE);
                    param.setEid(LogUtil.EVENT_ID_SERVICE_ITEM_CLICK);
                    if (!TextUtils.isEmpty(itemId)) {
                        param.setItemid(itemId);
                    }
                    if (geziId > 0) {
                        param.setGeziid("" + geziId);
                    }
                    param.setPvid(mData.get(positionIndex).getPvid());
                    LogUtil.log(param);
                }
            }
        };

        convertView.setOnClickListener(itemClickListener);
        //  holder.buttonSeeAD.setOnClickListener(itemClickListener);

//        holder.imageSingle.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                ServiceItem item = mData.get(positionIndex);
//                Bundle bundle = new Bundle();
//                bundle.putStringArrayList("photos", item.getImages());
//                bundle.putInt("index", 0);
//                Router.sharedRouter().open("imageBrowser", bundle);
//            }
//        });

        holder.imageList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Router.sharedRouter().open("services/" + itemId);
                try {
                    LogParam param = new LogParam();
                    param.setType(LogUtil.TYPE_CUSTOMIZE);
                    param.setEid(LogUtil.EVENT_ID_SERVICE_ITEM_CLICK);
                    if (!TextUtils.isEmpty(itemId)) {
                        param.setItemid(itemId);
                    }
                    if (geziId > 0) {
                        param.setGeziid("" + geziId);
                    }
                    param.setPvid(mData.get(position).getPvid());
                    LogUtil.log(param);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        holder.userAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ServiceItem item = mData.get(positionIndex);
                Router.sharedRouter().open("profile/" + item.getUserId());
            }
        });

        if (viewUsersAdapter != null) {
            viewUsersAdapter.setOnItemClickListener(new ViewUsersAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(View view, int p, long id) {
                    ServiceItem item = mData.get(positionIndex);
                    ServiceItem.ViewUser user = item.getViewUsers().get(p);
                    Router.sharedRouter().open("profile/" + user.getUserId());
                }
            });
        }

        /*holder.zmGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://xy.alipay.com/auth/whatszhima.htm?view=mobile";
                Bundle bundle = new Bundle();
                bundle.putString("url", url);
                Router.sharedRouter().open("web", bundle);
            }
        });*/
    }

    public void handlerInvisible(View v, List<String> strList, String itemId, int position) {
        if (dislikePopupWindow == null) {
            dislikePopupWindow = new ItemDislikePopupWindow((Activity) mContext, strList, itemId, position);
        } else {
            dislikePopupWindow.setData(strList, itemId, position);
        }

        if (dislikePopupWindow.isShowing()) {
            dislikePopupWindow.dismiss();
        } else {
            dislikePopupWindow.showAtLocation(v, Gravity.CENTER_VERTICAL, 0, 0);
        }

    }

    private void showOrHideShareList(View v, ServiceItem serviceItem) {
        ShareActivity shareActivity = new ShareActivity((Activity) mContext);
        if (socialSharePopupWindow == null) {
            socialSharePopupWindow = new SocialSharePopupWindow((Activity) mContext, serviceItem,
                    shareActivity, SocialSharePopupWindow.SHARE_TYPE_SERVICE);
        }
        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    private void toggleIsLike(ServiceItem item, View v) {
        TextView icon = (TextView) v.findViewById(R.id.btnFavIcon);
        TextView label = (TextView) v.findViewById(R.id.btnFavLabel);

        if (item.getIsLike() == 0) {
            item.setIsLike(1);
            item.setLikeCount(item.getLikeCount() + 1);
            icon.setTextColor(mContext.getResources().getColor(R.color.brand_b));
            icon.setText(mContext.getResources().getString(R.string.icon_star_active));
        } else {
            item.setIsLike(0);
            item.setLikeCount(item.getLikeCount() - 1);
            icon.setTextColor(mContext.getResources().getColor(R.color.tab_item_normal));
            icon.setText(mContext.getResources().getString(R.string.icon_star_normal));
        }
        if (item.getLikeCount() > 0) {
            label.setVisibility(View.VISIBLE);
            label.setText(String.valueOf(item.getLikeCount()));
        } else {
            label.setVisibility(View.GONE);
        }
    }

    private void xhrFav(String itemId, Boolean isLike) {
        try {
            JSONObject params = new JSONObject();
            params.put("itemId", itemId);
            if (isLike) {
                RequestService.addAttention(params, new MeidaRestClient.RestCallback() {
                    @Override
                    public void onSuccess(Object result) {
                    }

                    @Override
                    public void onFailure(HttpError error) {
                    }
                });
            } else {
                RequestService.delAttention(params, new MeidaRestClient.RestCallback() {
                    @Override
                    public void onSuccess(Object result) {
                    }

                    @Override
                    public void onFailure(HttpError error) {
                    }
                });
            }
        } catch (JSONException e) {
        }
    }


//    private void initComments(ServiceItem item, ViewHolder holder) {
//        if (item.getCommentCount() > 0 && item.getComments() != null) {
//            List<HashMap<String, String>> comments = item.getComments();
//            String format = mContext.getResources().getString(R.string.label_view_reviews);
//            holder.textCommentLabel.setVisibility(View.VISIBLE);
//            holder.commentsList.setVisibility(View.VISIBLE);
//            holder.textCommentLabel.setText(String.format(format, "" + item.getCommentCount()));
//            String[] form = {"userName", "content"};
//            int[] to = {R.id.commentUserName, R.id.commentContent};
//            SimpleAdapter commentsAdapter = new SimpleAdapter(mContext, comments, R.layout.single_comment_item, form, to);
//            holder.commentsList.setAdapter(commentsAdapter);
//        } else {
//            holder.commentsList.setVisibility(View.GONE);
//            holder.textCommentLabel.setVisibility(View.GONE);
//        }
//    }

    private View genViewHolder(View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_service, parent, false);
            holder = new ViewHolder(convertView);

            // 计算多图每栏宽度
            Activity activity = (Activity) mContext;
            Display display = activity.getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);
            int width = size.x;
            float margin = Helper.convertDpToPixel(77, mContext);
            float spacing = Helper.convertDpToPixel(10, mContext);
            float padding = Helper.convertDpToPixel(8, mContext);
            // width -= margin * 2;
            width -= margin;
            width -= spacing * 2;
            width -= padding * 2;
            imgWidth = width / 3;
            holder.imageList.setColumnWidth(imgWidth);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            if (holder == null) {
                return genViewHolder(null, parent);
            }
        }

        return convertView;
    }


    /**
     * Interface definition for a callback to be invoked when a view is clicked.
     */
    public interface OnClickListener {
        /**
         * Called when a view has been clicked.
         *
         * @param v        The view that was clicked.
         * @param position The item position.
         */
        void onClick(View v, int position, String itemId);
    }


    public class AdPicViewer {

        private LayoutInflater inflater;
        private Context context;

        private ViewPager viewPager;
        private ImageView[] imgViews;   //图片imgView
        private JSONArray adList;       //图片资源

        public AdPicViewer(JSONArray adList, LayoutInflater inflater, Context context) {
            this.adList = adList;
            this.inflater = inflater;
            this.context = context;
        }

        public View render() {

            View adRoot = inflater.inflate(R.layout.item_service_ad, null);
            int imgHeight = (int) Helper.convertDpToPixel(120, context);
            viewPager = (ViewPager) adRoot.findViewById(R.id.item_ad_pics_viewpager);

            //加载图片
            imgViews = new ImageView[adList.size()];
            for (int i = 0; i < imgViews.length; i++) {
                SimpleDraweeView imageView = new SimpleDraweeView(context);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setTag(i);
                ViewPager.LayoutParams params = new ViewPager.LayoutParams();
                imageView.setLayoutParams(params);
                imgViews[i] = imageView;
                final com.alibaba.fastjson.JSONObject adObj = adList.getJSONObject(i);
                String imgUrl = adObj.getString("pic");
                String imgCdn = ImgUtil.getCDNUrlWithHeight(imgUrl, imgHeight);

                imageView.setImageURI(Uri.parse(imgCdn));
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", adObj.getString("url"));
                        Router.sharedRouter().open("web", bundle);
                    }
                });
            }

            //设置Adapter
            viewPager.setAdapter(new PagerAdapter() {
                @Override
                public int getCount() {
                    return adList.size();
                }

                @Override
                public boolean isViewFromObject(View view, Object object) {
                    return view == object;
                }

                @Override
                public Object instantiateItem(View v, int position) {
                    ImageView iv = imgViews[position % imgViews.length];
                    ViewPager vp = (ViewPager) v;
                    if (iv.getParent() == null) {
                        vp.addView(iv, 0);  //http://vocaloid.iteye.com/blog/1814627, The specified child already has a parent. You must call removeView() on the child's parent first.
                    }
                    return iv;
                }

                @Override
                public void destroyItem(View container, int position, Object object) {
                    //((ViewPager)container).removeView(imgViews[position % imgViews.length]);  //测试时发现，若移除，当只有3张图片时会出现空白页
                }
            });

            CirclePageIndicator indicator = (CirclePageIndicator) adRoot.findViewById(R.id.item_ad_pics_tip);
            indicator.setViewPager(viewPager);
            viewPager.setCurrentItem(0);

            return adRoot;
        }
    }

    public static String typeToLabel(int serviceType, String cityName) {
        String label = null;
        switch (serviceType) {
            case 1:
                label = (cityName == null ? "" : cityName) + "上门";
                break;
            case 2:
                label = (cityName == null ? "" : cityName) + "到店";
                break;
            case 3:
                label = "线上";
                break;
            case 4:
                label = "邮寄";
                break;
            default:
                label = null;
        }
        return label;
    }

    public void setSquareHandlerPinEvent(SquareHandlerPinEvent squareHandlerPinEvent) {
        this.squareHandlerPinEvent = squareHandlerPinEvent;
    }

//    public void setInvisibleRecommendListener(InvisibleRecommendListener invisibleRecommendListener) {
//        this.invisibleRecommendListener = invisibleRecommendListener;
//    }
}
