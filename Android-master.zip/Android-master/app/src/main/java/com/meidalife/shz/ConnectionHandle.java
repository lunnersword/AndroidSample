package com.meidalife.shz;

import android.content.Context;
import android.os.Handler;

import com.alibaba.wukong.ConnectionListener;
import com.meidalife.shz.event.EventSender;
import com.meidalife.shz.event.type.NetworkConnectTypeEnum;

/**
 * Created by shijian on 15/9/5.
 */
public class ConnectionHandle implements ConnectionListener {

    Context mContext;
    Handler handler;

    ConnectionHandle(Context context) {
        this.mContext = context;
        handler = new Handler(mContext.getMainLooper());
    }

    @Override
    public void onConnected() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                EventSender.notifyNetworkChanged(NetworkConnectTypeEnum.TYPE_CONNECTED);

            }
        });
    }

    @Override
    public void onDisconnected(String s) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                EventSender.notifyNetworkChanged(NetworkConnectTypeEnum.TYPE_DISCONNECTED);

            }
        });
    }
}
