package com.meidalife.shz;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.activity.BaseActivity;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;
import com.usepropeller.routable.Router;

import org.json.JSONException;

public class MessageSettingActivity extends BaseActivity {

    String disturb;
    Switch nightSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_setting);
        initActionBar(R.string.title_activity_message_setting, true);

        TextView welcomeWordsArrow = (TextView) findViewById(R.id.WelcomeWordsArrow);
        welcomeWordsArrow.setTypeface(Helper.sharedHelper().getIconFont());
        TextView BlacklistArrow = (TextView) findViewById(R.id.BlacklistArrow);
        BlacklistArrow.setTypeface(Helper.sharedHelper().getIconFont());
        nightSwitch = (Switch) findViewById(R.id.night_switch);
        xhrProfile();

        if (!Helper.sharedHelper().hasToken()) {
            nightSwitch.setEnabled(false);
            nightSwitch.setChecked(false);
        }

        nightSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked) {
                JSONObject params = new JSONObject();
                params.put("disturb", isChecked ? 1 : 0);
                nightSwitch.setEnabled(false);
                HttpClient.get("1.0/user/updateDisturb", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        nightSwitch.setEnabled(true);
                    }

                    @Override
                    public void onFail(HttpError error) {
                        //buttonView.setChecked(!isChecked);
                        nightSwitch.setEnabled(true);
                        MessageUtils.showToastCenter(error.toString());
                    }
                });
            }
        });

    }

    public void handleWelcomeWords(View view) {

        Router.sharedRouter().open("welcomeWordsSetting");

    }

    public void handleBlacklist(View view) {

        Router.sharedRouter().open("blackList");

    }

    private void xhrProfile() {
        RequestSign.getProfile(new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                org.json.JSONObject json = (org.json.JSONObject) result;
                try {
                    Log.d("myprofile", json.toString());
                    org.json.JSONObject data = json.getJSONObject("data");
                    if (data.has("disturb")) {
                        disturb = data.getString("disturb");
                    }

                } catch (JSONException e) {
                    MessageUtils.showToastCenter(getString(R.string.error_server_500));
                }

                Log.d("mydisturb: ", disturb);
                nightSwitch.setChecked("1".equals(disturb) ? true : false);
            }

            @Override
            public void onFailure(HttpError error) {

            }
        });
    }

}
