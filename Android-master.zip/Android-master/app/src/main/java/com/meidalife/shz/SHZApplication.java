package com.meidalife.shz;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.multidex.MultiDexApplication;
import android.support.v4.app.NotificationCompat;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.wukong.ConnectionListener;
import com.alibaba.wukong.WKManager;
import com.alibaba.wukong.auth.AuthService;
import com.alibaba.wukong.im.Conversation;
import com.alibaba.wukong.im.ConversationChangeListener;
import com.alibaba.wukong.im.ConversationListener;
import com.alibaba.wukong.im.ConversationService;
import com.alibaba.wukong.im.IMEngine;
import com.alibaba.wukong.im.Message;
import com.alibaba.wukong.im.MessageContent;
import com.bugtags.library.Bugtags;
import com.facebook.drawee.backends.pipeline.Fresco;

import com.meidalife.shz.activity.*;

import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.bean.TabIndexEnum;
import com.meidalife.shz.db.DatabaseManager;
import com.meidalife.shz.db.ImNotifyMsg;
import com.meidalife.shz.db.ImNotifyMsgDao;
import com.meidalife.shz.dexposed.query.HotPatchManager;
import com.meidalife.shz.dexposed.query.IPatchInfoRequest;
import com.meidalife.shz.event.ConversationEvent;
import com.meidalife.shz.event.EventSender;
import com.meidalife.shz.event.SHZEventBus;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.event.type.NetworkConnectTypeEnum;
import com.meidalife.shz.im.ChatHelper;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.SyncHttpClient;
import com.meidalife.shz.rest.model.PayResult;
import com.meidalife.shz.service.ShzCoreService;
import com.meidalife.shz.task.TaskExecutor;
import com.meidalife.shz.util.SdcardUtil;
import com.meidalife.shz.util.StrUtil;
import com.umeng.analytics.MobclickAgent;
import com.umeng.message.PushAgent;
import com.umeng.message.UmengMessageHandler;
import com.umeng.message.UmengNotificationClickHandler;
import com.umeng.message.UmengRegistrar;
import com.umeng.message.entity.UMessage;
import com.umeng.socialize.PlatformConfig;
import com.usepropeller.routable.Router;
import com.yixia.camera.VCamera;
import com.yixia.camera.util.DeviceUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import cn.fraudmetrix.android.FMAgent;
import de.greenrobot.event.EventBus;

/**
 * Created by taber on 15/6/2.
 */
public class SHZApplication extends MultiDexApplication {
    private static final String LOG_TAG = "SHZApplication";
    private static SHZApplication context;
    private static String versionName = "";
    private String currentChatUserId = "";

    public static String uuid = "";
    public static String imei = "";
    public static String chanel = "";
    public static String device = "";
    public static SHZEventBus eventBus;
    private int notificationId = 0x100;
    private AMapLocationManager mLocationManager;
    private String bbId = "";

    public static volatile boolean hasLocated = false;

    @Override
    public void onCreate() {
        super.onCreate();

        context = this;

        Router.sharedRouter().setContext(getApplicationContext());
        Router.sharedRouter().map("main", MainActivity.class);
        Router.sharedRouter().map("home", MainActivity.class);  // for push
        Router.sharedRouter().map("main/:index", MainActivity.class);
        Router.sharedRouter().map("publish", ServicePublishActivity.class);
        Router.sharedRouter().map("publish/:id", ServicePublishActivity.class);
        Router.sharedRouter().map("services/:id", ServiceDetailActivity.class);
        Router.sharedRouter().map("detail/:id", ServiceDetailActivity.class); // for push

        Router.sharedRouter().map("publishOpus", OpusPublishActivity.class);
        Router.sharedRouter().map("publishgallery", OpusPublishActivity.class); // for push

        Router.sharedRouter().map("order/:id", OrderActivity.class);
        Router.sharedRouter().map("order/:id/:geziId", OrderActivity.class);
        Router.sharedRouter().map("buy/:id", OrderActivity.class);

        Router.sharedRouter().map("buyOrders/:type", OrderListActivity.class);
        Router.sharedRouter().map("saleOrders/:type", OrderListActivity.class);
        Router.sharedRouter().map("orderlist/:type", OrderListActivity.class);  // for push

        Router.sharedRouter().map("orderDetailAction", OrderDetailActivity.class);
        Router.sharedRouter().map("orders/:orderId", OrderDetailActivity.class);
        Router.sharedRouter().map("orderdetail/:orderId", OrderDetailActivity.class);   // for push
        Router.sharedRouter().map("ordersByTradeNo/:tradeId", OrderDetailActivity.class);
        Router.sharedRouter().map("orderCancel/:orderNo/:type", OrderCancelActivity.class);
        Router.sharedRouter().map("orderAdd/:orderNo", OrderAddActivity.class);
        Router.sharedRouter().map("orderJudge/:type/:itemId/:orderNo", OrderJudgeActivity.class);
        Router.sharedRouter().map("orderReply/:type/:commentId/:orderNo", OrderJudgeActivity.class);
        Router.sharedRouter().map("pay", PayActivity.class);

        Router.sharedRouter().map("setting/:disturb", SettingActivity.class);
        Router.sharedRouter().map("setting", SettingActivity.class);
        Router.sharedRouter().map("profile/:userId", ProfileActivity.class);
        Router.sharedRouter().map("user/:userId", ProfileActivity.class);   // for push
        Router.sharedRouter().map("addressManage", AddressManageActivity.class);
        Router.sharedRouter().map("workCellphone", WorkCellphoneActivity.class);


        Router.sharedRouter().map("serviceListLike", FavoriteActivity.class);
        Router.sharedRouter().map("favorites", FavoriteActivity.class);

        Router.sharedRouter().map("serviceListPublish", ServiceListPublishActivity.class);
        Router.sharedRouter().map("itemlist", ServiceListPublishActivity.class);

        Router.sharedRouter().map("aboutme", AboutMeActivity.class);
        Router.sharedRouter().map("chooseGender", ChooseGender.class);
        Router.sharedRouter().map("timemanage", TimeManageActivity.class);
        Router.sharedRouter().map("changeNickname", ChangeNicknameActivity.class);
        Router.sharedRouter().map("personalIntroduce", ChangePersonalIntroduce.class);
        Router.sharedRouter().map("messageSetting", MessageSettingActivity.class);
        Router.sharedRouter().map("welcomeWordsSetting", WelcomeWordsSetting.class);

        Router.sharedRouter().map("login", SignInActivity.class);
        Router.sharedRouter().map("signin", SignInActivity.class);
        Router.sharedRouter().map("signup", SignUpActivity.class);
        Router.sharedRouter().map("signupLable", SignUpSelectLabelActivity.class);

        Router.sharedRouter().map("pick/city", PickCityActivity.class);
        Router.sharedRouter().map("citylist", PickCityActivity.class);  // for push
        Router.sharedRouter().map("pick/photo", PickPhotoActivity.class);
        Router.sharedRouter().map("pick/service", PickServiceActivity.class);
        Router.sharedRouter().map("chatFormService/:receiverId/:itemId", ChatActivity.class);
        Router.sharedRouter().map("chat/:receiverId/itemId/:itemId", ChatActivity.class);   // for push
        Router.sharedRouter().map("chat/:receiverId", ChatActivity.class);  // and for push
        Router.sharedRouter().map("chat/:receiverId/orderNo/:orderNo", ChatActivity.class);
        Router.sharedRouter().map("notification/:subType", NotificationActivity.class);

        Router.sharedRouter().map("addresses", AddressesActivity.class);
        Router.sharedRouter().map("address", AddressesActivity.class);  // for push
        Router.sharedRouter().map("addresses/create", AddressCreateActivity.class);
        Router.sharedRouter().map("address/change", AddressChangeActivity.class);

        Router.sharedRouter().map("web", WebActivity.class);
        Router.sharedRouter().map("go/:url", WebActivity.class);
        Router.sharedRouter().map("imageBrowser", ImageBrowserActivity.class);

        Router.sharedRouter().map("commentList/:itemId", CommentListActivity.class);
        Router.sharedRouter().map("comments/:id", ServiceDetailActivity.class); // and for push

        Router.sharedRouter().map("orderCommentByOrderId/:orderNum", OrderCommentActivity.class);
        Router.sharedRouter().map("orderCommentByItemId/:itemId", OrderCommentActivity.class);

        Router.sharedRouter().map("profile_money/:sum", MoneyWholeActivity.class);
        Router.sharedRouter().map("profile_coin/:sum", CoinWholeActivity.class);
        Router.sharedRouter().map("money_coin_detail/:type", MoneyCoinDetailActivity.class);
        Router.sharedRouter().map("bill/:type", MoneyCoinDetailActivity.class); // for push
        Router.sharedRouter().map("bill", MoneyCoinDetailActivity.class);       // for push

        Router.sharedRouter().map("earn_mcoin", EarnMcoinActivity.class);
        Router.sharedRouter().map("earn_mcoin_contacts_intro", CoinContactsIntroActivity.class);
        Router.sharedRouter().map("mcoinaddressbook", CoinContactsIntroActivity.class); // for push
        Router.sharedRouter().map("earn_mcoin_contacts", CoinContactsActivity.class);
        Router.sharedRouter().map("mcoininvite/:code", PassphraseInputActivity.class);
        Router.sharedRouter().map("passphrase_input", PassphraseInputActivity.class);
        Router.sharedRouter().map("explore", PassphraseInputActivity.class); // for scheme
        Router.sharedRouter().map("passphrase_res", PassphraseResActivity.class);
        Router.sharedRouter().map("share_invite", ShareInviteActivity.class);

        Router.sharedRouter().map("money_withdraw", MoneyWithdrawActivity.class);
        Router.sharedRouter().map("withdraw_account/:accountId", WithdrawAccountActivity.class);
        Router.sharedRouter().map("withdraw_log", WithdrawLogActivity.class);
        Router.sharedRouter().map("withdrawlist", WithdrawLogActivity.class);   // for push

        Router.sharedRouter().map("like_list/:itemId", LikeListActivity.class);
        Router.sharedRouter().map("mcoin/:pointId/count/:count", AwardsAnimationActivity.class);

        Router.sharedRouter().map("service_snapshot/:itemId/:snapshotId", ServiceSnapshotActivity.class);

        Router.sharedRouter().map("search_res", SearchResActivity.class);
        Router.sharedRouter().map("search", SearchResActivity.class);   // for push, search/:keyword wait to handle ...
        Router.sharedRouter().map("bindzm", ZmAuthActivity.class);

        Router.sharedRouter().map("opusList/:itemId", OpusListActivity.class);
        Router.sharedRouter().map("opusShowDetail/:opusId", OpusShowDetailActivity.class);

        Router.sharedRouter().map("publishServiceFinish", ServicePublishCompleteActivity.class);
        Router.sharedRouter().map("serviceNotPutOnSale", ServiceNotPutOnSaleActivity.class);

        Router.sharedRouter().map("orderDelivery/:orderNo", OrderDeliverActivity.class);
        Router.sharedRouter().map("pickKuaidi", PickKuaidiActivity.class);
        Router.sharedRouter().map("orderRefund/:type/:orderNo", OrderRefundActivity.class);

        Router.sharedRouter().map("orderRefundDetail/:orderNo", OrderRefundDetailActivity.class);
        Router.sharedRouter().map("refunddetail/:orderNo", OrderRefundDetailActivity.class);

        Router.sharedRouter().map("orderRefundRefuse/:orderNo/:id", OrderRefundRefuseActivity.class);
        Router.sharedRouter().map("orderPayDetail/:orderNo", OrderPayDetailActivity.class);

        Router.sharedRouter().map("scan", BarcodeScannerActivity.class);    // for push
        Router.sharedRouter().map("orderSearch/:type", OrderSearchResultActivity.class);    // for search

        Router.sharedRouter().map("serviceListShow/:userId", ServiceListShowActivity.class);
        Router.sharedRouter().map("tradeAndCommentList", TradeAndCommentListActivity.class);
        Router.sharedRouter().map("qrCodeCreate", QRCodeCreateActivity.class);

        Router.sharedRouter().map("redPaperList4Order", RedPaperListForOrderActivity.class);

        Router.sharedRouter().map("redpaper", RedPaperListActivity.class);
        Router.sharedRouter().map("redpaper/:type", RedPaperListActivity.class);

        Router.sharedRouter().map("cropImage", CropImageActivity.class);

        Router.sharedRouter().map("certificationlist", CertificationListActivity.class);

        Router.sharedRouter().map("certify", CertificationDetailActivity.class);

        Router.sharedRouter().map("certification/:id", CertificationDetailActivity.class);

        Router.sharedRouter().map("certification/:id/tid/:tid", CertificationDetailActivity.class);


        Router.sharedRouter().map("orderUpdatePrice/:orderNo", UpdateOrderPriceActivity.class);
        Router.sharedRouter().map("location", PickAddressActivity.class);
        Router.sharedRouter().map("location/:searchType", PickAddressActivity.class);

        Router.sharedRouter().map("cate/:catId", CategoryActivity.class);

        Router.sharedRouter().map("profileLabel", ProfileLabelActivity.class);

        Router.sharedRouter().map("video", VCMediaRecorderActivity.class);

        Router.sharedRouter().map("rewards", RewardDialogActivity.class);

        Router.sharedRouter().map("blackList", BlackListActivity.class);

        Router.sharedRouter().map("uploadVideo", UploadVideoActivity.class);
        Router.sharedRouter().map("playVideo/:videoUrl", PlayVideoActivity.class);
        Router.sharedRouter().map("squareaskdetail/:demandId", SquareAskDetailActivity.class);
        Router.sharedRouter().map("squareAskChooseCategory", SquareAskChooseCategoryActivity.class);
        Router.sharedRouter().map("squareAskPublish/:geziId", SquareAskPublishActivity.class);
        Router.sharedRouter().map("squareaskreply/:askid", SquareAskReplyActivity.class);

        Router.sharedRouter().map("squareNearByPublish/:geziId", SquareNearByPublishActivity.class);
        Router.sharedRouter().map("squareNearByPublish/update/:geziId/:id", SquareNearByPublishActivity.class);
        Router.sharedRouter().map("nearbyCat", NearbyCategoryActivity.class);
        Router.sharedRouter().map("squarebbsdetail/:topicid", SquareBbsDetailActivity.class);
        Router.sharedRouter().map("squareBbsPublish/:geziId", SquareBbsPublishActivity.class);
        Router.sharedRouter().map("squareservicelist/:categoryId/geziid/:geziId", CategorySquareServiceActivity.class);

        Router.sharedRouter().map("serviceJoinSquare", ServiceJoinSquareActivity.class);
        Router.sharedRouter().map("squareUserList", SquareUserListActivity.class);
        Router.sharedRouter().map("squareQRCode", SquareQRCodeActivity.class);

        Router.sharedRouter().map("surroundSquare", SurroundSquareListActivity.class);
        Router.sharedRouter().map("ssswithmap", SurroundSquareListWithMapActivity.class);
        Router.sharedRouter().map("searchaddresssquare", SearchAddressActivity.class);

        Router.sharedRouter().map("squareindex/:id", SquareHomeActivity.class);
        Router.sharedRouter().map("squareindex/:id/tab/:tab", SquareHomeActivity.class);
        Router.sharedRouter().map("mysquares", MDMySquareActivity.class);
        Router.sharedRouter().map("squaremanage/index/:geziId", MDSquareManageCenterActivity.class);
        Router.sharedRouter().map("squaremanage/notice/:geziId", MDSquareManagePublishActivity.class);
        Router.sharedRouter().map("squaremanage/members/:geziId", MDSquareManageSearchActivity.class);
        Router.sharedRouter().map("squaremanage/service/:geziId", MDSquareManageCategoryOrderActivity.class);
        Router.sharedRouter().map("squaremanage/phone/:geziId", MDSquareManageTelephoneActivity.class);
        Router.sharedRouter().map("squaremanage/phone/update/:geziId", MDSquareManagePhoneUpdateActivity.class);
        Router.sharedRouter().map("squaremanage/asklist/:geziId", MDSquareManageAskListActivity.class);

        Router.sharedRouter().map("squareAskChooseService", SquareAskChooseServiceActivity.class);

        Router.sharedRouter().map("createSquare", ApplySquareActivity.class);
        Router.sharedRouter().map("selectSquareAddress", SelectSquareAddressActivity.class);
        Router.sharedRouter().map("citylistforsquare", PickCityForSquareActivity.class);

        Router.sharedRouter().map("viewPosition", ViewLocationActivity.class);

        Router.sharedRouter().map("mylottery/:type", MDMyLotteryActivity.class);

        Router.sharedRouter().map("lotterypayresult", LotteryPayCompleteActivity.class);
        Router.sharedRouter().map("squaredailyclean/:geziId", HouseKeepingActivity.class);
        Router.sharedRouter().map("pick/addresslocation", AddressLocationActivity.class);

        Router.sharedRouter().map("payresult", PayResultActivity.class);

        /*
        ------------- 相关初始化 ----------------
         */

        // 初始化httpclient
        HttpClient.init();

        // 设置context
        Helper.sharedHelper().setContext(getApplicationContext());

        mLocationManager = new AMapLocationManager(context);

        // 图片加载库
        Fresco.initialize(context);

        // 初始化imei
        imei = getImei();

        // 获取渠道
        chanel = getChannelCode();

        initUmeng();

        initUmengShare();
        String processName = getProcessName(context);
        if ("com.meidalife.shz".equals(processName)) {   // com.meidalife.shz:push 单独进程，会导致重复执行
            // 启动后台线程：生成uuid和上传device
            new Thread(new TaskRunnable()).start();
            // 初始化定位，定時更新
            TaskExecutor.postTask(new TaskExecutor.TaggedRunnable("initLocation") {
                @Override
                public void run() {
                    try {
                        mLocationManager.updateLocation(null);
                    } catch (Exception e) {
                    }
                }
            });

        }

        //图片编辑sdk初始化
        //PGEditImageLoader.initImageLoader(this);
        //PGEditSDK.instance().initSDK(this);

        LogUtil.log(LogUtil.TYPE_START_APP, this.getClass().getName());

        initEventBus();

        // 初始化悟空
        initWukong();

        TaskExecutor.postTask(new TaskExecutor.TaggedRunnable("initVCamera") {
            @Override
            public void run() {
                try {
                    initVCamera();
                } catch (Exception e) {

                }
            }
        });

        if (BuildConfig.DEBUG) {
            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                @Override
                public void uncaughtException(Thread thread, Throwable ex) {
                    Log.e("SHZApplication", ex.toString());
                    ex.printStackTrace();
                }
            });
        }

        Intent coreSerice = new Intent();
        coreSerice.setClass(this, ShzCoreService.class);
        startService(coreSerice);


        //init hotpatch

        TaskExecutor.postTask(new TaskExecutor.TaggedRunnable("initHotpatch") {
            @Override
            public void run() {
                try {
                    initHotPatch();
                } catch (Exception e) {

                }
            }
        });

//        initHotPatch();

        initFMAgent();

        if (BuildConfig.SHOW_BUG_TAG) {
            MobclickAgent.setCatchUncaughtExceptions(false);
            Bugtags.start("607806f1bb22b2053b11a0e133ed105b", this, Bugtags.BTGInvocationEventBubble);
        }
    }

    void initHotPatch() {
        HotPatchManager manager = HotPatchManager.getInstance((IPatchInfoRequest) new DefaultPatchInfoRequest(this));
        manager.startHotPatch(this);
    }

    private void initWukong() {
        try {
            IMEngine.setUserAvailable(true); // 是否启用悟空保存用户信息（如果设置false只保存openId）
            IMEngine.launch(this);
            if (Helper.sharedHelper().hasToken()) {
                long userId = Long.parseLong(Helper.sharedHelper().getUserId());
                if (IMEngine.getIMService(AuthService.class).latestAuthInfo().getOpenId() == userId) {
                    IMEngine.getIMService(AuthService.class).autoLogin(userId);
                } else {
                    ChatHelper.getInstance(this).authWuKong(Helper.sharedHelper().getUserId());
                }
            }

            registerImListener();
        } catch (Exception e) {
            Log.d("initIM", e.getMessage());
        }
    }

    private void registerImListener() {
        // 若已登录，自动登录一次
        // 会话监听器
        IMEngine.getIMService(ConversationService.class).addConversationListener(new ConversationListener() {
            @Override
            public void onAdded(List<Conversation> list) {
                Log.d(LOG_TAG, "onAdded:" + list.size());
                List<Conversation> conversations = filterOwnSend(list);
                if (conversations.size() == 0) return;
                for (Conversation c : conversations) {
                    c.addUnreadCount(1);    // 先增加计数，再处理回调
                }
                notifyNewMessage(conversations.get(0).latestMessage());
                ConversationEvent event = new ConversationEvent(MsgTypeEnum.TYPE_CHAT);
                event.setConversationList(list);
                EventBus.getDefault().post(event);
            }

            @Override
            public void onRemoved(List<Conversation> list) {
            }
        });

        IMEngine.getIMService(ConversationService.class).addConversationChangeListener(new ConversationChangeListener() {
            @Override
            public void onLatestMessageChanged(List<Conversation> list) {
                Log.d(LOG_TAG, "onLatestMessageChanged:" + list.size());
                List<Conversation> conversations = filterOwnSend(list);
                if (conversations.size() == 0)
                    return;
                if (String.valueOf(conversations.get(0).latestMessage().senderId()).equals(getCurrentChatUserId())) {
                    return;
                }
                for (Conversation c : conversations) {
                    c.addUnreadCount(1);
                }
                notifyNewMessage(conversations.get(0).latestMessage());
                ConversationEvent event = new ConversationEvent(MsgTypeEnum.TYPE_CHAT);
                event.setConversationList(list);
                EventBus.getDefault().post(event);
            }
        });

        // 处理网络连接异常
        WKManager.registerConnectionListener(new ConnectionListener() {
            @Override
            public void onConnected() {
                EventSender.notifyNetworkChanged(NetworkConnectTypeEnum.TYPE_CONNECTED);
            }

            @Override
            public void onDisconnected(String s) {
                EventSender.notifyNetworkChanged(NetworkConnectTypeEnum.TYPE_DISCONNECTED);
            }
        });
    }

    void initFMAgent() {
        FMAgent.init(this, !BuildConfig.DEBUG);
    }

    void initUmengShare() {
        PlatformConfig.setWeixin(Constant.APP_ID_WECHAT, Constant.APP_SECRET_WECHAT);
        PlatformConfig.setSinaWeibo("83477276", "d1be19a6f815cb223a456c7369535c23");
        PlatformConfig.setQQZone(Constant.APP_ID_QQ, Constant.APP_SECRET_QQ);
    }

    void initUmeng() {
        PushAgent mPushAgent = PushAgent.getInstance(getApplicationContext());
        mPushAgent.enable();
        mPushAgent.setNoDisturbMode(4, 35, 4, 36);  // 关闭免打扰 http://dev.umeng.com/push/android/integration#1_7_2，sdk设置0不生效
        //mPushAgent.setMergeNotificaiton(false);   // 1分钟内：同一应用多条消息合并

        UmengNotificationClickHandler notificationClickHandler = new UmengNotificationClickHandler() {
            @Override
            public void dealWithCustomAction(Context context, UMessage msg) {
                try {
                    JSONObject json = msg.getRaw().getJSONObject("extra");
                    String url = json.getString("target_url");
                    if (url.startsWith("http://")) {
                        Bundle bundle = new Bundle();
                        bundle.putString("url", url);
                        Router.sharedRouter().open("web", bundle);
                    } else {
                        String jumpTarget = url.split("//")[1];
                        if ("news".equals(jumpTarget)) {
                            jumpTarget = "main/" + TabIndexEnum.MESSAGE_TAB_INDEX.value;
                        }
                        Router.sharedRouter().open(jumpTarget);
                    }
                } catch (Exception e) {
                    Log.e(SHZApplication.class.getName(), "deal with notify click fail", e);
                }
            }
        };
        UmengMessageHandler umengMessageHandler = new UmengMessageHandler() {
            @Override
            public void dealWithNotificationMessage(Context context, UMessage uMessage) {
                try {
                    Log.d(LOG_TAG, "Notify push message from Umeng channel");
                    notifyNotificationMessage(uMessage.getRaw(), "友盟");
                } catch (Exception e) {
                    Log.e(SHZApplication.class.getName(), "deal with notify message fail", e);
                }
            }
        };
        mPushAgent.setNotificationClickHandler(notificationClickHandler);
        mPushAgent.setMessageHandler(umengMessageHandler);
    }

    public void notifyNotificationMessage(JSONObject json, String channelSuffix) {
        Log.d(LOG_TAG, "notifyNotificationMessage from:" + channelSuffix);
        if (json == null) {
            return;
        }
        try {
            JSONObject extraJson = json.getJSONObject("extra");
            String url = extraJson.getString("target_url");
            if (!TextUtils.isEmpty(url)) {
                String[] urlArray = url.split("//");
                if (urlArray.length > 1) {
                    String jumpTarget = urlArray[1];
                    if (jumpTarget.startsWith("mcoin")) {
                        Router.sharedRouter().open(jumpTarget);
                        return;
                    }
                }
            }

            try {
                if (extraJson.has("message_id")) {
                    long messageId = extraJson.getLong("message_id");

                    List<ImNotifyMsg> imNotifyList = DatabaseManager.getInstance().getDaoSession().getImNotifyMsgDao().
                            queryBuilder().where(ImNotifyMsgDao.Properties.MessageId.eq(messageId)).build().list();
                    if (imNotifyList == null || imNotifyList.isEmpty()) {
                        ImNotifyMsg notifyMsg = new ImNotifyMsg();
                        notifyMsg.setMessageId(messageId);
                        DatabaseManager.getInstance().getDaoSession().getImNotifyMsgDao().insertOrReplace(notifyMsg);
                    } else {
                        Log.d(LOG_TAG, "The notify message already notified.");
                        return;
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            JSONObject bodyJson = json.getJSONObject("body");
            Intent resultIntent = new Intent(SHZApplication.getInstance(), MainActivity.class);
            if (!TextUtils.isEmpty(url)) {
                if (url.startsWith("http://")) {
                    resultIntent.setData(Uri.parse("imlifer://go/" + Uri.encode(url)));
                } else {
                    String jumpTarget = url.split("//")[1];
                    if ("news".equals(jumpTarget)) {
                        jumpTarget = "main/" + TabIndexEnum.MESSAGE_TAB_INDEX.value;
                    }
                    resultIntent.setData(Uri.parse("imlifer://" + jumpTarget));
                }
            }

            PendingIntent resultPendingIntent = PendingIntent.getActivity(
                    SHZApplication.getInstance(), 0, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);

            NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(SHZApplication.getInstance());
            mBuilder.setSmallIcon(R.mipmap.ic_launcher);

            if (BuildConfig.DEBUG || BuildConfig.SHOW_BUG_TAG) {
                mBuilder.setContentTitle(bodyJson.getString("title") + "-" + channelSuffix);
            } else {
                mBuilder.setContentTitle(bodyJson.getString("title"));
            }

            mBuilder.setContentText(bodyJson.getString("text"));
            mBuilder.setTicker(bodyJson.getString("ticker"));
            mBuilder.setWhen(System.currentTimeMillis());
            mBuilder.setAutoCancel(true);
            mBuilder.setDefaults(Notification.DEFAULT_VIBRATE);
            mBuilder.setContentIntent(resultPendingIntent);

            Notification notification = mBuilder.build();
            notification.defaults = Notification.DEFAULT_SOUND;
            //确保最多不超过5个通知
            if (notificationId > 0x105) {
                notificationId = 0x100;
            }
            notificationId++;
            NotificationManager mNotifyMgr = (NotificationManager) SHZApplication.getInstance().
                    getSystemService(Context.NOTIFICATION_SERVICE);
            mNotifyMgr.notify(notificationId, notification);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void notifyNewMessage(Message message) {
        if (message == null ||
                String.valueOf(message.senderId()).equals(getCurrentChatUserId())) {
            return;
        }

        try {
            String text = ChatHelper.getMessageSubTitle(message.messageContent());
            MessageContent content = message.messageContent();
            if (content instanceof MessageContent.TextContent) {
                text = ((MessageContent.TextContent) content).text();
            }

            String userName = null;
            String userId = null;
            if (!TextUtils.isEmpty(message.extension("from"))) {
                com.alibaba.fastjson.JSONObject from = com.alibaba.fastjson.JSONObject.parseObject(message.extension("from"));
                userName = from.getString("nick");
                userId = from.getString("id");
            }
            PendingIntent resultPendingIntent;
            Intent resultIntent = new Intent(this, MainActivity.class);
            Bundle bundle = new Bundle();
            bundle.putInt("index", TabIndexEnum.MESSAGE_TAB_INDEX.value);
            resultIntent.putExtras(bundle);

            if (!TextUtils.isEmpty(userId)) {
                resultIntent.setData(Uri.parse("imlifer://chat/" + userId));
            }

            resultPendingIntent = PendingIntent.getActivity(
                    this, 0, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);

            NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
            mBuilder.setSmallIcon(R.mipmap.ic_launcher);
            mBuilder.setContentTitle("新消息");
            mBuilder.setContentText(TextUtils.isEmpty(userName) ? text : (userName + ": " + text));
            mBuilder.setTicker("收到新消息!");
            mBuilder.setWhen(System.currentTimeMillis());
            mBuilder.setAutoCancel(true);
            mBuilder.setDefaults(Notification.DEFAULT_VIBRATE);
            mBuilder.setContentIntent(resultPendingIntent);

            Notification notification = mBuilder.build();
            notification.defaults = Notification.DEFAULT_SOUND;
            int notificationId = 10090;
            try {
                if (!TextUtils.isEmpty(userId)) {
                    notificationId = Integer.parseInt(userId);
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            NotificationManager mNotifyMgr = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            mNotifyMgr.notify(notificationId, notification);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private List<Conversation> filterOwnSend(List<Conversation> conversationList) {
        List<Conversation> notOwnList = new ArrayList<>();
        for (Conversation c : conversationList) {
            Message m = c.latestMessage();
            if (m == null)
                continue;
            Long sendUserId = m.senderId();
            if (!sendUserId.toString().equals(Helper.sharedHelper().getUserId())) {
                notOwnList.add(c);
            }
        }
        return notOwnList;
    }

    void initVCamera() {
        try {
            File dcim = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            if (DeviceUtils.isZte()) {
                if (dcim.exists()) {
                    VCamera.setVideoCachePath(dcim + "/Camera/meida/");
                } else {
                    VCamera.setVideoCachePath(dcim.getPath().replace("/sdcard/", "/sdcard-ext/") + "/Camera/meida/");
                }
            } else {
                VCamera.setVideoCachePath(dcim + "/Camera/meida/");
            }
            // 开启log输出,ffmpeg输出到logcat
            VCamera.setDebugMode(true);
            // 初始化拍摄SDK，必须
            VCamera.initialize(context);
        } catch (Exception e) {
            Log.e("MainActivity", e.getMessage());
        }
    }

    private void initEventBus() {
        EventBus.clearCaches();
        eventBus = new SHZEventBus();
    }

    public static SHZApplication getInstance() {
        return context;
    }

    class TaskRunnable implements Runnable {

        private boolean isUploaded = false;

        @Override
        public void run() {

            // 先确保生成uuid
            GenUUIdTask uuIdTask = new GenUUIdTask();
            uuIdTask.run();

            // 循环上传device
            while (!isUploaded) {

                try {
                    Thread.sleep(5000);
                } catch (Exception e) {
                }
                ;

                String deviceToken = UmengRegistrar.getRegistrationId(getApplicationContext());
                if (StrUtil.isEmpty(deviceToken)) continue;   // token未获取到，则忽略，等待一定时间接着上传

                device = deviceToken;
                Helper.sharedHelper().setStringUserInfo(Constant.TAG_DEVICE_ID, deviceToken);
                com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
                params.put("deviceId", deviceToken);
                params.put("deviceType", 2);
                boolean res = SyncHttpClient.get(MeidaRestClient.V1 + "addDevice", params);
                if (res) {
                    Log.e(SHZApplication.class.getName(), "upload device success, token = " + deviceToken);
                    isUploaded = true;
                }
            }

            // 初始化日志记录
            LogUtil.init();
        }
    }

    public synchronized AMapLocationManager getLocationManager() {
        if (mLocationManager == null) {
            mLocationManager = new AMapLocationManager(context);
        }
        return mLocationManager;
    }

//    class LocationTask implements Runnable {
//        @Override
//        public void run() {
//            while (true) {
//                Helper.sharedHelper().updateLocation();
//                try {
//                    Thread.sleep(1000 * 60 * 5);
//                } catch (Exception e) {
//                }
//            }
//        }
//    }

    class GenUUIdTask implements Runnable {

        final String filename = "/.data.cache";

        @Override
        public void run() {

            try {
                List<String> fileDirList = new ArrayList<>();
                List<String> needWriteFileList = new ArrayList<>();

                // internal
                try {
                    File intDir = getFilesDir();
                    if (intDir != null) {
                        fileDirList.add(intDir.getAbsolutePath());
                    }
                } catch (Exception e) {
                }

                // external ：系统原生路径-图片文件夹
                try {
                    File extAuthDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                    if (extAuthDir != null) {
                        fileDirList.add(extAuthDir.getAbsolutePath());
                    }
                } catch (Exception e) {
                }

                // external ：mount命令路径
                try {
                    List<String> sdcardDirList = SdcardUtil.getSDCardPaths();
                    fileDirList.addAll(sdcardDirList);
                } catch (Exception e) {
                }

                for (String dir : fileDirList) {
                    if (StrUtil.isEmpty(dir))
                        continue;
                    String absDir = dir + "/com.tencent.mmtp";
                    String fileUuid = readUUId(absDir);
                    if (StrUtil.isEmpty(fileUuid)) {
                        needWriteFileList.add(absDir);
                    } else {
                        uuid = fileUuid;
                    }
                }

                if (StrUtil.isEmpty(uuid)) {
                    uuid = UUID.randomUUID().toString();
                }

                boolean isWriteTrue = false;
                for (String filepath : needWriteFileList) {
                    boolean res = writeUUID(filepath, uuid);
                    if (res) isWriteTrue = true;
                }

                if (needWriteFileList.size() == 0) { // 若所有文件都有uuid
                    Helper.sharedHelper().setStringUserInfo(Constant.UUID, uuid);
                }
                if (isWriteTrue) {   // 写sdcard成功
                    Helper.sharedHelper().setStringUserInfo(Constant.UUID, uuid);
                }

            } catch (Exception e) {
                Log.e(SHZApplication.class.getName(), "gen uuid and write file fail", e);
            }
        }

        private String readUUId(String filedir) {

            String uuid = null;
            try {
                File fin = new File(filedir + filename);
                BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fin), "UTF-8"));
                uuid = reader.readLine();
                reader.close();
                //Log.e(SHZApplication.class.getName(), "read uuid success, filename = " + filedir + ", uuid = " + uuid);
            } catch (Exception e) {
                //Log.e(SHZApplication.class.getName(), "read uuid fail, filename = " + filedir, e);
            }
            return uuid;
        }

        private boolean writeUUID(String filedir, String uuid) {
            try {
                File dir = new File(filedir);
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                File file = new File(filedir + filename);
                if (file.exists()) {
                    file.delete();
                }
                FileOutputStream fos = new FileOutputStream(file);
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fos, "UTF-8"));
                writer.write(uuid);
                writer.flush();
                writer.close();
                //Log.e(SHZApplication.class.getName(), "write uuid success, filename = " + filedir + ", uuid = " + uuid);
                return true;
            } catch (Exception e) {
                //Log.e(SHZApplication.class.getName(), "write uuid fail, filename = " + filedir, e);
                return false;
            }
        }
    }

    public String getProcessName(Context context) {
        int pid = android.os.Process.myPid();
        ActivityManager mActivityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningAppProcessInfo appProcess : mActivityManager.getRunningAppProcesses()) {
            if (appProcess.pid == pid) {
                return appProcess.processName;
            }
        }
        return null;
    }

    public String getVersionName() {
        try {
            if (!TextUtils.isEmpty(versionName)) {
                return versionName;
            }
            PackageManager packageManager = getPackageManager();
            // getPackageName()是你当前类的包名，0代表是获取版本信息
            PackageInfo packInfo = packageManager.getPackageInfo(getPackageName(), 0);
            versionName = packInfo.versionName;
        } catch (Exception e) {
            Log.e(SHZApplication.class.getName(), "get app versionName fail", e);
        }
        return versionName;
    }

    public String getChannelCode() {
        String code = getMetaData(context, "CHANNEL_NAME");
        if (code != null) {
            return code;
        }
        return "bingo";
    }

    public String getCurrentChatUserId() {
        return currentChatUserId;
    }

    public void setCurrentChatUserId(String currentChatUserId) {
        this.currentChatUserId = currentChatUserId;
    }

    private String getMetaData(Context context, String key) {
        try {
            ApplicationInfo ai = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
            Object value = ai.metaData.get(key);
            if (value != null) {
                return value.toString();
            }
        } catch (Exception e) {
        }

        return null;
    }

    private String getImei() {
        String imei = null;
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager != null) {
            imei = telephonyManager.getDeviceId();
        }
        return imei;
    }

    public String getBbId() {
        try {
            if (!TextUtils.isEmpty(bbId)) {
                return bbId;
            } else {
                if (TextUtils.isEmpty(Helper.sharedHelper().getStringUserInfo(Constant.TAG_BB_ID))) {
                    bbId = FMAgent.onEvent();
                    if (bbId.length() > 1024) {
                        //如果同盾生成ID过长，不使用此ID
                        bbId = "";
                    } else {
                        Helper.sharedHelper().setStringUserInfo(Constant.TAG_BB_ID, bbId);
                    }
                } else {
                    bbId = Helper.sharedHelper().getStringUserInfo(Constant.TAG_BB_ID);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bbId;
    }
}
