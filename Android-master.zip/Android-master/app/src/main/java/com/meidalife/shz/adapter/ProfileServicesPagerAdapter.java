package com.meidalife.shz.adapter;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ProfileItemDO;
import com.meidalife.shz.view.MyGridView;
import com.usepropeller.routable.Router;

import java.util.ArrayList;

/**
 * Created by taber on 15/8/11.
 */
public class ProfileServicesPagerAdapter extends PagerAdapter {
    ArrayList<ArrayList<ProfileItemDO>> mData;
    Context mContext;
    LayoutInflater mInflater;

    public ProfileServicesPagerAdapter(Context mContext, ArrayList<ArrayList<ProfileItemDO>> mData) {
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.mData = mData;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public View instantiateItem(ViewGroup container, final int position) {
        View rootView = mInflater.inflate(R.layout.item_profile_service_grid, container, false);
        MyGridView gridViewServices = (MyGridView) rootView.findViewById(R.id.gridViewServices);
        gridViewServices.setAdapter(new ProfileServicesAdapter(mContext, mData.get(position)));
        gridViewServices.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int index, long id) {
                ArrayList<ProfileItemDO> items = mData.get(position);
                ProfileItemDO item = items.get(index);
                Router.sharedRouter().open("services/" + item.getItemId());
            }
        });
        if (rootView.getParent() == null) {
            container.addView(rootView);
        }
        return rootView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }
}
