package com.meidalife.shz.event;

import com.meidalife.shz.event.type.MsgTypeEnum;

/**
 * Created by liujian on 16/1/21.
 */
public class LotteryListRefreshEvent extends BaseEvent{

    public LotteryListRefreshEvent() {
        super(MsgTypeEnum.TYPE_REFRESH);
    }
}
