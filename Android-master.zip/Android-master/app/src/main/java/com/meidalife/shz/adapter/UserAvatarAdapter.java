package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.UserDO;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by zuozheng on 15/12/22.
 * 广告adapter
 */
public class UserAvatarAdapter extends RecyclerView.Adapter<UserAvatarAdapter.ViewHolder> {
    private LayoutInflater mInflater;
    Context mContext;
    List<UserDO> mList;

//    int avatarImgWidth;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }

        @Bind(R.id.user_avatar)
        ImageView avatar;
    }

    public UserAvatarAdapter(Context context, List<UserDO> mList) {
        mContext = context;
        this.mInflater = LayoutInflater.from(context);
        this.mList = mList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = mInflater.inflate(R.layout.activity_service_detail_like_avatar, null);

//        Activity activity = (Activity) mContext;
//        Display display = activity.getWindowManager().getDefaultDisplay();
//        Point size = new Point();
//        display.getSize(size);
//        int avatarWidth = size.x;
//        float margin = Helper.convertDpToPixel(77, mContext);
//        float spacing = Helper.convertDpToPixel(5, mContext);
//        float padding = Helper.convertDpToPixel(0, mContext);
//        // width -= margin * 2;
//        avatarWidth -= margin;
//        avatarWidth -= spacing * (mList.size() - 1);
//        avatarWidth -= padding * (mList.size() - 1);
//        avatarImgWidth = avatarWidth / mList.size();

        return new ViewHolder(convertView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        UserDO user = mList.get(position);

//        ViewGroup.LayoutParams params = holder.avatar.getLayoutParams();// 得到item的LayoutParams布局参数
//        params.width = avatarImgWidth;// 把随机的高度赋予item布局
//        holder.avatar.setLayoutParams(params);// 把params设置给item布局

        if (user == null || TextUtils.isEmpty(ImgUtil.getCDNUrlWithWidth(user.getUserPicUrl(), holder.avatar.getLayoutParams().width))) {
            holder.avatar.setImageURI(null);
        } else {
            holder.avatar.setImageURI(Uri.parse(ImgUtil.getCDNUrlWithWidth(user.getUserPicUrl(), holder.avatar.getLayoutParams().width)));

        }

//            viewHolder.avatar.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    Router.sharedRouter().open("profile/" + user.getUserId());
//                }
//            });
    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

}
