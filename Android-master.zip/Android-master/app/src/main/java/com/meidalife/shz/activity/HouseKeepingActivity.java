package com.meidalife.shz.activity;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.HouseKeepingDo;
import com.usepropeller.routable.Router;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/2/22.
 */
public class HouseKeepingActivity extends BaseActivity {
    @Bind(R.id.serviceBg)
    SimpleDraweeView serviceBg;

    @Bind(R.id.servicePrice)
    TextView servicePrice;
    @Bind(R.id.serviceInterval)
    TextView serviceInterval;

    @Bind(R.id.detailList)
    ListView detailList;
    @Bind(R.id.orderButton)
    TextView orderButton;

    String geziId;
    String itemId;
    HouseKeepingDetailAdapter houseKeepingDetailAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_house_keeping);
        ButterKnife.bind(this);
        initActionBar(R.string.title_house_keeping, true, false);
        houseKeepingDetailAdapter = new HouseKeepingDetailAdapter(this, new JSONArray());
        detailList.setAdapter(houseKeepingDetailAdapter);
        geziId = getIntent().getStringExtra("geziId");

        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("order/" + itemId + "/" + geziId);
            }
        });
        getData();
    }

    private void getData() {
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);

        HttpClient.get("1.0/gezi/item/jiazheng/book", params, HouseKeepingDo.class,
                new HttpClient.HttpCallback<HouseKeepingDo>() {
                    @Override
                    public void onSuccess(HouseKeepingDo obj) {
                        if (null != obj) {
                            ViewGroup.LayoutParams params = serviceBg.getLayoutParams();
                            params.width = getResources().getDisplayMetrics().widthPixels;
                            //根据约定比例设置图片高度
                            params.height = (int) (getResources().getDisplayMetrics().widthPixels * (float) 263 / 375);
                            serviceBg.setLayoutParams(params);
                            if (!TextUtils.isEmpty(obj.getPicUrl())) {
                                serviceBg.setImageURI(Uri.parse(obj.getPicUrl()));
                            }

                            servicePrice.setText(obj.getPrice());
                            serviceInterval.setText(obj.getRemark());

                            itemId = obj.getItemId();
                            houseKeepingDetailAdapter.setHouseKeepingDetailDos(obj.getDetailList());
                            houseKeepingDetailAdapter.notifyDataSetChanged();
                        }
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToast(error.toString());
                    }
                });
    }

    public class HouseKeepingDetailAdapter extends BaseAdapter {
        Context mContext;
        private JSONArray houseKeepingDetailArray = new JSONArray();

        public HouseKeepingDetailAdapter(Context context, JSONArray houseKeepingDetailDos) {
            mContext = context;
            setHouseKeepingDetailDos(houseKeepingDetailDos);
        }

        public void setHouseKeepingDetailDos(JSONArray houseKeepingDetailDos) {
            houseKeepingDetailArray = houseKeepingDetailDos;
        }

        @Override
        public int getCount() {
            return houseKeepingDetailArray.size();
        }

        @Override
        public Object getItem(int position) {
            return houseKeepingDetailArray.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (convertView == null) {
                viewHolder = new ViewHolder();
                convertView = LayoutInflater.from(mContext).inflate(R.layout.item_house_keeping_detail, parent, false);
                viewHolder.title = (TextView) convertView.findViewById(R.id.title);
                viewHolder.detail = (TextView) convertView.findViewById(R.id.detail);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            JSONObject jsonObject = houseKeepingDetailArray.getJSONObject(position);
            viewHolder.title.setText(jsonObject.getString("title"));
            viewHolder.detail.setText(jsonObject.getString("value"));
            return convertView;
        }
    }

    public static class ViewHolder {
        TextView title;
        TextView detail;
    }
}
