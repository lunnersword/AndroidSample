package com.meidalife.shz.activity.fragment;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.MessageAdapter;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.event.ConversationEvent;
import com.meidalife.shz.event.EventSender;
import com.meidalife.shz.event.type.MsgTypeEnum;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ConversationDO;
import com.meidalife.shz.rest.request.RequestMessage;
import com.meidalife.shz.util.LoadUtil;
import com.umeng.analytics.MobclickAgent;
import com.usepropeller.routable.Router;

import java.util.LinkedList;
import java.util.List;

import de.greenrobot.event.EventBus;

public class MessageNotifyFragment extends BaseFragment {

    private Context context;

    private ViewGroup rootView;
    private View contentRoot;
    private LoadUtil loadUtil;

    private ListView listView;
    private RelativeLayout cellEmptyData;
    private MessageAdapter messageAdapter;
    List<ConversationDO> mNotifyList;

    ConversationDO mConversationDO;
    int mUnread;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mNotifyList = new LinkedList<ConversationDO>();
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {

        context = inflater.getContext();
        View rootLayout = inflater.inflate(R.layout.fragment_message_notify, null);

        rootView = (ViewGroup) rootLayout.findViewById(R.id.root_view);
        contentRoot = rootLayout.findViewById(R.id.content_root_view);
        loadUtil = new LoadUtil(inflater);

        cellEmptyData = (RelativeLayout) rootLayout.findViewById(R.id.message_no_data);
        listView = (ListView) rootLayout.findViewById(R.id.message_list);


        messageAdapter = new MessageAdapter(context, mNotifyList);
        listView.setAdapter(messageAdapter);


        /*
        点击事件
         */
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ConversationDO conversation = (ConversationDO) view.getTag();
                Router.sharedRouter().open("notification/" + conversation.getSubType());
            }
        });

        /*
        长按事件
         */
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                View deleteView = inflater.inflate(R.layout.message_delete_dialog, null);
                final AlertDialog dialog = new AlertDialog.Builder(context).create();
                dialog.setView(deleteView, 0, 0, 0, 0);
                dialog.show();
                View deleteTv = deleteView.findViewById(R.id.singleContextMenu);
                deleteTv.setVisibility(View.VISIBLE);
                deleteTv.setTag(position);
                deleteTv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final Integer position = (Integer) v.getTag();
                        mConversationDO = (ConversationDO) messageAdapter.getItem(position);
                        mUnread = mConversationDO.getUnread();
                        mConversationDO.setUnread(0);
                        dialog.dismiss();
                        JSONObject params = new JSONObject();
                        params.put("type", mConversationDO.getSubType());

                        HttpClient.get("1.0/notification/clearUnread", params, JSONObject.class, new HttpClient.HttpCallback() {

                            @Override
                            public void onSuccess(Object obj) {
                                //使用EventBus实现 先更新tab消息数量,后对未读数设为0
                                EventSender.modifyUnReadMsgCount(MsgTypeEnum.TYPE_NOTIFICATION, mUnread);

                                //调用接口设置已读成功 未读数设为0
                                mConversationDO.setUnread(0);

                                if (null != messageAdapter) {
                                    messageAdapter.notifyDataSetChanged();
                                }
                            }

                            @Override
                            public void onFail(HttpError error) {
                                MessageUtils.showToast(error.toString());
                            }
                        });
                    }
                });
                return true;
            }
        });

        return rootLayout;
    }


    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart(this.getClass().getName());
        LogUtil.log(LogUtil.TYPE_START_PAGE, this.getClass().getName());

        loadNotifyData();
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd(this.getClass().getName());
        LogUtil.log(LogUtil.TYPE_EXIT_PAGE, this.getClass().getName());
    }

    private void loadNotifyData() {
        loadUtil.loadPre(rootView, contentRoot);

        RequestMessage.getConversationList(new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                List<ConversationDO> list = (List<ConversationDO>) result;
                loadUtil.loadSuccess(contentRoot);

                mNotifyList.clear();
                mNotifyList.addAll(list);
                if (mNotifyList.size() == 0) {
                    listView.setVisibility(View.GONE);
                    cellEmptyData.setVisibility(View.VISIBLE);
                } else {
                    listView.setVisibility(View.VISIBLE);
                    cellEmptyData.setVisibility(View.GONE);
                }

                int notifyUnread = 0;
                for (int i = 0; i < list.size(); i++) {
                    ConversationDO c = list.get(i);
                    notifyUnread += c.getUnread();
                }
                //使用event bus 实现
                EventSender.notifyHadNewMsg(MsgTypeEnum.TYPE_NOTIFICATION, notifyUnread);

                ConversationEvent event = new ConversationEvent(MsgTypeEnum.TYPE_NOTIFICATION);
                event.setUnreadNotificationCount(notifyUnread);
                EventBus.getDefault().post(event);
                messageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(HttpError error) {
                loadUtil.loadFail(error, rootView, getActivity(), new LoadUtil.LoadCallback() {
                    @Override
                    public void execute() {
                        loadNotifyData();
                    }
                });
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
