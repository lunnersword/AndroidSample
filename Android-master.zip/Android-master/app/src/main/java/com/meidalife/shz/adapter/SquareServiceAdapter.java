package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.common.util.UriUtil;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.SquareCateDO;
import com.meidalife.shz.util.ImgUtil;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 格子首页  格子中宝贝item adapter
 * Created by zhq on 15/12/20.
 */
public class SquareServiceAdapter extends RecyclerView.Adapter<SquareServiceAdapter.ViewHolder> {
    LayoutInflater mInflater;
    Context mContext;
    List<SquareCateDO> mData;

    static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

//        @Bind(R.id.rootView)
//        View rootView;

        @Bind(R.id.serviceImg)
        SimpleDraweeView serviceImg;

        @Bind(R.id.cateName)
        TextView cateName;

        @Bind(R.id.serviceCount)
        TextView serviceCount;

        @Bind(R.id.bottomView)
        View bottomView;
    }

    public SquareServiceAdapter(Context context, List<SquareCateDO> data) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mData = data;
        mContext = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = mInflater.inflate(R.layout.item_square_service, null);

        return new ViewHolder(convertView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        SquareCateDO item = mData.get(position);

        if (item == null || TextUtils.isEmpty(ImgUtil.getCDNUrlWithWidth(item.getPicUrl(), holder.serviceImg.getLayoutParams().width))) {
            Uri uri = new Uri.Builder()
                    .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.pic_default_item)).build();
            holder.serviceImg.setImageURI(uri);
        } else {
            holder.serviceImg.setImageURI(Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getPicUrl(), holder.serviceImg.getLayoutParams().width)));
        }

        if (TextUtils.isEmpty(item.getCategoryName())) {
            holder.bottomView.setBackgroundColor(mContext.getResources().getColor(android.R.color.transparent));
        } else {
            holder.bottomView.setBackgroundColor(mContext.getResources().getColor(R.color.half_black));
        }
        holder.cateName.setText(item.getCategoryName());
        holder.serviceCount.setText("" + item.getItemCount());
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }
}
