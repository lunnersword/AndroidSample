package com.meidalife.shz.activity;

import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.PositionOutDO;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.DateUtils;
import com.usepropeller.routable.Router;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 发布便民电话 只有格主有发布权限
 * Created by xingchen on 2015/12/17.
 */
public class SquareNearByPublishActivity extends BaseActivity {
    private final static int SELECT_CATEGORY = 80;

    @Bind(R.id.nearbyTitle)
    EditText nearbyTitle;
    @Bind(R.id.textTitleLimit)
    TextView textTitleLimit;
    @Bind(R.id.nearbyContent)
    EditText nearbyContent;
    @Bind(R.id.textContentLimit)
    TextView textContentLimit;
    @Bind(R.id.startTime)
    TextView startTime;
    @Bind(R.id.endTime)
    TextView endTime;
    @Bind(R.id.catNameText)
    TextView catNameText;
    @Bind(R.id.removeImage)
    TextView removeImage;
    @Bind(R.id.picView)
    SimpleDraweeView picView;
    @Bind(R.id.selectPicView)
    View selectPicView;
    @Bind(R.id.addressText)
    TextView addressText;
    @Bind(R.id.phone)
    EditText phone;
    @Bind(R.id.saveView)
    TextView saveView;
    @Bind(R.id.rootView)
    ViewGroup rootView;
    @Bind(R.id.contentView)
    View contentView;

    private String picPath;
    private PositionOutDO positionOut;
    private boolean submit = false;
    private boolean uploadComplete = false;
    private boolean uploading = false;
    private String uploadImage;
    private int catId = Integer.MAX_VALUE;
    private int geziId = Integer.MAX_VALUE;
    private int id = Integer.MAX_VALUE;
    private double longitude = 0.0;
    private double latitude = 0.0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_square_nearby_publish);
        initActionBar(R.string.square_nearby_publish, true, false);
        ButterKnife.bind(this);
        if(!TextUtils.isEmpty(getIntent().getStringExtra("geziId")))
            geziId = Integer.parseInt(getIntent().getStringExtra("geziId"));
        if(!TextUtils.isEmpty(getIntent().getStringExtra("id")))
            id = Integer.parseInt(getIntent().getStringExtra("id"));
        hideIMM();
      //  mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());

        initListener();
        if(id!=Integer.MAX_VALUE)
            initData();
    }

    private void initListener() {
        phone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String contents = Helper.formatMobileNumber(s.toString().trim());
                if (contents.length() != s.toString().length()) {
                    phone.setText(contents);
                    phone.setSelection(contents.length());
                }
            }
        });
        nearbyTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textTitleLimit.setText("" + s.toString().length());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        nearbyContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textContentLimit.setText("" + s.toString().length());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        removeImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeImage.setVisibility(View.GONE);
                picView.setVisibility(View.GONE);
                selectPicView.setEnabled(true);
                picPath = null;
                uploadImage = null;
                uploadComplete = false;
            }
        });

        saveView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handlePublish();
            }
        });
    }

    private void initData(){
        showStatusLoading(rootView);
        contentView.setVisibility(View.GONE);
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("geziId", geziId);
        params.put("id", id);
        HttpClient.get("1.0/gezi/yp/detail", params, null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                hideStatusLoading();
                contentView.setVisibility(View.VISIBLE);
                initView(obj);
            }

            @Override
            public void onFail(HttpError error) {
                hideStatusLoading();
                contentView.setVisibility(View.VISIBLE);
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "加载数据失败");
            }
        });
    }

    private void initView(com.alibaba.fastjson.JSONObject result){
        nearbyTitle.setText(result.getString("title"));
        nearbyContent.setText(result.getString("desc"));
        addressText.setText(result.getString("address"));
        phone.setText(result.getString("phone"));
        String openHour = result.getString("openHour");
        String[] times = new String[2];
        //为了兼容之前页面调整造成的数据格式不一问题
        if(openHour.contains("-")){
            times = openHour.split("-");
        }else if(openHour.contains("~")){
            times = openHour.split("~");
        }
        if(times.length == 2){
            startTime.setText(times[0]);
            endTime.setText(times[1]);
        }
        uploadImage = (String)result.getJSONArray("pics").get(0);
        longitude = result.getDoubleValue("poiLongitude");
        latitude = result.getDoubleValue("poiLatitude");
        if(result.containsKey("catId") && result.containsKey("catName")){
            catId = result.getIntValue("catId");
            catNameText.setText(result.getString("catName"));
        }
        if(!TextUtils.isEmpty(uploadImage)){
            Log.d("initUploadImage",uploadImage);
            showImage(Uri.parse(uploadImage));
            uploadComplete = true;
        }
    }

    private void showImage(Uri uri) {
        picView.setImageURI(uri);
        picView.setVisibility(View.VISIBLE);
        removeImage.setVisibility(View.VISIBLE);
        selectPicView.setEnabled(false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK)
            return;
        Bundle params;
        switch (requestCode) {
            case SELECT_CATEGORY:
                params = data.getBundleExtra("params");
                String catName = params.getString("catName", "");
                catId = params.getInt("catId", Integer.MAX_VALUE);
                catNameText.setText(catName);
                catNameText.setTextColor(getResources().getColor(R.color.nearby_text));
                break;
            case Constant.REQUEST_CODE_PICK_PHOTO:
                params = data.getExtras();
                ArrayList paths = params.getStringArrayList("images");
                if (paths.size() > 0) {
                    picPath = (String) paths.get(0);
                    showImage(Uri.fromFile(new File(picPath)));
                }
                break;
            case Constant.REQUEST_CODE_PICK_LOCATION:
                Bundle extras = data.getExtras();
                positionOut = (PositionOutDO) extras.getSerializable("INTENT_SELECTED_ADDRESS");
                addressText.setText(positionOut.getAddress());
                longitude = positionOut.getPoiLongitude();
                latitude = positionOut.getPoiLatitude();
                addressText.setTextColor(getResources().getColor(R.color.nearby_text));
                break;
        }
    }


    public void handlePublish() {
        if (catId == Integer.MAX_VALUE) {
            MessageUtils.showToastCenter("还未选择信息类型哦");
            return;
        }

        if (TextUtils.isEmpty(nearbyTitle.getText().toString())) {
            MessageUtils.showToastCenter("还未填写周边名称哦");
            return;
        }

        if ( TextUtils.isEmpty(addressText.getText().toString())
                || "选择定位".equals(addressText.getText().toString())
                || (latitude == 0 && longitude == 0.0)) {
            MessageUtils.showToastCenter("还未选择定位哦");
            return;
        }

        if (TextUtils.isEmpty(phone.getText().toString())) {
            MessageUtils.showToastCenter("还未填写联系电话哦");
            return;
        }

        if (TextUtils.isEmpty(nearbyContent.getText().toString())) {
            MessageUtils.showToastCenter("还未描述内容哦");
            return;
        }

        if (picPath == null && uploadImage == null) {
            MessageUtils.showToastCenter("还未选择上传图片哦");
            return;
        }

        if (!submit) {
            submit = true;
            showProgressDialog("正在发布", false);

            if (uploadComplete && uploadImage != null) {
                xhrPublish();
            } else {
                uploadImages();
            }
        }
    }


    private void uploadImages() {
        if (!uploading && picPath != null) {
            uploading = true;
            RequestSign.upload(picPath, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    JSONObject json = (JSONObject) result;
                    try {
                        uploadImage = json.getString("data");
                        uploadComplete = true;
                        if (submit) {
                            xhrPublish();
                        }
                    } catch (JSONException e) {
                        uploading = false;
                        uploadComplete = false;
                        hideProgressDialog();
                        MessageUtils.showToastCenter(e.getMessage());
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    uploading = false;
                    uploadComplete = false;
                    submit = false;
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败");
                }
            });
        }
    }

    private void xhrPublish() {

        HttpClient.post("1.0/gezi/yp/add", getParams(), null, new HttpClient.HttpCallback<com.alibaba.fastjson.JSONObject>() {
            @Override
            public void onSuccess(com.alibaba.fastjson.JSONObject obj) {
                hideProgressDialog();
                submit = false;
                setResult(RESULT_OK);
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                submit = false;
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败，请重试");
            }
        });
    }

    private com.alibaba.fastjson.JSONObject getParams() {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        if(id!=Integer.MAX_VALUE)
            params.put("id",id);
        params.put("geziId", geziId);
        params.put("catId", catId);
        params.put("poiLongitude", longitude);
        params.put("poiLatitude", latitude);
        params.put("address", addressText.getText().toString());
        params.put("phone", phone.getText().toString().replace(" ", ""));
        params.put("title", nearbyTitle.getText().toString());
        params.put("desc", nearbyContent.getText().toString());
        com.alibaba.fastjson.JSONArray pics = new com.alibaba.fastjson.JSONArray();
        pics.add(uploadImage);
        params.put("pics", pics);
        params.put("openHour", startTime.getText().toString() + "-" + endTime.getText().toString());
        return params;
    }

    public void selectStartTime(View view) {
        TimePickerDialog time = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {

            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                startTime.setText(DateUtils.formatTime(hourOfDay) + ":" + DateUtils.formatTime(minute));
            }
        }, 00, 00, true);
        time.show();
    }

    public void selectEndTime(View view) {
        TimePickerDialog time = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {

            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                endTime.setText(DateUtils.formatTime(hourOfDay) + ":" + DateUtils.formatTime(minute));
            }
        }, 00, 00, true);
        time.show();
    }

    public void selectCatType(View view) {
        Bundle params = new Bundle();
        params.putInt("type", NearbyCategoryActivity.SQUARE_NEARBY_CATEGORY);
        params.putInt("geziId", geziId);
        Router.sharedRouter().openFormResult("nearbyCat", params, SELECT_CATEGORY, this);
    }

    public void selectPic(View view) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isCheckbox", true);
        bundle.putInt("maxLength", 1);
        Router.sharedRouter().openFormResult("pick/photo", bundle,
                Constant.REQUEST_CODE_PICK_PHOTO, this);
    }

    public void selectAddress(View view) {
        Bundle params = new Bundle();
        params.putDouble(Constant.GPS_LONG, longitude);
        params.putDouble(Constant.GPS_LAT, latitude);
        Router.sharedRouter().openFormResult("location/1",params,
                Constant.REQUEST_CODE_PICK_LOCATION, this);
    }

    @Override
    public void onBackPressed() {
        if (!hasChange()) {
            super.onBackPressed();
            return;
        }

        MessageUtils.createDialog(SquareNearByPublishActivity.this, "提醒", "真的要放弃编辑吗", R.string.confirm_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }, R.string.cancel_alias_publish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        }).show();
    }

    private boolean hasChange(){
        if(id == Integer.MAX_VALUE){
            if(catId == Integer.MAX_VALUE
                    && "选择定位".equals(addressText.getText().toString())
                    && TextUtils.isEmpty(nearbyTitle.getText().toString())
                    && TextUtils.isEmpty(nearbyContent.getText().toString())
                    && startTime.getText().toString().equals("00:00")
                    && endTime.getText().toString().equals("00:00")
                    && TextUtils.isEmpty(uploadImage)
                    && TextUtils.isEmpty(phone.getText().toString())){
                return false;
            }
        }
        return true;
    }
}
