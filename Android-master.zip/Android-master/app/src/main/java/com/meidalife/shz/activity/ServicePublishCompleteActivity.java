package com.meidalife.shz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.util.ShareActivity;
import com.usepropeller.routable.Router;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ServicePublishCompleteActivity extends BaseActivity {
    ShareActivity shareActivity;
    ServiceItem serviceItem;

    @Bind(R.id.checkDetailButton)
    TextView checkDetailButton;
    @Bind(R.id.continuePublishButton)
    TextView continuePublishButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_publish_complete);
        ButterKnife.bind(this);
        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            ArrayList<String> images = new ArrayList<String>();
            images.add(bundle.getString("image"));
            serviceItem = new ServiceItem();
            serviceItem.setImages(images);
            serviceItem.setContent(bundle.getString("desc"));
            serviceItem.setItemId(bundle.getString("itemId"));
            serviceItem.setTag(bundle.getString("title"));
            serviceItem.setUserId(Long.parseLong(Helper.sharedHelper().getUserId()));
            serviceItem.setUserName(Helper.sharedHelper().getStringUserInfo(Constant.USER_NICK));
            boolean bindGezi = bundle.getBoolean("bindGezi", false);
            if (bindGezi) {
                Bundle params = new Bundle();
                params.putString("serviceId", serviceItem.getItemId());
                params.putInt("type", ServiceJoinSquareActivity.SERVICE_JOIN_SQUARES);
                Router.sharedRouter().open("serviceJoinSquare", params);
            }
        }

        shareActivity = new ShareActivity(this);

        checkDetailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handlerCheckServiceDetail(v);
            }
        });

        continuePublishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                continuePublishService(v);
            }
        });
    }

    public void handleClose(View view) {
        finish();
    }

    public void handleShareCircle(View view) {
        if (serviceItem == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        shareActivity.shareServiceWithWxCircle(this, serviceItem);
    }

    public void handleShareWechat(View view) {
        if (serviceItem == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        shareActivity.shareServiceWithWxChat(this, serviceItem);
    }

    public void handleShareSina(View view) {
        if (serviceItem == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        shareActivity.shareServiceWithWeibo(this, serviceItem);
    }

    public void handleShareQQ(View view) {
        if (serviceItem == null) {
            MessageUtils.showToastCenter("分享内容不存在");
            return;
        }
        shareActivity.shareServiceWithQQ(this, serviceItem);
    }

    @OnClick(R.id.checkDetailButton)
    public void handlerCheckServiceDetail(View view) {
        Router.sharedRouter().open("services/" + serviceItem.getItemId());
        finish();
    }

    @OnClick(R.id.continuePublishButton)
    public void continuePublishService(View view) {
        Router.sharedRouter().open("publish");
        finish();
    }
}
