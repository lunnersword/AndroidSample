package com.meidalife.shz.im;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.meidalife.shz.Helper;
import com.meidalife.shz.service.ShzCoreService;

/**
 * Created by fufeng on 15/12/10.
 */
public class ImPushReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("ImPushReceiver", "onReceive" + intent.getAction());
        if (Helper.isNetworkConnected(context)) {
            Intent coreSerice = new Intent();
            coreSerice.setClass(context, ShzCoreService.class);
            context.startService(coreSerice);
        }
    }
}
