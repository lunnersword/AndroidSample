package com.meidalife.shz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.facebook.common.util.UriUtil;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.Bind;
import butterknife.ButterKnife;

public class UploadVideoActivity extends BaseActivity {

    private static final String TAG = "UploadVideo";


    @Bind(R.id.video_pic)
    SimpleDraweeView videoPic;

    String videoPath, remoteVideoUrl;
    String picPath, remotePicUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_video);
        initActionBar("视频", true, false);

        ButterKnife.bind(this);
        Bundle bundle = getIntent().getExtras();
        videoPath = bundle.getString("videoPath");
        picPath = bundle.getString("videoPicPath");

        if (TextUtils.isEmpty(videoPath)) {
            MessageUtils.showToast("视频内容为空 请重新拍摄");
            return;
        }

        if (TextUtils.isEmpty(picPath)) {
            Uri uri = new Uri.Builder()
                    .scheme(UriUtil.LOCAL_RESOURCE_SCHEME).path(String.valueOf(R.drawable.pic_service_default)).build();
            videoPic.setImageURI(uri);
        } else {
            Uri imgUri = new Uri.Builder()
                    .scheme(UriUtil.LOCAL_FILE_SCHEME).path(picPath).build();
            videoPic.setImageURI(imgUri);
        }


        //todo 如果为空 设置button不可以点击
    }

    public void handleUpload(View v) {
        xhrUploadVideoFile();
    }


    public void xhrUploadVideoFile() {
        if (TextUtils.isEmpty(videoPath)) {
            MessageUtils.showToast("视频文件为空 请重新录制");
            return;
        }
        showProgressDialog("正在上传，请别关闭", false);
        RequestSign.uploadVideo(videoPath, new HttpClient.HttpCallback<String>() {
            @Override
            public void onSuccess(String videoUrl) {
                hideProgressDialog();
                MessageUtils.showToast("上传文件成功");
                //todo  上传文件成功 需要调用更新个人信息接口 更新音频url和视频url
                remoteVideoUrl = videoUrl;

                if (!TextUtils.isEmpty(picPath)) {
                    xhrUpdateImages(picPath);
                } else {
                    xhrUpdateProfile();
                }
            }

            @Override
            public void onFail(HttpError error) {

            }
        });
    }

    public void handleOpenSpecification(View v) {
        String url = "http://kongge.com/support/agreement_video.html";
        Intent intent = new Intent();
        intent.setClass(this, WebActivity.class);
        intent.putExtra("url", url);
        startActivity(intent);
    }

    private void xhrUpdateProfile() {
        try {
            JSONObject params = new JSONObject();

            if (!TextUtils.isEmpty(remotePicUrl)) {
                params.put("vedioPic", remotePicUrl);
            }

            params.put("vedioUrl", remoteVideoUrl);

            showProgressDialog("正在更新个人信息");
            RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    hideProgressDialog();
                    //todo 更新个人详情接口 跳转到个人详情
//                    if (Helper.sharedHelper().hasToken()) {
//                        Router.sharedRouter().open("profile/" + Helper.sharedHelper().getUserId());
//                    } else {
//                        Router.sharedRouter().open("signin");
//                    }
                    finish();
                }

                @Override
                public void onFailure(HttpError error) {
                    hideProgressDialog();
//                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败");
                }
            });
        } catch (JSONException e) {
        }
    }


    private void xhrUpdateImages(final String picPath) {
        RequestSign.upload(picPath, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                org.json.JSONObject json = (org.json.JSONObject) result;
                try {
                    remotePicUrl = json.getString("data");
                    xhrUpdateProfile();
                } catch (Exception e) {
                    MessageUtils.showToastCenter(e.getMessage());
                }
            }

            @Override
            public void onFailure(HttpError error) {
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "图片上传失败");
            }
        });
    }
}
