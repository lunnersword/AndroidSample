package com.meidalife.shz.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.Album;

import java.io.File;
import java.util.List;

/**
 * Created by feng on 2015/7/18.
 */
public class AlbumListAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private List<Album> albumList;

    public AlbumListAdapter(Context context, List<Album> albumList) {
        mInflater = LayoutInflater.from(context);
        this.albumList = albumList;
        mContext = context;
    }

    @Override
    public int getCount() {
        return albumList.size();
    }

    @Override
    public Object getItem(int position) {
        return albumList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (convertView == null || convertView.getTag() == null) {
            convertView = mInflater.inflate(R.layout.album_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.cover = (ImageView) convertView.findViewById(R.id.album_cover);
            viewHolder.albumTitle = (TextView) convertView.findViewById(R.id.album_title);
            viewHolder.albumCount = (TextView) convertView.findViewById(R.id.album_count);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        Album album = albumList.get(position);
        viewHolder.albumTitle.setText(album.getBucketName());
        viewHolder.albumCount.setText(String.format(mContext.getString(R.string.album_count),
                album.getSize()));

        String path = album.getCover();
        //int iconSize = SobrrConstants.getSobrrDimenToPixel(R.dimen.album_icon_size);
        if (null != path) {
            File imageFile = new File(path);
            viewHolder.cover.setImageResource(R.mipmap.ic_launcher);
            if (imageFile.exists()) {
                Glide.with(mContext.getApplicationContext()).load(imageFile).error(R.mipmap.ic_launcher).into(viewHolder.cover);
            }
        }
        return convertView;
    }

    public static class ViewHolder {
        public ImageView cover;
        public TextView albumTitle;
        public TextView albumCount;
    }
}
