package com.meidalife.shz.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 格子管理中心-发布公告
 * Created by xingchen on 2015/12/22.
 */
public class MDSquareManagePublishActivity extends BaseActivity {
    private static int TEXT_LENGTH_LIMIT_CONTENT = 15;

    @Bind(R.id.noticeView)
    EditText noticeView;
    @Bind(R.id.textContentLimit)
    TextView textContentLimit;

    private int geziId = Integer.MAX_VALUE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_square_manage_publish);
        ButterKnife.bind(this);

        initActionBar(R.string.square_manager_center_notice, true, true);
        if(!TextUtils.isEmpty(getIntent().getStringExtra("geziId")))
            geziId = Integer.parseInt(getIntent().getStringExtra("geziId"));
        Bundle params = getIntent().getExtras();
        if(params != null && params.getString("notice") != null){
            noticeView.setText(params.getString("notice"));
            noticeView.setSelection((params.getString("notice")).length());
        }
        mButtonRight.setText(R.string.publish);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateNotice();
            }
        });

        noticeView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textContentLimit.setText("" + s.toString().length());
                if (s.toString().length() > TEXT_LENGTH_LIMIT_CONTENT) {
                    textContentLimit.setTextColor(getResources().getColor(R.color.brand_b));
                } else {
                    textContentLimit.setTextColor(getResources().getColor(R.color.grey_c));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void updateNotice() {
        String notice = noticeView.getText().toString();
        if (TextUtils.isEmpty(notice)) {
            MessageUtils.showToastCenter("还未填写公告内容哦");
            return;
        }
        if (notice.length() > TEXT_LENGTH_LIMIT_CONTENT) {
            MessageUtils.showToastCenter("公告内容不能超过15个字");
            return;
        }
        showProgressDialog("正在发布");
        JSONObject params = new JSONObject();
        params.put("geziId", geziId);
        params.put("notice", noticeView.getText().toString());
        HttpClient.get("1.0/gezi/update", params, null, new HttpClient.HttpCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject obj) {
                hideProgressDialog();
                finish();
            }

            @Override
            public void onFail(HttpError error) {
                hideProgressDialog();
                MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败，请稍后再试");
            }
        });
    }
}
