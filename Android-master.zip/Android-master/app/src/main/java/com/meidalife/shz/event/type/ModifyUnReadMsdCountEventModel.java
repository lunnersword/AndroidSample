
package com.meidalife.shz.event.type;

/**
 * Created by zuozheng on 14-10-31.
 */
public class ModifyUnReadMsdCountEventModel {

    public MsgTypeEnum type;
    public int msgCount;
}
