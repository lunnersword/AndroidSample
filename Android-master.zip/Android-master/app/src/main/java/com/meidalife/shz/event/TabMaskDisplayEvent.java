package com.meidalife.shz.event;

import com.meidalife.shz.event.type.TabMaskDisplayEventModel;

/**
 * Created by zuozheng on 14-10-31.
 */
public interface TabMaskDisplayEvent {

    public void onEvent(TabMaskDisplayEventModel model);
}
