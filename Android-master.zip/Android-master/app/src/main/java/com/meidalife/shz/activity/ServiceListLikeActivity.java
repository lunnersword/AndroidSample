package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.meidalife.shz.Helper;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestService;
import com.meidalife.shz.util.ShareActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;


/**
 * @deprecated
 */
public class ServiceListLikeActivity extends BaseActivity {

    static public final int PAGE_SIZE = 20;

    public ShareActivity shareActivity;

    String selectedTabIndex;
    ArrayList<ServiceItem> serviceItems;
    int page;
    Boolean loading;
    Boolean complete;
    Boolean isRefresh;
    ServicesAdapter adapter;

    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.listView)
    ListView listView;
    @Bind(R.id.listViewSwipe)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.likeListEmptyDataCell)
    RelativeLayout cellLikeEmpty;
    @Bind(R.id.likeListEmptyIcon)
    TextView emptyLikeIcon;
    @Bind(R.id.likeListEmptyText)
    TextView emptyLikeText;
    View listFooter;
    TextView footerMessage;
    ProgressBar footerLoading;
    Button footerReload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_list_like);
        ButterKnife.bind(this);

        initActionBar(R.string.title_activity_service_list_like, true);

        listFooter = getLayoutInflater().inflate(R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);
        listView.addFooterView(listFooter);
        listFooter.setVisibility(View.GONE);
        emptyLikeIcon.setTypeface(Helper.sharedHelper().getIconFont());

        serviceItems = new ArrayList<ServiceItem>();
        loading = false;
        complete = false;
        isRefresh = false;
        page = 0;

        initAdapter();
        initListView();

        shareActivity = new ShareActivity(this);

        loadData();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void loadData() {
        mSwipeRefreshLayout.setVisibility(View.GONE);
        cellLikeEmpty.setVisibility(View.GONE);
        showStatusLoading(rootView);
        hideStatusErrorServer();
        hideStatusErrorNetwork();
        xhrServices();
    }

    private void initAdapter() {
        adapter = new ServicesAdapter(this, serviceItems);
        listView.setAdapter(adapter);
    }

    private void initListView() {
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                handleRefresh();
            }
        });
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {

            private boolean moveToBottom = false;
            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (previous < firstVisibleItem) {
                    moveToBottom = true;
                } else if (previous > firstVisibleItem) {
                    moveToBottom = false;
                }
                previous = firstVisibleItem;

                if (totalItemCount == firstVisibleItem + visibleItemCount && moveToBottom) {
                    /* 需要加载更多数据的代码 */
                    loadNext();
                }
            }
        });
    }

    private JSONObject getParams(int page) {
        JSONObject params;
        try {
            params = new JSONObject();
            params.put("userId", Helper.sharedHelper().getUserId());
            params.put("pageSize", PAGE_SIZE);
            params.put("offset", page * PAGE_SIZE);
        } catch (JSONException e) {
            params = null;
        }

        return params;
    }

    private void xhrServices() {
        Log.i("Taber", "xhr services");
        MeidaRestClient.RestCallback callback = new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                loading = false;
                hideStatusLoading();
                listFooter.setVisibility(View.GONE);

                ArrayList<ServiceItem> items = (ArrayList<ServiceItem>) result;
                if (items.size() < PAGE_SIZE) {
                    complete = true;
                }
                if (isRefresh) {
                    isRefresh = false;
                    serviceItems.clear();
                    mSwipeRefreshLayout.setRefreshing(false);
                }
                serviceItems.addAll(items);
                adapter.notifyDataSetChanged();

                // 空数据
                if (serviceItems.size() == 0) {
                    cellLikeEmpty.setVisibility(View.VISIBLE);
                    emptyLikeText.setText(getString(R.string.profile_empty_like_myself));
                } else {
                    mSwipeRefreshLayout.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(HttpError error) {
                loading = false;
                hideStatusLoading();
                listFooter.setVisibility(View.GONE);

                // refresh
                if (page == 0) {
                    mSwipeRefreshLayout.setRefreshing(false);

                    if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        showStatusErrorNetwork(rootView);
                        setOnClickErrorNetwork(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadData();
                            }
                        });
                        return;
                    }

                    showStatusErrorServer(rootView);
                    setTextErrorServer(error != null ? error.getMessage() : getResources().getString(R.string.error_server_500));
                    setOnClickErrorServer(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            loadData();
                        }
                    });
                }
                // load next
                else {
                    page--;
                    if (error != null) {
                        if (HttpError.ERR_CODE_NETWORK_CODE == error.getCode()) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);
                    footerReload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            footerLoading.setVisibility(View.VISIBLE);
                            footerReload.setVisibility(View.GONE);
                            loadNext();
                        }
                    });
                }
            }
        };

        if (loading) {
            return;
        }

        listFooter.setVisibility(View.VISIBLE);
        loading = true;

        RequestService.getMyLikeList(getParams(page), callback);
    }

    private void handleRefresh() {
        isRefresh = true;
        page = 0;
        Log.i("Taber", "refresh profile");
        xhrServices();
    }

    private void loadNext() {
        if (!loading && !complete) {
            page++;
            Log.i("Taber", "load next profile");
            xhrServices();
        }
    }
}
