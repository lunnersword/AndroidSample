package com.meidalife.shz.event;

import com.meidalife.shz.event.type.MsgTypeEnum;

/**
 * Created by fufeng on 15/12/27.
 */
public class SquareRefreshEvent extends BaseEvent {
    public SquareRefreshEvent() {
        super(MsgTypeEnum.TYPE_REFRESH);
    }

    public String squareId;
    public Boolean isGezhu;
    public Boolean isJoined;
    public Boolean showLoading = true;
}
