package com.meidalife.shz.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;

import com.alibaba.fastjson.JSON;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.ServicesAdapter;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.model.SquareDO;
import com.meidalife.shz.rest.request.RequestSearch;
import com.meidalife.shz.util.LoadUtilV2;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by fufeng on 16/1/6.
 */
public class SearchServiceResultFragment extends BaseFragment implements SwipeRefreshLayout.OnRefreshListener {
    public static final String SEARCH_ARG_KEYWORD = "keyword";
    public static final String SEARCH_ARG_TYPE = "type";

    private static final String TYPE_ALL = "1";
    private static final String TYPE_NEAR = "2";
    private static final String TYPE_HOT = "3";
    private static final String TYPE_LATEST = "4";
    private static final String TYPE_MCOIN = "5";

    protected boolean isVisible;

    private int page = 0;
    private String keyword;
    private String type;
    private boolean isLoading = false;
    private boolean hasLoadOnce = false;
    private ArrayList<ServiceItem> items = new ArrayList<>();
    private List<SquareDO> squareDOs = new ArrayList<>();
    View rootView;
    View footView;
    @Bind(R.id.rootLayout)
    ViewGroup rootLayout;
    @Bind(R.id.searchResultList)
    ListView searchResultList;
    @Bind(R.id.searchEmptyLayout)
    ViewGroup searchEmptyLayout;
    @Bind(R.id.mSwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;

    ServicesAdapter serviceAdapter;
    SearchCompleteListener searchCompleteListener;
    private LoadUtilV2 helperV2;

    public static SearchServiceResultFragment newInstance(Bundle args) {
        SearchServiceResultFragment fragment = new SearchServiceResultFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public void setSearchActionListener(SearchCompleteListener searchCompleteListener) {
        this.searchCompleteListener = searchCompleteListener;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (null == rootView) {
            rootView = inflater.inflate(R.layout.fragment_search_result, container, false);
            ButterKnife.bind(this, rootView);

            helperV2 = new LoadUtilV2(inflater);

            footView = inflater.inflate(R.layout.fragment_comment_foot, searchResultList, false);
            searchResultList.addFooterView(footView);
            searchResultList.setEmptyView(searchEmptyLayout);
            serviceAdapter = new ServicesAdapter(getActivity(), items);
            searchResultList.setAdapter(serviceAdapter);
            searchResultList.setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                        if (view.getLastVisiblePosition() == view.getCount() - 1) {
                            footView.setVisibility(View.VISIBLE);
                            searchService(false);
                        }
                    }

                    final View topChildView = view.getChildAt(0);
                    if (scrollState == SCROLL_STATE_IDLE && view.getFirstVisiblePosition() == 0
                            && topChildView != null && topChildView.getTop() == 0) {
                        mSwipeRefreshLayout.setEnabled(true);
                        searchCompleteListener.onScrollToTop(true);
                    } else {
                        searchCompleteListener.onScrollToTop(false);
                        mSwipeRefreshLayout.setEnabled(false);
                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                }
            });
            mSwipeRefreshLayout.setOnRefreshListener(this);
        }
        if (isVisible && !hasLoadOnce) {
            searchService(true);
        }
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        // 缓存的rootView需要判断是否已经被加过parent，如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
        try {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null) {
                parent.removeView(rootView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroyView();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (getUserVisibleHint()) {
            isVisible = true;
            if (null != rootView && !hasLoadOnce) {
                searchService(true);
            }
        } else {
            isVisible = false;
        }
    }

    public List<SquareDO> getSquareListData() {
        return squareDOs;
    }

    private void searchService(final boolean reload) {
        if (isLoading) {
            return;
        }
        if (reload) {
            page = 0;
            helperV2.loadPre(rootLayout, mSwipeRefreshLayout);
        }
        type = getArguments().getString(SEARCH_ARG_TYPE);
        keyword = getArguments().getString(SEARCH_ARG_KEYWORD);

        String[] params = preParams();

        RequestSearch.search(params[0], params[1], params[2], type, page, new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                if (null == getActivity() || getActivity().isFinishing()) {
                    return;
                }
                if (reload) {
                    items.clear();
                }
                helperV2.loadSuccess(mSwipeRefreshLayout);
                JSONObject json = (JSONObject) result;
                try {
                    Object dataObj = json.get("data");
                    String itemList = null;
                    String squareList = null;
                    if (dataObj instanceof JSONObject) {
                        JSONObject data = (JSONObject) dataObj;
                        // 正常数据
                        itemList = data.getString("itemList");
                        squareList = data.getString("geziList");
                    } else {
                        itemList = dataObj.toString();
                    }

                    List<ServiceItem> newData = JSON.parseArray(itemList, ServiceItem.class);
                    footView.setVisibility(View.GONE);
                    items.addAll(newData);
                    serviceAdapter.setData(items);
                    serviceAdapter.notifyDataSetChanged();

                    if (!TextUtils.isEmpty(squareList)) {
                        squareDOs = JSON.parseArray(squareList, SquareDO.class);
                        if (null != squareDOs && !squareDOs.isEmpty()) {
                            searchCompleteListener.onUpdateSquareList(squareDOs);
                        }
                    }
                    page++;
                    hasLoadOnce = true;
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(HttpError error) {
                footView.setVisibility(View.GONE);
                helperV2.loadFail(error, rootLayout, new LoadUtilV2.RetryCallback() {
                    @Override
                    public void retry() {
                        searchService(true);
                    }
                });
            }
        });
    }

    private String[] preParams() {
        String[] qs = new String[3];
        if (TYPE_ALL.equals(type)) {
            qs[0] = "default:'" + keyword + "'";
            qs[1] = null;
            qs[2] = null;

        } else if (TYPE_NEAR.equals(type)) {
            qs[0] = "default:'" + keyword + "' AND city_code:'" + SHZApplication.getInstance().getLocationManager().getLocation().getCityCode() + "'";
            qs[1] = "+distance(poi_longitude,poi_latitude,\"" + SHZApplication.getInstance().getLocationManager().getLocation().getLongitude() + "\",\"" +
                    SHZApplication.getInstance().getLocationManager().getLocation().getLatitude() + "\");update_time";
            qs[2] = null;
        } else if (TYPE_HOT.equals(type)) {
            qs[0] = "default:'" + keyword + "'";
            qs[1] = "hot_score";
            qs[2] = null;
        } else if (TYPE_LATEST.equals(type)) {
            qs[0] = "default:'" + keyword + "'";
            qs[1] = "update_time";
            qs[2] = null;
        } else if (TYPE_MCOIN.equals(type)) {
            qs[0] = "default:'" + keyword + "' AND city_code:'" + SHZApplication.getInstance().getLocationManager().getLocation().getCityCode() + "'";
            qs[1] = null;
            qs[2] = "point_support=1";
        }
        return qs;
    }

    @Override
    public void onRefresh() {
        mSwipeRefreshLayout.setRefreshing(false);
        searchService(true);
    }

    public interface SearchCompleteListener {
        void onUpdateSquareList(List<SquareDO> squareDOs);

        void onScrollToTop(boolean top);
    }
}
