package com.meidalife.shz.activity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.PublishGridAdapter;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestOpus;
import com.meidalife.shz.rest.request.RequestSign;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.view.MyGridView;
import com.usepropeller.routable.Router;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class OpusPublishActivity extends BaseActivity {

    ArrayList images;
    PublishGridAdapter adapter;
    String itemId;

    HashMap uploadImages = new HashMap();
    boolean uploadComplete = false;
    boolean submit = false;
    boolean uploading = false;

    boolean isFromProfile = false;

    @Bind(R.id.imageAvatar)
    SimpleDraweeView imageAvatar;
    @Bind(R.id.textDescription)
    EditText textDescription;
    @Bind(R.id.gridViewImages)
    MyGridView gridViewImages;
    @Bind(R.id.textRelativeService)
    TextView textRelativeService;
    @Bind(R.id.iconRight)
    TextView iconRight;
    @Bind(R.id.buttonPublish)
    Button buttonPublish;
    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.action_bar_button_right)
    Button publishActionBarButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opus_publish);
        initActionBar(R.string.title_activity_opus_publish, true, true);

        ButterKnife.bind(this);

        hideIMM();

        Intent intent = getIntent();
        if (intent != null) {
            Bundle bundle = intent.getExtras();
            if (bundle != null)
                isFromProfile = bundle.getBoolean("isFromProfile");
        }

        iconRight.setTypeface(Helper.sharedHelper().getIconFont());

        // set avatar //todo set default avatar
        String avatarUrl = Helper.sharedHelper().getStringUserInfo(Constant.USER_AVATAR);
        if (TextUtils.isEmpty(avatarUrl)) {
            String userId = Helper.sharedHelper().getStringUserInfo(Constant.USER_ID);
            String gender = Helper.sharedHelper().getStringUserInfo(Constant.USER_GENDER);
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(OpusPublishActivity.this, userId, gender);
            imageAvatar.setImageURI(getDefaultAvatarUri);
        } else {
            Uri avatarUri = Uri.parse(ImgUtil.getCDNUrlWithWidth(avatarUrl, imageAvatar.getLayoutParams().width));
            imageAvatar.setImageURI(avatarUri);
        }

        // set images
        Bundle extrasIntent = getIntent().getExtras();

        if (extrasIntent != null) {
            images = extrasIntent.getStringArrayList("images");
        }

        if (images == null) {
            images = new ArrayList();
        } else {
            uploadImages();
        }

        adapter = new PublishGridAdapter(this, images, Constant.MAX_IMAGE_LENGTH, PublishGridAdapter.TYPE_OTHER);
        gridViewImages.setAdapter(adapter);
        adapter.setOnClickPlusListener(new PublishGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                Bundle bundle = new Bundle();
                bundle.putBoolean("isCheckbox", true);
                bundle.putInt("maxLength", Constant.MAX_IMAGE_LENGTH - images.size());
                Router.sharedRouter().openFormResult("pick/photo", bundle,
                        Constant.REQUEST_CODE_PICK_PHOTO, OpusPublishActivity.this);
            }
        });
        adapter.setOnClickRemoveListener(new PublishGridAdapter.OnClickListener() {
            @Override
            public void onClick(View v, int position) {
                if (position < images.size()) {
                    images.remove(position);
                    adapter.notifyDataSetChanged();
                }
            }
        });
        gridViewImages.setOnItemClickListener(adapter);

        textDescription.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Bundle bundle;
        switch (requestCode) {
            case Constant.REQUEST_CODE_PICK_PHOTO:
                if (resultCode == RESULT_OK) {
                    bundle = data.getExtras();
                    ArrayList paths = bundle.getStringArrayList("images");
                    for (int i = 0; i < paths.size(); i++) {
                        // 如果图片列表中没有当前选中的照片，则添加到图片列表中
                        if (images.indexOf(paths.get(i)) == -1) {
                            images.add(paths.get(i));
                        }
                    }
                    adapter.notifyDataSetChanged();
                    uploading = false;
                    uploadComplete = false;
                    uploadImages();
                }
                break;
            case Constant.REQUEST_CODE_PICK_SERVICE:
                if (resultCode == RESULT_OK) {
                    bundle = data.getExtras();
                    itemId = bundle.getString("itemId");
                    textRelativeService.setText(this.getResources().getString(R.string.label_i_can) + " " + bundle.getString("tag"));
                }
                break;
            default:
        }
    }

    public void handleSelectService(View view) {
        if (itemId != null) {
            Bundle bundle = new Bundle();
            bundle.putString("itemId", itemId);
            Router.sharedRouter().openFormResult("pick/service", bundle,
                    Constant.REQUEST_CODE_PICK_SERVICE, this);
        } else {
            Router.sharedRouter().openFormResult("pick/service",
                    Constant.REQUEST_CODE_PICK_SERVICE, this);
        }
    }

    @OnClick(R.id.action_bar_button_right)
    public void handlePublish(View view) {
        if (images.size() == 0) {
            MessageUtils.showToastCenter("还未选择图片哦");
            return;
        }

        if (!submit) {
            submit = true;
            showProgressDialog("正在发布", false);

            if (uploadComplete) {
                xhrPublish();
            } else {
                uploadImages();
            }
        }
    }

    private void xhrPublish() {
        JSONObject params = new JSONObject();

        try {
            if (itemId != null) {
                params.put("itemId", itemId);
            }
            if (textDescription.getText() != null) {
                params.put("description", textDescription.getText());
            }
            params.put("images", getUploadImagesUrl());

            RequestOpus.addOpus(params, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    hideProgressDialog();
                    submit = false;
                    setResult(RESULT_OK);
                    finish();
                    if (!isFromProfile) {
                        Router.sharedRouter().open("profile/" + Helper.sharedHelper().getUserId());
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    hideProgressDialog();
                    submit = false;
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败，请重试");
                }
            });
        } catch (JSONException e) {

        }
    }

    private JSONArray getUploadImagesUrl() {
        JSONArray data = new JSONArray();
        for (int i = 0; i < images.size(); i++) {
            if (uploadImages.containsKey(images.get(i))) {
                data.put(uploadImages.get(images.get(i)));
            }
        }
        return data;
    }

    private void uploadImages() {
        if (!uploading) {
            uploading = true;

            ArrayList uploadQueue = new ArrayList();
            for (int i = 0; i < images.size(); i++) {
                // 如果图片列表中没有当前选中的照片，则添加到图片列表中
                if (!uploadImages.containsKey(images.get(i))) {
                    uploadQueue.add(images.get(i));
                }
            }

            xhrUpdateImages(uploadQueue, 0);
        }
    }

    private void xhrUpdateImages(final ArrayList paths, final int index) {
        if (paths.size() > 0) {
            final String path = (String) paths.get(index);
            RequestSign.upload(path, new MeidaRestClient.RestCallback() {
                @Override
                public void onSuccess(Object result) {
                    JSONObject json = (JSONObject) result;
                    try {
                        uploadImages.put(path, json.getString("data"));
                        if (index == paths.size() - 1) {
                            uploadComplete = true;
                            if (submit) {
                                xhrPublish();
                            }
                        } else {
                            uploadComplete = false;
                            xhrUpdateImages(paths, index + 1);
                        }
                    } catch (JSONException e) {
                        uploading = false;
                        uploadComplete = false;
                        hideProgressDialog();
                        MessageUtils.showToastCenter(e.getMessage());
                    }
                }

                @Override
                public void onFailure(HttpError error) {
                    uploading = false;
                    uploadComplete = false;
                    submit = false;
                    hideProgressDialog();
                    MessageUtils.showToastCenter(error != null ? error.getMessage() : "发布失败");
                }
            });
        } else {
            uploadComplete = true;
            if (submit) {
                xhrPublish();
            }
        }
    }
}
