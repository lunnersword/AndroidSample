package com.meidalife.shz.event;

import android.view.View;

/**
 * Created by xingchen on 2015/12/27.
 */
public interface SquareHandlerPinEvent {

    void handlerPin(View v,int position);

}
