package com.meidalife.shz.activity;

public interface DelAttentionListener {
    public void onDelClick(String id, int position);
}