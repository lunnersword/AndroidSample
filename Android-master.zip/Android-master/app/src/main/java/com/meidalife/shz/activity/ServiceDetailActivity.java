package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CommentAdapter;
import com.meidalife.shz.analysis.LogParam;
import com.meidalife.shz.analysis.LogUtil;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.CommentDO;
import com.meidalife.shz.rest.model.ServiceDO;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestCommentOpr;
import com.meidalife.shz.rest.request.RequestItem;
import com.meidalife.shz.rest.request.RequestService;
import com.meidalife.shz.util.ImgUtil;
import com.meidalife.shz.util.ShareActivity;
import com.meidalife.shz.util.StrUtil;
import com.meidalife.shz.widget.SocialSharePopupWindow;
import com.usepropeller.routable.Router;
import com.viewpagerindicator.CirclePageIndicator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * 详情页展示
 */
public class ServiceDetailActivity extends BaseActivity implements AbsListView.OnScrollListener {

    public ShareActivity shareActivity;

    private LayoutInflater inflater;
    private Context context;

    private ViewGroup contentRoot;

    private Long itemId;
    private ServiceDO serviceItem;

    ImageView userPic;
    TextView sexIcon;
    TextView realNameAuthStatus;
    TextView zmLevel;
    TextView skillAuth;
    private ListView commentsView;
    private ViewGroup noCommentsView;
    private ProgressBar footPb;
    private CommentAdapter commentAdapter;
    private View inputViewGroup;

    private LinearLayout avatarGroup;
    private TextView sellCountText;
    private TextView evaluationCountText;
    private View detailFoot;
    private TextView likeSize;
    private View detail_skill_group;
    private ViewGroup servicePriceLayout;

    private TextView report;
    private ViewGroup earnestLayout;
    private TextView earnestValue;
    private TextView earnestPayLink;
    private TextView finalPayAmount;
    private ViewGroup earnestDetailLayout;
    private TextView earnestPrice;
    private TextView earnestOriPrice;
    private TextView finalPayTime;
    private TextView earnestPayButton;

    private SocialSharePopupWindow socialSharePopupWindow;

    private boolean isMoreData = true;
    private boolean isLoading = false;
    private int previous;
    private int page = 0;
    private int pageSize = 10;

    private TextView commentSize;   // 处理新增评论更新数量
    private int commentCount = 0;
    private CommentItemListener commentItemListener;

    private Integer likeMaxSize = 7;
    int likeCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_detail);

        //初始化action bar
        initActionBar(R.string.service_detail_title, true, true);
        mButtonRight.setText(R.string.icon_share);
        mButtonRight.setTypeface(Helper.sharedHelper().getIconFont());
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (serviceItem != null) {
                    showOrHideShareList(v);
                    LogParam param = new LogParam();
                    param.setType(LogUtil.TYPE_CUSTOMIZE);
                    param.setEid(LogUtil.EVENT_ID_SHARE_CLICK);
                    param.setPvid(serviceItem.getPvid());
                    LogUtil.log(param);
                }
            }
        });

        Bundle extras = getIntent().getExtras();
        itemId = Long.parseLong(extras.getString("id"));

        context = this;
        shareActivity = new ShareActivity(this);

        initView();
        initLoadData();
    }

    @Override
    public void onBackPressed() {
        if (inputViewGroup.getVisibility() == View.VISIBLE) {
            inputViewGroup.setVisibility(View.GONE);
            detailFoot.setVisibility(View.VISIBLE);
            return;
        }
        super.onBackPressed();
    }

    void initView() {
        inflater = getLayoutInflater();
        contentRoot = (ViewGroup) findViewById(R.id.service_detail_content_root_view);
        earnestPayButton = (TextView) findViewById(R.id.earnestPayButton);
        //main view
        View mainView = inflater.inflate(R.layout.activity_service_detail_main, null);

        //用户信息
        ViewGroup authGroup = (ViewGroup) mainView.findViewById(R.id.detail_auth_group);
        authGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (serviceItem != null)
                    Router.sharedRouter().open("profile/" + serviceItem.getUserId());
            }
        });

        //头像
        userPic = (ImageView) mainView.findViewById(R.id.detail_user_pic);
        //性别
        sexIcon = (TextView) mainView.findViewById(R.id.detail_sex_icon);
        //实名认证状态
        realNameAuthStatus = (TextView) mainView.findViewById(R.id.detail_real_name_auth_status);
        //芝麻信用分数
        zmLevel = (TextView) mainView.findViewById(R.id.detail_zm_level);
        //个人认证
        skillAuth = (TextView) mainView.findViewById(R.id.detail_skill_tv);
        detail_skill_group = mainView.findViewById(R.id.detail_skill_group);

        report = (TextView) mainView.findViewById(R.id.report);

        report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reportService();
            }
        });
        //销量 部分(跳转到评价部分)
        ViewGroup sellCountGroup = (ViewGroup) mainView.findViewById(R.id.sellCountGroup);
        sellCountGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (serviceItem.getSellCount() > 0) {
                    Bundle params = new Bundle();
                    params.putLong("itemId", itemId);
                    Router.sharedRouter().open("tradeAndCommentList", params);
                }
            }
        });
        //评价 部分
        ViewGroup evaluationCountGroup = (ViewGroup) mainView.findViewById(R.id.evaluationCountGroup);
        evaluationCountGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (serviceItem.getEvaluationCount() > 0) {
                    Bundle params = new Bundle();
                    params.putLong("itemId", itemId);
                    Router.sharedRouter().open("tradeAndCommentList", params);
                }
            }
        });

        sellCountText = (TextView) mainView.findViewById(R.id.sellCountText);
        evaluationCountText = (TextView) mainView.findViewById(R.id.evaluationCountText);

        //未评价view
        noCommentsView = (ViewGroup) mainView.findViewById(R.id.noCommentsView);

        //服务价格布局,预定商品隐藏
        servicePriceLayout = (ViewGroup) mainView.findViewById(R.id.servicePriceLayout);
        //定金价格
        earnestLayout = (ViewGroup) mainView.findViewById(R.id.earnestLayout);
        earnestValue = (TextView) mainView.findViewById(R.id.earnestValue);
        earnestPayLink = (TextView) mainView.findViewById(R.id.earnestPayLink);
        finalPayAmount = (TextView) mainView.findViewById(R.id.finalPayAmount);

        earnestDetailLayout = (ViewGroup) mainView.findViewById(R.id.earnestDetailLayout);
        earnestPrice = (TextView) mainView.findViewById(R.id.earnestPrice);
        earnestOriPrice = (TextView) mainView.findViewById(R.id.earnestOriPrice);

        finalPayTime = (TextView) mainView.findViewById(R.id.finalPayTime);

        View foot = inflater.inflate(R.layout.fragment_comment_foot, null);
        footPb = (ProgressBar) foot.findViewById(R.id.detail_comment_foot_pb);

        // 评论
        detailFoot = findViewById(R.id.service_detail_foot);
        inputViewGroup = findViewById(R.id.detail_comment_input_group);
        EditText inputText = (EditText) findViewById(R.id.comment_input_text);
        TextView inputCommit = (TextView) findViewById(R.id.comment_input_commit);
        commentItemListener = new CommentItemListener(inputText, inputViewGroup, detailFoot);
        inputCommit.setOnClickListener(commentItemListener);

        commentsView = (ListView) findViewById(R.id.detail_comment_list);
        commentsView.addHeaderView(mainView);
        commentsView.addFooterView(foot);
        commentsView.setOnItemClickListener(commentItemListener);

        commentsView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final CommentAdapter.PJViewHolder curr = (CommentAdapter.PJViewHolder) view.getTag();

                if (null != curr) {
                    View contextMenu = LayoutInflater.from(ServiceDetailActivity.this).inflate(R.layout.message_delete_dialog, null);
                    final AlertDialog dialog = new AlertDialog.Builder(ServiceDetailActivity.this).create();
                    dialog.setView(contextMenu, 0, 0, 0, 0);
                    dialog.show();
                    TextView deleteTv = (TextView) contextMenu.findViewById(R.id.singleContextMenu);
                    deleteTv.setText(R.string.report);
                    deleteTv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent();
                            intent.setClass(ServiceDetailActivity.this, ReportActivity.class);
                            intent.putExtra("targetId", String.valueOf(curr.commentId));
                            intent.putExtra("target", Constant.REPORT_TYPE_SERVICE_LEAVE_MESSAGE);
                            startActivity(intent);
                        }
                    });

                    return true;
                }
                return false;
            }
        });

        mainView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                commentItemListener.hideKeyword();
            }
        });
    }

    public void initLoadData() {
        showStatusLoading(contentRoot);
        RequestItem.get(itemId.toString(), null, new HttpClient.HttpCallback<ServiceDO>() {
            @Override
            public void onSuccess(ServiceDO result) {
                hideStatusLoading();
                hideStatusErrorNetwork();
                hideStatusErrorServer();
                detailFoot.setVisibility(View.VISIBLE);
                renderItem(result);
                loadComments();
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(ServiceDetailActivity.class.getName(), "req item data fail, itemId=" +
                        itemId + ", " + error.toString());
                detailFoot.setVisibility(View.GONE);
                hideStatusLoading();
                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(contentRoot, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initLoadData();
                        }
                    });
                    return;
                }
                showStatusErrorServer(contentRoot, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        initLoadData();
                    }
                });
                setTextErrorServer(error.toString());
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }


    public void renderItem(final ServiceDO item) {
        serviceItem = item;

        setActionBarTitle(item.getUserName());

        if (TextUtils.isEmpty(item.getUserAvatar())) {
            Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(this, String.valueOf(item.getUserId()), item.getUserGender());
            userPic.setImageURI(getDefaultAvatarUri);
        } else {
            Uri uri = Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getUserAvatar(), userPic.getLayoutParams().width));
            userPic.setImageURI(uri);
        }

        if (item.getUserGender() == null) {
            sexIcon.setVisibility(View.GONE);
        } else {
            if (item.getUserGender().equals("woman") || item.getUserGender().equals("F")) {
                sexIcon.setText(context.getResources().getString(R.string.icon_gender_f));
                sexIcon.setTextColor(getResources().getColor(R.color.brand_b));
            } else {
                sexIcon.setText(context.getResources().getString(R.string.icon_gender_m));
                sexIcon.setTextColor(getResources().getColor(R.color.brand_i));
            }
        }

        //设置用户实名认证状态和技能认证状态
        if (item.getRealNameCert() == 1) {
            realNameAuthStatus.setText("已实名认证");
        } else {
            realNameAuthStatus.setText("未实名认证");
        }

        if (TextUtils.isEmpty(item.getZmLevel())) {
            zmLevel.setText("芝麻信用未绑定");
        } else {
            zmLevel.setText("芝麻信用" + item.getZmLevel());
        }

        List<String> certList = item.getCertList();
        if (certList != null && certList.size() > 0) {
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < certList.size(); i++) {
                if (i == certList.size() - 1) {
                    str.append(certList.get(i));
                } else {
                    str.append(certList.get(i)).append("、");
                }
            }
            skillAuth.setText(str.toString());
        } else {
            detail_skill_group.setVisibility(View.GONE);
        }


        /**
         *中间区域，如：title等
         */
        TextView latestSell = (TextView) findViewById(R.id.detail_latest_sell);
        Long latestOrderTime = item.getLatestOrderTime();
        if (latestOrderTime != null) {
            long offset = System.currentTimeMillis() / 1000 / 60 - latestOrderTime / 60;
            if (offset < 60) {
                latestSell.setText(offset + "分钟前卖出一笔");
            } else if (offset < (60 * 24)) {
                latestSell.setText((offset / 60) + "小时前卖出一笔");
            } else {
                latestSell.setText("一天前卖出一笔");
            }
            latestSell.setVisibility(View.VISIBLE);
        } else {
            latestSell.setVisibility(View.GONE);
        }

        TextView userTag = (TextView) findViewById(R.id.detail_user_tag);
        userTag.setText(getString(R.string.label_i_can) + item.getTag());

        //特大活动标识
        SimpleDraweeView bigPromotionIcon = (SimpleDraweeView) findViewById(R.id.bigPromotionIcon);
        if (!TextUtils.isEmpty(item.getBigPromotionIcon())) {
            bigPromotionIcon.setVisibility(View.VISIBLE);
            bigPromotionIcon.setImageURI(Uri.parse(item.getBigPromotionIcon()));
        }

        TextView promotionTag = (TextView) findViewById(R.id.detail_promotion_tag);
        TextView price = (TextView) findViewById(R.id.detail_price);
        TextView oriPrice = (TextView) findViewById(R.id.detail_origin_price);
        if (TextUtils.isEmpty(item.getPromotionPrice())) {
            price.setText(item.getPrice());
        } else {
            promotionTag.setVisibility(View.VISIBLE);
            price.setText(item.getPromotionPrice());
            oriPrice.setVisibility(View.VISIBLE);
            oriPrice.setText(item.getPrice());
            oriPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
        }

        TextView itemStock = (TextView) findViewById(R.id.itemStock);
        if (item.getPromotionNum() > 0) {
            itemStock.setText("剩余" + item.getPromotionNum() + "单");
        } else {
            itemStock.setVisibility(View.GONE);
        }

        // 评分
        TextView judgeStar = (TextView) findViewById(R.id.detail_judge_star);
        judgeStar.setText(item.getGrade() + "星");
        ViewGroup starGroup = (ViewGroup) findViewById(R.id.detail_judge_star_icon_group);
        View starsView = inflater.inflate(R.layout.activity_service_detail_stars, null);
        View starsRed = starsView.findViewById(R.id.star_red_group);
        starsRed.getLayoutParams().width = (int) ((int) Helper.convertDpToPixel(100, context) * item.getGrade() / 5);
        starGroup.removeAllViews();
        starGroup.addView(starsView);


        TextView content = (TextView) findViewById(R.id.detail_content);
        content.setText(item.getContent());

        int tenDp = (int) Helper.convertDpToPixel(10, context);
        int deviceWidth = content.getResources().getDisplayMetrics().widthPixels;

        LinearLayout picsGroup = (LinearLayout) findViewById(R.id.detail_pics_group);
        picsGroup.removeAllViews();
        for (String imgUrl : item.getImages()) {
            int imgWidth = deviceWidth - (2 * tenDp);
            int imgHeight = imgWidth;
            // 计算图片高度
            String[] arrays = imgUrl.split("/");
            String[] imgWh = arrays[arrays.length - 1].split("_");
            if (imgWh.length == 3) {
                float width = Integer.parseInt(imgWh[0].substring(0, imgWh[0].length() - 1));
                float height = Integer.parseInt(imgWh[1].substring(0, imgWh[1].length() - 1));
                imgHeight = (int) ((height * imgWidth) / width);
                if (imgHeight > 4096) {
                    imgHeight = 4096;
                    imgWidth = (int) ((width / height) * 4096);
                }
            }
            // 显示图片
            SimpleDraweeView imgView = (SimpleDraweeView) inflater.inflate(R.layout.activity_service_detail_pics_item, null);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(imgWidth, imgHeight);
            layoutParams.setMargins(0, tenDp, 0, 0);
            imgView.setLayoutParams(layoutParams);
            imgUrl = ImgUtil.getCDNUrlWithWidth(imgUrl, imgWidth);
            imgView.setImageURI(Uri.parse(imgUrl));
            picsGroup.addView(imgView);
        }

        /*售出数目&评论数量*/
        sellCountText.setText(serviceItem.getSellCount() > 0 ?
                String.format(getString(R.string.sell_count), serviceItem.getSellCount()) : getString(R.string.sell_count_none));
        evaluationCountText.setText(item.getEvaluationCount() > 0 ?
                String.format(getString(R.string.comment_count), item.getEvaluationCount()) : getString(R.string.comment_count_none));

        /*
        底部区域，如：上门、评分等
         */

        TextView typeIcon = (TextView) findViewById(R.id.detail_service_type_icon);
        TextView serviceType = (TextView) findViewById(R.id.detail_service_type);
        String serviceTypeValue = "";
        switch (item.getServiceType()) {
            case 1:
                typeIcon.setBackgroundResource(R.mipmap.publish_type_1_active);
                serviceTypeValue = item.getCityName() + "上门";
                break;
            case 2:
                typeIcon.setBackgroundResource(R.mipmap.publish_type_2_active);
                serviceTypeValue = item.getCityName() + "到店";
                break;
            case 3:
                typeIcon.setBackgroundResource(R.mipmap.publish_type_3_active);
                serviceTypeValue = "线上";
                break;
            case 4:
                ((TextView) findViewById(R.id.detail_buy_bt)).setText("立即购买");
                typeIcon.setBackgroundResource(R.mipmap.publish_type_4_active);
                //根据设置分为 现货邮寄、现做邮寄
                if (item.getIsSpot() == 1) {
                    serviceTypeValue = "邮寄(现做)";
                } else {
                    serviceTypeValue = "邮寄(定制)";
                }
                break;
        }
        serviceType.setText(serviceTypeValue);

        View locationGroup = findViewById(R.id.detail_location_group);
        TextView location = (TextView) findViewById(R.id.detail_location);
        if (item.getDistance() == null) {
            locationGroup.setVisibility(View.GONE);
        } else {
            locationGroup.setVisibility(View.VISIBLE);
            location.setText("相距" + item.getDistance());
        }

        setServiceDate(item);

        View canMcoinGroup = findViewById(R.id.detail_can_mcoin_group);
        if (item.getPointSupport() != null && item.getPointSupport() == 1) {
            TextView canMcoin = (TextView) findViewById(R.id.detail_can_mcoin);
            canMcoin.setText("可用M豆");
        } else {
            canMcoinGroup.setVisibility(View.GONE);
        }

        View redPackSupportLayout = findViewById(R.id.redPackSupportLayout);
        if (item.getRedpackSupport()) {
            TextView canredcoin = (TextView) findViewById(R.id.redPackSupport);
            canredcoin.setText("可用红包");
        } else {
            redPackSupportLayout.setVisibility(View.GONE);
        }
        // 服务地址，仅到店显示
        View addressGroup = findViewById(R.id.detail_address_group);
        TextView detailAddressValue = (TextView) findViewById(R.id.detail_address_value);
        if (item.getAddressName() == null) {
            addressGroup.setVisibility(View.GONE);
        } else {
            addressGroup.setVisibility(View.VISIBLE);
            detailAddressValue.setText(item.getAddressName());
        }

        //格子
        View squareGroup = findViewById(R.id.detail_square_group);
        SimpleDraweeView squareImg = (SimpleDraweeView) findViewById(R.id.detail_square_pic);
        TextView detailSquareValue = (TextView) findViewById(R.id.detail_square_name);

        if (item.getNearestGezi() == null) {
            squareGroup.setVisibility(View.GONE);
        } else {
            squareGroup.setVisibility(View.VISIBLE);
            squareGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("squareindex/" + item.getNearestGezi().getGeziId());
                }
            });

            detailSquareValue.setText("该服务来自 " + item.getNearestGezi().getGeziName());

            squareImg.setImageURI(Uri.parse(ImgUtil.getCDNUrlWithWidth(item.getNearestGezi().getGeziPicUrl(), squareImg.getLayoutParams().width)));
        }


        // 喜欢
        avatarGroup = (LinearLayout) findViewById(R.id.like_user_avatar_group);
        View likeRight = findViewById(R.id.detail_like_right);
        likeCount = item.getLikeCount();
        likeSize = (TextView) findViewById(R.id.detail_like_size);
        if (likeCount > 0) {
            likeSize.setText("收藏（" + likeCount + "）");
            showLikeAvatar(item.getLikeUsers());
            likeRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("like_list/" + itemId);
                }
            });
        } else {
            likeSize.setText("收藏");
            likeRight.setVisibility(View.INVISIBLE);
        }

        // 留言Label
        commentSize = (TextView) findViewById(R.id.detail_comment_size);
        commentCount = item.getMessageCount();
        commentSize.setText("留言区（" + commentCount + "）");

        // 作品秀
        RelativeLayout opusGroup = (RelativeLayout) findViewById(R.id.detail_opus_group);
        TextView opusCount = (TextView) findViewById(R.id.detail_opus_size);
        if (item.getOpusCount() > 0) {
            opusGroup.setVisibility(View.VISIBLE);
            opusCount.setText("作品秀" + "（" + item.getOpusCount() + "）");
        } else {
            opusCount.setText("作品秀");
            opusGroup.setVisibility(View.GONE);
        }
        opusGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.sharedRouter().open("opusList/" + itemId);
            }
        });

        renderEarnestLayout(item);
        renderFootView(item);
    }

    private void setServiceDate(ServiceDO item) {
        try {
            Calendar nextServiceTime = Calendar.getInstance();
            nextServiceTime.setTimeInMillis(item.getNextServiceTime());
            int serviceDay = nextServiceTime.get(Calendar.DAY_OF_YEAR);

            Calendar current = Calendar.getInstance();
            current.setTime(new Date());
            int currentDay = current.get(Calendar.DAY_OF_YEAR);

            TextView canTime = (TextView) findViewById(R.id.detail_can_time);
            canTime.setText(item.getReadableNextServiceTime() + "起有空");

            if (nextServiceTime.get(Calendar.YEAR) == current.get(Calendar.YEAR)) {
                if (serviceDay == currentDay) {
                    canTime.setText(getString(R.string.today_avilable));
                } else if ((serviceDay - currentDay) == 1) {
                    canTime.setText(getString(R.string.tomorrow_avilable));
                } else if ((serviceDay - currentDay) == 2) {
                    canTime.setText(getString(R.string.the_day_after_tomorrow_avilable));
                }
            } else {
                currentDay -= getMaxYear();
                if ((serviceDay - currentDay) == 1) {
                    canTime.setText(getString(R.string.tomorrow_avilable));
                } else if ((serviceDay - currentDay) == 2) {
                    canTime.setText(getString(R.string.the_day_after_tomorrow_avilable));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int getMaxYear() {
        Calendar cd = Calendar.getInstance();
        cd.set(Calendar.DAY_OF_YEAR, 1);// 把日期设为当年第一天
        cd.roll(Calendar.DAY_OF_YEAR, -1);// 把日期回滚一天。
        int MaxYear = cd.get(Calendar.DAY_OF_YEAR);
        return MaxYear;
    }

    private void renderFootView(final ServiceDO item) {
        //喜欢
        final TextView likeIconView = (TextView) findViewById(R.id.foot_like_icon);
        final TextView isLike = (TextView) findViewById(R.id.isLike);
        LinearLayout likeLayout = (LinearLayout) findViewById(R.id.like_ll);
        if (item.getIsLike() != 0) {
            likeIconView.setText(getResources().getString(R.string.icon_star_active));
            likeIconView.setTextColor(getResources().getColor(R.color.brand_b));
            isLike.setText(getResources().getString(R.string.liked));
        }
        likeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    toggleIsLike(item, likeIconView, isLike);
                } else {
                    jumpToLogin("services/" + itemId);
                    finish();
                }
            }
        });

        /*
        点击评论
         */
        View footPLLayout = findViewById(R.id.pl_ll);
        footPLLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Helper.sharedHelper().hasToken()) {
                    commentItemListener.comment();
                } else {
                    jumpToLogin("services/" + itemId);
                }
            }
        });

        /*
        点击聊一聊
         */
        TextView chatBt = (TextView) findViewById(R.id.detail_chat_bt);

        chatBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //广告商品
                if (!StrUtil.isEmpty(serviceItem.getLink())) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", serviceItem.getLink());
                    Router.sharedRouter().open("web", bundle);
                }
                //进入聊一聊
                else {
                    String action = "chatFormService/";
                    action += serviceItem.getUserId();
                    action += "/";
                    action += itemId;
                    Bundle chatBundle = new Bundle();
                    chatBundle.putString("itemPrice", serviceItem.getPrice());
                    chatBundle.putString("itemTitle", serviceItem.getTag());
                    chatBundle.putString("itemPic", serviceItem.getImages().get(0));
                    chatBundle.putString("receiveAvatar", serviceItem.getUserAvatar());
                    chatBundle.putString("receiveName", serviceItem.getUserName());
                    if (Helper.sharedHelper().hasToken()) {
                        Router.sharedRouter().open(action, chatBundle);

                        LogParam param = new LogParam();
                        param.setType(LogUtil.TYPE_CUSTOMIZE);
                        param.setEid(LogUtil.EVENT_ID_CHAT_CLICK);
                        param.setPvid(serviceItem.getPvid());
                        LogUtil.log(param);
                    } else {
                        Bundle bundle = new Bundle();
                        bundle.putString("action", action);
                        bundle.putBundle("bundle", chatBundle);
                        Router.sharedRouter().open("signin", bundle);
                    }
                }
            }
        });

        // 若是自己，隐藏立即预约和聊一聊
        View buyBt = findViewById(R.id.detail_buy_bt);
        if (item.getEditable() == 1) {
            chatBt.setVisibility(View.INVISIBLE);
            if (TextUtils.isEmpty(item.getEarnest())) {
                buyBt.setVisibility(View.INVISIBLE);
                earnestPayButton.setVisibility(View.GONE);
            } else {
                earnestPayButton.setVisibility(View.INVISIBLE);
                buyBt.setVisibility(View.GONE);
            }
        } else {
            chatBt.setEnabled(true);
            buyBt.setEnabled(true);
            earnestPayButton.setEnabled(true);
            if (!TextUtils.isEmpty(item.getEarnest())) {
                buyBt.setVisibility(View.GONE);
                earnestPayButton.setVisibility(View.VISIBLE);
                earnestPayButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (Helper.sharedHelper().hasToken()) {
                            Router.sharedRouter().open("order/" + itemId);
                        } else {
                            Router.sharedRouter().open("signin");
                        }
                    }
                });
            } else {
                earnestPayButton.setVisibility(View.GONE);
                buyBt.setVisibility(View.VISIBLE);
                buyBt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (Helper.sharedHelper().hasToken()) {
                            Router.sharedRouter().open("order/" + itemId);
                        } else {
                            Router.sharedRouter().open("signin");
                        }
                    }
                });
            }
        }
    }

    private void renderEarnestLayout(ServiceItem item) {
        if (!TextUtils.isEmpty(item.getEarnest())) {
            earnestLayout.setVisibility(View.VISIBLE);
            earnestDetailLayout.setVisibility(View.VISIBLE);
            earnestValue.setText(item.getEarnest());

            if (TextUtils.isEmpty(item.getPromotionPrice())) {
                earnestPrice.setText(String.format(getString(R.string.earnest_price), item.getPrice()));
                earnestOriPrice.setVisibility(View.GONE);
            } else {
                earnestPrice.setText(String.format(getString(R.string.earnest_price), item.getPromotionPrice()));
                earnestOriPrice.setVisibility(View.VISIBLE);
                earnestOriPrice.setText(item.getPrice());
                earnestOriPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);  // 设置中划线并加清晰
            }
            earnestPayLink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("url", serviceItem.getPresellTip());
                    Router.sharedRouter().open("web", bundle);
                }
            });
            finalPayTime.setText(String.format(getString(R.string.final_pay_time), item.getFinalPayTime()));
            finalPayAmount.setText(String.format(getString(R.string.final_pay_amount), item.getFinalPay()));
            servicePriceLayout.setVisibility(View.GONE);
        } else {
            earnestDetailLayout.setVisibility(View.GONE);
            earnestLayout.setVisibility(View.GONE);
            servicePriceLayout.setVisibility(View.VISIBLE);
        }
    }

    private void toggleIsLike(ServiceItem item, TextView icon, TextView text) {

        if (item.getIsLike() == 0) {
            likeReq(item, true, icon, text);
        } else {
            likeReq(item, false, icon, text);
        }
    }


    private void likeReq(final ServiceItem item, Boolean isLike, final TextView icon, final TextView text) {
        try {
            JSONObject params = new JSONObject();
            params.put("itemId", itemId.toString());
            if (isLike) {
                RequestService.addAttention(params, new MeidaRestClient.RestCallback() {
                    @Override
                    public void onSuccess(Object result) {
                        MessageUtils.showToastCenter(getResources().getString(R.string.add_like_success));
                        // 改变样式
                        item.setIsLike(1);
                        item.setLikeCount(item.getLikeCount() + 1);
                        icon.setTextColor(getResources().getColor(R.color.brand_b));
                        icon.setText(getResources().getString(R.string.icon_star_active));
                        text.setText(getResources().getString(R.string.liked));
                        // 喜欢列表
                        likeCount = likeCount + 1;
                        likeSize.setText("收藏（" + likeCount + "）");
                        ServiceItem.ViewUser user = new ServiceItem.ViewUser();
                        user.setUserAvatar(Helper.sharedHelper().getStringUserInfo(Constant.USER_PIC));
                        user.setUserId(Helper.sharedHelper().getStringUserInfo(Constant.USER_ID));
                        ArrayList<ServiceItem.ViewUser> likeList = serviceItem.getLikeUsers();
                        likeList.add(0, user);
                        showLikeAvatar(likeList);
                    }

                    @Override
                    public void onFailure(HttpError error) {
                    }
                });
            } else {
                RequestService.delAttention(params, new MeidaRestClient.RestCallback() {
                    @Override
                    public void onSuccess(Object result) {
                        MessageUtils.showToastCenter(getResources().getString(R.string.cancel_like_success));
                        // 改变样式
                        item.setIsLike(0);
                        item.setLikeCount(item.getLikeCount() - 1);
                        icon.setTextColor(getResources().getColor(R.color.brand_d));
                        icon.setText(getResources().getString(R.string.icon_star_normal));
                        text.setText(getResources().getString(R.string.like));
                        // 喜欢列表
                        likeCount = likeCount - 1;
                        likeSize.setText("收藏（" + likeCount + "）");
                        String userId = Helper.sharedHelper().getStringUserInfo(Constant.USER_ID);
                        ArrayList<ServiceItem.ViewUser> likeList = serviceItem.getLikeUsers();
                        for (int i = 0; i < likeList.size(); i++) {
                            ServiceItem.ViewUser u = likeList.get(i);
                            if (userId.equals(u.getUserId())) {
                                likeList.remove(i);
                                break;
                            }
                        }
                        showLikeAvatar(likeList);
                    }

                    @Override
                    public void onFailure(HttpError error) {
                        MessageUtils.showToastCenter(error.getMessage());
                    }
                });
            }
        } catch (JSONException e) {
        }
    }


    public void showLikeAvatar(List<ServiceItem.ViewUser> datalist) {

        avatarGroup.removeAllViews();

        int end = Math.min(likeMaxSize, datalist.size());
        datalist = datalist.subList(0, end);

        for (int i = 0; i < datalist.size(); i++) {

            final ServiceItem.ViewUser user = datalist.get(i);
            View view = inflater.inflate(R.layout.activity_service_detail_like_avatar, null);
            ImageView avatar = (ImageView) view.findViewById(R.id.user_avatar);
            String avatarUrl = ImgUtil.getCDNUrlWithWidth(user.getUserAvatar(), avatar.getLayoutParams().width);
            if (TextUtils.isEmpty(avatarUrl)) {
                String userId = user.getUserId();
                String gender = user.getGender();
                Uri getDefaultAvatarUri = ImgUtil.getDefaultAvatarUri(ServiceDetailActivity.this, userId, gender);
                avatar.setImageURI(getDefaultAvatarUri);
            } else {
                avatar.setImageURI(Uri.parse(avatarUrl));
            }

            avatarGroup.addView(view);

            avatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Router.sharedRouter().open("profile/" + user.getUserId());
                }
            });
        }
    }


    public void loadComments() {

        HttpClient.get("1.0/comment/getComment", genParams(0), CommentDO.class, new HttpClient.HttpCallback<List<CommentDO>>() {
            @Override
            public void onSuccess(List<CommentDO> dataList) {
                loadSuccess(contentRoot);
                commentAdapter = new CommentAdapter(context, inflater, dataList);   // 为保证head显示，因此无论是否有数据，都设置adapter
                commentsView.setAdapter(commentAdapter);
                if (dataList.size() > 0) {
                    commentsView.setOnScrollListener(ServiceDetailActivity.this);
                    noCommentsView.setVisibility(View.GONE);
                } else {
                    noCommentsView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFail(HttpError error) {
                Log.e(ServiceDetailActivity.class.getName(), "req comment data fail, itemId=" + itemId + ", " + error.toString());

                if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                    showStatusErrorNetwork(contentRoot, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            initLoadData();
                        }
                    });
                    return;
                }
                showStatusErrorServer(contentRoot, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        initLoadData();
                    }
                });
            }
        });
    }

    private void showOrHideShareList(View v) {
        if (socialSharePopupWindow == null) {
            socialSharePopupWindow = new SocialSharePopupWindow(this, serviceItem,
                    shareActivity, SocialSharePopupWindow.SHARE_TYPE_SERVICE);
        }
        if (socialSharePopupWindow.isShowing()) {
            socialSharePopupWindow.dismiss();
        } else {
            socialSharePopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0);
        }
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (!isMoreData) {
            return;
        }
        if (isLoading) { // 若已经在加载中，则忽略
            return;
        }
        boolean moveToBottom = false;
        if (previous <= firstVisibleItem) {
            moveToBottom = true;
        }
        previous = firstVisibleItem;
        if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
            isLoading = true;
            footPb.setVisibility(View.VISIBLE);
            page++;
            HttpClient.get("1.0/comment/getComment", genParams(page), CommentDO.class, new HttpClient.HttpCallback<List<CommentDO>>() {
                @Override
                public void onSuccess(List<CommentDO> dataList) {
                    isLoading = false;
                    if (dataList.size() == 0) {
                        isMoreData = false;
                        footPb.setVisibility(View.GONE);
                    } else {
                        commentAdapter.add(dataList);
                        commentAdapter.notifyDataSetChanged();
                        footPb.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    isLoading = false;
                    MessageUtils.showToastCenter(error.getMessage());
                    page--;
                    footPb.setVisibility(View.GONE);
                }
            });
        }
    }

    public com.alibaba.fastjson.JSONObject genParams(int page) {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", pageSize);
        params.put("offset", page * pageSize);
        params.put("typeList", "2,4");
        return params;
    }


    private void jumpToLogin(String action) {
        Bundle bundle = new Bundle();
        bundle.putString("action", action);
        Router.sharedRouter().open("signin", bundle);
    }

    private void reportService() {
        Intent intent = new Intent();
        intent.setClass(this, ReportActivity.class);
        intent.putExtra("targetId", String.valueOf(itemId));
        intent.putExtra("target", Constant.REPORT_TYPE_SERVICE);
        startActivity(intent);
    }

    /**
     * 服务详情主图区
     */
    public static class MainPicViewer {

        private LayoutInflater inflater;
        private Context context;
        private ViewGroup picsPlacer;

        private int picIndex = 0;   //记录主图翻动位置

        private ViewPager viewPager;
        private ImageView[] imgViews;   //图片imgView
        private List<String> imgList;   //图片资源

        public MainPicViewer(List<String> imgs, LayoutInflater inflater, Context context, ViewGroup picsPlacer) {
            this.imgList = imgs;
            this.inflater = inflater;
            this.context = context;
            this.picsPlacer = picsPlacer;
        }

        public void render() {

            View mutilPicView = inflater.inflate(R.layout.activity_service_detail_main_pics_mutil, null);
            picsPlacer.addView(mutilPicView);
            viewPager = (ViewPager) mutilPicView.findViewById(R.id.detail_main_pics_viewpager);

            //加载图片
            imgViews = new ImageView[imgList.size()];
            for (int i = 0; i < imgViews.length; i++) {
                SimpleDraweeView imageView = new SimpleDraweeView(context);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setTag(i);
                imgViews[i] = imageView;
                String imgUrl = imgList.get(i);
                ImgUtil.load(context, imgUrl, picsPlacer.getLayoutParams(), imageView);
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Bundle bundle = new Bundle();
                        bundle.putStringArrayList("photos", (ArrayList<String>) imgList);
                        int index = (Integer) v.getTag();
                        picIndex = index;
                        bundle.putInt("index", index);
                        Router.sharedRouter().open("imageBrowser", bundle);
                    }
                });
            }

            //设置Adapter
            viewPager.setAdapter(new PagerAdapter() {
                @Override
                public int getCount() {
                    return imgList.size();
                }

                @Override
                public boolean isViewFromObject(View view, Object object) {
                    return view == object;
                }

                @Override
                public Object instantiateItem(View v, int position) {
                    ImageView iv = imgViews[position % imgViews.length];
                    ViewPager vp = (ViewPager) v;
                    if (iv.getParent() == null) {
                        vp.addView(iv, 0);  //http://vocaloid.iteye.com/blog/1814627, The specified child already has a parent. You must call removeView() on the child's parent first.
                    }
                    return iv;
                }

                @Override
                public void destroyItem(View container, int position, Object object) {
                    //((ViewPager)container).removeView(imgViews[position % imgViews.length]);  //测试时发现，若移除，当只有3张图片时会出现空白页
                }
            });

            CirclePageIndicator indicator = (CirclePageIndicator) mutilPicView.findViewById(R.id.detail_main_pics_tip);
            indicator.setViewPager(viewPager);
            viewPager.setCurrentItem(picIndex);
        }

    }

    public class CommentItemListener implements AdapterView.OnItemClickListener, TextView.OnClickListener {

        private CommentAdapter.PJViewHolder pre;
        private InputMethodManager keyboard;

        private EditText inputText;
        private View inputViewGroup;
        private View detailFoot;

        private Handler handler = new Handler();

        public CommentItemListener(EditText inputText, View inputViewGroup, View detailFoot) {
            keyboard = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            this.inputText = inputText;
            this.inputViewGroup = inputViewGroup;
            this.detailFoot = detailFoot;
        }

        @Override
        public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
            if (!Helper.sharedHelper().hasToken()) {
                finish();
                jumpToLogin("services/" + itemId);
                return;
            }

            inputText.setHint(null);

            if (pre == null && (null != view.getTag())) {
                CommentAdapter.PJViewHolder curr = (CommentAdapter.PJViewHolder) view.getTag();
                inputText.setFocusable(true);
                inputText.setFocusableInTouchMode(true);
                inputText.requestFocus();
                String nick = "";
                if (null != curr.buyNick && null != curr.buyNick.getText()) {
                    nick = curr.buyNick.getText().toString();
                }
                inputText.setHint("回复:" + nick);
                keyboard.showSoftInput(inputText, InputMethodManager.SHOW_IMPLICIT);
                pre = curr;
                inputViewGroup.setVisibility(View.VISIBLE);
                detailFoot.setVisibility(View.GONE);
            } else {
                hideKeyword();
            }
        }

        public void onClick(View v) {
            if (!Helper.sharedHelper().hasToken()) {
                finish();
                jumpToLogin("services/" + itemId);
                return;
            }

            keyboard.hideSoftInputFromWindow(v.getWindowToken(), 0);
            String content = inputText.getText().toString();

            if (StrUtil.isEmpty(content)) {
                Toast.makeText(context, "请输入内容", Toast.LENGTH_LONG).show();
                return;
            }

            Long commentId = null;
            Integer type = 4;       // 默认，普通留言
            if (pre != null) {       // 普通回复
                commentId = pre.commentId;
                type = 2;
            }
            RequestCommentOpr.addComment(itemId, null, commentId, null, content, null, type, new HttpClient.HttpCallback<CommentDO>() {

                @Override
                public void onSuccess(CommentDO obj) {
                    Toast.makeText(context, "发表成功", Toast.LENGTH_SHORT).show();
                    commentsView.setVisibility(View.VISIBLE);
                    inputViewGroup.setVisibility(View.GONE);
                    detailFoot.setVisibility(View.VISIBLE);
                    noCommentsView.setVisibility(View.GONE);
                    commentAdapter.addHead(obj);
                    commentAdapter.notifyDataSetChanged();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            commentsView.setSelection(commentsView.getBottom());
                        }
                    }, 50);
                    commentSize.setVisibility(View.VISIBLE);
                    commentCount = commentCount + 1;
                    commentSize.setText(commentCount + "条评论");
                }

                @Override
                public void onFail(HttpError error) {
                    MessageUtils.showToastCenter(error.toString());
                }

            });
            inputText.setText(null);    // 清空数据
            inputText.setHint(null);
            pre = null;
        }

        public void comment() {
            inputText.setFocusable(true);
            inputText.setFocusableInTouchMode(true);
            inputText.requestFocus();
            inputText.setHint(null);
            keyboard.showSoftInput(inputText, InputMethodManager.SHOW_IMPLICIT);
            inputViewGroup.setVisibility(View.VISIBLE);
            detailFoot.setVisibility(View.GONE);
        }

        public void hideKeyword() {
            keyboard.hideSoftInputFromWindow(inputText.getWindowToken(), 0);
            inputText.setText(null);
            inputViewGroup.setVisibility(View.GONE);
            detailFoot.setVisibility(View.VISIBLE);
            pre = null;
        }

    }

}
