package com.meidalife.shz.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.ServiceManageAdapter;
import com.meidalife.shz.adapter.ServiceManageAdapter.IServiceStatusListener;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.model.ServiceItem;
import com.meidalife.shz.rest.request.RequestService;
import com.usepropeller.routable.Router;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 我发布的服务
 */
public class ServiceListPublishActivity extends BaseActivity implements IServiceStatusListener {

    static public final int PAGE_SIZE = 20;
    static private final int ITEM_UP_NOT_REAL_CERT = 136;

    ArrayList<ServiceItem> serviceItems;
    int page;
    Boolean loading;
    Boolean complete;
    Boolean isRefresh;
    ServiceManageAdapter adapter;

    @Bind(R.id.rootView)
    LinearLayout rootView;
    @Bind(R.id.listView)
    ListView listView;
    @Bind(R.id.listViewSwipe)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @Bind(R.id.publishListEmptyDataCell)
    RelativeLayout cellPublishEmpty;
    @Bind(R.id.publishListEmptyIcon)
    TextView emptyPublishIcon;
    @Bind(R.id.publishListEmptyText)
    TextView emptyPublishText;
    View listFooter;
    TextView footerMessage;
    ProgressBar footerLoading;
    Button footerReload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_list_publish);
        ButterKnife.bind(this);

        initActionBar(R.string.title_activity_service_list_publish, true);

        listFooter = getLayoutInflater().inflate(R.layout.view_list_footer, null);
        footerLoading = (ProgressBar) listFooter.findViewById(R.id.loading);
        footerMessage = (TextView) listFooter.findViewById(R.id.message);
        footerReload = (Button) listFooter.findViewById(R.id.footerReload);
        listView.addFooterView(listFooter);
        listFooter.setVisibility(View.GONE);
        emptyPublishIcon.setTypeface(Helper.sharedHelper().getIconFont());

        serviceItems = new ArrayList<ServiceItem>();
        loading = false;
        complete = false;
        isRefresh = false;
        page = 0;

        initAdapter();
        initListView();
        loadData();
    }

    private void loadData() {
        serviceItems.clear();
        mSwipeRefreshLayout.setVisibility(View.GONE);
        cellPublishEmpty.setVisibility(View.GONE);
        showStatusLoading(rootView);
        hideStatusErrorServer();
        hideStatusErrorNetwork();
        xhrServices();
    }

    private void initAdapter() {
        adapter = new ServiceManageAdapter(this, serviceItems);
        adapter.setServiceStatusListener(this);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ServiceItem item = serviceItems.get(position);
                Router.sharedRouter().open("detail/" + item.getItemId());
            }
        });
    }

    private void initListView() {
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                handleRefresh();
            }
        });
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {

            private boolean moveToBottom = false;
            private int previous = 0;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (previous < firstVisibleItem) {
                    moveToBottom = true;
                } else if (previous > firstVisibleItem) {
                    moveToBottom = false;
                }
                previous = firstVisibleItem;

                if (totalItemCount == firstVisibleItem + visibleItemCount && moveToBottom) {
                    /* 需要加载更多数据的代码 */
                    loadNext();
                }
            }
        });
    }

    private org.json.JSONObject getParams(int page) {
        org.json.JSONObject params;
        try {
            params = new org.json.JSONObject();
            params.put("userId", Helper.sharedHelper().getUserId());
            params.put("pageSize", PAGE_SIZE);
            params.put("offset", page * PAGE_SIZE);
        } catch (org.json.JSONException e) {
            params = null;
        }

        return params;
    }

    private void xhrServices() {
        MeidaRestClient.RestCallback callback = new MeidaRestClient.RestCallback() {
            @Override
            public void onSuccess(Object result) {
                loading = false;
                hideStatusLoading();
                listFooter.setVisibility(View.GONE);

                ArrayList<ServiceItem> items = (ArrayList<ServiceItem>) result;
                if (items.size() < PAGE_SIZE) {
                    complete = true;
                }
                if (isRefresh) {
                    isRefresh = false;
                    serviceItems.clear();
                    mSwipeRefreshLayout.setRefreshing(false);
                }
                serviceItems.addAll(items);
                adapter.notifyDataSetChanged();

                // 空数据
                if (serviceItems.size() == 0) {
                    cellPublishEmpty.setVisibility(View.VISIBLE);
                    emptyPublishText.setText(getString(R.string.profile_empty_publish_myself));
                } else {
                    mSwipeRefreshLayout.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(HttpError error) {
                loading = false;
                hideStatusLoading();
                listFooter.setVisibility(View.GONE);

                // refresh
                if (page == 0) {
                    mSwipeRefreshLayout.setRefreshing(false);

                    if (error != null && error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                        showStatusErrorNetwork(rootView);
                        setOnClickErrorNetwork(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                loadData();
                            }
                        });
                        return;
                    }

                    showStatusErrorServer(rootView);
                    setTextErrorServer(error != null ? error.getMessage() : getResources().getString(R.string.error_server_500));
                    setOnClickErrorServer(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            loadData();
                        }
                    });
                }
                // load next
                else {
                    page--;
                    if (error != null) {
                        if (error.getCode() == HttpError.ERR_CODE_NETWORK_CODE) {
                            footerReload.setText("网络异常，点击重试");
                        } else {
                            footerReload.setText(error.getMessage() + "，点击重试");
                        }
                    } else {
                        footerReload.setText("发生一个未知错误，点击重试");
                    }
                    footerReload.setVisibility(View.VISIBLE);
                    footerLoading.setVisibility(View.GONE);
                    footerMessage.setVisibility(View.GONE);
                    footerReload.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            footerLoading.setVisibility(View.VISIBLE);
                            footerReload.setVisibility(View.GONE);
                            loadNext();
                        }
                    });
                }
            }
        };

        if (loading) {
            return;
        }

        listFooter.setVisibility(View.VISIBLE);
        loading = true;

        RequestService.getMyPublishList(getParams(page), callback);
    }

    private void handleRefresh() {
        isRefresh = true;
        page = 0;
        Log.i("Taber", "refresh profile");
        xhrServices();
    }

    private void loadNext() {
        if (!loading && !complete) {
            page++;
            Log.i("Taber", "load next profile");
            xhrServices();
        }
    }

    @Override
    public void touch(String itemId) {
        JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("id", itemId);
        HttpClient.get("1.0/item/update/touch", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        MessageUtils.showToastCenter("上头条成功，快去首页看看吧");
                    }

                    @Override
                    public void onFail(HttpError error) {
                        MessageUtils.showToastCenter("上头条失败" + error.getMessage());
                    }
                }
        );
    }

    //删除服务
    @Override
    public void remove(final String itemId) {
        MessageUtils.createDialog(ServiceListPublishActivity.this, "提醒", "确认删除服务？删除之后无法恢复", R.string.confirm, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteItem(itemId);
            }
        }, R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // do nothing
            }
        }).show();
    }

    void deleteItem(String itemId) {
        JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("id", itemId);
        HttpClient.get("1.0/item/update/delete", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        afterRequest(true, "删除成功");
                    }

                    @Override
                    public void onFail(HttpError error) {
                        afterRequest(false, "删除失败" + error.getMessage());
                    }
                }
        );
    }

    //下架服务
    @Override
    public void downShelf(final String itemId) {
        MessageUtils.createDialog(ServiceListPublishActivity.this, "确定下架该服务？", "下架后服务将无法被发现和查看", R.string.confirm, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                itemDownShelf(itemId);
            }
        }, R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // do nothing
            }
        }).show();
    }

    void itemDownShelf(String itemId) {
        JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("id", itemId);
        HttpClient.get("1.0/item/update/downShelf", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        afterRequest(true, "下架成功");
                    }

                    @Override
                    public void onFail(HttpError error) {
                        afterRequest(false, "下架失败" + error.getMessage());
                    }
                }
        );
    }

    //上架
    @Override
    public void upShelf(String itemId) {
        JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("id", itemId);
        HttpClient.get("1.0/item/update/upShelf", params, JSONObject.class, new HttpClient.HttpCallback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject obj) {
                        afterRequest(true, "上架成功");
                    }

                    @Override
                    public void onFail(HttpError error) {
                        if (error.getCode() == ITEM_UP_NOT_REAL_CERT) {
                            getCertificateUserDialog(error.getMessage()).show();
                        } else {
                            afterRequest(false, "上架失败" + error.getMessage());
                        }

                    }
                }
        );
    }

    void afterRequest(boolean needReload, String msg) {
        if (needReload) {
            loadData();
        }
        MessageUtils.showToastCenter(msg);
    }

    private AlertDialog getCertificateUserDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setPositiveButton("立即认证", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Router.sharedRouter().open("certificationlist");
                    }
                })
                .setNegativeButton("下次再说", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
        return builder.create();
    }

}
