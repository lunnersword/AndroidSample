package com.meidalife.shz.activity.fragment;

import android.support.v4.app.Fragment;
import android.view.KeyEvent;


/**
 * Created by zhq on 15/10/22.
 */
public class BaseFragment extends Fragment {

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public boolean onFragmentKeyDown(int keyCode, KeyEvent event) {
        return false;
    }
}
