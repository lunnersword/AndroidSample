package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.facebook.drawee.generic.RoundingParams;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.model.UserItem;
import com.meidalife.shz.util.ImgUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fufeng on 15/12/22.
 */
public class SquareUserAvatarAdapter extends RecyclerView.Adapter<SquareUserAvatarAdapter.ViewHolder> {
    private List<UserItem> data = new ArrayList<>();
    private Context mContext;
    private final int ICON_SIZE;

    public SquareUserAvatarAdapter(Context context, List<UserItem> data) {
        mContext = context;
        setData(data);
        ICON_SIZE = mContext.getResources().getDimensionPixelSize(R.dimen.square_user_small_icon_size);
    }

    public void setData(List<UserItem> data) {
        this.data = data;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.item_single_simple_drawee_view, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        SimpleDraweeView imageView = (SimpleDraweeView) view.findViewById(R.id.image);
        RoundingParams roundingParams = RoundingParams.asCircle();
        imageView.getHierarchy().setRoundingParams(roundingParams);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);//居中显示
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ICON_SIZE, ICON_SIZE);
        imageView.setLayoutParams(params);
        imageView.setPadding(0,
                mContext.getResources().getDimensionPixelSize(R.dimen.square_user_icon_padding),
                mContext.getResources().getDimensionPixelSize(R.dimen.square_user_icon_padding) * 2,
                mContext.getResources().getDimensionPixelSize(R.dimen.square_user_icon_padding));
        viewHolder.avatar = imageView;
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final UserItem item = data.get(position);
        if (!TextUtils.isEmpty(item.getUserAvatar())) {
            String cdnUrl = ImgUtil.getCDNUrlWithWidth(item.getUserAvatar(),
                    mContext.getResources().getDimensionPixelSize(R.dimen.square_user_small_icon_size));
            holder.avatar.setImageURI(Uri.parse(cdnUrl));
        } else {
            holder.avatar.setImageURI(ImgUtil.getDefaultAvatarUri(mContext,
                    item.getUserId(), item.getUserGender()));
        }

//        holder.avatar.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Router.sharedRouter().open("profile/" + item.getUserId());
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        SimpleDraweeView avatar;

        public ViewHolder(View itemView) {
            super(itemView);
        }
    }
}
