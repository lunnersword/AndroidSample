package com.meidalife.shz;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.alipay.sdk.app.PayTask;
import com.meidalife.shz.rest.model.PayResult;
import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

import org.json.JSONObject;

/**
 * Created by taber on 15/6/19.
 */
public class Pay {
    public static final int PAY_WAY_NONE = 0;
    public static final int PAY_WAY_ALIPAY = 1;
    public static final int PAY_WAY_WECHAT = 2;
    public static final int PAY_WAY_FUND = 3;
    public static final int PAY_WAY_MCOIN = 4;
    public static final int PAY_WAY_COUPON = 0;

    //todo 清理静态变量
    public static final String ACION_PAY_RESULT = "com.meidalife.shz.ACION_PAY_RESULT";
    public static final String TAG_ERROR_CODE = "errCode";

    //0 表示不需要支付 1 表示需要支付
    public static final String TAG_NEED_PAY = "needPay";
    //支付方式 1 支付宝 2 微信
    public static final String TAG_PAY_WAY = "payway";
    public static final String TAG_PAY_TYPE = "type";
    public static final String TAG_PAY_TRADE_NUMBER = "tradeNo";
    public static final String TAG_PAY_RESULT = "result";

    private static final int SDK_PAY_FLAG = 1;
    private static final int SDK_CHECK_FLAG = 2;

    public static void payWithAlipay(final Activity activity, final String payInfo, final PayCallback callback) {
        final Handler mHandler = new Handler() {
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case SDK_PAY_FLAG: {
                        PayResult payResult = new PayResult((String) msg.obj);
//                        String resultInfo = payResult.getResult();
                        String resultStatus = payResult.getResultStatus();

                        if (TextUtils.equals(resultStatus, "9000")) {
                            callback.success();
                        } else {
                            if (TextUtils.equals(resultStatus, "8000")) {
                                callback.failure(new Error("支付结果确认中"));
                            } else if (TextUtils.equals(resultStatus, "6001")) {
                                callback.failure(new Error("您已取消付款"));
                            } else {
                                callback.failure(new Error("支付失败，请重试"));
                            }
                        }
                        break;
                    }
                    case SDK_CHECK_FLAG: {
                        callback.failure(new Error((String) msg.obj));
                        break;
                    }
                    default:
                        break;
                }
            }

            ;
        };

        Runnable payRunnable = new Runnable() {
            @Override
            public void run() {
                // 构造PayTask 对象
                PayTask alipay = new PayTask(activity);
                // 调用支付接口，获取支付结果
                String result = alipay.pay(payInfo);

                Message msg = new Message();
                msg.what = SDK_PAY_FLAG;
                msg.obj = result;
                mHandler.sendMessage(msg);
            }
        };

        // 必须异步调用
        Thread payThread = new Thread(payRunnable);
        payThread.start();
    }

    public static void payWithWechat(Context context, JSONObject json) {
        if (!Helper.isPackageExist(context, "com.tencent.mm")) {
            MessageUtils.showToast(context.getString(R.string.pay_error_wechat_not_exist));
            return;
        }
        IWXAPI api = WXAPIFactory.createWXAPI(context, Constant.APP_ID_WECHAT);
        PayReq req = new PayReq();

        req.appId = Constant.APP_ID_WECHAT;
        req.partnerId = json.optString("partnerId");
        req.prepayId = json.optString("prepayId");
        req.packageValue = json.optString("packageStr");
        req.nonceStr = json.optString("nonceStr");
        req.timeStamp = json.optString("timeStamp");
        req.sign = json.optString("sign");
        api.registerApp(Constant.APP_ID_WECHAT);
        api.sendReq(req);
    }

    public static void payWithWechat(Context context, com.alibaba.fastjson.JSONObject json) {
        if (!Helper.isPackageExist(context, "com.tencent.mm")) {
            MessageUtils.showToast(context.getString(R.string.pay_error_wechat_not_exist));
            return;
        }
        IWXAPI api = WXAPIFactory.createWXAPI(context, Constant.APP_ID_WECHAT);
        PayReq req = new PayReq();

        req.appId = Constant.APP_ID_WECHAT;
        req.partnerId = json.getString("partnerId");
        req.prepayId = json.getString("prepayId");
        req.packageValue = json.getString("packageStr");
        req.nonceStr = json.getString("nonceStr");
        req.timeStamp = json.getString("timeStamp");
        req.sign = json.getString("sign");
        api.registerApp(Constant.APP_ID_WECHAT);
        api.sendReq(req);
    }

    public interface PayCallback {
        public void success();

        public void failure(Error error);
    }
}
