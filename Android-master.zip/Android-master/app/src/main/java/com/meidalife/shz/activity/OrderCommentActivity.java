package com.meidalife.shz.activity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.alibaba.fastjson.JSONObject;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.adapter.CommentAdapter;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.CommentDO;
import com.meidalife.shz.util.LoadUtilV2;
import com.meidalife.shz.util.StrUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by shijian on 15/7/17.
 */
public class OrderCommentActivity extends BaseActivity implements AbsListView.OnScrollListener {

    private Context context;
    private LayoutInflater inflater;

    private ViewGroup rootView;
    private View contentRoot;
    private LoadUtilV2 loadHelper;

    private ListView commentListView;
    private CommentAdapter adapter;
    private ProgressBar footPb;

    private String orderNum;

    private String itemId;
    private int pageSize = 20;
    private int page = 0;
    private boolean isMoreData = true;
    private boolean isLoading = false;
    private int previous;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_comment_list);
        initActionBar(R.string.title_comment_order_list, true);

        context = getApplicationContext();
        inflater = getLayoutInflater();

        Bundle extras = getIntent().getExtras();
        if (extras.get("orderNum") != null) {
            orderNum = extras.getString("orderNum");
        } else if (extras.get("itemId") != null) {
            itemId = extras.getString("itemId");
        }

        rootView = (ViewGroup) findViewById(R.id.root_view);
        contentRoot = findViewById(R.id.content_root_view);
        loadHelper = new LoadUtilV2(inflater);

        commentListView = (ListView) findViewById(R.id.comment_list_view);
        View foot = inflater.inflate(R.layout.fragment_comment_foot, null);
        commentListView.addFooterView(foot);
        footPb = (ProgressBar) foot.findViewById(R.id.detail_comment_foot_pb);

        initLoadData();
    }

    public void initLoadData() {

        loadHelper.loadPre(rootView, contentRoot);

        JSONObject params = new JSONObject();

        if (!StrUtil.isEmpty(orderNum)) {
            params.put("orderNumber", orderNum);
            HttpClient.get("1.0/comment/getCommentByOrder", params, CommentDO.class, new HttpClient.HttpCallback<CommentDO>() {
                @Override
                public void onSuccess(final CommentDO obj) {
                    loadHelper.loadSuccess(contentRoot);
                    List<CommentDO> commentList = new ArrayList<CommentDO>();
                    commentList.add(obj);
                    adapter = new CommentAdapter(context, inflater, commentList);
                    commentListView.setAdapter(adapter);
                    if (obj.getCanModify() == 0) {  //可修改评论
                        showActionBarRightButton();
                        mButtonRight.setText(R.string.btn_change_address);
                        mButtonRight.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Helper.sharedHelper().hasToken()) {
                                    Bundle bundle = new Bundle();
                                    bundle.putString("canModify", "0");
                                    bundle.putString("userId", obj.getUserId() + "");
                                    Router.sharedRouter().open("orderJudge/1/" + obj.getItemId() + "/" + orderNum, bundle);
                                    finish();
                                } else
                                    Router.sharedRouter().open("signin");
                            }
                        });
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    loadHelper.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                        @Override
                        public void retry() {
                            initLoadData();
                        }
                    });
                }
            });

        } else if (!StrUtil.isEmpty(itemId)) {
            params = genParams(0);
            HttpClient.get("1.0/comment/getComment", params, CommentDO.class, new HttpClient.HttpCallback<List<CommentDO>>() {
                @Override
                public void onSuccess(List<CommentDO> dataList) {
                    loadHelper.loadSuccess(contentRoot);
                    adapter = new CommentAdapter(context, inflater, dataList);
                    commentListView.setAdapter(adapter);
                    commentListView.setOnScrollListener(OrderCommentActivity.this);
                }

                @Override
                public void onFail(HttpError error) {
                    loadHelper.loadFail(error, rootView, new LoadUtilV2.RetryCallback() {
                        @Override
                        public void retry() {
                            initLoadData();
                        }
                    });
                }
            });
        }

    }


    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (!isMoreData) {
            return;
        }
        if (isLoading) { // 若已经在加载中，则忽略
            return;
        }
        boolean moveToBottom = false;
        if (previous <= firstVisibleItem) {
            moveToBottom = true;
        }
        previous = firstVisibleItem;
        if ((totalItemCount <= firstVisibleItem + visibleItemCount) && moveToBottom) {
            isLoading = true;
            footPb.setVisibility(View.VISIBLE);
            page++;
            HttpClient.get("1.0/comment/getComment", genParams(page), CommentDO.class, new HttpClient.HttpCallback<List<CommentDO>>() {
                @Override
                public void onSuccess(List<CommentDO> dataList) {
                    isLoading = false;
                    if (dataList.size() == 0) {
                        isMoreData = false;
                        footPb.setVisibility(View.GONE);
                    } else {
                        adapter.add(dataList);
                        adapter.notifyDataSetChanged();
                        footPb.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onFail(HttpError error) {
                    isLoading = false;
                    MessageUtils.showToastCenter(error.getMessage());
                    page--;
                    footPb.setVisibility(View.GONE);
                }
            });
        }
    }


    public com.alibaba.fastjson.JSONObject genParams(int page) {
        com.alibaba.fastjson.JSONObject params = new com.alibaba.fastjson.JSONObject();
        params.put("itemId", itemId);
        params.put("pageSize", pageSize);
        params.put("offset", page * pageSize);
        params.put("typeList", "1,3");
        return params;
    }


}
