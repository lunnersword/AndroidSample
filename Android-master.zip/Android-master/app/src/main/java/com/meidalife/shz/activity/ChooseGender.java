package com.meidalife.shz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.meidalife.shz.Constant;
import com.meidalife.shz.Helper;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.MeidaRestClient;
import com.meidalife.shz.rest.request.RequestSign;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.Bind;
import butterknife.ButterKnife;

public class ChooseGender extends BaseActivity {

    private Boolean isRealUser;
    private String gender;

    @Bind(R.id.maleCheck)
    TextView maleCheck;
    @Bind(R.id.femaleCheck)
    TextView femaleCheck;

    @Bind(R.id.chooseMale)
    View chooseMale;
    @Bind(R.id.chooseFemale)
    View chooseFemale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_gender);
        initActionBar(R.string.title_activity_gender, true, true);
        ButterKnife.bind(this);
        maleCheck.setTypeface(Helper.sharedHelper().getIconFont());
        femaleCheck.setTypeface(Helper.sharedHelper().getIconFont());
        gender = null;
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        String preGender = bundle.getString(Constant.DATA_GENDER);
        isRealUser = bundle.getBoolean("isRealUser");
        if (isRealUser) {
            mButtonRight.setEnabled(false);
            chooseMale.setEnabled(false);
            chooseFemale.setEnabled(false);
        }

        chooseMale();
        if (preGender != null) {
            if ("女".equals(preGender))
                chooseFemale();
        }

        mButtonRight.setText(R.string.confirm);
        mButtonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mButtonRight.setEnabled(false);

                JSONObject params = new JSONObject();
                try {
                    params.put("gender", "男".equals(gender) ? Constant.GENDER_MAN : Constant.GENDER_WOMAN);
                } catch (JSONException e) {
                }
                RequestSign.updateProfile(params, new MeidaRestClient.RestCallback() {
                    @Override
                    public void onSuccess(Object result) {
                        MessageUtils.showToastCenter("保存成功");
                        mButtonRight.setEnabled(true);
                        Bundle bundle = new Bundle();
                        bundle.putString(Constant.DATA_GENDER, gender);
                        Intent returnIntent = new Intent();
                        returnIntent.putExtras(bundle);
                        setResult(RESULT_OK, returnIntent);
                        finish();
                    }

                    @Override
                    public void onFailure(HttpError error) {
                        MessageUtils.showToastCenter(error != null ? error.getMessage() : "保存失败，实名认证后不可更改");
                        mButtonRight.setEnabled(true);
                        finish();
                    }
                });

            }
        });
    }

    public void handleChooseMale(View view) {
        chooseMale();

    }

    private void chooseMale() {
        gender = "男";
        maleCheck.setTextColor(getResources().getColor(R.color.brand_b));
        femaleCheck.setTextColor(getResources().getColor(R.color.grey_c));
    }

    public void handleChooseFemale(View view) {
        chooseFemale();
    }

    private void chooseFemale() {
        gender = "女";
        femaleCheck.setTextColor(getResources().getColor(R.color.brand_b));
        maleCheck.setTextColor(getResources().getColor(R.color.grey_c));
    }

}
