
package com.meidalife.shz.event.type;

/**
 * Created by zuozheng on 14-10-31.
 */
public class NetworkConnectEventModel {

    public NetworkConnectTypeEnum type;
}
