package com.meidalife.shz.activity;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.meidalife.shz.Constant;
import com.meidalife.shz.MessageUtils;
import com.meidalife.shz.R;
import com.meidalife.shz.SHZApplication;
import com.meidalife.shz.adapter.AddressSuggestAdapter;
import com.meidalife.shz.location.AMapLocationManager;
import com.meidalife.shz.rest.HttpClient;
import com.meidalife.shz.rest.HttpError;
import com.meidalife.shz.rest.model.LocationDO;
import com.meidalife.shz.rest.model.PositionOutDO;
import com.meidalife.shz.util.MapDataUtil;
import com.usepropeller.routable.Router;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhq 2016/02/18
 * @description 地图拖动定位坐标 更新周边地址
 * 调用类 ChatActivity.java SquareNearByPublishActivity.java
 */
public class PickAddressActivity extends BaseMapActivity
        implements
        View.OnClickListener, AdapterView.OnItemClickListener,
        AMap.OnCameraChangeListener, AMap.OnMarkerClickListener {

    private final static String TAG = "SelectPosition";
    private ListView mListView;
    private View mLocatingView;
    private AddressSuggestAdapter mAdapter;
    private LatLng mLastPosition;
    private Double mCurLatitude;
    private Double mCurLongitude;
    private String cityCode;
//    private IconTextView mImageArrow;
    private AMapLocationManager mLocationManager;
    private boolean needLocation = false;
    private View searchBar;

    private PositionOutDO currentPosition;

    private Button confirmButton;
    private int searchType =0;

    @Override
    public int getLayoutResource() {
        return R.layout.activity_select_location_map;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!TextUtils.isEmpty(getIntent().getStringExtra("searchType")))
            searchType = Integer.parseInt(getIntent().getStringExtra("searchType"));
        initView();
        if(searchType == 0){
            initActionBar(R.string.title_select_position, true, true);
            searchBar.setVisibility(View.GONE);
            mTextTitle.setVisibility(View.VISIBLE);
        }else{
            initActionBar(R.string.title_select_position, true, true);
            searchBar.setVisibility(View.VISIBLE);
            searchBar.setOnClickListener(this);
            mTextTitle.setVisibility(View.GONE);
        }
    }

    void initView() {
        confirmButton = (Button) findViewById(R.id.action_bar_button_right);
        confirmButton.setText(R.string.confirm);
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAddressSelected();
            }
        });
//        mImageArrow = (IconTextView) findViewById(R.id.location_position);
//        mImageArrow.setTypeface(Helper.sharedHelper().getIconFont());
//        mImageArrow.setOnClickListener(this);
        mLocatingView = this.findViewById(R.id.address_locating_icon);

        mLocatingView.setOnClickListener(this);
        mAdapter = new AddressSuggestAdapter(this);
        mAdapter.setIsShowSelected(true);
        mListView = (ListView) this.findViewById(R.id.nearby_address_list);
        mListView.setOnItemClickListener(this);
        mListView.setAdapter(mAdapter);
        searchBar = this.findViewById(R.id.searchBar);

    }

    void initData() {
        currentPosition = new PositionOutDO();
        mLocationManager = SHZApplication.getInstance().getLocationManager();

        LocationDO locationDO = mLocationManager.getLocation();
        if (locationDO != null) {
            mCurLongitude = locationDO.getLongitude();
            mCurLatitude = locationDO.getLatitude();
        }

        Bundle params = getIntent().getExtras();
        if (params != null) {
            mCurLongitude = params.getDouble(Constant.GPS_LONG, 0) == 0 ? mCurLongitude : params.getDouble(Constant.GPS_LONG);
            mCurLatitude = params.getDouble(Constant.GPS_LAT, 0) == 0 ? mCurLatitude : params.getDouble(Constant.GPS_LAT);
        }

        Log.v(TAG, "longitude: " + mCurLongitude + ", latitude:" + mCurLatitude);

        if (mCurLongitude != 0 || mCurLatitude != 0) {
            setIntentLbsLocation(mCurLongitude, mCurLatitude);
        } else {
            getCurrentLbsLocation();
        }
    }

    void setIntentLbsLocation(double curLongitude, double curLatitude) {
        mCurLongitude = curLongitude;
        mCurLatitude = curLatitude;
    }

    void getCurrentLbsLocation() {
        mLocationManager.updateLocation(mLocationChangedListener);
    }

    /**
     * 定位监听
     */
    private AMapLocationManager.LocationChangedListener mLocationChangedListener = new AMapLocationManager.LocationChangedListener() {

        @Override
        public void onLocationUpdateFailed() {
            needLocation = false;
        }

        @Override
        public void onLocationChanged(LocationDO location) {
            mCurLongitude = location.getLongitude();
            mCurLatitude = location.getLatitude();
            cityCode = location.getCityCode();

            if (needLocation) {
                needLocation = false;
            }

            LatLng currentLln = new LatLng(mCurLatitude, mCurLongitude);
            if(tagMarker != null ){
                nowLongitude = mCurLongitude;
                nowLatitude = mCurLatitude;
                tagMarker.setPosition(currentLln);
            }
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
            aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        }
    };

    @Override
    protected void onSetUpAMap() {
        super.onSetUpAMap();
        initData();
        aMap.getUiSettings().setZoomControlsEnabled(false);
        aMap.setOnCameraChangeListener(this);
        addMark(mCurLongitude, mCurLatitude, "", "", true);
        if(tagMarker == null){
            nowLongitude = mCurLongitude;
            nowLatitude = mCurLatitude;
            addMarkTag(mCurLongitude, mCurLatitude, "", "", true);
            mapDataUtil = new MapDataUtil(tagMarker,aMap);
        }
    }

    private void addMark(Double Longitude, Double Latitude, String descripe, String snippet, boolean isZoom) {

        try {
            LatLng llA = new LatLng(Latitude, Longitude);
            MarkerOptions markerOption = new MarkerOptions();
            markerOption.position(llA);
            markerOption.title(descripe);
            markerOption.snippet(snippet);
            markerOption.anchor(0.5f, 1f);
            markerOption.draggable(true);
            if ("".equals(snippet))
                markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
            else
                markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.icn_map_current));
            aMap.addMarker(markerOption);
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(llA));
            if (isZoom)
                aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
            aMap.setOnMarkerClickListener(this);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 用户点击了，选择这个位置
     */
    public void processSelectLocation() {
        if (mAdapter != null && mAdapter.getCount() > 0) {
            currentPosition = mAdapter.getItem(0);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.address_locating_icon) {
            needLocation = true;
            getCurrentLbsLocation();

        } else if (v.getId() == R.id.location_position) {
            processSelectLocation();
        } else if(v.getId() == R.id.searchBar){
            // TODO: 16/1/31 跳转到搜索页
            Bundle bundle = new Bundle();
            bundle.putString("cityCode", TextUtils.isEmpty(cityCode)?"":cityCode);
            bundle.putString("lng", "" + mCurLongitude);
            bundle.putString("lat", "" + mCurLatitude);

            Router.sharedRouter().openFormResult("searchaddresssquare", bundle, Constant.REQUEST_CODE_PICK_ADDRESS, PickAddressActivity.this);
        }
    }

    @Override
    public void onCameraChange(CameraPosition cameraPosition) {
        Log.v(TAG, "onCameraChange: " + cameraPosition.toString());
//        mImageArrow.setVisibility(View.VISIBLE);
    }

    /**
     * 对移动地图结束事件回调
     */
    @Override
    public void onCameraChangeFinish(CameraPosition cameraPosition) {
        Log.v(TAG, "onCameraChangeFinish:" + cameraPosition.toString());

        TranslateAnimation animation = getVerticalTranslateAnimation();
//        mImageArrow.setAnimation(animation);
        animation.startNow();
        onLocationChanged(cameraPosition.target);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK && requestCode == Constant.REQUEST_CODE_PICK_ADDRESS) {
            Bundle extras = data.getExtras();
            PositionOutDO mSelectPosition = (PositionOutDO) extras.getSerializable("positionDO");

            if (mSelectPosition != null) {
//                mCurLongitude = mSelectPosition.getPoiLongitude();
//                mCurLatitude = mSelectPosition.getPoiLatitude();

//                nowLongitude = mCurLongitude;
//                nowLatitude = mCurLatitude;
                LatLng position = new LatLng(mSelectPosition.getPoiLatitude(),mSelectPosition.getPoiLongitude());
                //tagMarker.setPosition(position);
                aMap.moveCamera(CameraUpdateFactory.changeLatLng(position));
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void onLocationChanged(LatLng position) {
        if (mLastPosition != null
                && mLastPosition.equals(position)) {
            //Do not search same address again.
            return;
        }
        //点击移动的回调不触发
        if(mapDataUtil != null && (mapDataUtil.getIsRunning()
                || mapDataUtil.isMoveCallBack() ))
            return;
        mLastPosition = position;

        mCurLongitude = position.longitude;
        mCurLatitude = position.latitude;

        nowLongitude = mCurLongitude;
        nowLatitude = mCurLatitude;
        tagMarker.setPosition(position);

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("poiLongitude", String.valueOf(mCurLongitude));
            jsonObject.put("poiLatitude", String.valueOf(mCurLatitude));
            jsonObject.put("keyword", "");
            jsonObject.put("offset", "40");
            jsonObject.put("type", 2);
            HttpClient.get("1.0/address/search", jsonObject, JSONObject.class, callback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    HttpClient.HttpCallback<JSONObject> callback = new HttpClient.HttpCallback<JSONObject>() {
        @Override
        public void onSuccess(JSONObject jsonObj) {
            JSONArray resultArray = jsonObj.getJSONArray("results");

            List<PositionOutDO> poiList = new ArrayList<PositionOutDO>();
            if (resultArray != null && resultArray.size() > 0) {
                for (int index = 0; index < resultArray.size(); index++) {
                    JSONObject json = (JSONObject) resultArray.get(index);
                    String name = json.getString("name");
                    String address = json.getString("address");
                    double poiLongitude = json.getDouble("poiLongitude");
                    double poiLatitude = json.getDouble("poiLatitude");

                    PositionOutDO poi = new PositionOutDO();
                    poi.setPoiLongitude(poiLongitude);
                    poi.setPoiLatitude(poiLatitude);
                    poi.setName(name);
                    poi.setAddress(address);
                    poiList.add(poi);
                }
            }

            mAdapter.setData(poiList);
            mAdapter.setCurrentPosition(0);
            mAdapter.notifyDataSetChanged();
//            mListView.setSelection(0);
            if (poiList.size() > 0)
                currentPosition = poiList.get(0);
            mListView.setVisibility(View.VISIBLE);
        }

        @Override
        public void onFail(HttpError error) {
            MessageUtils.showToast("获取附近地址失败: " + error.getMessage());
        }
    };

    private TranslateAnimation getVerticalTranslateAnimation() {
        TranslateAnimation animation = new TranslateAnimation(0, 0, 0, -20);
        animation.setInterpolator(new DecelerateInterpolator());
        animation.setDuration(200);//设置动画持续时间
        animation.setStartOffset(0);
        animation.setRepeatCount(1);//设置重复次数
        animation.setRepeatMode(Animation.REVERSE);//设置反方向执行
        return animation;
    }

    private double nowLongitude;
    private double nowLatitude;
    private MapDataUtil mapDataUtil;
    private Marker tagMarker = null;

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if(mapDataUtil != null && mapDataUtil.getIsRunning())
            return;
        currentPosition = mAdapter.getItem(position);
        Log.v(TAG, "click address: " + currentPosition.getAddress() + currentPosition.getAddress());
        if(tagMarker == null){
            nowLongitude = mCurLongitude;
            nowLatitude = mCurLatitude;
            addMarkTag(mCurLongitude, mCurLatitude, "", "", true);
            mapDataUtil = new MapDataUtil(tagMarker,aMap);
        }
        mapDataUtil.initData(nowLongitude,nowLatitude,currentPosition.getPoiLongitude(),currentPosition.getPoiLatitude());
        nowLongitude = currentPosition.getPoiLongitude();
        nowLatitude = currentPosition.getPoiLatitude();
        mAdapter.setCurrentPosition(position);
        mAdapter.notifyDataSetChanged();
    }

    private void addMarkTag(Double Longitude, Double Latitude, String descripe, String snippet, boolean isZoom) {

        try {
            LatLng llA = new LatLng(Latitude, Longitude);
            MarkerOptions tagMarkerOption = new MarkerOptions();
            tagMarkerOption.position(llA);
            tagMarkerOption.title(descripe);
            tagMarkerOption.snippet(snippet);
            tagMarkerOption.anchor(0.5f, 1f);
            tagMarkerOption.draggable(true);
            tagMarkerOption.icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_anchor));
            tagMarker = aMap.addMarker(tagMarkerOption);
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(llA));
            if (isZoom)
                aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void onAddressSelected() {
        Intent result = new Intent();
        currentPosition.setPoiLongitude(mCurLongitude);
        currentPosition.setPoiLatitude(mCurLatitude);
        result.putExtra("INTENT_SELECTED_ADDRESS", currentPosition);
        setResult(RESULT_OK, result);
        finish();
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        if (marker.getPosition().latitude >= 0 && marker.getPosition().longitude >= 0) {
            LatLng currentLln = new LatLng(marker.getPosition().latitude, marker.getPosition().longitude);
            aMap.moveCamera(CameraUpdateFactory.changeLatLng(currentLln));
            aMap.moveCamera(CameraUpdateFactory.zoomTo(aMap.getMaxZoomLevel() - 5));
        }
        return true;
    }
}