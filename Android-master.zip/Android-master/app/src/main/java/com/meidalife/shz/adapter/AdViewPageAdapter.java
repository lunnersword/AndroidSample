package com.meidalife.shz.adapter;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.facebook.drawee.view.SimpleDraweeView;
import com.meidalife.shz.R;
import com.meidalife.shz.util.ImgUtil;
import com.usepropeller.routable.Router;

/**
 * Created by fufeng on 15/11/8.
 */
public class AdViewPageAdapter extends BasePageAdapter {
    private Context mContext;
    private JSONArray adArray = new JSONArray();
    private final int imgHeight;

    public AdViewPageAdapter(Context context) {
        imgHeight = context.getResources().getDimensionPixelSize(R.dimen.ad_view_height);
        mContext = context;
    }

    public void setData(JSONArray data) {
        adArray = data;
    }

    @Override
    public View newView(int position) {
        final JSONObject adData = adArray.getJSONObject(position);
        String imgUrl = adData.getString("pic");
        String imgCdn = ImgUtil.getCDNUrlWithHeight(imgUrl, imgHeight);

        SimpleDraweeView imageView = new SimpleDraweeView(mContext);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ViewPager.LayoutParams params = new ViewPager.LayoutParams();
        imageView.setLayoutParams(params);

        imageView.setImageURI(Uri.parse(imgCdn));
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("url", adData.getString("url"));
                Router.sharedRouter().open("web", bundle);
            }
        });
        return imageView;
    }

    @Override
    public int getCount() {
        return adArray.size();
    }
}
